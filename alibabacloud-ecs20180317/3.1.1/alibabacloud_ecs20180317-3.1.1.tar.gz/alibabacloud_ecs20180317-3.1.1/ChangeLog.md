2023-05-25 Version: 3.0.8
- DescribeDemands add PrivatePoolId.

2023-04-17 Version: 3.0.7
- Add ModifyDiskDeployment.

2023-03-28 Version: 3.0.6
- Change visibility of param ActionType in DescribeImageSupportInstanceTypes.

2023-03-27 Version: 3.0.5
- Suppoort jumbo frame.

2023-02-13 Version: 3.0.4
- Support TagPolicy Verify NoTag.
- Fixed bugs for DescribeDemands error code.
- Add encrypted disk ErrorCode.
- DescribeDedicatedHosts supports SocketDetails param to check socket capacities of specified dedicated hosts.

2023-02-06 Version: 3.0.3
- Add OpenAPI DescribeReservedInstanceAutoRenewAttribute, ModifyReservedInstanceAutoRenewAttribute.

2023-01-11 Version: 3.0.2
- Add error code for ModifyInstanceNetworkSpec.
- Add invalid account buying spot error code.
- Support ip prefix for eni.
- Update the StorageLocationArn to private.
- Security Group Rule support rule id.

2022-10-14 Version: 3.0.1
- Add GPUMemorySize to DescribeInstanceTypes api.

2022-09-27 Version: 3.0.0
- Modify Size type form int32 to int64 of `DescribePriceRequest` `DataDisk` param.

2022-07-15 Version: 2.1.3
- Support Security Group Batch Manager Rules.

2022-07-11 Version: 2.1.2
- Support Storage And Network Features For LaunchTemplate.

2022-04-27 Version: 2.1.1
- Support systemdisk encrypt and arns.

2022-04-13 Version: 4.24.17
- Support throughput for API DescribeDisks.


2021-08-27 Version: 2.1.0
- DescribeSecurityGroups support query by next token.

2021-03-22 Version: 2.0.2
- Generated python 2014-05-26 for Ecs.

2020-12-29 Version: 2.0.1
- AMP Version Change.

2020-12-28 Version: 2.0.0
- AMP Version Change.

2020-11-30 Version: 1.2.0
- Support network interface join or leave security group.

2020-11-16 Version: 1.1.0
- Nat public IP supports the ISP attribute.

2020-10-27 Version: 1.0.2
- Generated python 2014-05-26 for Ecs.

2020-09-02 Version: 1.0.1
- Generated python 2014-05-26 for Ecs.

