#!/usr/bin/env python3
"""Điểm vào dòng lệnh cho QiangDingg"""
import sys
import time
from .utils.helpers import clear_screen
from .utils.banner import show_banner, show_menu, old_clone_menu
from .utils.stats_display import show_stats
from .utils.telegram import init_telegram
from .crackers import crack_all_series, crack_series_100003_100004, crack_series_2009

def main():
    init_telegram()
    clear_screen()
    show_banner()
    from rich.console import Console
    console = Console()
    console.print("[bold green]═══════════════════════════════════════════[/bold green]")
    console.print("[bold purple]  QiangDingg - BẢN 8.0 - GIAO DIỆN XUỐNG DÒNG - ĐẦY MÀU[/bold purple]")
    console.print("[bold green]═══════════════════════════════════════════[/bold green]")
    time.sleep(1.5)
    
    while True:
        choice = show_menu()
        if choice == "1":
            sub = old_clone_menu()
            if sub == "1":
                crack_all_series()
            elif sub == "2":
                crack_series_100003_100004()
            elif sub == "3":
                crack_series_2009()
            else:
                continue
        elif choice == "2":
            show_stats()
        else:
            console.print("[bold red]Thoát.[/bold red]")
            sys.exit(0)

if __name__ == "__main__":
    main()