from setuptools import setup, find_packages
import codecs
import os



VERSION = '1.0.0'
DESCRIPTION = 'hi'

# Setting up
setup(
    name="checkscrapeinfo",
    version=VERSION,
    author="xolo",
    author_email="robokidefe@gmail.com",
    description=DESCRIPTION,
    long_description_content_type="text/markdown",
    packages=find_packages(),
)