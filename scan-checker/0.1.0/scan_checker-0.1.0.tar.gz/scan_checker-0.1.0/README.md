# QiangDingg - Facebook Account Tool

**Refactored, modularized, and secured version.**

## Installation
```bash
pip install .
```

## Usage
CLI: `qiangdingg`

Web API: `python -m qiangdingg.web.app`
