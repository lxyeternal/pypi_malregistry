def obfuscate(file):
    return
