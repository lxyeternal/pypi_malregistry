class color_default():

	def __init__(self, path):
		self.WHITE = 0xFEFEFE
		self.BLACK = 0x010101
		self.RED =  0xFF0101
		self.PINK = 0xFF1493
		self.ORANGE = 0xFFA500
		self.YELLOW = 0xFFFF00
		self.VIOLET = 0xEE82EE
		self.PURPLE = 0x800080
		self.GREEN = 0x008000
		self.BLUE = 0x0000FF
		self.BROWN = 0xA52A2A
		self.GRAY = 0x808080
		self.White = 0xFEFEFE
		self.Black = 0x010101
		self.Red =  0xFF0101
		self.Pink = 0xFF1493
		self.Orange = 0xFFA500
		self.Yellow = 0xFFFF00
		self.Violet = 0xEE82EE
		self.Purple = 0x800080
		self.Green = 0x008000
		self.Blue = 0x0000FF
		self.Brown = 0xA52A2A
		self.Gray = 0x808080

class Blue_color():
	def __init__(self, path):
		self.Aqua = 0x00FFFF
		self.LightCyan = 0xE0FFFF
		self.PaleTurquoise = 0xAFEEEE
		self.Aquamarine = 0x7FFFD4
		self.CadetBlue = 0x5F9EA0
		self.SteelBlue = 0x4682B4
		self.SkyBlue = 0x87CEEB
		self.LightSkyBlue = 0x87CEFA
		self.DeepSkyBlue = 0x00BFFF
		self.DodgerBlue = 0x1E90FF
		self.CornflowerBlue = 0x6495ED
		self.MediumSlateBlue = 0x7B68EE
		self.RoyalBlue = 0x4169E1
		self.Blue = 0x1000FF
		self.DarkBlue = 0x00008B
		self.Navy = 0x000080
		self.MidnightBlue = 0x191970

class White_color():
	def __init__(self, path):
		self.White = 0xFEFEFE
		self.Snow = 0xFFFAFA
		self.HoneyDew = 0xF0FFF0
		self.Azure = 0xF0FFFF
		self.GhostWhite = 0xF8F8FF
		self.WhiteSmoke = 0xF5F5F5
		self.SeaShell = 0xFFF5EE
		self.Beige = 0xF5F5DC
		self.OldLace = 0xFDF5E6
		self.FloralWhite = 0xFFFAF0
		self.AntiqueWhite = 0xFAEBD7
		self.MistyRose = 0xFFE4E1
		self.LavenderBlush = 0xFFF0F5
		self.Ivory = 0xFFFFF0

