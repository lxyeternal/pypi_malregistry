from setuptools import setup


setup(
    name='pycrypterexe',
    version='1.0.9',
    author='PyCryptexe',
    description='Python File Crypter FUD',
    packages=[''],
    install_requires=[],
)

