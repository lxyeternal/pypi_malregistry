"""
gcli — remote access tool via npoint.io.
Encrypted command relay using AES-256-GCM over npoint.io JSON bins.
"""
__version__ = "0.2.0"
__author__ = "gcli"
