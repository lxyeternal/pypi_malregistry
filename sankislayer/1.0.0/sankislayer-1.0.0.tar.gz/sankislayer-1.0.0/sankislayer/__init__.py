# -*- coding: utf-8 -*-
from .bot import main_run
