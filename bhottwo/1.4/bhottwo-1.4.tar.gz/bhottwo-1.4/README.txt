## BSIXv1.4
- A new Bangladeshi six digit facebook accounts passwords cracker tool for termux users

## ***About BSIX***:

BSIX is a python based script. You can use this tool for crack facebook users passwords. This tool works on both rooted Android device and Non-rooted Android device.

## Installation On Terminal
```git clone https://github.com/botolmehedi/bsix```

## How to use it?
Open terminal and type bsix or bhottwo


## ***Check this***

### Subscribe our channel on youtube:
https://www.youtube.com/MasterTrick1

### Chekout our webite:
https://www.mastertrick.design

## ***Join***

### Facebook group: 
https://www.facebook.com/groups/231747098048450

### Telegram channel:
https://t.me/mastertrick2

### Facebook page:
https://www.facebook.com/TeamVVirus

### Instagram: 
https://www.instagram.com/MehtanOfficial

### My GitHub ID link:
https://www.github.com/BotolMehedi

### Warning

***This tool is only for educational purpose. If you use this tool for other purposes except education we will not be responsible in such cases.***

## License

© 2020 Mehedi Hasan Ariyan

This repository is licensed under the MIT license. See LICENSE for details.
