from setuptools import setup, find_packages

setup(
    name="accesspdp",
    version="2.0.1",
    author="detox56",
    author_email="bughunt250+depn@gmail.com",
    description="test",
    packages=find_packages(),
    install_requires=['requests'],
)
