"""
qlinforge.formatters — Data formatting helpers.
"""

import csv
import io
import json
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional


def pretty_json(data: Any, indent: int = 2, ensure_ascii: bool = False) -> str:
    """Return a pretty-printed JSON string."""
    return json.dumps(data, indent=indent, ensure_ascii=ensure_ascii, sort_keys=False)


def csv_to_dict(csv_text: str, delimiter: str = ",") -> List[Dict[str, str]]:
    """Convert CSV text to a list of dictionaries (first row = headers)."""
    reader = csv.DictReader(io.StringIO(csv_text), delimiter=delimiter)
    return [row for row in reader]


def timestamp_to_str(
    ts: float,
    fmt: str = "%Y-%m-%d %H:%M:%S",
    utc: bool = True,
) -> str:
    """Convert a Unix timestamp to a formatted datetime string."""
    tz = timezone.utc if utc else None
    dt = datetime.fromtimestamp(ts, tz=tz)
    return dt.strftime(fmt)


def str_to_timestamp(
    s: str,
    fmt: str = "%Y-%m-%d %H:%M:%S",
) -> float:
    """Parse a datetime string and return a Unix timestamp (UTC)."""
    dt = datetime.strptime(s, fmt).replace(tzinfo=timezone.utc)
    return dt.timestamp()


def humanize_bytes(n: int, precision: int = 1) -> str:
    """Return a human-readable file size string (e.g. '1.5 GB')."""
    if n < 0:
        raise ValueError("n must be non-negative")
    units = ["B", "KB", "MB", "GB", "TB", "PB"]
    size = float(n)
    for unit in units:
        if size < 1024.0:
            return f"{size:.{precision}f} {unit}"
        size /= 1024.0
    return f"{size:.{precision}f} EB"
