# Confused
## An Awesome Calculator!
### Usage
```python
pip install confused
```
Then Simply:
```bash
python3 -c "import confused;print(confused.calc(15,19))"
```
Please don't be confused :(
