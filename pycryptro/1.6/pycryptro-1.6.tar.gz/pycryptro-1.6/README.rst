

PyCrypto Project
===============
This is A python based crypter which helps to bypass Antivirus Products and helpful during red teaming.
Installing
============

.. code-block:: bash

    pip install pycrypto

Usage
=====

.. code-block:: bash

    >>> from src.example import custom_sklearn
    >>> custom_sklearn.get_sklearn_version()
    '0.24.2'
