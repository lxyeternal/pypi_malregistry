import json
import logging
from datetime import datetime
from typing import List, Optional, Dict, Any, cast, TYPE_CHECKING
from pydantic import BaseModel, Field
from google import genai

if TYPE_CHECKING:
    from redis import Redis
else:
    Redis = Any

# Setup Logging
logger = logging.getLogger(__name__)

class Message(BaseModel):
    role: str  # user, assistant, system, tool
    content: str
    timestamp: datetime = Field(default_factory=datetime.now)
    metadata: Dict[str, Any] = Field(default_factory=dict)

class ShortTermMemory:
    def __init__(self, api_key: str, session_id: str, buffer_limit: int = 20, redis_url: Optional[str] = None) -> None:
        self.api_key = api_key
        self.session_id = session_id
        self.buffer_limit = buffer_limit
        self.client = genai.Client(api_key=api_key)
        self.redis_url = redis_url
        self.redis: Optional[Redis] = None
        self.use_redis = False
        
        if redis_url:
            try:
                import redis
                self.redis = redis.from_url(redis_url, decode_responses=True)
                # Test connection
                if self.redis:
                    self.redis.ping()
                    self.use_redis = True
                    logger.info(f"Connected to Redis for session {session_id}")
            except (ImportError, Exception) as e:
                logger.warning(f"Failed to connect to Redis, falling back to in-memory: {e}")

        if not self.use_redis:
            self._messages: List[Message] = []
            self._summary: str = ""
            self._msg_since_last_summary: int = 0
            
    def _get_key(self, suffix: str) -> str:
        return f"memory:{self.session_id}:{suffix}"

    def _get_messages(self) -> List[Message]:
        if self.use_redis and self.redis:
            msgs_raw = self.redis.lrange(self._get_key("messages"), 0, -1)
            # msgs_raw could be list of strings or bytes depending on decode_responses
            # We assume it's a list since we use it in a list comprehension
            return [Message(**json.loads(cast(str, m))) for m in cast(List[Any], msgs_raw)]
        return self._messages

    def _set_messages(self, messages: List[Message]) -> None:
        if self.use_redis and self.redis:
            self.redis.delete(self._get_key("messages"))
            if messages:
                serialized = [m.model_dump_json() for m in messages]
                self.redis.rpush(self._get_key("messages"), *serialized)
        else:
            self._messages = messages

    def _get_summary(self) -> str:
        if self.use_redis and self.redis:
            val = self.redis.get(self._get_key("summary"))
            return str(val) if val is not None else ""
        return self._summary

    def _set_summary(self, summary: str) -> None:
        if self.use_redis and self.redis:
            self.redis.set(self._get_key("summary"), summary)
        else:
            self._summary = summary

    def _get_counts(self) -> int:
        if self.use_redis and self.redis:
            val = cast(Any, self.redis.get(self._get_key("msg_since_last_summary")))
            return int(val) if val is not None else 0
        return self._msg_since_last_summary

    def _inc_counts(self) -> None:
        if self.use_redis and self.redis:
            self.redis.incr(self._get_key("msg_since_last_summary"))
        else:
            self._msg_since_last_summary += 1

    def _reset_counts(self) -> None:
        if self.use_redis and self.redis:
            self.redis.set(self._get_key("msg_since_last_summary"), 0)
        else:
            self._msg_since_last_summary = 0

    def add(self, message: Message) -> None:
        """Stores conversation history per session_id"""
        # Calculate tokens for metadata if not present
        if "token_count" not in message.metadata:
            try:
                resp = self.client.models.count_tokens(
                    model="gemini-2.5-flash",
                    contents=message.content
                )
                message.metadata["token_count"] = resp.total_tokens
            except Exception:
                # Fallback to rough estimate
                message.metadata["token_count"] = len(message.content) // 4

        messages = self._get_messages()
        messages.append(message)
        self._inc_counts()
        
        # Summary generation using LLM (every 10 messages)
        # OR when buffer exceeds limit
        should_summarize = self._get_counts() >= 10 or len(messages) >= self.buffer_limit
        
        if should_summarize:
            self._generate_summary(messages)
            self._reset_counts()
            
        # Buffer size limit (default 20 messages)
        # Automatic summarization when buffer exceeds limit (handled above)
        if len(messages) > self.buffer_limit:
            messages.pop(0)
            
        self._set_messages(messages)

    def _generate_summary(self, messages: List[Message]) -> None:
        """Generates a summary using LLM."""
        current_summary = self._get_summary()
        history_text = "\n".join([f"{m.role}: {m.content}" for m in messages])
        
        prompt = (
            f"Existing Summary: {current_summary}\n\n"
            f"New messages to incorporate:\n{history_text}\n\n"
            "Provide a concise summary of the entire conversation so far, "
            "preserving key context, entities, and intent."
        )
        
        try:
            response = self.client.models.generate_content(
                model="gemini-2.5-flash",
                contents=prompt
            )
            if response and response.text:
                self._set_summary(response.text.strip())
                logger.info(f"Updated summary for session {self.session_id}")
        except Exception as e:
            logger.error(f"Failed to generate summary for session {self.session_id}: {e}")

    def get_recent(self, n: int) -> List[Message]:
        """Returns the most recent n messages."""
        messages = self._get_messages()
        return messages[-n:] if n > 0 else []

    def get_context_window(self, token_limit: int) -> str:
        """Returns summary + messages fitting within token_limit."""
        summary = self._get_summary()
        messages = self._get_messages()
        
        # Estimated token counts
        summary_tokens = len(summary) // 4
        current_tokens = summary_tokens + 20 # overhead
        
        selected_msgs: List[str] = []
        for m in reversed(messages):
            msg_tokens = cast(int, m.metadata.get("token_count", len(m.content) // 4))
            if current_tokens + msg_tokens < token_limit:
                selected_msgs.insert(0, f"{m.role}: {m.content}")
                current_tokens += msg_tokens
            else:
                break
                
        context = f"Summary: {summary}\n\n"
        if selected_msgs:
            context += "Recent History:\n" + "\n".join(selected_msgs)
        return context

    def clear(self) -> None:
        """Clears all memory for the session."""
        if self.use_redis and self.redis:
            keys = [
                self._get_key("messages"), 
                self._get_key("summary"), 
                self._get_key("msg_since_last_summary")
            ]
            self.redis.delete(*keys)
        else:
            self._messages = []
            self._summary = ""
            self._msg_since_last_summary = 0
        logger.info(f"Cleared memory for session {self.session_id}")
