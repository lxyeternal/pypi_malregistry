"""
Roblox Catalog API - https://catalog.roblox.com
Covers item search, item details, bundles, and resale data.
"""

from typing import List, Optional


class CatalogAPI:
    BASE = "https://catalog.roblox.com/v1"
    BASE2 = "https://catalog.roblox.com/v2"

    def __init__(self, client):
        self._c = client

    # ------------------------------------------------------------------ #
    #  Search                                                              #
    # ------------------------------------------------------------------ #

    def search_catalog(
        self,
        keyword: str = "",
        category: str = "All",
        subcategory: str = "All",
        sort_type: str = "Relevance",
        sort_aggregation: int = 5,
        price_min: Optional[int] = None,
        price_max: Optional[int] = None,
        limit: int = 30,
        cursor: Optional[str] = None,
        include_not_for_sale: bool = False,
    ) -> dict:
        """
        Search the Roblox avatar shop / catalog.

        Args:
            category: "All", "Clothing", "Accessories", "AvatarAnimations",
                      "BodyParts", "Gear", "Models", "Plugins", "Decals",
                      "Audio", "Meshes", "Images", "MeshParts".
            subcategory: Varies by category (e.g. "TShirts", "Hats").
            sort_type: "Relevance", "Favorited", "Sales", "Updated",
                       "PriceAsc", "PriceDesc".
            sort_aggregation: Time window — 5=All time, 1=Past day, 3=Past week.
            limit: 10, 28, 30, or 120.

        Returns:
            dict: {keyword, previousPageCursor, nextPageCursor,
                   data: [{id, name, itemType, assetType, bundleType,
                            description, productId, genres, bundledItems,
                            itemStatus, itemRestrictions, creatorType,
                            creatorTargetId, creatorName, price,
                            premiumPricing, lowestPrice, purchaseCount,
                            favoriteCount, offSaleDeadline}, ...]}
        """
        params = {
            "category": category,
            "subcategory": subcategory,
            "sortType": sort_type,
            "sortAggregation": sort_aggregation,
            "limit": limit,
            "includeNotForSale": include_not_for_sale,
        }
        if keyword:
            params["keyword"] = keyword
        if price_min is not None:
            params["minPrice"] = price_min
        if price_max is not None:
            params["maxPrice"] = price_max
        if cursor:
            params["cursor"] = cursor
        return self._c._get(f"{self.BASE}/search/items", params=params)

    # ------------------------------------------------------------------ #
    #  Item details                                                        #
    # ------------------------------------------------------------------ #

    def get_item_details(self, items: List[dict]) -> dict:
        """
        Get details for multiple catalog items.

        Args:
            items: List of {itemType: "Asset"|"Bundle", id: int}

        Returns:
            dict: {data: [{id, itemType, assetType, name, description,
                            productId, price, ...}, ...]}
        """
        return self._c._post(
            f"{self.BASE}/catalog/items/details",
            json={"items": items},
        )

    def get_asset_details(self, asset_id: int) -> dict:
        """
        Shortcut to get a single asset's details.
        """
        data = self.get_item_details([{"itemType": "Asset", "id": asset_id}])
        results = data.get("data", [])
        return results[0] if results else {}

    def get_bundle_details(self, bundle_id: int) -> dict:
        """
        Get details of a specific bundle.

        Returns:
            dict: {id, name, description, bundleType, items, creator,
                    product, ...}
        """
        return self._c._get(f"{self.BASE}/bundles/{bundle_id}/details")

    def get_bundles_by_ids(self, bundle_ids: List[int]) -> dict:
        """
        Get multiple bundles by ID.

        Returns:
            dict: {data: [...]}
        """
        return self._c._get(
            f"{self.BASE}/bundles/details",
            params={"bundleIds": ",".join(str(i) for i in bundle_ids)},
        )

    # ------------------------------------------------------------------ #
    #  User / group catalog                                                #
    # ------------------------------------------------------------------ #

    def get_user_bundles(self, user_id: int, bundle_type: Optional[str] = None,
                         limit: int = 10, cursor: Optional[str] = None) -> dict:
        """
        Get bundles owned by a user.

        Returns:
            dict: {previousPageCursor, nextPageCursor, data: [...]}
        """
        params = {"limit": limit}
        if bundle_type:
            params["bundleType"] = bundle_type
        if cursor:
            params["cursor"] = cursor
        url = (f"{self.BASE}/users/{user_id}/bundles"
               if not bundle_type
               else f"{self.BASE}/users/{user_id}/bundles/{bundle_type}")
        return self._c._get(url, params=params)

    def get_group_items(self, group_id: int, category: str = "2",
                        limit: int = 30, cursor: Optional[str] = None) -> dict:
        """
        Get catalog items created by a group.

        Args:
            category: Asset category integer as string ("2" = clothing, etc.)

        Returns:
            dict: {previousPageCursor, nextPageCursor, data: [...]}
        """
        params = {"category": category, "limit": limit}
        if cursor:
            params["cursor"] = cursor
        return self._c._get(
            f"{self.BASE2}/search/items",
            params={**params, "creatorType": "Group",
                    "creatorTargetId": group_id},
        )

    # ------------------------------------------------------------------ #
    #  Resale / economy                                                    #
    # ------------------------------------------------------------------ #

    def get_asset_resale_data(self, asset_id: int) -> dict:
        """
        Get resale price history and seller data for a limited item.

        Returns:
            dict: {assetStock, sales, numberRemaining, recentAveragePrice,
                   originalPrice, priceDataPoints: [{value, date}],
                   volumeDataPoints: [{value, date}]}
        """
        return self._c._get(
            f"https://economy.roblox.com/v1/assets/{asset_id}/resale-data"
        )

    def get_asset_resellers(self, asset_id: int, limit: int = 10,
                            cursor: Optional[str] = None) -> dict:
        """
        Get users currently reselling a limited item.

        Returns:
            dict: {previousPageCursor, nextPageCursor,
                   data: [{userAssetId, seller, price, serialNumber}, ...]}
        """
        params = {"limit": limit}
        if cursor:
            params["cursor"] = cursor
        return self._c._get(
            f"https://economy.roblox.com/v1/assets/{asset_id}/resellers",
            params=params,
        )

    # ------------------------------------------------------------------ #
    #  Favorites                                                           #
    # ------------------------------------------------------------------ #

    def get_asset_favorite_count(self, asset_id: int) -> dict:
        """
        Get the number of users who have favorited an asset.

        Returns:
            int (the count)
        """
        resp = self._c._get(
            f"{self.BASE}/favorites/assets/{asset_id}/count"
        )
        return resp

    def get_bundle_favorite_count(self, bundle_id: int) -> dict:
        """Get favorite count for a bundle."""
        return self._c._get(
            f"{self.BASE}/favorites/bundles/{bundle_id}/count"
        )
