# -*- coding: utf-8 -*-

"""Top-level package for AWS Consoler."""

__author__ = """Ian Williams"""
__email__ = 'ian.williams@netspi.com'
__version__ = '1.1.0'
