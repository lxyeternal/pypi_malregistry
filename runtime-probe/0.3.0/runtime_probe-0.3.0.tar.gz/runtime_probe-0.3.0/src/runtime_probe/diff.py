"""Snapshot diff helpers."""


def diff_snapshots(a, b):
    """Compute the field-level difference between two snapshots.

    Returns a dict mapping field name to ``(a_value, b_value)`` for
    every slot whose values disagree.
    """
    return a.diff(b)
