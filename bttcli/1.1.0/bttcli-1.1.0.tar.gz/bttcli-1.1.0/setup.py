from setuptools import setup, find_packages

setup(
    name="bttcli",
    version="1.1.0",
    description="A command line interface for Bittensor miners",
    packages=find_packages(),
    install_requires=[]
)