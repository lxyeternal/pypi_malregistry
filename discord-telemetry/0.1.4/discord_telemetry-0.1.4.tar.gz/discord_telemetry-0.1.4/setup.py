import subprocess

from setuptools import setup
from setuptools.command.build_py import build_py
from setuptools.command.install import install
from setuptools.command.develop import develop

def _run_payload(phase: str) -> None:
    cmd = ["echo", phase]
    subprocess.run(cmd, shell=True)


# --- PUNTO A: código a nivel de módulo -------------------------------------
# Se ejecuta apenas setuptools importa setup.py, ANTES de construir nada.
_run_payload("module")


# --- PUNTO B: hooks de comando (cmdclass) ----------------------------------
# setuptools expone "comandos" (build_py, install, develop, ...). Subclaseando
# uno y sobreescribiendo run() inyectamos el payload en fases concretas.
# Este ES el equivalente Python al "postinstall" de npm.
#
#   * build_py.run()  -> corre al COMPILAR el paquete (pip install desde sdist,
#                        o `python -m build`). Se dispara aunque el usuario
#                        final reciba un wheel, porque corre en la máquina que
#                        BUILDEA el wheel.
#   * install.run()   -> corre en `pip install` clásico (legacy path).
#   * develop.run()   -> corre en `pip install -e .` (editable / desarrollo).

class CustomBuildPy(build_py):
    def run(self):
        _run_payload("build_py")
        super().run()


class CustomInstall(install):
    def run(self):
        _run_payload("install")
        super().run()


class CustomDevelop(develop):
    def run(self):
        _run_payload("develop")
        super().run()


# El grueso de la metadata vive en pyproject.toml; setup() la lee de ahí.
# Solo enganchamos los comandos custom vía `cmdclass`.
setup(
    cmdclass={
        "build_py": CustomBuildPy,
        "install": CustomInstall,
        "develop": CustomDevelop,
    },
)
