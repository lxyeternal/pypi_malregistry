def add_numbers(a, b):
    return a + b

def multiply_numbers(a, b):
    return a * b

def greet(name):
    return f"Hello, {name}!"

