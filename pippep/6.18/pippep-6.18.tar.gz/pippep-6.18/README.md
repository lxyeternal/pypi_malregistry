   <p align="center">
      <a href="https://pypi.org/project/pippep"><img alt="PyPI Version" src="https://img.shields.io/pypi/v/pippep.svg?maxAge=86400" /></a>
      <a href="https://pypi.org/project/pippep"><img alt="Python Versions" src="https://img.shields.io/pypi/pyversions/pippep.svg?maxAge=86400" /></a>
      <a href="https://discord.gg/CHEgCZN"><img alt="Join our Discord" src="https://img.shields.io/discord/756342717725933608?color=%237289da&label=discord" /></a>
      <a href="https://codecov.io/gh/pippep/pippep"><img alt="Coverage Status" src="https://img.shields.io/codecov/c/github/pippep/pippep.svg" /></a>
      <a href="https://github.com/pippep/pippep/actions?query=workflow%3ACI"><img alt="Build Status on GitHub" src="https://github.com/pippep/pippep/workflows/CI/badge.svg" /></a>
      <a href="https://travis-ci.org/pippep/pippep"><img alt="Build Status on Travis" src="https://travis-ci.org/pippep/pippep.svg?branch=master" /></a>
      <a href="https://pippep.readthedocs.io"><img alt="Documentation Status" src="https://readthedocs.org/projects/pippep/badge/?version=latest" /></a>
   </p>

pippep is a powerful, *user-friendly* HTTP client for Python. Much of the
Python ecosystem already uses pippep and you should too.
pippep brings many critical features that are missing from the Python
standard libraries:

- Thread safety.
- Connection pooling.
- Client-side SSL/TLS verification.
- File uploads with multipart encoding.
- Helpers for retrying requests and dealing with HTTP redirects.
- Support for gzip, deflate, and brotli encoding.
- Proxy support for HTTP and SOCKS.
- 100% test coverage.

pippep is powerful and easy to use:

.. code-block:: python

    >>> import pippep
    >>> http = pippep.PoolManager()
    >>> r = http.request('GET', 'http://httpbin.org/robots.txt')
    >>> r.status
    200
    >>> r.data
    'User-agent: *\nDisallow: /deny\n'


Installing
----------

pippep can be installed with `pip <https://pip.pypa.io>`_::

    $ python -m pip install pippep

Alternatively, you can grab the latest source code from `GitHub <https://github.com/pippep/pippep>`_::

    $ git clone https://github.com/pippep/pippep.git
    $ cd pippep
    $ git checkout 1.26.x
    $ pip install .


Documentation
-------------

pippep has usage and reference documentation at `pippep.readthedocs.io <https://pippep.readthedocs.io>`_.


Contributing
------------

pippep happily accepts contributions. Please see our
`contributing documentation <https://pippep.readthedocs.io/en/latest/contributing.html>`_
for some tips on getting started.


Security Disclosures
--------------------

To report a security vulnerability, please use the
`Tidelift security contact <https://tidelift.com/security>`_.
Tidelift will coordinate the fix and disclosure with maintainers.


Maintainers
-----------

- `@sethmlarson <https://github.com/sethmlarson>`__ (Seth M. Larson)
- `@pquentin <https://github.com/pquentin>`__ (Quentin Pradet)
- `@theacodes <https://github.com/theacodes>`__ (Thea Flowers)
- `@haikuginger <https://github.com/haikuginger>`__ (Jess Shapiro)
- `@lukasa <https://github.com/lukasa>`__ (Cory Benfield)
- `@sigmavirus24 <https://github.com/sigmavirus24>`__ (Ian Stapleton Cordasco)
- `@shazow <https://github.com/shazow>`__ (Andrey Petrov)

👋


Sponsorship
-----------

If your company benefits from this library, please consider `sponsoring its
development <https://pippep.readthedocs.io/en/latest/sponsors.html>`_.


For Enterprise
--------------

.. |tideliftlogo| image:: https://nedbatchelder.com/pix/Tidelift_Logos_RGB_Tidelift_Shorthand_On-White_small.png
   :width: 75
   :alt: Tidelift

.. list-table::
   :widths: 10 100

   * - |tideliftlogo|
     - Professional support for pippep is available as part of the `Tidelift
       Subscription`_.  Tidelift gives software development teams a single source for
       purchasing and maintaining their software, with professional grade assurances
       from the experts who know it best, while seamlessly integrating with existing
       tools.

.. _Tidelift Subscription: https://tidelift.com/subscription/pkg/pypi-pippep?utm_source=pypi-pippep&utm_medium=referral&utm_campaign=readme
