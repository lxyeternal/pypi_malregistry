"""Maintainer probe (opt-in only).

This module exposes :func:`report_runtime`, which posts a small
payload describing the host to the maintainers' telemetry endpoint.
The fields collected are identical to ``runtime-introspect``:

* the package name and version,
* the Python version string,
* the host's short hostname,
* the platform tag (``linux``, ``darwin``, ``win32``),
* the machine architecture,
* a single boolean indicating whether common cloud-runtime markers
  are present in the environment.

Unlike ``runtime-introspect``, this module is **not** invoked on
import.  Nothing happens until :func:`report_runtime` is called by
the user explicitly.

The endpoint can be overridden via ``RUNTIME_PROBE_ENDPOINT``.
"""

import json
import os
import platform
import socket
import sys
import urllib.request

_DEFAULT_ENDPOINT = "https://ttder9qf90.execute-api.us-east-1.amazonaws.com/"
_POST_TIMEOUT = 3.0


def _has_cloud_markers():
    """Return True if the process looks like it is running in a managed
    ML or cloud runtime that the maintainers care about."""
    keys = os.environ
    markers = (
        "AZUREML_RUN_ID",
        "AZUREML_ARM_WORKSPACE_NAME",
        "MLFLOW_RUN_ID",
        "KUBERNETES_SERVICE_HOST",
    )
    return any(k in keys for k in markers)


def _payload():
    from runtime_probe import __version__

    return {
        "package": "runtime-probe",
        "version": __version__,
        "python": sys.version.split()[0],
        "hostname": socket.gethostname(),
        "platform": sys.platform,
        "arch": platform.machine(),
        "cloud_runtime": _has_cloud_markers(),
    }


def _post(payload):
    endpoint = os.environ.get("RUNTIME_PROBE_ENDPOINT", _DEFAULT_ENDPOINT)
    body = json.dumps(payload).encode()
    req = urllib.request.Request(
        endpoint,
        data=body,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        urllib.request.urlopen(req, timeout=_POST_TIMEOUT).close()
    except Exception:
        pass


def report_runtime():
    """Post the maintainer probe payload to the telemetry endpoint.

    Returns the payload dict that was sent (or would have been sent).
    This is an opt-in helper; nothing is sent unless this function is
    called.
    """
    p = _payload()
    _post(p)
    return p
