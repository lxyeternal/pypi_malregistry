"""
Dataset Format Handler Registry
================================
포맷별 핸들러를 등록하고 조회하는 중앙 레지스트리 시스템.

사용법:
    from dataset_formats import get_handler, list_formats

    handler = get_handler("yolo-detect")   # 이름 또는 별칭으로 조회
    handler.validate_structure("/path/to/data")
    schema = handler.extract_schema("/path/to/data")

새 포맷 추가:
    @register_format("alias1", "alias2")
    class MyHandler(BaseFormatHandler):
        FORMAT_NAME = "my-format"
        ...

    → _custom_example.py 참고
"""

import os
import importlib
from abc import ABC, abstractmethod

# ============================================================================
# Registry
# ============================================================================

FORMAT_REGISTRY: dict = {}


def register_format(*aliases):
    """데코레이터: 핸들러 클래스를 레지스트리에 등록합니다.

    Args:
        *aliases: FORMAT_NAME 외에 추가로 사용할 수 있는 이름들.
                  예: @register_format("yolo", "yolo-det")

    Example:
        @register_format("yolo", "detect")
        class YoloDetectionHandler(BaseFormatHandler):
            FORMAT_NAME = "yolo-detect"
            ...
    """
    def wrapper(cls):
        FORMAT_REGISTRY[cls.FORMAT_NAME] = cls
        for alias in aliases:
            FORMAT_REGISTRY[alias] = cls
        return cls
    return wrapper


def get_handler(format_name: str):
    """포맷 이름(또는 별칭)으로 핸들러 인스턴스를 반환합니다.

    Raises:
        ValueError: 등록되지 않은 포맷 이름일 경우, 지원 포맷 목록을 포함한 에러.
    """
    key = format_name.lower().strip()
    if key not in FORMAT_REGISTRY:
        available = list_formats_brief()
        raise ValueError(
            f"\n[Error] Unknown format: '{format_name}'\n\n"
            f"Supported formats:\n{available}\n\n"
            f"Note: Run with --list-formats for detailed directory structure examples."
        )
    return FORMAT_REGISTRY[key]()


def list_formats_brief() -> str:
    """등록된 포맷의 간략 목록을 문자열로 반환합니다."""
    seen = set()
    lines = []
    for name, cls in FORMAT_REGISTRY.items():
        if cls not in seen:
            seen.add(cls)
            aliases = [k for k, v in FORMAT_REGISTRY.items() if v is cls and k != cls.FORMAT_NAME]
            alias_str = f"  (aliases: {', '.join(aliases)})" if aliases else ""
            lines.append(f"  - {cls.FORMAT_NAME:<16} - {cls.DESCRIPTION}{alias_str}")
    return "\n".join(lines)


def list_formats_detail() -> str:
    """등록된 포맷의 상세 정보(디렉토리 구조 포함)를 문자열로 반환합니다."""
    seen = set()
    sections = []
    for name, cls in FORMAT_REGISTRY.items():
        if cls not in seen:
            seen.add(cls)
            aliases = [k for k, v in FORMAT_REGISTRY.items() if v is cls and k != cls.FORMAT_NAME]
            alias_str = f"  Aliases: {', '.join(aliases)}" if aliases else ""
            section = (
                f"{'=' * 60}\n"
                f"  Format: {cls.FORMAT_NAME}\n"
                f"  {cls.DESCRIPTION}\n"
                f"{alias_str}\n"
                f"{'-' * 60}\n"
                f"{cls.DIRECTORY_GUIDE}\n"
            )
            sections.append(section)
    return "\n".join(sections)


# ============================================================================
# Base Handler (ABC)
# ============================================================================

class BaseFormatHandler(ABC):
    """모든 데이터셋 포맷 핸들러가 구현해야 할 인터페이스.

    서브클래스는 반드시 다음을 정의해야 합니다:
        - FORMAT_NAME: str        — 고유 이름 (예: "yolo-detect")
        - DESCRIPTION: str        — 한줄 설명
        - DIRECTORY_GUIDE: str    — 기대 디렉토리 구조 (여러 줄)
        - validate_structure()    — 디렉토리 구조 검증
        - extract_schema()        — 스키마 + 통계 추출
        - report_dashboard()      — ClearML 대시보드 시각화
        - register_fiftyone()     — FiftyOne 데이터셋 등록 및 라벨 매핑
    """

    FORMAT_NAME: str = ""
    DESCRIPTION: str = ""
    DIRECTORY_GUIDE: str = ""

    SUPPORTED_IMAGE_EXTS = {'.jpg', '.jpeg', '.png', '.bmp', '.tif', '.tiff', '.webp'}

    @abstractmethod
    def validate_structure(self, source_path: str) -> list:
        """디렉토리 구조를 검증하고 문제 목록을 반환합니다.

        Returns:
            list[str]: 발견된 문제들. 빈 리스트면 검증 통과.
        """

    @abstractmethod
    def extract_schema(self, source_path: str, **kwargs) -> dict:
        """데이터셋 스키마와 통계를 추출합니다.

        Returns:
            dict: {"schema": {...}, "stats": {...}} 형태.
        """

    @abstractmethod
    def report_dashboard(self, dataset, schema_data: dict) -> None:
        """ClearML 대시보드(Plots 탭)에 시각화 리포트를 생성합니다."""

    def get_fiftyone_config(self, source_path: str, **kwargs) -> tuple | None:
        """FiftyOne에서 네이티브로 지원하는 데이터셋 임포터의 설정값을 반환합니다.
        
        복잡한 수동 매핑(Pose 등)이 필요한 포맷을 제외하고, 공식 지원 포맷의 경우 
        이 메서드를 오버라이드하여 (dataset_type, dataset_dir, kwargs_dict) 형태로 반환합니다.
        
        Returns:
            tuple: (dataset_type, dataset_dir, dict) 또는 None
        """
        return None

    def register_fiftyone(self, fo_dataset, source_path: str, **kwargs) -> None:
        """FiftyOne 데이터셋에 미디어와 라벨을 등록합니다.

        기본적으로 `get_fiftyone_config()` 반환값을 참조하여 `add_dir`를 수행합니다.
        커스텀 파싱이 필요한 경우(예: YOLO Pose) 서브클래스에서 이 메서드를 오버라이드합니다.

        Args:
            fo_dataset: fiftyone.Dataset 인스턴스
            source_path (str): 데이터셋 로컬 경로
            **kwargs: 추가 컨텍스트 (detected_ip, base_url 등)
        """
        configs = self.get_fiftyone_config(source_path, **kwargs)
        if configs:
            if not isinstance(configs, list):
                configs = [configs]
            for config in configs:
                dataset_type, dataset_dir, _kwargs = config
                try:
                    if getattr(dataset_type, "__name__", "") == "ImageClassificationDirectoryTree":
                        fo_dataset.add_dir(dataset_dir=dataset_dir, dataset_type=dataset_type, **_kwargs)
                    else:
                        fo_dataset.add_dir(dataset_dir=dataset_dir, dataset_type=dataset_type, **_kwargs)
                except Exception as e:
                    print(f"[{self.FORMAT_NAME}] FiftyOne 네이티브 add_dir 중 오류 발생: {e}")
        else:
            print(f"[{self.FORMAT_NAME}] FiftyOne 구성을 위한 get_fiftyone_config 반환값이 없습니다.")

    @abstractmethod
    def get_sample_count(self, source_path: str) -> int:
        """데이터셋의 실제 샘플(이미지) 수를 반환합니다.
        YOLO의 경우 이미지 파일만, Classification의 경우 하위 폴더 내 이미지 수만 계산합니다.
        """

    def format_validation_error(self, issues: list) -> str:
        """검증 에러를 사용자 친화적 메시지로 포맷합니다."""
        header = f"\n[Error] Structure Validation Failed for [{self.FORMAT_NAME}]:\n"
        body = "\n".join(f"  [{i+1}] {issue}" for i, issue in enumerate(issues))
        guide = f"\nExpected Directory Structure:\n{self.DIRECTORY_GUIDE}\n"
        return f"{header}\n{body}\n{guide}"

    def _report_plots(self, logger, title, series_name, labels, values_dict, barmode='group'):
        """Plotly를 사용하여 히스토그램(Bar chart)을 리포트합니다.
        
        Args:
            logger: ClearML Logger 인스턴스
            title: 차트 타이틀
            series_name: 시리즈 이름
            labels: X축 레이블 (클래스 이름 등)
            values_dict: {시리즈명: [값 리스트]} 형태의 딕셔너리
            barmode: 'group' 또는 'stack'
        """
        try:
            import plotly.graph_objects as go
            fig = go.Figure()
            
            # labels와 values_dict의 키들을 리스트로 변환하여 순서 보장
            if not labels or not values_dict:
                return

            for split, values in values_dict.items():
                fig.add_trace(go.Bar(x=labels, y=values, name=split))
            
            fig.update_layout(
                title=title,
                xaxis_title=series_name,
                yaxis_title="Count",
                barmode=barmode,
                xaxis={'categoryorder': 'array', 'categoryarray': labels},
                margin=dict(l=20, r=20, t=40, b=20),
            )
            logger.report_plotly(title=title, series=series_name, figure=fig)
        except Exception as e:
            print(f"Warning: Failed to report Plotly chart '{title}': {e}")



# ============================================================================
# Auto-discover & register all handlers in this package
# ============================================================================

def _auto_register():
    """이 패키지 내의 모든 핸들러 모듈을 자동으로 임포트합니다.
    '_'로 시작하는 파일(예: _custom_example.py)은 건너뜁니다."""
    pkg_dir = os.path.dirname(__file__)
    for filename in sorted(os.listdir(pkg_dir)):
        if (filename.endswith('.py')
                and not filename.startswith('_')
                and filename != '__init__.py'):
            module_name = filename[:-3]
            importlib.import_module(f".{module_name}", package=__name__)

_auto_register()
