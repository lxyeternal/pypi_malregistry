"""
YOLO Pose/Keypoint Handler
============================
YOLO Pose Estimation (keypoint) 포맷 핸들러.

라벨 형식:
    <class_id> <cx> <cy> <w> <h> <kp1_x> <kp1_y> <kp1_v> <kp2_x> <kp2_y> <kp2_v> ...
    - bbox: normalized center_x, center_y, width, height
    - keypoints: normalized x, y + visibility (0=없음, 1=가림, 2=보임)

YAML 필수 키:
    kpt_shape: [17, 3]    # [num_keypoints, dims_per_keypoint(x,y,v)]

FiftyOne 연동:
    FiftyOne은 YOLO Pose를 직접 지원하지 않으므로,
    수동으로 fo.Keypoints 객체를 생성하여 등록합니다.

사용 예:
    python upload_dataset.py --format yolo-pose --local_dir ./pose_data ...
"""

import os

from . import register_format
from .yolo_base import YoloBaseHandler


@register_format("pose", "keypoint", "kpt", "yolo-pose", "yolo-kpt")
class YoloPoseHandler(YoloBaseHandler):
    FORMAT_NAME = "yolo-pose"
    DESCRIPTION = "YOLO Pose/Keypoint — TXT keypoint labels + YAML config (kpt_shape required)"
    DIRECTORY_GUIDE = """
    your_dataset/
    ├── dataset.yaml (or data.yaml)
    │   ├── names: {0: person}
    │   ├── kpt_shape: [17, 3]                 # [num_keypoints, dims] ← Required!
    │   ├── task: pose
    │   ├── train: train/images
    │   └── val: val/images
    ├── train/
    │   ├── images/
    │   │   └── img001.jpg
    │   └── labels/
    │       └── img001.txt
    ├── val/
    │   ├── images/
    │   └── labels/
    └── test/  (optional)

    📋 Label format (each line = one person/object with keypoints):
       <cls> <cx> <cy> <w> <h> <kp1_x> <kp1_y> <kp1_v> <kp2_x> <kp2_y> <kp2_v> ...

       - <cls>: class index
       - <cx> <cy> <w> <h>: bounding box (normalized)
       - <kp_x> <kp_y>: keypoint coordinates (normalized)
       - <kp_v>: visibility (0=not labeled, 1=occluded, 2=visible)

    Example (COCO 17-keypoint, img001.txt):
       0 0.45 0.50 0.20 0.60 0.45 0.25 2 0.44 0.24 2 0.46 0.24 1 ...

    ⚠️  kpt_shape 필드가 없으면 업로드가 거부됩니다.
        COCO 기준: kpt_shape: [17, 3]
        커스텀 키포인트: kpt_shape: [N, 3] (N = 정의한 키포인트 수)
    """

    def _default_task_type(self):
        return "pose"

    def _validate_format_specific(self, source_path, yaml_data):
        """kpt_shape 키 존재 여부 및 형식 확인."""
        issues = []
        kpt_shape = yaml_data.get('kpt_shape')
        if not kpt_shape:
            issues.append(
                "'kpt_shape' key is missing in YAML. "
                "Pose format requires kpt_shape (e.g., kpt_shape: [17, 3])."
            )
        elif not isinstance(kpt_shape, list) or len(kpt_shape) != 2:
            issues.append(
                f"'kpt_shape' must be [num_keypoints, dims]. Got: {kpt_shape}"
            )
        return issues

    def _extra_schema_fields(self, yaml_data):
        """kpt_shape를 스키마에 포함."""
        kpt_shape = yaml_data.get('kpt_shape', [])
        fields = {}
        if kpt_shape:
            fields['kpt_shape'] = kpt_shape
            fields['num_keypoints'] = kpt_shape[0] if len(kpt_shape) > 0 else 0
        # flip_idx (좌우 대칭 키포인트 매핑)
        flip_idx = yaml_data.get('flip_idx')
        if flip_idx:
            fields['flip_idx'] = flip_idx
        return fields

    def _init_extra_stats(self):
        return {
            "visibility_counts": {"visible": 0, "occluded": 0, "not_labeled": 0},
            "total_keypoints_checked": 0,
        }

    def _parse_label_file(self, lbl_path, img_path, names,
                          ins_per_class, extra_stats, use_pixel_stats):
        try:
            with open(lbl_path, 'r') as f:
                for line in f:
                    parts = line.strip().split()
                    if len(parts) >= 6:  # at least class + bbox(4) + 1 keypoint dim
                        cid = int(parts[0])
                        if 0 <= cid < len(names):
                            ins_per_class[cid] += 1

                        # Keypoint visibility stats (triplets after bbox)
                        kp_start = 5
                        kp_values = parts[kp_start:]
                        for i in range(2, len(kp_values), 3):  # every 3rd value is visibility
                            try:
                                v = float(kp_values[i])
                                if v == 0:
                                    extra_stats["visibility_counts"]["not_labeled"] += 1
                                elif v == 1:
                                    extra_stats["visibility_counts"]["occluded"] += 1
                                elif v == 2:
                                    extra_stats["visibility_counts"]["visible"] += 1
                                extra_stats["total_keypoints_checked"] += 1
                            except (ValueError, IndexError):
                                pass
        except Exception:
            pass

    def report_dashboard(self, dataset, schema_data):
        if not schema_data:
            return
        try:
            schema = schema_data.get('schema', {})
            stats = schema_data.get('stats', {})

            dataset._task.connect_configuration(
                configuration={"schema": schema, "stats": stats},
                name='dataset_schema'
            )

            tags = dataset.tags or []
            if "POSE" not in tags:
                dataset.tags = tags + ["POSE"]

            logger = dataset._task.get_logger()
            if not stats:
                return

            # 1. Image/Label Summary
            summary_data = [["Split", "Images", "Labeled", "Background"]]
            for s, v in stats.items():
                summary_data.append([
                    s, v['images'],
                    v.get('labeled_images', 0),
                    v.get('background_images', 0)
                ])
            logger.report_table("Dataset Health", "Image/Label Summary",
                                table_plot=summary_data)

            # 2. Class Distribution
            class_data = [["Class Name"]]
            split_names = list(stats.keys())
            for s in split_names:
                class_data[0].append(f"{s} (Ins)")
            class_data[0].append("Total")

            for i, name in enumerate(schema.get('names', [])):
                row = [name]
                total_ins = 0
                for s in split_names:
                    count = stats[s].get('instances_per_class', {}).get(i, 0)
                    row.append(count)
                    total_ins += count
                row.append(total_ins)
                class_data.append(row)
            logger.report_table("Dataset Analysis", "Class Distribution",
                                table_plot=class_data)

            # 2.2 Plotly Histogram (New)
            plot_values = {s: [] for s in split_names}
            total_values = []
            labels = schema.get('names', [])
            for i in range(len(labels)):
                total_ins = 0
                for s in split_names:
                    count = stats[s].get('instances_per_class', {}).get(i, 0)
                    plot_values[s].append(count)
                    total_ins += count
                total_values.append(total_ins)
            
            plot_values["Total"] = total_values
            self._report_plots(
                logger, 
                title="Class Distribution (Histogram)", 
                series_name="Class Name", 
                labels=labels, 
                values_dict=plot_values
            )


            # 3. Keypoint Visibility (전체 합산)
            total_vis = {"visible": 0, "occluded": 0, "not_labeled": 0}
            total_checked = 0
            for s, v in stats.items():
                vis = v.get("visibility_counts", {})
                for k in total_vis:
                    total_vis[k] += vis.get(k, 0)
                total_checked += v.get("total_keypoints_checked", 0)

            if total_checked > 0:
                kp_data = [["Visibility", "Count", "Percentage"]]
                for label, count in total_vis.items():
                    pct = f"{count / total_checked * 100:.1f}%"
                    kp_data.append([label.replace("_", " ").title(), count, pct])
                kp_data.append(["Total Checked", total_checked, "100%"])
                logger.report_table("Dataset Analysis", "Keypoint Visibility",
                                    table_plot=kp_data)

        except Exception as e:
            print(f"Dashboard Reporting Warning: {e}")

    def register_fiftyone(self, fo_dataset, source_path: str, **kwargs) -> None:
        """YOLO Pose 수동 파싱 및 FiftyOne 등록."""
        import fiftyone as fo
        from tqdm import tqdm

        yaml_path = self._find_yaml(source_path)
        data = self._load_yaml(yaml_path)
        names = data.get('names', {})
        if isinstance(names, dict):
            names = {int(k): v for k, v in names.items()}
        else:
            names = {i: v for i, v in enumerate(names)}

        kpt_shape = data.get('kpt_shape', [17, 3])
        num_kpts = kpt_shape[0]

        for split in ['train', 'val', 'test']:
            split_p = data.get(split)
            if not split_p:
                continue

            abs_split_path = self._resolve_split_path(source_path, data, split_p)
            if not os.path.exists(abs_split_path):
                continue

            img_dir, lbl_dir = self._discover_img_lbl_dirs(abs_split_path)
            
            # 1. 이미지 + 라벨 스캔
            print(f"  Scanning images and parsing YOLO Pose labels for [{split}]...")
            samples = []
            
            # 이미지 파일 목록 탐색
            for root, _, files in os.walk(img_dir):
                for f in files:
                    if os.path.splitext(f)[1].lower() in self.SUPPORTED_IMAGE_EXTS:
                        img_path = os.path.join(root, f)
                        rel_base = os.path.splitext(os.path.relpath(img_path, img_dir))[0]
                        lbl_path = os.path.join(lbl_dir, rel_base + ".txt")

                        sample = fo.Sample(filepath=img_path, tags=[split])
                        
                        if os.path.exists(lbl_path):
                            detections = []
                            keypoints_list = []
                            
                            try:
                                with open(lbl_path, "r") as lf:
                                    for line in lf:
                                        parts = list(map(float, line.strip().split()))
                                        if len(parts) < 5:
                                            continue
                                        
                                        label = names.get(int(parts[0]), str(int(parts[0])))
                                        
                                        # Box (cx, cy, w, h) -> [x, y, w, h] (top-left rel)
                                        cx, cy, w, h = parts[1:5]
                                        detections.append(fo.Detection(
                                            label=label,
                                            bounding_box=[cx - w/2, cy - h/2, w, h]
                                        ))

                                        # Keypoints
                                        kp_data = parts[5:]
                                        points = []
                                        import math
                                        for i in range(0, min(len(kp_data), num_kpts * 3), 3):
                                            if i + 1 < len(kp_data):
                                                px, py = kp_data[i], kp_data[i+1]
                                                vis = kp_data[i+2] if i + 2 < len(kp_data) else 1.0
                                                # 처리: YOLO에서는 안 보이는 점을 보통 (0, 0) 또는 vis=0으로 표기합니다.
                                                if (px == 0.0 and py == 0.0) or vis == 0.0:
                                                    points.append((math.nan, math.nan))
                                                else:
                                                    points.append((px, py))
                                        
                                        if points:
                                            keypoints_list.append(fo.Keypoint(
                                                label=label,
                                                points=points
                                            ))
                                
                                if detections:
                                    sample["ground_truth"] = fo.Detections(detections=detections)
                                if keypoints_list:
                                    sample["keypoints"] = fo.Keypoints(keypoints=keypoints_list)
                                    
                            except Exception as e:
                                print(f"Warning: Failed to parse {lbl_path}: {e}")
                        
                        samples.append(sample)

            if samples:
                fo_dataset.add_samples(samples)

        # Skeleton 설정 (COCO 17-kpt인 경우 자동 설정)
        if num_kpts == 17:
             fo_dataset.default_skeleton = fo.KeypointSkeleton(
                labels=[
                    "nose", "left eye", "right eye", "left ear", "right ear",
                    "left shoulder", "right shoulder", "left elbow", "right elbow",
                    "left wrist", "right wrist", "left hip", "right hip",
                    "left knee", "right knee", "left ankle", "right ankle",
                ],
                edges=[
                    [11, 5, 3, 1, 0, 2, 4, 6, 12],
                    [9, 7, 5, 6, 8, 10],
                    [15, 13, 11, 12, 14, 16],
                ],
            )
