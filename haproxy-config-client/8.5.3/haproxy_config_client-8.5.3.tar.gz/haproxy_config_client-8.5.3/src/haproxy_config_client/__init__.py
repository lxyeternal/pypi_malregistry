"""environment config reader"""
__version__ = "8.5.3"
