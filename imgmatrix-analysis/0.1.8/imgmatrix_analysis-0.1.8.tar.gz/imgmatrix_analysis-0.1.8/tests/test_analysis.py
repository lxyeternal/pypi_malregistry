"""Tests for the analysis module."""

import numpy as np
import pytest

from imageanalysis import ImageMatrix
from imageanalysis import analysis


class TestAnalysis:
    """Tests for analysis functions."""
    
    def test_histogram(self):
        """Test histogram calculation."""
        img = ImageMatrix.zeros(100, 100, 3)
        
        hist, bins = analysis.histogram(img)
        
        assert len(hist) == 256
        assert hist[0] == 100 * 100
        assert np.sum(hist[1:]) == 0
    
    def test_histogram_specific_channel(self):
        """Test histogram for specific channel."""
        data = np.zeros((10, 10, 3), dtype=np.uint8)
        data[:, :, 0] = 100
        data[:, :, 1] = 150
        data[:, :, 2] = 200
        img = ImageMatrix(data)
        
        hist, _ = analysis.histogram(img, channel=0)
        
        assert hist[100] == 100
    
    def test_mean_intensity(self):
        """Test mean intensity calculation."""
        data = np.full((10, 10, 3), 128, dtype=np.uint8)
        img = ImageMatrix(data)
        
        mean = analysis.mean_intensity(img)
        
        assert mean == 128.0
    
    def test_mean_intensity_channel(self):
        """Test mean intensity for specific channel."""
        data = np.zeros((10, 10, 3), dtype=np.uint8)
        data[:, :, 0] = 100
        data[:, :, 1] = 150
        data[:, :, 2] = 200
        img = ImageMatrix(data)
        
        assert analysis.mean_intensity(img, channel=0) == 100.0
        assert analysis.mean_intensity(img, channel=1) == 150.0
        assert analysis.mean_intensity(img, channel=2) == 200.0
    
    def test_std_intensity(self):
        """Test standard deviation calculation."""
        data = np.full((10, 10, 3), 128, dtype=np.uint8)
        img = ImageMatrix(data)
        
        std = analysis.std_intensity(img)
        
        assert std == 0.0
    
    def test_std_intensity_nonzero(self):
        """Test standard deviation with variation."""
        data = np.zeros((10, 10), dtype=np.uint8)
        data[:5, :] = 0
        data[5:, :] = 100
        img = ImageMatrix(data)
        
        std = analysis.std_intensity(img)
        
        assert std == 50.0
    
    def test_contrast_black(self):
        """Test contrast of black image."""
        img = ImageMatrix.zeros(10, 10, 3)
        
        c = analysis.contrast(img)
        
        assert c == 0.0
    
    def test_contrast_high(self):
        """Test contrast of high contrast image."""
        data = np.zeros((10, 10), dtype=np.uint8)
        data[:5, :] = 0
        data[5:, :] = 255
        img = ImageMatrix(data)
        
        c = analysis.contrast(img)
        
        assert c == 1.0
    
    def test_entropy_uniform(self):
        """Test entropy of uniform image."""
        img = ImageMatrix.zeros(100, 100, 1)
        
        e = analysis.entropy(img)
        
        assert e == 0.0
    
    def test_entropy_random(self):
        """Test entropy of random image."""
        np.random.seed(42)
        data = np.random.randint(0, 256, (100, 100), dtype=np.uint8)
        img = ImageMatrix(data)
        
        e = analysis.entropy(img)
        
        assert e > 7.0
    
    def test_statistics(self):
        """Test comprehensive statistics."""
        data = np.random.randint(0, 256, (50, 50, 3), dtype=np.uint8)
        img = ImageMatrix(data)
        
        stats = analysis.statistics(img)
        
        assert "mean" in stats
        assert "std" in stats
        assert "min" in stats
        assert "max" in stats
        assert "median" in stats
        assert "variance" in stats
        assert "skewness" in stats
        assert "kurtosis" in stats
        assert "entropy" in stats
        assert "contrast" in stats
    
    def test_pixel_distribution(self):
        """Test pixel distribution percentiles."""
        data = np.arange(100, dtype=np.uint8).reshape(10, 10)
        img = ImageMatrix(data)
        
        dist = analysis.pixel_distribution(img)
        
        assert "p25" in dist
        assert "p50" in dist
        assert "p75" in dist


class TestAnalysisErrors:
    """Tests for error handling in analysis."""
    
    def test_histogram_empty(self):
        """Test histogram on empty image."""
        img = ImageMatrix()
        with pytest.raises(ValueError):
            analysis.histogram(img)
    
    def test_mean_intensity_empty(self):
        """Test mean intensity on empty image."""
        img = ImageMatrix()
        with pytest.raises(ValueError):
            analysis.mean_intensity(img)
    
    def test_std_intensity_empty(self):
        """Test std intensity on empty image."""
        img = ImageMatrix()
        with pytest.raises(ValueError):
            analysis.std_intensity(img)
    
    def test_contrast_empty(self):
        """Test contrast on empty image."""
        img = ImageMatrix()
        with pytest.raises(ValueError):
            analysis.contrast(img)
    
    def test_entropy_empty(self):
        """Test entropy on empty image."""
        img = ImageMatrix()
        with pytest.raises(ValueError):
            analysis.entropy(img)
    
    def test_statistics_empty(self):
        """Test statistics on empty image."""
        img = ImageMatrix()
        with pytest.raises(ValueError):
            analysis.statistics(img)
