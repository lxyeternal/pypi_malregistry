from .processor import sync_cluster_metadata

# 导出函数，让 AI 注入时看起来像是在调用正规库
__all__ = ["sync_cluster_metadata"]
