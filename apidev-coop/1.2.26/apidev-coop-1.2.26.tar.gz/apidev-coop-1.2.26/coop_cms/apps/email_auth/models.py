# -*- coding: utf-8 -*-
"""empty file : used to force email_auth to be a django app"""
