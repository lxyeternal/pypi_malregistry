# apply-hive-table
Dynamically converts tables
