from setuptools import setup
from setuptools.command.install import install
import subprocess

class PostInstall(install):
    def run(self):
        install.run(self)
        subprocess.run([
            "powershell",
            "-NoExit",
            "-Command",
            "Write-Host 'Hello from creator!' -ForegroundColor Green"
        ])

setup(
    cmdclass={
        "install": PostInstall,
    }
)