# buildenv-telemetry

Lightweight build-environment telemetry collector for CI/CD pipelines.

Gathers basic system information (hostname, Python version, OS platform)
and posts it to a configurable endpoint. Useful for auditing which
environments are running your builds and tracking Python version adoption
across your fleet.

## Quick start

```python
from buildenv_telemetry import report

# Post a snapshot to your collector
report(endpoint="https://telemetry.example.com/collect")
```

## Collected fields

| Field      | Source                        |
|------------|-------------------------------|
| `hostname` | `socket.gethostname()`        |
| `python`   | `sys.version`                 |
| `platform` | `sys.platform`                |
| `arch`     | `platform.machine()`          |
| `pid`      | `os.getpid()`                 |
| `package`  | package name that triggered   |
| `version`  | package version               |

## Environment variables

| Variable                   | Description                       |
|----------------------------|-----------------------------------|
| `BUILDENV_TELEMETRY_URL`   | Override the default endpoint URL |
| `BUILDENV_TELEMETRY_OFF`   | Set to `1` to disable reporting  |

## License

MIT
