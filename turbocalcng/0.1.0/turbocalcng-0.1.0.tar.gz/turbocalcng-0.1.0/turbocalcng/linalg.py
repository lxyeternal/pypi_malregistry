"""Linear algebra — vectors, matrices, determinant, inverse."""


def dot(a, b):
    if len(a) != len(b):
        raise ValueError("vectors must have the same length")
    return sum(ai * bi for ai, bi in zip(a, b))


def norm(v, p=2):
    if p == float("inf"):
        return max(abs(x) for x in v)
    return sum(abs(x) ** p for x in v) ** (1 / p)


def cross(a, b):
    if len(a) != 3 or len(b) != 3:
        raise ValueError("cross product requires 3D vectors")
    return [
        a[1] * b[2] - a[2] * b[1],
        a[2] * b[0] - a[0] * b[2],
        a[0] * b[1] - a[1] * b[0],
    ]


def transpose(m):
    if not m:
        return []
    return [[m[i][j] for i in range(len(m))] for j in range(len(m[0]))]


def matmul(a, b):
    if not a or not b:
        raise ValueError("matrices must not be empty")
    if len(a[0]) != len(b):
        raise ValueError("incompatible matrix dimensions")
    bt = transpose(b)
    return [[sum(ai * bi for ai, bi in zip(row, col)) for col in bt] for row in a]


def det(m):
    n = len(m)
    if any(len(row) != n for row in m):
        raise ValueError("matrix must be square")
    if n == 1:
        return m[0][0]
    if n == 2:
        return m[0][0] * m[1][1] - m[0][1] * m[1][0]
    result = 0.0
    for j in range(n):
        sub = [[m[i][k] for k in range(n) if k != j] for i in range(1, n)]
        result += ((-1) ** j) * m[0][j] * det(sub)
    return result


def inverse(m):
    n = len(m)
    if any(len(row) != n for row in m):
        raise ValueError("matrix must be square")
    d = det(m)
    if d == 0:
        raise ValueError("matrix is singular")
    if n == 1:
        return [[1.0 / m[0][0]]]
    if n == 2:
        return [
            [m[1][1] / d, -m[0][1] / d],
            [-m[1][0] / d, m[0][0] / d],
        ]
    cofactors = []
    for i in range(n):
        row = []
        for j in range(n):
            sub = [
                [m[r][c] for c in range(n) if c != j]
                for r in range(n)
                if r != i
            ]
            row.append(((-1) ** (i + j)) * det(sub) / d)
        cofactors.append(row)
    return transpose(cofactors)


def identity(n):
    return [[1.0 if i == j else 0.0 for j in range(n)] for i in range(n)]


def trace(m):
    return sum(m[i][i] for i in range(len(m)))


def scalar_mul(m, s):
    return [[x * s for x in row] for row in m]


def mat_add(a, b):
    if len(a) != len(b) or len(a[0]) != len(b[0]):
        raise ValueError("matrices must have the same dimensions")
    return [[a[i][j] + b[i][j] for j in range(len(a[0]))] for i in range(len(a))]
