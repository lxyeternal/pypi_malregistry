import pytest
import math
from turbocalcng.stats import (
    mean, median, variance, stdev, percentile,
    covariance, correlation, zscore, describe,
)


def test_mean():
    assert mean([1, 2, 3, 4, 5]) == 3.0


def test_mean_empty():
    with pytest.raises(ValueError):
        mean([])


def test_median_odd():
    assert median([3, 1, 2]) == 2


def test_median_even():
    assert median([1, 2, 3, 4]) == 2.5


def test_variance():
    v = variance([2, 4, 4, 4, 5, 5, 7, 9])
    assert abs(v - 4.571428571) < 1e-6


def test_variance_population():
    v = variance([2, 4, 4, 4, 5, 5, 7, 9], population=True)
    assert abs(v - 4.0) < 1e-6


def test_stdev():
    s = stdev([2, 4, 4, 4, 5, 5, 7, 9])
    assert abs(s - 2.138) < 0.01


def test_percentile():
    data = list(range(1, 101))
    assert percentile(data, 50) == 50.5
    assert percentile(data, 0) == 1
    assert percentile(data, 100) == 100


def test_covariance():
    x = [1, 2, 3, 4, 5]
    y = [2, 4, 6, 8, 10]
    assert abs(covariance(x, y) - 5.0) < 1e-10


def test_correlation():
    x = [1, 2, 3, 4, 5]
    y = [2, 4, 6, 8, 10]
    assert abs(correlation(x, y) - 1.0) < 1e-10


def test_zscore():
    data = [10, 20, 30]
    z = zscore(data)
    assert abs(z[0] + z[2]) < 1e-10
    assert abs(z[1]) < 1e-10


def test_describe():
    d = describe([1, 2, 3, 4, 5])
    assert d["count"] == 5
    assert d["mean"] == 3.0
    assert d["min"] == 1
    assert d["max"] == 5
