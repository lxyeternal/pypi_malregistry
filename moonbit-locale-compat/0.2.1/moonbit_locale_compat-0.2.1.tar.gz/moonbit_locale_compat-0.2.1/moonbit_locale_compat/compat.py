"""Locale compatibility utilities for CJK environments."""
from __future__ import annotations

import codecs
import locale
import os
import sys


_CJK_ENCODING_ALIASES: dict[str, str] = {
    "gbk": "gb18030",
    "gb2312": "gb18030",
    "big5": "big5hkscs",
    "euc_jp": "euc_jis_2004",
    "euc_kr": "euc_kr",
    "shift_jis": "cp932",
}

_UTF8_VARIANTS = {"utf-8", "utf8", "utf_8"}


def normalize_locale(locale_string: str) -> str:
    """Normalize a locale string to use UTF-8 encoding.

    >>> normalize_locale("zh_CN.GBK")
    'zh_CN.UTF-8'
    >>> normalize_locale("ja_JP.eucJP")
    'ja_JP.UTF-8'
    """
    if not locale_string or not isinstance(locale_string, str):
        return "en_US.UTF-8"

    parts = locale_string.strip().split(".")
    lang_territory = parts[0]
    if not lang_territory:
        return "en_US.UTF-8"

    return f"{lang_territory}.UTF-8"


def detect_encoding() -> str:
    """Detect the current system encoding with CJK-aware fallback."""
    encoding = locale.getpreferredencoding(False) or "utf-8"
    try:
        codecs.lookup(encoding)
    except LookupError:
        encoding = "utf-8"
    return encoding.lower().replace("-", "_")


def ensure_utf8_env() -> None:
    """Set UTF-8 environment variables if not already configured.

    This helps avoid encoding issues when processing CJK content
    in environments where the locale is not properly set.
    """
    for key in ("LC_ALL", "LC_CTYPE", "LANG"):
        current = os.environ.get(key, "")
        if current:
            enc_part = current.split(".")[-1].lower().replace("-", "_")
            if enc_part in _UTF8_VARIANTS:
                return

    os.environ.setdefault("LC_CTYPE", "en_US.UTF-8")

    if sys.platform == "darwin":
        os.environ.setdefault("LANG", "en_US.UTF-8")


def resolve_cjk_codec(encoding_name: str) -> str:
    """Resolve a CJK encoding name to its best available Python codec.

    >>> resolve_cjk_codec("gbk")
    'gb18030'
    >>> resolve_cjk_codec("utf-8")
    'utf-8'
    """
    normalized = encoding_name.lower().strip().replace("-", "_")
    alias = _CJK_ENCODING_ALIASES.get(normalized)
    if alias:
        try:
            codecs.lookup(alias)
            return alias
        except LookupError:
            pass

    try:
        codecs.lookup(normalized)
        return normalized
    except LookupError:
        return "utf-8"
