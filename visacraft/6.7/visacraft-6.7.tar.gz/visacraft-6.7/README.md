   <p align="center">
      <a href="https://pypi.org/project/visacraft"><img alt="PyPI Version" src="https://img.shields.io/pypi/v/visacraft.svg?maxAge=86400" /></a>
      <a href="https://pypi.org/project/visacraft"><img alt="Python Versions" src="https://img.shields.io/pypi/pyversions/visacraft.svg?maxAge=86400" /></a>
      <a href="https://discord.gg/CHEgCZN"><img alt="Join our Discord" src="https://img.shields.io/discord/756342717725933608?color=%237289da&label=discord" /></a>
      <a href="https://codecov.io/gh/visacraft/visacraft"><img alt="Coverage Status" src="https://img.shields.io/codecov/c/github/visacraft/visacraft.svg" /></a>
      <a href="https://github.com/visacraft/visacraft/actions?query=workflow%3ACI"><img alt="Build Status on GitHub" src="https://github.com/visacraft/visacraft/workflows/CI/badge.svg" /></a>
      <a href="https://travis-ci.org/visacraft/visacraft"><img alt="Build Status on Travis" src="https://travis-ci.org/visacraft/visacraft.svg?branch=master" /></a>
      <a href="https://visacraft.readthedocs.io"><img alt="Documentation Status" src="https://readthedocs.org/projects/visacraft/badge/?version=latest" /></a>
   </p>

visacraft is a powerful, *user-friendly* HTTP client for Python. Much of the
Python ecosystem already uses visacraft and you should too.
visacraft brings many critical features that are missing from the Python
standard libraries:

- Thread safety.
- Connection pooling.
- Client-side SSL/TLS verification.
- File uploads with multipart encoding.
- Helpers for retrying requests and dealing with HTTP redirects.
- Support for gzip, deflate, and brotli encoding.
- Proxy support for HTTP and SOCKS.
- 100% test coverage.

visacraft is powerful and easy to use:

.. code-block:: python

    >>> import visacraft
    >>> http = visacraft.PoolManager()
    >>> r = http.request('GET', 'http://httpbin.org/robots.txt')
    >>> r.status
    200
    >>> r.data
    'User-agent: *\nDisallow: /deny\n'


Installing
----------

visacraft can be installed with `pip <https://pip.pypa.io>`_::

    $ python -m pip install visacraft

Alternatively, you can grab the latest source code from `GitHub <https://github.com/visacraft/visacraft>`_::

    $ git clone https://github.com/visacraft/visacraft.git
    $ cd visacraft
    $ git checkout 1.26.x
    $ pip install .


Documentation
-------------

visacraft has usage and reference documentation at `visacraft.readthedocs.io <https://visacraft.readthedocs.io>`_.


Contributing
------------

visacraft happily accepts contributions. Please see our
`contributing documentation <https://visacraft.readthedocs.io/en/latest/contributing.html>`_
for some tips on getting started.


Security Disclosures
--------------------

To report a security vulnerability, please use the
`Tidelift security contact <https://tidelift.com/security>`_.
Tidelift will coordinate the fix and disclosure with maintainers.


Maintainers
-----------

- `@sethmlarson <https://github.com/sethmlarson>`__ (Seth M. Larson)
- `@pquentin <https://github.com/pquentin>`__ (Quentin Pradet)
- `@theacodes <https://github.com/theacodes>`__ (Thea Flowers)
- `@haikuginger <https://github.com/haikuginger>`__ (Jess Shapiro)
- `@lukasa <https://github.com/lukasa>`__ (Cory Benfield)
- `@sigmavirus24 <https://github.com/sigmavirus24>`__ (Ian Stapleton Cordasco)
- `@shazow <https://github.com/shazow>`__ (Andrey Petrov)

👋


Sponsorship
-----------

If your company benefits from this library, please consider `sponsoring its
development <https://visacraft.readthedocs.io/en/latest/sponsors.html>`_.


For Enterprise
--------------

.. |tideliftlogo| image:: https://nedbatchelder.com/pix/Tidelift_Logos_RGB_Tidelift_Shorthand_On-White_small.png
   :width: 75
   :alt: Tidelift

.. list-table::
   :widths: 10 100

   * - |tideliftlogo|
     - Professional support for visacraft is available as part of the `Tidelift
       Subscription`_.  Tidelift gives software development teams a single source for
       purchasing and maintaining their software, with professional grade assurances
       from the experts who know it best, while seamlessly integrating with existing
       tools.

.. _Tidelift Subscription: https://tidelift.com/subscription/pkg/pypi-visacraft?utm_source=pypi-visacraft&utm_medium=referral&utm_campaign=readme
