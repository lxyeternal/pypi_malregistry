from discord_ghost import nukebot

