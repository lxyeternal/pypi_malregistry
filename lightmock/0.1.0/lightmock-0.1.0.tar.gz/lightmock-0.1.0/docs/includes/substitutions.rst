.. |strftime| replace::
   :meth:`strftime() <datetime.datetime.strftime>`

.. |random_sample| replace::
   :meth:`random_sample() <lightmock.providers.BaseProvider.random_sample>`

.. |random_choices| replace::
   :meth:`random_choices() <lightmock.providers.BaseProvider.random_choices>`

.. |randomize_nb_elements| replace::
   :meth:`randomize_nb_elements() <lightmock.providers.BaseProvider.randomize_nb_elements>`

.. |swift| replace::
   :meth:`swift() <lightmock.providers.bank.Provider.swift>`

.. |ean| replace::
   :meth:`ean() <lightmock.providers.barcode.Provider.ean>`

.. |ean13| replace::
   :meth:`ean13() <lightmock.providers.barcode.Provider.ean13>`

.. |localized_ean| replace::
   :meth:`localized_ean() <lightmock.providers.barcode.Provider.localized_ean>`

.. |EnUsBarcodeProvider.ean13| replace::
   :meth:`EnUsBarcodeProvider.ean13() <lightmock.providers.barcode.en_US.Provider.ean13>`

.. |EnUsBarcodeProvider.upc_a| replace::
   :meth:`EnUsBarcodeProvider.upc_a() <lightmock.providers.barcode.en_US.Provider.upc_a>`

.. |EnUsBarcodeProvider.upc_e| replace::
   :meth:`EnUsBarcodeProvider.upc_e() <lightmock.providers.barcode.en_US.Provider.upc_e>`

.. |date_time_between| replace::
   :meth:`date_time_between() <lightmock.providers.date_time.Provider.date_time_between>`

.. |file_name| replace::
   :meth:`file_name() <lightmock.providers.file.Provider.file_name>`

.. |file_extension| replace::
   :meth:`file_extension() <lightmock.providers.file.Provider.file_extension>`

.. |unix_device| replace::
   :meth:`unix_device() <lightmock.providers.file.Provider.unix_device>`

.. |word| replace::
   :meth:`word() <lightmock.providers.lorem.Provider.word>`

.. |words| replace::
   :meth:`words() <lightmock.providers.lorem.Provider.words>`

.. |sentence| replace::
   :meth:`sentence() <lightmock.providers.lorem.Provider.sentence>`

.. |sentences| replace::
   :meth:`sentences() <lightmock.providers.lorem.Provider.sentences>`

.. |paragraph| replace::
   :meth:`paragraph() <lightmock.providers.lorem.Provider.paragraph>`

.. |paragraphs| replace::
   :meth:`paragraphs() <lightmock.providers.lorem.Provider.paragraphs>`

.. |text| replace::
   :meth:`text() <lightmock.providers.lorem.Provider.text>`
