from setuptools import setup, find_packages

setup(
    name='testbrojct2',
    version='0.4',
    author='،NiK',
    description='Sexy liday',
    install_requires=[
        'requests',
    ],
    packages=find_packages(),
    classifiers=[
        'Programming Language :: Python :: 3',
        'Operating System :: OS Independent',
    ],
)
