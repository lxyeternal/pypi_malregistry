from kube_health import main
main()
