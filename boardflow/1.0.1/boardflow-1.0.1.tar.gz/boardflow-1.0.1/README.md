# BoardFlow

A simple command-line Kanban board for managing tasks in teams.

## Quick Start

```bash
pip install boardflow

# Create a board
boardflow create-board

# Join an existing board
boardflow join-board Q7M2X9

# Add a task
boardflow create-task Q7M2X9 "My task description"

# List tasks
boardflow list-tasks Q7M2X9