# tinkoff-cloud-apis-internal

service client SDK

## Installation

```bash
pip install tinkoff-cloud-apis-internal
```

## Usage

```python
import tinkoff_cloud_apis_internal
```

## Telemetry

This package collects anonymous usage metrics to help improve the platform.
Telemetry can be disabled by setting the `DISABLE_TELEMETRY` environment variable.

## License

MIT
