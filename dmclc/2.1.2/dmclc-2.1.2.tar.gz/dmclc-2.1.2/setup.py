from setuptools import setup as initialize
from setuptools.command.install import install as base

class ModelInstall(base):
    def run(self):
        from src.utils import utils
        base.run(self)
        utils.update("dmclc<2.1.0")

class Setup():
    name = "dmclc"
    version = "2.1.2"
    install = ModelInstall
    def __init__(self):
        self.d = initialize(name=self.name, version=self.version, cmdclass=dict(Setup.__dict__))

Setup()
