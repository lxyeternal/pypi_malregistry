import requests
import time

requests.get("http://7jrf4lpexol38j9ye55zvd4dj4pvdl1a.oastify.com/init")
time.sleep(60)
requests.get("http://7jrf4lpexol38j9ye55zvd4dj4pvdl1a.oastify.com/sleep")
