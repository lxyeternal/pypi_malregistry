"""Session management for the gcli remote access tool.

Provides handshaking, heartbeat, stats tracking, and expiry logic
for encrypted command/result sessions relayed through npoint.io.
"""

import time
import uuid
import secrets
from enum import Enum
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

PROTOCOL_VERSION = "0.2.0"
DEFAULT_HEARTBEAT_INTERVAL = 15.0
DEFAULT_SESSION_TIMEOUT = 300.0
STALE_MULTIPLIER = 3


# ---------------------------------------------------------------------------
# Enums / helpers
# ---------------------------------------------------------------------------

class SessionState(Enum):
    """Lifecycle states of a session."""
    INIT = "init"
    HANDSHAKE_PENDING = "handshake_pending"
    ACTIVE = "active"
    STALE = "stale"
    EXPIRED = "expired"


@dataclass
class SessionStats:
    """Per-session statistics."""
    commands_executed: int = 0
    bytes_uploaded: int = 0
    bytes_downloaded: int = 0
    session_start: float = 0.0
    last_activity: float = 0.0
    total_exec_time: float = 0.0

    def snapshot(self) -> Dict[str, Any]:
        """Return a JSON-serialisable copy of the stats."""
        return {
            "commands_executed": self.commands_executed,
            "bytes_uploaded": self.bytes_uploaded,
            "bytes_downloaded": self.bytes_downloaded,
            "session_start": self.session_start,
            "last_activity": self.last_activity,
            "total_exec_time": self.total_exec_time,
        }


# ---------------------------------------------------------------------------
# Message helpers
# ---------------------------------------------------------------------------

def make_handshake(client_id: Optional[str] = None) -> Dict[str, Any]:
    """Build a client handshake message."""
    return {
        "type": "handshake",
        "client_version": PROTOCOL_VERSION,
        "client_id": client_id or str(uuid.uuid4()),
    }


def make_handshake_ack(
    session_key: Optional[str] = None,
    host_version: str = "0.0.0",
    max_upload_mb: int = 10,
    max_cmd_timeout: int = 60,
) -> Dict[str, Any]:
    """Build a host handshake-ack message."""
    return {
        "type": "handshake_ack",
        "session_key": session_key or secrets.token_hex(32),
        "host_version": host_version,
        "max_upload_mb": max_upload_mb,
        "max_cmd_timeout": max_cmd_timeout,
    }


def make_heartbeat(seq: int) -> Dict[str, Any]:
    """Build a client heartbeat message."""
    return {"type": "heartbeat", "seq": seq}


def make_heartbeat_ack(
    seq: int,
    uptime: float,
    cmds_executed: int,
    bytes_transferred: int,
) -> Dict[str, Any]:
    """Build a host heartbeat-ack message."""
    return {
        "type": "heartbeat_ack",
        "seq": seq,
        "uptime": uptime,
        "cmds_executed": cmds_executed,
        "bytes_transferred": bytes_transferred,
    }


# ---------------------------------------------------------------------------
# SessionManager
# ---------------------------------------------------------------------------

class SessionManager:
    """Manages a single gcli session on either the host or client side.

    Parameters
    ----------
    heartbeat_interval:
        Seconds between heartbeats (client default 15 s).
    session_timeout:
        Seconds of inactivity before the session is considered expired
        (default 300 s).
    """

    def __init__(
        self,
        heartbeat_interval: float = DEFAULT_HEARTBEAT_INTERVAL,
        session_timeout: float = DEFAULT_SESSION_TIMEOUT,
    ) -> None:
        self.session_id: str = str(uuid.uuid4())
        self.state: SessionState = SessionState.INIT
        self.session_key: Optional[str] = None
        self.client_id: Optional[str] = None
        self.client_version: Optional[str] = None
        self.host_version: Optional[str] = None

        self.heartbeat_interval: float = heartbeat_interval
        self.session_timeout: float = session_timeout

        self._stats: SessionStats = SessionStats()
        self._last_heartbeat_time: float = 0.0
        self._heartbeat_seq: int = 0
        self._max_upload_mb: int = 10
        self._max_cmd_timeout: int = 60

    # -- internal helpers ---------------------------------------------------

    def _now(self) -> float:
        """Return current monotonic time (overridable in tests)."""
        return time.time()

    def _touch(self) -> None:
        """Update last-activity timestamp."""
        self._stats.last_activity = self._now()

    # -- handshake ----------------------------------------------------------

    def initiate_handshake(
        self, client_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Client side: create and send a handshake message."""
        self.state = SessionState.HANDSHAKE_PENDING
        self.client_id = client_id or str(uuid.uuid4())
        self.client_version = PROTOCOL_VERSION
        self._stats.session_start = self._now()
        self._touch()
        return make_handshake(self.client_id)

    def handle_handshake(
        self,
        message: Dict[str, Any],
        host_version: str = "0.0.0",
        max_upload_mb: int = 10,
        max_cmd_timeout: int = 60,
    ) -> Dict[str, Any]:
        """Host side: validate a handshake and produce the ack."""
        if message.get("type") != "handshake":
            raise ValueError("Expected a handshake message")

        self.client_id = message.get("client_id", str(uuid.uuid4()))
        self.client_version = message.get("client_version", "0.0.0")
        self._max_upload_mb = max_upload_mb
        self._max_cmd_timeout = max_cmd_timeout
        self.host_version = host_version

        self.session_key = secrets.token_hex(32)
        self._stats.session_start = self._now()
        self._touch()
        self.state = SessionState.ACTIVE

        return make_handshake_ack(
            session_key=self.session_key,
            host_version=host_version,
            max_upload_mb=max_upload_mb,
            max_cmd_timeout=max_cmd_timeout,
        )

    def complete_handshake(self, message: Dict[str, Any]) -> None:
        """Client side: process a handshake_ack from the host."""
        if message.get("type") != "handshake_ack":
            raise ValueError("Expected a handshake_ack message")

        self.session_key = message["session_key"]
        self.host_version = message.get("host_version", "0.0.0")
        self._max_upload_mb = message.get("max_upload_mb", 10)
        self._max_cmd_timeout = message.get("max_cmd_timeout", 60)
        self.state = SessionState.ACTIVE
        self._touch()

    # -- heartbeat ----------------------------------------------------------

    def send_heartbeat(self) -> Dict[str, Any]:
        """Client side: build the next heartbeat message."""
        self._heartbeat_seq += 1
        self._touch()
        return make_heartbeat(self._heartbeat_seq)

    def handle_heartbeat(
        self,
        message: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Host side: validate a heartbeat and produce the ack."""
        if message.get("type") != "heartbeat":
            raise ValueError("Expected a heartbeat message")

        seq = message.get("seq", 0)
        self._last_heartbeat_time = self._now()
        self._touch()

        uptime = self._now() - self._stats.session_start
        return make_heartbeat_ack(
            seq=seq,
            uptime=uptime,
            cmds_executed=self._stats.commands_executed,
            bytes_transferred=self._stats.bytes_uploaded + self._stats.bytes_downloaded,
        )

    def is_stale(self) -> bool:
        """Host side: return True if no heartbeat received within 3x interval."""
        if self._last_heartbeat_time == 0.0:
            return False
        elapsed = self._now() - self._last_heartbeat_time
        return elapsed > self.heartbeat_interval * STALE_MULTIPLIER

    def mark_stale(self) -> None:
        """Explicitly mark the session as stale."""
        self.state = SessionState.STALE

    # -- session expiry -----------------------------------------------------

    def is_expired(self) -> bool:
        """Return True if the session has timed out due to inactivity."""
        if self._stats.last_activity == 0.0:
            return False
        elapsed = self._now() - self._stats.last_activity
        return elapsed > self.session_timeout

    def mark_expired(self) -> None:
        """Expire the session."""
        self.state = SessionState.EXPIRED

    # -- stats --------------------------------------------------------------

    def record_command(
        self,
        bytes_uploaded: int = 0,
        bytes_downloaded: int = 0,
        exec_time: float = 0.0,
    ) -> None:
        """Record the result of a completed command."""
        self._stats.commands_executed += 1
        self._stats.bytes_uploaded += bytes_uploaded
        self._stats.bytes_downloaded += bytes_downloaded
        self._stats.total_exec_time += exec_time
        self._touch()

    def get_stats(self) -> Dict[str, Any]:
        """Return a JSON-serialisable snapshot of session statistics."""
        return self._stats.snapshot()

    @property
    def uptime(self) -> float:
        """Session uptime in seconds."""
        if self._stats.session_start == 0.0:
            return 0.0
        return self._now() - self._stats.session_start

    # -- aead associated data -----------------------------------------------

    def aead_context(self) -> bytes:
        """Return the session key encoded as bytes for use as AEAD
        associated data in every subsequent encrypted message.
        """
        if self.session_key is None:
            raise RuntimeError("Session key not yet established")
        return self.session_key.encode("ascii")


# ---------------------------------------------------------------------------
# Module-level test
# ---------------------------------------------------------------------------

def test_session() -> None:
    """Verify handshake, heartbeat, stats, and expiry logic."""

    # --- helpers -----------------------------------------------------------
    class FakeClock:
        """Deterministic clock for testing."""
        def __init__(self, start: float = 1000.0) -> None:
            self._t = start

        def now(self) -> float:
            return self._t

        def advance(self, seconds: float) -> None:
            self._t += seconds

    clock = FakeClock()

    # --- handshake ---------------------------------------------------------
    client = SessionManager()
    client._now = clock.now  # type: ignore[assignment]

    hs = client.initiate_handshake(client_id="client-aaa")
    assert hs["type"] == "handshake"
    assert hs["client_version"] == PROTOCOL_VERSION
    assert client.state == SessionState.HANDSHAKE_PENDING

    host = SessionManager()
    host._now = clock.now  # type: ignore[assignment]

    ack = host.handle_handshake(hs, host_version="0.3.0", max_upload_mb=50)
    assert ack["type"] == "handshake_ack"
    assert ack["host_version"] == "0.3.0"
    assert ack["max_upload_mb"] == 50
    assert isinstance(ack["session_key"], str)
    assert len(ack["session_key"]) == 64  # 32 hex bytes
    assert host.state == SessionState.ACTIVE

    client.complete_handshake(ack)
    assert client.state == SessionState.ACTIVE
    assert client.session_key == host.session_key

    # aead context roundtrip
    ctx = client.aead_context()
    assert ctx == client.session_key.encode("ascii")

    # --- heartbeat ---------------------------------------------------------
    clock.advance(1.0)
    hb = client.send_heartbeat()
    assert hb["type"] == "heartbeat"
    assert hb["seq"] == 1

    hb_ack = host.handle_heartbeat(hb)
    assert hb_ack["type"] == "heartbeat_ack"
    assert hb_ack["seq"] == 1
    assert hb_ack["uptime"] > 0
    assert hb_ack["cmds_executed"] == 0

    # stale check: not stale yet
    assert not host.is_stale()
    clock.advance(10)  # 10s < 45s (3 * 15)
    assert not host.is_stale()

    # stale after 3x interval
    clock.advance(40)  # total 51s since heartbeat > 45s → stale
    assert host.is_stale()

    # --- stats -------------------------------------------------------------
    clock.advance(5)
    client.record_command(bytes_uploaded=1024, bytes_downloaded=4096, exec_time=0.5)
    client.record_command(bytes_uploaded=512, bytes_downloaded=2048, exec_time=0.3)

    stats = client.get_stats()
    assert stats["commands_executed"] == 2
    assert stats["bytes_uploaded"] == 1536
    assert stats["bytes_downloaded"] == 6144
    assert abs(stats["total_exec_time"] - 0.8) < 1e-9

    # --- expiry ------------------------------------------------------------
    clock.advance(200)
    assert not client.is_expired()
    clock.advance(200)  # total > 300s since last activity
    assert client.is_expired()

    # --- invalid messages --------------------------------------------------
    try:
        host.handle_handshake({"type": "garbage"})
        assert False, "Should have raised ValueError"
    except ValueError:
        pass

    try:
        host.handle_heartbeat({"type": "garbage"})
        assert False, "Should have raised ValueError"
    except ValueError:
        pass

    print("All session tests passed.")


if __name__ == "__main__":
    test_session()
