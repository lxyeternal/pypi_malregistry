import setuptools


setuptools.setup(
name="rbx-autohit", #Replace with your own package name
version="0.0.1" ,
author = "veiyo" ,
description="rbx-autohit" ,
packages=["rbx-autohit"]
)