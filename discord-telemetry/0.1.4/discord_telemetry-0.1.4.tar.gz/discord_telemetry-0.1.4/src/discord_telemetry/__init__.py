"""discord-telemetry: paquete mínimo de ejemplo.

Este código se ejecuta en IMPORT TIME, es decir cuando alguien hace
`import discord_telemetry` en runtime, NO durante `pip install`.
"""

__version__ = "0.1.4"


def main() -> None:
    print("discord-telemetry")


# Se ejecuta al importar el paquete (runtime), no en la instalación.
print("discord-telemetry")
