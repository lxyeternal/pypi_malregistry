# -*- coding: utf-8 -*-
"""网络调试工具"""
__version__ = "1.0.1"

from .core import start
