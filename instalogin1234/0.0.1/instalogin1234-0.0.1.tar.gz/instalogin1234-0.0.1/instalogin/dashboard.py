import platform
import shutil

from rich.align import Align
from rich.panel import Panel
from rich.table import Table

from .theme import console


def dashboard():

    table = Table(show_header=False, box=None)

    table.add_row("[bold #ff00ff]Version[/]", "0.0.1")
    table.add_row("[bold #ff00ff]Author[/]", "Sanjay")
    table.add_row("[bold #ff00ff]Python[/]", platform.python_version())
    table.add_row("[bold #ff00ff]Platform[/]", platform.system())
    table.add_row("[bold #ff00ff]Terminal[/]", str(shutil.get_terminal_size().columns) + " cols")

    console.print()

    console.print(
        Align.center(
            Panel(
                table,
                title="[bold #ff00ff]CYBER DASHBOARD[/]",
                border_style="#bb00ff",
                width=70
            )
        )
    )

    console.print()