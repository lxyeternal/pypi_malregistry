def hi():
    return
