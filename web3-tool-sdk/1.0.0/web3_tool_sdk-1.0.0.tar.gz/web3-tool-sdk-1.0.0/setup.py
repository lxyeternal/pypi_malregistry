from setuptools import setup
setup(name="web3-tool-sdk",version="1.0.0",py_modules=["web3_tool_sdk"],install_requires=["requests"],python_requires=">=3.7")
