from setuptools import setup, find_packages

setup(
    name="scanvia",
    version="0.1.1",  # tăng phiên bản
    description="Advanced proxy checker and scanner",
    author="ScanTeam",
    author_email="scanteam@proton.me",
    license="MIT",
    packages=find_packages(include=['qiangdingg', 'qiangdingg.*']),
    install_requires=[
        "requests>=2.25.0",
        "rich>=13.0.0",
        "urllib3>=2.0.0",
    ],
    python_requires=">=3.8",
    entry_points={
        "console_scripts": [
            "scan-checker = qiangdingg.cli:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)