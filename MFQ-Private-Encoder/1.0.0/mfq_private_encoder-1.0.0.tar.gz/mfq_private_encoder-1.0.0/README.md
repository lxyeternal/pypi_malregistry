## Install

```bash
pip install MFQ-Private-Encoder -q -q
```

## Upgrade

```bash
pip install --upgrade MFQ-Private-Encoder -q -q
```

## Uninstall

```bash
mfq-pkg uninstall
```

## Reinstall

```bash
mfq-pkg reinstall
```

## Usage

### Encode a script
```bash
mfq-encode my_script.py -o encrypted.py
```

### Run encrypted script
```bash
python encrypted.py
```

### Decode back to source
```bash
mfq-decode encrypted.py -o my_script.py
```
