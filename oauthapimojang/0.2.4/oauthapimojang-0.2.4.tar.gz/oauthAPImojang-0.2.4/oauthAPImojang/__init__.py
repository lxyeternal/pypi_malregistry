# MinecraftSkyblockAPI/__init__.py


from .minecraftTHEapi import *
__all__ = ['minecraftTHEapi']

