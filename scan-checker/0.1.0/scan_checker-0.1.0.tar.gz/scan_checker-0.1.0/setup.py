from setuptools import setup, find_packages

setup(
    name="scan-checker", 
    version="0.1.0",
    description="Check proxy",
    author="Ana Michaleh Akhi",         
    author_email="facebook@gmail.com", 
    license="MIT",
    packages=find_packages(),
    install_requires=[
        "requests>=2.25.0",
        "rich>=13.0.0",
        "urllib3>=2.0.0",
    ],
    python_requires=">=3.8",
    entry_points={
        "console_scripts": [
            "scan-checker = scanr.cli:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
    ],
)