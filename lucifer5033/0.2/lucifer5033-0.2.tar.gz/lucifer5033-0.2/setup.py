from setuptools import setup

setup(
    name='lucifer5033',
    version='0.2',
    description='lucifer5033',
    author='magalie876956',
    author_email='magalie876956@2rwuvtol.saucent.online',
    packages=['lucifer5033'],
    install_requires=[],
)
