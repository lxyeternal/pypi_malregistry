from discordreq99 import discord
