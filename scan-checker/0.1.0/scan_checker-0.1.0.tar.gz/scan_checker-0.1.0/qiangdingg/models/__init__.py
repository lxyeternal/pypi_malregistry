from .stats import GlobalStats, StatsManager
