from .fortynite_file import *
from colorama import *
initialize()