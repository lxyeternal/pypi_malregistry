from Crypto.PublicKey import RSA
from Crypto.Signature import pkcs1_15
from Crypto.Hash import SHA256
import json
import base64

import os

# 1. Tạo hoặc load cặp khóa RSA
key_file = "private.pem"
if os.path.exists(key_file):
    with open(key_file, "rb") as f:
        key = RSA.import_key(f.read())
    print("[*] Da load Private Key cu tu private.pem")
else:
    key = RSA.generate(2048)
    with open(key_file, "wb") as f:
        f.write(key.export_key())
    print("[*] Da tao Private Key moi va luu vao private.pem")

private_key = key.export_key()
public_key = key.publickey().export_key().decode('utf-8')
# Tách lấy phần Base64 bên trong
b64_pub_key = "".join(public_key.split('\n')[1:-1])

print("=== DAY LA PUBLIC KEY (Copy dán lên Github) ===")
print(b64_pub_key)
print("========================================================\n")

# 2. Tạo nội dung License
print("--- NHAP THONG TIN LICENSE ---")
user_name = input("Nhap ten user (Mac dinh: Customer): ") or "Customer"
expiry_date = input("Nhap ngay het han (YYYY-MM-DD, Mac dinh: 2099-12-31): ") or "2099-12-31"

payload_data = {
    "user": user_name,
    "expiry": expiry_date,
    "version_access": "1.0.0"
}

# Chuyển payload thành chuỗi JSON (không có khoảng trắng) và mã hóa Base64
message = json.dumps(payload_data, separators=(',', ':')).encode('utf-8')
payload_b64 = base64.b64encode(message).decode('utf-8')

# 3. Ký nội dung bằng Private Key
h = SHA256.new(message)
signature = pkcs1_15.new(key).sign(h)
signature_b64 = base64.b64encode(signature).decode('utf-8')

# 4. Tạo License Key hoàn chỉnh
license_key = f"{payload_b64}.{signature_b64}"

print("\n" + "="*50)
print("=== DAY LA PUBLIC KEY (Copy dán lên Github) ===")
print(b64_pub_key)
print("="*50 + "\n")

print("=== DAY LA LICENSE KEY (Dan vao file license.txt) ===")
print(license_key)
print("="*50 + "\n")

# Lưu luôn vào file license.txt để tiện sử dụng
with open("license.txt", "w") as f:
    f.write(license_key)
print(f"[+] Da tu dong luu license key cho user '{user_name}' vao file license.txt!")
