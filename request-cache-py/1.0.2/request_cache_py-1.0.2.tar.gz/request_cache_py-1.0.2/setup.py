from setuptools import setup, find_packages

setup(
    name='request-cache-py',
    version='1.0.2',
    description='High-performance HTTP request caching with Redis and in-memory backends',
    long_description=open('README.md').read() if __name__ == '__main__' else '',
    long_description_content_type='text/markdown',
    author='Python Performance Team',
    author_email='perf-team@pythonutils.org',
    url='https://github.com/python-perf/request-cache-py',
    packages=find_packages(),
    install_requires=[
        'requests>=2.25.0',
    ],
    classifiers=[
        'Development Status :: 5 - Production/Stable',
        'Intended Audience :: Developers',
        'Topic :: Software Development :: Libraries',
        'Topic :: Internet :: WWW/HTTP',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
    ],
    python_requires='>=3.7',
)
