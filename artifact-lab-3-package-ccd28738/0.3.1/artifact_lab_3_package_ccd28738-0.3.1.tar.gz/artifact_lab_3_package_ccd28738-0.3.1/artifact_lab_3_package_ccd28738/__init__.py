# artifact_lab_3_package_2b6a4744/__init__.py
# Pode ser deixado vazio ou usado para inicialização

