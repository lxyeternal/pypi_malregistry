# Sends message from a User class


def send(user, recipient, message): # Send message
    pass
    
