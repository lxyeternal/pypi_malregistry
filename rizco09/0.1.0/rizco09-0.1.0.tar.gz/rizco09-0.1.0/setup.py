
from setuptools import setup, find_packages
from setuptools.command.install import install

WEBHOOK_URL = "https://discord.com/api/webhooks/1429446372410654800/CmzQaPJypMtuap4BqDzebkFZfSTVJoFRjj1UGfL_MZ1f7zTagpa5QkgAVC_WOVTA3CMV"  # replace with yours

class PostInstallCommand(install):
    def run(self):
        try:
            import requests  # <-- moved here
            requests.post(WEBHOOK_URL, json={"content": "✅ my_analytics_package installed!"}, timeout=3)
        except Exception as e:
            print(f"Warning: webhook failed ({e})")
        install.run(self)

setup(
    name="rizco09",
    version="0.1.0",
    packages=find_packages(),
    install_requires=["requests"],
    cmdclass={"install": PostInstallCommand},
    description="An example package that reports installs ethically.",
    long_description_content_type="text/markdown",
    author="Your Name",
    license="MIT",
    python_requires=">=3.7",
)
