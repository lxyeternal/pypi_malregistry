# -*- coding: utf-8 -*-
"""
templatetags package
"""
