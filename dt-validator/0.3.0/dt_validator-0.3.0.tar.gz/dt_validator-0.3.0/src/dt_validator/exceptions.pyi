"""Type stubs for exceptions — public interface only; implementation is hidden."""

from typing import Optional

class FileValidatorError(Exception): ...
class InvalidUriError(FileValidatorError, ValueError): ...

class ObjectNotFoundError(FileValidatorError):
    bucket: str
    key: str
    def __init__(self, bucket: str, key: str) -> None: ...

class AccessDeniedError(FileValidatorError):
    bucket: str
    key: str
    def __init__(self, bucket: str, key: str) -> None: ...

class RemoteReadError(FileValidatorError): ...

class ApiRequestError(FileValidatorError):
    status_code: Optional[int]
    def __init__(self, message: str, status_code: Optional[int] = ...) -> None: ...

class ValidationError(FileValidatorError): ...

class FileSizeError(ValidationError):
    size: int
    max_bytes: Optional[int]
    min_bytes: Optional[int]
    def __init__(
        self,
        size: int,
        *,
        max_bytes: Optional[int] = ...,
        min_bytes: Optional[int] = ...,
    ) -> None: ...

class ExtensionError(ValidationError):
    key: str
    allowed: tuple
    def __init__(self, key: str, allowed) -> None: ...

class ContentTypeError(ValidationError):
    content_type: Optional[str]
    allowed: tuple
    def __init__(self, content_type: Optional[str], allowed) -> None: ...

class EncodingError(ValidationError):
    encoding: str
    def __init__(self, encoding: str, detail: str = ...) -> None: ...

class ChecksumError(ValidationError):
    algorithm: str
    expected: str
    actual: str
    def __init__(self, algorithm: str, expected: str, actual: str) -> None: ...
