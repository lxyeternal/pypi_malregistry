# anistream

A Python package for anime streaming utilities.

## Installation

```bash
pip install anistream
```

## Usage

```python
from anistream import cloudflarebypass as cfb

cfb.bypass()
```
