from setuptools import setup

setup(
    name="colorfonts",
    version="2.3",
    description="stylize your print !",
    packages=['colorfonts'], 
    zip_safe=False
)