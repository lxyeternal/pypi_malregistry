def isRed(color): 
    return color == "red"