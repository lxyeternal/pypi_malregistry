#Gets information about the logged in user
import requests

def getuserinfo(user): #user will be a Class
    pass
