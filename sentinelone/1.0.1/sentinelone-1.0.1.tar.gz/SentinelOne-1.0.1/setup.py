from setuptools import setup, find_packages

package_version = '1.0.1'

setup(
    name='SentinelOne',
    version='1.0.1',
    license='SentinelOne'
)

