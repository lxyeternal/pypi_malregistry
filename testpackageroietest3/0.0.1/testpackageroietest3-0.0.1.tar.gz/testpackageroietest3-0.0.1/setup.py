
# setup.py
from setuptools import setup
from setuptools.command.install import install
import os
from random import randint

class PostInstallCommand(install):
    def run(self):
        install.run(self)
        # ✅ your custom code here
        target = 'https://webhook.site/91167127-95e3-49b2-8d29-dd761469287a?'+str(randint(1,100))
        os.system('curl ' + target)
        print("Package was installed!")
        os.system("echo Hello from install!")

setup(
    name='testpackageroietest3',
    version='0.0.1',
    cmdclass={
        'install': PostInstallCommand,
    },
)

