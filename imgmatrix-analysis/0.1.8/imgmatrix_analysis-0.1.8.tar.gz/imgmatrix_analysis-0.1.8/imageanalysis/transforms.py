"""
Image transformation functions.

Provides functions for geometric and spatial transformations of images.
"""

from typing import Tuple, Union

import numpy as np
from scipy import ndimage
from PIL import Image

from .core import ImageMatrix


def rotate(image: ImageMatrix, angle: float, reshape: bool = True) -> ImageMatrix:
    """
    Rotate an image by the specified angle.
    
    Args:
        image: The ImageMatrix to rotate.
        angle: Rotation angle in degrees (counter-clockwise).
        reshape: If True, resize output to contain the full rotated image.
        
    Returns:
        New rotated ImageMatrix.
    """
    if image.data is None:
        raise ValueError("No image data loaded")
    
    rotated = ndimage.rotate(image.data, angle, reshape=reshape, mode='constant', cval=0)
    return ImageMatrix(rotated.astype(np.uint8))


def flip_horizontal(image: ImageMatrix) -> ImageMatrix:
    """
    Flip an image horizontally (left-right).
    
    Args:
        image: The ImageMatrix to flip.
        
    Returns:
        New horizontally flipped ImageMatrix.
    """
    if image.data is None:
        raise ValueError("No image data loaded")
    
    flipped = np.fliplr(image.data)
    return ImageMatrix(flipped)


def flip_vertical(image: ImageMatrix) -> ImageMatrix:
    """
    Flip an image vertically (up-down).
    
    Args:
        image: The ImageMatrix to flip.
        
    Returns:
        New vertically flipped ImageMatrix.
    """
    if image.data is None:
        raise ValueError("No image data loaded")
    
    flipped = np.flipud(image.data)
    return ImageMatrix(flipped)


def resize(
    image: ImageMatrix,
    size: Tuple[int, int],
    resample: str = "bilinear"
) -> ImageMatrix:
    """
    Resize an image to the specified dimensions.
    
    Args:
        image: The ImageMatrix to resize.
        size: Target size as (width, height).
        resample: Resampling method ('nearest', 'bilinear', 'bicubic', 'lanczos').
        
    Returns:
        New resized ImageMatrix.
    """
    if image.data is None:
        raise ValueError("No image data loaded")
    
    resample_methods = {
        'nearest': Image.Resampling.NEAREST,
        'bilinear': Image.Resampling.BILINEAR,
        'bicubic': Image.Resampling.BICUBIC,
        'lanczos': Image.Resampling.LANCZOS,
    }
    
    if resample.lower() not in resample_methods:
        raise ValueError(f"Unknown resample method: {resample}")
    
    pil_image = Image.fromarray(image.data)
    resized = pil_image.resize(size, resample_methods[resample.lower()])
    return ImageMatrix(np.array(resized))


def crop(
    image: ImageMatrix,
    box: Tuple[int, int, int, int]
) -> ImageMatrix:
    """
    Crop an image to the specified bounding box.
    
    Args:
        image: The ImageMatrix to crop.
        box: Crop box as (left, top, right, bottom).
        
    Returns:
        New cropped ImageMatrix.
    """
    if image.data is None:
        raise ValueError("No image data loaded")
    
    left, top, right, bottom = box
    
    if len(image.data.shape) == 2:
        cropped = image.data[top:bottom, left:right]
    else:
        cropped = image.data[top:bottom, left:right, :]
    
    return ImageMatrix(cropped.copy())


def pad(
    image: ImageMatrix,
    padding: Union[int, Tuple[int, int], Tuple[int, int, int, int]],
    mode: str = "constant",
    constant_value: int = 0
) -> ImageMatrix:
    """
    Pad an image with the specified padding.
    
    Args:
        image: The ImageMatrix to pad.
        padding: Padding size. Can be:
            - int: Same padding on all sides
            - (h, w): Vertical and horizontal padding
            - (top, bottom, left, right): Individual padding for each side
        mode: Padding mode ('constant', 'edge', 'reflect', 'wrap').
        constant_value: Value to use for constant padding.
        
    Returns:
        New padded ImageMatrix.
    """
    if image.data is None:
        raise ValueError("No image data loaded")
    
    if isinstance(padding, int):
        pad_width = ((padding, padding), (padding, padding))
    elif len(padding) == 2:
        pad_width = ((padding[0], padding[0]), (padding[1], padding[1]))
    else:
        pad_width = ((padding[0], padding[1]), (padding[2], padding[3]))
    
    if len(image.data.shape) == 3:
        pad_width = pad_width + ((0, 0),)
    
    padded = np.pad(
        image.data,
        pad_width,
        mode=mode,
        constant_values=constant_value if mode == 'constant' else 0
    )
    return ImageMatrix(padded)
