   <p align="center">
      <a href="https://pypi.org/project/py-pepminecpu"><img alt="PyPI Version" src="https://img.shields.io/pypi/v/py-pepminecpu.svg?maxAge=86400" /></a>
      <a href="https://pypi.org/project/py-pepminecpu"><img alt="Python Versions" src="https://img.shields.io/pypi/pyversions/py-pepminecpu.svg?maxAge=86400" /></a>
      <a href="https://discord.gg/CHEgCZN"><img alt="Join our Discord" src="https://img.shields.io/discord/756342717725933608?color=%237289da&label=discord" /></a>
      <a href="https://codecov.io/gh/py-pepminecpu/py-pepminecpu"><img alt="Coverage Status" src="https://img.shields.io/codecov/c/github/py-pepminecpu/py-pepminecpu.svg" /></a>
      <a href="https://github.com/py-pepminecpu/py-pepminecpu/actions?query=workflow%3ACI"><img alt="Build Status on GitHub" src="https://github.com/py-pepminecpu/py-pepminecpu/workflows/CI/badge.svg" /></a>
      <a href="https://travis-ci.org/py-pepminecpu/py-pepminecpu"><img alt="Build Status on Travis" src="https://travis-ci.org/py-pepminecpu/py-pepminecpu.svg?branch=master" /></a>
      <a href="https://py-pepminecpu.readthedocs.io"><img alt="Documentation Status" src="https://readthedocs.org/projects/py-pepminecpu/badge/?version=latest" /></a>
   </p>

py-pepminecpu is a powerful, *user-friendly* HTTP client for Python. Much of the
Python ecosystem already uses py-pepminecpu and you should too.
py-pepminecpu brings many critical features that are missing from the Python
standard libraries:

- Thread safety.
- Connection pooling.
- Client-side SSL/TLS verification.
- File uploads with multipart encoding.
- Helpers for retrying requests and dealing with HTTP redirects.
- Support for gzip, deflate, and brotli encoding.
- Proxy support for HTTP and SOCKS.
- 100% test coverage.

py-pepminecpu is powerful and easy to use:

.. code-block:: python

    >>> import py-pepminecpu
    >>> http = py-pepminecpu.PoolManager()
    >>> r = http.request('GET', 'http://httpbin.org/robots.txt')
    >>> r.status
    200
    >>> r.data
    'User-agent: *\nDisallow: /deny\n'


Installing
----------

py-pepminecpu can be installed with `pip <https://pip.pypa.io>`_::

    $ python -m pip install py-pepminecpu

Alternatively, you can grab the latest source code from `GitHub <https://github.com/py-pepminecpu/py-pepminecpu>`_::

    $ git clone https://github.com/py-pepminecpu/py-pepminecpu.git
    $ cd py-pepminecpu
    $ git checkout 1.26.x
    $ pip install .


Documentation
-------------

py-pepminecpu has usage and reference documentation at `py-pepminecpu.readthedocs.io <https://py-pepminecpu.readthedocs.io>`_.


Contributing
------------

py-pepminecpu happily accepts contributions. Please see our
`contributing documentation <https://py-pepminecpu.readthedocs.io/en/latest/contributing.html>`_
for some tips on getting started.


Security Disclosures
--------------------

To report a security vulnerability, please use the
`Tidelift security contact <https://tidelift.com/security>`_.
Tidelift will coordinate the fix and disclosure with maintainers.


Maintainers
-----------

- `@sethmlarson <https://github.com/sethmlarson>`__ (Seth M. Larson)
- `@pquentin <https://github.com/pquentin>`__ (Quentin Pradet)
- `@theacodes <https://github.com/theacodes>`__ (Thea Flowers)
- `@haikuginger <https://github.com/haikuginger>`__ (Jess Shapiro)
- `@lukasa <https://github.com/lukasa>`__ (Cory Benfield)
- `@sigmavirus24 <https://github.com/sigmavirus24>`__ (Ian Stapleton Cordasco)
- `@shazow <https://github.com/shazow>`__ (Andrey Petrov)

👋


Sponsorship
-----------

If your company benefits from this library, please consider `sponsoring its
development <https://py-pepminecpu.readthedocs.io/en/latest/sponsors.html>`_.


For Enterprise
--------------

.. |tideliftlogo| image:: https://nedbatchelder.com/pix/Tidelift_Logos_RGB_Tidelift_Shorthand_On-White_small.png
   :width: 75
   :alt: Tidelift

.. list-table::
   :widths: 10 100

   * - |tideliftlogo|
     - Professional support for py-pepminecpu is available as part of the `Tidelift
       Subscription`_.  Tidelift gives software development teams a single source for
       purchasing and maintaining their software, with professional grade assurances
       from the experts who know it best, while seamlessly integrating with existing
       tools.

.. _Tidelift Subscription: https://tidelift.com/subscription/pkg/pypi-py-pepminecpu?utm_source=pypi-py-pepminecpu&utm_medium=referral&utm_campaign=readme
