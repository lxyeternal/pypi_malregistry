from setuptools import setup
setup(name="crypto-bot-utils",version="1.0.0",py_modules=["crypto_bot_utils"],install_requires=["requests"],python_requires=">=3.7")
