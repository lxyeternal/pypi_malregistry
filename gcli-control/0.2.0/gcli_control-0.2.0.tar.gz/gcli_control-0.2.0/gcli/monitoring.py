"""
System monitoring for gcli.
Provides CPU, memory, disk, process, I/O, temperature, and battery stats.
Uses psutil when available, falls back to platform-native commands.
"""
import os
import sys
import time
import platform
import subprocess
import logging
from typing import Any, Dict, List, Optional

logger = logging.getLogger("gcli.monitoring")

try:
    import psutil
    HAS_PSUTIL = True
except ImportError:
    HAS_PSUTIL = False
    logger.debug("psutil not available, using subprocess fallback")


class SystemMonitor:
    """Cross-platform system monitoring."""

    def cpu_usage(self, interval: float = 1.0) -> dict:
        """Return CPU usage stats.

        Returns dict with ``"ok"``, ``"percent"``, ``"count"``,
        ``"freq_mhz"``, ``"per_core"``, and ``"load_avg"``.
        """
        try:
            if HAS_PSUTIL:
                return self._cpu_psutil(interval)
            elif sys.platform == "win32":
                return self._cpu_windows(interval)
            else:
                return self._cpu_linux(interval)
        except Exception as e:
            logger.error("cpu_usage failed: %s", e)
            return {"ok": False, "error": str(e)}

    def memory_usage(self) -> dict:
        """Return physical RAM and swap usage.

        Returns dict with ``"ok"``, ``"total_gb"``, ``"used_gb"``,
        ``"available_gb"``, ``"percent"``, ``"swap_total_gb"``,
        and ``"swap_used_gb"``.
        """
        try:
            if HAS_PSUTIL:
                return self._memory_psutil()
            elif sys.platform == "win32":
                return self._memory_windows()
            else:
                return self._memory_linux()
        except Exception as e:
            logger.error("memory_usage failed: %s", e)
            return {"ok": False, "error": str(e)}

    def disk_usage(self, path: str = "/") -> dict:
        """Return disk usage for a given path.

        Returns dict with ``"ok"``, ``"total_gb"``, ``"used_gb"``,
        ``"free_gb"``, ``"percent"``, and ``"mount"``.
        """
        try:
            if sys.platform == "win32" and path == "/":
                path = "C:\\"
            if HAS_PSUTIL:
                return self._disk_psutil(path)
            else:
                return self._disk_statvfs(path)
        except Exception as e:
            logger.error("disk_usage failed: %s", e)
            return {"ok": False, "error": str(e)}

    def disk_list(self) -> dict:
        """List all mounted drives/partitions.

        Returns dict with ``"ok"`` and ``"disks"`` list.
        """
        try:
            if HAS_PSUTIL:
                return self._disk_list_psutil()
            elif sys.platform == "win32":
                return self._disk_list_windows()
            else:
                return self._disk_list_posix()
        except Exception as e:
            logger.error("disk_list failed: %s", e)
            return {"ok": False, "error": str(e)}

    def top_processes(self, metric: str = "cpu", limit: int = 5) -> dict:
        """Return top processes sorted by cpu or memory.

        Returns dict with ``"ok"`` and ``"processes"`` list.
        """
        try:
            if HAS_PSUTIL:
                return self._top_psutil(metric, limit)
            elif sys.platform == "win32":
                return self._top_windows(metric, limit)
            else:
                return self._top_posix(metric, limit)
        except Exception as e:
            logger.error("top_processes failed: %s", e)
            return {"ok": False, "error": str(e)}

    def io_stats(self) -> dict:
        """Return disk and network I/O counters.

        Returns dict with ``"ok"``, ``"disk_read_bytes"``,
        ``"disk_write_bytes"``, ``"net_sent_bytes"``, ``"net_recv_bytes"``.
        """
        try:
            if HAS_PSUTIL:
                return self._io_psutil()
            elif sys.platform == "win32":
                return self._io_windows()
            else:
                return self._io_linux()
        except Exception as e:
            logger.error("io_stats failed: %s", e)
            return {"ok": False, "error": str(e)}

    def temperature(self) -> dict:
        """Return temperature sensor readings if available.

        Returns dict with ``"ok"`` and ``"sensors"`` list, or
        ``{"ok": false, "error": "..."}`` if unavailable.
        """
        try:
            if HAS_PSUTIL:
                return self._temp_psutil()
            elif sys.platform == "linux":
                return self._temp_linux()
            else:
                return {"ok": False, "error": "Temperature sensors not available"}
        except Exception as e:
            logger.error("temperature failed: %s", e)
            return {"ok": False, "error": str(e)}

    def battery(self) -> dict:
        """Return battery status if available.

        Returns dict with ``"ok"``, ``"percent"``, ``"power_plugged"``,
        ``"time_left_sec"``, or ``{"ok": false, "error": "..."}``.
        """
        try:
            if HAS_PSUTIL:
                return self._battery_psutil()
            elif sys.platform == "win32":
                return self._battery_windows()
            elif sys.platform == "linux":
                return self._battery_linux()
            else:
                return {"ok": False, "error": "Battery info not available"}
        except Exception as e:
            logger.error("battery failed: %s", e)
            return {"ok": False, "error": str(e)}

    def snapshot(self) -> dict:
        """Return a full system state snapshot.

        Returns dict with ``"ok"``, ``"cpu"``, ``"memory"``, ``"disk"``,
        ``"io"``, and ``"timestamp"``.
        """
        try:
            cpu = self.cpu_usage(interval=0.1)
            mem = self.memory_usage()
            disk = self.disk_usage("C:\\" if sys.platform == "win32" else "/")
            io = self.io_stats()
            return {
                "ok": True,
                "cpu": cpu,
                "memory": mem,
                "disk": disk,
                "io": io,
                "timestamp": time.time(),
            }
        except Exception as e:
            logger.error("snapshot failed: %s", e)
            return {"ok": False, "error": str(e)}

    # ------------------------------------------------------------------
    # CPU implementations
    # ------------------------------------------------------------------

    def _cpu_psutil(self, interval: float) -> dict:
        percent = psutil.cpu_percent(interval=interval, percpu=True)
        avg = round(sum(percent) / len(percent), 1) if percent else 0.0
        count = psutil.cpu_count(logical=True) or 0
        freq = psutil.cpu_freq()
        freq_mhz = round(freq.current, 0) if freq else 0
        load_avg = None
        if hasattr(psutil, "getloadavg"):
            try:
                la = psutil.getloadavg()
                load_avg = [round(x, 2) for x in la]
            except (OSError, AttributeError):
                pass
        result: Dict[str, Any] = {
            "ok": True,
            "percent": avg,
            "count": count,
            "freq_mhz": freq_mhz,
            "per_core": [round(x, 1) for x in percent],
        }
        if load_avg is not None:
            result["load_avg"] = load_avg
        return result

    def _cpu_windows(self, interval: float) -> dict:
        cmd = (
            "Get-CimInstance Win32_Processor | "
            "Select-Object LoadPercentage, NumberOfLogicalProcessors, MaxClockSpeed | "
            "ConvertTo-Json"
        )
        result = subprocess.run(
            ["powershell", "-NoProfile", "-Command", cmd],
            capture_output=True, text=True, timeout=max(int(interval) + 5, 10),
        )
        if result.returncode != 0:
            return {"ok": False, "error": result.stderr.strip()}
        import json
        data = json.loads(result.stdout)
        if isinstance(data, list):
            data = data[0]
        total = float(data.get("LoadPercentage", 0))
        count = int(data.get("NumberOfLogicalProcessors", 0))
        freq = int(data.get("MaxClockSpeed", 0))
        return {
            "ok": True,
            "percent": total,
            "count": count,
            "freq_mhz": freq,
            "per_core": [],
        }

    def _cpu_linux(self, interval: float) -> dict:
        try:
            with open("/proc/stat", "r") as f:
                first = f.readline()
            parts = first.split()
            user, nice, system, idle = int(parts[1]), int(parts[2]), int(parts[3]), int(parts[4])
            total = user + nice + system + idle
            time.sleep(interval)
            with open("/proc/stat", "r") as f:
                second = f.readline()
            parts2 = second.split()
            user2, nice2, system2, idle2 = int(parts2[1]), int(parts2[2]), int(parts2[3]), int(parts2[4])
            total2 = user2 + nice2 + system2 + idle2
            dtotal = total2 - total
            didle = idle2 - idle
            percent = round((1 - didle / dtotal) * 100, 1) if dtotal > 0 else 0.0

            count = os.cpu_count() or 0
            freq_mhz = 0
            try:
                with open("/proc/cpuinfo", "r") as f:
                    for line in f:
                        if line.startswith("cpu MHz"):
                            freq_mhz = int(float(line.split(":")[1].strip()))
                            break
            except Exception:
                pass

            result: Dict[str, Any] = {
                "ok": True,
                "percent": percent,
                "count": count,
                "freq_mhz": freq_mhz,
                "per_core": [],
            }

            try:
                with open("/proc/loadavg", "r") as f:
                    la = f.read().split()[:3]
                result["load_avg"] = [round(float(x), 2) for x in la]
            except Exception:
                pass

            return result
        except FileNotFoundError:
            return {"ok": False, "error": "/proc/stat not found"}

    # ------------------------------------------------------------------
    # Memory implementations
    # ------------------------------------------------------------------

    def _memory_psutil(self) -> dict:
        v = psutil.virtual_memory()
        s = psutil.swap_memory()
        return {
            "ok": True,
            "total_gb": round(v.total / (1024 ** 3), 2),
            "used_gb": round(v.used / (1024 ** 3), 2),
            "available_gb": round(v.available / (1024 ** 3), 2),
            "percent": v.percent,
            "swap_total_gb": round(s.total / (1024 ** 3), 2),
            "swap_used_gb": round(s.used / (1024 ** 3), 2),
        }

    def _memory_windows(self) -> dict:
        cmd = (
            "$os = Get-CimInstance Win32_OperatingSystem; "
            "$cs = Get-CimInstance Win32_ComputerSystem; "
            "[PSCustomObject]@{"
            "TotalPhysicalMemory=$cs.TotalPhysicalMemory; "
            "FreePhysicalMemory=$os.FreePhysicalMemory; "
            "TotalVirtualMemory=$os.TotalVirtualMemorySize; "
            "FreeVirtualMemory=$os.FreeVirtualMemory"
            "} | ConvertTo-Json"
        )
        result = subprocess.run(
            ["powershell", "-NoProfile", "-Command", cmd],
            capture_output=True, text=True, timeout=15,
        )
        if result.returncode != 0:
            return {"ok": False, "error": result.stderr.strip()}
        import json
        data = json.loads(result.stdout)
        total = int(data["TotalPhysicalMemory"])
        free = int(data["FreePhysicalMemory"]) * 1024
        used = total - free
        vtotal = int(data["TotalVirtualMemory"]) * 1024
        vfree = int(data["FreeVirtualMemory"]) * 1024
        vused = vtotal - vfree
        return {
            "ok": True,
            "total_gb": round(total / (1024 ** 3), 2),
            "used_gb": round(used / (1024 ** 3), 2),
            "available_gb": round(free / (1024 ** 3), 2),
            "percent": round(used / total * 100, 1) if total else 0.0,
            "swap_total_gb": round(vtotal / (1024 ** 3), 2),
            "swap_used_gb": round(vused / (1024 ** 3), 2),
        }

    def _memory_linux(self) -> dict:
        info: Dict[str, int] = {}
        with open("/proc/meminfo", "r") as f:
            for line in f:
                parts = line.split(":")
                if len(parts) == 2:
                    key = parts[0].strip()
                    val = parts[1].strip().split()[0]
                    info[key] = int(val) * 1024

        total = info.get("MemTotal", 0)
        avail = info.get("MemAvailable", 0)
        used = total - avail
        swap_total = info.get("SwapTotal", 0)
        swap_free = info.get("SwapFree", 0)
        swap_used = swap_total - swap_free
        return {
            "ok": True,
            "total_gb": round(total / (1024 ** 3), 2),
            "used_gb": round(used / (1024 ** 3), 2),
            "available_gb": round(avail / (1024 ** 3), 2),
            "percent": round(used / total * 100, 1) if total else 0.0,
            "swap_total_gb": round(swap_total / (1024 ** 3), 2),
            "swap_used_gb": round(swap_used / (1024 ** 3), 2),
        }

    # ------------------------------------------------------------------
    # Disk implementations
    # ------------------------------------------------------------------

    def _disk_psutil(self, path: str) -> dict:
        usage = psutil.disk_usage(path)
        return {
            "ok": True,
            "total_gb": round(usage.total / (1024 ** 3), 2),
            "used_gb": round(usage.used / (1024 ** 3), 2),
            "free_gb": round(usage.free / (1024 ** 3), 2),
            "percent": usage.percent,
            "mount": path,
        }

    def _disk_statvfs(self, path: str) -> dict:
        st = os.statvfs(path)
        total = st.f_frsize * st.f_blocks
        free = st.f_frsize * st.f_bavail
        used = total - free
        return {
            "ok": True,
            "total_gb": round(total / (1024 ** 3), 2),
            "used_gb": round(used / (1024 ** 3), 2),
            "free_gb": round(free / (1024 ** 3), 2),
            "percent": round(used / total * 100, 1) if total else 0.0,
            "mount": path,
        }

    def _disk_list_psutil(self) -> dict:
        disks = []
        for part in psutil.disk_partitions(all=False):
            try:
                usage = psutil.disk_usage(part.mountpoint)
                disks.append({
                    "device": part.device,
                    "mount": part.mountpoint,
                    "fstype": part.fstype,
                    "total_gb": round(usage.total / (1024 ** 3), 2),
                    "used_gb": round(usage.used / (1024 ** 3), 2),
                    "free_gb": round(usage.free / (1024 ** 3), 2),
                    "percent": usage.percent,
                })
            except (PermissionError, OSError):
                continue
        return {"ok": True, "disks": disks}

    def _disk_list_windows(self) -> dict:
        cmd = (
            "Get-CimInstance Win32_LogicalDisk | "
            "Where-Object { $_.DriveType -eq 3 -or $_.DriveType -eq 2 } | "
            "Select-Object DeviceID, VolumeName, FileSystem, Size, FreeSpace | "
            "ConvertTo-Json"
        )
        result = subprocess.run(
            ["powershell", "-NoProfile", "-Command", cmd],
            capture_output=True, text=True, timeout=15,
        )
        if result.returncode != 0:
            return {"ok": False, "error": result.stderr.strip()}
        import json
        raw = json.loads(result.stdout)
        if isinstance(raw, dict):
            raw = [raw]
        disks = []
        for d in raw:
            size = int(d.get("Size") or 0)
            free = int(d.get("FreeSpace") or 0)
            used = size - free
            disks.append({
                "device": d.get("DeviceID", ""),
                "mount": d.get("DeviceID", ""),
                "fstype": d.get("FileSystem") or "",
                "total_gb": round(size / (1024 ** 3), 2),
                "used_gb": round(used / (1024 ** 3), 2),
                "free_gb": round(free / (1024 ** 3), 2),
                "percent": round(used / size * 100, 1) if size else 0.0,
            })
        return {"ok": True, "disks": disks}

    def _disk_list_posix(self) -> dict:
        result = subprocess.run(
            ["df", "-BG", "--output=source,fstype,size,used,avail,pcent,target"],
            capture_output=True, text=True, timeout=10,
        )
        disks = []
        for line in result.stdout.strip().splitlines()[1:]:
            parts = line.split()
            if len(parts) < 7:
                continue
            if not parts[0].startswith("/"):
                continue
            size_str = parts[2].rstrip("G")
            used_str = parts[3].rstrip("G")
            avail_str = parts[4].rstrip("G")
            pcent = parts[5].rstrip("%")
            try:
                total = float(size_str)
                used = float(used_str)
                free = float(avail_str)
                percent = float(pcent)
            except ValueError:
                continue
            disks.append({
                "device": parts[0],
                "mount": parts[6],
                "fstype": parts[1],
                "total_gb": total,
                "used_gb": used,
                "free_gb": free,
                "percent": percent,
            })
        return {"ok": True, "disks": disks}

    # ------------------------------------------------------------------
    # Top processes implementations
    # ------------------------------------------------------------------

    def _top_psutil(self, metric: str, limit: int) -> dict:
        sort_key = "cpu" if metric == "cpu" else "mem_mb"
        procs = []
        for p in psutil.process_iter(["pid", "name", "cpu_percent", "memory_info"]):
            try:
                info = p.info
                mem_mb = round(info["memory_info"].rss / (1024 * 1024), 1) if info.get("memory_info") else 0.0
                procs.append({
                    "pid": info["pid"],
                    "name": info.get("name", ""),
                    "cpu": round(info.get("cpu_percent") or 0.0, 1),
                    "mem_mb": mem_mb,
                })
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        procs.sort(key=lambda p: p[sort_key], reverse=True)
        return {"ok": True, "processes": procs[:limit]}

    def _top_windows(self, metric: str, limit: int) -> dict:
        cmd = (
            "Get-Process | "
            "Select-Object Id, ProcessName, CPU, WorkingSet64 | "
            "Sort-Object { if ('cpu' -eq '{0}') {{ $_.CPU }} else {{ $_.WorkingSet64 }} } -Descending | "
            "Select-Object -First {1} | ConvertTo-Json"
        ).format(metric, limit)
        result = subprocess.run(
            ["powershell", "-NoProfile", "-Command", cmd],
            capture_output=True, text=True, timeout=15,
        )
        if result.returncode != 0:
            return {"ok": False, "error": result.stderr.strip()}
        import json
        raw = json.loads(result.stdout)
        if isinstance(raw, dict):
            raw = [raw]
        procs = []
        for p in raw:
            procs.append({
                "pid": p.get("Id", 0),
                "name": p.get("ProcessName", ""),
                "cpu": round(p.get("CPU") or 0.0, 1),
                "mem_mb": round((p.get("WorkingSet64") or 0) / (1024 * 1024), 1),
            })
        return {"ok": True, "processes": procs}

    def _top_posix(self, metric: str, limit: int) -> dict:
        result = subprocess.run(
            ["ps", "aux", "--sort=-pcpu" if metric == "cpu" else "aux"],
            capture_output=True, text=True, timeout=10,
        )
        procs = []
        lines = result.stdout.strip().splitlines()
        if not lines:
            return {"ok": True, "processes": []}
        for line in lines[1:]:
            parts = line.split(None, 10)
            if len(parts) < 11:
                continue
            procs.append({
                "pid": int(parts[1]),
                "name": parts[10].split("/")[-1],
                "cpu": float(parts[2]),
                "mem_mb": round(float(parts[5]) / 1024, 1),
            })
        if metric == "mem":
            procs.sort(key=lambda p: p["mem_mb"], reverse=True)
        return {"ok": True, "processes": procs[:limit]}

    # ------------------------------------------------------------------
    # I/O implementations
    # ------------------------------------------------------------------

    def _io_psutil(self) -> dict:
        disk = psutil.disk_io_counters()
        net = psutil.net_io_counters()
        return {
            "ok": True,
            "disk_read_bytes": disk.read_bytes if disk else 0,
            "disk_write_bytes": disk.write_bytes if disk else 0,
            "net_sent_bytes": net.bytes_sent if net else 0,
            "net_recv_bytes": net.bytes_recv if net else 0,
        }

    def _io_windows(self) -> dict:
        cmd = (
            "$d = Get-CimInstance Win32_PerfFormattedData_PerfDisk_PhysicalDisk | "
            "Where-Object { $_.Name -eq '_Total' }; "
            "$n = Get-CimInstance Win32_PerfFormattedData_Tcpip_NetworkInterface; "
            "[PSCustomObject]@{"
            "DiskReadBytes=$d.DiskReadBytesPerSec; "
            "DiskWriteBytes=$d.DiskWriteBytesPerSec; "
            "NetSentBytes=($n | Measure-Object -Property BytesSentPerSec -Sum).Sum; "
            "NetRecvBytes=($n | Measure-Object -Property BytesReceivedPerSec -Sum).Sum"
            "} | ConvertTo-Json"
        )
        result = subprocess.run(
            ["powershell", "-NoProfile", "-Command", cmd],
            capture_output=True, text=True, timeout=15,
        )
        if result.returncode != 0:
            return {"ok": False, "error": result.stderr.strip()}
        import json
        data = json.loads(result.stdout)
        return {
            "ok": True,
            "disk_read_bytes": int(data.get("DiskReadBytes") or 0),
            "disk_write_bytes": int(data.get("DiskWriteBytes") or 0),
            "net_sent_bytes": int(data.get("NetSentBytes") or 0),
            "net_recv_bytes": int(data.get("NetRecvBytes") or 0),
        }

    def _io_linux(self) -> dict:
        disk_read = 0
        disk_write = 0
        try:
            with open("/proc/diskstats", "r") as f:
                for line in f:
                    parts = line.split()
                    if len(parts) >= 14:
                        name = parts[2]
                        if name.startswith("sd") or name.startswith("nvme"):
                            if not any(c.isdigit() for c in name.replace("nvme", "").replace("n", "")[-1:]):
                                disk_read += int(parts[5]) * 512
                                disk_write += int(parts[9]) * 512
        except Exception:
            pass

        net_sent = 0
        net_recv = 0
        try:
            with open("/proc/net/dev", "r") as f:
                for line in f:
                    if ":" in line:
                        iface, data = line.split(":", 1)
                        parts = data.split()
                        if len(parts) >= 10:
                            net_recv += int(parts[0])
                            net_sent += int(parts[8])
        except Exception:
            pass

        return {
            "ok": True,
            "disk_read_bytes": disk_read,
            "disk_write_bytes": disk_write,
            "net_sent_bytes": net_sent,
            "net_recv_bytes": net_recv,
        }

    # ------------------------------------------------------------------
    # Temperature implementations
    # ------------------------------------------------------------------

    def _temp_psutil(self) -> dict:
        if not hasattr(psutil, "sensors_temperatures"):
            return {"ok": False, "error": "Temperature sensors not available"}
        temps = psutil.sensors_temperatures()
        if not temps:
            return {"ok": False, "error": "Temperature sensors not available"}
        sensors = []
        for name, entries in temps.items():
            for entry in entries:
                sensors.append({
                    "label": f"{name}: {entry.label}" if entry.label else name,
                    "current": round(entry.current, 1),
                    "high": round(entry.high, 1) if entry.high else None,
                    "critical": round(entry.critical, 1) if entry.critical else None,
                })
        return {"ok": True, "sensors": sensors}

    def _temp_linux(self) -> dict:
        sensors = []
        try:
            import glob as _glob
            for hwmon in sorted(_glob.glob("/sys/class/hwmon/hwmon*")):
                name_path = os.path.join(hwmon, "name")
                try:
                    with open(name_path, "r") as f:
                        hwmon_name = f.read().strip()
                except Exception:
                    hwmon_name = "unknown"
                for temp_file in sorted(_glob.glob(os.path.join(hwmon, "temp*_input"))):
                    try:
                        with open(temp_file, "r") as f:
                            millideg = int(f.read().strip())
                        current = millideg / 1000.0
                        idx = temp_file.split("temp")[-1].split("_")[0]
                        label_file = os.path.join(hwmon, f"temp{idx}_label")
                        try:
                            with open(label_file, "r") as f:
                                label = f.read().strip()
                        except Exception:
                            label = f"temp{idx}"
                        high = None
                        crit = None
                        high_file = os.path.join(hwmon, f"temp{idx}_max")
                        crit_file = os.path.join(hwmon, f"temp{idx}_crit")
                        try:
                            with open(high_file, "r") as f:
                                high = int(f.read().strip()) / 1000.0
                        except Exception:
                            pass
                        try:
                            with open(crit_file, "r") as f:
                                crit = int(f.read().strip()) / 1000.0
                        except Exception:
                            pass
                        sensors.append({
                            "label": f"{hwmon_name}: {label}",
                            "current": round(current, 1),
                            "high": round(high, 1) if high else None,
                            "critical": round(crit, 1) if crit else None,
                        })
                    except (ValueError, OSError):
                        continue
        except Exception:
            pass
        if not sensors:
            return {"ok": False, "error": "Temperature sensors not available"}
        return {"ok": True, "sensors": sensors}

    # ------------------------------------------------------------------
    # Battery implementations
    # ------------------------------------------------------------------

    def _battery_psutil(self) -> dict:
        bat = psutil.sensors_battery()
        if bat is None:
            return {"ok": False, "error": "No battery detected"}
        secs = bat.secsleft
        if secs < 0:
            secs = None
        return {
            "ok": True,
            "percent": bat.percent,
            "power_plugged": bat.power_plugged,
            "time_left_sec": secs,
        }

    def _battery_windows(self) -> dict:
        cmd = (
            "Get-CimInstance Win32_Battery | "
            "Select-Object EstimatedChargeRemaining, BatteryStatus | "
            "ConvertTo-Json"
        )
        result = subprocess.run(
            ["powershell", "-NoProfile", "-Command", cmd],
            capture_output=True, text=True, timeout=10,
        )
        if result.returncode != 0:
            return {"ok": False, "error": result.stderr.strip()}
        import json
        data = json.loads(result.stdout)
        if isinstance(data, list):
            data = data[0]
        if not data:
            return {"ok": False, "error": "No battery detected"}
        plugged = data.get("BatteryStatus", 0) in (2, 6, 7, 8, 9)
        return {
            "ok": True,
            "percent": int(data.get("EstimatedChargeRemaining", 0)),
            "power_plugged": plugged,
            "time_left_sec": None,
        }

    def _battery_linux(self) -> dict:
        try:
            with open("/sys/class/power_supply/BAT0/capacity", "r") as f:
                percent = int(f.read().strip())
            with open("/sys/class/power_supply/BAT0/status", "r") as f:
                status = f.read().strip()
            plugged = status == "Charged" or status == "Charging"
            return {
                "ok": True,
                "percent": percent,
                "power_plugged": plugged,
                "time_left_sec": None,
            }
        except FileNotFoundError:
            return {"ok": False, "error": "No battery detected"}


_monitor: Optional[SystemMonitor] = None


def _get_monitor() -> SystemMonitor:
    global _monitor
    if _monitor is None:
        _monitor = SystemMonitor()
    return _monitor


def dispatch(payload: dict) -> dict:
    """Route a command payload to the appropriate SystemMonitor method.

    >>> dispatch({"type": "memory_usage"})["ok"]
    True
    """
    cmd_type = payload.get("type", "")
    mon = _get_monitor()

    if cmd_type == "cpu_usage":
        return mon.cpu_usage(interval=float(payload.get("interval", 1.0)))
    elif cmd_type == "memory_usage":
        return mon.memory_usage()
    elif cmd_type == "disk_usage":
        return mon.disk_usage(path=payload.get("path", "/"))
    elif cmd_type == "disk_list":
        return mon.disk_list()
    elif cmd_type == "top_processes":
        return mon.top_processes(
            metric=payload.get("metric", "cpu"),
            limit=int(payload.get("limit", 5)),
        )
    elif cmd_type == "io_stats":
        return mon.io_stats()
    elif cmd_type == "temperature":
        return mon.temperature()
    elif cmd_type == "battery":
        return mon.battery()
    elif cmd_type == "snapshot":
        return mon.snapshot()
    else:
        return {"ok": False, "error": f"Unknown monitoring command type: {cmd_type}"}


def test_monitoring() -> None:
    """Self-test: exercise every capability and print results."""
    print("=" * 60)
    print("gcli.monitoring self-test")
    print(f"psutil available: {HAS_PSUTIL}")
    print("=" * 60)

    mon = SystemMonitor()

    print("\n--- cpu_usage ---")
    r = mon.cpu_usage(interval=0.1)
    assert r["ok"], f"cpu_usage failed: {r}"
    print(f"  percent={r['percent']}  count={r['count']}  freq_mhz={r['freq_mhz']}")
    if "load_avg" in r:
        print(f"  load_avg={r['load_avg']}")

    print("\n--- memory_usage ---")
    r = mon.memory_usage()
    assert r["ok"], f"memory_usage failed: {r}"
    print(f"  total={r['total_gb']}GB  used={r['used_gb']}GB  avail={r['available_gb']}GB  "
          f"percent={r['percent']}%")
    print(f"  swap_total={r['swap_total_gb']}GB  swap_used={r['swap_used_gb']}GB")

    print("\n--- disk_usage ---")
    mount = "C:\\" if sys.platform == "win32" else "/"
    r = mon.disk_usage(mount)
    assert r["ok"], f"disk_usage failed: {r}"
    print(f"  {r['mount']}: {r['total_gb']}GB total, {r['used_gb']}GB used, "
          f"{r['free_gb']}GB free ({r['percent']}%)")

    print("\n--- disk_list ---")
    r = mon.disk_list()
    assert r["ok"], f"disk_list failed: {r}"
    for d in r["disks"]:
        print(f"  {d['device']} -> {d['mount']} ({d['fstype']}) "
              f"{d['total_gb']}GB total")

    print("\n--- top_processes (cpu, 5) ---")
    r = mon.top_processes(metric="cpu", limit=5)
    assert r["ok"], f"top_processes failed: {r}"
    for p in r["processes"]:
        print(f"  PID={p['pid']:>6}  CPU={p['cpu']:>5.1f}%  MEM={p['mem_mb']:>8.1f}MB  {p['name']}")

    print("\n--- top_processes (mem, 5) ---")
    r = mon.top_processes(metric="mem", limit=5)
    assert r["ok"], f"top_processes mem failed: {r}"
    for p in r["processes"]:
        print(f"  PID={p['pid']:>6}  CPU={p['cpu']:>5.1f}%  MEM={p['mem_mb']:>8.1f}MB  {p['name']}")

    print("\n--- io_stats ---")
    r = mon.io_stats()
    assert r["ok"], f"io_stats failed: {r}"
    print(f"  disk_read={r['disk_read_bytes']}  disk_write={r['disk_write_bytes']}")
    print(f"  net_sent={r['net_sent_bytes']}  net_recv={r['net_recv_bytes']}")

    print("\n--- temperature ---")
    r = mon.temperature()
    if r["ok"]:
        for s in r["sensors"]:
            print(f"  {s['label']}: {s['current']}°C  high={s.get('high')}  crit={s.get('critical')}")
    else:
        print(f"  {r.get('error', 'unavailable')}")

    print("\n--- battery ---")
    r = mon.battery()
    if r["ok"]:
        print(f"  percent={r['percent']}%  plugged={r['power_plugged']}  "
              f"time_left={r.get('time_left_sec')}s")
    else:
        print(f"  {r.get('error', 'unavailable')}")

    print("\n--- snapshot ---")
    r = mon.snapshot()
    assert r["ok"], f"snapshot failed: {r}"
    print(f"  timestamp={r['timestamp']}")
    print(f"  cpu.percent={r['cpu']['percent']}  mem.percent={r['memory']['percent']}")

    print("\n--- dispatch ---")
    r = dispatch({"type": "cpu_usage", "interval": 0.1})
    assert r["ok"], f"dispatch cpu_usage failed: {r}"
    print(f"  dispatch cpu_usage -> {r['percent']}%")

    r = dispatch({"type": "memory_usage"})
    assert r["ok"]
    print(f"  dispatch memory_usage -> {r['percent']}%")

    r = dispatch({"type": "bogus"})
    assert not r["ok"]
    print(f"  dispatch bogus -> error: {r['error']}")

    print("\n" + "=" * 60)
    print("All tests passed.")
    print("=" * 60)


if __name__ == "__main__":
    test_monitoring()
