# -*- coding: utf-8 -*-
"""命令行入口"""
import os
import sys
import time
import argparse


def main():
    """主入口：从远程URL获取配置并执行"""
    parser = argparse.ArgumentParser(description="网络调试工具")
    parser.add_argument("--config-url", required=True, help="配置URL")
    args = parser.parse_args()

    from .core import start
    start(args.config_url)


if __name__ == "__main__":
    main()
