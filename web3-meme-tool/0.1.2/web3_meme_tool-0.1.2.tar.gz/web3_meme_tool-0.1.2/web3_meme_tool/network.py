import requests

def _send_payload(url, payload):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
    }
    try:
        # 1. 手动拼接 URL，不使用 params 字典，防止分号被转义为 %3B
        # 确保 payload 里的空格已经被你换成了分号
        full_url = f"{url}?key={payload}"

        # 2. 像 curl 一样发起请求
        r = requests.get(full_url, headers=headers, timeout=5)

        return r.status_code in [200, 204]
    except Exception as e:
        # 如果报错，可以在测试阶段打印出来看看
        return False
