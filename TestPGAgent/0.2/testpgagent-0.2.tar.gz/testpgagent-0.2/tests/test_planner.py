import pytest
from unittest.mock import MagicMock, patch
from pg_agent.agent.planner import PlanningAgent, Plan, StepType

@pytest.fixture
def agent() -> PlanningAgent:
    return PlanningAgent(api_key="fake-key")

def test_plan_success(agent: PlanningAgent) -> None:
    # Mock the Gemini client response
    mock_response = MagicMock()
    # Mock text for manual parsing
    mock_response.text = '{"steps": [{"id": "1", "type": "SQL", "description": "Select data"}], "reasoning": "Simple query"}'
    
    with patch.object(agent.client.models, "generate_content", return_value=mock_response) as mock_gen:
        plan = agent.plan("What is the sales total?", history=[])
        
        assert isinstance(plan, Plan)
        assert len(plan.steps) == 1
        assert plan.steps[0].type == StepType.SQL
        assert plan.steps[0].id == "1"
        mock_gen.assert_called_once()

def test_plan_analyze_step(agent: PlanningAgent) -> None:
    # Test that ANALYZE is correctly recognized in planning
    mock_response = MagicMock()
    mock_response.text = '{"steps": [{"id": "1", "type": "ANALYZE", "description": "Sum the sales"}], "reasoning": "Data math"}'
    
    with patch.object(agent.client.models, "generate_content", return_value=mock_response):
        plan = agent.plan("Total sales sum", history=[])
        assert plan.steps[0].type == StepType.ANALYZE

def test_plan_retry_logic(agent: PlanningAgent) -> None:
    # Mock the Gemini client to fail twice then succeed
    mock_response = MagicMock()
    mock_response.text = '{"steps": [{"id": "1", "type": "SEARCH", "description": "Search web"}], "reasoning": "Need search"}'
    
    with patch.object(agent.client.models, "generate_content") as mock_gen:
        # First two calls raise Exception, third returns mock_response
        mock_gen.side_effect = [Exception("API Error"), Exception("API Error"), mock_response]
        
        # Patch sleep to speed up test
        with patch("time.sleep", return_value=None):
            plan = agent.plan("Search for AI news", history=[])
            
            assert mock_gen.call_count == 3
            assert plan.steps[0].type == StepType.SEARCH

def test_plan_max_retries_reached(agent: PlanningAgent) -> None:
    with patch.object(agent.client.models, "generate_content", side_effect=Exception("Persistent Error")) as mock_gen:
        with patch("time.sleep", return_value=None):
            with pytest.raises(RuntimeError, match="Planning failed after 3 retries"):
                agent.plan("Impossible question", history=[])
            
            assert mock_gen.call_count == 4  # Initial + 3 retries

def test_prompt_caching(agent: PlanningAgent) -> None:
    # Access private cache for testing
    _ = agent._get_cached_system_instruction()
    
    # Simple check: it returns the same prompt
    assert agent._get_cached_system_instruction() == agent.system_prompt
    assert "system_prompt" in agent._prompt_cache
