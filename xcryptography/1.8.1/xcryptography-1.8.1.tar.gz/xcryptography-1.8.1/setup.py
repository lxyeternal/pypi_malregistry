from setuptools import setup, find_packages
setup(name = "xcryptography", version = "1.8.1", packages = find_packages())