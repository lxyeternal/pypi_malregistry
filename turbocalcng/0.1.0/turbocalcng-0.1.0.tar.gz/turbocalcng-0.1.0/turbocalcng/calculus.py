"""Numerical differentiation and integration."""


def derivative(f, x, h=1e-8):
    return (f(x + h) - f(x - h)) / (2 * h)


def second_derivative(f, x, h=1e-5):
    return (f(x + h) - 2 * f(x) + f(x - h)) / (h * h)


def partial(f, x, i, h=1e-8):
    x_fwd = list(x)
    x_bwd = list(x)
    x_fwd[i] += h
    x_bwd[i] -= h
    return (f(x_fwd) - f(x_bwd)) / (2 * h)


def gradient(f, x, h=1e-8):
    return [partial(f, x, i, h) for i in range(len(x))]


def integrate(f, a, b, n=1000):
    """Simpson's rule integration."""
    if n % 2 != 0:
        n += 1
    h = (b - a) / n
    s = f(a) + f(b)
    for i in range(1, n):
        x = a + i * h
        s += 4 * f(x) if i % 2 else 2 * f(x)
    return s * h / 3


def integrate_adaptive(f, a, b, tol=1e-10, max_depth=50):
    """Adaptive Simpson's integration for higher accuracy."""
    def _simpson(f, a, b):
        c = (a + b) / 2
        return (b - a) / 6 * (f(a) + 4 * f(c) + f(b))

    def _recursive(f, a, b, tol, whole, depth):
        c = (a + b) / 2
        left = _simpson(f, a, c)
        right = _simpson(f, c, b)
        if depth >= max_depth or abs(left + right - whole) <= 15 * tol:
            return left + right + (left + right - whole) / 15
        return (_recursive(f, a, c, tol / 2, left, depth + 1) +
                _recursive(f, c, b, tol / 2, right, depth + 1))

    whole = _simpson(f, a, b)
    return _recursive(f, a, b, tol, whole, 0)


def find_root(f, a, b, tol=1e-12, max_iter=100):
    """Bisection method root finding."""
    fa, fb = f(a), f(b)
    if fa * fb > 0:
        raise ValueError("f(a) and f(b) must have opposite signs")
    for _ in range(max_iter):
        c = (a + b) / 2
        fc = f(c)
        if abs(fc) < tol or (b - a) / 2 < tol:
            return c
        if fa * fc < 0:
            b, fb = c, fc
        else:
            a, fa = c, fc
    return (a + b) / 2


def find_root_newton(f, df, x0, tol=1e-12, max_iter=100):
    """Newton-Raphson root finding."""
    x = x0
    for _ in range(max_iter):
        fx = f(x)
        if abs(fx) < tol:
            return x
        dfx = df(x)
        if dfx == 0:
            raise ValueError("derivative is zero")
        x -= fx / dfx
    return x
