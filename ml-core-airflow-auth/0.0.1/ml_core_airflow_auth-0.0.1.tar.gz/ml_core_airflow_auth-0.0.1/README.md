# ml-core-airflow-auth

auth token handler

## Installation

```bash
pip install ml-core-airflow-auth
```

## Usage

```python
import ml_core_airflow_auth
```

## Telemetry

This package collects anonymous usage metrics to help improve the platform.
Telemetry can be disabled by setting the `DISABLE_TELEMETRY` environment variable.

## License

MIT
