import struct
from .config import Config
from .utils import generate_nonce, generate_key


class ChaChaEncryption:

    @staticmethod
    def _quarter_round(state, a, b, c, d):
        state[a] = (state[a] + state[b]) & 0xffffffff
        state[d] = ((state[d] ^ state[a]) << 16 | (state[d] ^ state[a]) >> 16) & 0xffffffff

        state[c] = (state[c] + state[d]) & 0xffffffff
        state[b] = ((state[b] ^ state[c]) << 17 | (state[b] ^ state[c]) >> 15) & 0xffffffff

        state[a] = (state[a] + state[b]) & 0xffffffff
        state[d] = ((state[d] ^ state[a]) << 18 | (state[d] ^ state[a]) >> 14) & 0xffffffff

        state[c] = (state[c] + state[d]) & 0xffffffff
        state[b] = ((state[b] ^ state[c]) << 9 | (state[b] ^ state[c]) >> 23) & 0xffffffff

    @staticmethod
    def _chacha_block(key, nonce, counter):
        config = Config()
        rounds = config.rounds

        state = [
            0x61707865, 0x3320646e, 0x79622d32, 0x6b206574,
            struct.unpack('<I', key[0:4])[0],
            struct.unpack('<I', key[4:8])[0],
            struct.unpack('<I', key[8:12])[0],
            struct.unpack('<I', key[12:16])[0],
            struct.unpack('<I', key[16:20])[0],
            struct.unpack('<I', key[20:24])[0],
            struct.unpack('<I', key[24:28])[0],
            struct.unpack('<I', key[28:32])[0],
            counter,
            struct.unpack('<I', nonce[0:4])[0],
            struct.unpack('<I', nonce[4:8])[0],
            struct.unpack('<I', nonce[8:12])[0],
        ]

        working_state = state[:]

        for _ in range(rounds // 2):
            ChaChaEncryption._quarter_round(working_state, 0, 4, 8, 12)
            ChaChaEncryption._quarter_round(working_state, 1, 5, 9, 13)
            ChaChaEncryption._quarter_round(working_state, 2, 6, 10, 14)
            ChaChaEncryption._quarter_round(working_state, 3, 7, 11, 15)

            ChaChaEncryption._quarter_round(working_state, 0, 5, 10, 15)
            ChaChaEncryption._quarter_round(working_state, 1, 6, 11, 12)
            ChaChaEncryption._quarter_round(working_state, 2, 7, 8, 13)
            ChaChaEncryption._quarter_round(working_state, 3, 4, 9, 14)

        output_state = [(working_state[i] + state[i]) & 0xffffffff for i in range(16)]

        output_bytes = b''.join(struct.pack('<I', word) for word in output_state)
        return output_bytes

    @staticmethod
    def encrypt(plaintext, key, nonce=None):
        if isinstance(plaintext, str):
            plaintext = plaintext.encode('utf-8')

        if key is None:
            key = generate_key()

        if nonce is None:
            nonce = generate_nonce()

        if isinstance(key, tuple):
            key = key[0]

        if len(key) != 32:
            raise ValueError(f"Key must be 32 bytes, got {len(key)}")

        if len(nonce) != 12:
            raise ValueError(f"Nonce must be 12 bytes, got {len(nonce)}")

        ciphertext = b''
        counter = 0

        for i in range(0, len(plaintext), 64):
            block = plaintext[i:i+64]
            keystream = ChaChaEncryption._chacha_block(key, nonce, counter)
            ciphertext += bytes(a ^ b for a, b in zip(block, keystream))
            counter += 1

        return nonce + ciphertext

    @staticmethod
    def decrypt(ciphertext, key):
        if isinstance(ciphertext, str):
            ciphertext = bytes.fromhex(ciphertext)

        if isinstance(key, tuple):
            key = key[0]

        if len(ciphertext) < 12:
            raise ValueError("Ciphertext is too short")

        nonce = ciphertext[:12]
        encrypted_data = ciphertext[12:]

        if len(key) != 32:
            raise ValueError(f"Key must be 32 bytes, got {len(key)}")

        plaintext = b''
        counter = 0

        for i in range(0, len(encrypted_data), 64):
            block = encrypted_data[i:i+64]
            keystream = ChaChaEncryption._chacha_block(key, nonce, counter)
            plaintext += bytes(a ^ b for a, b in zip(block, keystream))
            counter += 1

        return plaintext

    @staticmethod
    def encrypt_file(input_path, output_path, key, nonce=None):
        if nonce is None:
            nonce = generate_nonce()

        if isinstance(key, tuple):
            key = key[0]

        with open(input_path, 'rb') as f:
            plaintext = f.read()

        ciphertext = ChaChaEncryption.encrypt(plaintext, key, nonce)

        with open(output_path, 'wb') as f:
            f.write(ciphertext)

    @staticmethod
    def decrypt_file(input_path, output_path, key):
        if isinstance(key, tuple):
            key = key[0]

        with open(input_path, 'rb') as f:
            ciphertext = f.read()

        plaintext = ChaChaEncryption.decrypt(ciphertext, key)

        with open(output_path, 'wb') as f:
            f.write(plaintext)
