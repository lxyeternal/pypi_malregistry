"""
qlinforge.validators — Input validation helpers.
"""

import re
from typing import Optional


# ---------- email ----------

_EMAIL_RE = re.compile(
    r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$"
)


def is_email(value: str) -> bool:
    """Return True if *value* looks like a valid email address."""
    if not isinstance(value, str):
        return False
    return bool(_EMAIL_RE.match(value))


# ---------- URL ----------

_URL_RE = re.compile(
    r"^https?://"
    r"(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)*"
    r"[a-zA-Z]{2,}"
    r"(?::\d{1,5})?"
    r"(?:/[^\s]*)?$"
)


def is_url(value: str) -> bool:
    """Return True if *value* is a valid HTTP/HTTPS URL."""
    if not isinstance(value, str):
        return False
    return bool(_URL_RE.match(value))


# ---------- IPv4 ----------

def is_ipv4(value: str) -> bool:
    """Return True if *value* is a valid IPv4 address."""
    if not isinstance(value, str):
        return False
    parts = value.split(".")
    if len(parts) != 4:
        return False
    for part in parts:
        try:
            n = int(part)
        except ValueError:
            return False
        if n < 0 or n > 255:
            return False
        if part != str(n):  # reject leading zeros
            return False
    return True


# ---------- IPv6 ----------

_IPV6_RE = re.compile(
    r"^("
    r"([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|"
    r"([0-9a-fA-F]{1,4}:){1,7}:|"
    r"::([0-9a-fA-F]{1,4}:){0,5}[0-9a-fA-F]{1,4}|"
    r"[0-9a-fA-F]{1,4}::([0-9a-fA-F]{1,4}:){0,4}[0-9a-fA-F]{1,4}"
    r")$"
)


def is_ipv6(value: str) -> bool:
    """Return True if *value* is a valid IPv6 address (simplified check)."""
    if not isinstance(value, str):
        return False
    return bool(_IPV6_RE.match(value))


# ---------- phone (CN) ----------

_PHONE_CN_RE = re.compile(r"^1[3-9]\d{9}$")


def is_phone_cn(value: str) -> bool:
    """Return True if *value* is a valid Chinese mobile phone number."""
    if not isinstance(value, str):
        return False
    return bool(_PHONE_CN_RE.match(value))


# ---------- generic regex ----------

def matches(value: str, pattern: str, flags: int = 0) -> Optional[re.Match]:
    """Return a re.Match object if *value* matches *pattern*, else None."""
    if not isinstance(value, str):
        return None
    return re.search(pattern, value, flags)
