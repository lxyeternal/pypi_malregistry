\# Sher Tool Demo



Simple Python CLI tool.



\## Usage



sher-tool greet  

sher-tool add 5 10

