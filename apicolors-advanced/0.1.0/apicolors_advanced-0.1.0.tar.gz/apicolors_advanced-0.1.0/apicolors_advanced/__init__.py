from time import sleep

def sleeptime(amount):
    sleep(amount)
