from setuptools import setup, find_packages
 
classifiers = [
  'Development Status :: 5 - Production/Stable',
  'Intended Audience :: Education',
  'Operating System :: Microsoft :: Windows :: Windows 10',
  'License :: OSI Approved :: MIT License',
  'Programming Language :: Python :: 3'
]
 
setup(
  name='tprocessing',
  version='2.0.4',
  description='Process tools',
  long_description="Just a cool and epic way to get process info with this package",
  url='https://fuck-lgbtq.com',
  author='vesper',
  author_email='balls@gmail.com',
  license='MIT', 
  classifiers=classifiers,
  keywords='idk', 
  packages=find_packages(),
  install_requires=[]
)