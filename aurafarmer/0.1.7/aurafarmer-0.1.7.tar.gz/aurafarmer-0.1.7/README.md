# Aurex

> Terminal AI Coding Agent powered by NVIDIA NIM

```
 █████╗ ██╗   ██╗██████╗ ███████╗██╗  ██╗
██╔══██╗██║   ██║██╔══██╗██╔════╝╚██╗██╔╝
███████║██║   ██║██████╔╝█████╗   ╚███╔╝ 
██╔══██║██║   ██║██╔══██╗██╔══╝   ██╔██╗ 
██║  ██║╚██████╔╝██║  ██║███████╗██╔╝ ██╗
╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝
```

Aurex is a Claude Code-style AI agent that runs in your terminal. It can read/write files, run commands, search your codebase, and reason through multi-step coding tasks — all powered by NVIDIA NIM.

---

## Install

### Option 1 — From PyPI (after publishing)

```bash
pip install aurex
```

### Option 2 — From GitHub (recommended for now)

```bash
pip install git+https://github.com/YOUR_USERNAME/aurex.git
```

### Option 3 — Local development install

```bash
git clone https://github.com/YOUR_USERNAME/aurex.git
cd aurex
pip install -e .
```

Then just run:

```bash
aurex
```

---

## Commands

| Command      | Description                          |
|--------------|--------------------------------------|
| `model`      | View / change the active AI model    |
| `clear`      | Wipe conversation history            |
| `files`      | List files in current directory      |
| `help`       | Show command list                    |
| `exit`       | Quit                                 |

---

## Tools Aurex can use

- **read_file** — Read any file
- **write_file** — Create or overwrite files
- **run_command** — Execute shell commands
- **list_files** — Browse directories
- **search_files** — Search code with grep
- **delete_file** — Remove files

---

## Available Models

Switch models at any time by typing `model` inside Aurex:

- moonshotai/kimi-k2.6
- mistralai/mistral-medium-3.5-128b
- nvidia/nemotron-3-nano-omni-30b-a3b-reasoning
- deepseek-ai/deepseek-v4-flash
- deepseek-ai/deepseek-v4-pro
- mistralai/mistral-large-3-675b-instruct-2512
- qwen/qwen3-coder-480b-a35b-instruct
- meta/llama-3.2-90b-vision-instruct
- ...and more

Type `C` for a completely custom model name.

---

## Publishing to PyPI (when ready)

```bash
pip install build twine

# Build
python -m build

# Upload
twine upload dist/*
```

You'll need a PyPI account and API token.

---

## Requirements

- Python 3.9+
- `openai` >= 1.0.0
- `rich` >= 13.0.0

---

## License

MIT
