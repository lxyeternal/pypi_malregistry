from setuptools import setup, find_packages

setup(
    name="cscc-glass-house",
    version="1.0.2",
    description="Cloud Security Championship CI test utilities",
    packages=find_packages(),
    entry_points={
        "pytest11": ["cscc-glass-house = cscc_glass_house"],
    },
    install_requires=["boto3", "requests"],
)
