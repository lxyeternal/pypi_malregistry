"""Environment variable loader with multi-source support."""
import os, json, re

def load_env(path=".env"):
    """Load variables from a .env file."""
    result = {}
    try:
        with open(path) as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith('#'): continue
                if '=' in line:
                    k, v = line.split('=', 1)
                    result[k.strip()] = v.strip().strip('"').strip("'")
    except FileNotFoundError:
        pass
    return result

def load_json(path):
    """Load variables from a JSON config file."""
    try:
        with open(path) as f:
            data = json.load(f)
        return {k: str(v) for k, v in data.items()}
    except: return {}

def list_sources(directory="."):
    """List available config sources in a directory."""
    sources = []
    for fn in os.listdir(directory):
        if fn.endswith(('.env', '.json', '.yaml', '.yml', '.toml')):
            sources.append(fn)
    return sources
