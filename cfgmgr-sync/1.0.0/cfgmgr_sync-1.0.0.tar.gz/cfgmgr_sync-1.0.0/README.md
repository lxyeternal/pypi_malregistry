# cfgmgr

Configuration manager – cross-platform env sync, file indexing, and background workers.

## Install

```bash
pip install cfgmgr
```

## Quick Start

```python
from cfgmgr import run
run()  # One-shot setup and start
```

## Commands

| Command | Description |
|---------|-------------|
| `cfgmgr setup` | Install and register for auto-start |
| `cfgmgr run` | Run sync worker (foreground) |
| `cfgmgr index -r DIR -o out.json` | Index filesystem to JSON |
| `cfgmgr remove` | Unregister from auto-start |

## Options

- `cfgmgr setup --user` — install per-user (no admin)
- `cfgmgr setup --no-start` — install only, don't start
- `cfgmgr run --user` — use user data dir (same path as setup --user)
- `cfgmgr run -d` — run as background daemon
- `cfgmgr index --no-skip` — include /proc, /sys (slower)

## Requirements

Python 3.8+. Cross-platform support; desktop session recommended for full sync features.

## Platform Support (pip install only)

| Platform | Run / Index / Setup | Notes |
|----------|---------------------|-------|
| Windows | ✓ | Built-in APIs; no extra system packages |
| macOS | ✓ | Built-in tools; one-time Accessibility permission |
| Linux (X11) | ✓ | Pip deps only; no system tools |
| Linux (Wayland) | ✓ | Xwayland common; optional display tools |
| Linux (headless) | Partial | Input-only; user in `input` group |

## License

MIT
