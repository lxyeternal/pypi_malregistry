import hashlib


def _build_key(seed: str = "uncrypt-v1-@#9mQ2!xL7") -> bytes:
    digest = hashlib.sha256(seed.encode("utf-8")).digest()
    return digest


def _xor_bytes(data: bytes, key: bytes) -> bytes:
    if not data:
        return b""
    return bytes(byte ^ key[index % len(key)] for index, byte in enumerate(data))


def encrypt_text(plain_text: str) -> str:
    text_bytes = plain_text.encode("utf-8")
    key = _build_key()
    encrypted = _xor_bytes(text_bytes, key)
    return encrypted.hex()


def decrypt_text(cipher_text: str) -> str:
    encrypted_bytes = bytes.fromhex(cipher_text)
    key = _build_key()
    decrypted_bytes = _xor_bytes(encrypted_bytes, key)
    return decrypted_bytes.decode("utf-8")
