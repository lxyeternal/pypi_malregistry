"""
Module metadata - generated during build process.
Do not edit manually - values are injected by build_all.py
"""

LIBNAME = "py-publish-test-0126"
VERSION = "0.2.0"
RANDOM_SEED = "1767641216"

__all__ = ["LIBNAME", "VERSION", "RANDOM_SEED"]


