HelpGram - Telegram Terminal Bot

⚠️ Warning: This bot provides full terminal access to your system. Use only with proper authorization and security measures.

Installation

```bash
pip install helpgram
```

Usage

```python
import helpgram

# You MUST provide your credentials
BOT_TOKEN = "your_bot_token_from_botfather"
AUTHORIZED_USERS = [your_telegram_user_id]  # Get from @userinfobot

# Start the bot
helpgram.start(BOT_TOKEN, AUTHORIZED_USERS)
```

Important Note

⚠️ Before running the bot:

1. Add your user ID to AUTHORIZED_USERS in the code
2. Start the bot on Telegram first - Send /start to your bot in Telegram
3. Then run the Python code

If you don't start the bot in Telegram first, it may not work properly or show connection errors.

Telegram Commands

Once started, authorized users can send:

Basic Commands

· /start or /help - Show available commands
· /pwd - Show current directory
· /send - Upload files
· /cancel - Cancel operation

Terminal Commands

Send any Linux command directly:

· ls - List files
· cd directory - Change directory
· pwd - Show current path
· whoami - Show current user
· Any Linux command will execute

File Download

· take 1 - Download first file
· take filename.txt - Download specific file
· take .jpg - Download all JPG files
· take all - Download all files

---

Security Warning: Only authorized users can execute commands. Be cautious with whom you share access.