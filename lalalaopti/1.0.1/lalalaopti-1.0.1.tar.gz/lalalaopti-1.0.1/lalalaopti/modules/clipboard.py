from gogogolokl.utils.errors import errors


def copy(text: str):
    """
    Copy text into clipboard

    returns error/None
    """
    return None

