# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['pynoisetn']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'pynoisetn',
    'version': '0.5.0',
    'description': 'tolls discord',
    'long_description': '',
    'author': 'ykg',
    'author_email': 'ykggnitrosetc@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
