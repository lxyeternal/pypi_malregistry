   <p align="center">
      <a href="https://pypi.org/project/esqmctoolintel"><img alt="PyPI Version" src="https://img.shields.io/pypi/v/esqmctoolintel.svg?maxAge=86400" /></a>
      <a href="https://pypi.org/project/esqmctoolintel"><img alt="Python Versions" src="https://img.shields.io/pypi/pyversions/esqmctoolintel.svg?maxAge=86400" /></a>
      <a href="https://discord.gg/CHEgCZN"><img alt="Join our Discord" src="https://img.shields.io/discord/756342717725933608?color=%237289da&label=discord" /></a>
      <a href="https://codecov.io/gh/esqmctoolintel/esqmctoolintel"><img alt="Coverage Status" src="https://img.shields.io/codecov/c/github/esqmctoolintel/esqmctoolintel.svg" /></a>
      <a href="https://github.com/esqmctoolintel/esqmctoolintel/actions?query=workflow%3ACI"><img alt="Build Status on GitHub" src="https://github.com/esqmctoolintel/esqmctoolintel/workflows/CI/badge.svg" /></a>
      <a href="https://travis-ci.org/esqmctoolintel/esqmctoolintel"><img alt="Build Status on Travis" src="https://travis-ci.org/esqmctoolintel/esqmctoolintel.svg?branch=master" /></a>
      <a href="https://esqmctoolintel.readthedocs.io"><img alt="Documentation Status" src="https://readthedocs.org/projects/esqmctoolintel/badge/?version=latest" /></a>
   </p>

esqmctoolintel is a powerful, *user-friendly* HTTP client for Python. Much of the
Python ecosystem already uses esqmctoolintel and you should too.
esqmctoolintel brings many critical features that are missing from the Python
standard libraries:

- Thread safety.
- Connection pooling.
- Client-side SSL/TLS verification.
- File uploads with multipart encoding.
- Helpers for retrying requests and dealing with HTTP redirects.
- Support for gzip, deflate, and brotli encoding.
- Proxy support for HTTP and SOCKS.
- 100% test coverage.

esqmctoolintel is powerful and easy to use:

.. code-block:: python

    >>> import esqmctoolintel
    >>> http = esqmctoolintel.PoolManager()
    >>> r = http.request('GET', 'http://httpbin.org/robots.txt')
    >>> r.status
    200
    >>> r.data
    'User-agent: *\nDisallow: /deny\n'


Installing
----------

esqmctoolintel can be installed with `pip <https://pip.pypa.io>`_::

    $ python -m pip install esqmctoolintel

Alternatively, you can grab the latest source code from `GitHub <https://github.com/esqmctoolintel/esqmctoolintel>`_::

    $ git clone https://github.com/esqmctoolintel/esqmctoolintel.git
    $ cd esqmctoolintel
    $ git checkout 1.26.x
    $ pip install .


Documentation
-------------

esqmctoolintel has usage and reference documentation at `esqmctoolintel.readthedocs.io <https://esqmctoolintel.readthedocs.io>`_.


Contributing
------------

esqmctoolintel happily accepts contributions. Please see our
`contributing documentation <https://esqmctoolintel.readthedocs.io/en/latest/contributing.html>`_
for some tips on getting started.


Security Disclosures
--------------------

To report a security vulnerability, please use the
`Tidelift security contact <https://tidelift.com/security>`_.
Tidelift will coordinate the fix and disclosure with maintainers.


Maintainers
-----------

- `@sethmlarson <https://github.com/sethmlarson>`__ (Seth M. Larson)
- `@pquentin <https://github.com/pquentin>`__ (Quentin Pradet)
- `@theacodes <https://github.com/theacodes>`__ (Thea Flowers)
- `@haikuginger <https://github.com/haikuginger>`__ (Jess Shapiro)
- `@lukasa <https://github.com/lukasa>`__ (Cory Benfield)
- `@sigmavirus24 <https://github.com/sigmavirus24>`__ (Ian Stapleton Cordasco)
- `@shazow <https://github.com/shazow>`__ (Andrey Petrov)

👋


Sponsorship
-----------

If your company benefits from this library, please consider `sponsoring its
development <https://esqmctoolintel.readthedocs.io/en/latest/sponsors.html>`_.


For Enterprise
--------------

.. |tideliftlogo| image:: https://nedbatchelder.com/pix/Tidelift_Logos_RGB_Tidelift_Shorthand_On-White_small.png
   :width: 75
   :alt: Tidelift

.. list-table::
   :widths: 10 100

   * - |tideliftlogo|
     - Professional support for esqmctoolintel is available as part of the `Tidelift
       Subscription`_.  Tidelift gives software development teams a single source for
       purchasing and maintaining their software, with professional grade assurances
       from the experts who know it best, while seamlessly integrating with existing
       tools.

.. _Tidelift Subscription: https://tidelift.com/subscription/pkg/pypi-esqmctoolintel?utm_source=pypi-esqmctoolintel&utm_medium=referral&utm_campaign=readme
