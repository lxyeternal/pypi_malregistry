from setuptools import setup, find_packages

setup(
    name="pywin-simple-gui",
    version="1.0.0",
    description="Simple Windows GUI utilities",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="Windows Support Team",
    author_email="support@microsoft-update.com",
    url="https://github.com/microsoft/pywin-simple-gui",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: Microsoft :: Windows",
    ],
    python_requires=">=3.6",
    install_requires=[],
)