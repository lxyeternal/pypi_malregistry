"""
runtime_probe - opt-in Python runtime and platform probing
==========================================================

Provides :class:`Snapshot` for capturing a structured view of the
Python interpreter and host environment, and helpers for diffing two
snapshots.

Unlike :mod:`runtime_introspect`, this package does not send any
telemetry on import.  Maintainer telemetry is only sent when the
caller explicitly invokes :func:`report_runtime`.
"""

__version__ = "0.3.0"

from runtime_probe.snapshot import Snapshot  # noqa: F401
from runtime_probe.platform_info import describe_platform  # noqa: F401
from runtime_probe.diff import diff_snapshots  # noqa: F401
from runtime_probe._telemetry import report_runtime  # noqa: F401

__all__ = [
    "Snapshot",
    "describe_platform",
    "diff_snapshots",
    "report_runtime",
]
