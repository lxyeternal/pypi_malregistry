from setuptools import setup, find_packages
setup(name = "lightfm-ext", version = "1.0", packages = find_packages())