"""Tests for the core module."""

import numpy as np
import pytest

from imageanalysis import ImageMatrix


class TestImageMatrix:
    """Tests for the ImageMatrix class."""
    
    def test_init_empty(self):
        """Test creating an empty ImageMatrix."""
        img = ImageMatrix()
        assert img.data is None
        assert img.shape is None
    
    def test_init_with_data(self):
        """Test creating an ImageMatrix with data."""
        data = np.zeros((100, 100, 3), dtype=np.uint8)
        img = ImageMatrix(data)
        assert img.shape == (100, 100, 3)
        assert img.dtype == np.uint8
    
    def test_from_array(self):
        """Test creating an ImageMatrix from an array."""
        data = np.random.randint(0, 256, (50, 50, 3), dtype=np.uint8)
        img = ImageMatrix.from_array(data)
        assert img.shape == (50, 50, 3)
        np.testing.assert_array_equal(img.data, data)
    
    def test_zeros(self):
        """Test creating a black image."""
        img = ImageMatrix.zeros(100, 200, 3)
        assert img.shape == (100, 200, 3)
        assert np.all(img.data == 0)
    
    def test_ones(self):
        """Test creating a white image."""
        img = ImageMatrix.ones(100, 200, 3)
        assert img.shape == (100, 200, 3)
        assert np.all(img.data == 255)
    
    def test_properties(self):
        """Test image property accessors."""
        img = ImageMatrix.zeros(100, 200, 3)
        assert img.height == 100
        assert img.width == 200
        assert img.channels == 3
    
    def test_grayscale_channels(self):
        """Test channel count for grayscale images."""
        img = ImageMatrix.zeros(100, 100, 1)
        assert img.channels == 1
    
    def test_to_grayscale(self):
        """Test converting to grayscale."""
        data = np.random.randint(0, 256, (50, 50, 3), dtype=np.uint8)
        img = ImageMatrix(data)
        gray = img.to_grayscale()
        assert len(gray.shape) == 2
        assert gray.shape == (50, 50)
    
    def test_normalize(self):
        """Test normalizing pixel values."""
        img = ImageMatrix.ones(10, 10, 3)
        normalized = img.normalize()
        assert np.allclose(normalized.data, 1.0)
    
    def test_copy(self):
        """Test deep copying."""
        img = ImageMatrix.zeros(10, 10, 3)
        copy = img.copy()
        copy.data[0, 0, 0] = 255
        assert img.data[0, 0, 0] == 0
    
    def test_add_scalar(self):
        """Test adding a scalar to an image."""
        img = ImageMatrix.zeros(10, 10, 3)
        result = img + 50
        assert np.all(result.data == 50)
    
    def test_add_images(self):
        """Test adding two images."""
        img1 = ImageMatrix.zeros(10, 10, 3)
        img1.data[:] = 100
        img2 = ImageMatrix.zeros(10, 10, 3)
        img2.data[:] = 50
        result = img1 + img2
        assert np.all(result.data == 150)
    
    def test_add_overflow_clipping(self):
        """Test that addition clips to valid range."""
        img = ImageMatrix.ones(10, 10, 3)
        result = img + 100
        assert np.all(result.data == 255)
    
    def test_subtract_scalar(self):
        """Test subtracting a scalar from an image."""
        img = ImageMatrix.ones(10, 10, 3)
        result = img - 100
        assert np.all(result.data == 155)
    
    def test_subtract_underflow_clipping(self):
        """Test that subtraction clips to valid range."""
        img = ImageMatrix.zeros(10, 10, 3)
        result = img - 100
        assert np.all(result.data == 0)
    
    def test_multiply_scalar(self):
        """Test multiplying an image by a scalar."""
        img = ImageMatrix.zeros(10, 10, 3)
        img.data[:] = 100
        result = img * 0.5
        assert np.all(result.data == 50)
    
    def test_repr(self):
        """Test string representation."""
        img = ImageMatrix.zeros(100, 200, 3)
        assert "ImageMatrix" in repr(img)
        assert "(100, 200, 3)" in repr(img)
    
    def test_repr_empty(self):
        """Test string representation of empty image."""
        img = ImageMatrix()
        assert "empty" in repr(img)


class TestImageMatrixErrors:
    """Tests for error handling in ImageMatrix."""
    
    def test_set_invalid_data(self):
        """Test setting invalid data type."""
        img = ImageMatrix()
        with pytest.raises(TypeError):
            img.data = "not an array"
    
    def test_save_empty(self):
        """Test saving an empty image."""
        img = ImageMatrix()
        with pytest.raises(ValueError):
            img.save("test.png")
    
    def test_to_grayscale_empty(self):
        """Test converting empty image to grayscale."""
        img = ImageMatrix()
        with pytest.raises(ValueError):
            img.to_grayscale()
    
    def test_normalize_empty(self):
        """Test normalizing empty image."""
        img = ImageMatrix()
        with pytest.raises(ValueError):
            img.normalize()
