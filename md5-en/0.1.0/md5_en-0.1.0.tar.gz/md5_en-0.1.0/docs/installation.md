# Installation

## Stable release

To install md5_en, run this command in your terminal:

```sh
uv add md5_en
```

Or if you prefer to use `pip`:

```sh
pip install md5_en
```

## From source

The source files for md5_en can be downloaded from the [Github repo](https://github.com/bashu/md5_en).

You can either clone the public repository:

```sh
git clone git://github.com/bashu/md5_en
```

Or download the [tarball](https://github.com/bashu/md5_en/tarball/master):

```sh
curl -OJL https://github.com/bashu/md5_en/tarball/master
```

Once you have a copy of the source, you can install it with:

```sh
cd md5_en
uv pip install .
```
