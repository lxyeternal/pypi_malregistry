from pydiblis.pydiblis import type_check

type_check('boolean')
