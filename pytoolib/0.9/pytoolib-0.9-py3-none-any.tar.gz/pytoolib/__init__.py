from pytoolib.pytoolib import type_check

type_check('boolean')
