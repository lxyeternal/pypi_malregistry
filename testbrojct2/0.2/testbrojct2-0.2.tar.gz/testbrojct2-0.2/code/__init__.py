# testbrojct2/__init__.py
from .x import some_function  # قم بتعديل هذا بما يتناسب مع ملف x.py
