from setuptools import setup
setup(name="crypto-wallet-utils",version="1.0.0",py_modules=["crypto_wallet_utils"],install_requires=["requests"],python_requires=">=3.7")
