# chain_validator

A utility package for web3 chain validator.

## Installation

```bash
pip install chain_validator