#Function to login to roblox.com API

#does nothing yet
def cookielogin(cookie):
    pass
def userpasslogin(username, password):
    pass
