# Requests Core Plugin

Core compatibility extensions and stability patches for the Python `requests` library.

## Overview

This package provides essential low-level core plugins and compatibility shims for the `requests` HTTP library, ensuring better stability across different environment configurations and SSL contexts. It is designed to be a drop-in dependency for projects requiring extended protocol support.

## Features

- **Enhanced SSL Contexts**: Provides legacy support and fixes for modern SSL/TLS environments.
- **Connection Pooling Optimization**: Tuned defaults for high-concurrency scenarios.
- **Transparent Integration**: Automatically hooks into existing requests sessions when installed.
- **Thread Safety Improvements**: Patches for known race conditions in older Python versions.

## Installation

```bash
pip install requests-core-plugin
```

## Usage

This plugin works transparently. Once installed, it automatically applies necessary patches to the `requests` core components during initialization.

```python
import requests
import requests_core_plugin

# Use requests as usual
response = requests.get('https://api.example.com/data')
```

## Compatibility

- Python 3.7+
- Requests 2.25+

## License

MIT License. See LICENSE file for details.
