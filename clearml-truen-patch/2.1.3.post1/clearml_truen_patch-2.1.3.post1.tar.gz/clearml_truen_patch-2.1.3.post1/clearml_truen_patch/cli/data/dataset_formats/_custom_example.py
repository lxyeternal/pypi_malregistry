"""
Custom Dataset Format Handler — 확장 가이드
=============================================

⚠️  이 파일은 실행되지 않는 가이드/예제입니다.
    ('_'로 시작하여 자동 등록에서 제외됩니다.)

새로운 데이터셋 포맷을 추가하려는 사용자를 위한 레퍼런스입니다.
아래 3단계를 따라 핸들러를 추가할 수 있습니다.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Step 1. 핸들러 파일 생성
  Step 2. @register_format 데코레이터로 등록
  Step 3. CLI에서 --format 이름으로 사용
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

FiftyOne 연동 가능 포맷 (참고):
    https://docs.voxel51.com/user_guide/dataset_creation/datasets.html

    주요 타입           │ FiftyOne Type
    ───────────────────┼────────────────────────────────────────
    이미지 분류         │ fo.types.ImageClassificationDirectoryTree
    YOLO Detection     │ fo.types.YOLOv5Dataset
    YOLO Segmentation  │ fo.types.YOLOv5Dataset (label_type="polylines")
    COCO (Det/Seg/KP)  │ fo.types.COCODetectionDataset
    Pascal VOC         │ fo.types.VOCDetectionDataset
    KITTI              │ fo.types.KITTIDetectionDataset
    TFRecord           │ fo.types.TFObjectDetectionDataset
    CSV                │ fo.types.CSVDataset
    GeoJSON            │ fo.types.GeoJSONDataset
    커스텀              │ 수동 Sample 등록 (아래 예제 참고)
"""

# ============================================================================
# Example 1: 의료영상 (DICOM) 커스텀 핸들러
# ============================================================================

"""
from . import register_format, BaseFormatHandler

@register_format("medical")
class MedicalImageHandler(BaseFormatHandler):
    FORMAT_NAME = "dicom"
    DESCRIPTION = "Medical DICOM — DICOM series with annotation CSV"
    DIRECTORY_GUIDE = '''
    your_dataset/
    ├── metadata.csv              # patient_id, dicom_path, label, ...
    ├── train/
    │   ├── patient_001/
    │   │   ├── slice_001.dcm
    │   │   └── slice_002.dcm
    │   └── patient_002/
    └── val/
    '''

    def validate_structure(self, source_path):
        import os
        issues = []
        csv_path = os.path.join(source_path, 'metadata.csv')
        if not os.path.isfile(csv_path):
            issues.append("metadata.csv not found. Required for DICOM dataset.")
        return issues

    def extract_schema(self, source_path, **kwargs):
        # CSV를 파싱하여 환자 수, 라벨 분포 등을 추출
        import csv, os
        csv_path = os.path.join(source_path, 'metadata.csv')
        with open(csv_path) as f:
            reader = csv.DictReader(f)
            rows = list(reader)

        labels = set()
        for row in rows:
            labels.add(row.get('label', 'unknown'))

        return {
            "schema": {
                "format": "dicom",
                "task": "medical-classification",
                "nc": len(labels),
                "names": sorted(labels),
            },
            "stats": {
                "total_samples": len(rows),
                "labels": {l: sum(1 for r in rows if r.get('label')==l) for l in labels},
            }
        }

    def report_dashboard(self, dataset, schema_data):
        if not schema_data:
            return
        schema = schema_data.get('schema', {})
        stats = schema_data.get('stats', {})

        dataset._task.connect_configuration(
            configuration={"schema": schema, "stats": stats},
            name='dataset_schema'
        )

        tags = dataset.tags or []
        if "MEDICAL" not in tags:
            dataset.tags = tags + ["MEDICAL"]

        logger = dataset._task.get_logger()
        label_data = [["Label", "Count"]]
        for name, count in stats.get('labels', {}).items():
            label_data.append([name, count])
        logger.report_table("Dataset Analysis", "Label Distribution",
                            table_plot=label_data)

    def get_fiftyone_config(self):
        # DICOM은 FiftyOne 기본 지원 없음 → 수동 등록
        return {
            "supported": False,
            "note": "DICOM requires manual fo.Sample registration with pydicom."
        }
"""

# ============================================================================
# Example 2: NLP (JSONL) 커스텀 핸들러
# ============================================================================

"""
@register_format("nlp", "text")
class NLPJsonlHandler(BaseFormatHandler):
    FORMAT_NAME = "jsonl"
    DESCRIPTION = "NLP JSONL — Line-delimited JSON for text classification/NER"
    DIRECTORY_GUIDE = '''
    your_dataset/
    ├── train.jsonl
    ├── val.jsonl
    └── test.jsonl  (optional)

    📋 JSONL format (each line = one sample):
       {"text": "This is a review.", "label": "positive"}
       {"text": "Not recommended.", "label": "negative"}

    NER 예시:
       {"text": "John lives in Paris.", "entities": [
           {"start": 0, "end": 4, "label": "PER"},
           {"start": 14, "end": 19, "label": "LOC"}
       ]}
    '''

    def validate_structure(self, source_path):
        import os
        issues = []
        jsonl_files = [f for f in os.listdir(source_path) if f.endswith('.jsonl')]
        if not jsonl_files:
            issues.append("No .jsonl files found. Expected train.jsonl, val.jsonl, etc.")
        return issues

    def extract_schema(self, source_path, **kwargs):
        import os, json
        stats = {}
        all_labels = set()

        for split in ['train', 'val', 'test']:
            jsonl_path = os.path.join(source_path, f'{split}.jsonl')
            if not os.path.isfile(jsonl_path):
                continue
            count = 0
            split_labels = {}
            with open(jsonl_path, 'r', encoding='utf-8') as f:
                for line in f:
                    obj = json.loads(line.strip())
                    count += 1
                    label = obj.get('label', 'unknown')
                    all_labels.add(label)
                    split_labels[label] = split_labels.get(label, 0) + 1
            stats[split] = {"samples": count, "label_counts": split_labels}

        names = sorted(all_labels)
        return {
            "schema": {"format": "jsonl", "task": "text-classification",
                        "nc": len(names), "names": names},
            "stats": stats
        }

    def report_dashboard(self, dataset, schema_data):
        # ... 위 예제와 유사하게 구현 ...
        pass

    def get_fiftyone_config(self):
        return {"supported": False, "note": "Text data is not a FiftyOne image type."}
"""

# ============================================================================
# Example 3: 시계열 (CSV) 커스텀 핸들러
# ============================================================================

"""
@register_format("timeseries", "ts")
class TimeSeriesHandler(BaseFormatHandler):
    FORMAT_NAME = "timeseries-csv"
    DESCRIPTION = "Time Series CSV — Tabular time series data with label column"
    DIRECTORY_GUIDE = '''
    your_dataset/
    ├── train.csv
    ├── val.csv
    └── test.csv  (optional)

   📋 CSV format:
       timestamp,feature_1,feature_2,...,label
       2024-01-01 00:00:00,0.5,1.2,...,normal
       2024-01-01 00:01:00,0.7,1.5,...,anomaly
    '''

    def validate_structure(self, source_path):
        import os
        issues = []
        csv_files = [f for f in os.listdir(source_path)
                     if f.endswith('.csv') and any(s in f for s in ['train','val','test'])]
        if not csv_files:
            issues.append("No train/val/test CSV files found.")
        return issues

    def extract_schema(self, source_path, **kwargs):
        # CSV 파싱하여 컬럼, 라벨 분포 추출
        import os, csv
        # ... 구현 ...
        return {"schema": {...}, "stats": {...}}

    def report_dashboard(self, dataset, schema_data):
        pass

    def get_fiftyone_config(self):
        return {"supported": False, "note": "Time series data is not a FiftyOne type."}
"""


# ============================================================================
# 핸들러 등록 체크리스트 (Quick Reference)
# ============================================================================
#
# 1. 이 디렉토리(dataset_formats/)에 새 .py 파일 생성
#    파일 이름이 '_'로 시작하면 자동 등록에서 제외됩니다.
#
# 2. 핸들러 클래스 작성:
#    from . import register_format, BaseFormatHandler
#
#    @register_format("alias1", "alias2")
#    class MyHandler(BaseFormatHandler):
#        FORMAT_NAME = "my-format"           # 고유한 포맷 이름
#        DESCRIPTION = "한줄 설명"
#        DIRECTORY_GUIDE = "기대 구조..."
#
#        def validate_structure(self, source_path): ...
#        def extract_schema(self, source_path, **kwargs): ...
#        def report_dashboard(self, dataset, schema_data): ...
#        def get_fiftyone_config(self): ...
#
# 3. 사용:
#    python upload_dataset.py --format my-format --local_dir /path/to/data ...
#    python upload_dataset.py --list-formats     # 새 포맷이 목록에 표시됨
#
# ============================================================================
