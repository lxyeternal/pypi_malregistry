import setuptools

setuptools.setup(
    name="ase-jreq",
    version="0.0.3",
    packages=setuptools.find_packages(),
    author="abss",
    description="Dont install this package, purely testing purpose",
    entry_points={
        'console_scripts': [
            'ase-jreq = http_query.http_query:main'
        ]
    },
    install_requires= [
        'click',
        'requests'
    ]
)
