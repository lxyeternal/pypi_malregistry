from setuptools import setup

setup(
    name='modularseven',
    version='1.0',
    description='modularseven',
    packages=['modularseven'],
    install_requires=[],
)
