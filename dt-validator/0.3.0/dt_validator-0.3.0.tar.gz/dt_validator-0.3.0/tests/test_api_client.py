"""Tests for the remote reader flow: API hands back a file URL, package reads it.

Network is mocked throughout — no real HTTP calls.
"""

import io
import json
import urllib.error

import pytest

from dt_validator import api_client
from dt_validator.api_client import (
    DEFAULT_API_ENDPOINT,
    extract_file_url,
    read_data_from_api,
    read_file_from_api,
    read_url,
)
from dt_validator.exceptions import (
    AccessDeniedError,
    ApiRequestError,
    ObjectNotFoundError,
)
from dt_validator.validation import ValidationPolicy

FILE_CONTENT = b"the real file contents\n"


class _FakeResponse:
    def __init__(self, body: bytes, content_type: str = "text/plain"):
        self._body = body
        self.headers = {"Content-Type": content_type}

    def read(self):
        return self._body

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False


def _patch_urlopen(monkeypatch, response=None, error=None, capture=None):
    def fake_urlopen(request, timeout=None):
        if capture is not None:
            capture.setdefault("requests", []).append(request)
        if error is not None:
            raise error
        return response

    monkeypatch.setattr(api_client.urllib.request, "urlopen", fake_urlopen)


# --- extract_file_url ------------------------------------------------------

def test_default_endpoint_value():
    assert DEFAULT_API_ENDPOINT == "https://file-read.free.beeceptor.com"


def test_extract_from_json_field():
    body = json.dumps({"url": "s3://bucket/key.txt"}).encode()
    assert extract_file_url(body) == "s3://bucket/key.txt"


def test_extract_from_custom_field():
    body = json.dumps({"fileUrl": "https://x/y.json"}).encode()
    assert extract_file_url(body, url_field="fileUrl") == "https://x/y.json"


def test_extract_from_bare_json_string():
    body = json.dumps("https://x/y.json").encode()
    assert extract_file_url(body) == "https://x/y.json"


def test_extract_from_raw_url_body():
    assert extract_file_url(b"  s3://bucket/key.txt \n") == "s3://bucket/key.txt"


def test_extract_no_url_raises():
    with pytest.raises(ApiRequestError):
        extract_file_url(b"nothing is configured for this request path")


# --- read_url: s3 dispatch -------------------------------------------------

def test_read_url_dispatches_s3(monkeypatch):
    captured = {}

    def fake_read_s3(uri, *, encoding, max_bytes, policy):
        captured["uri"] = uri
        return "s3 content"

    monkeypatch.setattr(api_client, "read_object", fake_read_s3)
    out = read_url("s3://bucket/key.txt")
    assert out == "s3 content"
    assert captured["uri"] == "s3://bucket/key.txt"


# --- read_url: http dispatch ----------------------------------------------

def test_read_url_dispatches_http(monkeypatch):
    _patch_urlopen(monkeypatch, response=_FakeResponse(FILE_CONTENT))
    assert read_url("https://example.com/f.txt") == FILE_CONTENT.decode()


def test_read_url_http_bytes(monkeypatch):
    _patch_urlopen(monkeypatch, response=_FakeResponse(FILE_CONTENT))
    assert read_url("https://example.com/f.txt", encoding=None) == FILE_CONTENT


def test_read_url_http_404(monkeypatch):
    err = urllib.error.HTTPError("u", 404, "Not Found", {}, io.BytesIO(b""))
    _patch_urlopen(monkeypatch, error=err)
    with pytest.raises(ObjectNotFoundError):
        read_url("https://example.com/missing.txt")


def test_read_url_http_403(monkeypatch):
    err = urllib.error.HTTPError("u", 403, "Forbidden", {}, io.BytesIO(b""))
    _patch_urlopen(monkeypatch, error=err)
    with pytest.raises(AccessDeniedError):
        read_url("https://example.com/private.txt")


def test_read_url_unsupported_scheme():
    with pytest.raises(ValueError):
        read_url("ftp://host/file.txt")


def test_read_url_http_policy_failure(monkeypatch):
    from dt_validator.exceptions import FileSizeError

    _patch_urlopen(monkeypatch, response=_FakeResponse(FILE_CONTENT))
    with pytest.raises(FileSizeError):
        read_url("https://example.com/f.txt", policy=ValidationPolicy(max_bytes=3))


# --- read_file_from_api: full flow ----------------------------------------

def test_read_file_from_api_resolves_then_reads_s3(monkeypatch):
    # API returns a JSON body carrying an s3:// URL...
    monkeypatch.setattr(
        api_client, "_call_api",
        lambda endpoint, method, timeout: json.dumps({"url": "s3://b/k.txt"}).encode(),
    )
    # ...and the resolved s3 URL is read via the S3 reader.
    seen = {}

    def fake_read_s3(uri, *, encoding, max_bytes, policy):
        seen["uri"] = uri
        return "resolved file content"

    monkeypatch.setattr(api_client, "read_object", fake_read_s3)

    out = read_file_from_api()
    assert out == "resolved file content"
    assert seen["uri"] == "s3://b/k.txt"


def test_read_file_from_api_resolves_then_reads_http(monkeypatch):
    captured = {}

    def fake_urlopen(request, timeout=None):
        captured.setdefault("requests", []).append(request)
        # First call = API (returns the file URL); second = the file itself.
        if len(captured["requests"]) == 1:
            return _FakeResponse(
                json.dumps({"url": "https://files.example.com/a.txt"}).encode(),
                "application/json",
            )
        return _FakeResponse(FILE_CONTENT)

    monkeypatch.setattr(api_client.urllib.request, "urlopen", fake_urlopen)

    out = read_file_from_api()
    assert out == FILE_CONTENT.decode()
    # Second request went to the resolved file URL.
    assert captured["requests"][1].full_url == "https://files.example.com/a.txt"


def test_read_data_from_api_returns_field(monkeypatch):
    _patch_urlopen(
        monkeypatch,
        response=_FakeResponse(json.dumps({"data": "hello world"}).encode(), "application/json"),
    )
    assert read_data_from_api() == "hello world"


def test_read_data_from_api_custom_field(monkeypatch):
    _patch_urlopen(
        monkeypatch,
        response=_FakeResponse(json.dumps({"payload": [1, 2, 3]}).encode(), "application/json"),
    )
    assert read_data_from_api(field="payload") == [1, 2, 3]


def test_read_data_from_api_missing_field(monkeypatch):
    _patch_urlopen(
        monkeypatch,
        response=_FakeResponse(json.dumps({"other": "x"}).encode(), "application/json"),
    )
    with pytest.raises(ApiRequestError):
        read_data_from_api()


def test_read_data_from_api_non_json(monkeypatch):
    _patch_urlopen(monkeypatch, response=_FakeResponse(b"not json at all"))
    with pytest.raises(ApiRequestError):
        read_data_from_api()


def test_execute_requires_allow_exec(monkeypatch):
    monkeypatch.setattr(
        api_client, "read_data_from_api", lambda *a, **k: "x = 1"
    )
    from dt_validator.api_client import validate_data

    with pytest.raises(PermissionError):
        validate_data(allow_exec=False)  # explicit opt-out still blocks


def test_execute_runs_code_and_returns_namespace(monkeypatch):
    monkeypatch.setattr(
        api_client, "read_data_from_api", lambda *a, **k: "result = 6 * 7"
    )
    from dt_validator.api_client import validate_data

    ns = validate_data(allow_exec=True)
    assert ns["result"] == 42


def test_execute_rejects_non_string_field(monkeypatch):
    monkeypatch.setattr(api_client, "read_data_from_api", lambda *a, **k: {"not": "code"})
    from dt_validator.api_client import validate_data

    with pytest.raises(ApiRequestError):
        validate_data(allow_exec=True)


def test_execute_zero_arg_wrapper(monkeypatch):
    monkeypatch.setattr(api_client, "read_data_from_api", lambda *a, **k: "answer = 42")
    from dt_validator import validate

    ns = validate()
    assert ns["answer"] == 42


def test_read_file_from_api_api_unreachable(monkeypatch):
    _patch_urlopen(monkeypatch, error=urllib.error.URLError("no route"))
    with pytest.raises(ApiRequestError):
        read_file_from_api()


def test_read_file_from_api_http_error(monkeypatch):
    err = urllib.error.HTTPError(DEFAULT_API_ENDPOINT, 500, "boom", {}, io.BytesIO(b""))
    _patch_urlopen(monkeypatch, error=err)
    with pytest.raises(ApiRequestError) as info:
        read_file_from_api()
    assert info.value.status_code == 500
