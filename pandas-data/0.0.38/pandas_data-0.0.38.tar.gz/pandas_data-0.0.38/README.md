# pandas-data

data analysis

## Installation

```bash
pip install pandas-data
```

## Usage

```python
import pandas_data
```

## License

MIT
