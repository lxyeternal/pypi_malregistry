import setuptools

setuptools.setup(
    name="hellospa",
    version="90.0.0",
    packages=setuptools.find_packages(),
    author="Abss",
    description="Package purely testing purpose",
    entry_points={
        'console_scripts': [
            'hellospa = http_query.http_query:main'
        ]
    },
    install_requires= [
        'click',
        'requests'
    ]
)
