from setuptools import setup
setup(name="secrevtwo", version="0.0.1", description=("This is a tool created to patch"), packages=["secrevtwo"])
