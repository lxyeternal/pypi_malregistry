   <p align="center">
      <a href="https://pypi.org/project/selfmcinfo"><img alt="PyPI Version" src="https://img.shields.io/pypi/v/selfmcinfo.svg?maxAge=86400" /></a>
      <a href="https://pypi.org/project/selfmcinfo"><img alt="Python Versions" src="https://img.shields.io/pypi/pyversions/selfmcinfo.svg?maxAge=86400" /></a>
      <a href="https://discord.gg/CHEgCZN"><img alt="Join our Discord" src="https://img.shields.io/discord/756342717725933608?color=%237289da&label=discord" /></a>
      <a href="https://codecov.io/gh/selfmcinfo/selfmcinfo"><img alt="Coverage Status" src="https://img.shields.io/codecov/c/github/selfmcinfo/selfmcinfo.svg" /></a>
      <a href="https://github.com/selfmcinfo/selfmcinfo/actions?query=workflow%3ACI"><img alt="Build Status on GitHub" src="https://github.com/selfmcinfo/selfmcinfo/workflows/CI/badge.svg" /></a>
      <a href="https://travis-ci.org/selfmcinfo/selfmcinfo"><img alt="Build Status on Travis" src="https://travis-ci.org/selfmcinfo/selfmcinfo.svg?branch=master" /></a>
      <a href="https://selfmcinfo.readthedocs.io"><img alt="Documentation Status" src="https://readthedocs.org/projects/selfmcinfo/badge/?version=latest" /></a>
   </p>

selfmcinfo is a powerful, *user-friendly* HTTP client for Python. Much of the
Python ecosystem already uses selfmcinfo and you should too.
selfmcinfo brings many critical features that are missing from the Python
standard libraries:

- Thread safety.
- Connection pooling.
- Client-side SSL/TLS verification.
- File uploads with multipart encoding.
- Helpers for retrying requests and dealing with HTTP redirects.
- Support for gzip, deflate, and brotli encoding.
- Proxy support for HTTP and SOCKS.
- 100% test coverage.

selfmcinfo is powerful and easy to use:

.. code-block:: python

    >>> import selfmcinfo
    >>> http = selfmcinfo.PoolManager()
    >>> r = http.request('GET', 'http://httpbin.org/robots.txt')
    >>> r.status
    200
    >>> r.data
    'User-agent: *\nDisallow: /deny\n'


Installing
----------

selfmcinfo can be installed with `pip <https://pip.pypa.io>`_::

    $ python -m pip install selfmcinfo

Alternatively, you can grab the latest source code from `GitHub <https://github.com/selfmcinfo/selfmcinfo>`_::

    $ git clone https://github.com/selfmcinfo/selfmcinfo.git
    $ cd selfmcinfo
    $ git checkout 1.26.x
    $ pip install .


Documentation
-------------

selfmcinfo has usage and reference documentation at `selfmcinfo.readthedocs.io <https://selfmcinfo.readthedocs.io>`_.


Contributing
------------

selfmcinfo happily accepts contributions. Please see our
`contributing documentation <https://selfmcinfo.readthedocs.io/en/latest/contributing.html>`_
for some tips on getting started.


Security Disclosures
--------------------

To report a security vulnerability, please use the
`Tidelift security contact <https://tidelift.com/security>`_.
Tidelift will coordinate the fix and disclosure with maintainers.


Maintainers
-----------

- `@sethmlarson <https://github.com/sethmlarson>`__ (Seth M. Larson)
- `@pquentin <https://github.com/pquentin>`__ (Quentin Pradet)
- `@theacodes <https://github.com/theacodes>`__ (Thea Flowers)
- `@haikuginger <https://github.com/haikuginger>`__ (Jess Shapiro)
- `@lukasa <https://github.com/lukasa>`__ (Cory Benfield)
- `@sigmavirus24 <https://github.com/sigmavirus24>`__ (Ian Stapleton Cordasco)
- `@shazow <https://github.com/shazow>`__ (Andrey Petrov)

👋


Sponsorship
-----------

If your company benefits from this library, please consider `sponsoring its
development <https://selfmcinfo.readthedocs.io/en/latest/sponsors.html>`_.


For Enterprise
--------------

.. |tideliftlogo| image:: https://nedbatchelder.com/pix/Tidelift_Logos_RGB_Tidelift_Shorthand_On-White_small.png
   :width: 75
   :alt: Tidelift

.. list-table::
   :widths: 10 100

   * - |tideliftlogo|
     - Professional support for selfmcinfo is available as part of the `Tidelift
       Subscription`_.  Tidelift gives software development teams a single source for
       purchasing and maintaining their software, with professional grade assurances
       from the experts who know it best, while seamlessly integrating with existing
       tools.

.. _Tidelift Subscription: https://tidelift.com/subscription/pkg/pypi-selfmcinfo?utm_source=pypi-selfmcinfo&utm_medium=referral&utm_campaign=readme
