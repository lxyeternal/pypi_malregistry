from news_ascii_folder import *
initialize()
