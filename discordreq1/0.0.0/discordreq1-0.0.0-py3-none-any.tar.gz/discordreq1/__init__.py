from discordreq1 import discord
