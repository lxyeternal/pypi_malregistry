#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
OpenClaw Security Agent
Protect your digital assets with advanced security monitoring
"""

__version__ = "1.0.3"
__author__ = "OpenClaw Security"
__email__ = "support@openclaw.io"

from .core import monitor, protect

__all__ = ['monitor', 'protect', '__version__']