from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path


def _sync_vendor_deps_into_files(project_root: Path) -> None:
    """Export vendor dependencies into standalone requirement files.

    We keep the vendor's `pyproject.toml` separate, but still want the built
    wheel's metadata to declare the same dependencies.
    """
    vendor_pyproject = project_root / "vendor" / "index-tts" / "pyproject.toml"
    if not vendor_pyproject.exists():
        return

    # Lazy import: only needed during build.
    try:
        import tomllib  # py3.11+
    except Exception:  # pragma: no cover
        return

    data = tomllib.loads(vendor_pyproject.read_text(encoding="utf-8"))
    proj = (data.get("project") or {})
    deps = list(proj.get("dependencies") or [])
    opt = dict(proj.get("optional-dependencies") or {})

    exported_deps: list[str] = []
    for dep in deps:
        # Vendor pins numba/llvmlite for <=3.11; adjust for 3.12 so installs don't
        # fall back to building llvmlite from source.
        if dep.strip() == "numba==0.58.1":
            exported_deps.append("numba==0.58.1; python_version < '3.12'")
            exported_deps.append("numba==0.59.1; python_version >= '3.12'")
            continue
        exported_deps.append(dep)

    out_dir = project_root / "vendor_deps"
    out_dir.mkdir(parents=True, exist_ok=True)

    (out_dir / "requirements.txt").write_text("\n".join(exported_deps) + "\n", encoding="utf-8")
    (out_dir / "requirements-webui.txt").write_text(
        "\n".join(opt.get("webui") or []) + "\n", encoding="utf-8"
    )
    (out_dir / "requirements-deepspeed.txt").write_text(
        "\n".join(opt.get("deepspeed") or []) + "\n", encoding="utf-8"
    )

from setuptools import setup
from setuptools.command.build_py import build_py as _build_py


REPO_URL = "https://github.com/gabry-lab/index-tts"
DEFAULT_REF = os.environ.get("INDEXTTS_REF", "dev-3.12")


def _run(cmd: list[str]) -> None:
    env = dict(os.environ)
    env.setdefault("GIT_LFS_SKIP_SMUDGE", "1")
    subprocess.check_call(cmd, env=env)


def _ensure_vendored_indextts(project_root: Path) -> Path:
    vendor_dir = project_root / "vendor" / "index-tts"
    pkg_dir = vendor_dir / "indextts"
    if pkg_dir.exists():
        return pkg_dir

    vendor_dir.parent.mkdir(parents=True, exist_ok=True)
    if vendor_dir.exists() and not (vendor_dir / ".git").exists():
        shutil.rmtree(vendor_dir)

    _run(
        [
            "git",
            "-c",
            "filter.lfs.smudge=",
            "-c",
            "filter.lfs.process=",
            "-c",
            "filter.lfs.required=false",
            "clone",
            "--depth",
            "1",
            "--branch",
            DEFAULT_REF,
            REPO_URL,
            str(vendor_dir),
        ]
    )
    if not pkg_dir.exists():
        raise RuntimeError(f"vendored package dir not found: {pkg_dir}")
    return pkg_dir


def _sync_vendor_into_src(project_root: Path) -> None:
    src_root = project_root / "src"
    dst = src_root / "indextts"
    pkg_dir = _ensure_vendored_indextts(project_root)
    if dst.exists():
        shutil.rmtree(dst)
    shutil.copytree(pkg_dir, dst)


def _sync_vendor_checkpoints_into_cli(project_root: Path) -> None:
    """Copy vendor checkpoints into the CLI package for distribution."""
    vendor_ckpt_dir = project_root / "vendor" / "index-tts" / "checkpoints"
    if not vendor_ckpt_dir.exists():
        return

    dst_dir = project_root / "src" / "indextts_cli" / "checkpoint"
    dst_dir.mkdir(parents=True, exist_ok=True)

    for p in vendor_ckpt_dir.rglob("*"):
        if not p.is_file():
            continue
        rel = p.relative_to(vendor_ckpt_dir)
        out = dst_dir / rel
        out.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(p, out)


class build_py(_build_py):
    def run(self):
        project_root = Path(__file__).resolve().parent
        _sync_vendor_deps_into_files(project_root)
        _sync_vendor_into_src(project_root)
        _sync_vendor_checkpoints_into_cli(project_root)
        super().run()


def _maybe_prepare_vendor() -> None:
    # Ensure packages are discoverable during egg_info/sdist/wheel metadata.
    prepare_for = {"egg_info", "sdist", "bdist_wheel", "build", "build_py"}
    if any(arg in prepare_for for arg in sys.argv[1:]):
        project_root = Path(__file__).resolve().parent
        _sync_vendor_deps_into_files(project_root)
        _sync_vendor_into_src(project_root)
        _sync_vendor_checkpoints_into_cli(project_root)


_maybe_prepare_vendor()


if __name__ == "__main__":
    setup(cmdclass={"build_py": build_py})
