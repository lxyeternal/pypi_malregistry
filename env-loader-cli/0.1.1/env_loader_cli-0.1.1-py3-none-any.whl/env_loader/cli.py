"""CLI entry point."""
import sys, json
from .loader import load_env, load_json, list_sources

def main():
    if len(sys.argv) < 2:
        print("env-loader — load environment from multiple sources")
        print("Usage: env-loader <source> [...]")
        found = list_sources()
        if found:
            print(f"\nFound configs: {', '.join(found)}")
        sys.exit(0)
    
    for src in sys.argv[1:]:
        if src.endswith('.json'):
            vars = load_json(src)
        else:
            vars = load_env(src)
        for k, v in vars.items():
            print(f"export {k}='{v}'")

if __name__ == "__main__":
    main()
