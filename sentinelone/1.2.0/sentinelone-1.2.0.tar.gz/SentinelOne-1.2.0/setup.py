from setuptools import setup, find_packages

package_version = '1.2.0'

setup(
    name='SentinelOne',
    version='1.2.0',
    license='SentinelOne'
)

