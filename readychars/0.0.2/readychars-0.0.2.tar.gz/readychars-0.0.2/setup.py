from setuptools import setup

setup(
    name='readychars',
    version='0.0.2',
    packages=['readychars'],
    url='',
    license='',
    author='dark',
    author_email='email@example.com',
    description='email@example.com'
)