from setuptools import setup, find_packages

setup(
    name="ethereum_input_decorder",  # CHANGE THIS: Must be unique on PyPI!
    version="1.2.2",
    author="Your Name",
    author_email="your.email@example.com",
    description="A module that prints Hello World on import",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),           
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.7",
)
