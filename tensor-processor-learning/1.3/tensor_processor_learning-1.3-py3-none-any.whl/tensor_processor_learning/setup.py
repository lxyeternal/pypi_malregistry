from setuptools import setup

setup(
    name='tensor_processor_learning',
    version='1.0',
    description='My module',
    packages=['tensor_processor_learning'],
    install_requires=[],
)
