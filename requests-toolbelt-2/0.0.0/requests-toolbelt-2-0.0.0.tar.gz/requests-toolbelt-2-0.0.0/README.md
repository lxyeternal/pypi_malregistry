# Don't use, this is an example for a presentation on typosquatting

## But look how popular I am!