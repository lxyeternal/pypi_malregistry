from setuptools import setup

setup(
    name="ascii2text",
    version='2.4',
    license='Eclipse Public License 2.0',
    authors=["joe140"],
    author_email="<joeyn@gmail.com>",
    description="lets you convert text to ascci banners",
    long_description='lets you convert text to ascci banners',
    keywords=['cli', 'better', 'colors', 'terminal', 'tui', 'ascci'],
    packages=['ascii2text']
)
