This is a very simple calculator that takes two numbers and either add, subtract, multiply or divide them.
