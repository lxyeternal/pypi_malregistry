"""Exception hierarchy for dt-validator.

All errors raised by this package derive from :class:`FileValidatorError`, so
callers can catch everything with a single ``except`` while still being able to
distinguish specific failure modes.
"""

from __future__ import annotations

from typing import Optional


class FileValidatorError(Exception):
    """Base class for every error raised by this package."""


class InvalidUriError(FileValidatorError, ValueError):
    """The supplied reference is not a valid ``s3://`` URI or S3 HTTPS URL.

    Subclasses :class:`ValueError` for backwards compatibility with callers that
    catch ``ValueError`` from :func:`dt_validator.reader.parse_uri`.
    """


class ObjectNotFoundError(FileValidatorError):
    """The requested S3 object does not exist (HTTP 404 / NoSuchKey)."""

    def __init__(self, bucket: str, key: str):
        self.bucket = bucket
        self.key = key
        super().__init__(f"Object not found: s3://{bucket}/{key}")


class AccessDeniedError(FileValidatorError):
    """Anonymous access was denied (HTTP 403). The object is likely not public."""

    def __init__(self, bucket: str, key: str):
        self.bucket = bucket
        self.key = key
        super().__init__(
            f"Access denied for s3://{bucket}/{key}. "
            "The object is not publicly readable (anonymous GetObject was refused)."
        )


class RemoteReadError(FileValidatorError):
    """A network- or service-level error occurred while talking to S3."""


class ApiRequestError(FileValidatorError):
    """The remote reader API could not be reached or returned an error."""

    def __init__(self, message: str, status_code: Optional[int] = None):
        self.status_code = status_code
        super().__init__(message)


class ValidationError(FileValidatorError):
    """Base class for all pre-/post-read validation failures."""


class FileSizeError(ValidationError):
    """The object's size falls outside the permitted bounds."""

    def __init__(
        self,
        size: int,
        *,
        max_bytes: Optional[int] = None,
        min_bytes: Optional[int] = None,
    ):
        self.size = size
        self.max_bytes = max_bytes
        self.min_bytes = min_bytes
        if max_bytes is not None and size > max_bytes:
            msg = f"Object is {size} bytes, exceeding the maximum of {max_bytes} bytes."
        elif min_bytes is not None and size < min_bytes:
            msg = f"Object is {size} bytes, below the minimum of {min_bytes} bytes."
        else:
            msg = f"Object size {size} bytes failed validation."
        super().__init__(msg)


class ExtensionError(ValidationError):
    """The object key does not have one of the allowed file extensions."""

    def __init__(self, key: str, allowed):
        self.key = key
        self.allowed = tuple(allowed)
        super().__init__(
            f"Key {key!r} does not end with an allowed extension: "
            f"{', '.join(self.allowed)}"
        )


class ContentTypeError(ValidationError):
    """The object's Content-Type is not among the allowed media types."""

    def __init__(self, content_type: Optional[str], allowed):
        self.content_type = content_type
        self.allowed = tuple(allowed)
        super().__init__(
            f"Content-Type {content_type!r} is not allowed. "
            f"Expected one of: {', '.join(self.allowed)}"
        )


class EncodingError(ValidationError):
    """The object's bytes could not be decoded with the expected text encoding."""

    def __init__(self, encoding: str, detail: str = ""):
        self.encoding = encoding
        suffix = f" ({detail})" if detail else ""
        super().__init__(f"Content is not valid {encoding}{suffix}.")


class ChecksumError(ValidationError):
    """The object's content did not match the expected checksum."""

    def __init__(self, algorithm: str, expected: str, actual: str):
        self.algorithm = algorithm
        self.expected = expected
        self.actual = actual
        super().__init__(
            f"{algorithm} checksum mismatch: expected {expected}, got {actual}."
        )
