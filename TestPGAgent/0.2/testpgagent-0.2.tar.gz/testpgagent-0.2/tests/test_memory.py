import pytest
from typing import Generator
from unittest.mock import MagicMock, patch
from pg_agent.memory.short_term import ShortTermMemory, Message

@pytest.fixture
def mock_genai_client() -> Generator[MagicMock, None, None]:
    with patch('google.genai.Client') as mock:
        client = mock.return_value
        # Mock count_tokens
        client.models.count_tokens.return_value = MagicMock(total_tokens=10)
        # Mock generate_content
        client.models.generate_content.return_value = MagicMock(text="This is a summary.")
        yield client

def test_memory_add_and_recent(mock_genai_client: MagicMock) -> None:
    memory = ShortTermMemory(api_key="test", session_id="session1", buffer_limit=5)
    
    msg1 = Message(role="user", content="Hello")
    memory.add(msg1)
    
    recent = memory.get_recent(1)
    assert len(recent) == 1
    assert recent[0].content == "Hello"
    assert recent[0].metadata["token_count"] == 10

def test_memory_buffer_limit(mock_genai_client: MagicMock) -> None:
    # Set low buffer limit to test truncation
    memory = ShortTermMemory(api_key="test", session_id="session2", buffer_limit=2)
    
    memory.add(Message(role="user", content="Msg 1"))
    memory.add(Message(role="assistant", content="Msg 2"))
    memory.add(Message(role="user", content="Msg 3"))
    
    recent = memory.get_recent(10)
    assert len(recent) == 2
    assert recent[0].content == "Msg 2"
    assert recent[1].content == "Msg 3"

def test_memory_summarization_trigger(mock_genai_client: MagicMock) -> None:
    # Every 10 messages trigger summary
    memory = ShortTermMemory(api_key="test", session_id="session3", buffer_limit=20)
    
    for i in range(10):
        memory.add(Message(role="user", content=f"Msg {i}"))
        
    assert mock_genai_client.models.generate_content.called
    assert memory._get_summary() == "This is a summary."

def test_memory_context_window(mock_genai_client: MagicMock) -> None:
    memory = ShortTermMemory(api_key="test", session_id="session4", buffer_limit=5)
    memory._set_summary("Old context.")
    memory.add(Message(role="user", content="New info"))
    
    ctx = memory.get_context_window(token_limit=100)
    assert "Old context." in ctx
    assert "user: New info" in ctx

def test_memory_clear(mock_genai_client: MagicMock) -> None:
    memory = ShortTermMemory(api_key="test", session_id="session5")
    memory.add(Message(role="user", content="To be cleared"))
    memory.clear()
    
    assert len(memory.get_recent(10)) == 0
    assert memory._get_summary() == ""
