from rich.console import Console
from rich.table import Table
from ..models.stats import StatsManager
from .helpers import clear_screen
from .banner import show_banner

console = Console()

def show_stats():
    clear_screen()
    show_banner()
    stats = StatsManager().get()
    stats_table = Table(title="[bold cyan]THỐNG KÊ PHÂN LOẠI[/bold cyan]")
    stats_table.add_column("Loại", style="bold yellow")
    stats_table.add_column("Số lượng", style="bold green")
    stats_table.add_row("✅ ALIVE (có cookie)", str(stats.alive_count))
    stats_table.add_row("⚠️ 2FA", str(stats.twofa_count))
    stats_table.add_row("📧 UNVERIFIED_EMAIL", str(stats.unverified_email_count))
    stats_table.add_row("📱 UNVERIFIED_PHONE", str(stats.unverified_phone_count))
    stats_table.add_row("💀 DIE", str(stats.die_count))
    stats_table.add_row("🔄 TEMP_BLOCK", str(stats.temp_block_count))
    stats_table.add_row("🚫 LOCKED / ACCOUNT_DISABLED", str(stats.temp_block_count))
    stats_table.add_row("❓ UNKNOWN/ERROR", str(stats.unknown_count))
    stats_table.add_row("📦 Tổng OK (có pass)", str(len(stats.oks)))
    stats_table.add_row("🚫 Tổng CP", str(len(stats.cps)))
    console.print(stats_table)
    input("\n[cyan]Nhấn Enter để quay lại...[/cyan]")