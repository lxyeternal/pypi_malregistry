from setuptools import setup, find_packages
setup(name = "ros2-demo-py", version = "1.2", packages = find_packages())