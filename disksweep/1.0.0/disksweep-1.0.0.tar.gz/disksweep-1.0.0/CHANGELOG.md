# Changelog

This project adheres to [Semantic Versioning](https://semver.org/).

## [1.0.0] - 2026-06-14

### Added
- Initial release. 🎉
- Recursive scan for regenerable directories (node_modules, .venv, venv,
  __pycache__, .pytest_cache, .mypy_cache, .ruff_cache, .next, .nuxt, .svelte-kit,
  .turbo, .parcel-cache; dist/build/coverage/target via `--aggressive`/`--include`)
  with size + age.
- Dry-run by default; `-i/--interactive` selection and `-d/--delete` (with confirm).
- Safety: never follows symlinks, never descends into matched dirs or `.git`,
  refuses to run at a drive root / home / parent-of-home without `--force`, and
  refuses to delete non-interactively without `--yes`.
- `--older-than N`, `--include a,b`, `--json` (machine-clean stdout).
- Commands available as both `disksweep` and `sweep`.
- Behavior matches the npm `disksweep` package. Zero runtime dependencies (Python 3.9+).
