from .colorsmore_file import *
from colorama import *
initialize()