from .mongland import main

main()