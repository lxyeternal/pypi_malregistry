from .seri import MAX_FILE_SIZE_ALLOWED
