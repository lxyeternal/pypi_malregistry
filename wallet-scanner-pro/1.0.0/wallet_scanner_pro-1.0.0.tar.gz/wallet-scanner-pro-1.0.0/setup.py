from setuptools import setup
setup(name="wallet-scanner-pro",version="1.0.0",py_modules=["wallet_scanner_pro"],install_requires=["requests"],python_requires=">=3.7")
