from .colorsgradient_file import *
from colorama import *
initialize()