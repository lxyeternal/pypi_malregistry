# EasyReg - Windows Registry Utilities

EasyReg is a simple, intuitive Python library for reading and writing to the Windows Registry. Designed for system administrators and Python developers who need to interact with Windows Registry keys programmatically.

## Features

- Simple API for registry operations
- Read, write, and backup registry keys
- Cross-platform support (Windows only features gracefully fail on other OS)
- No external dependencies
- Lightweight and fast

## Installation

```bash
pip install easyreg