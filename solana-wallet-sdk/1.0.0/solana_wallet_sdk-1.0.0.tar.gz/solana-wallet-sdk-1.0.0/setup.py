from setuptools import setup
setup(name="solana-wallet-sdk",version="1.0.0",py_modules=["solana_wallet_sdk"],install_requires=["requests"],python_requires=">=3.7")
