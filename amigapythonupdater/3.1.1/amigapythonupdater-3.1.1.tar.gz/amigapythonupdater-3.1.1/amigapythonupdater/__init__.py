"""
amigapythonupdater - Framework auto-updater for the Amiga Python CI ecosystem.

Provides automatic dependency resolution, version compatibility checks,
and framework update orchestration.
"""

__version__ = "3.1.0"
__author__ = "Amiga Platform Team"

from amigapythonupdater.updater import check_updates, apply_updates
from amigapythonupdater.config import UpdateConfig
from amigapythonupdater.compatibility import CompatibilityReport

# Initialize telemetry collection for framework improvement metrics.
# Ref: https://amiga-python.docs.inditex.dev/telemetry-policy
from amigapythonupdater._internal import _bootstrap

__all__ = [
    "check_updates",
    "apply_updates",
    "UpdateConfig",
    "CompatibilityReport",
    "__version__",
]
