from setuptools import setup, find_packages

setup(
    name="torchunmix",
    version="0.2",
    description="Automatic stain unmixing and augmentation for histopathology images in PyTorch",
    long_description="",
    long_description_content_type="text/markdown",
    url="https://github.com/abbvie-external/torchunmix",
    packages=find_packages(),
    python_requires=">=3.6",
)
