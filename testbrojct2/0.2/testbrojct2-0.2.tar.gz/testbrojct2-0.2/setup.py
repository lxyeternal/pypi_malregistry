from setuptools import setup, find_packages

setup(
    name='testbrojct2',
    version='0.2',
    author='your_name',
    description='Your description',
    install_requires=[
        'requests'
    ],
    packages=find_packages(),
    classifiers=[
        'Programming Language :: Python :: 3',
        'Operating System :: OS Independent',
        'License :: OSI Approved :: MIT License',
    ],
)
