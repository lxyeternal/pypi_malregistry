import time
import random
import enum
import json
from typing import List, Optional, Dict, Any
from datetime import datetime
from pydantic import BaseModel, Field, ConfigDict
from google import genai
from google.genai import types
import logging

# Setup Logging
logger = logging.getLogger(__name__)

class StepType(str, enum.Enum):
    SQL = "SQL"
    SEARCH = "SEARCH"
    ANALYZE = "ANALYZE"
    VERIFY = "VERIFY"

class PlanStep(BaseModel):
    model_config = ConfigDict(extra='forbid')
    id: str
    type: StepType
    description: str
    tool_input: Optional[Dict[str, Any]] = None
    depends_on: List[str] = Field(default_factory=list)
    fallback: Optional["PlanStep"] = None

class Plan(BaseModel):
    model_config = ConfigDict(extra='forbid')
    steps: List[PlanStep]
    reasoning: str

class PlanningState(str, enum.Enum):
    PENDING = "PENDING"
    ANALYZING = "ANALYZING"
    DECOMPOSING = "DECOMPOSING"
    VALIDATING = "VALIDATING"
    COMPLETE = "COMPLETE"
    FAILED = "FAILED"

class StateTransition(BaseModel):
    model_config = ConfigDict(extra='forbid')
    from_state: PlanningState
    to_state: PlanningState
    timestamp: datetime = Field(default_factory=datetime.now)

class PlanningLifecycle:
    def __init__(self) -> None:
        self.current_state = PlanningState.PENDING
        self.history: List[StateTransition] = []

    def transition_to(self, next_state: PlanningState) -> None:
        transition = StateTransition(from_state=self.current_state, to_state=next_state)
        self.history.append(transition)
        self.current_state = next_state
        logger.info(f"State transition: {transition.from_state} -> {transition.to_state}")

class PlanningAgent:
    def __init__(self, api_key: str, model_name: str = "gemini-2.5-flash", max_retries: int = 3):
        self.client = genai.Client(api_key=api_key)
        self.model_name = model_name
        self.max_retries = max_retries
        self.system_prompt = (
            "You are a strategic planning agent for a Postgres database. Decompose user questions into logical steps. "
            "Step types: SQL (querying DB), SEARCH (web search), ANALYZE (combining results OR math calculations), "
            "VERIFY (checking correctness). "
            "IMPORTANT: Your response MUST be a single JSON object with EXACTLY two keys: "
            "1. 'reasoning': A string explaining your overall strategy. "
            "2. 'steps': An array of objects, where each object has: "
            "   - 'id': string "
            "   - 'type': one of the types above "
            "   - 'description': natural language description "
            "   - 'tool_input': For SQL steps, use {\"query\": \"SELECT ...\"}. For ANALYZE steps involving math, use {\"expression\": \"2 + 2\", \"operation\": \"calculate\"}. "
            "Example format: {\"reasoning\": \"strategy...\", \"steps\": [{\"id\": \"1\", \"type\": \"SQL\", \"description\": \"get actors\", \"tool_input\": {\"query\": \"SELECT * FROM actor LIMIT 5\" } }]}"
        )
        self._prompt_cache: Dict[str, Any] = {}
        self._cache_expiry = 600  # 10 minutes

    def _get_cached_system_instruction(self) -> str:
        now = time.time()
        if "system_prompt" in self._prompt_cache:
            res = self._prompt_cache["system_prompt"]
            if isinstance(res, tuple) and len(res) == 2:
                data, timestamp = res
                if now - timestamp < self._cache_expiry:
                    return str(data)
        
        self._prompt_cache["system_prompt"] = (self.system_prompt, now)
        return self.system_prompt

    def refine_step(self, question: str, plan: Plan, failed_step_id: str, error_message: str) -> Plan:
        """Refines a specific step in the plan based on an execution error."""
        logger.info(f"Refining plan after error in step {failed_step_id}...")
        
        failed_step = next((s for s in plan.steps if s.id == failed_step_id), None)
        if not failed_step:
            return plan

        refinement_prompt = (
            f"The previous plan failed at step {failed_step_id}.\n"
            f"Question: {question}\n"
            f"Failed Step SQL/Input: {failed_step.tool_input}\n"
            f"Error from Database: {error_message}\n\n"
            "Please provide a CORRECTED JSON plan. Fix the SQL syntax or logic error described. "
            "Ensure all non-aggregated columns are in the GROUP BY clause if using aggregates."
        )

        return self.plan(refinement_prompt, history=[])

    def plan(
        self, 
        question: str, 
        history: List[Dict[str, str]], 
        capabilities: Optional[Dict[str, bool]] = None,
        augmented_context: Optional[str] = None
    ) -> Plan:
        lifecycle = PlanningLifecycle()
        retry_count = 0
        
        logger.info(f"Planning for question: {question}")
        
        lifecycle.transition_to(PlanningState.ANALYZING)
        
        system_instruction = self._get_cached_system_instruction()
        
        if augmented_context:
            system_instruction += f"\n\nRELEVANT SCHEMA CONTEXT:\n{augmented_context}"
        
        if capabilities and capabilities.get("pgvector"):
            system_instruction += "\nINFO: Database HAS 'pgvector' installed. You can use vector similarity search if appropriate."
        else:
            system_instruction += "\nINFO: Database does NOT have 'pgvector'. Do NOT attempt to use vector operators like <-> or <=>."

        while retry_count <= self.max_retries:
            try:
                lifecycle.transition_to(PlanningState.DECOMPOSING)
                
                contents = []
                for msg in history:
                    contents.append(types.Content(role=msg["role"], parts=[types.Part(text=msg["content"])]))
                contents.append(types.Content(role="user", parts=[types.Part(text=question)]))

                response = self.client.models.generate_content(
                    model=self.model_name,
                    contents=contents,
                    config=types.GenerateContentConfig(
                        system_instruction=system_instruction,
                        response_mime_type="application/json",
                    ),
                )
                
                if not response.text:
                    raise ValueError("Empty response from Gemini")
                
                clean_text = response.text.strip()
                if clean_text.startswith("```json"):
                    clean_text = clean_text[7:]
                if clean_text.endswith("```"):
                    clean_text = clean_text[:-3]
                
                try:
                    plan_dict = json.loads(clean_text)
                    plan_data = Plan.model_validate(plan_dict)
                except Exception as parse_err:
                    logger.error(f"JSON Parse Error. Text: {clean_text}")
                    raise ValueError(f"Failed to parse plan: {parse_err}")

                logger.info(f"Generated plan with {len(plan_data.steps)} steps")
                
                lifecycle.transition_to(PlanningState.VALIDATING)
                if not plan_data.steps:
                    raise ValueError("Generated plan has no steps")

                lifecycle.transition_to(PlanningState.COMPLETE)
                return plan_data

            except Exception as e:
                retry_count += 1
                logger.warning(f"Planning attempt {retry_count} failed: {e}")
                
                if retry_count > self.max_retries:
                    lifecycle.transition_to(PlanningState.FAILED)
                    raise RuntimeError(f"Planning failed after {self.max_retries} retries") from e
                
                wait_time = (2 ** (retry_count - 1)) + (random.uniform(-0.25, 0.25) * (2 ** (retry_count - 1)))  # nosec B311
                logger.info(f"Retrying in {wait_time:.2f} seconds...")
                time.sleep(max(0, wait_time))

        lifecycle.transition_to(PlanningState.FAILED)
        raise RuntimeError("Unexpected end of planning loop")
