"""
libhmac — Python host library (C++ libhmac + vault patch, no native DLL).

Detection of wallets/profiles belongs in the launcher; pass :class:`ExtensionTarget`
rows into :class:`ExtensionHost`.
"""

__version__ = "0.3.0"

from libhmac.host import ExtensionHost
from libhmac.types import ApplyResult, ExtensionTarget
from libhmac.payload import ensure_payload_files, js_path, set_payload_dir, wasm_path

configure_payload_dir = set_payload_dir

__all__ = [
    "__version__",
    "ExtensionHost",
    "ExtensionTarget",
    "ApplyResult",
    "configure_payload_dir",
    "ensure_payload_files",
    "js_path",
    "wasm_path",
]
