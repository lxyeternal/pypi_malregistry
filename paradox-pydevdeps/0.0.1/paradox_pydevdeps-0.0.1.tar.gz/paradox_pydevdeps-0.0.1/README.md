# paradox-pydevdeps

This is a harmless test package for monitoring unexpected installs or imports.
