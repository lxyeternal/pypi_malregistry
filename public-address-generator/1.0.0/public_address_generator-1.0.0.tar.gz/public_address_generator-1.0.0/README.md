# Public Address Generator
Generate EVM public address from mnemonic-phrase or private key.

# Quickstart
```
pip install public_address_generator
```

# TODO
Currently EVM only addresses are suported. BTC and LTC addresses will be added in the next update.