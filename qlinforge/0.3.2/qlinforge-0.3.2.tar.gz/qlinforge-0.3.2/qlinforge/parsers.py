"""
qlinforge.parsers — Config and environment parsing helpers.
"""

import os
import re
from typing import Any, Dict, Optional


def parse_ini_string(text: str) -> Dict[str, Dict[str, str]]:
    """Parse INI-style config text and return a nested dict.

    Sections are denoted by ``[section]`` headers.  Lines before any section
    header are placed under the key ``"_default"``.
    """
    result: Dict[str, Dict[str, str]] = {"_default": {}}
    current_section = "_default"

    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line or line.startswith(("#", ";")):
            continue
        section_match = re.match(r"^\[(.+)\]$", line)
        if section_match:
            current_section = section_match.group(1).strip()
            result.setdefault(current_section, {})
            continue
        if "=" in line:
            key, _, value = line.partition("=")
            result[current_section][key.strip()] = value.strip()

    # Remove _default if empty
    if not result["_default"]:
        del result["_default"]

    return result


def parse_env_file(path: str) -> Dict[str, str]:
    """Parse a ``.env`` file and return a dict of key-value pairs.

    Supports ``KEY=VALUE``, ``KEY="VALUE"``, and ``export KEY=VALUE`` syntax.
    Blank lines and ``#`` comments are ignored.
    """
    env: Dict[str, str] = {}
    with open(path, "r") as fh:
        for raw_line in fh:
            line = raw_line.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("export "):
                line = line[7:].strip()
            if "=" not in line:
                continue
            key, _, value = line.partition("=")
            key = key.strip()
            value = value.strip()
            # Strip surrounding quotes
            if len(value) >= 2 and value[0] == value[-1] and value[0] in ('"', "'"):
                value = value[1:-1]
            env[key] = value
    return env


def expand_env_vars(text: str, env: Optional[Dict[str, str]] = None) -> str:
    """Expand ``${VAR}`` and ``$VAR`` references in *text*.

    Uses *env* if provided, otherwise falls back to ``os.environ``.
    """
    mapping = env if env is not None else os.environ

    def _replace(match: re.Match) -> str:
        var_name = match.group(1) or match.group(2)
        return mapping.get(var_name, match.group(0))

    return re.sub(r"\$\{(\w+)\}|\$(\w+)", _replace, text)


def flatten_dict(
    d: Dict[str, Any],
    sep: str = ".",
    _prefix: str = "",
) -> Dict[str, Any]:
    """Flatten a nested dictionary using *sep* as key separator.

    Example::

        >>> flatten_dict({"a": {"b": 1, "c": 2}})
        {'a.b': 1, 'a.c': 2}
    """
    items: Dict[str, Any] = {}
    for key, value in d.items():
        new_key = f"{_prefix}{sep}{key}" if _prefix else key
        if isinstance(value, dict):
            items.update(flatten_dict(value, sep=sep, _prefix=new_key))
        else:
            items[new_key] = value
    return items
