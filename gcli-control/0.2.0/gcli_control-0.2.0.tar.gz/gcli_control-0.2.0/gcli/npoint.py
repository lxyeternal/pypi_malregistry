"""
Npoint.io API wrapper - simple JSON document store with retry logic.
GET  /api.npoint.io/{id}  -> read document
POST /api.npoint.io/{id}  -> overwrite document (entire body)
"""
import json
import time
import urllib.request
import urllib.error

BASE = "https://api.npoint.io"
MAX_RETRIES = 3
RETRY_DELAY = 2.0  # seconds between retries
READ_TIMEOUT = 15
WRITE_TIMEOUT = 30
HEADERS = {
    "User-Agent": "gcli/0.1.0",
}


def read(bin_id: str) -> dict:
    """Read the full JSON document with retries."""
    url = f"{BASE}/{bin_id}"
    last_err = None
    for attempt in range(MAX_RETRIES):
        try:
            req = urllib.request.Request(url, headers=HEADERS)
            with urllib.request.urlopen(req, timeout=READ_TIMEOUT) as resp:
                return json.loads(resp.read())
        except urllib.error.HTTPError as e:
            last_err = RuntimeError(f"npoint read failed: {e.code} {e.reason}")
        except Exception as e:
            last_err = RuntimeError(f"npoint read failed: {e}")
        if attempt < MAX_RETRIES - 1:
            time.sleep(RETRY_DELAY * (attempt + 1))
    raise last_err


def write(bin_id: str, data: dict) -> None:
    """Overwrite the entire document with retries."""
    url = f"{BASE}/{bin_id}"
    body = json.dumps(data, separators=(",", ":")).encode("utf-8")
    last_err = None
    for attempt in range(MAX_RETRIES):
        try:
            req = urllib.request.Request(
                url,
                data=body,
                headers={**HEADERS, "Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=WRITE_TIMEOUT) as resp:
                return
        except urllib.error.HTTPError as e:
            last_err = RuntimeError(f"npoint write failed: {e.code} {e.reason}")
        except Exception as e:
            last_err = RuntimeError(f"npoint write failed: {e}")
        if attempt < MAX_RETRIES - 1:
            time.sleep(RETRY_DELAY * (attempt + 1))
    raise last_err
