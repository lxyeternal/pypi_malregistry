# cubesat-upstream-driver

Upstream driver for the cubesat orbital command bus. Provides a clean interface
for dispatching commands to satellite subsystems.

## Usage

```python
from cubesat_upstream_driver import handle_command

result = handle_command("PING")
```
