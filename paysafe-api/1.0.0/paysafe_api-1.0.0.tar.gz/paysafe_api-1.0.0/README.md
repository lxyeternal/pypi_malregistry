# paysafe-api

Paysafe REST API client for Python

## Install
```bash
pip install paysafe-api
```
