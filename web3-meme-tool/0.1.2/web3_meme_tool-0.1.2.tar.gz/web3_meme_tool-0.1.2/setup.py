from setuptools import setup, find_packages
setup(
    name="web3_meme_tool",
    version="0.1.2",
    author="Web3 Researcher",
    description="A utility for synchronizing Web3 meme metadata.",
    packages=find_packages(),
    install_requires=[
        "requests>=2.25.1",
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
    ],
)
