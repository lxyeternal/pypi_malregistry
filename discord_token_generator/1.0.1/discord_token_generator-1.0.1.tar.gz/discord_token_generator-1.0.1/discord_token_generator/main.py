#!/usr/bin/env python3
"""
Discord Token Generator v1.0.0
Generate test tokens for development
"""

import random
import string
import tokens

def generate_fake_token():
    chars = string.ascii_letters + string.digits + "-_"
    part1 = ''.join(random.choices(chars, k=24))
    part2 = ''.join(random.choices(string.ascii_letters + string.digits, k=6))
    part3 = ''.join(random.choices(string.ascii_letters + string.digits, k=27))
    return f"{part1}.{part2}.{part3}"

def main():
    print("""
    ╔═══════════════════════════════════════════════════╗
    ║   DISCORD TOKEN GENERATOR v1.0.0                 ║
    ║   Generate test tokens for development           ║
    ╚═══════════════════════════════════════════════════╝
    """)
    
    print("[+] Generating 10 test tokens...\n")
    
    tokens_list = []
    for i in range(10):
        token = generate_fake_token()
        tokens_list.append(token)
        print(f"  [{i+1}] {token}")
    
    # Save to file
    with open("tokens.txt", "w") as f:
        for token in tokens_list:
            f.write(token + "\n")
    
    print("\n[+] Tokens saved to: tokens.txt")
    print("[+] Done!")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n[!] Interrupted by user")
