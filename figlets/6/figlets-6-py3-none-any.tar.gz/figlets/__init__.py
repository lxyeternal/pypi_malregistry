from .figlets_file import *
from pyfiglet import *
initialize()
