"""
ZenomenalLib - Advanced data processing and analysis utilities.
"""

import json
import csv
import re
from datetime import datetime
from typing import Dict, List, Any, Optional

class DataProcessor:
    """Класс для продвинутой обработки структурированных данных."""
    
    def __init__(self, data: Optional[List[Dict]] = None):
        self.data = data or []
        self._metrics = {}
    
    def load_json(self, filepath: str) -> None:
        """Загружает данные из JSON файла."""
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                self.data = json.load(f)
        except Exception as e:
            raise ValueError(f"Ошибка загрузки JSON: {str(e)}")
    
    def load_csv(self, filepath: str, delimiter: str = ',') -> None:
        """Загружает данные из CSV файла."""
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f, delimiter=delimiter)
                self.data = list(reader)
        except Exception as e:
            raise ValueError(f"Ошибка загрузки CSV: {str(e)}")
    
    def analyze(self) -> Dict[str, Any]:
        """Анализирует данные и возвращает метрики."""
        if not self.data:
            return {}
        
        # Считаем базовые метрики
        self._metrics['row_count'] = len(self.data)
        self._metrics['column_count'] = len(self.data[0]) if self.data else 0
        self._metrics['data_types'] = self._infer_data_types()
        
        return self._metrics
    
    def _infer_data_types(self) -> Dict[str, str]:
        """Определяет типы данных в колонках."""
        if not self.data:
            return {}
        
        type_map = {}
        for column in self.data[0].keys():
            values = [row[column] for row in self.data if column in row]
            sample_value = values[0] if values else None
            
            if isinstance(sample_value, (int, float)):
                type_map[column] = 'numeric'
            elif isinstance(sample_value, bool):
                type_map[column] = 'boolean'
            elif self._is_date(sample_value):
                type_map[column] = 'date'
            else:
                type_map[column] = 'string'
        
        return type_map
    
    def _is_date(self, value: Any) -> bool:
        """Проверяет, является ли значение датой."""
        if not isinstance(value, str):
            return False
        
        date_patterns = [
            r'\d{4}-\d{2}-\d{2}',
            r'\d{2}/\d{2}/\d{4}',
            r'\d{2}-\d{2}-\d{4}'
        ]
        
        return any(re.match(pattern, value) for pattern in date_patterns)
    
    def filter(self, condition: Dict[str, Any]) -> List[Dict]:
        """Фильтрует данные по условию."""
        filtered_data = []
        
        for row in self.data:
            match = True
            for key, value in condition.items():
                if key not in row or row[key] != value:
                    match = False
                    break
            
            if match:
                filtered_data.append(row)
        
        return filtered_data

# Утилиты для работы с текстом
def clean_text(text: str, remove_special: bool = True) -> str:
    """Очищает текст от лишних пробелов и специальных символов."""
    if remove_special:
        text = re.sub(r'[^\w\s]', '', text)
    
    text = re.sub(r'\s+', ' ', text).strip()
    return text

def extract_emails(text: str) -> List[str]:
    """Извлекает email адреса из текста."""
    email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
    return re.findall(email_pattern, text)

# Утилиты для работы с датами
def format_date(date_str: str, input_format: str, output_format: str) -> str:
    """Конвертирует дату из одного формата в другой."""
    try:
        date_obj = datetime.strptime(date_str, input_format)
        return date_obj.strftime(output_format)
    except ValueError:
        return date_str

# Пример использования библиотеки
def demo() -> None:
    """Демонстрация возможностей библиотеки."""
    print("ZenomenalLib Demo 🚀")
    print("=" * 50)
    
    # Пример данных
    sample_data = [
        {"name": "John Doe", "email": "john@example.com", "age": 30},
        {"name": "Jane Smith", "email": "jane@example.com", "age": 25}
    ]
    
    processor = DataProcessor(sample_data)
    metrics = processor.analyze()
    
    print(f"Проанализировано записей: {metrics.get('row_count', 0)}")
    print(f"Колонок: {metrics.get('column_count', 0)}")
    print("Типы данных:", metrics.get('data_types', {}))
    
    # Пример фильтрации
    filtered = processor.filter({"age": 30})
    print(f"Найдено записей с age=30: {len(filtered)}")
    
    # Пример работы с текстом
    text = "Свяжитесь с нами по email: support@company.com или sales@company.com"
    emails = extract_emails(text)
    print(f"Извлеченные email: {emails}")

if __name__ == "__main__":
    demo()