dark-magic
==========

.. image:: https://img.shields.io/pypi/v/dark-magic.svg
    :target: https://pypi.python.org/pypi/dark-magic
    :alt: Latest PyPI version

.. image:: https://travis-ci.org/borntyping/cookiecutter-pypackage-minimal.png
   :target: https://travis-ci.org/borntyping/cookiecutter-pypackage-minimal
   :alt: Latest Travis CI build status

This library contains a simple simplex solver for linear constrained equations in dual form.

Usage
-----


Usage: ./dark_magic <command> x_FILEPATH A_FILEPATH b_FILEPATH c_FILEPATH


Disclaimer
----------
This is a test package.

Installation
------------

pip install dark-magic

Requirements
^^^^^^^^^^^^

Compatibility
-------------

Licence
-------

Authors
-------

`dark-magic` was written by `Joel Rogan <matrix.epokh@gmail.com>`_.
