# code/x.py

def some_function():
    print("Hello from some_function")
