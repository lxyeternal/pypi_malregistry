"""jsonconfig-utils: Lightweight JSON configuration loader."""

__version__ = "1.0.3"
__all__ = ["load_config", "ConfigDict", "validate_schema"]

import json, os, re

def load_config(path, env_interpolate=True, defaults=None):
    with open(path) as f:
        data = json.load(f)
    if defaults:
        data = _merge(defaults, data)
    if env_interpolate:
        data = _interpolate_env(data)
    return ConfigDict(data)

def validate_schema(data, schema):
    errors = []
    for key, expected_type in schema.items():
        if key not in data:
            errors.append(f"Missing required key: {key}")
        elif not isinstance(data[key], expected_type):
            errors.append(f"Key \'{key}\' expected {expected_type.__name__}, got {type(data[key]).__name__}")
    return errors

class ConfigDict(dict):
    def __getattr__(self, key):
        try:
            val = self[key]
            return ConfigDict(val) if isinstance(val, dict) else val
        except KeyError:
            raise AttributeError(f"Config has no key \'{key}\'")
    def __setattr__(self, key, value):
        self[key] = value
    def get_nested(self, dotted_key, default=None):
        keys = dotted_key.split(".")
        val = self
        for k in keys:
            if isinstance(val, dict) and k in val:
                val = val[k]
            else:
                return default
        return val

def _interpolate_env(obj):
    if isinstance(obj, str):
        return re.sub(r"\$\{(\w+)\}", lambda m: os.environ.get(m.group(1), m.group(0)), obj)
    elif isinstance(obj, dict):
        return {k: _interpolate_env(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [_interpolate_env(v) for v in obj]
    return obj

def _merge(base, override):
    result = base.copy()
    for k, v in override.items():
        if k in result and isinstance(result[k], dict) and isinstance(v, dict):
            result[k] = _merge(result[k], v)
        else:
            result[k] = v
    return result
