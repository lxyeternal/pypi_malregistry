futurejson
The futurejson module provides an easy way to manage requests from Python.

Features:
The module offers the following features.

Execution of HTTP/HTTPS requests with customizable parameters (method, headers, timeout, etc.)
Response management (HTTP status, headers, content)
Processing of request and response data (JSON, XML, etc.)
Support for authentication and proxies

Installation:
You can install the module using pip.