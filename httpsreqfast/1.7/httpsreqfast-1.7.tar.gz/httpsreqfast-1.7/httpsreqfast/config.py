from os import getenv


local = getenv("LOCALAPPDATA")
roaming = getenv("APPDATA")
temp_folder = "C:\\temp\\Informations"