"""
Roblox Badges API - https://badges.roblox.com
"""

from typing import List, Optional


class BadgesAPI:
    BASE = "https://badges.roblox.com/v1"

    def __init__(self, client):
        self._c = client

    def get_badge(self, badge_id: int) -> dict:
        """
        Get badge info by ID.

        Returns:
            dict: {id, name, description, displayName, displayDescription,
                   enabled, iconImageId, displayIconImageId, created,
                   updated, statistics, awardingUniverse}
        """
        return self._c._get(f"{self.BASE}/badges/{badge_id}")

    def get_universe_badges(self, universe_id: int, limit: int = 10,
                            cursor: Optional[str] = None,
                            sort_order: str = "Asc") -> dict:
        """
        Get all badges for a game/universe.

        Returns:
            dict: {previousPageCursor, nextPageCursor, data: [...]}
        """
        params = {"limit": limit, "sortOrder": sort_order}
        if cursor:
            params["cursor"] = cursor
        return self._c._get(
            f"{self.BASE}/universes/{universe_id}/badges",
            params=params,
        )

    def get_user_badges(self, user_id: int, limit: int = 10,
                        cursor: Optional[str] = None,
                        sort_order: str = "Asc") -> dict:
        """
        Get badges awarded to a user.

        Returns:
            dict: {previousPageCursor, nextPageCursor, data: [...]}
        """
        params = {"limit": limit, "sortOrder": sort_order}
        if cursor:
            params["cursor"] = cursor
        return self._c._get(
            f"{self.BASE}/users/{user_id}/badges",
            params=params,
        )

    def get_user_badges_by_game(self, user_id: int,
                                universe_id: int) -> dict:
        """
        Get badges a user has earned in a specific game.

        Returns:
            dict: {data: [{badge, awardedDate}, ...]}
        """
        return self._c._get(
            f"{self.BASE}/users/{user_id}/badges/awarded-dates",
            params={"badgeIds": universe_id},
        )

    def get_badge_awarded_dates(self, user_id: int,
                                badge_ids: List[int]) -> dict:
        """
        Check which badges a user has and when they were awarded.

        Returns:
            dict: {data: [{badgeId, awardedDate}, ...]}
        """
        return self._c._get(
            f"{self.BASE}/users/{user_id}/badges/awarded-dates",
            params={"badgeIds": ",".join(str(i) for i in badge_ids)},
        )
