from setuptools import setup, find_packages

setup(
    name="dify-api",
    version="2.0.0",
    author="detox56",
    author_email="usernodesester@gmail.com",
    description="test",
    packages=find_packages(),
    install_requires=['requests'],
)

