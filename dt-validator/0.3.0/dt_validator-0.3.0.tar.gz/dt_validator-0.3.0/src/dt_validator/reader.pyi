"""Type stubs for reader — public interface only; implementation is hidden."""

from dataclasses import dataclass
from typing import Optional

from .validation import ValidationPolicy

@dataclass(frozen=True)
class FileLocation:
    bucket: str
    key: str
    region: Optional[str] = ...

@dataclass(frozen=True)
class FileMetadata:
    location: FileLocation
    size: int
    content_type: Optional[str]
    etag: Optional[str]
    last_modified: Optional[object] = ...

def parse_uri(uri: str) -> FileLocation:
    """Parse an ``s3://bucket/key`` URI or S3 HTTPS URL into an FileLocation."""
    ...

def head_object(uri: str) -> FileMetadata:
    """Fetch object metadata (size, content-type, etag) via an anonymous HEAD."""
    ...

def read_object(
    uri: str,
    *,
    encoding: Optional[str] = ...,
    max_bytes: Optional[int] = ...,
    policy: Optional[ValidationPolicy] = ...,
) -> str | bytes:
    """Read a publicly-accessible S3 object and return its contents."""
    ...
