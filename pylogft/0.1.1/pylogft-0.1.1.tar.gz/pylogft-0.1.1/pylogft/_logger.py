"""Core `Logger` and `BoundLogger` implementations."""
from __future__ import annotations

import functools
import json
import logging
import os
import sys
import threading
from contextlib import contextmanager
from datetime import datetime
from typing import Any, Callable, IO, Optional, Union

from ._format import (
    LEVEL_NUMERIC,
    default_format,
    format_traceback,
    supports_color,
)
from ._sinks import FileSink

_pylogft_DIR = os.path.dirname(os.path.abspath(__file__))


class _Sink:
    """An internal record of a registered output destination."""
    __slots__ = (
        "id", "writer", "closer", "level_no",
        "filter", "format", "colorize", "serialize",
    )

    def __init__(self, id_, writer, closer, level_no, filter_, format_, colorize, serialize):
        self.id = id_
        self.writer = writer
        self.closer = closer
        self.level_no = level_no
        self.filter = filter_
        self.format = format_
        self.colorize = colorize
        self.serialize = serialize


class Logger:
    """A small, friendly logger with pretty defaults.

    Use the pre-built :data:`pylogft.log` instance directly::

        from pylogft import log
        log.info("hello")

    Or instantiate your own ``Logger()`` for an isolated configuration.
    """

    def __init__(self):
        self._sinks: dict[int, _Sink] = {}
        self._next_id = 0
        self._min_level_no = 100
        self._lock = threading.RLock()
        self._context: dict[str, Any] = {}
        self.add(sys.stderr)

    # -------------------------------------------------------------- sinks
    def add(
        self,
        sink: Union[str, "os.PathLike[str]", IO, Callable[[str], None]],
        *,
        level: Union[str, int] = "DEBUG",
        format: Optional[Union[str, Callable[[dict], str]]] = None,
        filter: Optional[Callable[[dict], bool]] = None,
        rotate: Optional[Union[str, int]] = None,
        keep: Optional[Union[str, int]] = None,
        compress: bool = False,
        encoding: str = "utf-8",
        colorize: Optional[bool] = None,
        serialize: bool = False,
    ) -> int:
        """Register a new output destination.

        Parameters
        ----------
        sink :
            Where the messages go. One of:

            * a path string (file with optional rotation)
            * a writable file-like object (e.g. ``sys.stderr``)
            * a callable taking a single ``str`` (custom handler)
        level :
            Minimum level for this sink. Default ``"DEBUG"``.
        format :
            Custom format. Either a ``str.format``-style template using
            ``{time} {level} {message} {name} {function} {line} {thread}``
            and ``{extra.key}`` placeholders, or a callable taking the
            record dict and returning the rendered line. If ``None``,
            uses the built-in pretty layout.
        filter :
            Optional callable returning ``True``/``False`` for a record.
        rotate :
            Rotation policy. Either a size string like ``"10 MB"``/``"500 KB"``,
            an ``int`` byte count, or one of ``"hourly"``, ``"daily"``,
            ``"weekly"``, ``"monthly"``.
        keep :
            Retention. Either an ``int`` (number of rotated files to keep)
            or a string like ``"7 days"``.
        compress :
            Gzip rotated files.
        colorize :
            Force-enable/disable ANSI colors. ``None`` auto-detects.
        serialize :
            Emit one JSON object per line (overrides ``format``).

        Returns
        -------
        int
            Sink id, which you can later pass to :meth:`remove`.
        """
        with self._lock:
            level_no = self._level_to_no(level)
            closer: Optional[Callable[[], None]] = None

            if isinstance(sink, (str, os.PathLike)):
                file_sink = FileSink(
                    sink, rotate=rotate, keep=keep,
                    compress=compress, encoding=encoding,
                )
                writer = file_sink.write
                closer = file_sink.close
                if colorize is None:
                    colorize = False
            elif hasattr(sink, "write"):
                stream = sink
                writer = stream.write
                if colorize is None:
                    colorize = supports_color(stream)
            elif callable(sink):
                writer = sink
                if colorize is None:
                    colorize = False
            else:
                raise TypeError(f"Unsupported sink type: {type(sink)!r}")

            sink_id = self._next_id
            self._next_id += 1
            self._sinks[sink_id] = _Sink(
                sink_id, writer, closer, level_no,
                filter, format, bool(colorize), bool(serialize),
            )
            self._recompute_min_level()
            return sink_id

    def remove(self, sink_id: Optional[int] = None) -> None:
        """Remove a sink. With no argument, removes all sinks."""
        with self._lock:
            if sink_id is None:
                for s in self._sinks.values():
                    if s.closer is not None:
                        try:
                            s.closer()
                        except Exception:
                            pass
                self._sinks.clear()
            else:
                s = self._sinks.pop(sink_id, None)
                if s is not None and s.closer is not None:
                    try:
                        s.closer()
                    except Exception:
                        pass
            self._recompute_min_level()

    def _recompute_min_level(self) -> None:
        self._min_level_no = (
            min(s.level_no for s in self._sinks.values()) if self._sinks else 100
        )

    # ------------------------------------------------------------ context
    def bind(self, **kwargs) -> "BoundLogger":
        """Return a logger that always attaches the given context."""
        return BoundLogger(self, {**self._context, **kwargs})

    @contextmanager
    def contextualize(self, **kwargs):
        """Temporarily attach context for the duration of a ``with`` block."""
        old = self._context
        self._context = {**old, **kwargs}
        try:
            yield self
        finally:
            self._context = old

    # ------------------------------------------------------------ logging
    @staticmethod
    def _level_to_no(level: Union[str, int]) -> int:
        if isinstance(level, int):
            return level
        try:
            return LEVEL_NUMERIC[level.upper()]
        except KeyError as e:
            raise ValueError(f"Unknown level: {level!r}") from e

    def _log(
        self,
        level_name: str,
        message: Any,
        *args,
        exc_info=None,
        _stdlib_record=None,
        **extra,
    ) -> None:
        level_no = LEVEL_NUMERIC.get(level_name.upper(), 20)
        if level_no < self._min_level_no:
            return
        level_name = level_name.upper()

        msg_str = str(message)
        if args or extra:
            try:
                if "{" in msg_str and "}" in msg_str:
                    msg_str = msg_str.format(*args, **extra)
                elif args:
                    msg_str = msg_str % args
            except (KeyError, IndexError, ValueError, TypeError):
                pass

        if _stdlib_record is not None:
            name = _stdlib_record.name
            func = _stdlib_record.funcName
            line = _stdlib_record.lineno
            file = _stdlib_record.pathname
        else:
            frame = self._find_caller_frame()
            if frame is not None:
                name = frame.f_globals.get("__name__", "?")
                func = frame.f_code.co_name
                line = frame.f_lineno
                file = frame.f_code.co_filename
            else:
                name, func, line, file = "?", "?", 0, "?"

        merged_extra = {**self._context, **extra}

        record = {
            "time": datetime.now(),
            "level": level_name,
            "level_no": level_no,
            "name": name,
            "function": func,
            "line": line,
            "file": file,
            "message": msg_str,
            "extra": merged_extra,
            "thread": threading.current_thread().name,
            "process": os.getpid(),
            "exception": exc_info,
        }

        with self._lock:
            sinks = list(self._sinks.values())

        for sink in sinks:
            if record["level_no"] < sink.level_no:
                continue
            if sink.filter is not None:
                try:
                    if not sink.filter(record):
                        continue
                except Exception:
                    continue
            try:
                output = self._render(record, sink)
                sink.writer(output)
            except Exception as exc:
                sys.stderr.write(f"pylogft: sink error: {exc!r}\n")

    def _find_caller_frame(self):
        frame = sys._getframe(2)
        while frame is not None:
            filename = frame.f_code.co_filename
            if not filename.startswith(_pylogft_DIR):
                base = os.path.basename(filename)
                if base != "logging" and "logging" not in os.path.normpath(filename).split(os.sep):
                    return frame
            frame = frame.f_back
        return None

    def _render(self, record: dict, sink: _Sink) -> str:
        if sink.serialize:
            text = self._render_json(record)
        elif sink.format is None:
            text = default_format(record, colorize_output=sink.colorize)
        elif callable(sink.format):
            text = sink.format(record)
        else:
            text = sink.format.format(**_format_kwargs(record))

        exc_info = record.get("exception")
        if exc_info is True:
            exc_info = sys.exc_info()
        if isinstance(exc_info, BaseException):
            exc_info = (type(exc_info), exc_info, exc_info.__traceback__)
        if isinstance(exc_info, tuple) and exc_info[0] is not None:
            if not sink.serialize:
                tb = format_traceback(*exc_info, colorize_output=sink.colorize)
                text = text + "\n" + tb
        return text + "\n"

    def _render_json(self, record: dict) -> str:
        payload = {
            "time": record["time"].isoformat(),
            "level": record["level"],
            "name": record["name"],
            "function": record["function"],
            "line": record["line"],
            "file": record["file"],
            "message": record["message"],
            "thread": record["thread"],
            "process": record["process"],
            "extra": {k: _json_safe(v) for k, v in record["extra"].items()},
        }
        exc_info = record.get("exception")
        if exc_info is True:
            exc_info = sys.exc_info()
        if isinstance(exc_info, BaseException):
            exc_info = (type(exc_info), exc_info, exc_info.__traceback__)
        if isinstance(exc_info, tuple) and exc_info[0] is not None:
            payload["exception"] = {
                "type": exc_info[0].__name__,
                "value": str(exc_info[1]),
                "traceback": format_traceback(*exc_info, colorize_output=False),
            }
        return json.dumps(payload, default=str)

    # ---------------------------------------------------------- shortcuts
    def trace(self, message, *args, **kwargs):    self._log("TRACE", message, *args, **kwargs)
    def debug(self, message, *args, **kwargs):    self._log("DEBUG", message, *args, **kwargs)
    def info(self, message, *args, **kwargs):     self._log("INFO", message, *args, **kwargs)
    def success(self, message, *args, **kwargs):  self._log("SUCCESS", message, *args, **kwargs)
    def warning(self, message, *args, **kwargs):  self._log("WARNING", message, *args, **kwargs)
    warn = warning
    def error(self, message, *args, **kwargs):    self._log("ERROR", message, *args, **kwargs)
    def critical(self, message, *args, **kwargs): self._log("CRITICAL", message, *args, **kwargs)

    def exception(self, message, *args, **kwargs):
        """Log an exception with traceback (call inside an ``except`` block)."""
        kwargs.setdefault("exc_info", sys.exc_info())
        self._log("ERROR", message, *args, **kwargs)

    def log(self, level, message, *args, **kwargs):
        self._log(level if isinstance(level, str) else str(level),
                  message, *args, **kwargs)

    # ------------------------------------------------------------- catch
    def catch(
        self,
        func_or_exc=None,
        *,
        level: str = "ERROR",
        reraise: bool = False,
        message: str = "An error occurred",
    ):
        """Capture exceptions, used as a decorator or context manager.

        As a bare decorator::

            @log.catch
            def risky(): ...

        With options::

            @log.catch(reraise=True)
            def risky(): ...

        As a context manager::

            with log.catch():
                risky()
        """
        # Bare-decorator form: @log.catch
        if callable(func_or_exc) and not isinstance(func_or_exc, type):
            return _make_catch_decorator(self, Exception, level, reraise, message)(func_or_exc)

        exception = func_or_exc if isinstance(func_or_exc, type) else Exception
        return _Catcher(self, exception, level, reraise, message)

    # ---------------------------------------------------- stdlib intercept
    def intercept_stdlib(self, level: Union[str, int] = "DEBUG") -> "Logger":
        """Route the standard ``logging`` module through this logger."""
        from ._stdlib import InterceptHandler
        root = logging.getLogger()
        for h in list(root.handlers):
            root.removeHandler(h)
        root.addHandler(InterceptHandler(self, level=self._level_to_no(level)))
        root.setLevel(self._level_to_no(level))
        return self


class BoundLogger:
    """A view of a :class:`Logger` that attaches extra context to every record."""

    def __init__(self, parent: Logger, context: dict):
        self._parent = parent
        self._context = context

    def bind(self, **kwargs) -> "BoundLogger":
        return BoundLogger(self._parent, {**self._context, **kwargs})

    @contextmanager
    def contextualize(self, **kwargs):
        old = self._context
        self._context = {**old, **kwargs}
        try:
            yield self
        finally:
            self._context = old

    def _log(self, level, message, *args, exc_info=None, **extra):
        merged = {**self._context, **extra}
        self._parent._log(level, message, *args, exc_info=exc_info, **merged)

    def trace(self, m, *a, **kw):    self._log("TRACE", m, *a, **kw)
    def debug(self, m, *a, **kw):    self._log("DEBUG", m, *a, **kw)
    def info(self, m, *a, **kw):     self._log("INFO", m, *a, **kw)
    def success(self, m, *a, **kw):  self._log("SUCCESS", m, *a, **kw)
    def warning(self, m, *a, **kw):  self._log("WARNING", m, *a, **kw)
    warn = warning
    def error(self, m, *a, **kw):    self._log("ERROR", m, *a, **kw)
    def critical(self, m, *a, **kw): self._log("CRITICAL", m, *a, **kw)

    def exception(self, m, *a, **kw):
        kw.setdefault("exc_info", sys.exc_info())
        self._log("ERROR", m, *a, **kw)

    def log(self, level, m, *a, **kw): self._log(level, m, *a, **kw)

    def catch(self, *args, **kwargs):
        return self._parent.catch(*args, **kwargs)._with_context(self._context)


# ---------------------------------------------------------- catch helpers


class _Catcher:
    def __init__(self, logger: Logger, exception, level, reraise, message):
        self._logger = logger
        self._exception = exception
        self._level = level
        self._reraise = reraise
        self._message = message
        self._extra: dict = {}

    def _with_context(self, extra: dict) -> "_Catcher":
        self._extra = dict(extra)
        return self

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, exc_tb):
        if exc_type is None:
            return False
        if not issubclass(exc_type, self._exception):
            return False
        self._logger._log(
            self._level, self._message,
            exc_info=(exc_type, exc_value, exc_tb),
            **self._extra,
        )
        return not self._reraise

    def __call__(self, func):
        return _make_catch_decorator(
            self._logger, self._exception, self._level, self._reraise, self._message,
            extra=self._extra,
        )(func)


def _make_catch_decorator(logger, exception, level, reraise, message, extra=None):
    extra = extra or {}

    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except exception:
                logger._log(level, message, exc_info=sys.exc_info(), **extra)
                if reraise:
                    raise
                return None
        return wrapper
    return decorator


# ---------------------------------------------------------- helpers


def _format_kwargs(record: dict) -> dict:
    out = {
        "time": record["time"].strftime("%Y-%m-%d %H:%M:%S"),
        "level": record["level"],
        "name": record["name"],
        "function": record["function"],
        "line": record["line"],
        "file": record["file"],
        "message": record["message"],
        "thread": record["thread"],
        "process": record["process"],
    }
    for k, v in record["extra"].items():
        out[f"extra.{k}"] = v
        out.setdefault(k, v)
    return out


def _json_safe(value):
    try:
        json.dumps(value)
        return value
    except (TypeError, ValueError):
        return repr(value)
