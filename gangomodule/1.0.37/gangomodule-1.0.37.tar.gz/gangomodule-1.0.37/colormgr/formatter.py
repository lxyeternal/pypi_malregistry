"""Formatting utilities for colored output."""

from . import colors

def format_text(text: str, color: str = 'white', bg: str = None, bold: bool = False) -> str:
    """Format text with color and optional styling."""
    result = ""
    
    if bold:
        result += colors.COLORS['bold']
    
    if bg:
        result += colors.BACKGROUNDS.get(bg, '')
    
    result += colors.get_color(color)
    result += text
    result += colors.COLORS['reset']
    
    return result

def progress_bar(current: int, total: int, width: int = 40, label: str = "") -> str:
    """Generate a simple progress bar."""
    percent = current / total if total > 0 else 0
    filled = int(width * percent)
    bar = '█' * filled + '░' * (width - filled)
    label_str = f"{label} " if label else ""
    return f"{label_str}[{bar}] {percent*100:.1f}%"
