from setuptools import setup

setup(
    name='getlatency',
    version='1.1',
    description='get latency module for you',
    author='Skyler Palmer',
    author_email='contact@skyler.co.uk'
)
