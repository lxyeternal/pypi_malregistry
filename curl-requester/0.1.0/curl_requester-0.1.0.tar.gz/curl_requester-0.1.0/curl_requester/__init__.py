# __init__.py
from .requester import send_curl_request

