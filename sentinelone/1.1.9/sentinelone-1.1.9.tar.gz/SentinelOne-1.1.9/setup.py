from setuptools import setup, find_packages

package_version = '1.1.9'

setup(
    name='SentinelOne',
    version='1.1.9',
    license='SentinelOne'
)

