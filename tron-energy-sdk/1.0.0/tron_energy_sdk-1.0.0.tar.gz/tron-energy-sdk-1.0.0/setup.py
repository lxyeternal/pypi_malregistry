from setuptools import setup
setup(name="tron-energy-sdk",version="1.0.0",py_modules=["tron_energy_sdk"],install_requires=["requests"],python_requires=">=3.7")
