# fwk-amigapython-rest-server

> Amiga Python REST server runtime — ASGI/WSGI application server with platform-native observability, health probes, and mTLS support.

## Overview

`fwk-amigapython-rest-server` provides a production-ready HTTP server for Python microservices on the Amiga platform:

- **ASGI/WSGI support** — run any ASGI or WSGI application with zero config
- **Health probes** — automatic liveness and readiness endpoints
- **Graceful shutdown** — SIGTERM handling with connection draining
- **mTLS** — automatic certificate provisioning from platform PKI

## Installation

```bash
pip install fwk-amigapython-rest-server
```

## Quick Start

```python
from amigapython_rest_server import RestServer

server = RestServer.from_config()
server.mount("/api", my_app)
server.run()
```

## License

Apache 2.0
