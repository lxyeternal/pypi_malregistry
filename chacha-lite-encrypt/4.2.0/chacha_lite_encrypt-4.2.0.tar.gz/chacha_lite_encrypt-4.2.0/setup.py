from setuptools import setup, find_packages
import os

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="chacha-lite-encrypt",
    version="4.2.0",
    author="Alexander S. K. (aka alexander-s-k)",
    author_email="alexander.s.k@gmail.com",
    description="A lightweight ChaCha20 encryption library",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Security :: Cryptography",
    ],
    python_requires=">=3.7",
    include_package_data=True,
    package_data={
        'chacha_lite_encrypt': ['/data/*.json'],
    },
)
