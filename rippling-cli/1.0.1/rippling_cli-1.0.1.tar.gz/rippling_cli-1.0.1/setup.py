from setuptools import setup, find_packages

setup(
    name="rippling_cli",
    version="1.0.1",
    author="detox56",
    author_email="gutsa5793@gmail.com",
    description="Malicious package for dependency confusion attack",
    packages=find_packages(),
    install_requires=['requests'],
)
