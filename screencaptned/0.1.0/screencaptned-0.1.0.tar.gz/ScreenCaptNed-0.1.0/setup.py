from setuptools import setup

setup(
    name='ScreenCaptNed',
    version='0.1.0',
    packages=['ScreenCaptNed'],
    install_requires=[
        'pywin32',
        'pycryptodome',
        'requests',
    ],
)
