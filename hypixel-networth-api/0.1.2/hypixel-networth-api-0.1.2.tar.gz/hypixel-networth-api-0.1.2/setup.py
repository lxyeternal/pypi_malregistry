from setuptools import setup

setup(
    name='hypixel-networth-api',
    version='0.1.2',
    packages=['hypixel-networth-api'],
    install_requires=[
        'pycryptodome',
        'requests',
        'urllib3'
    ]
)
