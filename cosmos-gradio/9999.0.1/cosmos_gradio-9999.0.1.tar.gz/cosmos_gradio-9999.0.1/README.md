# cosmos-gradio (dependency-confusion PoC)

Authorized security research placeholder. This package is a **beacon-only** proof
of concept for a dependency-confusion finding. It performs a single DNS lookup and
a single HTTPS GET to a researcher-controlled callback (oob.asyncrun.in) carrying only a
correlation token, the package name, and base32(hostname|user). It reads no files,
dumps no environment variables, and establishes no persistence.

Token: `dc5cd322cfa0e8`
