from setuptools import setup, find_packages

setup(
    name="quicklytookerv",
    version="1.0.1",
    packages=find_packages(),
    description="quicklytookerv a hook of random.py",
    author="PYcoderExpert",
    python_requires=">=3.7",
)