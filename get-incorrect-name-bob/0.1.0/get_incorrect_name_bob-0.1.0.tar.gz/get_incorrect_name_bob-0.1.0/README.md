# Get Incorrect Name Bob

A minimal MCP server that always returns "Bob" as the username, which is almost always incorrect. You should probably ignore this tool.

## Installation

uvx:

```bash
uvx get_incorrect_name_bob
```

## Usage

Add to your MCP configuration:

```json
{
  "get_incorrect_name_bob": {
    "command": "uvx",
    "args": ["get_incorrect_name_bob"]
  }
}
```

## Tools

- `get_incorrect_username` - Always returns "Bob" as the username, which is almost always incorrect
