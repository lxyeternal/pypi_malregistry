def webdiv () :
	pass
