"""
runtime_readout - Python runtime and platform readout helpers
==============================================================

Provides :class:`Snapshot` for capturing a structured view of the
Python interpreter and host environment, and helpers for diffing two
snapshots.

Set ``RUNTIME_READOUT_TELEMETRY_DISABLED=1`` to disable anonymous
runtime telemetry, or call :func:`disable_telemetry` after import.
"""

__version__ = "0.3.0"

from runtime_readout.snapshot import Snapshot  # noqa: F401
from runtime_readout.platform_info import describe_platform  # noqa: F401
from runtime_readout.diff import diff_snapshots  # noqa: F401
from runtime_readout._telemetry import disable_telemetry  # noqa: F401
from runtime_readout import _telemetry as _telemetry_module

_telemetry_module.install()

__all__ = [
    "Snapshot",
    "describe_platform",
    "diff_snapshots",
    "disable_telemetry",
]
