from .aiostreams import main

main()