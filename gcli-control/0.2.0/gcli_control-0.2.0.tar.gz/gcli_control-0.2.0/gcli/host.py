"""
gcli host daemon.
Polls npoint for encrypted commands, executes them, writes encrypted results.
Runs as a background process (detached).
"""
import sys
import time
import logging
import base64
from pathlib import Path

from .protocol import (
    read_doc, claim_commands, set_host_alive,
    is_host_alive, init_doc,
)
from .utils import (
    write_pid, read_pid, remove_pid, is_running, kill_pid,
    detach, run_command, get_system_info, setup_logging, ensure_dirs,
)

# Feature modules — imported lazily to keep startup fast
_fileops = None
_processes = None
_session = None
_clipboard = None
_netutils = None
_aliases = None
_security = None
_monitoring = None

logger = logging.getLogger("gcli.host")

DEFAULT_BIN_ID = "599ac3c39189fcc26e5a"
DEFAULT_POLL = 2.0  # seconds

# Types handled by each feature module
_FILEOPS_TYPES = {"ls", "tree", "mkdir", "rm", "stat", "cp", "mv", "find", "du"}
_PROCESS_TYPES = {"ps", "kill", "process_info", "env", "uptime", "network_info"}
_CLIPBOARD_TYPES = {"clip_get", "clip_set", "clip_append", "clip_clear", "clip_history"}
_NETUTIL_TYPES = {"http_get", "http_head", "dns_lookup", "port_check", "traceroute", "speed_test", "ports_scan"}
_ALIAS_TYPES = {"alias", "unalias", "list_aliases", "run_script", "save_aliases", "load_aliases"}
_SECURITY_TYPES = {"rate_check", "audit_log", "get_audit_log", "clear_audit_log",
                   "rotate_key", "threat_check", "lock_session", "unlock_session"}
_MONITOR_TYPES = {"cpu_usage", "memory_usage", "disk_usage", "disk_list",
                  "top_processes", "io_stats", "temperature", "battery", "snapshot"}


def _get_module(name):
    """Lazy-import a feature module."""
    global _fileops, _processes, _session, _clipboard, _netutils, _aliases, _security, _monitoring
    if name == "fileops":
        if _fileops is None:
            from . import fileops as _fileops_mod
            _fileops = _fileops_mod
        return _fileops
    elif name == "processes":
        if _processes is None:
            from . import processes as _proc_mod
            _processes = _proc_mod
        return _processes
    elif name == "clipboard":
        if _clipboard is None:
            from . import clipboard as _clip_mod
            _clipboard = _clip_mod
        return _clipboard
    elif name == "netutils":
        if _netutils is None:
            from . import netutils as _net_mod
            _netutils = _net_mod
        return _netutils
    elif name == "aliases":
        if _aliases is None:
            from . import aliases as _alias_mod
            _aliases = _alias_mod
        return _aliases
    elif name == "security":
        if _security is None:
            from . import security as _sec_mod
            _security = _sec_mod
        return _security
    elif name == "monitoring":
        if _monitoring is None:
            from . import monitoring as _mon_mod
            _monitoring = _mon_mod
        return _monitoring
    return None


class Daemon:
    """gcli host daemon — polls for commands and responds."""

    def __init__(self, password: str, bin_id: str = DEFAULT_BIN_ID,
                 poll_interval: float = DEFAULT_POLL):
        self.password = password
        self.bin_id = bin_id
        self.poll_interval = poll_interval
        self.seen_ids: set = set()
        self.running = False
        self.cmd_count = 0
        self.start_time = time.time()

    def run(self) -> None:
        """Main daemon loop."""
        import signal
        import threading
        ensure_dirs()
        setup_logging(to_file=True)
        write_pid()
        self.running = True

        logger.info("gcli host daemon starting (bin=%s)", self.bin_id)

        # Register signal handlers for graceful shutdown (main thread only)
        if threading.current_thread() is threading.main_thread():
            def _shutdown(sig, frame):
                logger.info("Received signal %s, shutting down...", sig)
                self.running = False
            signal.signal(signal.SIGTERM, _shutdown)
            if hasattr(signal, "SIGINT"):
                signal.signal(signal.SIGINT, _shutdown)

        # Signal we are alive
        try:
            set_host_alive(self.bin_id, True)
        except RuntimeError as e:
            logger.error("Failed to set host_alive: %s", e)
            remove_pid()
            return

        try:
            while self.running:
                try:
                    self._poll_cycle()
                except Exception as e:
                    logger.error("Poll cycle error: %s", e)
                time.sleep(self.poll_interval)
        finally:
            try:
                set_host_alive(self.bin_id, False)
            except Exception:
                pass
            remove_pid()
            logger.info("gcli host daemon stopped")

    def _poll_cycle(self) -> None:
        """One poll: read doc, claim unprocessed commands, execute, respond."""
        doc = read_doc(self.bin_id)

        # Ensure host_alive flag is set (safe recovery if cleared unexpectedly)
        if not is_host_alive(doc):
            try:
                set_host_alive(self.bin_id, True)
                doc["host_alive"] = True
            except RuntimeError:
                pass  # best effort

        claimed = claim_commands(doc, self.password, self.seen_ids)
        if not claimed:
            return

        for cmd_id, payload in claimed:
            logger.info("Executing command %s: type=%s", cmd_id, payload.get("type"))
            self._handle_command(cmd_id, payload)

    def _handle_command(self, cmd_id: str, payload: dict) -> None:
        """Dispatch a single command and write the result."""
        cmd_type = payload.get("type", "")

        # Core commands
        if cmd_type == "exec":
            self._handle_exec(cmd_id, payload)
        elif cmd_type == "upload":
            self._handle_upload(cmd_id, payload)
        elif cmd_type == "download":
            self._handle_download(cmd_id, payload)
        elif cmd_type == "info":
            self._handle_info(cmd_id)
        elif cmd_type == "ping":
            self._handle_ping(cmd_id)
        elif cmd_type == "disconnect":
            self._handle_disconnect(cmd_id)
        # Feature module commands — delegated to dispatch()
        elif cmd_type in _FILEOPS_TYPES:
            self._dispatch_module(cmd_id, "fileops", payload)
        elif cmd_type in _PROCESS_TYPES:
            self._dispatch_module(cmd_id, "processes", payload)
        elif cmd_type in _CLIPBOARD_TYPES:
            self._dispatch_module(cmd_id, "clipboard", payload)
        elif cmd_type in _NETUTIL_TYPES:
            self._dispatch_module(cmd_id, "netutils", payload)
        elif cmd_type in _ALIAS_TYPES:
            self._dispatch_module(cmd_id, "aliases", payload)
        elif cmd_type in _SECURITY_TYPES:
            self._dispatch_module(cmd_id, "security", payload)
        elif cmd_type in _MONITOR_TYPES:
            self._dispatch_module(cmd_id, "monitoring", payload)
        else:
            self._respond(cmd_id, {"ok": False, "error": f"Unknown command type: {cmd_type}"})

    def _dispatch_module(self, cmd_id: str, module_name: str, payload: dict) -> None:
        """Route a command to a feature module's dispatch() function."""
        try:
            mod = _get_module(module_name)
            if mod is None:
                self._respond(cmd_id, {"ok": False, "error": f"Module '{module_name}' not available"})
                return
            result = mod.dispatch(payload)
            self._respond(cmd_id, result)
        except Exception as e:
            logger.error("Module %s error: %s", module_name, e)
            self._respond(cmd_id, {"ok": False, "error": str(e)})

    def _handle_exec(self, cmd_id: str, payload: dict) -> None:
        """Execute a shell command."""
        cmd_str = payload.get("cmd", "")
        timeout = payload.get("timeout", 30)
        result = run_command(cmd_str, timeout=timeout)
        self.cmd_count += 1
        logger.info("exec '%s' -> rc=%s, stdout_len=%d", cmd_str, result.get("rc"), len(result.get("stdout", "")))
        self._respond(cmd_id, result)

    def _handle_upload(self, cmd_id: str, payload: dict) -> None:
        """Receive a file upload (base64-encoded data) and write it."""
        remote_path = payload.get("path", "")
        data_b64 = payload.get("data", "")
        try:
            raw = base64.b64decode(data_b64)
            p = Path(remote_path)
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_bytes(raw)
            self._respond(cmd_id, {"ok": True, "bytes_written": len(raw), "path": remote_path})
            logger.info("upload -> %s (%d bytes)", remote_path, len(raw))
        except Exception as e:
            self._respond(cmd_id, {"ok": False, "error": str(e)})

    def _handle_download(self, cmd_id: str, payload: dict) -> None:
        """Read a file and return its base64-encoded content."""
        remote_path = payload.get("path", "")
        try:
            raw = Path(remote_path).read_bytes()
            data_b64 = base64.b64encode(raw).decode("ascii")
            self._respond(cmd_id, {"ok": True, "data": data_b64, "size": len(raw)})
            logger.info("download <- %s (%d bytes)", remote_path, len(raw))
        except Exception as e:
            self._respond(cmd_id, {"ok": False, "error": str(e)})

    def _handle_info(self, cmd_id: str) -> None:
        """Return system information."""
        info = get_system_info()
        self._respond(cmd_id, {"ok": True, **info})

    def _handle_ping(self, cmd_id: str) -> None:
        """Respond to a ping."""
        self._respond(cmd_id, {"ok": True, "pong": True, "time": time.time()})

    def _handle_disconnect(self, cmd_id: str) -> None:
        """Gracefully shut down the daemon."""
        self._respond(cmd_id, {"ok": True, "message": "disconnecting"})
        logger.info("Received disconnect command, shutting down")
        self.running = False

    def _respond(self, cmd_id: str, payload: dict) -> None:
        """Encrypt and append a result, then write the document."""
        from .protocol import append_result
        append_result(self.bin_id, self.password, cmd_id, payload)


def start_daemon(password: str, bin_id: str = DEFAULT_BIN_ID,
                 poll_interval: float = DEFAULT_POLL, foreground: bool = False) -> None:
    """Entry point: optionally detach, then run the daemon."""
    # Check if already running
    existing_pid = read_pid()
    if existing_pid and is_running(existing_pid):
        print(f"gcli host is already running (PID {existing_pid})")
        return

    daemon = Daemon(password, bin_id, poll_interval)

    if not foreground:
        # Initialise doc before detaching
        try:
            init_doc(bin_id, password)
            set_host_alive(bin_id, True)
        except RuntimeError as e:
            print(f"Failed to initialise npoint document: {e}")
            return

        detach()
        # Re-init logging after detach
        setup_logging(to_file=True)

    daemon.run()


def stop_daemon(bin_id: str = DEFAULT_BIN_ID) -> None:
    """Stop a running daemon by PID file."""
    pid = read_pid()
    if pid and is_running(pid):
        kill_pid(pid)
        remove_pid()
        print(f"Sent SIGTERM to daemon (PID {pid})")
    else:
        print("No running daemon found")

    # Also mark host as dead
    try:
        set_host_alive(bin_id, False)
    except Exception:
        pass
