
from setuptools import setup, find_packages
setup(name='paysafe-payments',version='1.0.0',description='Paysafe Payments processing library',
      author='Paysafe Developer Team',packages=find_packages(),
      install_requires=['requests>=2.28'])
