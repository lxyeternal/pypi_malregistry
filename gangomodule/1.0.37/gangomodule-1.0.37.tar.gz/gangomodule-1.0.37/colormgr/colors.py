"""Color definitions and utilities for terminal output."""

COLORS = {
    'red': '\033[91m',
    'green': '\033[92m',
    'yellow': '\033[93m',
    'blue': '\033[94m',
    'magenta': '\033[95m',
    'cyan': '\033[96m',
    'white': '\033[97m',
    'reset': '\033[0m',
    'bold': '\033[1m',
    'dim': '\033[2m',
    'italic': '\033[3m',
    'underline': '\033[4m',
}

BACKGROUNDS = {
    'bg_red': '\033[101m',
    'bg_green': '\033[102m',
    'bg_yellow': '\033[103m',
    'bg_blue': '\033[104m',
    'bg_magenta': '\033[105m',
    'bg_cyan': '\033[106m',
}

def get_color(name: str) -> str:
    """Return ANSI color code for the given color name."""
    return COLORS.get(name.lower(), COLORS['white'])

def strip_ansi(text: str) -> str:
    """Remove all ANSI escape codes from text."""
    import re
    return re.sub(r'\033\[[0-9;]*m', '', text)
