from setuptools import setup, find_packages

setup(
    name='reversepkg',
    version='0.1.0',
    description='Totally not suspicious reverse tool',
    author='YourName',
    packages=find_packages(),
    include_package_data=True,
    python_requires='>=3.6',
)
