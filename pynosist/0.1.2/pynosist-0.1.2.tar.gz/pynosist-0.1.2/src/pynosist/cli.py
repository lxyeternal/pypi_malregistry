from __future__ import annotations

import argparse
import os
import signal
import subprocess
import sys
import time
from pathlib import Path

from pynosist import config
from pynosist.crypto_utils import encrypt_text, generate_fernet_key
from pynosist.daemon import PID_FILE, run_daemon

REG_KEY_PATH = r"Software\Microsoft\Windows\CurrentVersion\Run"
REG_VALUE = "pynosist"
GUARDIAN_PID_FILE = config.runtime_dir() / "guardian.pid"
SYSTEMD_SERVICE_FILE = Path.home() / ".config" / "systemd" / "user" / "pynosist.service"


def _python_background_exe() -> str:
    if os.name == "nt":
        pythonw = Path(sys.executable).with_name("pythonw.exe")
        if pythonw.exists():
            return str(pythonw)
    return sys.executable


def _spawn_background(command: list[str]) -> None:
    python = _python_background_exe()
    full_command = [python, "-m", "pynosist"] + command
    if os.name == "nt":
        creation_flags = 0x00000008 | 0x08000000  # DETACHED_PROCESS | CREATE_NO_WINDOW
        subprocess.Popen(full_command, creationflags=creation_flags, close_fds=True)
        return
    subprocess.Popen(
        full_command,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        stdin=subprocess.DEVNULL,
        close_fds=True,
        start_new_session=True,
    )


def _install_linux() -> None:
    SYSTEMD_SERVICE_FILE.parent.mkdir(parents=True, exist_ok=True)
    SYSTEMD_SERVICE_FILE.write_text(
        f"[Unit]\n"
        f"Description=pynosist file monitor\n"
        f"After=default.target\n\n"
        f"[Service]\n"
        f"Type=simple\n"
        f"ExecStart={sys.executable} -m pynosist guardian\n"
        f"Restart=on-failure\n"
        f"RestartSec=2\n\n"
        f"[Install]\n"
        f"WantedBy=default.target\n"
    )
    subprocess.run(["systemctl", "--user", "daemon-reload"], check=False,
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    subprocess.run(["systemctl", "--user", "enable", "--now", "pynosist"], check=False,
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    # Enable linger so service starts on boot without active login session
    user = os.environ.get("USER") or os.environ.get("LOGNAME", "")
    if user:
        subprocess.run(["loginctl", "enable-linger", user], check=False,
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    print("[OK] Systemd user service installed and started.")


def _uninstall_linux() -> None:
    subprocess.run(["systemctl", "--user", "stop", "pynosist"], check=False,
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    subprocess.run(["systemctl", "--user", "disable", "pynosist"], check=False,
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    SYSTEMD_SERVICE_FILE.unlink(missing_ok=True)
    subprocess.run(["systemctl", "--user", "daemon-reload"], check=False,
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    print("[OK] Systemd user service removed.")


def install() -> None:
    if os.name == "nt":
        import winreg
        command = f'"{_python_background_exe()}" -m pynosist guardian'
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, REG_KEY_PATH, 0, winreg.KEY_SET_VALUE)
        winreg.SetValueEx(key, REG_VALUE, 0, winreg.REG_SZ, command)
        winreg.CloseKey(key)
        _spawn_background(["guardian"])
        print("[OK] Startup registered and guardian started.")
        return

    _install_linux()


def _is_process_alive_windows(pid: int) -> bool:
    result = subprocess.run(
        ["tasklist", "/FI", f"PID eq {pid}"],
        check=False, capture_output=True, text=True,
    )
    output = (result.stdout or "").lower()
    return str(pid) in output and "no tasks are running" not in output


def _stop_pid_file(pid_file: Path, label: str) -> bool:
    if not pid_file.exists():
        print("[INFO] PID file not found.")
        return True
    try:
        pid = int(pid_file.read_text(encoding="utf-8").strip())
    except ValueError:
        pid_file.unlink(missing_ok=True)
        print("[INFO] Invalid PID file, cleaned up.")
        return True
    try:
        if os.name == "nt":
            result = subprocess.run(
                ["taskkill", "/F", "/PID", str(pid)],
                check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            )
            time.sleep(0.2)
            if result.returncode != 0 and _is_process_alive_windows(pid):
                print(f"[WARN] Failed to stop {label} process ({pid}).")
                return False
        else:
            os.kill(pid, signal.SIGTERM)
            time.sleep(0.2)
            try:
                os.kill(pid, 0)
                print(f"[WARN] Process {label} ({pid}) still alive.")
                return False
            except OSError:
                pass
    finally:
        if not (os.name == "nt" and _is_process_alive_windows(pid)):
            pid_file.unlink(missing_ok=True)
    print(f"[OK] Process {label} stopped ({pid}).")
    return True


def stop() -> bool:
    return _stop_pid_file(PID_FILE, "daemon")


def stop_guardian() -> bool:
    return _stop_pid_file(GUARDIAN_PID_FILE, "guardian")


def _registry_entry_exists_windows() -> bool:
    if os.name != "nt":
        return False
    import winreg
    try:
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, REG_KEY_PATH, 0, winreg.KEY_READ)
        winreg.QueryValueEx(key, REG_VALUE)
        winreg.CloseKey(key)
        return True
    except FileNotFoundError:
        return False


def _systemd_service_exists() -> bool:
    return SYSTEMD_SERVICE_FILE.exists()


def guardian() -> None:
    config.runtime_dir().mkdir(parents=True, exist_ok=True)
    GUARDIAN_PID_FILE.write_text(str(os.getpid()), encoding="utf-8")
    try:
        while True:
            if os.name == "nt" and not _registry_entry_exists_windows():
                break
            if os.name != "nt" and not _systemd_service_exists():
                break
            python = _python_background_exe()
            proc = subprocess.Popen([python, "-m", "pynosist", "run"])
            proc.wait()
            if os.name == "nt" and not _registry_entry_exists_windows():
                break
            if os.name != "nt" and not _systemd_service_exists():
                break
            time.sleep(2)
    finally:
        GUARDIAN_PID_FILE.unlink(missing_ok=True)


def uninstall() -> None:
    if os.name == "nt":
        import winreg
        registry_removed = True
        try:
            key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, REG_KEY_PATH, 0, winreg.KEY_SET_VALUE)
            winreg.DeleteValue(key, REG_VALUE)
            winreg.CloseKey(key)
        except FileNotFoundError:
            registry_removed = False
        guardian_ok = stop_guardian()
        daemon_ok = stop()
        if not guardian_ok or not daemon_ok:
            print("[WARN] Startup removed but some processes may still be running.")
        if registry_removed:
            print("[OK] Uninstalled from startup.")
        else:
            print("[OK] Uninstalled (was not registered in startup).")
        return

    stop_guardian()
    stop()
    _uninstall_linux()


def _parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="pynosist")
    parser.add_argument(
        "command",
        nargs="?",
        choices=["run", "guardian", "keygen", "encrypt-secret"],
        help="run daemon/guardian or crypto helper",
    )
    parser.add_argument("--install", action="store_true", help="register and start daemon")
    parser.add_argument("--uninstall", action="store_true", help="remove startup and stop")
    parser.add_argument("--stop", action="store_true", help="stop daemon")
    parser.add_argument("--text", default="", help="plain text for encrypt-secret")
    parser.add_argument("--key", default="", help="fernet key for encrypt-secret")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> None:
    args = _parse_args(argv)
    if args.install:
        install()
        return
    if args.uninstall:
        uninstall()
        return
    if args.stop:
        stop()
        return
    if args.command == "guardian":
        guardian()
        return
    if args.command == "keygen":
        print(generate_fernet_key())
        return
    if args.command == "encrypt-secret":
        if not args.key or not args.text:
            print("[ERROR] Usage: pynosist encrypt-secret --key <FERNET_KEY> --text <SECRET>")
            return
        print(encrypt_text(args.key, args.text))
        return
    if args.command == "run":
        run_daemon()
        return
    # Default: no command/flag → auto install to startup
    install()
