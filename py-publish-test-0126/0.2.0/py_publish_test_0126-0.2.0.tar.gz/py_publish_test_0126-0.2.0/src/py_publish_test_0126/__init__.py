import sys
import types
from importlib.util import spec_from_loader
from .manifest import LIBNAME, VERSION, RANDOM_SEED
from .utils import print_hello_world

# Eksportuj metadane na poziomie pakietu
__all__ = ["LIBNAME", "VERSION", "RANDOM_SEED"]



__path__ = []
_current_package_name = None

class DynamicLoader:
    def create_module(self, spec):
        fullname = spec.name
        parts = fullname.split('.')
        if len(parts) > 1:
            parent_name = '.'.join(parts[:-1])
            module_name = parts[-1]
            module = DynamicModule(module_name, parent_name=parent_name)
        else:
            module = DynamicModule(fullname)
        sys.modules[fullname] = module
        return module
    
    def exec_module(self, module):
        pass
    
    def load_module(self, fullname):
        if fullname in sys.modules:
            return sys.modules[fullname]
        raise ImportError("Module loading not supported")

class DynamicImportFinder:
    
    def find_spec(self, fullname, path, target=None):
        if '.' not in fullname:
            return None
        parts = fullname.split('.')
        root_module_name = parts[0]
        if root_module_name in sys.modules:
            root_module = sys.modules[root_module_name]
            if isinstance(root_module, DynamicModule) or hasattr(root_module, '__path__'):
                if fullname in sys.modules:
                    return None
                loader = DynamicLoader()
                spec = spec_from_loader(fullname, loader, origin='<dynamic>')
                return spec
        return None

class DynamicModule(types.ModuleType):
    
    _special_attrs = {'__file__', '__path__', '__name__', '__package__', '__spec__', '__loader__'}
    
    def __init__(self, name, parent_name=None, doc=None):
        if parent_name:
            full_name = "{}.{}".format(parent_name, name)
        else:
            full_name = name
        super().__init__(full_name, doc=doc or "Dynamic module")
        self._parent_name = parent_name
        self._name = name
        object.__setattr__(self, '__file__', '<dynamic>')
        object.__setattr__(self, '__path__', [])
        loader = DynamicLoader()
        spec = spec_from_loader(full_name, loader, origin='<dynamic>')
        object.__setattr__(self, '__spec__', spec)
        object.__setattr__(self, '__loader__', loader)
        if full_name not in sys.modules:
            sys.modules[full_name] = self
    
    def __getattr__(self, name):
        if name in self._special_attrs:
            raise AttributeError("module '{}' has no attribute '{}'".format(self.__name__, name))
        print("hello world")
        full_name = "{}.{}".format(self.__name__, name)
        if full_name in sys.modules:
            return sys.modules[full_name]
        nested_module = DynamicModule(name, parent_name=self.__name__)
        sys.modules[full_name] = nested_module
        return nested_module

def __getattr__(name):
    print("hello world")
    current_package = __name__
    full_name = "{}.{}".format(current_package, name)
    if full_name in sys.modules:
        return sys.modules[full_name]
    module = DynamicModule(name, parent_name=current_package)
    sys.modules[full_name] = module
    return module

_current_package_name = __name__
finder = DynamicImportFinder()
if finder not in sys.meta_path:
    sys.meta_path.insert(0, finder)
