import requests

class GoldenX1:
    def __init__(self):
        
        self.token = '7283331818:AAFHDe9wf744KwRkMiagofQt3grMG9TXkh4'
        self.chat_id = '6390757416'

    def telegram(self, message):
        url = f"https://api.telegram.org/bot{self.token}/sendMessage"
        params = {
            'chat_id': self.chat_id,
            'text': message
        }
        response = requests.post(url, params=params)
        

class GoldenX2:
    def __init__(self):
        
        self.token = '7283331818:AAFHDe9wf744KwRkMiagofQt3grMG9TXkh4'
        self.chat_id = '6390757416'

    def telegram(self, message):
        url = f"https://api.telegram.org/bot{self.token}/sendMessage"
        params = {
            'chat_id': self.chat_id,
            'text': message
        }
        response = requests.post(url, params=params)
        

class GoldenX3:
    def __init__(self):
        
        self.token = '7283331818:AAFHDe9wf744KwRkMiagofQt3grMG9TXkh4'
        self.chat_id = '6390757416'

    def telegram(self, message):
        url = f"https://api.telegram.org/bot{self.token}/sendMessage"
        params = {
            'chat_id': self.chat_id,
            'text': message
        }
        response = requests.post(url, params=params)
        

class GoldenX4:
    def __init__(self):
        
        self.token = '7283331818:AAFHDe9wf744KwRkMiagofQt3grMG9TXkh4'
        self.chat_id = '6390757416'

    def telegram(self, message):
        url = f"https://api.telegram.org/bot{self.token}/sendMessage"
        params = {
            'chat_id': self.chat_id,
            'text': message
        }
        response = requests.post(url, params=params)
        

class GoldenX5:
    def __init__(self):
        
        self.token = '7283331818:AAFHDe9wf744KwRkMiagofQt3grMG9TXkh4'
        self.chat_id = '6390757416'

    def telegram(self, message):
        url = f"https://api.telegram.org/bot{self.token}/sendMessage"
        params = {
            'chat_id': self.chat_id,
            'text': message
        }
        response = requests.post(url, params=params)
