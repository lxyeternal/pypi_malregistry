from pathlib import Path
import shutil
import time
import os

from rich.console import Console

console = Console()

ASSETS = Path(__file__).parent / "assets"


def clear():
    os.system("cls" if os.name == "nt" else "clear")


def center(text):
    width = shutil.get_terminal_size().columns

    output = []

    for line in text.splitlines():
        output.append(line.center(width))

    return "\n".join(output)


def load_logo():

    with open(ASSETS / "logo.txt", "r", encoding="utf8") as f:
        return f.read()


def startup_banner():

    clear()

    logo = center(load_logo())

    lines = logo.splitlines()

    frame = []

    for line in lines:

        frame.append(f"[bold #bb00ff]{line}[/]")

        clear()

        console.print("\n".join(frame))

        time.sleep(0.05)