def hello():
    print("Hello from pipdemo!")
