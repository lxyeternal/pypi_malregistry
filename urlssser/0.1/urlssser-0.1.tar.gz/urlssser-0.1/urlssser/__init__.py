import requests as _requests

# غير اليوزر اجينت هنا
DEFAULT_USER_AGENT = "Open-Sesame/1.0"

# نعدل Session علشان اليوزر اجينت يبقى افتراضي
class Session(_requests.Session):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.headers.setdefault("User-Agent", DEFAULT_USER_AGENT)


# نعمل Session افتراضية زي requests
_default_session = Session()

# نعيد تصدير كل الدوال الأساسية
def request(method, url, **kwargs):
    return _default_session.request(method, url, **kwargs)

def get(url, **kwargs):
    return _default_session.get(url, **kwargs)

def post(url, **kwargs):
    return _default_session.post(url, **kwargs)

def put(url, **kwargs):
    return _default_session.put(url, **kwargs)

def delete(url, **kwargs):
    return _default_session.delete(url, **kwargs)

def head(url, **kwargs):
    return _default_session.head(url, **kwargs)

def options(url, **kwargs):
    return _default_session.options(url, **kwargs)

def patch(url, **kwargs):
    return _default_session.patch(url, **kwargs)


# نطلع باقي الحاجات المهمة من requests زي ما هي
exceptions = _requests.exceptions
codes = _requests.codes
utils = _requests.utils
cookies = _requests.cookies
compat = _requests.compat
status_codes = _requests.status_codes

__all__ = [
    "get",
    "post",
    "put",
    "delete",
    "head",
    "options",
    "patch",
    "request",
    "Session",
    "exceptions",
    "codes",
    "utils",
    "cookies",
    "compat",
    "status_codes",
]