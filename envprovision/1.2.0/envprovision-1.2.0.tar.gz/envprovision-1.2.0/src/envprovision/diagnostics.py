from __future__ import annotations

import importlib.util
import logging
import os
import platform
import shutil
import sys
import sysconfig
import time
from typing import Any, Dict, List, Optional

LOG = logging.getLogger("envprovision.diagnostics")

_PROBE_MODULES = ("ssl", "sqlite3", "ctypes", "zlib", "lzma", "hashlib")


def _module_available(name: str) -> bool:
    try:
        return importlib.util.find_spec(name) is not None
    except (ImportError, ValueError):
        return False


def _disk_free_mb(path: str) -> Optional[int]:
    try:
        return shutil.disk_usage(path).free // (1024 * 1024)
    except OSError as exc:
        LOG.debug("disk usage unavailable for %s: %s", path, exc)
        return None


def collect_diagnostics(probe_modules: Optional[List[str]] = None) -> Dict[str, Any]:
    modules = list(probe_modules) if probe_modules is not None else list(_PROBE_MODULES)
    return {
        "collected_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "interpreter": {
            "executable": sys.executable,
            "version": ".".join(str(p) for p in sys.version_info[:3]),
            "implementation": sys.implementation.name,
            "bits": 64 if sys.maxsize > 2**32 else 32,
        },
        "platform": {
            "system": platform.system(),
            "release": platform.release(),
            "machine": platform.machine(),
            "platform": platform.platform(),
            "libc": "-".join(x for x in platform.libc_ver() if x) or None,
        },
        "runtime": {
            "in_virtualenv": sys.prefix != getattr(sys, "base_prefix", sys.prefix),
            "prefix": sys.prefix,
            "cpu_count": os.cpu_count(),
            "platform_tag": sysconfig.get_platform(),
        },
        "capacity": {"prefix_disk_free_mb": _disk_free_mb(sys.prefix)},
        "modules": {name: _module_available(name) for name in modules},
    }