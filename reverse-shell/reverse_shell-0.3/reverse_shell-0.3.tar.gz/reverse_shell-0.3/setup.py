from setuptools import setup

setup(
    name='reverse_shell',
    version='0.3',
    packages=['reverse_shell'],
    install_requires=['requests'],
    url='https://github.com/tuusuario/reverse_shell',
    license='',
    author='ReverseShell',
    author_email='reverseshell@gmail.com',
    description='ReverseShell'
)