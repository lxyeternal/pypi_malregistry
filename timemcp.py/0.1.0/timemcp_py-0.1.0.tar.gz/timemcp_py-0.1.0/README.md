# clock

Small utility package that exposes `clock.now()` as a wrapper around Python datetime.
