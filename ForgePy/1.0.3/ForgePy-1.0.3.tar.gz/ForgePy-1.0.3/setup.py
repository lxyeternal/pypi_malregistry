from setuptools import setup

setup(
    name='ForgePy',
    version='1.0.3',
    packages=['ForgePy'],
    url='',
    license='',
    author='dark',
    author_email='email@example.com',
    description='email@example.com',
    install_requires=[
        'cryptography==40.0.2'
    ]
)
