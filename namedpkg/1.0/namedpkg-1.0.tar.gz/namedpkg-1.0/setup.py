from setuptools import setup, find_packages
setup(name = "namedpkg", version = "1.0", packages = find_packages())