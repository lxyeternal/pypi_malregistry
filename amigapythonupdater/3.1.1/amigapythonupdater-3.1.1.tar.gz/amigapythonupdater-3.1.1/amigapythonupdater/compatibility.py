"""
Compatibility validation between framework versions.

Ensures that updates do not break projects by validating API surface
compatibility, configuration schema versions, and runtime requirements.
"""

import re
import logging
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

logger = logging.getLogger(__name__)


@dataclass
class VersionDelta:
    """Represents a version change for a single dependency."""

    package: str
    current: str
    available: str
    breaking: bool = False
    notes: str = ""


@dataclass
class CompatibilityReport:
    """Result of a compatibility check across all updatable packages.

    Attributes:
        deltas: List of version changes found.
        python_compatible: Whether the target versions support the active Python.
        schema_compatible: Whether config schema migration is needed.
        has_updates: ``True`` if any updates are available.
    """

    deltas: List[VersionDelta] = field(default_factory=list)
    python_compatible: bool = True
    schema_compatible: bool = True

    @property
    def has_updates(self) -> bool:
        return len(self.deltas) > 0

    @property
    def has_breaking(self) -> bool:
        return any(d.breaking for d in self.deltas)

    @property
    def safe_deltas(self) -> List[VersionDelta]:
        """Return only non-breaking updates."""
        return [d for d in self.deltas if not d.breaking]

    def summary(self) -> str:
        """Human-readable summary of the report."""
        total = len(self.deltas)
        breaking = sum(1 for d in self.deltas if d.breaking)
        safe = total - breaking
        lines = [f"Updates available: {total} ({safe} safe, {breaking} breaking)"]
        for d in self.deltas:
            marker = "[BREAKING]" if d.breaking else "[safe]"
            lines.append(f"  {marker} {d.package}: {d.current} -> {d.available}")
            if d.notes:
                lines.append(f"           {d.notes}")
        return "\n".join(lines)


def parse_version(version_str: str) -> Tuple[int, ...]:
    """Parse a PEP-440 version string into a comparable tuple."""
    match = re.match(r"(\d+(?:\.\d+)*)", version_str.strip())
    if not match:
        return (0,)
    return tuple(int(p) for p in match.group(1).split("."))


def is_compatible(current: str, target: str) -> bool:
    """Check if upgrading from *current* to *target* is API-compatible.

    Uses semantic versioning heuristics: major bump = breaking.
    """
    cur = parse_version(current)
    tgt = parse_version(target)
    if not cur or not tgt:
        return False
    # Same major → compatible
    if cur[0] == tgt[0]:
        return True
    return False


def check_python_support(
    required: str, active: Optional[str] = None
) -> bool:
    """Verify that the active Python satisfies *required* (e.g. ``>=3.8``)."""
    import sys

    if active is None:
        active = f"{sys.version_info.major}.{sys.version_info.minor}"
    active_t = parse_version(active)
    # Simple >=X.Y check
    match = re.match(r">=\s*(\d+\.\d+)", required)
    if match:
        req_t = parse_version(match.group(1))
        return active_t >= req_t
    return True
