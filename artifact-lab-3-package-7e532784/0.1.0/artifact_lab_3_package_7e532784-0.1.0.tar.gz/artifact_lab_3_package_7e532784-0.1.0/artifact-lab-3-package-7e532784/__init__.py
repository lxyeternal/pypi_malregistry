# __init__.py
from .main import send_data
