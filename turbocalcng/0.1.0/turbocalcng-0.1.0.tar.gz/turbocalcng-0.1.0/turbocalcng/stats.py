"""Statistical functions — mean, median, variance, stdev, percentiles."""

import math


def mean(data):
    if not data:
        raise ValueError("data must not be empty")
    return sum(data) / len(data)


def median(data):
    if not data:
        raise ValueError("data must not be empty")
    s = sorted(data)
    n = len(s)
    mid = n // 2
    if n % 2 == 0:
        return (s[mid - 1] + s[mid]) / 2
    return s[mid]


def variance(data, population=False):
    if not data:
        raise ValueError("data must not be empty")
    m = mean(data)
    ss = sum((x - m) ** 2 for x in data)
    n = len(data) if population else len(data) - 1
    if n == 0:
        raise ValueError("need at least 2 values for sample variance")
    return ss / n


def stdev(data, population=False):
    return math.sqrt(variance(data, population))


def percentile(data, p):
    if not data:
        raise ValueError("data must not be empty")
    if not 0 <= p <= 100:
        raise ValueError("percentile must be between 0 and 100")
    s = sorted(data)
    k = (len(s) - 1) * p / 100
    f = math.floor(k)
    c = math.ceil(k)
    if f == c:
        return s[int(k)]
    return s[f] * (c - k) + s[c] * (k - f)


def covariance(x, y):
    if len(x) != len(y):
        raise ValueError("x and y must have the same length")
    if len(x) < 2:
        raise ValueError("need at least 2 values")
    mx, my = mean(x), mean(y)
    return sum((xi - mx) * (yi - my) for xi, yi in zip(x, y)) / (len(x) - 1)


def correlation(x, y):
    sx, sy = stdev(x), stdev(y)
    if sx == 0 or sy == 0:
        raise ValueError("standard deviation is zero")
    return covariance(x, y) / (sx * sy)


def zscore(data):
    m = mean(data)
    s = stdev(data, population=True)
    if s == 0:
        raise ValueError("standard deviation is zero")
    return [(x - m) / s for x in data]


def describe(data):
    return {
        "count": len(data),
        "mean": mean(data),
        "median": median(data),
        "stdev": stdev(data) if len(data) > 1 else 0.0,
        "min": min(data),
        "max": max(data),
        "p25": percentile(data, 25),
        "p75": percentile(data, 75),
    }
