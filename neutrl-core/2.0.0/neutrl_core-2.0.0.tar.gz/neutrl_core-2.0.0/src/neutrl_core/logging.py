"""Structured logging configuration using structlog."""

from __future__ import annotations

import logging
import sys
from enum import Enum
from typing import Any

import structlog


class LogLevel(str, Enum):
    """Supported log levels."""
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"


def setup_logging(
    level: str | LogLevel = LogLevel.INFO,
    format: str = "json",
    service_name: str = "neutrl",
) -> None:
    """Configure structured logging for a Neutrl service.

    Sets up structlog with processors for adding context, timestamps,
    and formatting. Supports both JSON and human-readable console output.

    Args:
        level: Minimum log level.
        format: Output format — "json" for machine-readable or "console"
            for human-readable colored output.
        service_name: Service name added to every log entry.

    Example:
        >>> setup_logging(level="INFO", format="json", service_name="trading-engine")
        >>> log = get_logger("positions")
        >>> log.info("position_opened", symbol="ETH-PERP", size=1.5)
    """
    if isinstance(level, str):
        level = LogLevel(level.upper())

    shared_processors: list[Any] = [
        structlog.contextvars.merge_contextvars,
        structlog.processors.add_log_level,
        structlog.processors.StackInfoRenderer(),
        structlog.dev.set_exc_info,
        structlog.processors.TimeStamper(fmt="iso"),
    ]

    if format == "json":
        renderer: Any = structlog.processors.JSONRenderer()
    else:
        renderer = structlog.dev.ConsoleRenderer(
            colors=sys.stderr.isatty(),
        )

    structlog.configure(
        processors=[
            *shared_processors,
            structlog.processors.format_exc_info,
            renderer,
        ],
        wrapper_class=structlog.make_filtering_bound_logger(
            getattr(logging, level.value)
        ),
        context_class=dict,
        logger_factory=structlog.PrintLoggerFactory(file=sys.stderr),
        cache_logger_on_first_use=True,
    )

    logging.basicConfig(
        format="%(message)s",
        stream=sys.stderr,
        level=getattr(logging, level.value),
    )

    stdlib_logger = logging.getLogger()
    stdlib_logger.setLevel(getattr(logging, level.value))

    for name in ("urllib3", "httpx", "httpcore", "web3"):
        logging.getLogger(name).setLevel(logging.WARNING)

    log = get_logger("neutrl.core")
    log.info(
        "logging_configured",
        level=level.value,
        format=format,
        service=service_name,
    )


def get_logger(name: str | None = None) -> Any:
    """Get a structlog logger instance.

    Args:
        name: Logger name (e.g., "trading.positions"). If None, uses the
            root logger.

    Returns:
        A structlog BoundLogger with context-variable merging.

    Example:
        >>> log = get_logger("staking")
        >>> log.info("stake_processed", amount=1000, user="0xabc...")
    """
    return structlog.get_logger(name)


def bind_context(**kwargs: Any) -> None:
    """Bind key-value pairs to the current context.

    Values are included in all subsequent log entries within the same
    async context (or thread). Use for request IDs, user IDs, etc.

    Args:
        **kwargs: Key-value pairs to bind.

    Example:
        >>> bind_context(request_id="abc-123", user="0xdef...")
        >>> log.info("processing")  # includes request_id and user
    """
    structlog.contextvars.bind_contextvars(**kwargs)


def clear_context() -> None:
    """Clear all bound context variables."""
    structlog.contextvars.clear_contextvars()
