"""Core knowledge base primitives.

Copyright (c) 2026 4us71n0. Released under the MIT License.

The default implementation is dependency-free: documents are held in memory,
persisted as JSON, and ranked with a simple term-frequency score. It is meant
as a small, predictable base that heavier retrieval backends can build on.
"""

from __future__ import annotations

import json
import math
import re
from collections import Counter
from collections.abc import Iterable, Iterator
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Union

__all__ = ["Document", "KnowledgeBase", "SearchResult", "tokenize"]

_TOKEN_RE = re.compile(r"[a-z0-9]+")

PathLike = Union[str, Path]


def tokenize(text: str) -> list[str]:
    """Split text into lowercase alphanumeric tokens."""
    return _TOKEN_RE.findall(text.lower())


@dataclass
class Document:
    """A single knowledge base entry."""

    id: str
    text: str
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {"id": self.id, "text": self.text, "metadata": self.metadata}

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Document:
        return cls(
            id=str(data["id"]),
            text=str(data["text"]),
            metadata=dict(data.get("metadata") or {}),
        )


@dataclass
class SearchResult:
    """A document paired with its relevance score for a query."""

    document: Document
    score: float


class KnowledgeBase:
    """An in-memory collection of documents with keyword search."""

    def __init__(self, documents: Iterable[Document] | None = None) -> None:
        self._documents: dict[str, Document] = {}
        for document in documents or ():
            self.add(document)

    def __len__(self) -> int:
        return len(self._documents)

    def __iter__(self) -> Iterator[Document]:
        return iter(self._documents.values())

    def __contains__(self, doc_id: object) -> bool:
        return doc_id in self._documents

    def add(self, document: Document) -> Document:
        """Insert a document, replacing any existing entry with the same id."""
        self._documents[document.id] = document
        return document

    def add_text(
        self,
        doc_id: str,
        text: str,
        metadata: dict[str, Any] | None = None,
    ) -> Document:
        """Convenience wrapper around :meth:`add`."""
        return self.add(Document(id=doc_id, text=text, metadata=dict(metadata or {})))

    def get(self, doc_id: str) -> Document | None:
        return self._documents.get(doc_id)

    def remove(self, doc_id: str) -> bool:
        """Delete a document. Returns ``True`` if it existed."""
        return self._documents.pop(doc_id, None) is not None

    def search(self, query: str, limit: int = 5) -> list[SearchResult]:
        """Rank documents against ``query`` using tf-idf style scoring.

        Matching is exact on lowercased tokens — there is no stemming, so
        ``"refund"`` does not match ``"refunds"``.
        """
        terms = tokenize(query)
        if not terms or not self._documents:
            return []

        total_docs = len(self._documents)
        doc_tokens = {
            doc_id: Counter(tokenize(doc.text)) for doc_id, doc in self._documents.items()
        }
        doc_freq = {
            term: sum(1 for counts in doc_tokens.values() if counts[term]) for term in set(terms)
        }

        results: list[SearchResult] = []
        for doc_id, counts in doc_tokens.items():
            length = sum(counts.values()) or 1
            score = 0.0
            for term in terms:
                if not counts[term] or not doc_freq[term]:
                    continue
                idf = math.log(1 + total_docs / doc_freq[term])
                score += (counts[term] / length) * idf
            if score > 0:
                results.append(SearchResult(document=self._documents[doc_id], score=score))

        results.sort(key=lambda result: (-result.score, result.document.id))
        return results[:limit] if limit > 0 else results

    def to_dict(self) -> dict[str, Any]:
        return {"version": 1, "documents": [doc.to_dict() for doc in self._documents.values()]}

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> KnowledgeBase:
        return cls(Document.from_dict(item) for item in data.get("documents", []))

    def save(self, path: PathLike) -> Path:
        """Write the knowledge base to ``path`` as JSON."""
        target = Path(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(json.dumps(self.to_dict(), indent=2), encoding="utf-8")
        return target

    @classmethod
    def load(cls, path: PathLike) -> KnowledgeBase:
        """Read a knowledge base previously written by :meth:`save`."""
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        return cls.from_dict(data)
