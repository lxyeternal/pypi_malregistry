"""Parse an interactive selection string into zero-based indices.

    "all"        -> every index
    "none" / ""  -> []
    "1,3-5"      -> [0, 2, 3, 4]

Out-of-range and malformed tokens are ignored. Mirrors the npm `select.js`.
"""

from __future__ import annotations

import re


def parse_selection(text, count):
    s = str(text if text is not None else "").strip().lower()
    if s in ("", "none", "q", "quit"):
        return []
    if s in ("all", "*", "a"):
        return list(range(count))

    picked = set()
    for part in s.split(","):
        token = part.strip()
        if not token:
            continue
        m = re.match(r"^(\d+)\s*-\s*(\d+)$", token)
        if m:
            a, b = int(m.group(1)), int(m.group(2))
            if a > b:
                a, b = b, a
            for n in range(a, b + 1):
                _add_one_based(picked, n, count)
        elif re.match(r"^\d+$", token):
            _add_one_based(picked, int(token), count)
        # ignore anything else
    return sorted(picked)


def _add_one_based(picked, one_based, count):
    idx = one_based - 1
    if 0 <= idx < count:
        picked.add(idx)
