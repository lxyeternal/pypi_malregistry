"""
dbhandler.models - Lightweight ORM-style BaseModel.
"""

from __future__ import annotations

from typing import Any, ClassVar, Dict, List, Optional, TYPE_CHECKING

from .exceptions import ModelError

if TYPE_CHECKING:
    from .core import DBHandler


class ModelMeta(type):
    """Metaclass that collects declared fields."""

    def __new__(mcs, name, bases, namespace):
        fields = {}
        for key, val in list(namespace.items()):
            if isinstance(val, Field):
                fields[key] = val
        namespace["_fields"] = fields
        cls = super().__new__(mcs, name, bases, namespace)
        return cls


class Field:
    """
    Descriptor representing a database column.

    Example:
        class User(BaseModel):
            __table__ = "users"
            name  = Field(str, nullable=False)
            email = Field(str, nullable=False, unique=True)
            age   = Field(int, default=0)
    """

    _TYPE_MAP = {
        int:   "INTEGER",
        float: "REAL",
        str:   "TEXT",
        bool:  "INTEGER",
        bytes: "BLOB",
    }

    def __init__(
        self,
        type_: type = str,
        *,
        nullable: bool = True,
        default: Any = None,
        unique: bool = False,
        primary_key: bool = False,
    ):
        self.type_ = type_
        self.nullable = nullable
        self.default = default
        self.unique = unique
        self.primary_key = primary_key
        self.name: Optional[str] = None  # set by BaseModel.__init_subclass__

    def sql_type(self) -> str:
        return self._TYPE_MAP.get(self.type_, "TEXT")

    def column_def(self) -> str:
        parts = [self.name, self.sql_type()]
        if self.primary_key:
            parts.append("PRIMARY KEY AUTOINCREMENT")
        else:
            if not self.nullable:
                parts.append("NOT NULL")
            if self.unique:
                parts.append("UNIQUE")
            if self.default is not None:
                parts.append(f"DEFAULT {self.default!r}")
        return " ".join(parts)

    def __set_name__(self, owner, name):
        self.name = name

    def __get__(self, obj, objtype=None):
        if obj is None:
            return self
        return obj.__dict__.get(self.name, self.default)

    def __set__(self, obj, value):
        obj.__dict__[self.name] = value


class BaseModel(metaclass=ModelMeta):
    """
    Lightweight ORM-style base class.

    Subclass this to define a table model:

        class User(BaseModel):
            __table__ = "users"
            __db__: DBHandler = None  # set at runtime

            id    = Field(int, primary_key=True)
            name  = Field(str, nullable=False)
            email = Field(str, nullable=False, unique=True)
            age   = Field(int, default=0)

        # Bind database connection
        User.__db__ = db

        # Create the table
        User.create_table()

        # Insert
        user = User(name="Alice", email="alice@example.com", age=30)
        user.save()

        # Query
        users = User.all()
        alice = User.get(id=1)

        # Update
        alice.age = 31
        alice.save()

        # Delete
        alice.delete()
    """

    __table__: ClassVar[str] = ""
    __db__: ClassVar[Optional["DBHandler"]] = None
    _fields: ClassVar[Dict[str, Field]] = {}

    def __init__(self, **kwargs: Any):
        self._pk_value: Optional[Any] = None
        for name, field in self.__class__._fields.items():
            value = kwargs.pop(name, field.default)
            setattr(self, name, value)
        if kwargs:
            raise ModelError(f"Unknown fields: {', '.join(kwargs)}")

    # ------------------------------------------------------------------
    # Class-level helpers
    # ------------------------------------------------------------------

    @classmethod
    def _db(cls) -> "DBHandler":
        if cls.__db__ is None:
            raise ModelError(
                f"No database bound to {cls.__name__}. Set {cls.__name__}.__db__ = db."
            )
        return cls.__db__

    @classmethod
    def _pk_field(cls) -> Optional[str]:
        for name, field in cls._fields.items():
            if field.primary_key:
                return name
        return None

    @classmethod
    def _non_pk_fields(cls) -> Dict[str, Field]:
        return {n: f for n, f in cls._fields.items() if not f.primary_key}

    # ------------------------------------------------------------------
    # Schema
    # ------------------------------------------------------------------

    @classmethod
    def create_table(cls, if_not_exists: bool = True) -> None:
        """Create the table in the database based on declared fields."""
        modifier = "IF NOT EXISTS " if if_not_exists else ""
        col_defs = [f.column_def() for f in cls._fields.values()]
        sql = f"CREATE TABLE {modifier}{cls.__table__} ({', '.join(col_defs)})"
        cls._db().execute(sql)
        cls._db().commit()

    @classmethod
    def drop_table(cls, if_exists: bool = True) -> None:
        """Drop the table from the database."""
        modifier = "IF EXISTS " if if_exists else ""
        cls._db().execute(f"DROP TABLE {modifier}{cls.__table__}")
        cls._db().commit()

    # ------------------------------------------------------------------
    # CRUD
    # ------------------------------------------------------------------

    def save(self) -> None:
        """Insert or update this instance in the database."""
        pk = self.__class__._pk_field()
        data = {
            name: getattr(self, name)
            for name, field in self.__class__._non_pk_fields().items()
        }
        db = self.__class__._db()

        if pk and getattr(self, pk) is not None:
            # UPDATE
            pk_val = getattr(self, pk)
            ph = db._single_placeholder()
            db.update(
                self.__class__.__table__,
                data,
                where=f"{pk} = {ph}",
                where_params=(pk_val,),
            )
        else:
            # INSERT
            row_id = db.insert(self.__class__.__table__, data)
            if pk:
                setattr(self, pk, row_id)
        db.commit()

    def delete(self) -> None:
        """Delete this instance from the database."""
        pk = self.__class__._pk_field()
        if pk is None:
            raise ModelError("Cannot delete: no primary key defined.")
        pk_val = getattr(self, pk)
        if pk_val is None:
            raise ModelError("Cannot delete: primary key value is None.")
        db = self.__class__._db()
        ph = db._single_placeholder()
        db.delete(self.__class__.__table__, where=f"{pk} = {ph}", params=(pk_val,))
        db.commit()

    @classmethod
    def get(cls, **kwargs: Any) -> Optional["BaseModel"]:
        """Return the first matching row as a model instance, or None."""
        db = cls._db()
        ph = db._single_placeholder()
        where = " AND ".join(f"{k} = {ph}" for k in kwargs)
        params = tuple(kwargs.values())
        row = db.fetchone(f"SELECT * FROM {cls.__table__} WHERE {where}", params)
        return cls._from_row(row) if row else None

    @classmethod
    def all(cls) -> List["BaseModel"]:
        """Return all rows as a list of model instances."""
        rows = cls._db().fetchall(f"SELECT * FROM {cls.__table__}")
        return [cls._from_row(r) for r in rows]

    @classmethod
    def filter(cls, where: str, params: tuple = ()) -> List["BaseModel"]:
        """
        Return filtered rows as model instances.

        Example:
            adults = User.filter("age >= ?", (18,))
        """
        rows = cls._db().fetchall(
            f"SELECT * FROM {cls.__table__} WHERE {where}", params
        )
        return [cls._from_row(r) for r in rows]

    @classmethod
    def count(cls, where: Optional[str] = None, params: tuple = ()) -> int:
        """Return the number of rows matching an optional WHERE clause."""
        sql = f"SELECT COUNT(*) AS n FROM {cls.__table__}"
        if where:
            sql += f" WHERE {where}"
        row = cls._db().fetchone(sql, params or None)
        return int(row["n"]) if row else 0

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    @classmethod
    def _from_row(cls, row: Dict[str, Any]) -> "BaseModel":
        instance = cls.__new__(cls)
        instance._pk_value = None
        for name, field in cls._fields.items():
            setattr(instance, name, row.get(name, field.default))
        return instance

    def to_dict(self) -> Dict[str, Any]:
        """Return the model instance as a plain dictionary."""
        return {name: getattr(self, name) for name in self.__class__._fields}

    def __repr__(self) -> str:
        fields = ", ".join(
            f"{k}={v!r}" for k, v in self.to_dict().items()
        )
        return f"<{self.__class__.__name__} {fields}>"
