# pip-RCE
POC of RCE through unsafe pip package

## Usage
You can modify the remote `IP` and `PORT` by yourself.

use `python3 setup.py sdist` to build the package.

use `twine upload dist/*` to upload the package to pypi.