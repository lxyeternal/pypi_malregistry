import textwrap
import shutil

def format_block(text, width=None, indent=0):
    """
    Wraps text to the specified width, defaulting to the terminal width.
    """
    if not width:
        # Get terminal width, fallback to 80
        width = shutil.get_terminal_size((80, 20)).columns
    
    prefix = " " * indent
    wrapper = textwrap.TextWrapper(
        width=width,
        initial_indent=prefix,
        subsequent_indent=prefix,
        break_long_words=False,
        replace_whitespace=False
    )
    return wrapper.fill(text)

def align_columns(data, padding=4):
    """
    Simple helper to align list data into columns.
    """
    if not data:
        return ""
    col_width = max(len(str(x)) for x in data) + padding
    return "".join(str(x).ljust(col_width) for x in data)

def dedent(text):
    """
    Dedents text by removing common leading whitespace.
    """
    return textwrap.dedent(text)