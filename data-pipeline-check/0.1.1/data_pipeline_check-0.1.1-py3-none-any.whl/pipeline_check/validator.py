"""Data pipeline configuration validator."""
import os, json, yaml

class PipelineValidator:
    def __init__(self):
        self.errors = []
    
    def validate_config(self, path):
        if not os.path.exists(path):
            return [f"Config file not found: {path}"]
        try:
            with open(path) as f:
                if path.endswith('.json'):
                    data = json.load(f)
                elif path.endswith(('.yaml', '.yml')):
                    try:
                        data = yaml.safe_load(f)
                    except:
                        return ["Cannot parse YAML (install pyyaml for YAML support)"]
                else:
                    return [f"Unsupported format: {path}"]
            
            checks = []
            if 'source' not in data and 'input' not in data:
                checks.append("Missing 'source' or 'input' field")
            if 'steps' not in data and 'pipeline' not in data:
                checks.append("No pipeline steps defined")
            return checks
        except Exception as e:
            return [str(e)]
    
    def scan_directory(self, directory="."):
        results = {}
        for fn in os.listdir(directory):
            if fn.endswith(('.json', '.yaml', '.yml', '.toml')):
                results[fn] = self.validate_config(os.path.join(directory, fn))
        return results
