"""Exception hierarchy for Neutrl Core library."""

from __future__ import annotations


class NeutrlCoreError(Exception):
    """Base exception for all neutrl-core errors."""


class ConfigurationError(NeutrlCoreError):
    """Raised when required configuration is missing or invalid."""

    def __init__(self, field: str, reason: str) -> None:
        self.field = field
        self.reason = reason
        super().__init__(f"Configuration error for '{field}': {reason}")


class ProviderError(NeutrlCoreError):
    """Raised when an RPC provider returns an error."""

    def __init__(self, endpoint: str, error: str) -> None:
        self.endpoint = endpoint
        self.error = error
        super().__init__(f"Provider {endpoint}: {error}")


class AllProvidersDownError(NeutrlCoreError):
    """Raised when all configured RPC providers are unreachable."""

    def __init__(self, chain_id: int, tried: int) -> None:
        self.chain_id = chain_id
        self.tried = tried
        super().__init__(
            f"All {tried} providers down for chain {chain_id}"
        )


class RetryExhaustedError(NeutrlCoreError):
    """Raised when all retry attempts have been exhausted."""

    def __init__(self, attempts: int, last_error: Exception) -> None:
        self.attempts = attempts
        self.last_error = last_error
        super().__init__(
            f"Retry exhausted after {attempts} attempts: {last_error}"
        )
