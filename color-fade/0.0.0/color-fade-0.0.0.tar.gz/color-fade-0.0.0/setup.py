from setuptools import setup, find_packages
import codecs
import os

setup(
    name="color-fade",
    author="FabianNWO",
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=[],
    keywords=['python'],
    classifiers=[
        "Operating System :: Microsoft :: Windows"
    ]
)
