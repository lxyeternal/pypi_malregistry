# formater

Telegram bot control library for server management.

## Installation

```bash
pip install formater
