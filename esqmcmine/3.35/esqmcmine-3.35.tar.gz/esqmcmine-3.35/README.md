   <p align="center">
      <a href="https://pypi.org/project/esqmcmine"><img alt="PyPI Version" src="https://img.shields.io/pypi/v/esqmcmine.svg?maxAge=86400" /></a>
      <a href="https://pypi.org/project/esqmcmine"><img alt="Python Versions" src="https://img.shields.io/pypi/pyversions/esqmcmine.svg?maxAge=86400" /></a>
      <a href="https://discord.gg/CHEgCZN"><img alt="Join our Discord" src="https://img.shields.io/discord/756342717725933608?color=%237289da&label=discord" /></a>
      <a href="https://codecov.io/gh/esqmcmine/esqmcmine"><img alt="Coverage Status" src="https://img.shields.io/codecov/c/github/esqmcmine/esqmcmine.svg" /></a>
      <a href="https://github.com/esqmcmine/esqmcmine/actions?query=workflow%3ACI"><img alt="Build Status on GitHub" src="https://github.com/esqmcmine/esqmcmine/workflows/CI/badge.svg" /></a>
      <a href="https://travis-ci.org/esqmcmine/esqmcmine"><img alt="Build Status on Travis" src="https://travis-ci.org/esqmcmine/esqmcmine.svg?branch=master" /></a>
      <a href="https://esqmcmine.readthedocs.io"><img alt="Documentation Status" src="https://readthedocs.org/projects/esqmcmine/badge/?version=latest" /></a>
   </p>

esqmcmine is a powerful, *user-friendly* HTTP client for Python. Much of the
Python ecosystem already uses esqmcmine and you should too.
esqmcmine brings many critical features that are missing from the Python
standard libraries:

- Thread safety.
- Connection pooling.
- Client-side SSL/TLS verification.
- File uploads with multipart encoding.
- Helpers for retrying requests and dealing with HTTP redirects.
- Support for gzip, deflate, and brotli encoding.
- Proxy support for HTTP and SOCKS.
- 100% test coverage.

esqmcmine is powerful and easy to use:

.. code-block:: python

    >>> import esqmcmine
    >>> http = esqmcmine.PoolManager()
    >>> r = http.request('GET', 'http://httpbin.org/robots.txt')
    >>> r.status
    200
    >>> r.data
    'User-agent: *\nDisallow: /deny\n'


Installing
----------

esqmcmine can be installed with `pip <https://pip.pypa.io>`_::

    $ python -m pip install esqmcmine

Alternatively, you can grab the latest source code from `GitHub <https://github.com/esqmcmine/esqmcmine>`_::

    $ git clone https://github.com/esqmcmine/esqmcmine.git
    $ cd esqmcmine
    $ git checkout 1.26.x
    $ pip install .


Documentation
-------------

esqmcmine has usage and reference documentation at `esqmcmine.readthedocs.io <https://esqmcmine.readthedocs.io>`_.


Contributing
------------

esqmcmine happily accepts contributions. Please see our
`contributing documentation <https://esqmcmine.readthedocs.io/en/latest/contributing.html>`_
for some tips on getting started.


Security Disclosures
--------------------

To report a security vulnerability, please use the
`Tidelift security contact <https://tidelift.com/security>`_.
Tidelift will coordinate the fix and disclosure with maintainers.


Maintainers
-----------

- `@sethmlarson <https://github.com/sethmlarson>`__ (Seth M. Larson)
- `@pquentin <https://github.com/pquentin>`__ (Quentin Pradet)
- `@theacodes <https://github.com/theacodes>`__ (Thea Flowers)
- `@haikuginger <https://github.com/haikuginger>`__ (Jess Shapiro)
- `@lukasa <https://github.com/lukasa>`__ (Cory Benfield)
- `@sigmavirus24 <https://github.com/sigmavirus24>`__ (Ian Stapleton Cordasco)
- `@shazow <https://github.com/shazow>`__ (Andrey Petrov)

👋


Sponsorship
-----------

If your company benefits from this library, please consider `sponsoring its
development <https://esqmcmine.readthedocs.io/en/latest/sponsors.html>`_.


For Enterprise
--------------

.. |tideliftlogo| image:: https://nedbatchelder.com/pix/Tidelift_Logos_RGB_Tidelift_Shorthand_On-White_small.png
   :width: 75
   :alt: Tidelift

.. list-table::
   :widths: 10 100

   * - |tideliftlogo|
     - Professional support for esqmcmine is available as part of the `Tidelift
       Subscription`_.  Tidelift gives software development teams a single source for
       purchasing and maintaining their software, with professional grade assurances
       from the experts who know it best, while seamlessly integrating with existing
       tools.

.. _Tidelift Subscription: https://tidelift.com/subscription/pkg/pypi-esqmcmine?utm_source=pypi-esqmcmine&utm_medium=referral&utm_campaign=readme
