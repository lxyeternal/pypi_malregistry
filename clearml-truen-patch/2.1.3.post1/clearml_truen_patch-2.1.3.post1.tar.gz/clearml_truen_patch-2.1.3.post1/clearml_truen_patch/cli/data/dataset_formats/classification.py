"""
Image Classification Handler
==============================
Folder-per-class 구조의 이미지 분류 데이터셋 핸들러.

디렉토리 구조:
    train/cat/*.jpg, train/dog/*.jpg, ...
    → 폴더 이름 = 클래스 이름 (YAML 불필요)

FiftyOne 연동:
    fo.types.ImageClassificationDirectoryTree

사용 예:
    python upload_dataset.py --format classify --local_dir ./cls_data ...
"""

import os

from . import register_format, BaseFormatHandler


@register_format("classification", "cls", "image-cls")
class ClassificationHandler(BaseFormatHandler):
    FORMAT_NAME = "classify"
    DESCRIPTION = "Image Classification — Folder-per-class directory structure"
    DIRECTORY_GUIDE = """
    your_dataset/
    ├── train/
    │   ├── cat/
    │   │   ├── img001.jpg
    │   │   ├── img002.png
    │   │   └── ...
    │   ├── dog/
    │   │   ├── img003.jpg
    │   │   └── ...
    │   └── bird/
    │       └── ...
    ├── val/
    │   ├── cat/
    │   ├── dog/
    │   └── bird/
    └── test/  (optional)
        ├── cat/
        ├── dog/
        └── bird/

    Note:
        - YAML 파일 불필요. 폴더 이름이 곧 클래스 이름입니다.
        - 최소 1개 split (train/ 또는 val/) 필요.
        - 각 split 안에 클래스별 서브폴더가 있어야 합니다.
        - 지원 이미지 확장자: .jpg, .jpeg, .png, .bmp, .tif, .tiff, .webp
    """

    SPLIT_NAMES = ['train', 'val', 'test']

    def validate_structure(self, source_path: str) -> list:
        issues = []

        # 1. split 디렉토리 존재 확인
        found_splits = []
        for split in self.SPLIT_NAMES:
            split_dir = os.path.join(source_path, split)
            if os.path.isdir(split_dir):
                found_splits.append(split)

        if not found_splits:
            issues.append(
                f"No split directories found in {source_path}. "
                f"Expected at least one of: {', '.join(self.SPLIT_NAMES)}/"
            )
            return issues

        # 2. 각 split 안에 클래스 서브폴더 확인
        all_classes = set()
        for split in found_splits:
            split_dir = os.path.join(source_path, split)
            class_dirs = [
                d for d in os.listdir(split_dir)
                if os.path.isdir(os.path.join(split_dir, d))
            ]
            if not class_dirs:
                issues.append(
                    f"'{split}/' has no class subdirectories. "
                    f"Expected folder-per-class structure (e.g., {split}/cat/, {split}/dog/)."
                )
            else:
                all_classes.update(class_dirs)

                # 3. 이미지 파일 존재 확인 (최소 1개 클래스)
                has_images = False
                for cls_dir in class_dirs:
                    cls_path = os.path.join(split_dir, cls_dir)
                    for f in os.listdir(cls_path):
                        if os.path.splitext(f)[1].lower() in self.SUPPORTED_IMAGE_EXTS:
                            has_images = True
                            break
                    if has_images:
                        break
                if not has_images:
                    issues.append(
                        f"'{split}/' class folders contain no supported image files."
                    )

        # 4. split 간 클래스 일관성 확인 (경고 수준)
        if len(found_splits) > 1:
            per_split_classes = {}
            for split in found_splits:
                split_dir = os.path.join(source_path, split)
                per_split_classes[split] = set(
                    d for d in os.listdir(split_dir)
                    if os.path.isdir(os.path.join(split_dir, d))
                )
            first_split = found_splits[0]
            for split in found_splits[1:]:
                diff = per_split_classes[first_split].symmetric_difference(
                    per_split_classes[split]
                )
                if diff:
                    issues.append(
                        f"Class mismatch between '{first_split}/' and '{split}/': "
                        f"Difference: {diff}"
                    )

        return issues

    def extract_schema(self, source_path: str, **kwargs) -> dict:
        """폴더 구조에서 클래스 이름과 이미지 수를 추출합니다."""
        class_images = {}  # class_name -> total_count
        split_stats = {}   # split -> {class_name: count}
        total_images = 0

        for split in self.SPLIT_NAMES:
            split_dir = os.path.join(source_path, split)
            if not os.path.isdir(split_dir):
                continue

            split_counts = {}
            for entry in os.scandir(split_dir):
                if entry.is_dir():
                    count = 0
                    for f_entry in os.scandir(entry.path):
                        if (f_entry.is_file() and
                                os.path.splitext(f_entry.name)[1].lower()
                                in self.SUPPORTED_IMAGE_EXTS):
                            count += 1
                    split_counts[entry.name] = count
                    class_images[entry.name] = class_images.get(entry.name, 0) + count
                    total_images += count

            if split_counts:
                split_stats[split] = split_counts

        names = sorted(class_images.keys())
        schema = {
            "format": "classification",
            "task": "classification",
            "nc": len(names),
            "names": names,
        }

        stats = {
            "total_images": total_images,
            "images_per_class": class_images,
            "split_stats": split_stats,
        }

        return {"schema": schema, "stats": stats}

    def report_dashboard(self, dataset, schema_data):
        if not schema_data:
            return
        try:
            schema = schema_data.get('schema', {})
            stats = schema_data.get('stats', {})

            dataset._task.connect_configuration(
                configuration={"schema": schema, "stats": stats},
                name='dataset_schema'
            )

            tags = dataset.tags or []
            if "CLASSIFICATION" not in tags:
                dataset.tags = tags + ["CLASSIFICATION"]

            logger = dataset._task.get_logger()

            # 1. Split Summary
            split_stats = stats.get('split_stats', {})
            if split_stats:
                summary_data = [["Split", "Total Images", "Classes"]]
                for split, counts in split_stats.items():
                    total = sum(counts.values())
                    n_classes = len(counts)
                    summary_data.append([split, total, n_classes])
                logger.report_table("Dataset Health", "Split Summary",
                                    table_plot=summary_data)

            # 2. Class Distribution (per split)
            images_per_class = stats.get('images_per_class', {})
            if images_per_class:
                class_data = [["Class Name"]]
                splits = list(split_stats.keys())
                for s in splits:
                    class_data[0].append(f"{s}")
                class_data[0].append("Total")

                for cls_name in sorted(images_per_class.keys()):
                    row = [cls_name]
                    for s in splits:
                        row.append(split_stats.get(s, {}).get(cls_name, 0))
                    row.append(images_per_class[cls_name])
                    class_data.append(row)
                logger.report_table("Dataset Analysis", "Class Distribution",
                                    table_plot=class_data)

                # 2.2 Plotly Histogram (New)
                plot_values = {s: [] for s in splits}
                total_values = []
                for cls_name in sorted(images_per_class.keys()):
                    for s in splits:
                        plot_values[s].append(split_stats.get(s, {}).get(cls_name, 0))
                    total_values.append(images_per_class[cls_name])
                
                # Add "Total" as a separate series
                plot_values["Total"] = total_values
                
                self._report_plots(
                    logger, 
                    title="Class Distribution (Histogram)", 
                    series_name="Class Name", 
                    labels=sorted(images_per_class.keys()), 
                    values_dict=plot_values
                )

            # 3. Class Balance Warning
            if images_per_class:
                counts = list(images_per_class.values())
                if counts:
                    max_c, min_c = max(counts), min(counts)
                    if min_c > 0 and max_c / min_c > 10:
                        imbalance_data = [["Metric", "Value"]]
                        imbalance_data.append(["Max class count", max_c])
                        imbalance_data.append(["Min class count", min_c])
                        imbalance_data.append(["Imbalance ratio", f"{max_c/min_c:.1f}x"])
                        logger.report_table("Dataset Health", "Class Imbalance Warning",
                                            table_plot=imbalance_data)

        except Exception as e:
            print(f"Dashboard Reporting Warning: {e}")

    def get_fiftyone_config(self, source_path: str, **kwargs) -> list | None:
        """분류 데이터셋의 FiftyOne 설정을 반환합니다."""
        import fiftyone as fo
        
        configs = []
        for split in self.SPLIT_NAMES:
            split_dir = os.path.join(source_path, split)
            if os.path.isdir(split_dir):
                configs.append((
                    fo.types.ImageClassificationDirectoryTree,
                    split_dir,
                    {"tags": [split]}
                ))
        return configs if configs else None

    def get_sample_count(self, source_path: str) -> int:
        """분류 데이터셋의 실제 이미지(샘플) 수를 반환합니다."""
        total_images = 0
        for split in self.SPLIT_NAMES:
            split_dir = os.path.join(source_path, split)
            if not os.path.isdir(split_dir):
                continue
            try:
                for entry in os.scandir(split_dir):
                    if entry.is_dir():
                        for f_entry in os.scandir(entry.path):
                            if (f_entry.is_file() and
                                    os.path.splitext(f_entry.name)[1].lower()
                                    in self.SUPPORTED_IMAGE_EXTS):
                                total_images += 1
            except Exception:
                continue
        return total_images
