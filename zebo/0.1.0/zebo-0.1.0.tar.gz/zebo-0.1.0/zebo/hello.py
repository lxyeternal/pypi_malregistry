from zebo.scripts.runner import i_am_cute
def hello():
    i_am_cute()
    print("hello cute <3")


