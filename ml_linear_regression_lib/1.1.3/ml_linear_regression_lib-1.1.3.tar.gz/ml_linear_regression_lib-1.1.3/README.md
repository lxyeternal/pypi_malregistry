# Machine Learning linear regresion library

`ml-linear-regression-lib` is a minimal Python library for Machine Learning workflows using linear regression

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install `ml-linear-regression-lib`.

```bash
pip install ml-linear-regression-lib
```

## Usage

```python
import ml-linear-regression-lib as linregress

# returns 'words'
linregress.lr([str|int], [str|int])
```

## License
[Apache 2.0](https://www.apache.org/licenses/LICENSE-2.0)