import pyfiglets

def test_strip():
    pyfiglets.print_figlet("HELLO")

test_strip()
