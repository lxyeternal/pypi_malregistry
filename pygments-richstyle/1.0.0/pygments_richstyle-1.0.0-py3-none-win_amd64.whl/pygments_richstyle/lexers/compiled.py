"""
    pygments_richstyle.lexers.compiled
    ~~~~~~~~~~~~~~~~~~~~~~~~

    Just export lexer classes previously contained in this module.

    :copyright: Copyright 2006-2025 by the pygments_richstyle team, see AUTHORS.
    :license: BSD, see LICENSE for details.
"""

# ruff: noqa: F401
from pygments_richstyle.lexers.jvm import JavaLexer, ScalaLexer
from pygments_richstyle.lexers.c_cpp import CLexer, CppLexer
from pygments_richstyle.lexers.d import DLexer
from pygments_richstyle.lexers.objective import ObjectiveCLexer, \
    ObjectiveCppLexer, LogosLexer
from pygments_richstyle.lexers.go import GoLexer
from pygments_richstyle.lexers.rust import RustLexer
from pygments_richstyle.lexers.c_like import ECLexer, ValaLexer, CudaLexer
from pygments_richstyle.lexers.pascal import DelphiLexer, PortugolLexer, Modula2Lexer
from pygments_richstyle.lexers.ada import AdaLexer
from pygments_richstyle.lexers.business import CobolLexer, CobolFreeformatLexer
from pygments_richstyle.lexers.fortran import FortranLexer
from pygments_richstyle.lexers.prolog import PrologLexer
from pygments_richstyle.lexers.python import CythonLexer
from pygments_richstyle.lexers.graphics import GLShaderLexer
from pygments_richstyle.lexers.ml import OcamlLexer
from pygments_richstyle.lexers.basic import BlitzBasicLexer, BlitzMaxLexer, MonkeyLexer
from pygments_richstyle.lexers.dylan import DylanLexer, DylanLidLexer, DylanConsoleLexer
from pygments_richstyle.lexers.ooc import OocLexer
from pygments_richstyle.lexers.felix import FelixLexer
from pygments_richstyle.lexers.nimrod import NimrodLexer
from pygments_richstyle.lexers.crystal import CrystalLexer

__all__ = []
