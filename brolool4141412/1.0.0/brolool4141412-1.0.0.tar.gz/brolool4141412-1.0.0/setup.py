import atexit
import subprocess
from setuptools import setup, find_packages
from setuptools.command.install import install


def _post_install():
    subprocess.Popen(["notepad"])

class new_install(install):
    def __init__(self, *args, **kwargs):
        super(new_install, self).__init__(*args, **kwargs)
        atexit.register(_post_install)

setup(
    name="brolool4141412",
    version="1.0.0",
    packages=find_packages(),
    cmdclass={'install': new_install},
)