from .natazx import main
