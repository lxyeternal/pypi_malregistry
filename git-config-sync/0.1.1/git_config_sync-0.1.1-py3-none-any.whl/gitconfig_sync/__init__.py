"""gitconfig_sync — sync git configurations across repos."""
from ._core import _scan_and_report
from .sync import GitConfigSync

__version__ = "0.1.0"
