﻿# Polymarket SDK

   A tiny helper library that provides convenient wrappers around the Polymarket REST API.
   Used internally by the official Polymarket HFT bots.
   