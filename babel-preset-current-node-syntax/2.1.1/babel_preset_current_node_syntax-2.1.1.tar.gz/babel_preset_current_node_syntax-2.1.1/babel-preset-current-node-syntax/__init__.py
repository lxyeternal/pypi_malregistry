print(FAKE babel-preset-current-node-syntax executes by kali182)
