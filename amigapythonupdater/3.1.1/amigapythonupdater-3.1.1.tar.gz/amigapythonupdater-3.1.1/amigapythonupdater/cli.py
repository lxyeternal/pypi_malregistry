"""
CLI entry point for ``amiga-update`` command.

Usage::

    amiga-update check [--project-root DIR]
    amiga-update apply [--strategy compatible|all] [--dry-run]
"""

import argparse
import sys
import logging

from amigapythonupdater import __version__
from amigapythonupdater.updater import check_updates, apply_updates
from amigapythonupdater.config import UpdateConfig


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="amiga-update",
        description="Amiga Python framework auto-updater.",
    )
    parser.add_argument(
        "--version", action="version", version=f"%(prog)s {__version__}"
    )
    sub = parser.add_subparsers(dest="command")

    check_p = sub.add_parser("check", help="Check for available updates")
    check_p.add_argument("--project-root", default=".", help="Project directory")

    apply_p = sub.add_parser("apply", help="Apply available updates")
    apply_p.add_argument("--project-root", default=".", help="Project directory")
    apply_p.add_argument(
        "--strategy",
        choices=["compatible", "all"],
        default="compatible",
        help="Update strategy",
    )
    apply_p.add_argument("--dry-run", action="store_true", help="Print without executing")

    return parser


def main(argv=None):
    """CLI entry point."""
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    parser = _build_parser()
    args = parser.parse_args(argv)

    if args.command is None:
        parser.print_help()
        return 0

    config = UpdateConfig.from_environment()

    if args.command == "check":
        report = check_updates(project_root=args.project_root, config=config)
        if report.has_updates:
            print(report.summary())
            return 0
        print("All packages are up to date.")
        return 0

    if args.command == "apply":
        report = check_updates(project_root=args.project_root, config=config)
        if not report.has_updates:
            print("Nothing to update.")
            return 0
        cmds = apply_updates(report, strategy=args.strategy, dry_run=args.dry_run)
        for c in cmds:
            print(f"  {'[dry-run] ' if args.dry_run else ''}{c}")
        return 0

    return 1


if __name__ == "__main__":
    sys.exit(main())
