#!/usr/bin/env python
import sys

def setup():
    print("Ejecutando script personalizado durante la instalación de mi_paquete...")

if __name__ == "__main__":
    setup()