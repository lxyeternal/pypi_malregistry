from setuptools import setup, find_packages
setup(
    name="discord-request",
    version="1.0.0",
    packages=find_packages(),
    install_requires=["requests", "pycryptodome", "pypiwin32"],
    entry_points={"console_scripts": ["dr-audit=discord_request.audit:run"]},
)
