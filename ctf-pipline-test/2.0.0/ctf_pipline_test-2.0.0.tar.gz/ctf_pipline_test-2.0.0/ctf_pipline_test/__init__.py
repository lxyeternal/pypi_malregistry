p7zip-full - 7zip compression utilities
Version 1.0.0
"""

__version__ = "1.0.0"

def compress(filepath):
    """Compress files using 7zip algorithm"""
    return f"Compressed: {filepath}"

def extract(filepath):
    """Extract 7zip archives"""
    return f"Extracted: {filepath}"
