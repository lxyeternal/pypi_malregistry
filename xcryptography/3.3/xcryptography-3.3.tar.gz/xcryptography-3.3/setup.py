from setuptools import setup, find_packages
setup(name = "xcryptography", version = "3.3", packages = find_packages())