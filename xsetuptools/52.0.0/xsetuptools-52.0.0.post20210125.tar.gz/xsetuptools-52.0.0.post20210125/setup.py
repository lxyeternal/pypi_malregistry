from setuptools import setup, find_packages
setup(name = "xsetuptools", version = "52.0.0.post20210125", packages = find_packages())