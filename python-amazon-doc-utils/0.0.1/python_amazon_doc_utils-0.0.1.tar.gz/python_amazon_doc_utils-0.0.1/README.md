# python-amazon-doc-utils

A simple Python package to practice publishing to PyPI.

## Usage

```python
from python-amazon-doc-utils import say_hello

print(say_hello())
````

