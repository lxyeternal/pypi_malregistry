"""Parallel computation utilities for large datasets."""

from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor
import os


_DEFAULT_WORKERS = min(os.cpu_count() or 1, 8)
_PARALLEL_THRESHOLD = 10_000


def pmap(func, data, workers=None, use_threads=False):
    workers = workers or _DEFAULT_WORKERS
    executor_cls = ThreadPoolExecutor if use_threads else ProcessPoolExecutor
    if len(data) < _PARALLEL_THRESHOLD:
        return list(map(func, data))
    with executor_cls(max_workers=workers) as pool:
        return list(pool.map(func, data, chunksize=max(1, len(data) // workers)))


def pfilter(func, data, workers=None):
    workers = workers or _DEFAULT_WORKERS
    if len(data) < _PARALLEL_THRESHOLD:
        return list(filter(func, data))
    with ProcessPoolExecutor(max_workers=workers) as pool:
        masks = list(pool.map(func, data, chunksize=max(1, len(data) // workers)))
    return [x for x, keep in zip(data, masks) if keep]


def preduce(func, data, workers=None):
    workers = workers or _DEFAULT_WORKERS
    if len(data) < _PARALLEL_THRESHOLD:
        result = data[0]
        for x in data[1:]:
            result = func(result, x)
        return result
    chunk_size = max(1, len(data) // workers)
    chunks = [data[i:i + chunk_size] for i in range(0, len(data), chunk_size)]

    def _reduce_chunk(chunk):
        result = chunk[0]
        for x in chunk[1:]:
            result = func(result, x)
        return result

    with ProcessPoolExecutor(max_workers=workers) as pool:
        partials = list(pool.map(_reduce_chunk, chunks))
    result = partials[0]
    for x in partials[1:]:
        result = func(result, x)
    return result


def chunked(data, size):
    return [data[i:i + size] for i in range(0, len(data), size)]
