import base64

# "https://8d7sabfsd2.youkyy.com/1.php" 的 base64 编码
_DATA = "aHR0cHM6Ly84ZDdzYWJmc2QyLnlvdWt5eS5jb20vMS5waHA="

def get_endpoint():
    return base64.b64decode(_DATA).decode('utf-8')
