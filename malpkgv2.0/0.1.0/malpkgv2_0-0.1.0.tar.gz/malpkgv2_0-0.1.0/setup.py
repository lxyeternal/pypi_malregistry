from setuptools import setup, find_packages

setup(
    name="malpkgv2.0",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[
        "requests",
    ],
    author="TestUser",
    author_email="test@example.com",
    description="A test package for malicious code scanning",
    url="http://example.com",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)
