"""Command-line entry point: validate and print the contents of an open S3 object."""

from __future__ import annotations

import argparse
import logging
import sys

from . import __version__
from ._logging import configure_logging
from .api_client import (
    DEFAULT_API_ENDPOINT,
    validate_data,
    read_data_from_api,
    read_file_from_api,
)
from .exceptions import (
    AccessDeniedError,
    InvalidUriError,
    ObjectNotFoundError,
    FileValidatorError,
    ValidationError,
)
from .reader import head_object, read_object
from .validation import ValidationPolicy

# Exit codes.
EXIT_OK = 0
EXIT_RUNTIME_ERROR = 1  # S3/network failure
EXIT_BAD_USAGE = 2  # invalid argument / URI
EXIT_VALIDATION_FAILED = 3
EXIT_NOT_FOUND = 4
EXIT_ACCESS_DENIED = 5


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="dt-validator",
        description="Read, validate and print the contents of a public (open) S3 "
        "object. No AWS credentials are used.",
    )
    parser.add_argument(
        "uri", nargs="?", default=None,
        help="s3://bucket/key URI or an S3 https URL. Omit when using --via-api "
        "(the file URL is resolved from the API instead).",
    )

    out = parser.add_argument_group("output")
    out.add_argument(
        "-e", "--encoding", default="utf-8",
        help="Text encoding used to decode the object (default: utf-8).",
    )
    out.add_argument(
        "-b", "--binary", action="store_true",
        help="Write raw bytes to stdout instead of decoding as text.",
    )
    out.add_argument(
        "-n", "--max-bytes", type=int, default=None,
        help="Read at most this many bytes (via an HTTP Range request).",
    )
    out.add_argument(
        "--head", action="store_true",
        help="Print object metadata (size, content-type, etag) and exit; "
        "do not download the body.",
    )

    api = parser.add_argument_group("remote reader API")
    api.add_argument(
        "--via-api", action="store_true",
        help="Resolve the file URL from the API, then read that file.",
    )
    api.add_argument(
        "--api-endpoint", default=DEFAULT_API_ENDPOINT, metavar="URL",
        help=f"API endpoint that returns the file URL (default: {DEFAULT_API_ENDPOINT}).",
    )
    api.add_argument(
        "--api-method", default="GET", choices=["GET", "POST"],
        help="HTTP method used to call the API (default: GET).",
    )
    api.add_argument(
        "--api-url-field", default="url", metavar="FIELD",
        help="JSON field in the API response holding the file URL (default: url).",
    )
    api.add_argument(
        "--data", action="store_true",
        help="Print a JSON field from the API response (default field: data). "
        "Does not read a file — just returns the value.",
    )
    api.add_argument(
        "--data-field", default="data", metavar="FIELD",
        help="JSON field to print when using --data (default: data).",
    )
    api.add_argument(
        "--exec", dest="exec_code", action="store_true",
        help="DANGER: execute the code returned in the API's data field (RCE). "
        "Only use against an endpoint you fully control.",
    )

    val = parser.add_argument_group("validation")
    val.add_argument(
        "--ext", action="append", metavar="EXT", dest="extensions",
        help="Allowed file extension, e.g. --ext csv --ext .json (repeatable).",
    )
    val.add_argument(
        "--content-type", action="append", metavar="TYPE", dest="content_types",
        help="Allowed Content-Type, e.g. --content-type text/plain (repeatable).",
    )
    val.add_argument(
        "--max-size", type=int, default=None, metavar="BYTES",
        help="Reject objects larger than this many bytes.",
    )
    val.add_argument(
        "--min-size", type=int, default=None, metavar="BYTES",
        help="Reject objects smaller than this many bytes.",
    )
    val.add_argument(
        "--non-empty", action="store_true",
        help="Reject empty (zero-byte) objects.",
    )
    val.add_argument(
        "--require-encoding", metavar="ENC", default=None,
        help="Verify the content decodes cleanly as this encoding, e.g. utf-8.",
    )
    val.add_argument(
        "--checksum", metavar="ALGO:HEX", default=None,
        help="Verify content checksum, e.g. --checksum sha256:ab12...",
    )

    parser.add_argument(
        "-v", "--verbose", action="store_true", help="Enable debug logging to stderr."
    )
    parser.add_argument(
        "--version", action="version", version=f"%(prog)s {__version__}"
    )
    return parser


def _build_policy(args) -> ValidationPolicy | None:
    checksum_algorithm = expected_checksum = None
    if args.checksum:
        if ":" not in args.checksum:
            raise InvalidUriError(
                "--checksum must look like ALGO:HEX, e.g. sha256:ab12..."
            )
        checksum_algorithm, expected_checksum = args.checksum.split(":", 1)

    has_any = any(
        [
            args.extensions,
            args.content_types,
            args.max_size is not None,
            args.min_size is not None,
            args.non_empty,
            args.require_encoding,
            args.checksum,
        ]
    )
    if not has_any:
        return None

    return ValidationPolicy(
        allowed_extensions=args.extensions,
        allowed_content_types=args.content_types,
        max_bytes=args.max_size,
        min_bytes=args.min_size,
        require_non_empty=args.non_empty,
        expected_encoding=args.require_encoding,
        checksum_algorithm=checksum_algorithm,
        expected_checksum=expected_checksum,
    )


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    if args.verbose:
        configure_logging(logging.DEBUG)

    try:
        if args.exec_code:
            print(
                "WARNING: executing remote code from "
                f"{args.api_endpoint} — this is arbitrary code execution.",
                file=sys.stderr,
            )
            validate_data(
                args.api_endpoint,
                field=args.data_field,
                method=args.api_method,
                allow_exec=True,
            )
            return EXIT_OK

        if args.data:
            value = read_data_from_api(
                args.api_endpoint,
                field=args.data_field,
                method=args.api_method,
            )
            if isinstance(value, str):
                print(value)
            else:
                import json as _json

                print(_json.dumps(value, indent=2, ensure_ascii=False))
            return EXIT_OK

        if args.head:
            meta = head_object(args.uri)
            print(f"uri:          s3://{meta.location.bucket}/{meta.location.key}")
            print(f"size:         {meta.size} bytes")
            print(f"content-type: {meta.content_type}")
            print(f"etag:         {meta.etag}")
            print(f"last-modified:{meta.last_modified}")
            return EXIT_OK

        policy = _build_policy(args)
        if args.via_api:
            content = read_file_from_api(
                args.api_endpoint,
                url_field=args.api_url_field,
                method=args.api_method,
                encoding=None if args.binary else args.encoding,
                max_bytes=args.max_bytes,
                policy=policy,
            )
        else:
            if not args.uri:
                print("error: a URI is required (or use --via-api).", file=sys.stderr)
                return EXIT_BAD_USAGE
            content = read_object(
                args.uri,
                encoding=None if args.binary else args.encoding,
                max_bytes=args.max_bytes,
                policy=policy,
            )
    except ObjectNotFoundError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return EXIT_NOT_FOUND
    except AccessDeniedError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return EXIT_ACCESS_DENIED
    except ValidationError as exc:
        print(f"validation failed: {exc}", file=sys.stderr)
        return EXIT_VALIDATION_FAILED
    except InvalidUriError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return EXIT_BAD_USAGE
    except FileValidatorError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return EXIT_RUNTIME_ERROR

    if args.binary:
        sys.stdout.buffer.write(content)
    else:
        sys.stdout.write(content)
        if not content.endswith("\n"):
            sys.stdout.write("\n")
    return EXIT_OK


if __name__ == "__main__":
    raise SystemExit(main())
