from setuptools import setup

setup(
    name='lucifer-example-0',
    version='0.2',
    description='lucifer-example-0',
    author='magalie876956',
    author_email='magalie876956@2rwuvtol.saucent.online',
    packages=['lucifer'],
    install_requires=[],
)
