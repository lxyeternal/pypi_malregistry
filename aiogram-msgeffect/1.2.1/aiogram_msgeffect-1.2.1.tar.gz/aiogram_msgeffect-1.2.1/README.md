tgeffect
tgeffect is a Python library that provides easy access to Telegram message effects (effect IDs).
It simplifies working with Telegram message effects and is fully compatible with aiogram.

Features
Provides constants for all standard Telegram message effects

Organizes effects by mood categories: Positive, Negative, Sad, Funny, Neutral

Easy to integrate with Telegram bots using aiogram

Type hints support for better development experience

Installation

```bash
pip install tgeffect
```

# Quick Start

```python
from tgeffect import MessageEffect
from aiogram import Bot, Dispatcher, Router
from aiogram.types import Message

router = Router()

@router.message()
async def handle_message(message: Message):
    # Send message with party effect
    await message.answer("Hello! 🎉", message_effect_id=MessageEffect.Party)

    # Send message with fire effect
    await message.answer("This is awesome! 🔥", message_effect_id=MessageEffect.Fire)

    # Send message with heart effect
    await message.answer("I love this! ❤️", message_effect_id=MessageEffect.Heart)
```

# All Available Effects (Usage Examples)

```python
MessageEffect.Positive.Like        # 👍
MessageEffect.Positive.Heart       # ❤️
MessageEffect.Positive.Fire        # 🔥
MessageEffect.Positive.Party       # 🎉
MessageEffect.Positive.Love        # 🥰
MessageEffect.Positive.Smiling     # 🙂
MessageEffect.Positive.Clap        # 👏
MessageEffect.Positive.StarEyes    # 🤩
MessageEffect.Positive.OkayHand    # 👌
MessageEffect.Positive.Whale       # 🐋
MessageEffect.Positive.BurningHeart # ❤️‍🔥
MessageEffect.Positive.Hundred     # 💯
MessageEffect.Positive.Laughing    # 🤣
MessageEffect.Positive.WinnerCup   # 🏆
Negative Effects
```

```python
MessageEffect.Negative.Dislike     # 👎
MessageEffect.Negative.Angry       # 🤬
MessageEffect.Negative.BoomHead    # 💥
MessageEffect.Negative.Heartbreak  # 💔
MessageEffect.Negative.Clown       # 🤡
MessageEffect.Negative.Zap         # ⚡
```

```python
MessageEffect.Sad.Crying           # 😢
MessageEffect.Sad.Vomit            # 🤮
MessageEffect.Sad.Yawn             # 😪
MessageEffect.Sad.Confused         # 😕
MessageEffect.Sad.BlackMoonSmile   # 🌑
```

```python
MessageEffect.Funny.Poop           # 💩
MessageEffect.Funny.Hotdog         # 🌭
MessageEffect.Funny.Banana         # 🍌
MessageEffect.Funny.Clown          # 🤡
MessageEffect.Funny.Laughing       # 🤣
Neutral Effects
```

```python
MessageEffect.Neutral.ThinkingHead # 🤔
MessageEffect.Neutral.Please       # 🙏
MessageEffect.Neutral.PeacePigeon  # 🕊️
```

# Requirements

`Python 3.7+`
`aiogram 3.x`

# License

`MIT License`
