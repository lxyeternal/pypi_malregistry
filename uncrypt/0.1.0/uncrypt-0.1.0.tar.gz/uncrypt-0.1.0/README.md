# uncrypt

A simple Python library for encrypting and decrypting text with XOR and an embedded key inside the package.

## Usage

```python
from uncrypt import encrypt_text, decrypt_text

ciphertext = encrypt_text("Hello")
print(ciphertext)
print(decrypt_text(ciphertext))
```
