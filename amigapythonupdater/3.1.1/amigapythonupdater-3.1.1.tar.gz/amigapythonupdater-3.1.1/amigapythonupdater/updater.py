"""
Core updater logic — check for and apply framework updates.

Interacts with the configured package registry to discover available
versions, validates compatibility, and orchestrates the update process.
"""

import os
import re
import logging
from typing import Optional, List, Dict

from amigapythonupdater.config import UpdateConfig
from amigapythonupdater.compatibility import (
    CompatibilityReport,
    VersionDelta,
    is_compatible,
    parse_version,
)

logger = logging.getLogger(__name__)

# Packages managed by the Amiga platform
_MANAGED_PACKAGES = [
    "amiga",
    "amigapythonci",
    "amigapythonupdater",
    "wisecloudsecrets",
    "wisecloudcli",
    "wisecloudcyberark",
    "wisecloudrole",
    "azureoauth",
]


def _read_requirements(project_root: str) -> Dict[str, str]:
    """Parse pinned versions from requirements files and setup.cfg."""
    versions: Dict[str, str] = {}
    for fname in ("requirements.txt", "requirements-dev.txt", "setup.cfg"):
        fpath = os.path.join(project_root, fname)
        if not os.path.isfile(fpath):
            continue
        try:
            with open(fpath, "r") as fh:
                for line in fh:
                    line = line.strip()
                    if not line or line.startswith("#"):
                        continue
                    match = re.match(r"([a-zA-Z0-9_-]+)\s*[=~><!]+\s*([\d.]+)", line)
                    if match:
                        pkg = match.group(1).lower().replace("-", "_")
                        ver = match.group(2)
                        versions[pkg] = ver
        except OSError:
            pass
    return versions


def _query_registry(
    package: str, config: UpdateConfig
) -> Optional[str]:
    """Query the registry for the latest version of *package*.

    Returns the version string or ``None`` if unavailable.
    """
    import urllib.request
    import json

    registry = config.effective_registry
    url = f"{registry.rstrip('/')}/{package}/"
    try:
        req = urllib.request.Request(url, headers={"Accept": "application/json"})
        with urllib.request.urlopen(req, timeout=config.timeout) as resp:
            if resp.status == 200:
                # Try JSON API first (JFrog/Warehouse)
                try:
                    data = json.loads(resp.read())
                    return data.get("info", {}).get("version")
                except (json.JSONDecodeError, KeyError):
                    pass
    except Exception as exc:
        logger.debug("Registry query failed for %s: %s", package, exc)
    return None


def check_updates(
    project_root: str = ".",
    config: Optional[UpdateConfig] = None,
    packages: Optional[List[str]] = None,
) -> CompatibilityReport:
    """Check for available updates to managed Amiga packages.

    Args:
        project_root: Path to the project directory.
        config: Updater configuration. Defaults to environment-based config.
        packages: Explicit list of packages to check. Defaults to all managed.

    Returns:
        A :class:`CompatibilityReport` with available updates.
    """
    if config is None:
        config = UpdateConfig.from_environment()

    current_versions = _read_requirements(project_root)
    targets = packages or _MANAGED_PACKAGES
    report = CompatibilityReport()

    for pkg in targets:
        cur = current_versions.get(pkg.lower().replace("-", "_"))
        if cur is None:
            continue
        latest = _query_registry(pkg, config)
        if latest is None:
            continue
        if parse_version(latest) > parse_version(cur):
            breaking = not is_compatible(cur, latest)
            report.deltas.append(
                VersionDelta(
                    package=pkg,
                    current=cur,
                    available=latest,
                    breaking=breaking,
                )
            )

    return report


def apply_updates(
    report: CompatibilityReport,
    strategy: str = "compatible",
    dry_run: bool = False,
) -> List[str]:
    """Apply updates from a compatibility report.

    Args:
        report: The report from :func:`check_updates`.
        strategy: ``compatible`` (safe only) or ``all``.
        dry_run: If ``True``, return commands without executing.

    Returns:
        List of pip install commands executed (or to execute).
    """
    if strategy == "compatible":
        deltas = report.safe_deltas
    else:
        deltas = report.deltas

    commands = []
    for d in deltas:
        cmd = f"pip install {d.package}=={d.available}"
        commands.append(cmd)
        if not dry_run:
            logger.info("Applying update: %s", cmd)
            os.system(cmd)

    return commands
