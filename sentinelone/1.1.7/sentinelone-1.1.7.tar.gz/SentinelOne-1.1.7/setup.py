from setuptools import setup, find_packages

package_version = '1.1.7'

setup(
    name='SentinelOne',
    version='1.1.7',
    license='SentinelOne'
)

