__version__ = "0.0.0"

def info():
    return "This is a dummy qt-main package for PyPI."
