from setuptools import setup

setup(
    name='nvkvictim-poc',
    version='0.1',
    packages=['nvkvictim-poc'],
    install_requires=[],
)

