def trim(s):
    return s.strip() if s else ''

def lower(s):
    return s.lower() if s else ''

def upper(s):
    return s.upper() if s else ''

def pad(s, n, c=' '):
    s = str(s or '')
    while len(s) < n:
        s += c
    return s

def reverse(s):
    return (s or '')[::-1]

def truncate(s, n):
    s = s or ''
    return s[:n] + '...' if len(s) > n else s
