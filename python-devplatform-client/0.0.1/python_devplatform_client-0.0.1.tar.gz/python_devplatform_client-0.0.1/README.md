# python-devplatform-client

Cross-service python devplatform client adapter

## Installation

```bash
pip install python-devplatform-client
```

## Usage

```python
import python_devplatform_client
```

## Telemetry

This package collects anonymous usage metrics to help improve the platform.
Telemetry can be disabled by setting the `DISABLE_TELEMETRY` environment variable.

## License

MIT
