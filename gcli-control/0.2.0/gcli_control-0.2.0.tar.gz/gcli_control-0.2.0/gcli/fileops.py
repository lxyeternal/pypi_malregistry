"""
Remote file operations for the gcli host daemon.
Provides structured file commands (ls, tree, mkdir, rm, stat, cp, mv, find, du)
that return JSON-serialisable result dicts.
"""
import os
import fnmatch
import shutil
import logging
import datetime
import stat as stat_mod
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

logger = logging.getLogger("gcli.fileops")

DANGEROUS_PATHS: Tuple[str, ...] = (
    "/", "/bin", "/boot", "/dev", "/etc", "/lib", "/lib64", "/proc",
    "/root", "/sbin", "/sys", "/usr", "/var",
    "C:\\", "C:\\Windows", "C:\\Program Files", "C:\\Program Files (x86)",
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _human_size(nbytes: int) -> str:
    """Return a human-readable file size string."""
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if abs(nbytes) < 1024:
            return f"{nbytes:.1f} {unit}" if unit != "B" else f"{nbytes} B"
        nbytes /= 1024  # type: ignore[assignment]
    return f"{nbytes:.1f} PB"


def _format_time(ts: float) -> str:
    """Return an ISO-8601 string from a timestamp."""
    return datetime.datetime.fromtimestamp(ts).isoformat(timespec="seconds")


def _mode_to_str(mode: int) -> str:
    """Convert a numeric mode to an ``ls -l`` style permission string."""
    chars = ["-"] * 10
    if stat_mod.S_ISDIR(mode):
        chars[0] = "d"
    elif stat_mod.S_ISLNK(mode):
        chars[0] = "l"
    for i, (bit, letter) in enumerate(
        ((stat_mod.S_IRUSR, "r"), (stat_mod.S_IWUSR, "w"), (stat_mod.S_IXUSR, "x"),
         (stat_mod.S_IRGRP, "r"), (stat_mod.S_IWGRP, "w"), (stat_mod.S_IXGRP, "x"),
         (stat_mod.S_IROTH, "r"), (stat_mod.S_IWOTH, "w"), (stat_mod.S_IXOTH, "x"))
    ):
        if mode & bit:
            chars[i + 1] = letter
    return "".join(chars)


def _is_dangerous(path: str) -> bool:
    """Return True if *path* is a dangerous system directory."""
    resolved = os.path.abspath(path)
    for dangerous in DANGEROUS_PATHS:
        if resolved == os.path.abspath(dangerous):
            return True
    return False


def _safe_path(requested: str) -> Optional[str]:
    """Return the resolved absolute path, or ``None`` if it doesn't exist."""
    p = Path(requested).resolve()
    if not p.exists():
        return None
    return str(p)


# ---------------------------------------------------------------------------
# Individual operations
# ---------------------------------------------------------------------------

def op_ls(payload: dict) -> dict:
    """List directory contents."""
    path = payload.get("path", ".")
    show_hidden = payload.get("show_hidden", False)
    try:
        p = Path(path)
        if not p.exists():
            return {"ok": False, "error": f"Path not found: {path}"}
        if not p.is_dir():
            return {"ok": False, "error": f"Not a directory: {path}"}

        entries: List[dict] = []
        for item in sorted(p.iterdir()):
            name = item.name
            if not show_hidden and name.startswith("."):
                continue
            try:
                st = item.stat()
                entries.append({
                    "name": name,
                    "is_dir": item.is_dir(),
                    "size": st.st_size,
                    "size_human": _human_size(st.st_size),
                    "modified": _format_time(st.st_mtime),
                })
            except PermissionError:
                entries.append({
                    "name": name,
                    "is_dir": item.is_dir(),
                    "size": 0,
                    "size_human": "?",
                    "modified": None,
                    "error": "permission denied",
                })

        entries.sort(key=lambda e: (not e["is_dir"], e["name"].lower()))
        return {"ok": True, "entries": entries}
    except PermissionError:
        return {"ok": False, "error": f"Permission denied: {path}"}
    except Exception as exc:
        return {"ok": False, "error": str(exc)}


def op_tree(payload: dict) -> dict:
    """Return a tree-style string representation of a directory."""
    path = payload.get("path", ".")
    max_depth = payload.get("max_depth", 3)
    try:
        root = Path(path)
        if not root.exists():
            return {"ok": False, "error": f"Path not found: {path}"}
        if not root.is_dir():
            return {"ok": False, "error": f"Not a directory: {path}"}

        lines: List[str] = []
        dir_count = 0
        file_count = 0

        def _walk(directory: Path, prefix: str, depth: int) -> None:
            nonlocal dir_count, file_count
            if depth > max_depth:
                return
            try:
                children = sorted(directory.iterdir(), key=lambda c: (not c.is_dir(), c.name.lower()))
            except PermissionError:
                lines.append(f"{prefix}[permission denied]")
                return

            for i, child in enumerate(children):
                is_last = i == len(children) - 1
                connector = "\\u2514\\u2500\\u2500 " if is_last else "\\u251c\\u2500\\u2500 "
                suffix = "/" if child.is_dir() else ""
                lines.append(f"{prefix}{connector}{child.name}{suffix}")
                if child.is_dir():
                    dir_count += 1
                    _walk(child, prefix + ("    " if is_last else "\\u2502   "), depth + 1)
                else:
                    file_count += 1

        lines.append(f"{root.name}/")
        _walk(root, "", 1)

        tree_str = "\\n".join(lines) + "\\n"
        return {"ok": True, "tree": tree_str, "dirs": dir_count, "files": file_count}
    except PermissionError:
        return {"ok": False, "error": f"Permission denied: {path}"}
    except Exception as exc:
        return {"ok": False, "error": str(exc)}


def op_mkdir(payload: dict) -> dict:
    """Create a directory, optionally creating parent directories."""
    path = payload.get("path", "")
    parents = payload.get("parents", True)
    try:
        if not path:
            return {"ok": False, "error": "No path specified"}
        p = Path(path)
        p.mkdir(parents=parents, exist_ok=False)
        return {"ok": True, "path": str(p.resolve())}
    except FileExistsError:
        return {"ok": False, "error": f"Directory already exists: {path}"}
    except Exception as exc:
        return {"ok": False, "error": str(exc)}


def op_rm(payload: dict) -> dict:
    """Delete a file or directory."""
    path = payload.get("path", "")
    recursive = payload.get("recursive", False)
    try:
        if not path:
            return {"ok": False, "error": "No path specified"}
        if _is_dangerous(path):
            return {"ok": False, "error": "Refusing to delete dangerous system path"}
        p = Path(path)
        if not p.exists():
            return {"ok": False, "error": f"Path not found: {path}"}
        if p.is_dir():
            if not recursive:
                return {"ok": False, "error": "Is a directory (use recursive=true to remove)"}
            shutil.rmtree(p)
        else:
            p.unlink()
        return {"ok": True, "deleted": path}
    except PermissionError:
        return {"ok": False, "error": f"Permission denied: {path}"}
    except Exception as exc:
        return {"ok": False, "error": str(exc)}


def op_stat(payload: dict) -> dict:
    """Return detailed information about a path."""
    path = payload.get("path", "")
    try:
        if not path:
            return {"ok": False, "error": "No path specified"}
        p = Path(path)
        if not p.exists():
            return {"ok": False, "error": f"Path not found: {path}"}
        st = p.stat()
        return {
            "ok": True,
            "path": str(p.resolve()),
            "size": st.st_size,
            "size_human": _human_size(st.st_size),
            "modified": _format_time(st.st_mtime),
            "created": _format_time(st.st_ctime),
            "accessed": _format_time(st.st_atime),
            "is_dir": p.is_dir(),
            "is_file": p.is_file(),
            "is_link": p.is_symlink(),
            "permissions": _mode_to_str(st.st_mode),
        }
    except PermissionError:
        return {"ok": False, "error": f"Permission denied: {path}"}
    except Exception as exc:
        return {"ok": False, "error": str(exc)}


def op_cp(payload: dict) -> dict:
    """Copy a file or directory tree."""
    src = payload.get("src", "")
    dst = payload.get("dst", "")
    try:
        if not src or not dst:
            return {"ok": False, "error": "Both src and dst are required"}
        src_p = Path(src)
        if not src_p.exists():
            return {"ok": False, "error": f"Source not found: {src}"}
        if src_p.is_dir():
            shutil.copytree(src_p, dst)
        else:
            shutil.copy2(src_p, dst)
        size = Path(dst).stat().st_size if Path(dst).is_file() else 0
        return {"ok": True, "bytes_copied": size, "src": src, "dst": dst}
    except Exception as exc:
        return {"ok": False, "error": str(exc)}


def op_mv(payload: dict) -> dict:
    """Move or rename a file / directory."""
    src = payload.get("src", "")
    dst = payload.get("dst", "")
    try:
        if not src or not dst:
            return {"ok": False, "error": "Both src and dst are required"}
        src_p = Path(src)
        if not src_p.exists():
            return {"ok": False, "error": f"Source not found: {src}"}
        shutil.move(src, dst)
        return {"ok": True, "moved": True, "src": src, "dst": dst}
    except Exception as exc:
        return {"ok": False, "error": str(exc)}


def op_find(payload: dict) -> dict:
    """Find files matching a glob pattern."""
    path = payload.get("path", ".")
    pattern = payload.get("pattern", "*")
    max_results = payload.get("max_results", 100)
    try:
        root = Path(path)
        if not root.exists():
            return {"ok": False, "error": f"Path not found: {path}"}

        matches: List[str] = []
        for dirpath, dirnames, filenames in os.walk(root):
            for name in sorted(filenames + dirnames):
                if fnmatch.fnmatch(name, pattern):
                    full = os.path.join(dirpath, name)
                    rel = os.path.relpath(full, root).replace("\\", "/")
                    matches.append(rel)
                    if len(matches) >= max_results:
                        return {"ok": True, "matches": matches, "count": len(matches)}
        return {"ok": True, "matches": matches, "count": len(matches)}
    except Exception as exc:
        return {"ok": False, "error": str(exc)}


def op_du(payload: dict) -> dict:
    """Calculate disk usage of a path."""
    path = payload.get("path", ".")
    try:
        p = Path(path)
        if not p.exists():
            return {"ok": False, "error": f"Path not found: {path}"}
        if p.is_file():
            total = p.stat().st_size
        else:
            total = 0
            for entry in p.rglob("*"):
                try:
                    if entry.is_file():
                        total += entry.stat().st_size
                except (PermissionError, OSError):
                    continue
        return {"ok": True, "total_bytes": total, "total_human": _human_size(total)}
    except Exception as exc:
        return {"ok": False, "error": str(exc)}


# ---------------------------------------------------------------------------
# Dispatcher
# ---------------------------------------------------------------------------

_HANDLERS: Dict[str, Callable[[dict], dict]] = {
    "ls": op_ls,
    "tree": op_tree,
    "mkdir": op_mkdir,
    "rm": op_rm,
    "stat": op_stat,
    "cp": op_cp,
    "mv": op_mv,
    "find": op_find,
    "du": op_du,
}


def dispatch(payload: dict) -> dict:
    """
    Route a file-operation command payload to the correct handler.

    Parameters
    ----------
    payload:
        A dict with at least a ``"type"`` key matching one of the supported
        operation names (ls, tree, mkdir, rm, stat, cp, mv, find, du).

    Returns
    -------
    dict
        ``{"ok": True, ...}`` on success, or ``{"ok": False, "error": "..."}`` on failure.
    """
    cmd_type = payload.get("type", "")
    handler = _HANDLERS.get(cmd_type)
    if handler is None:
        return {"ok": False, "error": f"Unknown file operation: {cmd_type!r}"}
    return handler(payload)


# ---------------------------------------------------------------------------
# Self-test
# ---------------------------------------------------------------------------

def test_fileops() -> None:
    """Create a temporary directory, exercise every operation, then clean up."""
    import tempfile

    tmp = Path(tempfile.mkdtemp(prefix="gcli_fileops_test_"))
    passed = 0
    failed = 0
    try:
        # -- ls on empty dir --
        r = dispatch({"type": "ls", "path": str(tmp)})
        assert r["ok"] and r["entries"] == [], f"ls empty: {r}"
        passed += 1

        # -- mkdir --
        subdir = tmp / "sub"
        r = dispatch({"type": "mkdir", "path": str(subdir)})
        assert r["ok"], f"mkdir: {r}"
        passed += 1

        # -- mkdir with parents --
        deep = tmp / "a" / "b" / "c"
        r = dispatch({"type": "mkdir", "path": str(deep), "parents": True})
        assert r["ok"], f"mkdir parents: {r}"
        passed += 1

        # -- write some files --
        f1 = tmp / "hello.txt"
        f1.write_text("hello world", encoding="utf-8")
        f2 = subdir / "data.csv"
        f2.write_text("a,b,c\n1,2,3\n", encoding="utf-8")
        f3 = tmp / ".hidden"
        f3.write_text("secret", encoding="utf-8")
        passed += 1

        # -- ls without hidden --
        r = dispatch({"type": "ls", "path": str(tmp)})
        assert r["ok"]
        names = [e["name"] for e in r["entries"]]
        assert ".hidden" not in names
        assert "hello.txt" in names
        passed += 1

        # -- ls with hidden --
        r = dispatch({"type": "ls", "path": str(tmp), "show_hidden": True})
        assert r["ok"] and ".hidden" in [e["name"] for e in r["entries"]]
        passed += 1

        # -- stat --
        r = dispatch({"type": "stat", "path": str(f1)})
        assert r["ok"] and r["is_file"] and r["size"] == 11, f"stat: {r}"
        passed += 1

        # -- find --
        r = dispatch({"type": "find", "path": str(tmp), "pattern": "*.txt"})
        assert r["ok"] and r["count"] >= 1, f"find: {r}"
        passed += 1

        # -- tree --
        r = dispatch({"type": "tree", "path": str(tmp), "max_depth": 2})
        assert r["ok"] and r["dirs"] >= 1 and r["files"] >= 2, f"tree: {r}"
        passed += 1

        # -- du --
        r = dispatch({"type": "du", "path": str(tmp)})
        assert r["ok"] and r["total_bytes"] > 0, f"du: {r}"
        passed += 1

        # -- cp --
        copy_dst = tmp / "hello_copy.txt"
        r = dispatch({"type": "cp", "src": str(f1), "dst": str(copy_dst)})
        assert r["ok"] and copy_dst.read_text(encoding="utf-8") == "hello world", f"cp: {r}"
        passed += 1

        # -- mv --
        mv_dst = tmp / "hello_moved.txt"
        r = dispatch({"type": "mv", "src": str(copy_dst), "dst": str(mv_dst)})
        assert r["ok"] and not copy_dst.exists() and mv_dst.exists(), f"mv: {r}"
        passed += 1

        # -- rm file --
        r = dispatch({"type": "rm", "path": str(mv_dst)})
        assert r["ok"] and not mv_dst.exists(), f"rm: {r}"
        passed += 1

        # -- rm dir without recursive (should fail) --
        r = dispatch({"type": "rm", "path": str(subdir)})
        assert not r["ok"], f"rm dir without recursive should fail: {r}"
        passed += 1

        # -- rm dir with recursive --
        r = dispatch({"type": "rm", "path": str(subdir), "recursive": True})
        assert r["ok"] and not subdir.exists(), f"rm recursive: {r}"
        passed += 1

        # -- rm dangerous path --
        r = dispatch({"type": "rm", "path": "/"})
        assert not r["ok"], f"rm dangerous: {r}"
        passed += 1

        # -- unknown command --
        r = dispatch({"type": "bogus"})
        assert not r["ok"], f"unknown cmd: {r}"
        passed += 1

        # -- missing path --
        r = dispatch({"type": "ls", "path": "/nonexistent/path/xyz"})
        assert not r["ok"], f"ls missing: {r}"
        passed += 1

        print(f"fileops tests: {passed} passed, {failed} failed")
    except Exception as exc:
        failed += 1
        print(f"fileops tests FAILED: {exc}")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    test_fileops()
