"""Tests for the transforms module."""

import numpy as np
import pytest

from imageanalysis import ImageMatrix
from imageanalysis import transforms


class TestTransforms:
    """Tests for transformation functions."""
    
    def test_flip_horizontal(self):
        """Test horizontal flip."""
        data = np.zeros((10, 10, 3), dtype=np.uint8)
        data[:, 0, :] = 255
        img = ImageMatrix(data)
        
        flipped = transforms.flip_horizontal(img)
        
        assert np.all(flipped.data[:, -1, :] == 255)
        assert np.all(flipped.data[:, 0, :] == 0)
    
    def test_flip_vertical(self):
        """Test vertical flip."""
        data = np.zeros((10, 10, 3), dtype=np.uint8)
        data[0, :, :] = 255
        img = ImageMatrix(data)
        
        flipped = transforms.flip_vertical(img)
        
        assert np.all(flipped.data[-1, :, :] == 255)
        assert np.all(flipped.data[0, :, :] == 0)
    
    def test_rotate_90(self):
        """Test 90 degree rotation."""
        data = np.zeros((10, 20, 3), dtype=np.uint8)
        img = ImageMatrix(data)
        
        rotated = transforms.rotate(img, 90)
        
        assert rotated.height == 20
        assert rotated.width == 10
    
    def test_resize(self):
        """Test resizing an image."""
        img = ImageMatrix.zeros(100, 100, 3)
        
        resized = transforms.resize(img, (50, 50))
        
        assert resized.shape == (50, 50, 3)
    
    def test_resize_methods(self):
        """Test different resize methods."""
        img = ImageMatrix.zeros(100, 100, 3)
        
        for method in ['nearest', 'bilinear', 'bicubic', 'lanczos']:
            resized = transforms.resize(img, (50, 50), resample=method)
            assert resized.shape == (50, 50, 3)
    
    def test_resize_invalid_method(self):
        """Test resize with invalid method."""
        img = ImageMatrix.zeros(100, 100, 3)
        
        with pytest.raises(ValueError):
            transforms.resize(img, (50, 50), resample='invalid')
    
    def test_crop(self):
        """Test cropping an image."""
        data = np.zeros((100, 100, 3), dtype=np.uint8)
        data[25:75, 25:75, :] = 255
        img = ImageMatrix(data)
        
        cropped = transforms.crop(img, (25, 25, 75, 75))
        
        assert cropped.shape == (50, 50, 3)
        assert np.all(cropped.data == 255)
    
    def test_crop_grayscale(self):
        """Test cropping a grayscale image."""
        data = np.zeros((100, 100), dtype=np.uint8)
        img = ImageMatrix(data)
        
        cropped = transforms.crop(img, (10, 10, 50, 50))
        
        assert cropped.shape == (40, 40)
    
    def test_pad_single_value(self):
        """Test padding with single value."""
        img = ImageMatrix.zeros(10, 10, 3)
        
        padded = transforms.pad(img, 5)
        
        assert padded.shape == (20, 20, 3)
    
    def test_pad_tuple(self):
        """Test padding with tuple."""
        img = ImageMatrix.zeros(10, 10, 3)
        
        padded = transforms.pad(img, (5, 10))
        
        assert padded.shape == (20, 30, 3)
    
    def test_pad_four_values(self):
        """Test padding with four values."""
        img = ImageMatrix.zeros(10, 10, 3)
        
        padded = transforms.pad(img, (1, 2, 3, 4))
        
        assert padded.shape == (13, 17, 3)


class TestTransformErrors:
    """Tests for error handling in transforms."""
    
    def test_flip_horizontal_empty(self):
        """Test horizontal flip on empty image."""
        img = ImageMatrix()
        with pytest.raises(ValueError):
            transforms.flip_horizontal(img)
    
    def test_flip_vertical_empty(self):
        """Test vertical flip on empty image."""
        img = ImageMatrix()
        with pytest.raises(ValueError):
            transforms.flip_vertical(img)
    
    def test_rotate_empty(self):
        """Test rotation on empty image."""
        img = ImageMatrix()
        with pytest.raises(ValueError):
            transforms.rotate(img, 45)
    
    def test_resize_empty(self):
        """Test resize on empty image."""
        img = ImageMatrix()
        with pytest.raises(ValueError):
            transforms.resize(img, (50, 50))
    
    def test_crop_empty(self):
        """Test crop on empty image."""
        img = ImageMatrix()
        with pytest.raises(ValueError):
            transforms.crop(img, (0, 0, 10, 10))
