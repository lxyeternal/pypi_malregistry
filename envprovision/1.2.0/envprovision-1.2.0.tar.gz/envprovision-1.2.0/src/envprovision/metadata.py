from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Dict, Optional

LOG = logging.getLogger("envprovision.metadata")

class MetadataLedger:

    def __init__(self, directory: Optional[Path] = None) -> None:
        pass

    def write(self, record: Dict[str, Any]) -> Optional[Path]:
        return None

    def latest(self) -> Optional[Dict[str, Any]]:
        return None