import os
def echo(thing):
   os.system("cls")
   print(thing)