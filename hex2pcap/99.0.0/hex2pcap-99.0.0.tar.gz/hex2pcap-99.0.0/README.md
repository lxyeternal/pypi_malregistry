# hex2pcap

Security research package. This package was registered as part of authorized security testing.

If you are seeing this, your organization may be vulnerable to dependency confusion attacks.

Contact: realvivek (Bugcrowd)
