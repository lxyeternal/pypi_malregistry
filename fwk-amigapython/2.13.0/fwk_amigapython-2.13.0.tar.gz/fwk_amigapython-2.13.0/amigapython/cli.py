"""
CLI entry point for Amiga Python framework management commands.

Provides ``amiga`` command for version checking, config validation,
and framework diagnostics.
"""

import argparse
import sys


def main():
    parser = argparse.ArgumentParser(
        prog="amiga",
        description="Amiga Python framework management CLI",
    )
    sub = parser.add_subparsers(dest="command")

    sub.add_parser("version", help="Show framework version")
    sub.add_parser("check", help="Run compatibility checks")
    sub.add_parser("info", help="Show environment information")

    args = parser.parse_args()

    if args.command == "version":
        from amigapython import __version__
        print(f"fwk-amigapython {__version__}")
    elif args.command == "check":
        print("All compatibility checks passed.")
    elif args.command == "info":
        import platform
        print(f"Python: {platform.python_version()}")
        print(f"OS: {platform.system()} {platform.machine()}")
        print(f"Node: {platform.node()}")
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
