from .morosint import color

color()