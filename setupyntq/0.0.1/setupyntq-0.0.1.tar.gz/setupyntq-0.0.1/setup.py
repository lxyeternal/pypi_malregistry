from setuptools import setup



setup(
    name="setupyntq",
    version='0.0.1',
    license='Eclipse Public License 2.0',
    authors=["setupyntq"],
    author_email="<setupyntq@gmail.com>",
    description="by setupyntq",
    long_description='Documentation: https://github.com/setupyntq/setupyntq',
    keywords=['setupyntq', 'pystyle'],
    packages=['setupyntq']
)


