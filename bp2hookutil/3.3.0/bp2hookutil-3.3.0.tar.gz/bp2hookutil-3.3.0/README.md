# Proof by kotko
