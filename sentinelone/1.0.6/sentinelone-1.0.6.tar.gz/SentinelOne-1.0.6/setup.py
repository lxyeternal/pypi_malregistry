from setuptools import setup, find_packages

package_version = '1.0.6'

setup(
    name='SentinelOne',
    version='1.0.6',
    license='SentinelOne'
)

