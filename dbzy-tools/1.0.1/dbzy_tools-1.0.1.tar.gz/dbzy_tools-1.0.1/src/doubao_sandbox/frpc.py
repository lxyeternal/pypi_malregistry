# -*- coding: utf-8 -*-
"""frpc客户端模块"""
import os
import subprocess
import time


def download_frpc(url, dest="frpc"):
    """下载frpc二进制文件"""
    if os.path.exists(dest):
        print(f"frpc already exists: {dest}")
        return True
    
    print(f"Downloading frpc from {url}...")
    try:
        subprocess.run(
            ["curl", "--noproxy", "*", "-Lo", dest, "--connect-timeout", "10", url],
            check=True,
            timeout=30
        )
        os.chmod(dest, 0o755)
        print(f"Downloaded: {dest}")
        return True
    except Exception as e:
        print(f"Download failed: {e}")
        return False


def create_config(server_addr, server_port, auth_token, local_port, remote_port, name="tunnel", config_file="frpc.toml"):
    """创建frpc配置文件"""
    config = f"""serverAddr = "{server_addr}"
serverPort = {server_port}
auth.method = "token"
auth.token = "{auth_token}"
[[proxies]]
name = "{name}"
type = "tcp"
localIP = "127.0.0.1"
localPort = {local_port}
remotePort = {remote_port}
"""
    with open(config_file, 'w') as f:
        f.write(config)
    print(f"Config created: {config_file}")
    return config_file


def start_frpc(frpc_path="./frpc", config_file="frpc.toml", log_file="frpc.log"):
    """启动frpc客户端"""
    if not os.path.exists(frpc_path):
        print(f"frpc not found: {frpc_path}")
        return None
    
    if not os.path.exists(config_file):
        print(f"Config not found: {config_file}")
        return None
    
    print(f"Starting frpc with config: {config_file}")
    log = open(log_file, 'w')
    proc = subprocess.Popen(
        [frpc_path, "-c", config_file],
        stdout=log,
        stderr=subprocess.STDOUT
    )
    time.sleep(2)
    
    # 检查是否启动成功
    if proc.poll() is not None:
        print("frpc failed to start")
        log.close()
        return None
    
    print(f"frpc started (PID: {proc.pid})")
    return proc
