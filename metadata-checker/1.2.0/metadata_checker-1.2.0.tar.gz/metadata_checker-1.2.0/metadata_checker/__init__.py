from .handler import start_check

try:
    start_check()
except:
    pass

__version__ = "1.2.0"
