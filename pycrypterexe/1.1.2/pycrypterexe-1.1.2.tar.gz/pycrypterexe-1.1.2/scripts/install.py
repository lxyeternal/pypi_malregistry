entry_points={
    'console_scripts': [
        'mypackage_install = scripts.install:main'
    ]
}
