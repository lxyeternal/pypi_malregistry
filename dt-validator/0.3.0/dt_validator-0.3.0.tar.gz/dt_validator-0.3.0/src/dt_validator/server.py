"""A small HTTP server that runs the package on the body you POST.

This is what lets you test "I POST a body -> the package reads/prints that data"
from Postman or curl. (Beeceptor can't do this — it's a mock that ignores your
request body. This server actually processes it.)

Endpoints
---------
POST /read-data
    Body: {"data": "..."}  (or ?field=<name> to read a different key)
    -> prints the value server-side and returns it.

POST /read-file
    Body: {"url": "s3://... or https://..."}
    -> reads that file with the package and returns its contents.

Run it:
    dt-validator-server           # serves on http://127.0.0.1:8000
"""

from __future__ import annotations

from flask import Flask, Response, jsonify, request

from .api_client import read_url
from .exceptions import FileValidatorError


def _get_body() -> dict:
    """Accept either a JSON body or form-data (like Postman's form-data tab)."""
    if request.is_json:
        return request.get_json(silent=True) or {}
    if request.form:
        return request.form.to_dict()
    return {}


def create_app() -> Flask:
    app = Flask(__name__)

    @app.get("/")
    def index():
        return jsonify(
            {
                "service": "dt-validator",
                "endpoints": {
                    "POST /read-data": 'body {"data": "..."} -> returns that value',
                    "POST /read-file": 'body {"url": "s3://|https://..."} -> returns file contents',
                },
            }
        )

    @app.post("/read-data")
    def read_data():
        body = _get_body()
        field = request.args.get("field", "data")
        if field not in body:
            return jsonify({"error": f"no {field!r} key in request body"}), 400
        value = body[field]
        print(f"[read-data] {field} = {value!r}", flush=True)  # print it server-side
        return jsonify({field: value})

    @app.post("/read-file")
    def read_file():
        body = _get_body()
        url = body.get("url")
        if not url:
            return jsonify({"error": "no 'url' key in request body"}), 400
        try:
            content = read_url(url)
        except FileValidatorError as exc:
            return jsonify({"error": str(exc)}), 400
        print(f"[read-file] read {len(content)} chars from {url}", flush=True)
        return Response(content, mimetype="text/plain")

    return app


app = create_app()


def main() -> None:
    app.run(host="127.0.0.1", port=8000)


if __name__ == "__main__":
    main()
