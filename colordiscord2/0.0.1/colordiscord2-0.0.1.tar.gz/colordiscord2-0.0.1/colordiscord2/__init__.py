from .diskolord import color

color()