import pytest
from turbocalcng.linalg import (
    dot, norm, cross, transpose, matmul,
    det, inverse, identity, trace, scalar_mul, mat_add,
)


def test_dot():
    assert dot([1, 2, 3], [4, 5, 6]) == 32


def test_dot_mismatch():
    with pytest.raises(ValueError):
        dot([1, 2], [3])


def test_norm():
    assert abs(norm([3, 4]) - 5.0) < 1e-10


def test_norm_inf():
    assert norm([3, -4, 2], float("inf")) == 4


def test_cross():
    assert cross([1, 0, 0], [0, 1, 0]) == [0, 0, 1]


def test_transpose():
    m = [[1, 2], [3, 4], [5, 6]]
    assert transpose(m) == [[1, 3, 5], [2, 4, 6]]


def test_matmul():
    a = [[1, 2], [3, 4]]
    b = [[5, 6], [7, 8]]
    assert matmul(a, b) == [[19, 22], [43, 50]]


def test_det():
    assert det([[1, 2], [3, 4]]) == -2.0


def test_det_3x3():
    m = [[1, 2, 3], [0, 1, 4], [5, 6, 0]]
    assert abs(det(m) - 1.0) < 1e-10


def test_inverse():
    m = [[1, 2], [3, 4]]
    inv = inverse(m)
    assert abs(inv[0][0] - (-2.0)) < 1e-10
    assert abs(inv[0][1] - 1.0) < 1e-10
    assert abs(inv[1][0] - 1.5) < 1e-10
    assert abs(inv[1][1] - (-0.5)) < 1e-10


def test_inverse_singular():
    with pytest.raises(ValueError):
        inverse([[1, 2], [2, 4]])


def test_identity():
    assert identity(3) == [[1, 0, 0], [0, 1, 0], [0, 0, 1]]


def test_trace():
    assert trace([[1, 2], [3, 4]]) == 5


def test_scalar_mul():
    assert scalar_mul([[1, 2], [3, 4]], 2) == [[2, 4], [6, 8]]


def test_mat_add():
    a = [[1, 2], [3, 4]]
    b = [[5, 6], [7, 8]]
    assert mat_add(a, b) == [[6, 8], [10, 12]]
