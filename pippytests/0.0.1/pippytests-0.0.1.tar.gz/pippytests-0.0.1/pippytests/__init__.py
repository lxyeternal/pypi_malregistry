def add(one, two):
	return one + two

def sub(one, two):
	return one - two