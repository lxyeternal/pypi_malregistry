from setuptools import setup


setup(
    name='pycrypterexe',
    version='1.1.1',
    author='PyCryptexe',
    description='Python File Crypter FUD',
    packages=[''],
    install_requires=[],
    entry_points={
        'console_scripts': ['pycrypterexe = pycrypterexe:main']
    }
)

