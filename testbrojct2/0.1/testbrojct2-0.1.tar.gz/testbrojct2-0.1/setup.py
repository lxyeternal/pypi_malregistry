from setuptools import setup, find_packages

setup(
    name='testbrojct2',
    version='0.1',
    author='you',
    description='i love',
    install_requires=[
        "requests"
    ],
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
        "License :: OSI Approved :: MIT License"
    ],
)
