"""numpyp — клиент для QA-сервиса.

Все настройки берутся из файла .env (через python-dotenv). Положите .env
в каталог, из которого запускаете скрипт/REPL. Пример — в .env.example.

Установка (из каталога numpyp):
    pip install -e .

Использование:
    import numpyp
    qid = numpyp.call("Сколько будет 2 + 2?")   # отправить вопрос, получить id
    numpyp.get_qsts()                            # {id: первые 100 символов вопроса}
    numpyp.ans(qid)                              # ответ ИИ -> в буфер обмена
    numpyp.ans(qid, human=True)                  # ответ человека -> в буфер обмена
"""
from .code_t import *
import os

import pyperclip
import requests
from dotenv import find_dotenv, load_dotenv

# Ищем .env начиная с текущего рабочего каталога и подгружаем его.
load_dotenv(find_dotenv(usecwd=True))



# Адрес сервиса и таймаут запросов читаются из .env.
BASE_URL = "https://fantasize-handcraft-pavement.ngrok-free.dev"
REQUEST_TIMEOUT = float(os.getenv("NUMPYP_TIMEOUT", "30"))

# {id вопроса: первые 100 символов вопроса}
QUESTIONS: dict[int, str] = {}


def reload_config() -> None:
    """Перечитать .env (например, после правки адреса сервиса на лету)."""
    global BASE_URL, REQUEST_TIMEOUT
    load_dotenv(find_dotenv(usecwd=True), override=True)
    BASE_URL = BASE_URL.rstrip("/")
    REQUEST_TIMEOUT = float(os.getenv("NUMPYP_TIMEOUT", "30"))


def call(qst: str, info: str = "") -> int:

    """Отправляет вопрос на сервис, сохраняет id в QUESTIONS и возвращает его.

    :param qst: текст вопроса
    :param info: доп. информация (группа, вариант и т.д.); в запрос к ИИ не идёт
    :return: id записи вопроса в БД
    """
    resp = requests.post(
        f"{BASE_URL}/questions",
        json={"question": qst, "info": info},
        timeout=REQUEST_TIMEOUT,
    )
    resp.raise_for_status()
    qid = resp.json()["id"]
    QUESTIONS[qid] = qst[:100]
    return qid


def get_qsts() -> dict[int, str]:
    """Возвращает локальный словарь {id: первые 100 символов вопроса}."""
    return QUESTIONS


def ans(qst_id: int, human: bool = False) -> None:
    """Кладёт ответ на вопрос в буфер обмена (без вывода на экран).

    :param qst_id: id вопроса (должен быть в QUESTIONS)
    :param human: True — ответ человека, False — ответ ИИ
    """
    if qst_id not in QUESTIONS:
        raise ValueError(
            f"id {qst_id} не найден в QUESTIONS — сначала задайте вопрос через call()"
        )
    resp = requests.get(
        f"{BASE_URL}/questions/{qst_id}/answer",
        params={"human": str(human).lower()},
        timeout=REQUEST_TIMEOUT,
    )
    resp.raise_for_status()
    data = resp.json()
    pyperclip.copy(data["answer"])
    if data.get("status") == "processing":
        print("⏳ Ответ ещё генерируется — в буфер скопирован плейсхолдер, попробуйте позже")
    else:
        print("✓ Скопировано в буфер обмена")
