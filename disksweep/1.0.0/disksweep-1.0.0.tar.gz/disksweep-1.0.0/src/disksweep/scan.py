"""Dependency-free filesystem scanner for regenerable directories.

Never follows symlinks; never descends into a matched directory or .git.
Mirrors the npm `disksweep` scanner.
"""

from __future__ import annotations

import math
import os
import time

# Unambiguous, tool-specific, always-regenerable directories — safe by default.
DEFAULT_INCLUDE = [
    "node_modules",
    ".venv",
    "venv",
    "__pycache__",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
    ".next",
    ".nuxt",
    ".svelte-kit",
    ".turbo",
    ".parcel-cache",
]

# Heavier but more AMBIGUOUS names: usually build output, but can occasionally be
# a hand-authored source folder. Opt-in only, via --aggressive or --include.
AGGRESSIVE_INCLUDE = ["dist", "build", "coverage", "target"]

_SKIP_ALWAYS = {".git"}


def dir_stats(path: str):
    """Total size (bytes) and most-recent mtime (ms) of a directory subtree.
    Symlinks are not followed; unreadable entries are skipped."""
    size = 0
    mtime = 0.0
    stack = [path]
    while stack:
        cur = stack.pop()
        try:
            entries = list(os.scandir(cur))
        except OSError:
            continue
        for e in entries:
            try:
                if e.is_symlink():
                    continue
                if e.is_dir():
                    stack.append(e.path)
                elif e.is_file():
                    st = e.stat()
                    size += st.st_size
                    m = st.st_mtime * 1000
                    if m > mtime:
                        mtime = m
            except OSError:
                continue
    return size, mtime


def scan(root, include=None, older_than_days=None, now=None):
    """Scan `root` for regenerable directories.

    A provided `include` (even an empty list) is respected; only None uses the
    defaults — so an explicit empty include matches nothing rather than silently
    arming the full destructive default set.

    Returns a list of dicts {path, name, size, mtime} sorted by size descending.
    """
    inc = set(include if include is not None else DEFAULT_INCLUDE)
    now = now if now is not None else time.time() * 1000
    cutoff = now - older_than_days * 86_400_000 if older_than_days is not None else None

    results = []
    stack = [os.fspath(root)]
    while stack:
        d = stack.pop()
        try:
            entries = list(os.scandir(d))
        except OSError:
            continue
        for e in entries:
            try:
                if e.is_symlink() or not e.is_dir():
                    continue
            except OSError:
                continue
            name = e.name
            if name in inc:
                size, mtime = dir_stats(e.path)
                if cutoff is not None and mtime > cutoff:
                    continue  # too recently used
                results.append({"path": e.path, "name": name, "size": size, "mtime": mtime})
                # do NOT descend into a matched directory
            elif name not in _SKIP_ALWAYS:
                stack.append(e.path)

    results.sort(key=lambda r: -r["size"])
    return results


def human_size(num_bytes) -> str:
    """Human-readable byte size, e.g. 1536 -> "1.5 KB"."""
    units = ["B", "KB", "MB", "GB", "TB"]
    n = float(num_bytes)
    i = 0
    while n >= 1024 and i < len(units) - 1:
        n /= 1024
        i += 1
    if i == 0:
        rounded = int(num_bytes)
    elif n >= 100:
        rounded = round(n)
    else:
        rounded = round(n * 10) / 10
    if isinstance(rounded, float) and rounded.is_integer():
        rounded = int(rounded)
    return f"{rounded} {units[i]}"


def format_age(mtime_ms, now=None) -> str:
    """Compact relative age, e.g. "3w", "2mo", "5h", "just now"."""
    if not mtime_ms:
        return "—"
    now = now if now is not None else time.time() * 1000
    s = max(0.0, (now - mtime_ms) / 1000)
    for label, secs in (
        ("y", 31_536_000),
        ("mo", 2_592_000),
        ("w", 604_800),
        ("d", 86_400),
        ("h", 3_600),
        ("m", 60),
    ):
        if s >= secs:
            return f"{math.floor(s / secs)}{label}"
    return "just now"
