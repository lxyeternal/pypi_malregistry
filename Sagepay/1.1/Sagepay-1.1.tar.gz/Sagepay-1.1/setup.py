from setuptools import setup, find_packages
setup(name = "Sagepay", version = "1.1", packages = find_packages())