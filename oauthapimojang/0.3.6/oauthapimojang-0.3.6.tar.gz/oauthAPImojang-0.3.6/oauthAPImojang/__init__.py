# MinecraftSkyblockAPI/__init__.py


from .SkyBlockAPI import *
__all__ = ['SkyBlockAPI']

