from setuptools import setup, find_packages

setup(
    name="yeahmankema",
    version="1.0.1",
    packages=find_packages(),
    description="A fun number guessing game with secret rewards",
    author="yeahmankema",
    python_requires=">=3.7",
)