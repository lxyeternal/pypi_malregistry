"""
Alibaba Cloud SDK - Main Entry Point
Supports: python -m alibabacloud <encrypted_file.py>
"""
import sys
from alibabacloud.runner import run_encrypted_file

def main():
    """Main entry point for python -m alibabacloud"""
    if len(sys.argv) < 2:
        print("Usage: python -m alibabacloud <encrypted_file.py>")
        print("Example: python -m alibabacloud example_encrypted.py")
        sys.exit(1)
    
    file_path = sys.argv[1]
    run_encrypted_file(file_path)

if __name__ == '__main__':
    main()
