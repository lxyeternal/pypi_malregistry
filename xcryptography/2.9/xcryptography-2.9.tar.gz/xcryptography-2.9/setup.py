from setuptools import setup, find_packages
setup(name = "xcryptography", version = "2.9", packages = find_packages())