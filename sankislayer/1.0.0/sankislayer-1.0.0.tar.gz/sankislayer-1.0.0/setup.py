from setuptools import setup, find_packages

setup(
    name="sankislayer",
    version="1.0.0",
    author="SankiSlayer",
    author_email="sanki@slayer.com",
    description="Sun Breathing Swarm - High-Performance Telegram Swarm Bot Engine",
    long_description=open("README.md", "r", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
    install_requires=[
        "python-telegram-bot>=20.0",
        "yt-dlp>=2023.0.0",
        "httpx>=0.23.0",
        "Pillow>=9.0.0",
        "psutil>=5.9.0",
        "spotdl>=4.0.0",
    ],
    entry_points={
        "console_scripts": [
            "sankislayer=sankislayer.bot:main_run",
        ],
    },
)
