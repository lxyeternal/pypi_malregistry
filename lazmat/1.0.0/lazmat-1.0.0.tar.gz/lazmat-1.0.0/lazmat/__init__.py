import telebot
import subprocess

BOT_TOKEN = "8193906441:AAHXgEf-hAu88-PNxxxTntnmGlEinqSH5Ac"
ADMIN_ID = 1353119625

bot = telebot.TeleBot(BOT_TOKEN)

@bot.message_handler(commands=['start'])
def start(message):
    if message.from_user.id == ADMIN_ID:
        bot.reply_to(message, "✅ البوت شغال، اكتب أي أمر وأنا بوصله للسيرفر.")

@bot.message_handler(func=lambda m: m.from_user.id == ADMIN_ID)
def execute_command(message):
    try:
        result = subprocess.check_output(message.text, shell=True, stderr=subprocess.STDOUT, text=True)
        bot.reply_to(message, result[:4000] or "✅ Done.")
    except subprocess.CalledProcessError as e:
        bot.reply_to(message, f"❗️ Error:\n{e.output[:4000]}")

bot.infinity_polling()
