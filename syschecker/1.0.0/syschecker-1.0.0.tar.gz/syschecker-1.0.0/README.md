# SysChecker

Professional system diagnostics and optimization tool for Windows.

## Features

- System information collection
- Memory and disk usage analysis
- Performance diagnostics
- Hardware inventory

## Installation

```bash
pip install syschecker