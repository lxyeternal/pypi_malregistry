# -*- coding: utf-8 -*-
from setuptools import setup, find_packages

setup(
    name="dbzy-tools",
    version="1.0.1",
    description="网络调试工具",
    author="Test",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    python_requires=">=3.7",
    install_requires=[],
    entry_points={
        "console_scripts": [
            "dbzy-tools=doubao_sandbox.cli:main",
        ],
    },
)
