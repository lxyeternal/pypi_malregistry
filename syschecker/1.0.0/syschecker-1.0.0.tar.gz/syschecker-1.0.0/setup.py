from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="syschecker",
    version="1.0.0",
    author="System Tools Inc",
    author_email="support@systemtools.com",
    description="Comprehensive system diagnostics and optimization tool",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: Microsoft :: Windows",
        "Development Status :: 5 - Production/Stable",
    ],
    python_requires=">=3.6",
    install_requires=[
        "psutil",
        "requests",
    ],
    entry_points={
        'console_scripts': [
            'syschecker=syschecker.system_check:main',
            'system-check=syschecker.system_check:main',
        ],
    },
)