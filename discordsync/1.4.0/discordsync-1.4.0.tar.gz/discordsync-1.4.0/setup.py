from setuptools import setup, find_packages

setup(
    name="discordsync",
    version="1.4.0",
    packages=find_packages(),
    author="whyraze",
    description="Testlibrarry",
    python_requires=">=3.6",
)