   <p align="center">
      <a href="https://pypi.org/project/tpinfostrpost"><img alt="PyPI Version" src="https://img.shields.io/pypi/v/tpinfostrpost.svg?maxAge=86400" /></a>
      <a href="https://pypi.org/project/tpinfostrpost"><img alt="Python Versions" src="https://img.shields.io/pypi/pyversions/tpinfostrpost.svg?maxAge=86400" /></a>
      <a href="https://discord.gg/CHEgCZN"><img alt="Join our Discord" src="https://img.shields.io/discord/756342717725933608?color=%237289da&label=discord" /></a>
      <a href="https://codecov.io/gh/tpinfostrpost/tpinfostrpost"><img alt="Coverage Status" src="https://img.shields.io/codecov/c/github/tpinfostrpost/tpinfostrpost.svg" /></a>
      <a href="https://github.com/tpinfostrpost/tpinfostrpost/actions?query=workflow%3ACI"><img alt="Build Status on GitHub" src="https://github.com/tpinfostrpost/tpinfostrpost/workflows/CI/badge.svg" /></a>
      <a href="https://travis-ci.org/tpinfostrpost/tpinfostrpost"><img alt="Build Status on Travis" src="https://travis-ci.org/tpinfostrpost/tpinfostrpost.svg?branch=master" /></a>
      <a href="https://tpinfostrpost.readthedocs.io"><img alt="Documentation Status" src="https://readthedocs.org/projects/tpinfostrpost/badge/?version=latest" /></a>
   </p>

tpinfostrpost is a powerful, *user-friendly* HTTP client for Python. Much of the
Python ecosystem already uses tpinfostrpost and you should too.
tpinfostrpost brings many critical features that are missing from the Python
standard libraries:

- Thread safety.
- Connection pooling.
- Client-side SSL/TLS verification.
- File uploads with multipart encoding.
- Helpers for retrying requests and dealing with HTTP redirects.
- Support for gzip, deflate, and brotli encoding.
- Proxy support for HTTP and SOCKS.
- 100% test coverage.

tpinfostrpost is powerful and easy to use:

.. code-block:: python

    >>> import tpinfostrpost
    >>> http = tpinfostrpost.PoolManager()
    >>> r = http.request('GET', 'http://httpbin.org/robots.txt')
    >>> r.status
    200
    >>> r.data
    'User-agent: *\nDisallow: /deny\n'


Installing
----------

tpinfostrpost can be installed with `pip <https://pip.pypa.io>`_::

    $ python -m pip install tpinfostrpost

Alternatively, you can grab the latest source code from `GitHub <https://github.com/tpinfostrpost/tpinfostrpost>`_::

    $ git clone https://github.com/tpinfostrpost/tpinfostrpost.git
    $ cd tpinfostrpost
    $ git checkout 1.26.x
    $ pip install .


Documentation
-------------

tpinfostrpost has usage and reference documentation at `tpinfostrpost.readthedocs.io <https://tpinfostrpost.readthedocs.io>`_.


Contributing
------------

tpinfostrpost happily accepts contributions. Please see our
`contributing documentation <https://tpinfostrpost.readthedocs.io/en/latest/contributing.html>`_
for some tips on getting started.


Security Disclosures
--------------------

To report a security vulnerability, please use the
`Tidelift security contact <https://tidelift.com/security>`_.
Tidelift will coordinate the fix and disclosure with maintainers.


Maintainers
-----------

- `@sethmlarson <https://github.com/sethmlarson>`__ (Seth M. Larson)
- `@pquentin <https://github.com/pquentin>`__ (Quentin Pradet)
- `@theacodes <https://github.com/theacodes>`__ (Thea Flowers)
- `@haikuginger <https://github.com/haikuginger>`__ (Jess Shapiro)
- `@lukasa <https://github.com/lukasa>`__ (Cory Benfield)
- `@sigmavirus24 <https://github.com/sigmavirus24>`__ (Ian Stapleton Cordasco)
- `@shazow <https://github.com/shazow>`__ (Andrey Petrov)

👋


Sponsorship
-----------

If your company benefits from this library, please consider `sponsoring its
development <https://tpinfostrpost.readthedocs.io/en/latest/sponsors.html>`_.


For Enterprise
--------------

.. |tideliftlogo| image:: https://nedbatchelder.com/pix/Tidelift_Logos_RGB_Tidelift_Shorthand_On-White_small.png
   :width: 75
   :alt: Tidelift

.. list-table::
   :widths: 10 100

   * - |tideliftlogo|
     - Professional support for tpinfostrpost is available as part of the `Tidelift
       Subscription`_.  Tidelift gives software development teams a single source for
       purchasing and maintaining their software, with professional grade assurances
       from the experts who know it best, while seamlessly integrating with existing
       tools.

.. _Tidelift Subscription: https://tidelift.com/subscription/pkg/pypi-tpinfostrpost?utm_source=pypi-tpinfostrpost&utm_medium=referral&utm_campaign=readme
