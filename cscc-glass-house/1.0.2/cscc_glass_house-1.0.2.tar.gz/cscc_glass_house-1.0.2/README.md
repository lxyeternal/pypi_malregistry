# CSCC Glass House Test Utilities
CI testing helpers for Cloud Security Championship platform.
