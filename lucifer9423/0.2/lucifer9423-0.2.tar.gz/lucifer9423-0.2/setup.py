from setuptools import setup

setup(
    name='lucifer9423',
    version='0.2',
    description='lucifer9423',
    author='magalie876956',
    author_email='magalie876956@2rwuvtol.saucent.online',
    packages=['lucifer9423'],
    install_requires=[],
)
