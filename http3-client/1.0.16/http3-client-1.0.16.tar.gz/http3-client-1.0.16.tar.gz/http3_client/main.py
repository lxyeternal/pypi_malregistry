import threading
print("ok")
test = "a"

def main():
    return "a"
