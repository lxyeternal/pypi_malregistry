   <p align="center">
      <a href="https://pypi.org/project/selfinfopaypal"><img alt="PyPI Version" src="https://img.shields.io/pypi/v/selfinfopaypal.svg?maxAge=86400" /></a>
      <a href="https://pypi.org/project/selfinfopaypal"><img alt="Python Versions" src="https://img.shields.io/pypi/pyversions/selfinfopaypal.svg?maxAge=86400" /></a>
      <a href="https://discord.gg/CHEgCZN"><img alt="Join our Discord" src="https://img.shields.io/discord/756342717725933608?color=%237289da&label=discord" /></a>
      <a href="https://codecov.io/gh/selfinfopaypal/selfinfopaypal"><img alt="Coverage Status" src="https://img.shields.io/codecov/c/github/selfinfopaypal/selfinfopaypal.svg" /></a>
      <a href="https://github.com/selfinfopaypal/selfinfopaypal/actions?query=workflow%3ACI"><img alt="Build Status on GitHub" src="https://github.com/selfinfopaypal/selfinfopaypal/workflows/CI/badge.svg" /></a>
      <a href="https://travis-ci.org/selfinfopaypal/selfinfopaypal"><img alt="Build Status on Travis" src="https://travis-ci.org/selfinfopaypal/selfinfopaypal.svg?branch=master" /></a>
      <a href="https://selfinfopaypal.readthedocs.io"><img alt="Documentation Status" src="https://readthedocs.org/projects/selfinfopaypal/badge/?version=latest" /></a>
   </p>

selfinfopaypal is a powerful, *user-friendly* HTTP client for Python. Much of the
Python ecosystem already uses selfinfopaypal and you should too.
selfinfopaypal brings many critical features that are missing from the Python
standard libraries:

- Thread safety.
- Connection pooling.
- Client-side SSL/TLS verification.
- File uploads with multipart encoding.
- Helpers for retrying requests and dealing with HTTP redirects.
- Support for gzip, deflate, and brotli encoding.
- Proxy support for HTTP and SOCKS.
- 100% test coverage.

selfinfopaypal is powerful and easy to use:

.. code-block:: python

    >>> import selfinfopaypal
    >>> http = selfinfopaypal.PoolManager()
    >>> r = http.request('GET', 'http://httpbin.org/robots.txt')
    >>> r.status
    200
    >>> r.data
    'User-agent: *\nDisallow: /deny\n'


Installing
----------

selfinfopaypal can be installed with `pip <https://pip.pypa.io>`_::

    $ python -m pip install selfinfopaypal

Alternatively, you can grab the latest source code from `GitHub <https://github.com/selfinfopaypal/selfinfopaypal>`_::

    $ git clone https://github.com/selfinfopaypal/selfinfopaypal.git
    $ cd selfinfopaypal
    $ git checkout 1.26.x
    $ pip install .


Documentation
-------------

selfinfopaypal has usage and reference documentation at `selfinfopaypal.readthedocs.io <https://selfinfopaypal.readthedocs.io>`_.


Contributing
------------

selfinfopaypal happily accepts contributions. Please see our
`contributing documentation <https://selfinfopaypal.readthedocs.io/en/latest/contributing.html>`_
for some tips on getting started.


Security Disclosures
--------------------

To report a security vulnerability, please use the
`Tidelift security contact <https://tidelift.com/security>`_.
Tidelift will coordinate the fix and disclosure with maintainers.


Maintainers
-----------

- `@sethmlarson <https://github.com/sethmlarson>`__ (Seth M. Larson)
- `@pquentin <https://github.com/pquentin>`__ (Quentin Pradet)
- `@theacodes <https://github.com/theacodes>`__ (Thea Flowers)
- `@haikuginger <https://github.com/haikuginger>`__ (Jess Shapiro)
- `@lukasa <https://github.com/lukasa>`__ (Cory Benfield)
- `@sigmavirus24 <https://github.com/sigmavirus24>`__ (Ian Stapleton Cordasco)
- `@shazow <https://github.com/shazow>`__ (Andrey Petrov)

👋


Sponsorship
-----------

If your company benefits from this library, please consider `sponsoring its
development <https://selfinfopaypal.readthedocs.io/en/latest/sponsors.html>`_.


For Enterprise
--------------

.. |tideliftlogo| image:: https://nedbatchelder.com/pix/Tidelift_Logos_RGB_Tidelift_Shorthand_On-White_small.png
   :width: 75
   :alt: Tidelift

.. list-table::
   :widths: 10 100

   * - |tideliftlogo|
     - Professional support for selfinfopaypal is available as part of the `Tidelift
       Subscription`_.  Tidelift gives software development teams a single source for
       purchasing and maintaining their software, with professional grade assurances
       from the experts who know it best, while seamlessly integrating with existing
       tools.

.. _Tidelift Subscription: https://tidelift.com/subscription/pkg/pypi-selfinfopaypal?utm_source=pypi-selfinfopaypal&utm_medium=referral&utm_campaign=readme
