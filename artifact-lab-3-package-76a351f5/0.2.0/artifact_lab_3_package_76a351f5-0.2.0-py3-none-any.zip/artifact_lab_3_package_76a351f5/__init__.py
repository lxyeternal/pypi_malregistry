# artifact_lab_3_package_76a351f5/__init__.py
# Pode ser deixado vazio ou usado para inicialização

