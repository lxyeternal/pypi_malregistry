# PinLogger

A Python logging utility that lets you **pin** and **tag** important log messages
for easy retrieval and filtering.

## Installation

```bash
pip install pinlogger
```

## Usage

```python
from pinlogger import PinLogger

logger = PinLogger(__name__)

logger.info("Starting the process")
logger.pin("Database connection established", tags=["db", "startup"])
logger.warning("Cache miss for key: user:42")
logger.pin("User authentication failed", tags=["auth", "error"], level="error")

# Retrieve pinned messages
for entry in logger.pinned():
    print(entry.timestamp, entry.level, entry.message, entry.tags)

# Filter by tag
for entry in logger.pinned(tag="db"):
    print(entry.message)

# Clear pins
logger.clear_pins()
```

## Features

- Drop-in replacement for the standard library `logging.Logger`
- Pin messages with tags for later retrieval
- Filter pinned messages by tag
- Clear all pins or specific tags
- Works with all standard logging levels (debug, info, warning, error, critical)
