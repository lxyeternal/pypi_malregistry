from setuptools import setup
setup(name="python-splib", version="1.4.3", packages=["splib","splib._internal"], install_requires=['python-tracing>=0.1.5','shopee-sp-protocol>=0.4.0','garena-common>=1.0.25','loggingtool-shopee'], description=("This is splib for python"))
