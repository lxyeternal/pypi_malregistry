from setuptools import setup

setup(
    name="mulaptested-pakname",
    version="1.0.1",
    description="Safe POC for typo squatting/dependency confusion testing",
    author="Your Name",
    license="MIT",
    scripts=['notification.py'],
    install_requires=['requests', 'setuptools'],  # أضف setuptools لدعم pkg_resources
)