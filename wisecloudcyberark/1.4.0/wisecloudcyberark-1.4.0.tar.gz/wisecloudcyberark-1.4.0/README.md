# wisecloudcyberark

> WiseCloud CyberArk integration — credential proxy client for CyberArk CCP/AIM with OAuth2 authentication flow.

## Installation

```bash
pip install wisecloudcyberark
```

## License

Apache 2.0
