from setuptools import setup, find_packages

package_version = '1.0.2'

setup(
    name='SentinelOne',
    version='1.0.2',
    license='SentinelOne'
)

