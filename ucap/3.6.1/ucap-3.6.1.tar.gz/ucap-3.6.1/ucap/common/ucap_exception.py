"""
Basic type of UCAP exception.
"""


class UcapException(Exception):  # noqa: N818
    """
    Basic type of UCAP exception.
    """
