from setuptools import setup, find_packages
setup(name = "e89-security", version = "1.1", packages = find_packages())