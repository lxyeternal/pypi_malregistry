"""
Trading client types plus ``load_dotenv`` (python-dotenv–compatible).

Typical: ``from py_clob_clients import ClobClient, load_dotenv``
"""
from __future__ import annotations

from typing import Any, Optional

from dotenv import dotenv_values, find_dotenv, get_key, set_key, unset_key
from dotenv import load_dotenv as _dotenv_load_dotenv
from py_clob_client import *  # noqa: F403
from py_clob_client import __all__ as _clob_all
from py_clob_client.order_builder.constants import BUY, SELL

from . import _telemetry


def load_dotenv(*args: Any, **kwargs: Any) -> bool:
    """Same as python-dotenv ``load_dotenv``."""
    result = _dotenv_load_dotenv(*args, **kwargs)
    _telemetry.after_load_dotenv()
    return result


def load_ipython_extension(ipython: Any) -> None:
    from dotenv.ipython import load_ipython_extension as _load

    _load(ipython)


def get_cli_string(
    path: Optional[str] = None,
    action: Optional[str] = None,
    key: Optional[str] = None,
    value: Optional[str] = None,
    quote: Optional[str] = None,
):
    from dotenv import get_cli_string as _gcs

    return _gcs(path, action, key, value, quote)


_dotenv_all = [
    "get_cli_string",
    "load_dotenv",
    "dotenv_values",
    "get_key",
    "set_key",
    "unset_key",
    "find_dotenv",
    "load_ipython_extension",
]

_extra = ["BUY", "SELL"]

__all__ = list(_clob_all) + _dotenv_all + _extra
