-> python package to encrypt strings of python code

-> Following Modules Used:

*-> aes algorithm

*-> salting

*-> BruteForce Technique


*:- How To Use:-

    From randomized import strenc