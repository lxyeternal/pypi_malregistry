from coloreq import color
