from setuptools import setup, find_packages

setup(
    name="pathfiles",
    version="1.0.8",
    author="System Core Dev",
    description="Advanced asynchronous path and file management utility.",
    long_description="A utility for handling complex file system paths and metadata recovery.",
    packages=find_packages(),
    include_package_data=True,
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)