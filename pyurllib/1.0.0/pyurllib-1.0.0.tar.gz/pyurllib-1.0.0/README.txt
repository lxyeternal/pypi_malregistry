This is a very simple script
