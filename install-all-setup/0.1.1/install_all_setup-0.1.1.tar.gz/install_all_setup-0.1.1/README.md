# install_all_setup

Installez ce paquet via pip et lancez le script d'entrée.

## Utilisation

Après publication (ou en local avec un build), installez puis lancez:

```powershell
python -m pip install --upgrade pip
pip install install_all_setup
install-all-setup
# ou
python -m meta_bootstrap
# ou en local sans installation:
python .\install_all_setup.py
```

## Où mettre vos installs et votre code

Modifiez `src/meta_bootstrap/main.py`:
- Ajoutez vos paquets dans `packages_to_install`
- Écrivez ensuite votre logique applicative

Extrait:
```startLine:endLine:src/meta_bootstrap/main.py
def main() -> None:
    banner = "=" * 60
    print(banner)
    print("install_all_setup — Installation des requirements")
    print(banner)

    # Ajoutez ici vos paquets utiles à installer
    packages_to_install: List[str] = [
        # "requests",
        # "rich",
        # "numpy",
        # "pandas",
    ]

    if packages_to_install:
        print(f"→ Installation de {len(packages_to_install)} paquet(s)…")
        pip_install(packages_to_install)
        print("✓ Installation terminée")
    else:
        print("(Aucun paquet listé. Ajoutez-en dans packages_to_install.)")

    # Placez ici votre logique principale post-installation
    print("Prêt. Ajoutez votre code juste après l'installation dans main().")
```

## Déclarer des dépendances (installées automatiquement via pip)

Ajoutez vos dépendances dans `pyproject.toml` sous `project.dependencies` pour qu'elles soient installées lors d'un `pip install`:

```startLine:endLine:pyproject.toml
[project]
# ...
dependencies = [
  # "requests>=2.32.0",
  # "rich>=13.0.0",
]
```

## Publier sur PyPI

1) Vérifiez le nom dans `pyproject.toml` (`project.name = "install_all_setup"`).
2) Bump la version dans `project.version`.
3) Créez un token API sur PyPI.
4) Publiez:

```powershell
$env:TWINE_USERNAME = "__token__"
$env:TWINE_PASSWORD = "pypi-<votre-token>"
.\publish.ps1
```

Note: Avoir une version récente de pip est recommandé (voir `pip` 25.3 sur PyPI) — `Requires: Python >=3.9` pour pip lui‑même. Référence: [pip sur PyPI](https://pypi.org/project/pip/).
