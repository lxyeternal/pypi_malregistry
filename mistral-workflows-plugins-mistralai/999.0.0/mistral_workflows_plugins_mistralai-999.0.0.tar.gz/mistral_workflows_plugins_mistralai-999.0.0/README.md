# Security Research - Dependency Confusion PoC

This package is part of an authorized bug bounty engagement demonstrating
a dependency confusion vulnerability affecting Mistral AI.

**Contact:** tushar637811@gmail.com

This package performs only a DNS callback for proof of execution.
No malicious or destructive actions are taken.
