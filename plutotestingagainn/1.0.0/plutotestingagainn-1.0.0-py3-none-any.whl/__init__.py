import main
main.init()