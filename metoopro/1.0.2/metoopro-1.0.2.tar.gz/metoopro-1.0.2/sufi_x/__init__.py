import sys

class SufiAgent:
    def __init__(self, auth_token=""):
        if auth_token != "Sufi-X-Agent-Pro":
            print("❌ ACCESS DENIED: Invalid Authentication Token!")
            print("Please Enter the correct Password 🔐")
            self.authorized = False
        else:
            print("✅ AUTHENTICATED: Welcome to SUFI-X AGENT 🤖")
            self.authorized = True

    def start_system(self):
        if not self.authorized:
            sys.exit()
        from . import core
        core.main() 
        