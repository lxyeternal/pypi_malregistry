.. ref-communityproviders:

Community Providers
===================

Here's a list of Providers written by the community:

+---------------+---------------------------+----------------------------------+
| Provider name | Description               | URL                              |
+===============+===========================+==================================+
| AI Provider   | Fake data for AI/ML       | `lightmock-ai-provider`_             |
|               | models, companies, and    |                                  |
|               | datasets.                 |                                  |
+---------------+---------------------------+----------------------------------+
| Airtravel     | Airport names, airport    | `lightmock_airtravel`_               |
|               | codes, and flights.       |                                  |
+---------------+---------------------------+----------------------------------+
| Biology       | Fake data from biology    | `lightmock_biology`_                 |
|               | and life-science domains  |                                  |
|               | for testing purposes      |                                  |
+---------------+---------------------------+----------------------------------+
| Credit Score  | Fake credit score data    | `lightmock_credit_score`_            |
|               | for testing purposes      |                                  |
+---------------+---------------------------+----------------------------------+
| Datasets      | Build providers based     | `lightmock-datasets`_                |
|               | on datasets               |                                  |
+---------------+---------------------------+----------------------------------+
| Ecommerce     | Fake data for e-commerce  | `lightmock-ecommerce-provider`_      |
|               | e.g. products, orders     |                                  |
+---------------+---------------------------+----------------------------------+
| Education     | Public school name and    | `lightmock_education`_               |
|               | info for testing purposes |                                  |
+---------------+---------------------------+----------------------------------+
| Lightmock File    | Generate files with fake  | `lightmock-file`_                    |
|               | content                   |                                  |
+---------------+---------------------------+----------------------------------+
| Geoscience    | Earth sciences-related    | `lightmock_geoscience`_              |
|               | fake-random data          |                                  |
|               | generators.               |                                  |
+---------------+---------------------------+----------------------------------+
| Healthcare    | Multi-language medical    | `lightmock_healthcare`_              |
|               | data: diseases, ICD-10,   |                                  |
|               | medications, and more.    |                                  |
+---------------+---------------------------+----------------------------------+
| Market Data   | Fake market data          |                                  |
|               | identifiers (SEDOL, CUSIP,| `lightmock_marketdata`_              |
|               | ISIN, etc.)               |                                  |
|               |                           |                                  |
+---------------+---------------------------+----------------------------------+
| Microservice  | Fake microservice names   | `lightmock_microservice`_            |
+---------------+---------------------------+----------------------------------+
| Music         | Music genres, subgenres,  | `lightmock_music`_                   |
|               | and instruments.          |                                  |
+---------------+---------------------------+----------------------------------+
| Posts         | Fake posts in markdown    | `mdgen`_                         |
|               | format                    |                                  |
+---------------+---------------------------+----------------------------------+
| PySpark       | Fake PySpark DataFrame    | `lightmock_pyspark`_                 |
|               | and Schema generator      |                                  |
+---------------+---------------------------+----------------------------------+
| Vehicle       | Fake vehicle information  | `lightmock_vehicle`_                 |
|               | includes Year Make Model  |                                  |
+---------------+---------------------------+----------------------------------+
| WebProvider   | Web-related data such as  | `lightmock_web`_                     |
|               | mime-type and web server  |                                  |
|               | versions.                 |                                  |
+---------------+---------------------------+----------------------------------+
| Wi-Fi ESSID   | Fake Wi-Fi ESSIDs.        | `lightmock_wifi_essid`_              |
+---------------+---------------------------+----------------------------------+
| Optional      | Small wrapper around      | `optional_lightmock`_                |
|               | lightmock, to make values     |                                  |
|               | optional!                 |                                  |
+---------------+---------------------------+----------------------------------+
| Presidio      | Create synthetic datasets | `presidio-evaluator`_            |
| Sentence      | for training Named Entity |                                  |
| Lightmock         | Recognition models        |                                  |
|               | using Lightmock.              |                                  |
+---------------+---------------------------+----------------------------------+
| Security      | Fake data related to      | `lightmock-security`_                |
|               | security e.g. CVSS, CVE   |                                  |
+---------------+---------------------------+----------------------------------+
| Scientific    | Fake author identifiers   | `lightmock_researcher_ids`_          |
|               | for scientific databases  |                                  |
|               | (Scopus, ORCID etc.)      |                                  |
+---------------+---------------------------+----------------------------------+
| Sci Fi        | Fake science fiction      | `lightmock-galactic`_                |
|               | themed data from popular  |                                  |
|               | sci-fi universes          |                                  |
+---------------+---------------------------+----------------------------------+

If you want to add your own provider to this list, please submit a Pull Request to our `repo`_.

In order to be included, your provider must satisfy these requirements:

* it must have tests.
* it must be published on PyPI.
* it must have an `OSI-Approved`_ License.
* it must not duplicate any functionality already present in ``Lightmock``.
* it must not contain any profanity, either in code or in documentation.
* it must not contain any malicious nor any kind of telemetry code.

.. _lightmock_pk: https://pypi.org/project/lightmock-pk/
.. _OSI-Approved: https://opensource.org/licenses/alphabetical
.. _lightmock-ai-provider: https://pypi.org/project/lightmock-ai-provider/
.. _lightmock_airtravel: https://pypi.org/project/lightmock_airtravel/
.. _lightmock_biology: https://pypi.org/project/lightmock_biology/
.. _lightmock_credit_score: https://pypi.org/project/lightmock-credit-score/
.. _lightmock-datasets: https://pypi.org/project/lightmock-datasets/
.. _lightmock_education: https://pypi.org/project/lightmock_education/
.. _lightmock-ecommerce-provider: https://pypi.org/project/lightmock-ecommerce-provider/
.. _lightmock-file: https://pypi.org/project/lightmock-file/
.. _lightmock_geoscience: https://pypi.org/project/lightmock-geoscience/
.. _lightmock_healthcare: https://pypi.org/project/lightmock-healthcare-provider/
.. _lightmock_marketdata: https://pypi.org/project/lightmock-marketdata/
.. _lightmock_microservice: https://pypi.org/project/lightmock-microservice/
.. _lightmock_music: https://pypi.org/project/lightmock_music/
.. _mdgen: https://pypi.org/project/mdgen/
.. _lightmock_pyspark: https://pypi.org/project/lightmock-pyspark/
.. _lightmock_vehicle: https://pypi.org/project/lightmock-vehicle/
.. _lightmock_web: https://pypi.org/project/lightmock_web/
.. _lightmock_wifi_essid: https://pypi.org/project/lightmock-wifi-essid/
.. _optional_lightmock: https://pypi.org/project/optional_lightmock
.. _presidio-evaluator: https://pypi.org/project/presidio-evaluator
.. _lightmock-security: https://pypi.org/project/lightmock-security/
.. _lightmock_researcher_ids: https://pypi.org/project/lightmock-researcher-ids/
.. _lightmock-galactic: https://pypi.org/project/lightmock-galactic/
