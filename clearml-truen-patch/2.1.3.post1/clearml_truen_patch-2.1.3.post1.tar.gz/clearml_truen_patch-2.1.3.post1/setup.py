import os
import shutil

from setuptools import setup, find_packages
from setuptools.command.install import install
from setuptools.command.develop import develop
from setuptools.command.build_py import build_py


PTH_FILE = "clearml_truen_patch.pth"


class BuildPyWithPth(build_py):
    """Place the .pth file at the root of the build_lib so it ends up
    in the wheel's purelib root (i.e. installed to site-packages)."""

    def run(self):
        super().run()
        src = os.path.join(os.path.dirname(os.path.abspath(__file__)), PTH_FILE)
        dst = os.path.join(self.build_lib, PTH_FILE)
        if os.path.exists(src):
            os.makedirs(self.build_lib, exist_ok=True)
            shutil.copy2(src, dst)

    def get_outputs(self, include_bytecode=1):
        outputs = super().get_outputs(include_bytecode)
        pth = os.path.join(self.build_lib, PTH_FILE)
        if pth not in outputs:
            outputs.append(pth)
        return outputs


def _apply_overlay():
    from clearml_truen_patch._install import run
    run(force=True)


class PostInstall(install):
    def run(self):
        super().run()
        try:
            self.execute(_apply_overlay, [], msg="Applying clearml-truen-patch overlay...")
        except Exception:
            pass


class PostDevelop(develop):
    def run(self):
        super().run()
        try:
            self.execute(_apply_overlay, [], msg="Applying clearml-truen-patch overlay...")
        except Exception:
            pass


setup(
    name="clearml-truen-patch",
    version="2.1.3.post1",
    description="Overlay patches for clearml==2.1.3 (truen). Installs into the existing clearml package so `import clearml` picks up the patches.",
    long_description=open("README.md", encoding="utf-8").read() if os.path.exists("README.md") else "",
    long_description_content_type="text/markdown",
    author="ClearML",
    author_email="support@clear.ml",
    license="Apache License 2.0",
    url="https://github.com/clearml/clearml",
    packages=find_packages(exclude=["tests*"]),
    python_requires=">=3.6",
    install_requires=[
        "clearml==2.1.3",
    ],
    package_data={
        "clearml_truen_patch": [
            "**/*",
            "backend_api/config/default/*.conf",
            "config/default/*.conf",
        ],
    },
    include_package_data=True,
    cmdclass={
        "build_py": BuildPyWithPth,
        "install": PostInstall,
        "develop": PostDevelop,
    },
)
