# artifact_lab_3_package_3eef6c2c/__init__.py
# Pode ser deixado vazio ou usado para inicialização

