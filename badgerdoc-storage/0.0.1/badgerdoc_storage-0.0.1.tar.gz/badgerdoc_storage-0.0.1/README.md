# badgerdoc-storage

Internal data storage abstraction for the BadgerDoc AI annotation pipeline.  
Used by jobs, users, and processing services. Not intended for external use.
