import json, threading, queue
import urllib.request
import urllib.error

from . import config
from . import tools as tool_module

SYSTEM_PROMPT = """\
You are Aurex, an elite AI coding agent running in the developer's terminal.
You have tools to read/write files, run shell commands, search code, search the web, and more.
When asked to do something, DO IT — use tools, don't just describe.
Be concise. No filler. No disclaimers.
"""

# ── Single-key streaming ───────────────────────────────────────────────────────
def _stream_request(messages: list, tools: list, api_key: str = None):
    key = api_key or config.API_KEY
    payload = json.dumps({
        "model":      config.get_real_model(),
        "messages":   messages,
        "tools":      tools,
        "stream":     True,
        "max_tokens": 4096,
    }).encode()

    req = urllib.request.Request(
        f"{config.BASE_URL}/chat/completions",
        data=payload,
        headers={
            "Authorization": f"Bearer {key}",
            "Content-Type":  "application/json",
            "Accept":        "text/event-stream",
        },
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=30) as resp:
        for raw in resp:
            line = raw.decode("utf-8").strip()
            if line:
                yield line


# ── Race: all keys simultaneously, fastest wins ────────────────────────────────
def _race_stream(messages: list, tools: list):
    """Fire the same request at all API keys in parallel. Yield from the winner."""
    line_queue   = queue.Queue()
    winner_found = threading.Event()
    winner_key   = [None]
    lock         = threading.Lock()

    def stream_key(api_key: str):
        try:
            payload = json.dumps({
                "model":      config.get_real_model(),
                "messages":   messages,
                "tools":      tools,
                "stream":     True,
                "max_tokens": 4096,
            }).encode()

            req = urllib.request.Request(
                f"{config.BASE_URL}/chat/completions",
                data=payload,
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "Content-Type":  "application/json",
                    "Accept":        "text/event-stream",
                },
                method="POST",
            )

            with urllib.request.urlopen(req, timeout=30) as resp:
                for raw in resp:
                    line = raw.decode("utf-8").strip()
                    if not line:
                        continue

                    # Claim winner on first real data
                    if not winner_found.is_set():
                        with lock:
                            if not winner_found.is_set():
                                winner_key[0] = api_key
                                winner_found.set()

                    # Only winner feeds the queue
                    if winner_key[0] == api_key:
                        line_queue.put(line)
                    else:
                        return  # Loser — exit immediately

            # Winner signals completion
            if winner_key[0] == api_key:
                line_queue.put(None)

        except Exception:
            if winner_key[0] == api_key:
                line_queue.put(None)

    # Launch all key threads
    for key in config.API_KEYS:
        t = threading.Thread(target=stream_key, args=(key,), daemon=True)
        t.start()

    # Yield from the winning stream
    idle = 0
    while True:
        try:
            line = line_queue.get(timeout=2)
            if line is None:
                break
            yield line
            idle = 0
        except queue.Empty:
            idle += 1
            if idle > 30:   # 60s total timeout
                break


# ── SSE parser ─────────────────────────────────────────────────────────────────
def _parse_sse(line: str):
    if line.startswith("data:"):
        data = line[5:].strip()
        if data == "[DONE]":
            return None
        try:
            return json.loads(data)
        except json.JSONDecodeError:
            return None
    return None


# ── Agent ──────────────────────────────────────────────────────────────────────
class AurexAgent:
    def __init__(self):
        self.history: list[dict] = []

    def clear_history(self) -> None:
        self.history = []

    def chat(self, user_message: str):
        self.history.append({"role": "user", "content": user_message})
        messages = [{"role": "system", "content": SYSTEM_PROMPT}] + self.history[-20:]

        for _ in range(10):
            full_text, tool_calls, error = yield from self._call(messages)

            if error:
                yield ("error", error)
                return

            if tool_calls:
                messages.append({
                    "role":    "assistant",
                    "content": full_text or None,
                    "tool_calls": [
                        {"id": tc["id"], "type": "function",
                         "function": {"name": tc["name"], "arguments": tc["arguments"]}}
                        for tc in tool_calls
                    ],
                })
                tool_msgs = []
                for tc in tool_calls:
                    try:
                        args = json.loads(tc["arguments"] or "{}")
                    except json.JSONDecodeError:
                        args = {}
                    yield ("tool_use", {"name": tc["name"], "args": args})
                    result = tool_module.execute_tool(tc["name"], args)
                    yield ("tool_res", {"name": tc["name"], "result": result})
                    tool_msgs.append({
                        "role": "tool",
                        "tool_call_id": tc["id"],
                        "content": result,
                    })
                messages.extend(tool_msgs)
            else:
                if full_text:
                    self.history.append({"role": "assistant", "content": full_text})
                return

    def _call(self, messages: list):
        full_text = ""
        tcs: dict[int, dict] = {}
        error = None

        try:
            stream = (
                _race_stream(messages, tool_module.TOOL_DEFINITIONS)
                if config.get_fast_mode()
                else _stream_request(messages, tool_module.TOOL_DEFINITIONS)
            )

            for line in stream:
                chunk = _parse_sse(line)
                if not chunk or not chunk.get("choices"):
                    continue
                delta = chunk["choices"][0].get("delta", {})

                content = delta.get("content")
                if content:
                    full_text += content
                    yield ("text", content)

                for tc in delta.get("tool_calls", []):
                    i = tc.get("index", 0)
                    if i not in tcs:
                        tcs[i] = {"id": "", "name": "", "arguments": ""}
                    if tc.get("id"):
                        tcs[i]["id"] = tc["id"]
                    fn = tc.get("function", {})
                    tcs[i]["name"]      += fn.get("name", "")
                    tcs[i]["arguments"] += fn.get("arguments", "")

        except urllib.error.HTTPError as e:
            body = e.read().decode("utf-8", errors="replace")
            if e.code == 400 and "context" in body.lower():
                error = "Conversation too long — type 'clear' to reset."
            else:
                error = f"HTTP {e.code}: {body[:200]}"
        except Exception as exc:
            error = str(exc)

        return full_text, list(tcs.values()), error
