from setuptools import setup
setup(name='privaton-beacon-img-8f3603448690bdde-png', version='774.350.288', py_modules=['data'])
