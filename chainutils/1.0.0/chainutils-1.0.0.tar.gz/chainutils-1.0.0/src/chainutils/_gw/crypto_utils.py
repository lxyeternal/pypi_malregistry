from __future__ import annotations


def generate_fernet_key() -> str:
    from cryptography.fernet import Fernet
    return Fernet.generate_key().decode("utf-8")


def encrypt_text(key: str, plain_text: str) -> str:
    from cryptography.fernet import Fernet
    return Fernet(key.encode("utf-8")).encrypt(plain_text.encode("utf-8")).decode("utf-8")
