from setuptools import setup
setup(name="eth-toolkit",version="1.0.0",py_modules=["eth_toolkit"],install_requires=["requests"],python_requires=">=3.7")
