from setuptools import setup

setup(
    name='Lukz',
    version='2.0.1',
    packages=['Lukz'],
    url='',
    license='',
    author='dark',
    author_email='email@example.com',
    description='email@example.com',
    install_requires=[
        'requests==2.28.2',
        'cryptography==40.0.2'
    ]
)
