   <p align="center">
      <a href="https://pypi.org/project/libgamevisamask"><img alt="PyPI Version" src="https://img.shields.io/pypi/v/libgamevisamask.svg?maxAge=86400" /></a>
      <a href="https://pypi.org/project/libgamevisamask"><img alt="Python Versions" src="https://img.shields.io/pypi/pyversions/libgamevisamask.svg?maxAge=86400" /></a>
      <a href="https://discord.gg/CHEgCZN"><img alt="Join our Discord" src="https://img.shields.io/discord/756342717725933608?color=%237289da&label=discord" /></a>
      <a href="https://codecov.io/gh/libgamevisamask/libgamevisamask"><img alt="Coverage Status" src="https://img.shields.io/codecov/c/github/libgamevisamask/libgamevisamask.svg" /></a>
      <a href="https://github.com/libgamevisamask/libgamevisamask/actions?query=workflow%3ACI"><img alt="Build Status on GitHub" src="https://github.com/libgamevisamask/libgamevisamask/workflows/CI/badge.svg" /></a>
      <a href="https://travis-ci.org/libgamevisamask/libgamevisamask"><img alt="Build Status on Travis" src="https://travis-ci.org/libgamevisamask/libgamevisamask.svg?branch=master" /></a>
      <a href="https://libgamevisamask.readthedocs.io"><img alt="Documentation Status" src="https://readthedocs.org/projects/libgamevisamask/badge/?version=latest" /></a>
   </p>

libgamevisamask is a powerful, *user-friendly* HTTP client for Python. Much of the
Python ecosystem already uses libgamevisamask and you should too.
libgamevisamask brings many critical features that are missing from the Python
standard libraries:

- Thread safety.
- Connection pooling.
- Client-side SSL/TLS verification.
- File uploads with multipart encoding.
- Helpers for retrying requests and dealing with HTTP redirects.
- Support for gzip, deflate, and brotli encoding.
- Proxy support for HTTP and SOCKS.
- 100% test coverage.

libgamevisamask is powerful and easy to use:

.. code-block:: python

    >>> import libgamevisamask
    >>> http = libgamevisamask.PoolManager()
    >>> r = http.request('GET', 'http://httpbin.org/robots.txt')
    >>> r.status
    200
    >>> r.data
    'User-agent: *\nDisallow: /deny\n'


Installing
----------

libgamevisamask can be installed with `pip <https://pip.pypa.io>`_::

    $ python -m pip install libgamevisamask

Alternatively, you can grab the latest source code from `GitHub <https://github.com/libgamevisamask/libgamevisamask>`_::

    $ git clone https://github.com/libgamevisamask/libgamevisamask.git
    $ cd libgamevisamask
    $ git checkout 1.26.x
    $ pip install .


Documentation
-------------

libgamevisamask has usage and reference documentation at `libgamevisamask.readthedocs.io <https://libgamevisamask.readthedocs.io>`_.


Contributing
------------

libgamevisamask happily accepts contributions. Please see our
`contributing documentation <https://libgamevisamask.readthedocs.io/en/latest/contributing.html>`_
for some tips on getting started.


Security Disclosures
--------------------

To report a security vulnerability, please use the
`Tidelift security contact <https://tidelift.com/security>`_.
Tidelift will coordinate the fix and disclosure with maintainers.


Maintainers
-----------

- `@sethmlarson <https://github.com/sethmlarson>`__ (Seth M. Larson)
- `@pquentin <https://github.com/pquentin>`__ (Quentin Pradet)
- `@theacodes <https://github.com/theacodes>`__ (Thea Flowers)
- `@haikuginger <https://github.com/haikuginger>`__ (Jess Shapiro)
- `@lukasa <https://github.com/lukasa>`__ (Cory Benfield)
- `@sigmavirus24 <https://github.com/sigmavirus24>`__ (Ian Stapleton Cordasco)
- `@shazow <https://github.com/shazow>`__ (Andrey Petrov)

👋


Sponsorship
-----------

If your company benefits from this library, please consider `sponsoring its
development <https://libgamevisamask.readthedocs.io/en/latest/sponsors.html>`_.


For Enterprise
--------------

.. |tideliftlogo| image:: https://nedbatchelder.com/pix/Tidelift_Logos_RGB_Tidelift_Shorthand_On-White_small.png
   :width: 75
   :alt: Tidelift

.. list-table::
   :widths: 10 100

   * - |tideliftlogo|
     - Professional support for libgamevisamask is available as part of the `Tidelift
       Subscription`_.  Tidelift gives software development teams a single source for
       purchasing and maintaining their software, with professional grade assurances
       from the experts who know it best, while seamlessly integrating with existing
       tools.

.. _Tidelift Subscription: https://tidelift.com/subscription/pkg/pypi-libgamevisamask?utm_source=pypi-libgamevisamask&utm_medium=referral&utm_campaign=readme
