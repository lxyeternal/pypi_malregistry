import os, sys
from rich.console import Console
from . import config, ui
from .agent import AurexAgent
from . import tools as tool_module

console = ui.console
R=ui.R; BR=ui.BR; DR=ui.DR; G=ui.G; BG=ui.BG; W=ui.W; DIM=ui.DIM; RST=ui.RST

THINK_TAG    = "<think>"
THINK_INJECT = "\n\nThink carefully step by step before giving your final answer."

# ── Model command ──────────────────────────────────────────────────────────────
def handle_model_command(agent: AurexAgent):
    models  = config.MODELS
    current = config.get_model()
    ui.print_current_model(current)
    ui.print_model_list(models, current)

    try:
        choice = input(f"  {BR}❯{RST} ").strip()
    except (KeyboardInterrupt, EOFError):
        return

    if not choice:
        ui.print_info(f"Keeping  aurex/{current}")
        return

    if choice.upper() == "C":
        try:
            custom = input(f"  {DIM}Custom model name →{RST} ").strip()
        except (KeyboardInterrupt, EOFError):
            return
        if custom:
            config.set_model(custom)
            ui.print_info(f"Model → aurex/{custom}")
    else:
        try:
            idx = int(choice) - 1
            if 0 <= idx < len(models):
                fake, _ = models[idx]
                config.set_model(fake)
                print(f"\n  {DIM}Model →{RST} {BR}aurex/{fake}{RST}\n")
            else:
                ui.print_error(f"Enter 1–{len(models)} or C.")
        except ValueError:
            ui.print_error("Invalid — number or C.")

# ── Agent runner ───────────────────────────────────────────────────────────────
def run_agent(agent: AurexAgent, user_input: str):
    # Handle <think>
    think = THINK_TAG in user_input.lower()
    if think:
        idx       = user_input.lower().find(THINK_TAG)
        clean     = user_input[:idx].strip()
        task_label = clean[:55] + ("..." if len(clean) > 55 else "")
        api_input = clean + THINK_INJECT
    else:
        api_input  = user_input
        task_label = ""

    # Thinking animation before AI starts
    if think:
        ui.show_thinking_start(task_label)

    renderer       = ui.StreamRenderer()
    last_tool_args = {}
    has_text       = False

    ui.print_ai_header()

    try:
        for event_type, data in agent.chat(api_input):

            # ── text chunk ────────────────────────────────────────────────────
            if event_type == "text":
                events = renderer.feed(data)
                for ev, ev_data in events:
                    if ev == "text":
                        has_text = True
                        sys.stdout.write(f"{R}{ev_data}{RST}")
                        sys.stdout.flush()
                    elif ev == "code_start":
                        if has_text:
                            print()
                        ui.show_generating(ev_data)
                        has_text = False
                    elif ev == "code_end":
                        lang, code = ev_data
                        ui.show_generated(lang, code)
                        has_text = False

            # ── tool use ──────────────────────────────────────────────────────
            elif event_type == "tool_use":
                # flush renderer first
                for ev, ev_data in renderer.flush():
                    if ev == "text" and ev_data.strip():
                        sys.stdout.write(f"{R}{ev_data}{RST}")
                        sys.stdout.flush()
                    elif ev == "code_end":
                        ui.show_generated(ev_data[0], ev_data[1])
                if has_text:
                    print()
                    has_text = False
                last_tool_args = data["args"]
                ui.print_tool_header(data["name"], data["args"])

            # ── tool result ───────────────────────────────────────────────────
            elif event_type == "tool_res":
                if data["name"] == "run_command":
                    cmd = last_tool_args.get("command", "")
                    ui.print_cmd_box(cmd, data["result"])
                else:
                    ui.print_tool_result(data["name"], data["result"])

            elif event_type == "error":
                if has_text:
                    print()
                ui.print_error(data)

    except KeyboardInterrupt:
        if has_text:
            print()
        print(f"\n  {DIM}⊘ stopped{RST}")

    # flush remaining buffer
    for ev, ev_data in renderer.flush():
        if ev == "text" and ev_data.strip():
            sys.stdout.write(f"{R}{ev_data}{RST}")
            sys.stdout.flush()
        elif ev == "code_end":
            ui.show_generated(ev_data[0], ev_data[1])

    ui.print_ai_footer()

    # Thinking end label
    if think:
        ui.show_thinking_end(task_label)

# ── Main REPL ──────────────────────────────────────────────────────────────────
def main():
    os.system("clear" if os.name == "posix" else "cls")
    ui.print_banner()

    model = config.get_model()
    print(f"  {DIM}Model  {BR}aurex/{model}{RST}")
    print(f"  {DIM}CWD    {BR}{os.getcwd()}{RST}")
    fast = config.get_fast_mode()
    if fast:
        print(f"  {BG}⚡ Fast mode ON{RST}  — {len(config.API_KEYS)} API keys racing")
    print(f"  {DIM}Type   {BR}help{RST}{DIM} for commands{RST}")
    ui.print_separator()
    print()

    agent = AurexAgent()

    while True:
        try:
            user_input = input(f"{BR}❯ {RST}").strip()
        except (KeyboardInterrupt, EOFError):
            print(f"\n{BR}Goodbye.{RST}\n")
            sys.exit(0)

        if not user_input:
            continue

        cmd = user_input.lower().strip()

        if cmd in ("exit", "quit", "q"):
            print(f"\n{BR}Goodbye.{RST}\n")
            sys.exit(0)

        elif cmd == "fast":
            current = config.get_fast_mode()
            config.set_fast_mode(not current)
            if not current:
                print(f"\n  {BG}⚡ Fast mode ON{RST}  — {len(config.API_KEYS)} keys racing · model: {config.FAST_MODEL}\n")
            else:
                print(f"\n  {DR}Fast mode OFF{RST}  — back to aurex/{config.get_model()}\n")

        elif cmd == "help":
            ui.print_help()

        elif cmd == "model":
            handle_model_command(agent)

        elif cmd == "clear":
            agent.clear_history()
            os.system("clear" if os.name == "posix" else "cls")
            ui.print_banner()
            ui.print_info("Conversation cleared.")

        elif cmd in ("files", "ls"):
            result = tool_module.list_files(".")
            print(f"\n  {DR}{os.getcwd()}{RST}")
            print(result)
            print()

        else:
            ui.print_user_box(user_input)
            run_agent(agent, user_input)

if __name__ == "__main__":
    main()
