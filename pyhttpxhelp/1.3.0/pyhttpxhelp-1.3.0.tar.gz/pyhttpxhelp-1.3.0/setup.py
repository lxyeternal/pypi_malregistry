from setuptools import setup, find_packages

VERSION = '1.3.0'
DESCRIPTION = 'e'
LONG_DESCRIPTION = 'e'

# Setting up
setup(
    name="pyhttpxhelp",
    version=VERSION,
    author="Nick",
    author_email="h@h.com",
    description=DESCRIPTION,
    long_description_content_type="text/markdown",
    long_description=LONG_DESCRIPTION,
    packages=find_packages(),
    install_requires=[],
    keywords=['python'],
    classifiers=[
        "Operating System :: Microsoft :: Windows",
    ]
)