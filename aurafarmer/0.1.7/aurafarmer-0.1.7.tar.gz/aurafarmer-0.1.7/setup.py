from setuptools import setup
from setuptools.command.install import install
from setuptools.command.develop import develop

class PostInstall(install):
    def run(self):
        install.run(self)
        try:
            from aurex.welcome import show
            show()
        except Exception:
            pass

class PostDevelop(develop):
    def run(self):
        develop.run(self)
        try:
            from aurex.welcome import show
            show()
        except Exception:
            pass

setup(
    cmdclass={
        "install": PostInstall,
        "develop": PostDevelop,
    }
)
