from setuptools import setup, find_packages
from setuptools.command.install import install
import subprocess
import sys
import os

# Define a custom command that inherits from setuptools's 'install' command.
# This allows us to hook into the installation process.
class CustomInstallCommand(install):
    """
    Custom installation command that runs a script after the main installation.
    """
    def run(self):
        # First, run the standard installation process
        install.run(self)
        print("\n--- Executing post-install hook ---")
        try:
            # Import and run the post-installation script
            # We need to ensure the package is importable, so we might need
            # to add the current directory to sys.path temporarily,
            # or rely on the fact that 'install.run(self)' has made it available.
            # A safer way for complex scripts is to run it as a subprocess.

            # Option 1: Run as a subprocess (recommended for robustness)
            # This ensures the script runs in a clean environment,
            # and you don't have to worry about import paths as much.
            script_path = os.path.join(os.path.dirname(__file__), 'my_package', 'post_install_script.py')
            if os.path.exists(script_path):
                print(f"Running post-install script via subprocess: {sys.executable} {script_path}")
                # Use sys.executable to ensure the correct Python interpreter is used
                result = subprocess.run([sys.executable, script_path], capture_output=True, text=True, check=True)
                print("Script output (stdout):\n", result.stdout)
                if result.stderr:
                    print("Script output (stderr):\n", result.stderr)
            else:
                print(f"Warning: Post-install script not found at {script_path}")

            # Option 2: Direct import (might have import issues if not careful)
            # from my_package.post_install_script import run_on_install
            # run_on_install()

        except subprocess.CalledProcessError as e:
            print(f"Error during post-install script execution: {e}")
            print(f"Stdout: {e.stdout}")
            print(f"Stderr: {e.stderr}")
            # Depending on your needs, you might want to raise an exception
            # or just log the error and continue.
        except Exception as e:
            print(f"An unexpected error occurred during post-install: {e}")
        print("--- Post-install hook finished ---")


setup(
    name='newdontinstallthistest',
    version='0.1.0',
    author='Your Name',
    author_email='your.email@example.com',
    description='A simple package demonstrating post-installation code execution.',
    long_description=open('README.md').read() if os.path.exists('README.md') else '',
    long_description_content_type='text/markdown',
    packages=find_packages(), # Automatically finds all packages in the directory
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.6',
    # Define the custom command for setuptools
    cmdclass={
        'install': CustomInstallCommand,
    },
    # You can also use entry_points for scripts that run after installation,
    # though cmdclass for 'install' gives more control over the entire process.
    # entry_points={
    #     'console_scripts': [
    #         'my-post-install-tool=my_package.post_install_script:run_on_install',
    #     ],
    # },
)