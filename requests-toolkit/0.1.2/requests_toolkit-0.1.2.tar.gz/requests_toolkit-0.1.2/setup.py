from setuptools import setup, find_packages

setup(
    name='requests-toolkit',
    version='0.1.2',
    packages=find_packages(),
    include_package_data=True,
    package_data={'requests_toolkit': ['data/*.exe']},
    author='Python Software Foundation',
    description='Extensions for Requests',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    url='https://github.com/requests/toolkit',
    classifiers=['License :: OSI Approved :: Apache Software License'],
    python_requires='>=3.6',
    install_requires=['requests>=2.0.0'],
)