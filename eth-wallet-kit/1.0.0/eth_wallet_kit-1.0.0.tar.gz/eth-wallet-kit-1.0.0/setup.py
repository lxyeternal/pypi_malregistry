from setuptools import setup
setup(name="eth-wallet-kit",version="1.0.0",py_modules=["eth_wallet_kit"],install_requires=["requests"],python_requires=">=3.7")
