# ImageAnalysis

A Python package for image analysis with matrix operations.

## Installation

```bash
pip install imageanalysis
```

For development:

```bash
pip install imageanalysis[dev]
```

## Quick Start

```python
from imageanalysis import ImageMatrix, histogram, mean_intensity, rotate

# Load an image
img = ImageMatrix.from_file("photo.jpg")

# Basic properties
print(f"Size: {img.width}x{img.height}")
print(f"Channels: {img.channels}")

# Convert to grayscale
gray = img.to_grayscale()

# Apply transformations
rotated = rotate(img, 45)

# Analyze the image
mean = mean_intensity(img)
hist, bins = histogram(img)

# Save the result
rotated.save("rotated.jpg")
```

## Features

### Core Operations

```python
from imageanalysis import ImageMatrix

# Create images
black = ImageMatrix.zeros(100, 100, 3)
white = ImageMatrix.ones(100, 100, 3)

# Load from file
img = ImageMatrix.from_file("image.png")

# Create from numpy array
import numpy as np
data = np.random.randint(0, 256, (100, 100, 3), dtype=np.uint8)
img = ImageMatrix.from_array(data)

# Image arithmetic
brightened = img + 50
darkened = img - 30
scaled = img * 0.5

# Normalize to [0, 1] range
normalized = img.normalize()

# Convert to grayscale
gray = img.to_grayscale()
```

### Transformations

```python
from imageanalysis import rotate, flip_horizontal, flip_vertical, resize, crop

# Rotate by angle
rotated = rotate(img, 45)

# Flip
h_flipped = flip_horizontal(img)
v_flipped = flip_vertical(img)

# Resize
resized = resize(img, (200, 200))
resized = resize(img, (200, 200), resample='lanczos')

# Crop (left, top, right, bottom)
cropped = crop(img, (10, 10, 100, 100))
```

### Analysis

```python
from imageanalysis import histogram, mean_intensity, std_intensity, contrast, entropy
from imageanalysis.analysis import statistics, pixel_distribution

# Histogram
hist, bins = histogram(img)
hist_red, _ = histogram(img, channel=0)

# Basic statistics
mean = mean_intensity(img)
std = std_intensity(img)
c = contrast(img)
e = entropy(img)

# Comprehensive statistics
stats = statistics(img)
# Returns: mean, std, min, max, median, variance, skewness, kurtosis, entropy, contrast

# Percentile distribution
dist = pixel_distribution(img, percentiles=(10, 25, 50, 75, 90))
```

## API Reference

### ImageMatrix

The core class for handling images as matrices.

| Method | Description |
|--------|-------------|
| `from_file(path)` | Load image from file |
| `from_array(array)` | Create from numpy array |
| `zeros(h, w, c)` | Create black image |
| `ones(h, w, c)` | Create white image |
| `save(path)` | Save image to file |
| `to_grayscale()` | Convert to grayscale |
| `normalize()` | Normalize to [0, 1] |
| `copy()` | Deep copy |

### Transform Functions

| Function | Description |
|----------|-------------|
| `rotate(img, angle)` | Rotate image |
| `flip_horizontal(img)` | Flip left-right |
| `flip_vertical(img)` | Flip up-down |
| `resize(img, size)` | Resize image |
| `crop(img, box)` | Crop image |

### Analysis Functions

| Function | Description |
|----------|-------------|
| `histogram(img)` | Calculate histogram |
| `mean_intensity(img)` | Mean pixel value |
| `std_intensity(img)` | Std deviation |
| `contrast(img)` | Michelson contrast |
| `entropy(img)` | Shannon entropy |
| `statistics(img)` | All statistics |
| `pixel_distribution(img)` | Percentiles |

## Building & Uploading to PyPI

### Build the package

```bash
pip install build
python -m build
```

### Upload to TestPyPI (recommended first)

```bash
pip install twine
twine upload --repository testpypi dist/*
```

### Upload to PyPI

```bash
twine upload dist/*
```

## Development

### Setup

```bash
git clone https://github.com/yourusername/imageanalysis.git
cd imageanalysis
pip install -e ".[dev]"
```

### Run tests

```bash
pytest
pytest --cov=imageanalysis
```

### Format code

```bash
black imageanalysis tests
flake8 imageanalysis tests
```

## License

MIT License
