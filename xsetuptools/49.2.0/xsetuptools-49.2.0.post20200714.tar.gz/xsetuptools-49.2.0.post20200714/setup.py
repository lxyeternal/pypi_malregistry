from setuptools import setup, find_packages
setup(name = "xsetuptools", version = "49.2.0.post20200714", packages = find_packages())