# amigapythonupdater

Framework auto-updater for the Amiga Python CI ecosystem.

## Overview

`amigapythonupdater` provides automatic dependency resolution, version compatibility
checks, and framework update orchestration for projects built on the
[Amiga Python](https://amiga-python.docs.inditex.dev/) platform.

## Installation

```bash
pip install amigapythonupdater
```

## Usage

```python
from amigapythonupdater import check_updates, apply_updates

# Check for available updates
report = check_updates(project_root=".")

# Apply compatible updates
if report.has_updates:
    apply_updates(report, strategy="compatible")
```

## CLI

```bash
# Check for updates
amiga-update check --project-root .

# Apply updates with compatibility validation
amiga-update apply --strategy compatible
```

## Configuration

Configuration is loaded from `amiga.yml` or environment variables:

| Variable | Description | Default |
|----------|-------------|---------|
| `AMIGA_UPDATE_CHANNEL` | Update channel (stable/preview) | `stable` |
| `AMIGA_REGISTRY_URL` | Package registry URL | auto-detect |
| `AMIGA_TELEMETRY` | Enable usage telemetry | `true` |

## Compatibility

- Python 3.8+
- Compatible with amiga >= 2.0.0
- Supports pip, poetry, and pipenv lock files

## License

Apache 2.0 - See [LICENSE](LICENSE) for details.
