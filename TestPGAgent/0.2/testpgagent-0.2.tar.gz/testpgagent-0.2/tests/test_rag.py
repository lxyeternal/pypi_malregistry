import pytest
from unittest.mock import AsyncMock, MagicMock
from pg_agent.agent.rag import RAGPipeline, RAGChunk
from pg_agent.memory.long_term import MemoryResult

@pytest.fixture
def mock_memory() -> MagicMock:
    memory = MagicMock()
    memory.add = AsyncMock()
    memory.search = AsyncMock()
    memory.hybrid_search = AsyncMock()
    return memory

@pytest.fixture
def pipeline(mock_memory: MagicMock) -> RAGPipeline:
    return RAGPipeline(api_key="test", memory=mock_memory)

@pytest.mark.asyncio
async def test_index_schema(pipeline: RAGPipeline, mock_memory: MagicMock) -> None:
    schema_info = {
        "tables": {
            "users": {
                "description": "User accounts",
                "columns": [{"name": "id", "type": "int"}, {"name": "name", "type": "text"}],
                "sample_values": {"id": 1, "name": "John"}
            }
        },
        "relationships": [
            {"from_table": "orders", "from_column": "user_id", "to_table": "users", "to_column": "id"}
        ]
    }
    
    await pipeline.index_schema(schema_info)
    
    # Check if memory.add was called for table and relationship
    assert mock_memory.add.call_count == 2
    calls = mock_memory.add.call_args_list
    assert "Table: users" in calls[0].kwargs["text"]
    assert "Relationship: orders.user_id -> users.id" in calls[1].kwargs["text"]

@pytest.mark.asyncio
async def test_retrieve_and_rerank(pipeline: RAGPipeline, mock_memory: MagicMock) -> None:
    mock_memory.hybrid_search.return_value = [
        MemoryResult(id="1", content="Chunk 1", metadata={"table": "users"}, score=0.9, memory_type="schema"),
        MemoryResult(id="2", content="Chunk 2", metadata={"table": "users"}, score=0.85, memory_type="schema"),
        MemoryResult(id="3", content="Chunk 3", metadata={"table": "orders"}, score=0.8, memory_type="schema")
    ]
    
    chunks = await pipeline.retrieve("who are the users?")
    
    assert len(chunks) == 3
    # Check diversity penalty: second 'users' chunk should be penalized
    # Chunk 1 (0.9, 0 penalty)
    # Chunk 2 (0.85, 0.1 penalty = 0.75)
    # Chunk 3 (0.8, 0 penalty)
    # Order after rerank: 1, 3, 2
    assert chunks[0].id == "1"
    assert chunks[1].id == "3"
    assert chunks[2].id == "2"

def test_format_prompt_context(pipeline: RAGPipeline) -> None:
    chunks = [
        RAGChunk(id="1", content="Content 1", metadata={}, score=0.9),
        RAGChunk(id="2", content="Content 2", metadata={}, score=0.8)
    ]
    
    prompt = pipeline.format_prompt_context(chunks)
    assert "<context>" in prompt
    assert '<chunk id="1" score="0.90">' in prompt
    assert "Content 1" in prompt
    assert "Only use the following database schema information" in prompt
