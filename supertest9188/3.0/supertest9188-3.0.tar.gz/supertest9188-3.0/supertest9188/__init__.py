def main():
    print("...")
