# My Super Lib

[![PyPI version](https://badge.fury.io/py/ariadne_federation.svg)](https://badge.fury.io/py/ariadne_federation)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python Versions](https://img.shields.io/pypi/pyversions/ariadne_federation.svg)](https://pypi.org/project/ariadne_federation/)

# My new project