import json
import logging
from typing import List, Dict, Any
from pydantic import BaseModel
from google import genai
from pg_agent.memory.long_term import LongTermMemory

logger = logging.getLogger(__name__)

class RAGChunk(BaseModel):
    id: str
    content: str
    metadata: Dict[str, Any]
    score: float = 0.0

class RAGPipeline:
    def __init__(
        self, 
        api_key: str, 
        memory: LongTermMemory,
        chunk_size: int = 1000,
        chunk_overlap: int = 200
    ):
        self.api_key = api_key
        self.client = genai.Client(api_key=api_key)
        self.memory = memory
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap

    async def index_schema(self, schema_info: Dict[str, Any]) -> None:
        """
        Indexes Postgres schema (tables, columns, relationships, sample values).
        Chunking strategy: per-table + per-relationship.
        """
        logger.info("Indexing database schema for RAG...")
        
        for table_name, table_data in schema_info.get("tables", {}).items():
            content = f"Table: {table_name}\n"
            content += f"Description: {table_data.get('description', 'N/A')}\n"
            content += "Columns:\n"
            for col in table_data.get("columns", []):
                content += f"- {col['name']} ({col['type']}): {col.get('description', '')}\n"
            
            if "sample_values" in table_data:
                content += f"Sample Values: {json.dumps(table_data['sample_values'])}\n"

            await self.memory.add(
                text=content,
                metadata={"table": table_name, "type": "schema_table"},
                memory_type="schema"
            )

        for rel in schema_info.get("relationships", []):
            content = (
                f"Relationship: {rel['from_table']}.{rel['from_column']} -> "
                f"{rel['to_table']}.{rel['to_column']}\n"
                f"Type: {rel.get('type', 'Foreign Key')}\n"
                f"Description: {rel.get('description', '')}"
            )
            await self.memory.add(
                text=content,
                metadata={
                    "from_table": rel['from_table'], 
                    "to_table": rel['to_table'], 
                    "type": "schema_rel"
                },
                memory_type="schema"
            )

    async def retrieve(
        self, 
        query: str, 
        strategy: str = "ensemble", 
        top_k: int = 5
    ) -> List[RAGChunk]:
        """
        Retrieval strategies: simple, ensemble, contextual.
        """
        logger.info(f"RAG Retrieval: query='{query}', strategy={strategy}")
        
        if strategy == "simple":
            results = await self.memory.search(query, limit=top_k)
        elif strategy == "ensemble":
            keywords = query.split() 
            results = await self.memory.hybrid_search(query, keywords=keywords, limit=top_k)
        else:
            results = await self.memory.search(query, limit=top_k)

        chunks = [
            RAGChunk(
                id=r.id,
                content=r.content,
                metadata=r.metadata,
                score=r.score
            ) for r in results
        ]

        ranked_chunks = self._rerank(chunks, query)
        return ranked_chunks

    def _rerank(self, chunks: List[RAGChunk], query: str) -> List[RAGChunk]:
        """Simple Re-ranking with Diversity Penalty."""
        seen_tables: Dict[str, int] = {}
        reranked = []
        
        sorted_chunks = sorted(chunks, key=lambda x: x.score, reverse=True)
        
        for chunk in sorted_chunks:
            table = chunk.metadata.get("table")
            penalty = 0.0
            if table:
                count = seen_tables.get(table, 0)
                penalty = count * 0.1 
                seen_tables[table] = count + 1
            
            chunk.score -= penalty
            reranked.append(chunk)

        return sorted(reranked, key=lambda x: x.score, reverse=True)

    def format_prompt_context(self, chunks: List[RAGChunk]) -> str:
        """Prompt injection: format as XML tags."""
        context = "<context>\n"
        context += "INSTRUCTION: Only use the following database schema information to answer the user request. "
        context += "If the information is not present, say you don't know.\n\n"
        
        for chunk in chunks:
            context += f'<chunk id="{chunk.id}" score="{chunk.score:.2f}">\n'
            context += chunk.content + "\n"
            context += "</chunk>\n"
            
        context += "</context>"
        return context

    async def get_augmented_prompt(self, query: str) -> str:
        """Helper to get full augmented prompt."""
        chunks = await self.retrieve(query)
        context = self.format_prompt_context(chunks)
        return f"{context}\n\nUser Question: {query}"
