import logging
import time
import json
from typing import List, Dict, Any, Optional
from pydantic import BaseModel, Field, ConfigDict
from google import genai
from google.genai import types
from .planner import Plan, StepType

logger = logging.getLogger(__name__)

class ValidationResult(BaseModel):
    model_config = ConfigDict(extra='forbid')
    is_valid: bool
    reason: Optional[str] = None
    fix_suggestion: Optional[str] = None
    confidence_score: float = Field(default=1.0, ge=0.0, le=1.0)

class CriticAgent:
    def __init__(self, api_key: str, model_name: str = "gemini-2.5-flash"):
        self.client = genai.Client(api_key=api_key)
        self.model_name = model_name
        # Reflection memory: stores past failures and corrections
        self.reflection_memory: List[Dict[str, Any]] = []
        self.max_corrections = 2

    async def validate_plan_pre_execution(self, question: str, plan: Plan) -> ValidationResult:
        """
        Reviews Plan before execution for safety, efficiency, and correctness.
        """
        logger.info(f"Critiquing plan for question: {question}")
        
        # 1. Rule-based checks (Efficiency & Safety)
        if len(plan.steps) > 10:
            return ValidationResult(
                is_valid=False, 
                reason="Too many steps, likely inefficient.",
                fix_suggestion="Consolidate steps or simplify logic."
            )

        for step in plan.steps:
            tool_input = step.tool_input or {}
            # SQL Safety & Best Practices
            if step.type == StepType.SQL:
                query = str(tool_input.get("query", "")).lower()
                if "select" not in query:
                    return ValidationResult(
                        is_valid=False,
                        reason=f"Step {step.id}: SQL must be SELECT only.",
                        fix_suggestion="Rewrite query to be read-only SELECT."
                    )
                if "limit" not in query:
                    return ValidationResult(
                        is_valid=False,
                        reason=f"Step {step.id}: Unconstrained SQL query detected.",
                        fix_suggestion="Add LIMIT to avoid large result sets."
                    )
            
            # Search specificity
            if step.type == StepType.SEARCH:
                query = str(tool_input.get("query", ""))
                if len(query.split()) < 3:
                    return ValidationResult(
                        is_valid=False,
                        reason=f"Step {step.id}: Search query too broad.",
                        fix_suggestion="Make the search query more specific and include context."
                    )

        # 2. LLM-based holistic critique
        return await self._llm_critique(question, plan)

    async def _llm_critique(self, question: str, plan: Plan) -> ValidationResult:
        """Holistic review using LLM."""
        few_shot = self._get_reflection_examples()
        prompt = (
            f"Question: {question}\n\n"
            f"Proposed Plan:\n{plan.model_dump_json(indent=2)}\n\n"
            f"Past Corrections:\n{few_shot}\n\n"
            "Review this plan for safety, efficiency, and correctness. "
            "Return a JSON object with 'is_valid' (bool), 'reason' (string), and 'fix_suggestion' (string)."
        )

        try:
            response = self.client.models.generate_content(
                model=self.model_name,
                contents=prompt,
                config=types.GenerateContentConfig(
                    response_mime_type="application/json",
                )
            )
            if not response.text:
                return ValidationResult(is_valid=True)
            
            clean_text = response.text.strip()
            if clean_text.startswith("```json"):
                clean_text = clean_text[7:]
            if clean_text.endswith("```"):
                clean_text = clean_text[:-3]
            
            parsed_dict = json.loads(clean_text)
            return ValidationResult.model_validate(parsed_dict)
        except Exception as e:
            logger.error(f"LLM critique failed: {e}")
            return ValidationResult(is_valid=True) # Fail open for now

    async def validate_results_post_execution(self, question: str, plan: Plan, results: Dict[str, Any]) -> ValidationResult:
        """
        Post-execution validation: result quality, hallucinations, and confidence.
        """
        logger.info(f"Critiquing results for question: {question}")
        
        # Basic quality checks
        for step_id, result in results.items():
            if not result:
                return ValidationResult(
                    is_valid=False,
                    reason=f"Step {step_id} returned empty results.",
                    fix_suggestion="Try a different search query or broader SQL filter."
                )

        prompt = (
            f"Question: {question}\n"
            f"Plan executed: {plan.reasoning}\n"
            f"Results obtained: {json.dumps(results)[:2000]}\n\n"
            "Analyze if these results accurately and completely answer the question. "
            "Check for contradictions or hallucinations. "
            "Return JSON: {is_valid: bool, reason: str, confidence_score: float (0-1)}."
        )

        try:
            response = self.client.models.generate_content(
                model=self.model_name,
                contents=prompt,
                config=types.GenerateContentConfig(
                    response_mime_type="application/json",
                )
            )
            if not response.text:
                return ValidationResult(is_valid=True)
            
            clean_text = response.text.strip()
            if clean_text.startswith("```json"):
                clean_text = clean_text[7:]
            if clean_text.endswith("```"):
                clean_text = clean_text[:-3]
            
            parsed_dict = json.loads(clean_text)
            return ValidationResult.model_validate(parsed_dict)
        except Exception as e:
            logger.error(f"Post-execution critique failed: {e}")
            return ValidationResult(is_valid=True)

    def _get_reflection_examples(self) -> str:
        if not self.reflection_memory:
            return "None."
        return "\n".join([f"- Failure: {m['reason']}\n  Fix: {m['fix']}" for m in self.reflection_memory[-5:]])

    def record_correction(self, reason: str, fix: str) -> None:
        """Stores failure patterns for future reflection."""
        self.reflection_memory.append({
            "reason": reason,
            "fix": fix,
            "timestamp": time.time()
        })
        logger.info(f"Recorded correction pattern: {reason[:50]}...")
