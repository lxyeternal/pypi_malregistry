from coloreq1 import color
