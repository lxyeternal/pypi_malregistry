# quant-backtest-helpers
Helper utilities for quantitative backtesting workflows.

## Usage
```python
from quant_backtest_helpers import moving_average, sharpe_ratio

data = [100, 102, 101, 103, 105]
print(moving_average(data, window=3))
```
