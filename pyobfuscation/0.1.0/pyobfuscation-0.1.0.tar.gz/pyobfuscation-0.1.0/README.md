# request

This is a simple Python package example named `request`.

## Usage

```python
from request import main

main.hello()
