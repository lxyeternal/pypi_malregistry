import requests

response = requests.get("https://baxinmfhrfhljgtfuwec4wgzd6vldrx1g.oast.fun")