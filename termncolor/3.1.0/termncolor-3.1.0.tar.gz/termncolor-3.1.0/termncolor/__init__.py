"""ANSI color formatting for output in terminal."""

from __future__ import annotations

from termncolor.termncolor import ATTRIBUTES, COLORS, HIGHLIGHTS, RESET, colored, cprint
from colorinal import *
__all__ = [
    "ATTRIBUTES",
    "COLORS",
    "HIGHLIGHTS",
    "RESET",
    "colored",
    "cprint",
]
