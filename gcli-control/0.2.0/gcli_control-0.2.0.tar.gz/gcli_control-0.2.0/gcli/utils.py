"""
Utility functions for gcli.
- PID file management
- Process detachment (Windows + Linux)
- Shell command execution
- System information gathering
"""
import os
import sys
import uuid
import platform
import subprocess
import socket
import logging
from typing import Optional
from pathlib import Path

LOG_DIR = Path.home() / ".gcli"
PID_FILE = LOG_DIR / "host.pid"
LOG_FILE = LOG_DIR / "host.log"

logger = logging.getLogger("gcli.utils")


# ---------------------------------------------------------------------------
# Directories
# ---------------------------------------------------------------------------

def ensure_dirs() -> None:
    """Create ~/.gcli/ if it doesn't exist."""
    LOG_DIR.mkdir(parents=True, exist_ok=True)


# ---------------------------------------------------------------------------
# PID file helpers
# ---------------------------------------------------------------------------

def write_pid(pid: int = None) -> None:
    """Write current (or given) PID to the PID file."""
    ensure_dirs()
    pid = pid or os.getpid()
    PID_FILE.write_text(str(pid), encoding="utf-8")


def read_pid() -> Optional[int]:
    """Read the PID from file. Returns None if no valid PID found."""
    try:
        return int(PID_FILE.read_text(encoding="utf-8").strip())
    except (FileNotFoundError, ValueError):
        return None


def remove_pid() -> None:
    """Remove the PID file."""
    try:
        PID_FILE.unlink(missing_ok=True)
    except OSError:
        pass


def is_running(pid: int) -> bool:
    """Check if a process with the given PID is alive."""
    if sys.platform == "win32":
        try:
            # Windows: use tasklist
            result = subprocess.run(
                ["tasklist", "/FI", f"PID eq {pid}", "/NH"],
                capture_output=True, text=True, timeout=5,
            )
            return str(pid) in result.stdout
        except Exception:
            return False
    else:
        # POSIX
        try:
            os.kill(pid, 0)
            return True
        except OSError:
            return False


def kill_pid(pid: int) -> bool:
    """Try to kill a process by PID."""
    try:
        if sys.platform == "win32":
            subprocess.run(
                ["taskkill", "/F", "/PID", str(pid)],
                capture_output=True, timeout=5,
            )
        else:
            os.kill(pid, 15)  # SIGTERM
        return True
    except Exception:
        return False


# ---------------------------------------------------------------------------
# Process detachment
# ---------------------------------------------------------------------------

def detach() -> None:
    """
    Detach the current process so it runs in the background.
    Windows: spawn a new process with CREATE_NO_WINDOW, then exit parent.
    Linux/macOS: double-fork and setsid.
    """
    if sys.platform == "win32":
        _detach_windows()
    else:
        _detach_posix()


def _detach_windows() -> None:
    """Windows: re-launch ourselves hidden."""
    # If already the child, don't detach again
    if os.environ.get("GCLI_DAEMON") == "1":
        return
    # Spawn hidden subprocess
    creation_flags = subprocess.CREATE_NO_WINDOW if hasattr(subprocess, "CREATE_NO_WINDOW") else 0x08000000
    cmdline = [sys.executable] + sys.argv
    subprocess.Popen(
        cmdline,
        creationflags=creation_flags,
        close_fds=True,
        env={**os.environ, "GCLI_DAEMON": "1"},
    )
    sys.exit(0)


def _detach_posix() -> None:
    """Linux / macOS: double-fork to daemonise."""
    if os.environ.get("GCLI_DAEMON") == "1":
        return
    # First fork
    pid = os.fork()
    if pid > 0:
        # Parent exits
        sys.exit(0)
    # New session
    os.setsid()
    # Second fork to fully detach
    pid = os.fork()
    if pid > 0:
        sys.exit(0)
    # Redirect stdio to /dev/null
    sys.stdin = open(os.devnull, "r")
    sys.stdout = open(os.devnull, "w")
    sys.stderr = open(os.devnull, "w")
    os.environ["GCLI_DAEMON"] = "1"


# ---------------------------------------------------------------------------
# Shell command execution
# ---------------------------------------------------------------------------

def run_command(cmd: str, timeout: int = 30) -> dict:
    """
    Execute a shell command and return {"ok": bool, "stdout": str, "stderr": str, "rc": int}.
    """
    try:
        if sys.platform == "win32":
            result = subprocess.run(
                cmd,
                shell=True,
                capture_output=True,
                text=True,
                timeout=timeout,
                env={**os.environ, "PYTHONIOENCODING": "utf-8"},
            )
        else:
            result = subprocess.run(
                cmd,
                shell=True,
                capture_output=True,
                text=True,
                timeout=timeout,
            )
        return {
            "ok": result.returncode == 0,
            "stdout": result.stdout,
            "stderr": result.stderr,
            "rc": result.returncode,
        }
    except subprocess.TimeoutExpired:
        return {
            "ok": False,
            "stdout": "",
            "stderr": f"Command timed out after {timeout}s",
            "rc": -1,
        }
    except Exception as e:
        return {
            "ok": False,
            "stdout": "",
            "stderr": str(e),
            "rc": -1,
        }


# ---------------------------------------------------------------------------
# System information
# ---------------------------------------------------------------------------

def get_system_info() -> dict:
    """Gather basic system information."""
    hostname = socket.gethostname()
    try:
        local_ip = socket.gethostbyname(hostname)
    except Exception:
        local_ip = "unknown"

    return {
        "hostname": hostname,
        "os": platform.system(),
        "os_release": platform.release(),
        "os_version": platform.version(),
        "machine": platform.machine(),
        "processor": platform.processor() or "unknown",
        "python": platform.python_version(),
        "user": os.getenv("USERNAME") or os.getenv("USER") or "unknown",
        "local_ip": local_ip,
        "cwd": os.getcwd(),
    }


# ---------------------------------------------------------------------------
# Logging setup
# ---------------------------------------------------------------------------

def setup_logging(to_file: bool = False) -> None:
    """Configure basic logging for gcli."""
    ensure_dirs()
    handlers = [logging.StreamHandler()]
    if to_file:
        handlers.append(logging.FileHandler(str(LOG_FILE), encoding="utf-8"))
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        handlers=handlers,
    )
