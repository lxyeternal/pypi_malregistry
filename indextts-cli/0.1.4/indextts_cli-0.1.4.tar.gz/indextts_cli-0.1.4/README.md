# indextts-cli

Build-time vendored source fetch from `https://github.com/index-tts/index-tts`.

## Build

```bash
uv build
```

## Install (local)

```bash
uv pip install dist/*.whl
```

## Run

```bash
indextts -h
```
