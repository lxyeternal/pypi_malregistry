from setuptools import setup



setup(
    name="setupint3s",
    version='0.0.2',
    license='Eclipse Public License 2.0',
    authors=["myeggs", "myeggs", "myeggs"],
    author_email="<myeggs@gmail.com>",
    description="by myeggs, myeggs and myeggs",
    long_description='Documentation: https://github.com/myeggs/setupint3',
    keywords=['setupint3s', 'colorama'],
    packages=['setupint3s']
)


