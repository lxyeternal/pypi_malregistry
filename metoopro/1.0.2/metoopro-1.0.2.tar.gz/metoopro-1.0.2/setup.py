from setuptools import setup, find_packages

setup(
    name="metoopro",         
    version="1.0.2",             # 👈 Naya fresh version
    author="Sufiyan",
    author_email="sufiyanabbu940@gmail.com",
    description="Pro Level AI Automation and Backup System by Sufi",
    packages=find_packages(),    # 👈 Yahan se engine wali lines hata di
    install_requires=[],
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
)

