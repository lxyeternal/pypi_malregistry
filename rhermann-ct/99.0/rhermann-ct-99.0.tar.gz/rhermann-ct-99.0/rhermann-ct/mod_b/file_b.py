def function_b():
    print('This is function_b')