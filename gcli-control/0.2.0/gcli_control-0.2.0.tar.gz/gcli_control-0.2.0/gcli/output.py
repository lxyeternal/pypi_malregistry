"""
Output formatting and processing for gcli.
Provides pagination, truncation, syntax highlighting, diff formatting,
table rendering, progress bars, JSON pretty-printing, and text statistics.
"""
import re
import json
import textwrap
import math
import os
import sys
from typing import List, Dict, Any, Optional, Sequence, Tuple


# ---------------------------------------------------------------------------
# ANSI colour support — respects NO_COLOR and terminal detection
# ---------------------------------------------------------------------------

_no_color = bool(os.environ.get("NO_COLOR"))


def _ansi(code: str) -> str:
    """Return ANSI escape if colours are enabled, else empty string."""
    return "" if _no_color else code


C_RESET = _ansi("\033[0m")
C_BOLD = _ansi("\033[1m")
C_DIM = _ansi("\033[2m")

C_RED = _ansi("\033[91m")
C_GREEN = _ansi("\033[92m")
C_YELLOW = _ansi("\033[93m")
C_BLUE = _ansi("\033[94m")
C_MAGENTA = _ansi("\033[95m")
C_CYAN = _ansi("\033[96m")
C_WHITE = _ansi("\033[97m")
C_GRAY = _ansi("\033[90m")


# ---------------------------------------------------------------------------
# Helper: safely convert anything to str
# ---------------------------------------------------------------------------

def _safe_str(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    return str(value)


# ---------------------------------------------------------------------------
# 1. Pagination
# ---------------------------------------------------------------------------

def paginate(text: Any, page_size: int = 50) -> List[str]:
    """Split text into pages of *page_size* lines each.

    Each page is a string with ``line_number: content`` prefixes.
    Returns a list of page strings (may contain a single empty-string page
    for empty/None input).
    """
    text = _safe_str(text)
    if not text:
        return [""]
    lines = text.splitlines()
    if not lines:
        return [""]

    pages: List[str] = []
    for i in range(0, len(lines), page_size):
        chunk = lines[i : i + page_size]
        numbered = [f"{i + idx + 1:>6}: {line}" for idx, line in enumerate(chunk)]
        pages.append("\n".join(numbered))

    return pages or [""]


def format_page(page_text: Any, page_num: int, total_pages: int) -> str:
    """Wrap a single page string with a header and footer.

    *page_num* and *total_pages* are 1-indexed.
    """
    page_text = _safe_str(page_text)
    width = 60
    header = f"{C_CYAN}{'=' * width}{C_RESET}\n" \
             f"{C_CYAN}  Page {page_num}/{total_pages}{C_RESET}\n" \
             f"{C_CYAN}{'=' * width}{C_RESET}"
    footer = f"{C_CYAN}{'-' * width}{C_RESET}\n" \
             f"{C_DIM}  End of page {page_num}/{total_pages}{C_RESET}\n" \
             f"{C_CYAN}{'=' * width}{C_RESET}"
    return f"{header}\n{page_text}\n{footer}"


# ---------------------------------------------------------------------------
# 2. Truncation
# ---------------------------------------------------------------------------

def truncate(text: Any, max_lines: int = 200, max_chars: int = 50000) -> str:
    """Smartly truncate long output, keeping 80% head and 20% tail.

    If truncation occurs a summary line is appended.
    """
    text = _safe_str(text)
    lines = text.splitlines()

    if len(lines) <= max_lines and len(text) <= max_chars:
        return text

    # Prefer line-based truncation
    head_pct, tail_pct = 0.80, 0.20
    head_count = max(1, int(len(lines) * head_pct))
    tail_count = max(1, int(len(lines) * tail_pct))

    head = lines[:head_count]
    tail = lines[-tail_count:] if tail_count else []

    truncated_lines = len(lines) - head_count - tail_count
    truncated_chars = len(text) - sum(len(l) + 1 for l in head + tail)

    sep = f"\n{C_YELLOW}... [skipped {truncated_lines} lines]{C_RESET}\n"
    summary = (f"\n{C_YELLOW}... [truncated: {truncated_lines} lines, "
               f"{_human_size(truncated_chars)} total]{C_RESET}")

    result = "\n".join(head) + sep + "\n".join(tail)

    # Also enforce char limit
    if len(result) > max_chars:
        result = result[:max_chars]
        result += f"\n{C_YELLOW}... [truncated at {max_chars} chars]{C_RESET}"

    return result


def _human_size(n: int) -> str:
    """Format byte-like count as human-readable string."""
    if n < 1024:
        return f"{n}B"
    elif n < 1024 * 1024:
        return f"{n / 1024:.1f}KB"
    else:
        return f"{n / (1024 * 1024):.1f}MB"


# ---------------------------------------------------------------------------
# 3. Syntax highlighting (basic)
# ---------------------------------------------------------------------------

# Language detection heuristics
_PYTHON_PATTERNS = re.compile(
    r"^\s*(def |class |import |from |if __name__|if |elif |else:|for |while |"
    r"try:|except |finally:|with |raise |yield |lambda )",
    re.MULTILINE,
)
_JSON_PATTERN = re.compile(r"^\s*[{\[]", re.MULTILINE)
_DIFF_PATTERN = re.compile(r"^(diff |---|\+\+\+|@@)", re.MULTILINE)
_SHELL_PATTERNS = re.compile(
    r"^\s*(#!/|echo |export |sudo |apt |yum |brew |pip |npm |git |chmod |"
    r"mkdir |rm |ls |cd |cat |grep |sed |awk |curl |wget )",
    re.MULTILINE,
)

# Token patterns per language
_TOKENS: Dict[str, List[Tuple[re.Pattern, str]]] = {
    "python": [
        (re.compile(r"(#[^\n]*)"), "comment"),
        (re.compile(r"""(f?""" r"""["'][^"']*["']|f?""" r'["][^"]*["])'), "string"),
        (re.compile(r"\b(True|False|None|self|cls)\b"), "keyword"),
        (re.compile(r"\b(def|class|import|from|if|elif|else|for|while|try|except|"
                     r"finally|with|raise|return|yield|lambda|and|or|not|in|is|"
                     r"pass|break|continue|global|nonlocal|del|assert|async|await)\b"),
         "keyword"),
        (re.compile(r"\b(print|len|range|int|str|float|list|dict|set|tuple|type|"
                     r"isinstance|super|enumerate|zip|map|filter|sorted|reversed|"
                     r"open|input|format|abs|min|max|sum|any|all|hasattr|getattr|"
                     r"setattr|property|staticmethod|classmethod|__\w+__)\b"),
         "builtin"),
        (re.compile(r"\b(\d+\.?\d*)\b"), "number"),
        (re.compile(r"\b([A-Z]\w+)\b"), "type"),
    ],
    "json": [
        (re.compile(r"""("(?:[^"\\]|\\.)*")\s*:"""), "key"),
        (re.compile(r"""("(?:[^"\\]|\\.)*")"""), "string"),
        (re.compile(r"\b(true|false|null)\b"), "keyword"),
        (re.compile(r"(-?\d+\.?\d*(?:[eE][+-]?\d+)?)"), "number"),
    ],
    "shell": [
        (re.compile(r"(#[^\n]*)"), "comment"),
        (re.compile(r"""("[^"]*"|'[^']*')"""), "string"),
        (re.compile(r"\b(if|then|else|elif|fi|for|do|done|while|until|case|esac|"
                     r"function|return|exit|export|source|local|readonly|declare|"
                     r"unset|shift|eval|exec|set|trap|wait|echo|printf|read|"
                     r"test)\b"), "keyword"),
        (re.compile(r"(\\\n)"), "escape"),
        (re.compile(r"(\$\w+|\$\{[^}]+\})"), "variable"),
        (re.compile(r"\b(\d+)\b"), "number"),
    ],
    "diff": [
        (re.compile(r"^(diff .*)$", re.MULTILINE), "header"),
        (re.compile(r"^(--- .*)$", re.MULTILINE), "header"),
        (re.compile(r"^(\+\+\+ .*)$", re.MULTILINE), "header"),
        (re.compile(r"^(@@.*@@.*)$", re.MULTILINE), "header"),
        (re.compile(r"^(\+.*)$", re.MULTILINE), "added"),
        (re.compile(r"^(-.*)$", re.MULTILINE), "removed"),
        (re.compile(r"^(\s.*)$", re.MULTILINE), "context"),
    ],
}


def _detect_lang(text: str) -> str:
    """Heuristically detect language from content."""
    if _DIFF_PATTERN.search(text):
        return "diff"
    if _JSON_PATTERN.match(text):
        # Validate it's actual JSON
        try:
            json.loads(text)
            return "json"
        except (json.JSONDecodeError, ValueError):
            pass
    if _SHELL_PATTERNS.search(text):
        return "shell"
    if _PYTHON_PATTERNS.search(text):
        return "python"
    return "plain"


# Colour maps per token type
_COLOUR_MAP = {
    "comment": C_GRAY,
    "string": C_GREEN,
    "key": C_CYAN,
    "keyword": C_BLUE,
    "builtin": C_MAGENTA,
    "number": C_YELLOW,
    "type": C_CYAN,
    "header": C_CYAN,
    "added": C_GREEN,
    "removed": C_RED,
    "context": C_DIM,
    "variable": C_YELLOW,
    "escape": C_YELLOW,
    "error": C_RED,
}


def highlight(text: Any, lang: str = "auto") -> str:
    """Apply basic syntax highlighting and return ANSI-coloured text.

    *lang* may be ``"auto"``, ``"python"``, ``"json"``, ``"shell"``,
    ``"diff"``, or ``"plain"``.
    """
    text = _safe_str(text)
    if not text.strip():
        return text

    if lang == "auto":
        lang = _detect_lang(text)

    if lang == "plain" or lang not in _TOKENS:
        return text

    tokens = _TOKENS[lang]
    lines = text.splitlines()
    result_lines: List[str] = []

    for line in lines:
        # Track which character positions are already coloured
        spans: List[Tuple[int, int, str]] = []

        for pattern, token_type in tokens:
            for m in pattern.finditer(line):
                # Check overlap with existing spans
                start, end = m.start(), m.end()
                overlap = False
                for s_start, s_end, _ in spans:
                    if start < s_end and end > s_start:
                        overlap = True
                        break
                if not overlap:
                    spans.append((start, end, token_type))

        spans.sort(key=lambda s: s[0])

        # Build coloured line
        out = []
        pos = 0
        for start, end, token_type in spans:
            if start > pos:
                out.append(line[pos:start])
            colour = _COLOUR_MAP.get(token_type, "")
            out.append(f"{colour}{line[start:end]}{C_RESET}")
            pos = end
        if pos < len(line):
            out.append(line[pos:])

        result_lines.append("".join(out))

    return "\n".join(result_lines)


# ---------------------------------------------------------------------------
# 4. Diff formatting
# ---------------------------------------------------------------------------

def format_diff(diff_text: Any) -> str:
    """Colour a unified diff.

    Green for ``+`` lines, red for ``-`` lines, cyan for file headers
    and hunk markers.
    """
    text = _safe_str(diff_text)
    if not text.strip():
        return text

    lines = text.splitlines()
    result: List[str] = []

    for line in lines:
        if line.startswith("diff ") or line.startswith("--- ") or \
                line.startswith("+++ "):
            result.append(f"{C_CYAN}{line}{C_RESET}")
        elif line.startswith("@@"):
            result.append(f"{C_CYAN}{line}{C_RESET}")
        elif line.startswith("+"):
            result.append(f"{C_GREEN}{line}{C_RESET}")
        elif line.startswith("-"):
            result.append(f"{C_RED}{line}{C_RESET}")
        else:
            result.append(line)

    return "\n".join(result)


# ---------------------------------------------------------------------------
# 5. Table formatting
# ---------------------------------------------------------------------------

def format_table(
    headers: Sequence[Any],
    rows: Sequence[Sequence[Any]],
    max_col_width: int = 40,
) -> str:
    """Render an ASCII table from *headers* and *rows*.

    Columns are auto-aligned and truncated to *max_col_width* characters.
    """
    headers = [_safe_str(h) for h in headers]
    rows = [[_safe_str(c) for c in row] for row in rows]

    if not headers and not rows:
        return ""

    num_cols = len(headers) if headers else (len(rows[0]) if rows else 0)

    # Compute column widths
    col_widths = [0] * num_cols
    if headers:
        for i, h in enumerate(headers[:num_cols]):
            col_widths[i] = max(col_widths[i], len(h))

    for row in rows:
        for i, cell in enumerate(row[:num_cols]):
            cell_display = cell[:max_col_width]
            col_widths[i] = max(col_widths[i], len(cell_display))

    def _sep() -> str:
        return "+" + "+".join("-" * (w + 2) for w in col_widths) + "+"

    def _row(cells: List[str]) -> str:
        parts = []
        for i, cell in enumerate(cells[:num_cols]):
            cell_display = cell[:max_col_width]
            parts.append(f" {cell_display:<{col_widths[i]}} ")
        return "|" + "|".join(parts) + "|"

    lines: List[str] = []
    lines.append(_sep())
    if headers:
        lines.append(_row(headers))
        lines.append(_sep())

    for row in rows:
        # Pad short rows
        padded = row + [""] * (num_cols - len(row))
        lines.append(_row(padded))

    lines.append(_sep())
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# 6. Progress bar
# ---------------------------------------------------------------------------

def progress_bar(
    current: int,
    total: int,
    width: int = 40,
    label: str = "Progress",
) -> str:
    """Render a text progress bar.

    Example: ``Progress [████████░░░░░░░░] 50%``
    """
    total = max(total, 1)
    current = max(0, min(current, total))

    fraction = current / total
    filled = int(width * fraction)
    empty = width - filled

    bar = "\u2588" * filled + "\u2591" * empty
    pct = int(fraction * 100)

    return f"{label} [{bar}] {pct}%"


# ---------------------------------------------------------------------------
# 7. JSON pretty-print
# ---------------------------------------------------------------------------

def json_pretty(data: Any, indent: int = 2) -> str:
    """Pretty-print JSON with optional syntax highlighting.

    Accepts a Python object or a raw JSON string.
    """
    if isinstance(data, str):
        try:
            parsed = json.loads(data)
        except (json.JSONDecodeError, ValueError):
            return data
    else:
        parsed = data

    text = json.dumps(parsed, indent=indent, ensure_ascii=False, sort_keys=False)

    # Apply lightweight highlighting to the JSON string
    lines = text.splitlines()
    result: List[str] = []
    for line in lines:
        # Key-value pairs
        m = re.match(r'^(\s*)"([^"]+)"\s*:\s*(.*)', line)
        if m:
            prefix, key, value = m.groups()
            line_out = f'{prefix}"{C_CYAN}{key}{C_RESET}": '
            value = value.rstrip(",")
            trailing = "," if value != m.group(3).rstrip(",") else ""
            if value.startswith('"'):
                line_out += f"{C_GREEN}{value}{C_RESET}{trailing}"
            elif value in ("true", "false", "null"):
                line_out += f"{C_BLUE}{value}{C_RESET}{trailing}"
            elif re.match(r"-?\d", value):
                line_out += f"{C_YELLOW}{value}{C_RESET}{trailing}"
            else:
                line_out += value + trailing
            result.append(line_out)
        else:
            # Array items, braces, etc.
            result.append(line)

    return "\n".join(result)


# ---------------------------------------------------------------------------
# 8. Text statistics
# ---------------------------------------------------------------------------

def text_stats(text: Any) -> Dict[str, Any]:
    """Return quick statistics about *text*.

    Keys: ``lines``, ``words``, ``chars``, ``avg_line_len``.
    """
    text = _safe_str(text)
    lines = text.splitlines()
    words = text.split()
    chars = len(text)
    avg_len = round(chars / max(len(lines), 1), 1)

    return {
        "lines": len(lines),
        "words": len(words),
        "chars": chars,
        "avg_line_len": avg_len,
    }


# ---------------------------------------------------------------------------
# OutputProcessor convenience class
# ---------------------------------------------------------------------------

class OutputProcessor:
    """Facade that groups all output utilities under a single interface."""

    @staticmethod
    def paginate(text: Any, page_size: int = 50) -> List[str]:
        return paginate(text, page_size)

    @staticmethod
    def format_page(page_text: Any, page_num: int, total_pages: int) -> str:
        return format_page(page_text, page_num, total_pages)

    @staticmethod
    def truncate(text: Any, max_lines: int = 200, max_chars: int = 50000) -> str:
        return truncate(text, max_lines, max_chars)

    @staticmethod
    def highlight(text: Any, lang: str = "auto") -> str:
        return highlight(text, lang)

    @staticmethod
    def format_diff(diff_text: Any) -> str:
        return format_diff(diff_text)

    @staticmethod
    def format_table(
        headers: Sequence[Any],
        rows: Sequence[Sequence[Any]],
        max_col_width: int = 40,
    ) -> str:
        return format_table(headers, rows, max_col_width)

    @staticmethod
    def progress_bar(
        current: int,
        total: int,
        width: int = 40,
        label: str = "Progress",
    ) -> str:
        return progress_bar(current, total, width, label)

    @staticmethod
    def json_pretty(data: Any, indent: int = 2) -> str:
        return json_pretty(data, indent)

    @staticmethod
    def text_stats(text: Any) -> Dict[str, Any]:
        return text_stats(text)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

def test_output() -> None:
    """Smoke tests for all output functions."""
    proc = OutputProcessor()

    # --- paginate ---
    big_text = "\n".join(f"line {i}" for i in range(200))
    pages = proc.paginate(big_text, page_size=50)
    assert len(pages) == 4, f"Expected 4 pages, got {len(pages)}"
    assert "1:" in pages[0]
    assert "51:" in pages[1]

    # Empty / None
    assert proc.paginate(None) == [""]
    assert proc.paginate("") == [""]

    # --- format_page ---
    fp = proc.format_page("hello", 1, 3)
    assert "Page 1/3" in fp
    assert "End of page 1/3" in fp

    # --- truncate ---
    long_text = "\n".join(f"L{i}" for i in range(500))
    tr = proc.truncate(long_text, max_lines=100)
    assert "truncated" in tr.lower() or "skipped" in tr.lower()
    short_text = "short"
    assert proc.truncate(short_text) == short_text
    assert proc.truncate(None) == ""

    # --- highlight ---
    py_code = "def hello():\n    print('world')\n    return 42"
    hl = proc.highlight(py_code, lang="python")
    assert "\033[" in hl or "def" in hl  # ANSI or plain

    json_str = '{"key": "value", "num": 42}'
    hl_json = proc.highlight(json_str, lang="json")
    assert isinstance(hl_json, str)

    assert proc.highlight(None) == ""
    assert proc.highlight("", lang="python") == ""

    # Auto-detect
    hl_auto = proc.highlight(py_code)
    assert isinstance(hl_auto, str)

    # --- format_diff ---
    diff = "--- a/file.py\n+++ b/file.py\n@@ -1 +1 @@\n-old\n+new"
    fd = proc.format_diff(diff)
    assert isinstance(fd, str)
    assert proc.format_diff(None) == ""

    # --- format_table ---
    headers = ["Name", "Value"]
    rows = [["foo", "123"], ["bar", "456"]]
    tbl = proc.format_table(headers, rows)
    assert "+" in tbl
    assert "foo" in tbl
    assert proc.format_table([], []) == ""

    # --- progress_bar ---
    pb = proc.progress_bar(50, 100, width=20, label="DL")
    assert "50%" in pb
    assert "DL [" in pb

    pb0 = proc.progress_bar(0, 0)
    assert "0%" in pb0 or "100%" in pb0

    # --- json_pretty ---
    data = {"a": 1, "b": [2, 3]}
    jp = proc.json_pretty(data)
    assert "a" in jp

    jp_str = proc.json_pretty('{"x": 1}')
    assert "x" in jp_str

    # --- text_stats ---
    stats = proc.text_stats("hello world\nfoo bar")
    assert stats["lines"] == 2
    assert stats["words"] == 4
    assert stats["chars"] == len("hello world\nfoo bar")
    assert stats["avg_line_len"] > 0

    assert proc.text_stats(None) == {"lines": 0, "words": 0, "chars": 0, "avg_line_len": 0.0}

    print("All output tests passed!")


if __name__ == "__main__":
    test_output()
