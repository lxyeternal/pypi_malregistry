from setuptools import setup, find_packages
setup(name = "iou3d", version = "2.1", packages = find_packages())