=======
History
=======

1.1.0 (2020-04-13)
------------------

* Added logic to auto-detect partitions
* Added logic to override auto-detected endpoints, for corporate proxies

1.0.0 (2020-03-14)
------------------

* Release to GitHub.

0.1.0 (2020-02-24)
------------------

* Internal repository rehydration.
