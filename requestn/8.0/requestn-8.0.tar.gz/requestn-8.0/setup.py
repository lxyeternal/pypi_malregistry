import setuptools
setuptools.setup(
    name='requestn',
    version='8.0',
    author='Programmer Golden ',
    description='By Golden In telegram @rrrrrf',
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
        "License :: OSI Approved :: MIT License"
    ]
)
