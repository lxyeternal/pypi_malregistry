"""
AES-256-GCM encryption/decryption for gcli.
Password -> PBKDF2 -> 256-bit key -> AES-256-GCM.
"""
import os
import json
import base64
import hashlib
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

SALT = b"gcli-v1-salt-2024"  # fixed salt (password provides secrecy)
ITERATIONS = 600_000          # OWASP 2023 recommendation for PBKDF2-SHA256


def derive_key(password: str) -> bytes:
    """Derive a 256-bit key from a password using PBKDF2."""
    return hashlib.pbkdf2_hmac(
        "sha256",
        password.encode("utf-8"),
        SALT,
        ITERATIONS,
        dklen=32,
    )


def encrypt(plaintext: str, password: str) -> str:
    """Encrypt plaintext string -> base64 string. Format: nonce(12) + ciphertext + tag(16)."""
    key = derive_key(password)
    nonce = os.urandom(12)
    aesgcm = AESGCM(key)
    ct = aesgcm.encrypt(nonce, plaintext.encode("utf-8"), None)
    return base64.b64encode(nonce + ct).decode("ascii")


def decrypt(blob: str, password: str) -> str:
    """Decrypt base64 string -> plaintext string."""
    key = derive_key(password)
    raw = base64.b64decode(blob)
    nonce, ct = raw[:12], raw[12:]
    aesgcm = AESGCM(key)
    return aesgcm.decrypt(nonce, ct, None).decode("utf-8")


def encrypt_dict(data: dict, password: str) -> str:
    """Encrypt a dict -> base64 string (JSON-serialised then encrypted)."""
    return encrypt(json.dumps(data, separators=(",", ":")), password)


def decrypt_dict(blob: str, password: str) -> dict:
    """Decrypt a base64 string -> dict."""
    return json.loads(decrypt(blob, password))
