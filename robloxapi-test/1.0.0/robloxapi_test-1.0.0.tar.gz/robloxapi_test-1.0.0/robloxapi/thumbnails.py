"""
Roblox Thumbnails API - https://thumbnails.roblox.com
"""

from typing import List, Optional


class ThumbnailsAPI:
    BASE = "https://thumbnails.roblox.com/v1"

    def __init__(self, client):
        self._c = client

    def get_user_avatars(self, user_ids: List[int],
                         size: str = "420x420",
                         format: str = "Png",
                         is_circular: bool = False) -> dict:
        """
        Get avatar thumbnail URLs for a list of users.

        Args:
            size: "48x48", "50x50", "60x60", "75x75", "100x100",
                  "110x110", "140x140", "150x150", "150x200", "180x180",
                  "250x250", "352x352", "420x420", "720x720"
            format: "Png" or "Jpeg"

        Returns:
            dict: {data: [{targetId, state, imageUrl}, ...]}
        """
        return self._c._get(
            f"{self.BASE}/users/avatar",
            params={
                "userIds": ",".join(str(i) for i in user_ids),
                "size": size,
                "format": format,
                "isCircular": is_circular,
            },
        )

    def get_user_avatar_headshots(self, user_ids: List[int],
                                  size: str = "420x420",
                                  format: str = "Png",
                                  is_circular: bool = False) -> dict:
        """
        Get avatar headshot (head-only) thumbnail URLs.

        Returns:
            dict: {data: [{targetId, state, imageUrl}, ...]}
        """
        return self._c._get(
            f"{self.BASE}/users/avatar-headshot",
            params={
                "userIds": ",".join(str(i) for i in user_ids),
                "size": size,
                "format": format,
                "isCircular": is_circular,
            },
        )

    def get_game_icons(self, universe_ids: List[int],
                       size: str = "512x512",
                       format: str = "Png",
                       is_circular: bool = False) -> dict:
        """
        Get game icon thumbnail URLs.

        Args:
            size: "50x50", "128x128", "150x150", "256x256", "512x512"

        Returns:
            dict: {data: [{targetId, state, imageUrl}, ...]}
        """
        return self._c._get(
            f"{self.BASE}/games/icons",
            params={
                "universeIds": ",".join(str(i) for i in universe_ids),
                "size": size,
                "format": format,
                "isCircular": is_circular,
            },
        )

    def get_game_thumbnails(self, universe_ids: List[int],
                            size: str = "768x432",
                            format: str = "Png",
                            count_per_universe: int = 5) -> dict:
        """
        Get game screenshots/thumbnails for universes.

        Args:
            size: "480x270", "768x432"
            count_per_universe: How many thumbnails per game (1–10).

        Returns:
            dict: {data: [{universeId, error, thumbnails: [{targetId,
                           state, imageUrl}, ...]}, ...]}
        """
        return self._c._get(
            f"{self.BASE}/games/multiget/thumbnails",
            params={
                "universeIds": ",".join(str(i) for i in universe_ids),
                "size": size,
                "format": format,
                "countPerUniverse": count_per_universe,
            },
        )

    def get_asset_thumbnails(self, asset_ids: List[int],
                             size: str = "420x420",
                             format: str = "Png") -> dict:
        """
        Get thumbnail URLs for catalog assets.

        Args:
            size: "30x30", "42x42", "50x50", "60x62", "75x75", "110x110",
                  "140x140", "150x150", "160x100", "160x600", "250x250",
                  "256x144", "420x420", "480x270", "512x512", "576x324",
                  "700x700", "728x90", "768x432"

        Returns:
            dict: {data: [{targetId, state, imageUrl}, ...]}
        """
        return self._c._get(
            f"{self.BASE}/assets",
            params={
                "assetIds": ",".join(str(i) for i in asset_ids),
                "size": size,
                "format": format,
            },
        )

    def get_bundle_thumbnails(self, bundle_ids: List[int],
                              size: str = "420x420",
                              format: str = "Png") -> dict:
        """
        Get thumbnail URLs for catalog bundles.

        Returns:
            dict: {data: [{targetId, state, imageUrl}, ...]}
        """
        return self._c._get(
            f"{self.BASE}/bundles/thumbnails",
            params={
                "bundleIds": ",".join(str(i) for i in bundle_ids),
                "size": size,
                "format": format,
            },
        )

    def get_group_icons(self, group_ids: List[int],
                        size: str = "420x420",
                        format: str = "Png",
                        is_circular: bool = False) -> dict:
        """
        Get group icon thumbnail URLs.

        Returns:
            dict: {data: [{targetId, state, imageUrl}, ...]}
        """
        return self._c._get(
            f"{self.BASE}/groups/icons",
            params={
                "groupIds": ",".join(str(i) for i in group_ids),
                "size": size,
                "format": format,
                "isCircular": is_circular,
            },
        )
