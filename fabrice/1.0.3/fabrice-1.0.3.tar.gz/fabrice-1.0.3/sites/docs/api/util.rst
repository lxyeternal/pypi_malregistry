========
``util``
========

.. automodule:: fabric.util
