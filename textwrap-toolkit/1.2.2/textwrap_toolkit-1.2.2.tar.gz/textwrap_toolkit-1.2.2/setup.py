from setuptools import setup, find_packages

setup(
    name="textwrap-toolkit",
    version="1.2.2",
    author="TextStack Devs",
    author_email="contact@textstack.io",
    description="A lightweight utility for advanced text wrapping and terminal alignment.",
    long_description="""
# Textwrap Toolkit

A Python library designed to extend the capabilities of the built-in `textwrap` module.
It provides additional controls for dynamic terminal widths, ANSI escape sequence handling,
and structured log formatting.

## Installation
```bash
pip install textwrap-toolkit
```

## Usage
```python
from textwrap_toolkit import format_block
print(format_block("Your long text here...", width=40))
```
""",
    long_description_content_type="text/markdown",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Text Processing :: Filters",
        "Intended Audience :: Developers",
    ],
    python_requires='>=3.6',
    install_requires=[],
)