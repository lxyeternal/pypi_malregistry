from setuptools import setup, find_packages

setup(
    name="timsingapi",
    version="1.5",
    packages=find_packages(),
    description="Timsing api.",
    author="Security Researcher",
    author_email="johnblanzia@johnblanzia.com",
    zip_safe=False,
)
