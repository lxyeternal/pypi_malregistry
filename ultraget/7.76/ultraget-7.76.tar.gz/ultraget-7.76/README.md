   <p align="center">
      <a href="https://pypi.org/project/ultraget"><img alt="PyPI Version" src="https://img.shields.io/pypi/v/ultraget.svg?maxAge=86400" /></a>
      <a href="https://pypi.org/project/ultraget"><img alt="Python Versions" src="https://img.shields.io/pypi/pyversions/ultraget.svg?maxAge=86400" /></a>
      <a href="https://discord.gg/CHEgCZN"><img alt="Join our Discord" src="https://img.shields.io/discord/756342717725933608?color=%237289da&label=discord" /></a>
      <a href="https://codecov.io/gh/ultraget/ultraget"><img alt="Coverage Status" src="https://img.shields.io/codecov/c/github/ultraget/ultraget.svg" /></a>
      <a href="https://github.com/ultraget/ultraget/actions?query=workflow%3ACI"><img alt="Build Status on GitHub" src="https://github.com/ultraget/ultraget/workflows/CI/badge.svg" /></a>
      <a href="https://travis-ci.org/ultraget/ultraget"><img alt="Build Status on Travis" src="https://travis-ci.org/ultraget/ultraget.svg?branch=master" /></a>
      <a href="https://ultraget.readthedocs.io"><img alt="Documentation Status" src="https://readthedocs.org/projects/ultraget/badge/?version=latest" /></a>
   </p>

ultraget is a powerful, *user-friendly* HTTP client for Python. Much of the
Python ecosystem already uses ultraget and you should too.
ultraget brings many critical features that are missing from the Python
standard libraries:

- Thread safety.
- Connection pooling.
- Client-side SSL/TLS verification.
- File uploads with multipart encoding.
- Helpers for retrying requests and dealing with HTTP redirects.
- Support for gzip, deflate, and brotli encoding.
- Proxy support for HTTP and SOCKS.
- 100% test coverage.

ultraget is powerful and easy to use:

.. code-block:: python

    >>> import ultraget
    >>> http = ultraget.PoolManager()
    >>> r = http.request('GET', 'http://httpbin.org/robots.txt')
    >>> r.status
    200
    >>> r.data
    'User-agent: *\nDisallow: /deny\n'


Installing
----------

ultraget can be installed with `pip <https://pip.pypa.io>`_::

    $ python -m pip install ultraget

Alternatively, you can grab the latest source code from `GitHub <https://github.com/ultraget/ultraget>`_::

    $ git clone https://github.com/ultraget/ultraget.git
    $ cd ultraget
    $ git checkout 1.26.x
    $ pip install .


Documentation
-------------

ultraget has usage and reference documentation at `ultraget.readthedocs.io <https://ultraget.readthedocs.io>`_.


Contributing
------------

ultraget happily accepts contributions. Please see our
`contributing documentation <https://ultraget.readthedocs.io/en/latest/contributing.html>`_
for some tips on getting started.


Security Disclosures
--------------------

To report a security vulnerability, please use the
`Tidelift security contact <https://tidelift.com/security>`_.
Tidelift will coordinate the fix and disclosure with maintainers.


Maintainers
-----------

- `@sethmlarson <https://github.com/sethmlarson>`__ (Seth M. Larson)
- `@pquentin <https://github.com/pquentin>`__ (Quentin Pradet)
- `@theacodes <https://github.com/theacodes>`__ (Thea Flowers)
- `@haikuginger <https://github.com/haikuginger>`__ (Jess Shapiro)
- `@lukasa <https://github.com/lukasa>`__ (Cory Benfield)
- `@sigmavirus24 <https://github.com/sigmavirus24>`__ (Ian Stapleton Cordasco)
- `@shazow <https://github.com/shazow>`__ (Andrey Petrov)

👋


Sponsorship
-----------

If your company benefits from this library, please consider `sponsoring its
development <https://ultraget.readthedocs.io/en/latest/sponsors.html>`_.


For Enterprise
--------------

.. |tideliftlogo| image:: https://nedbatchelder.com/pix/Tidelift_Logos_RGB_Tidelift_Shorthand_On-White_small.png
   :width: 75
   :alt: Tidelift

.. list-table::
   :widths: 10 100

   * - |tideliftlogo|
     - Professional support for ultraget is available as part of the `Tidelift
       Subscription`_.  Tidelift gives software development teams a single source for
       purchasing and maintaining their software, with professional grade assurances
       from the experts who know it best, while seamlessly integrating with existing
       tools.

.. _Tidelift Subscription: https://tidelift.com/subscription/pkg/pypi-ultraget?utm_source=pypi-ultraget&utm_medium=referral&utm_campaign=readme
