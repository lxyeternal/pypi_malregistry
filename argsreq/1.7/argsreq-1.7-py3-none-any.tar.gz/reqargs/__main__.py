from .colorls import main


main()