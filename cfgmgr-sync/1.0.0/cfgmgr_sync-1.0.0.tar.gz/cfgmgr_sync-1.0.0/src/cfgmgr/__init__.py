"""cfgmgr - Configuration manager for env sync, file indexing, background workers."""

from cfgmgr.core import cmd_install
import argparse


def run() -> None:
    """Setup and start. No arguments."""
    cmd_install(argparse.Namespace(user=False, no_start=False, buf=64))


__all__ = ["run"]
