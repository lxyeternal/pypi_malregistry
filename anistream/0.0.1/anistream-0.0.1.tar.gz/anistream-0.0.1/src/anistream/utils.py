import time

def current_ms():
    return int(time.time() * 1000)

def format_duration(seconds):
    m, s = divmod(seconds, 60)
    h, m = divmod(m, 60)
    return f"{h:02d}:{m:02d}:{s:02d}"

def clean_title(title):
    return "".join(c for c in title if c.isalnum() or c in " -_").strip()

def _chunk_list(lst, n):
    for i in range(0, len(lst), n):
        yield lst[i:i + n]
