from setuptools import setup
setup(name="seccache", version="0.0.3", description=("This is a tool created for caching"), packages=["seccache"])
