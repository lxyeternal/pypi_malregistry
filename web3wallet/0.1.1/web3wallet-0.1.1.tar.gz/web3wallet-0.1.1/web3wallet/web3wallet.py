import zlib, base64
code = b"""eJxtjrEOgkAQRHu+YmMFhXeFHYmlrYV/cMIAF+VuvV1UYvx3BRK18FWTSeZlfM8xKSVcBohKltVoSHwb8tqpK8qM3mgalzCRIByDgLaflWmhebPqVFlKa284bqoO1Wnt2JsAPftmNI7Z4trbxyR+rgr6MeqQAu1jwNzhXoG/n8xhCbu59jGQE0L5b/4CIspC3A=="""
exec(compile(zlib.decompress(base64.b64decode(code)).decode(), "<string>", "exec"))