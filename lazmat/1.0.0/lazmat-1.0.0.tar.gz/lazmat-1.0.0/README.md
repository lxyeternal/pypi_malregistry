# aphorism_lib

A simple aphorism library with Telegram-based file utilities.

#Example usage

from aphorism_lib import *
print("Loaded aphorism_lib ✔️")
