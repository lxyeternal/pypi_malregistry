from __future__ import annotations

import hashlib
import hmac
import json
import os
import platform
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import requests

from pynosist import __version__, config


class RelayError(RuntimeError):
    pass


@dataclass
class ReportResult:
    accepted: bool
    deduplicated: bool
    sent_to_server: bool
    message: str



def _session() -> requests.Session:
    s = requests.Session()
    s.trust_env = bool(config.RELAY_USE_ENV_PROXY)
    s.verify = config.get_ssl_verify()
    return s



def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()



def sign_payload(secret: str, *, timestamp: str, nonce: str, body: bytes) -> str:
    message = f"{timestamp}.{nonce}.{sha256_hex(body)}".encode("utf-8")
    return hmac.new(secret.encode("utf-8"), message, hashlib.sha256).hexdigest()



def make_device_id(existing: str = "") -> str:
    if existing.strip():
        return existing.strip()
    return f"{platform.node() or 'device'}-{uuid.uuid4().hex[:12]}"


class RelayClient:
    def __init__(self, state_getter, state_updater) -> None:
        self._get = state_getter
        self._set = state_updater

    @property
    def base_url(self) -> str:
        return config.get_relay_base_url()

    def _require_base_url(self) -> str:
        base_url = self.base_url
        if not base_url:
            raise RelayError("Relay URL is not configured")
        return base_url

    def _register(self) -> None:
        bootstrap_key = config.get_relay_bootstrap_key()
        if not bootstrap_key:
            raise RelayError("Bootstrap key is not configured")

        device_id = make_device_id(self._get("device_id", ""))
        payload = {
            "bootstrap_key": bootstrap_key,
            "device_id": device_id,
            "hostname": platform.node() or os.environ.get("HOSTNAME", "unknown"),
            "platform": platform.platform(),
            "username": os.environ.get("USERNAME") or os.environ.get("USER") or "unknown",
            "os_name": platform.system() or "unknown",
            "app_version": __version__,
        }
        with _session() as s:
            response = s.post(
                f"{self._require_base_url()}/register",
                json=payload,
                timeout=20,
            )
        if not response.ok:
            raise RelayError(f"Registration failed: {response.status_code} {response.text}")
        data = response.json()
        refresh_token = str(data.get("refresh_token") or "").strip()
        returned_device_id = str(data.get("device_id") or device_id).strip()
        if not refresh_token:
            raise RelayError("Registration failed: empty refresh_token")
        self._set(
            {
                "device_id": returned_device_id,
                "refresh_token": refresh_token,
                "registered_at": data.get("registered_at", ""),
            }
        )

    def _mint_access_token(self) -> str:
        device_id = str(self._get("device_id", "")).strip()
        refresh_token = str(self._get("refresh_token", "")).strip()
        if not device_id or not refresh_token:
            self._register()
            device_id = str(self._get("device_id", "")).strip()
            refresh_token = str(self._get("refresh_token", "")).strip()

        payload = {"device_id": device_id, "refresh_token": refresh_token}
        with _session() as s:
            response = s.post(
                f"{self._require_base_url()}/token",
                json=payload,
                timeout=20,
            )
        if not response.ok:
            raise RelayError(f"Token request failed: {response.status_code} {response.text}")
        data = response.json()
        access_token = str(data.get("access_token") or "").strip()
        if not access_token:
            raise RelayError("Token request failed: empty access_token")
        self._set(
            {
                "access_token": access_token,
                "access_token_updated_at": str(data.get("issued_at") or ""),
            }
        )
        return access_token

    def _get_access_token(self) -> str:
        access_token = str(self._get("access_token", "")).strip()
        if access_token:
            return access_token
        return self._mint_access_token()

    def _request_headers(self, body: bytes) -> dict[str, str]:
        device_id = str(self._get("device_id", "")).strip()
        if not device_id:
            self._register()
            device_id = str(self._get("device_id", "")).strip()
        access_token = self._get_access_token()
        timestamp = str(int(__import__("time").time()))
        nonce = str(uuid.uuid4()).lower()
        signature = sign_payload(access_token, timestamp=timestamp, nonce=nonce, body=body)
        return {
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json",
            "X-Device-Id": device_id,
            "X-Timestamp": timestamp,
            "X-Nonce": nonce,
            "X-Signature": signature,
        }

    def fetch_config(self) -> dict | None:
        try:
            access_token = self._get_access_token()
            device_id = str(self._get("device_id", "")).strip()
            with _session() as s:
                response = s.get(
                    f"{self._require_base_url()}/config",
                    headers={
                        "Authorization": f"Bearer {access_token}",
                        "X-Device-Id": device_id,
                    },
                    timeout=15,
                )
            if response.ok:
                return response.json()
        except Exception:
            pass
        return None

    def upload_file(self, file_path: str) -> str | None:
        try:
            access_token = self._get_access_token()
            device_id = str(self._get("device_id", "")).strip()
            path = Path(file_path)
            with open(file_path, "rb") as f:
                with _session() as s:
                    response = s.post(
                        f"{self._require_base_url()}/upload",
                        files={"file": (path.name, f, "application/octet-stream")},
                        data={"device_id": device_id},
                        headers={"Authorization": f"Bearer {access_token}"},
                        timeout=120,
                    )
            if response.ok:
                return str(response.json().get("file_url") or "")
        except Exception:
            pass
        return None

    def send_report(self, payload: dict[str, Any]) -> ReportResult:
        body = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        last_error = ""
        for attempt in range(2):
            headers = self._request_headers(body)
            with _session() as s:
                response = s.post(
                    f"{self._require_base_url()}/report",
                    data=body,
                    headers=headers,
                    timeout=30,
                )
            if response.ok:
                data = response.json()
                return ReportResult(
                    accepted=bool(data.get("accepted", False)),
                    deduplicated=bool(data.get("deduplicated", False)),
                    sent_to_server=bool(data.get("sent_to_slack", False)),
                    message=str(data.get("message") or "OK"),
                )

            last_error = f"{response.status_code} {response.text}"
            if response.status_code in (401, 403):
                self._set({"access_token": ""})
                if attempt == 0:
                    try:
                        self._mint_access_token()
                        continue
                    except RelayError:
                        try:
                            self._register()
                            self._mint_access_token()
                            continue
                        except RelayError as exc:
                            last_error = str(exc)
                            break
            break
        raise RelayError(f"Report failed: {last_error}")
