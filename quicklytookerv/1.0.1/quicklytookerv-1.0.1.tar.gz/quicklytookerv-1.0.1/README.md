# quicklytookerv

quicklytookerv a hook for random.py

## Installation

```bash
pip install quicklytookerv