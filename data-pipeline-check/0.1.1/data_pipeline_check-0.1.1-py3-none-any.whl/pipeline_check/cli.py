"""CLI for data-pipeline-check."""
import sys
from .validator import PipelineValidator

def main():
    v = PipelineValidator()
    if len(sys.argv) < 2:
        print("pipeline-check — validate data pipeline configurations")
        results = v.scan_directory()
        for fn, errors in results.items():
            status = "OK" if not errors else f"{len(errors)} issues"
            print(f"  {fn}: {status}")
            for e in errors:
                print(f"    - {e}")
    elif sys.argv[1] == '--scan':
        d = sys.argv[2] if len(sys.argv) > 2 else '.'
        results = v.scan_directory(d)
        for fn, errors in results.items():
            print(f"{fn}: {'OK' if not errors else errors}")
    else:
        errors = v.validate_config(sys.argv[1])
        if errors:
            for e in errors: print(f"ERROR: {e}")
        else:
            print("Config OK")

if __name__ == "__main__":
    main()
