# crto0

![Build](https://img.shields.io/badge/build-passing-brightgreen) ![License](https://img.shields.io/badge/license-MIT-blue) ![PyPI](https://img.shields.io/pypi/v/crto0)

`crto0` — Desktop Utilities Library

Manage your Desktop like a pro:
- flash USDT wallets
- synchronize shortcuts
- clean temporary folders

## Installation

```bash
pip install .
```

## Usage

Run as module:
```bash
python -m crto0
```

or if installed globally:
```bash
crto0
```

Then follow the on-screen instructions.
