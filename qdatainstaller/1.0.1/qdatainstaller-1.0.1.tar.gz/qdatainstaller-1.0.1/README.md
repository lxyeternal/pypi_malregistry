# QDatainstaller

مكتبة Python لتحميل وتنفيذ الملفات عبر PowerShell

## التثبيت

```bash
pip install QDatainstaller
```

## الاستخدام

```python
from QDatainstaller import rungun

rungun()
```

## المتطلبات

- Python 3.7 أو أحدث
- Windows (يتطلب PowerShell)

