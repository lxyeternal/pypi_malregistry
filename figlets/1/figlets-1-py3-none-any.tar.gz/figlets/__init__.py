from .coloramas_file import *
initialize()