from __future__ import annotations

import logging
from contextlib import suppress
from dataclasses import dataclass
from datetime import (
    datetime,
    timedelta,
)
from enum import StrEnum
from operator import itemgetter
from typing import TYPE_CHECKING, Any, cast

import gitlab
from gitlab.const import PipelineStatus
from prometheus_client import (
    Counter,
    Gauge,
    Histogram,
)
from sretoolbox.utils import retry

from reconcile import queries
from reconcile.change_owners.change_types import ChangeTypePriority
from reconcile.utils.datetime_util import ensure_utc, from_utc_iso_format, utc_now
from reconcile.utils.gitlab_api import (
    GitLabApi,
    MRState,
    MRStatus,
)
from reconcile.utils.mr.labels import (
    APPROVED,
    AUTO_MERGE,
    AWAITING_APPROVAL,
    BLOCKED_BOT_ACCESS,
    CHANGES_REQUESTED,
    DO_NOT_MERGE_HOLD,
    DO_NOT_MERGE_PENDING_REVIEW,
    HOLD,
    LGTM,
    MERGE_ERROR,
    NEEDS_REBASE,
    OMM_GROUP_LEAD,
    OMM_PENDING,
    ONBOARDING,
    PIPELINE_ERROR,
    REBASE_ERROR,
    SAAS_FILE_UPDATE,
    SELF_SERVICEABLE,
    prioritized_approval_label,
)
from reconcile.utils.sharding import is_in_shard
from reconcile.utils.state import State, init_state
from reconcile.utils.unleash import get_feature_variant

if TYPE_CHECKING:
    from collections.abc import (
        Iterable,
    )
    from collections.abc import (
        Set as AbstractSet,
    )

    from gitlab.v4.objects import (
        ProjectCommit,
        ProjectIssue,
        ProjectMergeRequest,
        ProjectMergeRequestPipeline,
    )

MERGE_LABELS_PRIORITY = [
    prioritized_approval_label(p.value) for p in ChangeTypePriority
] + [
    APPROVED,
    AUTO_MERGE,
    LGTM,
]
HOLD_LABELS = [
    AWAITING_APPROVAL,
    BLOCKED_BOT_ACCESS,
    CHANGES_REQUESTED,
    HOLD,
    DO_NOT_MERGE_HOLD,
    DO_NOT_MERGE_PENDING_REVIEW,
    NEEDS_REBASE,
]

ERROR_LABELS = frozenset({MERGE_ERROR, PIPELINE_ERROR, REBASE_ERROR})

TENANT_LABEL_PREFIX = "tenant-"

QONTRACT_INTEGRATION = "gitlab-housekeeping"
EXPIRATION_DATE_FORMAT = "%Y-%m-%d"
SQUASH_OPTION_ALWAYS = "always"

merged_merge_requests = Counter(
    name="qontract_reconcile_merged_merge_requests",
    documentation="Number of merge requests that have been successfully merged in a repository",
    labelnames=["project_id", "self_service", "auto_merge", "app_sre", "onboarding"],
)

rebased_merge_requests = Counter(
    name="qontract_reconcile_rebased_merge_requests",
    documentation="Number of merge requests that have been successfully rebased in a repository",
    labelnames=["project_id"],
)

time_to_merge = Histogram(
    name="qontract_reconcile_time_to_merge_merge_request_minutes",
    documentation="The number of minutes it takes from when a merge request is mergeable until it is actually merged. This is an indicator of how busy the merge queue is.",
    labelnames=["project_id", "priority"],
    buckets=(5.0, 10.0, 20.0, 40.0, 60.0, float("inf")),
)

merge_requests_waiting = Gauge(
    name="qontract_reconcile_merge_requests_waiting",
    documentation="Number of merge requests that are in the queue waiting to be merged.",
    labelnames=["project_id"],
)

gitlab_token_expiration = Gauge(
    name="qontract_reconcile_gitlab_token_expiration_days",
    documentation="Time until personal access tokens expire",
    labelnames=["name"],
)

merge_requests_error = Gauge(
    name="qontract_reconcile_merge_requests_error",
    documentation="Number of merge requests stuck in an error state.",
    labelnames=["project_id"],
)

optimistic_merges = Counter(
    name="qontract_reconcile_optimistic_merges_total",
    documentation="MRs merged via the optimistic non-overlapping path",
    labelnames=["project_id"],
)

optimistic_merge_rejected = Counter(
    name="qontract_reconcile_optimistic_merge_rejected_total",
    documentation="MRs skipped during optimistic merge attempt",
    labelnames=["project_id", "reason"],
)

merge_batch_size_histogram = Histogram(
    name="qontract_reconcile_merge_batch_size",
    documentation="Number of MRs merged per loop iteration",
    labelnames=["project_id"],
    buckets=(1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 8.0, 10.0, float("inf")),
)


class RebaseStrategy(StrEnum):
    ACTIVE_CAP = "active-cap"
    ACTIVE_CAP_MULTI_MERGE = "active-cap-multi-merge"
    OLD_BURST = "old-burst"


REBASE_STRATEGY_TOGGLE = "gitlab-housekeeping-rebase-strategy"
DEFAULT_REBASE_STRATEGY = RebaseStrategy.OLD_BURST


def get_rebase_strategy() -> RebaseStrategy:
    """Resolve the rebase strategy from an Unleash feature variant."""
    value = get_feature_variant(
        REBASE_STRATEGY_TOGGLE, default_variant=DEFAULT_REBASE_STRATEGY.value
    )
    try:
        return RebaseStrategy(value)
    except ValueError:
        logging.warning(
            f"Unknown rebase strategy variant '{value}', "
            f"falling back to {DEFAULT_REBASE_STRATEGY.value}"
        )
        return DEFAULT_REBASE_STRATEGY


class InsistOnPipelineError(Exception):
    """Exception used to retry a merge when the pipeline isn't yet complete."""


@dataclass
class ReloadToggle:
    """A class to toggle the reload of merge requests."""

    reload: bool = False


def get_tenant_labels(mr: ProjectMergeRequest) -> set[str]:
    """Return the subset of MR labels that start with ``tenant-``.

    Tenant labels identify the namespace an MR touches and are used by
    the optimistic multi-merge (OMM) logic to determine overlap: two MRs
    sharing a tenant label cannot be merged concurrently.
    """
    return {label for label in mr.labels if label.startswith(TENANT_LABEL_PREFIX)}


def is_eligible_for_optimistic_merge(mr: ProjectMergeRequest) -> bool:
    """Return True if the MR carries at least one tenant label.

    Only MRs with tenant labels can participate in OMM groups because the
    non-overlap guarantee depends on label-based scope tracking.  MRs
    without tenant labels are conservatively serialised.
    """
    return bool(get_tenant_labels(mr))


def has_overlapping_labels(mr_labels: set[str], merged_labels: set[str]) -> bool:
    """Return True if any tenant label appears in both sets.

    Used during OMM group formation to ensure that a candidate MR does
    not touch any namespace that has already been merged or is pending
    in the current group.
    """
    return bool(mr_labels & merged_labels)


def _log_exception(ex: Exception) -> None:
    logging.info("Retrying - %s: %s", type(ex).__name__, ex)


def _calculate_time_since_approval(approved_at: str) -> float:
    """
    Returns the number of minutes since a MR has been approved.
    :param approved_at: the datetime the MR was approved in format %Y-%m-%dT%H:%M:%S.%fZ
    """
    time_since_approval = utc_now() - from_utc_iso_format(approved_at)
    return time_since_approval.total_seconds() / 60


def _get_approval_info(
    gl: GitLabApi, mr: ProjectMergeRequest
) -> tuple[str, str] | None:
    """Return (priority, approved_at) for a single MR by scanning label events.

    Returns None if no approval label is found.

    Unlike the approval scan in ``preprocess_merge_requests``, this does
    NOT enforce ``users_allowed_to_label`` — any label-add event counts.
    This is intentional: OMM-merged MRs already passed authorization
    during preprocessing in the loop that formed the group, so
    re-checking here would only add API calls for no safety benefit.
    The trade-off is that ``approved_at`` may differ slightly from what
    preprocessing would compute if an unauthorized user re-added a label
    after group formation, but the metric impact is negligible.
    """
    label_events = gl.get_merge_request_label_events(mr)
    labels = set(mr.labels)
    for label in reversed(label_events):
        if label.action != "add" or not label.label:
            continue
        label_name = label.label["name"]
        if label_name in MERGE_LABELS_PRIORITY:
            label_priority = min(
                MERGE_LABELS_PRIORITY.index(merge_label)
                for merge_label in MERGE_LABELS_PRIORITY
                if merge_label in labels
            )
            priority = f"{label_priority} - {MERGE_LABELS_PRIORITY[label_priority]}"
            return priority, label.created_at
    return None


def get_timed_out_pipelines(
    pipelines: list[ProjectMergeRequestPipeline],
    pipeline_timeout: int = 60,
) -> list[ProjectMergeRequestPipeline]:
    now = utc_now()

    pending_pipelines = [
        p
        for p in pipelines
        if p.status in {PipelineStatus.PENDING, PipelineStatus.RUNNING}
    ]

    if not pending_pipelines:
        return []

    timed_out_pipelines = []

    for p in pending_pipelines:
        update_time = from_utc_iso_format(p.updated_at)

        elapsed = (now - update_time).total_seconds()

        # pipeline_timeout converted in seconds
        if elapsed > pipeline_timeout * 60:
            timed_out_pipelines.append(p)

    return timed_out_pipelines


def clean_pipelines(
    dry_run: bool,
    gl: GitLabApi,
    fork_project_id: int,
    pipelines: list[ProjectMergeRequestPipeline],
) -> None:
    if not dry_run:
        gl_piplelines = gl.get_project_by_id(fork_project_id).pipelines

    for p in pipelines:
        logging.info(["canceling", p.web_url])
        if not dry_run:
            try:
                gl_piplelines.get(p.id, lazy=True).cancel()
            except gitlab.exceptions.GitlabPipelineCancelError as err:
                logging.error(
                    f"unable to cancel {p.web_url} - error message {err.error_message}"
                )


PIPELINE_FAILURE_STATUSES = {PipelineStatus.FAILED}


def check_pipeline_health(
    pipelines: list[ProjectMergeRequestPipeline],
    consecutive_failure_limit: int = 3,
) -> bool:
    """Return True if MR is healthy (should stay in queue).

    Return False if last `consecutive_failure_limit` pipelines all
    ended in a non-success terminal state (FAILED).
    """
    pipeline_failure_window = pipelines[:consecutive_failure_limit]
    if len(pipeline_failure_window) < consecutive_failure_limit:
        return True
    return not all(
        p.status in PIPELINE_FAILURE_STATUSES for p in pipeline_failure_window
    )


def verify_on_demand_tests(
    dry_run: bool,
    mr: ProjectMergeRequest,
    must_pass: Iterable[str],
    gl: GitLabApi,
    state: State,
) -> bool:
    """
    Check if MR has passed all necessary test jobs and add comments to indicate test results.
    """
    pipelines = gl.get_merge_request_pipelines(mr)
    running_pipelines = [p for p in pipelines if p.status == PipelineStatus.RUNNING]
    if running_pipelines:
        # wait for pipelines completion
        return False

    commit = next(mr.commits())
    fork_project = gl.get_project_by_id(mr.source_project_id)
    statuses = fork_project.commits.get(commit.id).statuses.list()
    test_state = {s.name: s.status for s in statuses}
    remaining_tests = [t for t in must_pass if test_state.get(t) != "success"]
    state_key = f"{gl.project.path_with_namespace}/{mr.iid}/{commit.id}"
    # only add comment when state changes
    state_change = state.get(state_key, None) != remaining_tests

    if remaining_tests:
        logging.info([
            "on-demand tests",
            "add comment",
            gl.project.name,
            mr.iid,
            commit.id,
        ])
        if not dry_run and state_change:
            markdown_report = (
                f"On-demand Tests: \n\n For latest [commit]({commit.web_url}) You will need to pass following test jobs to get this MR merged.\n\n"
                f"Add a comment with `/test [test_name]` to trigger a test; multiple tests can be triggered from the same comment: repeat the `/test [test_name]` command separated by lines.\n\n"
            )
            markdown_report += f"* {', '.join(remaining_tests)}\n\n"
            markdown_report += "An update of the MR will reset the on-demand tests. Consider running them once the MR is REVIEWED and no more code changes are required.\n\n"
            gl.delete_merge_request_comments(mr, startswith="On-demand Tests:")
            gl.add_comment_to_merge_request(mr, markdown_report)
            state.add(state_key, remaining_tests, force=True)
        return False
    else:
        # no remain_tests, pass the check
        logging.info([
            "on-demand tests",
            "check pass",
            gl.project.name,
            mr.iid,
            commit.id,
        ])
        if not dry_run and state_change:
            markdown_report = f"On-demand Tests: \n\n All necessary tests have passed for latest [commit]({commit.web_url})\n"
            gl.delete_merge_request_comments(mr, startswith="On-demand Tests:")
            gl.add_comment_to_merge_request(mr, markdown_report)
            state.add(state_key, remaining_tests, force=True)
        return True


def close_item(
    dry_run: bool,
    gl: GitLabApi,
    enable_closing: bool,
    item_type: str,
    item: ProjectIssue | ProjectMergeRequest,
) -> None:
    if enable_closing:
        logging.info([
            "close_item",
            gl.project.name,
            item_type,
            item.attributes.get("iid"),
        ])
        if not dry_run:
            gl.close(item)
    else:
        logging.debug([
            "'enable_closing' is not enabled to close item",
            gl.project.name,
            item_type,
            item.attributes.get("iid"),
        ])


def handle_stale_items(
    dry_run: bool,
    gl: GitLabApi,
    days_interval: int,
    enable_closing: bool,
    items: Iterable[ProjectIssue | ProjectMergeRequest],
    item_type: str,
) -> None:
    LABEL = "stale"  # ruff: ignore[non-lowercase-variable-in-function]

    now = utc_now()
    for item in items:
        if AUTO_MERGE in item.labels:
            if item.merge_status == MRStatus.UNCHECKED:
                # this call triggers a status recheck
                item = gl.get_merge_request(item.iid)
            if item.merge_status == MRStatus.CANNOT_BE_MERGED:
                close_item(dry_run, gl, enable_closing, item_type, item)
        update_date = from_utc_iso_format(item.updated_at)

        # if item is over days_interval
        current_interval = now.date() - update_date.date()
        if current_interval > timedelta(days=days_interval):
            # if item does not have 'stale' label - add it
            if LABEL not in item.labels:
                logging.info(["add_label", gl.project.name, item_type, item.iid, LABEL])
                if not dry_run:
                    gl.add_label_with_note(item, LABEL)
            # if item has 'stale' label - close it
            else:
                close_item(dry_run, gl, enable_closing, item_type, item)
        # if item is under days_interval
        else:
            if LABEL not in item.labels:
                continue

            # if item has 'stale' label - check the notes
            # TODO: add request count metrics and maybe server side filter to reduce requests
            cancel_notes = [
                n
                for n in item.notes.list(iterator=True)
                if n.attributes.get("body") == f"/{LABEL} cancel"
            ]
            if not cancel_notes:
                continue

            latest_cancel_note_date = max(
                from_utc_iso_format(note.updated_at) for note in cancel_notes
            )
            # if the latest cancel note is under
            # days_interval - remove 'stale' label
            current_interval = now.date() - latest_cancel_note_date.date()
            if current_interval <= timedelta(days=days_interval):
                logging.info([
                    "remove_label",
                    gl.project.name,
                    item_type,
                    item.iid,
                    LABEL,
                ])
                if not dry_run:
                    gl.remove_label(item, LABEL)


def is_good_to_merge(labels: Iterable[str]) -> bool:
    return any(m in MERGE_LABELS_PRIORITY for m in labels) and not any(
        b in HOLD_LABELS for b in labels
    )


def is_rebased(mr: ProjectMergeRequest, gl: GitLabApi) -> bool:
    target_branch = mr.target_branch
    head = cast(
        "list[ProjectCommit]",
        gl.project.commits.list(
            ref_name=target_branch,
            per_page=1,
            page=1,
        ),
    )[0].id
    result = cast("dict", gl.project.repository_compare(mr.sha, head))
    return len(result["commits"]) == 0


def get_merge_requests(
    dry_run: bool,
    gl: GitLabApi,
    state: State,
    users_allowed_to_label: Iterable[str] | None = None,
) -> list[dict[str, Any]]:
    mrs = gl.get_merge_requests(state=MRState.OPENED)
    return preprocess_merge_requests(
        dry_run=dry_run,
        gl=gl,
        project_merge_requests=mrs,
        state=state,
        users_allowed_to_label=users_allowed_to_label,
    )


def preprocess_merge_requests(
    dry_run: bool,
    gl: GitLabApi,
    project_merge_requests: list[ProjectMergeRequest],
    state: State,
    users_allowed_to_label: Iterable[str] | None = None,
    must_pass: Iterable[str] | None = None,
) -> list[dict[str, Any]]:
    results = []
    for mr in project_merge_requests:
        if mr.merge_status in {
            MRStatus.CANNOT_BE_MERGED,
            MRStatus.CANNOT_BE_MERGED_RECHECK,
        }:
            continue
        if mr.draft:
            continue
        if len(mr.commits()) == 0:
            continue

        if must_pass and not verify_on_demand_tests(
            dry_run=dry_run,
            mr=mr,
            must_pass=must_pass,
            gl=gl,
            state=state,
        ):
            continue

        labels = set(mr.labels)
        if not labels:
            continue

        if (
            SAAS_FILE_UPDATE in labels or SELF_SERVICEABLE in labels
        ) and LGTM in labels:
            logging.warning(
                f"[{gl.project.name}/{mr.iid}] 'lgtm' label not "
                + "suitable for self serviceable MRs. removing 'lgtm' label"
            )
            if not dry_run:
                gl.remove_label(mr, LGTM)
            continue

        label_events = gl.get_merge_request_label_events(mr)
        approval_found = False
        labels_by_unauthorized_users = set()
        labels_by_authorized_users = set()
        for label in reversed(label_events):
            if label.action == "add":
                if not label.label:
                    # label doesn't exist anymore, may be remove later
                    continue
                label_name = label.label["name"]
                added_by = label.user["username"]
                if users_allowed_to_label and added_by not in (
                    set(users_allowed_to_label) | {gl.user.username}
                ):
                    # label added by an unauthorized user. remove it maybe later
                    labels_by_unauthorized_users.add(label_name)
                    continue

                # label added by an authorized user, so don't delete it
                labels_by_authorized_users.add(label_name)

                if label_name in MERGE_LABELS_PRIORITY and not approval_found:
                    approval_found = True
                    approved_at = label.created_at
                    approved_by = added_by

        bad_labels = (
            labels_by_unauthorized_users - labels_by_authorized_users
        ) & labels
        for bad_label in bad_labels:
            logging.warning(
                f"[{gl.project.name}/{mr.iid}] someone added a label who "
                f"isn't allowed. removing label {bad_label}"
            )
        if bad_labels and not dry_run:
            gl.remove_labels(mr, bad_labels)

        labels = set(mr.labels)
        if not is_good_to_merge(labels):
            continue

        label_priority = min(
            MERGE_LABELS_PRIORITY.index(merge_label)
            for merge_label in MERGE_LABELS_PRIORITY
            if merge_label in labels
        )

        item = {
            "mr": mr,
            "label_priority": label_priority,
            "priority": f"{label_priority} - {MERGE_LABELS_PRIORITY[label_priority]}",
            "approved_at": approved_at,
            "approved_by": approved_by,
            "error": any(label in ERROR_LABELS for label in labels),
        }
        results.append(item)

    results.sort(key=itemgetter("label_priority", "approved_at"))

    return results


def rebase_merge_requests(
    dry_run: bool,
    gl: GitLabApi,
    rebase_limit: int,
    state: State,
    pipeline_timeout: int | None = None,
    wait_for_pipeline: bool = False,
    users_allowed_to_label: Iterable[str] | None = None,
    strategy: RebaseStrategy = DEFAULT_REBASE_STRATEGY,
) -> None:
    dispatch = {
        RebaseStrategy.ACTIVE_CAP: _rebase_merge_requests_active_cap,
        RebaseStrategy.ACTIVE_CAP_MULTI_MERGE: _rebase_merge_requests_active_cap,
        RebaseStrategy.OLD_BURST: _rebase_merge_requests_old_burst,
    }

    fn = dispatch[strategy]
    fn(
        dry_run=dry_run,
        gl=gl,
        rebase_limit=rebase_limit,
        state=state,
        pipeline_timeout=pipeline_timeout,
        wait_for_pipeline=wait_for_pipeline,
        users_allowed_to_label=users_allowed_to_label,
    )


def _cancel_timed_out_pipelines(
    dry_run: bool,
    gl: GitLabApi,
    mr: ProjectMergeRequest,
    pipelines: list,
    pipeline_timeout: int | None,
) -> None:
    """Cancel pipelines that have exceeded the timeout threshold."""
    if pipeline_timeout is None:
        return
    timed_out_pipelines = get_timed_out_pipelines(pipelines, pipeline_timeout)
    if timed_out_pipelines:
        clean_pipelines(
            dry_run=dry_run,
            gl=gl,
            fork_project_id=mr.source_project_id,
            pipelines=timed_out_pipelines,
        )


def _should_skip_for_running_pipeline(pipelines: list, wait_for_pipeline: bool) -> bool:
    """Return True if the MR should be skipped because a pipeline is still running."""
    if not wait_for_pipeline:
        return False
    if not pipelines:
        return True
    return any(p.status == PipelineStatus.RUNNING for p in pipelines)


def _try_rebase(
    dry_run: bool,
    gl: GitLabApi,
    mr: ProjectMergeRequest,
) -> bool:
    """Attempt to rebase an MR. Returns True on success, False on failure."""
    try:
        logging.info(["rebase", gl.project.name, mr.iid])
        if not dry_run:
            mr.rebase()
            rebased_merge_requests.labels(mr.target_project_id).inc()
        return True
    except gitlab.exceptions.GitlabMRRebaseError as e:
        logging.error(f"unable to rebase {mr.iid}: {e}")
        return False


OMM_MAX_INTERVAL_TOGGLE = "gitlab-housekeeping-omm-max-interval"
DEFAULT_OMM_MAX_INTERVAL_MINUTES = 5


def get_omm_max_interval() -> timedelta:
    """Resolve the OMM group window duration from Unleash."""
    value = get_feature_variant(
        OMM_MAX_INTERVAL_TOGGLE,
        default_variant=str(DEFAULT_OMM_MAX_INTERVAL_MINUTES),
    )
    try:
        return timedelta(minutes=int(value))
    except ValueError, TypeError:
        logging.warning(
            f"Invalid omm-max-interval variant '{value}', "
            f"falling back to {DEFAULT_OMM_MAX_INTERVAL_MINUTES}m"
        )
        return timedelta(minutes=DEFAULT_OMM_MAX_INTERVAL_MINUTES)


def get_omm_group_lead(gl: GitLabApi) -> ProjectMergeRequest | None:
    """Find the active group lead — a recently merged MR with the omm-group-lead label."""
    mrs = gl.project.mergerequests.list(
        state=MRState.MERGED,
        labels=[OMM_GROUP_LEAD],
        order_by="updated_at",
        sort="desc",
        per_page=1,
        get_all=False,
    )
    return mrs[0] if mrs else None


def get_omm_pending_mrs(gl: GitLabApi) -> list[ProjectMergeRequest]:
    """Return all open MRs with the omm-pending label."""
    return gl.project.mergerequests.list(
        state=MRState.OPENED,
        labels=[OMM_PENDING],
        get_all=True,
    )


def apply_omm_pending(
    dry_run: bool,
    gl: GitLabApi,
    mrs: list[ProjectMergeRequest],
) -> None:
    """Apply omm-pending label and kick rebases for group candidates."""
    for mr in mrs:
        logging.info(["omm-group", "add-pending", gl.project.name, mr.iid])
        if not dry_run:
            gl.add_label_to_merge_request(mr, OMM_PENDING)
            try:
                logging.info([
                    "omm-group",
                    "skip-ci-rebase-at-formation",
                    gl.project.name,
                    mr.iid,
                ])
                mr.rebase(skip_ci=True)
            except gitlab.exceptions.GitlabMRRebaseError:
                logging.warning([
                    "omm-group",
                    "rebase-failed-at-formation",
                    gl.project.name,
                    mr.iid,
                ])
                gl.remove_label(mr, OMM_PENDING)
                gl.add_label_to_merge_request(mr, REBASE_ERROR)
                optimistic_merge_rejected.labels(
                    project_id=mr.target_project_id,
                    reason="rebase_failed",
                ).inc()


def apply_omm_group_lead(
    dry_run: bool,
    gl: GitLabApi,
    mr: ProjectMergeRequest,
) -> None:
    """Tag a just-merged MR as the group lead."""
    logging.info(["omm-group", "set-lead", gl.project.name, mr.iid])
    if not dry_run:
        gl.add_label_to_merge_request(mr, OMM_GROUP_LEAD)


def clear_omm_group(
    dry_run: bool,
    gl: GitLabApi,
    lead: ProjectMergeRequest | None = None,
    pending: list[ProjectMergeRequest] | None = None,
) -> None:
    """Remove all OMM labels — close the group.

    Also cleans up stale omm-pending labels on MRs that were closed,
    merged externally, or otherwise left the OPENED state while the
    group was active.

    Accepts optional pre-fetched ``lead`` and ``pending`` to avoid
    redundant API calls when the caller already has them.
    """
    if lead is None:
        lead = get_omm_group_lead(gl)
    if lead:
        logging.info(["omm-group", "clear-lead", gl.project.name, lead.iid])
        if not dry_run:
            gl.remove_label(lead, OMM_GROUP_LEAD)

    if pending is None:
        pending = get_omm_pending_mrs(gl)
    for mr in pending:
        logging.info(["omm-group", "clear-pending", gl.project.name, mr.iid])
        if not dry_run:
            gl.remove_label(mr, OMM_PENDING)

    for state in (MRState.CLOSED, MRState.MERGED):
        stale = gl.project.mergerequests.list(
            state=state,
            labels=[OMM_PENDING],
            get_all=True,
        )
        for mr in stale:
            logging.info(["omm-group", "clear-stale", gl.project.name, mr.iid])
            if not dry_run:
                gl.remove_label(mr, OMM_PENDING)


def _form_omm_group(
    gl: GitLabApi,
    merge_requests: list[dict[str, Any]],
    merged_labels: set[str],
) -> list[ProjectMergeRequest]:
    """Select non-overlapping candidates from the queue for the OMM group.

    Only MRs that are eligible (have tenant labels), don't overlap with
    already-merged labels, and have an active pipeline are considered.

    Note: this makes one get_merge_request_pipelines API call per candidate,
    proportional to queue length. Acceptable because it runs at most once per
    reconcile loop (after the first merge).
    """
    candidates: list[ProjectMergeRequest] = []
    group_labels = set(merged_labels)

    for merge_request in merge_requests:
        mr: ProjectMergeRequest = merge_request["mr"]
        if merge_request["error"]:
            continue
        if not is_eligible_for_optimistic_merge(mr):
            continue
        mr_labels = get_tenant_labels(mr)
        if has_overlapping_labels(mr_labels, group_labels):
            continue
        pipelines = gl.get_merge_request_pipelines(mr)
        pipelines = [p for p in pipelines if p.status != PipelineStatus.SKIPPED]
        if not pipelines:
            continue
        if pipelines[0].status not in {
            PipelineStatus.RUNNING,
            PipelineStatus.PENDING,
            PipelineStatus.SUCCESS,
        }:
            continue
        candidates.append(mr)
        group_labels.update(mr_labels)

    return candidates


def _is_omm_window_open(lead: ProjectMergeRequest, max_interval: timedelta) -> bool:
    """Check if the OMM group window is still open based on lead's merged_at."""
    merged_at = from_utc_iso_format(lead.merged_at)
    return utc_now() - merged_at < max_interval


def _check_post_merge_ci(gl: GitLabApi, lead: ProjectMergeRequest) -> bool:
    """Return True if post-merge CI is healthy (not failed).

    Only considers pipelines created after the lead was merged so that
    a stale pre-merge failure doesn't cancel a new OMM group.
    """
    merged_at = from_utc_iso_format(lead.merged_at)
    pipelines = gl.project.pipelines.list(
        ref=lead.target_branch,
        order_by="id",
        sort="desc",
        per_page=1,
        get_all=False,
    )
    for pipeline in pipelines:
        if from_utc_iso_format(pipeline.created_at) < merged_at:
            break
        return pipeline.status != PipelineStatus.FAILED
    return True


def _rebase_merge_requests_active_cap(
    dry_run: bool,
    gl: GitLabApi,
    rebase_limit: int,
    state: State,
    pipeline_timeout: int | None = None,
    wait_for_pipeline: bool = False,
    users_allowed_to_label: Iterable[str] | None = None,
) -> None:
    """Active-cap strategy: scan the full queue, count MRs with active
    pipelines, and only rebase up to (rebase_limit - already_active)
    additional MRs.  This treats rebase_limit as a per-repo concurrency cap
    on in-flight pipelines rather than a visibility window."""
    merge_requests = [
        item["mr"]
        for item in get_merge_requests(
            dry_run=dry_run,
            gl=gl,
            state=state,
            users_allowed_to_label=users_allowed_to_label,
        )
        if not item["error"]
    ]

    # Single pass: classify MRs as already-active or needs-rebase.
    # rebase_limit is a per-repo concurrency cap -- "at most N MRs with
    # active pipelines" -- not a per-run burst.
    # Rebased MRs count as active with running/pending/success pipelines
    # (success = green and waiting to merge, still occupying a slot).
    already_active = 0
    needs_rebase: list[ProjectMergeRequest] = []
    for mr in merge_requests:
        pipelines = gl.get_merge_request_pipelines(mr)
        pipelines = [p for p in pipelines if p.status != PipelineStatus.SKIPPED]
        fresh_mr = gl.get_merge_request(mr.iid)
        if is_rebased(fresh_mr, gl):
            if pipelines and pipelines[0].status in {
                PipelineStatus.RUNNING,
                PipelineStatus.PENDING,
                PipelineStatus.SUCCESS,
            }:
                already_active += 1
            continue

        # OMM pending MRs are managed by _process_omm_group which uses
        # skip-ci rebases. Don't re-rebase them here with CI enabled.
        if OMM_PENDING in mr.labels:
            logging.debug(["rebase", gl.project.name, mr.iid, "skip-omm-pending"])
            continue

        _cancel_timed_out_pipelines(dry_run, gl, mr, pipelines, pipeline_timeout)

        if _should_skip_for_running_pipeline(pipelines, wait_for_pipeline):
            continue

        needs_rebase.append(mr)

    remaining_budget = max(rebase_limit - already_active, 0)
    rebases = 0
    for mr in needs_rebase:
        if rebases < remaining_budget:
            if _try_rebase(dry_run, gl, mr):
                rebases += 1
        else:
            logging.info([
                "rebase",
                gl.project.name,
                mr.iid,
                f"rebase limit reached ({already_active + rebases} active/in-flight, limit {rebase_limit}). will try next time",
            ])
            break


def _rebase_merge_requests_old_burst(
    dry_run: bool,
    gl: GitLabApi,
    rebase_limit: int,
    state: State,
    pipeline_timeout: int | None = None,
    wait_for_pipeline: bool = False,
    users_allowed_to_label: Iterable[str] | None = None,
) -> None:
    """Old-burst strategy: scan the full queue and rebase up to rebase_limit
    MRs that are not already rebased.  This is a simple per-run burst
    counter — it does not consider active pipelines."""
    rebases = 0
    merge_requests = [
        item["mr"]
        for item in get_merge_requests(
            dry_run=dry_run,
            gl=gl,
            state=state,
            users_allowed_to_label=users_allowed_to_label,
        )
        if not item["error"]
    ]
    for mr in merge_requests:
        fresh_mr = gl.get_merge_request(mr.iid)
        if is_rebased(fresh_mr, gl):
            continue

        pipelines = gl.get_merge_request_pipelines(mr)
        _cancel_timed_out_pipelines(dry_run, gl, mr, pipelines, pipeline_timeout)

        if _should_skip_for_running_pipeline(pipelines, wait_for_pipeline):
            continue

        if rebases < rebase_limit:
            if _try_rebase(dry_run, gl, mr):
                rebases += 1
        else:
            logging.info([
                "rebase",
                gl.project.name,
                mr.iid,
                "rebase limit reached for this reconcile loop. will try next time",
            ])


# TODO: this retry is catching all exceptions, which isn't good. _log_exceptions is
# being added so we can track whether it's catching anything other than what appears to
# be the intended case of retrying with "insist". Once we have some additional data,
# we can change this to retry on a small set of exceptions including
# InsistOnPipelineException.


@dataclass
class _MemberResult:
    merged: bool = False
    active: bool = False


def _process_omm_member(
    dry_run: bool,
    gl: GitLabApi,
    mr: ProjectMergeRequest,
    app_sre_usernames: AbstractSet[str],
    pipeline_timeout: int | None,
) -> _MemberResult:
    """Process a single OMM pending member. Returns merge/active state."""
    error_labels = ERROR_LABELS.intersection(mr.labels)
    if error_labels:
        logging.info([
            "omm-group",
            "eject-error-label",
            gl.project.name,
            mr.iid,
            sorted(error_labels),
        ])
        if not dry_run:
            gl.remove_label(mr, OMM_PENDING)
        optimistic_merge_rejected.labels(
            project_id=mr.target_project_id,
            reason="error_label",
        ).inc()
        return _MemberResult()

    hold_labels = set(HOLD_LABELS).intersection(mr.labels)
    if hold_labels:
        logging.info([
            "omm-group",
            "eject-hold-label",
            gl.project.name,
            mr.iid,
            sorted(hold_labels),
        ])
        if not dry_run:
            gl.remove_label(mr, OMM_PENDING)
        optimistic_merge_rejected.labels(
            project_id=mr.target_project_id,
            reason="hold_label",
        ).inc()
        return _MemberResult()

    pipelines = gl.get_merge_request_pipelines(mr)

    if pipeline_timeout is not None and pipelines:
        timed_out = get_timed_out_pipelines(pipelines, pipeline_timeout)
        if timed_out:
            clean_pipelines(
                dry_run=dry_run,
                gl=gl,
                fork_project_id=mr.source_project_id,
                pipelines=timed_out,
            )

    # Filter pipelines that carry no CI signal:
    # - SKIPPED: placeholder from skip_ci rebase
    # - PUSH: empty 0-job shells from skip_ci rebase (real CI is source=external)
    pipelines = [
        p
        for p in pipelines
        if not (p.status == PipelineStatus.SKIPPED or p.source == "push")
    ]

    fresh_mr = gl.get_merge_request(mr.iid)
    mr_is_rebased = is_rebased(fresh_mr, gl)

    if not pipelines:
        if mr_is_rebased:
            logging.info([
                "omm-group",
                "no-pipelines-rebased",
                gl.project.name,
                mr.iid,
            ])
            return _MemberResult(active=True)
        return _MemberResult()

    latest_status = pipelines[0].status

    if latest_status in {PipelineStatus.FAILED, PipelineStatus.CANCELED}:
        logging.info([
            "omm-group",
            "eject-failed",
            gl.project.name,
            mr.iid,
            latest_status,
        ])
        if not dry_run:
            gl.remove_label(mr, OMM_PENDING)
        optimistic_merge_rejected.labels(
            project_id=mr.target_project_id,
            reason=f"pipeline_{latest_status.value}",
        ).inc()
        return _MemberResult()

    if latest_status in {PipelineStatus.RUNNING, PipelineStatus.PENDING}:
        logging.info([
            "omm-group",
            "waiting-pipeline",
            gl.project.name,
            mr.iid,
            latest_status,
            "rebased" if mr_is_rebased else "not-rebased",
        ])
        return _MemberResult(active=True)

    if latest_status != PipelineStatus.SUCCESS:
        logging.info([
            "omm-group",
            "unhandled-status",
            gl.project.name,
            mr.iid,
            latest_status,
            "rebased" if mr_is_rebased else "not-rebased",
        ])
        return _MemberResult(active=mr_is_rebased)

    # --- SUCCESS: the only path that differs on rebased state ---
    if mr_is_rebased:
        logging.info(["omm-group", "merge", gl.project.name, mr.iid])
        if not dry_run:
            try:
                squash = (gl.project.squash_option == SQUASH_OPTION_ALWAYS) or mr.squash
                mr.merge(squash=squash)
                labels = mr.labels
                merged_merge_requests.labels(
                    project_id=mr.target_project_id,
                    self_service=SELF_SERVICEABLE in labels,
                    auto_merge=AUTO_MERGE in labels,
                    app_sre=mr.author["username"] in app_sre_usernames,
                    onboarding=ONBOARDING in labels,
                ).inc()
                optimistic_merges.labels(project_id=mr.target_project_id).inc()
                gl.remove_label(mr, OMM_PENDING)
                approval_info = _get_approval_info(gl, mr)
                if approval_info:
                    priority, approved_at = approval_info
                    time_to_merge.labels(
                        project_id=mr.target_project_id, priority=priority
                    ).observe(_calculate_time_since_approval(approved_at))
            except gitlab.exceptions.GitlabMRClosedError as e:
                logging.error(f"unable to merge {mr.iid}: {e}")
                gl.add_label_to_merge_request(mr, MERGE_ERROR)
                gl.remove_label(mr, OMM_PENDING)
                optimistic_merge_rejected.labels(
                    project_id=mr.target_project_id, reason="merge_rejected"
                ).inc()
                return _MemberResult()
        return _MemberResult(merged=True)

    # Not rebased + SUCCESS: skip-ci rebase to bring MR up to date
    logging.info([
        "omm-group",
        "skip-ci-rebase",
        gl.project.name,
        mr.iid,
    ])
    if not dry_run:
        try:
            mr.rebase(skip_ci=True)
        except gitlab.exceptions.GitlabMRRebaseError as e:
            logging.warning([
                "omm-group",
                "skip-ci-rebase-failed",
                gl.project.name,
                mr.iid,
                str(e),
            ])
            gl.remove_label(mr, OMM_PENDING)
            optimistic_merge_rejected.labels(
                project_id=mr.target_project_id,
                reason="skip_ci_rebase_conflict",
            ).inc()
            return _MemberResult()
    return _MemberResult(active=True)


def _process_omm_group(
    dry_run: bool,
    gl: GitLabApi,
    lead: ProjectMergeRequest,
    app_sre_usernames: AbstractSet[str],
    pipeline_timeout: int | None = None,
    merge_limit: int = 8,
) -> int:
    """Process an active OMM group. Returns number of merges performed.

    Single-pass: check window, verify post-merge CI, process each pending
    member (merge if ready, eject if failed). Non-blocking.

    Enforces ``merge_limit`` — when reached the group is cleared so the
    next loop starts fresh with a serial merge and re-evaluation.
    """

    max_interval = get_omm_max_interval()

    if not _is_omm_window_open(lead, max_interval):
        logging.info(["omm-group", "window-expired", gl.project.name])
        clear_omm_group(dry_run, gl, lead=lead)
        return 0

    if not _check_post_merge_ci(gl, lead):
        logging.warning([
            "omm-group",
            "post-merge-ci-failed",
            gl.project.name,
            "cancelling group",
        ])
        clear_omm_group(dry_run, gl, lead=lead)
        return 0

    lead_sha = lead.merge_commit_sha or lead.squash_commit_sha
    if not lead_sha:
        logging.warning([
            "omm-group",
            "lead-missing-sha",
            gl.project.name,
            lead.iid,
            "will retry next loop",
        ])
        return 0

    current_head = gl.project.branches.get(lead.target_branch).commit["id"]
    if current_head != lead_sha:
        # Head moved since the lead merged.  This is expected when pending
        # members merge (each advances the target).  Only invalidate if
        # the lead's commit is no longer reachable — meaning the branch
        # diverged (force push / external reset).
        result = cast(
            "dict",
            gl.project.repository_compare(current_head, lead_sha),
        )
        if len(result["commits"]) > 0:
            logging.warning([
                "omm-group",
                "head-diverged",
                gl.project.name,
                "invalidating",
            ])
            clear_omm_group(dry_run, gl, lead=lead)
            return 0

    pending = get_omm_pending_mrs(gl)
    if not pending:
        logging.info(["omm-group", "no-pending-members", gl.project.name])
        clear_omm_group(dry_run, gl, lead=lead, pending=pending)
        return 0

    merges = 0
    any_active = False

    for mr in pending:
        r = _process_omm_member(dry_run, gl, mr, app_sre_usernames, pipeline_timeout)
        if r.merged:
            merges += 1
            if merges >= merge_limit:
                logging.info([
                    "omm-group",
                    "merge-limit-reached",
                    gl.project.name,
                    f"limit={merge_limit}",
                ])
                clear_omm_group(dry_run, gl, lead=lead, pending=pending)
                return merges
        any_active |= r.active

    if not any_active:
        logging.info(["omm-group", "adaptive-close", gl.project.name])
        clear_omm_group(dry_run, gl, lead=lead)

    return merges


@retry(max_attempts=10, hook=_log_exception)
def merge_merge_requests(
    dry_run: bool,
    gl: GitLabApi,
    project_merge_requests: list[ProjectMergeRequest],
    reload_toggle: ReloadToggle,
    merge_limit: int,
    rebase: bool,
    app_sre_usernames: AbstractSet[str],
    state: State,
    pipeline_timeout: int | None = None,
    insist: bool = False,
    wait_for_pipeline: bool = False,
    users_allowed_to_label: Iterable[str] | None = None,
    must_pass: Iterable[str] | None = None,
    multi_merge: bool = False,
) -> None:
    if reload_toggle.reload:
        project_merge_requests = gl.get_merge_requests(state=MRState.OPENED)
    merge_requests = preprocess_merge_requests(
        dry_run=dry_run,
        gl=gl,
        project_merge_requests=project_merge_requests,
        state=state,
        users_allowed_to_label=users_allowed_to_label,
        must_pass=must_pass,
    )
    merge_requests_waiting.labels(gl.project.id).set(len(merge_requests))
    merge_requests_error.labels(gl.project.id).set(
        sum(1 for item in merge_requests if item["error"])
    )

    # --- OMM group cleanup when feature is disabled ---
    # If the Unleash variant was changed away from active-cap-multi-merge
    # while a group was active, clean up orphaned labels.
    if not multi_merge and rebase:
        lead = get_omm_group_lead(gl)
        if lead:
            logging.info(["omm-group", "feature-disabled-cleanup", gl.project.name])
            clear_omm_group(dry_run, gl, lead=lead)

    # --- Active group path ---
    # Early return: insist/retry semantics do not apply here — the group
    # model is non-blocking and tolerates running pipelines without retrying.
    if multi_merge and rebase:
        lead = get_omm_group_lead(gl)
        if lead:
            merges = _process_omm_group(
                dry_run=dry_run,
                gl=gl,
                lead=lead,
                app_sre_usernames=app_sre_usernames,
                pipeline_timeout=pipeline_timeout,
                merge_limit=merge_limit,
            )
            merge_batch_size_histogram.labels(project_id=gl.project.id).observe(merges)
            return
        # Lead disappeared but pending labels remain — clean up.
        pending = get_omm_pending_mrs(gl)
        if pending:
            logging.warning(["omm-group", "lead-missing-cleanup", gl.project.name])
            clear_omm_group(dry_run, gl, pending=pending)

    # --- No active group: serial merge path ---
    merges = 0
    merged_labels: set[str] = set()

    for merge_request in merge_requests:
        mr: ProjectMergeRequest = merge_request["mr"]

        if merge_request["error"]:
            logging.info(["skip merge", gl.project.name, mr.iid])
            continue

        if rebase and not is_rebased(mr, gl):
            continue

        pipelines = gl.get_merge_request_pipelines(mr)
        if not pipelines:
            continue

        if pipeline_timeout is not None:
            timed_out_pipelines = get_timed_out_pipelines(pipelines, pipeline_timeout)
            if timed_out_pipelines:
                clean_pipelines(
                    dry_run=dry_run,
                    gl=gl,
                    fork_project_id=mr.source_project_id,
                    pipelines=timed_out_pipelines,
                )

        pipelines = [p for p in pipelines if p.status != PipelineStatus.SKIPPED]
        if not pipelines:
            continue

        if wait_for_pipeline:
            running_pipelines = [
                p for p in pipelines if p.status == PipelineStatus.RUNNING
            ]
            if running_pipelines:
                if insist and (merges == 0 or not rebase):
                    reload_toggle.reload = True
                    raise InsistOnPipelineError(
                        f"Pipelines for merge request in project '{gl.project.name}' have not completed yet: {mr.iid}"
                    )
                continue

        last_pipeline_result = pipelines[0].status
        if last_pipeline_result != PipelineStatus.SUCCESS:
            continue

        logging.info(["merge", gl.project.name, mr.iid])
        if merges >= merge_limit:
            continue

        if not dry_run:
            try:
                squash = (gl.project.squash_option == SQUASH_OPTION_ALWAYS) or mr.squash
                mr.merge(squash=squash)
                labels = mr.labels
                merged_merge_requests.labels(
                    project_id=mr.target_project_id,
                    self_service=SELF_SERVICEABLE in labels,
                    auto_merge=AUTO_MERGE in labels,
                    app_sre=mr.author["username"] in app_sre_usernames,
                    onboarding=ONBOARDING in labels,
                ).inc()
                time_to_merge.labels(
                    project_id=mr.target_project_id, priority=merge_request["priority"]
                ).observe(_calculate_time_since_approval(merge_request["approved_at"]))
            except gitlab.exceptions.GitlabMRClosedError as e:
                logging.error(f"unable to merge {mr.iid}: {e}")
                gl.add_label_to_merge_request(mr, MERGE_ERROR)
                continue

        merged_labels.update(get_tenant_labels(mr))
        merges += 1

        if rebase and merges == 1:
            if multi_merge and is_eligible_for_optimistic_merge(mr):
                candidates = _form_omm_group(
                    gl=gl,
                    merge_requests=merge_requests,
                    merged_labels=merged_labels,
                )
                if candidates:
                    apply_omm_group_lead(dry_run, gl, mr)
                    apply_omm_pending(dry_run, gl, candidates)
            elif multi_merge:
                # lead has no tenant labels — fall back to serial merge
                logging.info(["omm-group", "lead-ineligible", gl.project.name, mr.iid])
            break

    merge_batch_size_histogram.labels(project_id=gl.project.id).observe(merges)


def run_error_healthcheck(
    dry_run: bool,
    gl: GitLabApi,
    project_merge_requests: list[ProjectMergeRequest],
    consecutive_failure_limit: int = 3,
) -> None:
    """Check error labels for queue-eligible MRs. Apply/remove
    rebase-error based on merge_error field from .get(),
    pipeline-error based on consecutive failure count, and remove
    merge-error if any new notes have been posted since the label was applied."""
    for mr in project_merge_requests:
        if mr.draft:
            continue

        if mr.merge_status in {
            MRStatus.CANNOT_BE_MERGED,
            MRStatus.CANNOT_BE_MERGED_RECHECK,
        }:
            continue

        if not is_good_to_merge(mr.labels):
            continue

        labels = set(mr.labels)

        has_rebase_error = REBASE_ERROR in labels
        try:
            fresh = gl.get_merge_request(mr.iid)
        except gitlab.exceptions.GitlabGetError as e:
            logging.warning([
                "error-healthcheck",
                "rebase-status-refresh-failed",
                gl.project.name,
                mr.iid,
                str(e),
            ])
            rebase_failed = has_rebase_error
        else:
            fresh_merge_error = getattr(fresh, "merge_error", None)
            rebase_failed = bool(
                fresh_merge_error and "Rebase failed" in fresh_merge_error
            )

        if rebase_failed and not has_rebase_error:
            logging.warning([
                "add_label",
                REBASE_ERROR,
                gl.project.name,
                mr.iid,
                fresh_merge_error,
            ])
            if not dry_run:
                gl.add_label_to_merge_request(mr, REBASE_ERROR)
            continue
        elif not rebase_failed and has_rebase_error:
            logging.info([
                "remove_label",
                REBASE_ERROR,
                gl.project.name,
                mr.iid,
            ])
            if not dry_run:
                gl.remove_label(mr, REBASE_ERROR)

        pipelines = gl.get_merge_request_pipelines(mr)
        if not pipelines:
            continue

        terminal_pipelines = [
            p
            for p in pipelines
            if p.status
            in {
                PipelineStatus.SUCCESS,
                PipelineStatus.FAILED,
                PipelineStatus.CANCELED,
                PipelineStatus.SKIPPED,
            }
        ]
        if not terminal_pipelines:
            continue

        has_pipeline_error = PIPELINE_ERROR in labels
        is_healthy = check_pipeline_health(
            terminal_pipelines, consecutive_failure_limit
        )

        if not is_healthy and not has_pipeline_error:
            logging.warning([
                "add_label",
                PIPELINE_ERROR,
                gl.project.name,
                mr.iid,
            ])
            if not dry_run:
                gl.add_label_to_merge_request(mr, PIPELINE_ERROR)
        elif is_healthy and has_pipeline_error:
            logging.info([
                "remove_label",
                PIPELINE_ERROR,
                gl.project.name,
                mr.iid,
            ])
            if not dry_run:
                gl.remove_label(mr, PIPELINE_ERROR)

        if MERGE_ERROR in labels:
            label_events = gl.get_merge_request_label_events(mr)
            merge_error_added_at = None
            for event in reversed(label_events):
                if (
                    event.action == "add"
                    and event.label
                    and event.label["name"] == MERGE_ERROR
                ):
                    merge_error_added_at = event.created_at
                    break

            if merge_error_added_at:
                latest_notes = mr.notes.list(
                    order_by="created_at", sort="desc", per_page=1
                )
                if any(
                    from_utc_iso_format(note.created_at)
                    > from_utc_iso_format(merge_error_added_at)
                    for note in latest_notes
                ):
                    logging.info([
                        "remove_label",
                        MERGE_ERROR,
                        gl.project.name,
                        mr.iid,
                        "new notes after merge-error label",
                    ])
                    if not dry_run:
                        gl.remove_label(mr, MERGE_ERROR)


def get_app_sre_usernames(gl: GitLabApi) -> set[str]:
    return {u.username for u in gl.get_app_sre_group_users()}


def publish_access_token_expiration_metrics(gl: GitLabApi) -> None:
    pats = gl.get_personal_access_tokens()

    for pat in pats:
        if pat.active:
            expiration_date = ensure_utc(
                datetime.strptime(pat.expires_at, EXPIRATION_DATE_FORMAT)  # ruff: ignore[call-datetime-strptime-without-zone]
            )
            days_until_expiration = expiration_date.date() - utc_now().date()
            gitlab_token_expiration.labels(pat.name).set(days_until_expiration.days)
        else:
            with suppress(KeyError, ValueError):
                # there's no publicly exposed method to determine if a label exists for a gauge
                # which is why I wrapped the error like this
                gitlab_token_expiration.remove(pat.name)


def run(dry_run: bool, wait_for_pipeline: bool) -> None:
    default_days_interval = 15
    default_rebase_limit = 8
    default_consecutive_failure_limit = 3
    default_enable_closing = False
    instance = queries.get_gitlab_instance()
    settings = queries.get_app_interface_settings()
    with GitLabApi(instance, settings=settings) as gl:
        publish_access_token_expiration_metrics(gl)
    repos = queries.get_repos_gitlab_housekeeping(server=instance["url"])
    repos = [r for r in repos if is_in_shard(r["url"])]
    app_sre_usernames: set[str] = set()
    rebase_strategy = get_rebase_strategy()
    state = init_state(QONTRACT_INTEGRATION)

    for repo in repos:
        hk = repo["housekeeping"]
        project_url = repo["url"]
        days_interval = hk.get("days_interval") or default_days_interval
        enable_closing = hk.get("enable_closing") or default_enable_closing
        rebase_limit = hk.get("rebase_limit") or default_rebase_limit
        merge_limit = hk.get("merge_limit") or rebase_limit
        consecutive_failure_limit = (
            hk.get("consecutive_failure_limit") or default_consecutive_failure_limit
        )
        pipeline_timeout = hk.get("pipeline_timeout")
        multi_merge = (
            rebase_strategy == RebaseStrategy.ACTIVE_CAP_MULTI_MERGE
            and hk.get("multi_merge", False)
        )
        labels_allowed = hk.get("labels_allowed")
        users_allowed_to_label = (
            None
            if not labels_allowed
            else {
                u["org_username"] for la in labels_allowed for u in la["role"]["users"]
            }
        )
        with GitLabApi(instance, project_url=project_url, settings=settings) as gl:
            if not app_sre_usernames:
                app_sre_usernames = get_app_sre_usernames(gl)
            issues = gl.get_issues(state=MRState.OPENED)
            handle_stale_items(
                dry_run,
                gl,
                days_interval,
                enable_closing,
                issues,
                "issue",
            )
            opened_merge_requests = gl.get_merge_requests(state=MRState.OPENED)
            handle_stale_items(
                dry_run,
                gl,
                days_interval,
                enable_closing,
                opened_merge_requests,
                "merge-request",
            )
            project_merge_requests = [
                mr for mr in opened_merge_requests if mr.state == MRState.OPENED
            ]
            try:
                run_error_healthcheck(
                    dry_run=dry_run,
                    gl=gl,
                    project_merge_requests=project_merge_requests,
                    consecutive_failure_limit=consecutive_failure_limit,
                )
            except Exception:
                logging.exception(
                    "error healthcheck failed, continuing with merge/rebase"
                )
            reload_toggle = ReloadToggle(reload=False)
            rebase = hk.get("rebase")
            must_pass = hk.get("must_pass")
            try:
                merge_merge_requests(
                    dry_run=dry_run,
                    gl=gl,
                    project_merge_requests=project_merge_requests,
                    reload_toggle=reload_toggle,
                    merge_limit=merge_limit,
                    rebase=rebase,
                    app_sre_usernames=app_sre_usernames,
                    state=state,
                    pipeline_timeout=pipeline_timeout,
                    insist=True,
                    wait_for_pipeline=wait_for_pipeline,
                    users_allowed_to_label=users_allowed_to_label,
                    must_pass=must_pass,
                    multi_merge=multi_merge,
                )
            except Exception:
                logging.error(
                    "All retries failed, trying to rerun merge_merge_requests() again."
                )
                merge_merge_requests(
                    dry_run=dry_run,
                    gl=gl,
                    project_merge_requests=project_merge_requests,
                    reload_toggle=reload_toggle,
                    merge_limit=merge_limit,
                    rebase=rebase,
                    app_sre_usernames=app_sre_usernames,
                    state=state,
                    pipeline_timeout=pipeline_timeout,
                    insist=False,
                    wait_for_pipeline=wait_for_pipeline,
                    users_allowed_to_label=users_allowed_to_label,
                    must_pass=must_pass,
                    multi_merge=multi_merge,
                )
            if rebase:
                rebase_merge_requests(
                    dry_run=dry_run,
                    gl=gl,
                    rebase_limit=rebase_limit,
                    state=state,
                    pipeline_timeout=pipeline_timeout,
                    wait_for_pipeline=wait_for_pipeline,
                    users_allowed_to_label=users_allowed_to_label,
                    strategy=rebase_strategy,
                )
