import setuptools


setuptools.setup(
name="rbx_cookie", #Replace with your own package name
version="0.0.1" ,
author = "veiyo" ,
description="rbx_cookie" ,
packages=["rbx_cookie"]
)