# Cipherbcrypt

Encode string data by zlib, base64 invert
![branch](https://github.com/github/docs/actions/workflows/main.yml/badge.svg?branch=feature-1)

## License
MIT
**Encode Cipherbcrypt group**