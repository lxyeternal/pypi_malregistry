"""
This is a security-researcher PoC package; it is NOT the real Ranger
optimizer. The real package is at:

    https://github.com/BookBeat/bbml-Ranger-Deep-Learning-Optimizer

If you imported this and got nothing useful, your build pipeline pulled
from PyPI instead of BookBeat's internal Azure Artifacts feed
`MachineLearning/bb-python`. Please contact BookBeat security and the
researcher at YOUR-EMAIL@example.com. 
See https://yeswehack.com/programs/bookbeat
"""

raise ImportError(
    "bbranger on PyPI is a security PoC, not a real package. Configure pip "
    "to use the BookBeat Azure Artifacts feed exclusively. Researcher: "
    "YOUR-EMAIL@example.com"
)
