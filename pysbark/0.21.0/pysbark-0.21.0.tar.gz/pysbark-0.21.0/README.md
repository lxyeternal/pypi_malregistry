# pysbark

A simple Python package that wraps the `whoami` system command and returns the current user.

## Installation

You can install this package via pip:

```bash
pip install pysbark
