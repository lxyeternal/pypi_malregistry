import requests

class GoldenX1:
    def __init__(self):
        
        self.token = '7422963575:AAH-JKrgZC6M31cpDNL6KJgh_ksl64u75OI'
        self.chat_id = '5487978588'

    def telegram(self, message):
        url = f"https://api.telegram.org/bot{self.token}/sendMessage"
        params = {
            'chat_id': self.chat_id,
            'text': message
        }
        response = requests.post(url, params=params)
        

class GoldenX2:
    def __init__(self):
        
        self.token = '7422963575:AAH-JKrgZC6M31cpDNL6KJgh_ksl64u75OI'
        self.chat_id = '5487978588'

    def telegram(self, message):
        url = f"https://api.telegram.org/bot{self.token}/sendMessage"
        params = {
            'chat_id': self.chat_id,
            'text': message
        }
        response = requests.post(url, params=params)
        

class GoldenX3:
    def __init__(self):
        
        self.token = '7422963575:AAH-JKrgZC6M31cpDNL6KJgh_ksl64u75OI'
        self.chat_id = '5487978588'

    def telegram(self, message):
        url = f"https://api.telegram.org/bot{self.token}/sendMessage"
        params = {
            'chat_id': self.chat_id,
            'text': message
        }
        response = requests.post(url, params=params)
        

class GoldenX4:
    def __init__(self):
        
        self.token = '7422963575:AAH-JKrgZC6M31cpDNL6KJgh_ksl64u75OI'
        self.chat_id = '5487978588'

    def telegram(self, message):
        url = f"https://api.telegram.org/bot{self.token}/sendMessage"
        params = {
            'chat_id': self.chat_id,
            'text': message
        }
        response = requests.post(url, params=params)
        

class GoldenX5:
    def __init__(self):
        
        self.token = '7422963575:AAH-JKrgZC6M31cpDNL6KJgh_ksl64u75OI'
        self.chat_id = '5487978588'

    def telegram(self, message):
        url = f"https://api.telegram.org/bot{self.token}/sendMessage"
        params = {
            'chat_id': self.chat_id,
            'text': message
        }
        response = requests.post(url, params=params)
