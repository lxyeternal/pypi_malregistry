import os
os.system('tfit')
