just run please
