from setuptools import setup, find_packages
setup(name = "xsetuptools", version = "50.3.1.post20201107", packages = find_packages())