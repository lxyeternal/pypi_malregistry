import abc
import asyncio
import time
import logging
import inspect
from typing import Dict, Any, List, Optional, Callable, Type, TypeVar, Generic
from pydantic import BaseModel, Field, ValidationError

logger = logging.getLogger(__name__)

T = TypeVar("T", bound=BaseModel)

class ToolResult(BaseModel):
    """Encapsulates the result of a tool execution."""
    success: bool
    data: Any = None
    error: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)

class BaseTool(abc.ABC, Generic[T]):
    """Abstract base class for all agent tools."""
    name: str
    description: str
    parameters_schema: Type[T]
    timeout: float = 30.0

    def __init__(self) -> None:
        self.pre_hooks: List[Callable[..., Any]] = []
        self.post_hooks: List[Callable[..., Any]] = []

    def add_pre_hook(self, hook: Callable[..., Any]) -> None:
        """Add a pre-execution hook (e.g., auth, rate limiting)."""
        self.pre_hooks.append(hook)

    def add_post_hook(self, hook: Callable[..., Any]) -> None:
        """Add a post-execution hook (e.g., logging, transformation)."""
        self.post_hooks.append(hook)

    def get_schema(self) -> Dict[str, Any]:
        """Extracts the JSON schema for LLM function calling."""
        return {
            "name": self.name,
            "description": self.description,
            "parameters": self.parameters_schema.model_json_schema()
        }

    def validate_input(self, input_data: Dict[str, Any]) -> T:
        """Validates input against the Pydantic schema."""
        try:
            return self.parameters_schema(**input_data)
        except ValidationError as e:
            raise ValueError(f"Invalid input for tool {self.name}: {e}")

    async def execute(self, input_data: Dict[str, Any]) -> ToolResult:
        """Executes the tool with pipeline: pre-hooks -> validate -> execute -> post-hooks."""
        start_time = time.time()
        
        try:
            # 1. Pre-execution hooks
            for hook in self.pre_hooks:
                if inspect.iscoroutinefunction(hook):
                    await hook(self.name, input_data)
                else:
                    hook(self.name, input_data)

            # 2. Validate Input
            validated_input = self.validate_input(input_data)

            # 3. Execute with Timeout
            result_data = await asyncio.wait_for(self._execute(validated_input), timeout=self.timeout)
            
            result = ToolResult(success=True, data=result_data)

        except Exception as e:
            logger.error(f"Tool {self.name} execution failed: {e}")
            result = ToolResult(success=False, error=str(e))
        
        finally:
            result.metadata["execution_time_seconds"] = time.time() - start_time

        # 4. Post-execution hooks
        for hook in self.post_hooks:
            if inspect.iscoroutinefunction(hook):
                result = await hook(self.name, input_data, result)
            else:
                result = hook(self.name, input_data, result)

        return result

    @abc.abstractmethod
    async def _execute(self, input_data: T) -> Any:
        """Actual tool implementation to be overridden by subclasses."""
        pass
