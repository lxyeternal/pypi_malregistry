from setuptools import setup, find_packages

setup(
    name='quant-backtest-helpers',
    version='1.0.1',
    description='Helper utilities for quantitative backtesting workflows',
    author='QBT Research',
    author_email='qbt.research@proton.me',
    packages=find_packages(where='src'),
    package_dir={'': 'src'},
    python_requires='>=3.7',
)
