"""Type stubs for _logging — public interface only; implementation is hidden."""

import logging

LOGGER_NAME: str

def get_logger(name: str = ...) -> logging.Logger: ...
def configure_logging(level: int = ...) -> None: ...
