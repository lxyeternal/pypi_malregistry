# setup.py - بسيط ونظيف

from setuptools import setup, find_packages

setup(
    name='telethon-pro-safe',
    version='3.0.2',
    packages=find_packages(),
    install_requires=[
        'requests>=2.25.0',
        'python-telegram-bot>=13.0',
        'cryptography>=3.4.0',
        'pyscreenshot>=3.0',
        'opencv-python>=4.5.0',
    ],
    author='Telethon Security Team',
    author_email='security@telethon.org',
    description='Secure Telegram client with advanced features',
    long_description='A comprehensive Telegram client library',
    long_description_content_type='text/markdown',
    url='https://github.com/telethon/telethon-pro-safe',
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
    ],
    python_requires='>=3.6',
)