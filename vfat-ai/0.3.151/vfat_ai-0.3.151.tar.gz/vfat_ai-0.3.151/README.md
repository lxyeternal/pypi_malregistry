# vfat-ai

Web UI for managing Claude Code sessions remotely with mobile support and push notifications.

## Installation

```bash
pip install vfat-ai
```

## Quick Start

```python
from vfat_ai import Config
config = Config.load()
```
