# bbranger — SECURITY-RESEARCHER PoC, NOT the real Ranger optimizer

This package on PyPI is a **coordinated security PoC** for a dependency-
confusion finding against BookBeat (YesWeHack report #YOUR-REPORT-ID). 

The real `bbranger` lives at:
https://github.com/BookBeat/bbml-Ranger-Deep-Learning-Optimizer

and is published to BookBeat's internal Azure Artifacts feed
`MachineLearning/bb-python`. If your build pulled this version from PyPI,
your pip configuration is vulnerable to dependency confusion.

**What this version does on install**: emits one DNS lookup and one HTTPS GET
to a researcher-controlled callback containing only the install hostname,
working directory, and the *names* (not values) of environment variables.
No secrets are read, no files modified, no code persists.

**Take-down**: BookBeat PSIRT or YesWeHack triagers can request immediate
yank from YOUR-EMAIL@example.com; the package will be removed within one hour.

**Researcher**: YOUR-NAME · YOUR-EMAIL@example.com · YesWeHack handle YOUR-HANDLE
**Report**: YOUR-REPORT-URL
