# govpkg

A simple Python client for the official `pkg.go.dev` v1beta API.

## Installation

```bash
pip install govpkg
```

## Usage

### Search for a package

```python
from govpkg import get

url = get("cobra")
print(url)
# https://pkg.go.dev/github.com/spf13/cobra
```

### Get package metadata

```python
from govpkg import package

pkg = package("github.com/spf13/cobra")
print(pkg)
```

You can also pass a pkg.go.dev URL:

```python
pkg = package("https://pkg.go.dev/github.com/spf13/cobra")
```

### Get module metadata

```python
from govpkg import module

mod = module("github.com/spf13/cobra")
print(mod)
```

Or using a pkg.go.dev URL:

```python
mod = module("https://pkg.go.dev/github.com/spf13/cobra")
```

## API

### `get(query: str) -> str`

Searches for a Go package and returns the pkg.go.dev URL of the best match.

### `package(path: str) -> dict`

Returns metadata for a Go package.

### `module(path: str) -> dict`

Returns metadata for the Go module containing the package.

## Requirements

- Python 3.9+
- `requests`

## License

MIT
