

import os
import subprocess

def test_exec():

    print('here is executer.test_exec')