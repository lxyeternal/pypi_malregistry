import json
import logging
from typing import List, Dict, Any, Optional, cast
from pydantic import BaseModel
import asyncpg
from google import genai
from google.genai import types

logger = logging.getLogger(__name__)

class MemoryResult(BaseModel):
    id: str
    content: str
    metadata: Dict[str, Any]
    score: float
    memory_type: str

class LongTermMemory:
    """
    PostgreSQL-based long term memory using pgvector.
    """
    def __init__(self, api_key: str, dsn: str):
        self.dsn = dsn
        self.client = genai.Client(api_key=api_key)
        self.pool: Optional[asyncpg.Pool] = None
        self._new_vectors_count = 0
        self._reindex_threshold = 100

    async def connect(self) -> None:
        if not self.pool:
            self.pool = await asyncpg.create_pool(self.dsn)
            logger.info("Connected to PostgreSQL for LongTermMemory")

    async def disconnect(self) -> None:
        if self.pool:
            await self.pool.close()
            self.pool = None

    async def add(
        self, 
        text: str, 
        metadata: Dict[str, Any], 
        memory_type: str = "general"
    ) -> str:
        """Embeds and stores a new memory chunk."""
        if not self.pool:
            await self.connect()
        
        # 1. Generate Embedding
        response = self.client.models.embed_content(
            model="gemini-embedding-001",
            contents=text,
            config=types.EmbedContentConfig(output_dimensionality=768)
        )
        if not response.embeddings:
            raise RuntimeError("Failed to generate embedding")
            
        embedding = response.embeddings[0].values

        # 2. Store in PG
        if self.pool is None:
            raise RuntimeError("Database pool not initialized")

        async with self.pool.acquire() as conn:
            row = await conn.fetchrow("""
                INSERT INTO long_term_memory (content, embedding, metadata, memory_type)
                VALUES ($1, $2, $3, $4)
                RETURNING id;
            """, text, str(embedding), json.dumps(metadata), memory_type)
            
            if not row:
                raise RuntimeError("Failed to insert memory")
                
            self._new_vectors_count += 1
            await self._check_reindex(conn)
            
            return str(row['id'])

    async def search(self, query: str, limit: int = 5) -> List[MemoryResult]:
        """Vector search using cosine similarity."""
        logger.info(f"Vector search for: {query}")
        
        if not self.pool:
            await self.connect()
        
        if self.pool is None:
            return []

        # 1. Embed query
        response = self.client.models.embed_content(
            model="gemini-embedding-001",
            contents=query,
            config=types.EmbedContentConfig(output_dimensionality=768)
        )
        if not response.embeddings:
            return []
            
        query_embedding = response.embeddings[0].values

        # 2. Vector Search
        async with self.pool.acquire() as conn:
            rows = await conn.fetch("""
                SELECT id, content, metadata, memory_type,
                       1 - (embedding <=> $1) as score
                FROM long_term_memory
                ORDER BY embedding <=> $1
                LIMIT $2;
            """, str(query_embedding), limit)
            
            return [
                MemoryResult(
                    id=str(r['id']),
                    content=r['content'],
                    metadata=json.loads(r['metadata']),
                    score=r['score'],
                    memory_type=r['memory_type']
                ) for r in rows
            ]

    async def hybrid_search(self, query: str, keywords: List[str], limit: int = 5) -> List[MemoryResult]:
        """Hybrid search combining vector similarity and keyword filtering."""
        logger.info(f"Hybrid search for: {query} with keywords {keywords}")
        
        if not self.pool:
            await self.connect()
        
        if self.pool is None:
            return []

        # 1. Embed query
        response = self.client.models.embed_content(
            model="gemini-embedding-001",
            contents=query,
            config=types.EmbedContentConfig(output_dimensionality=768)
        )
        if not response.embeddings:
            return []
            
        query_embedding = response.embeddings[0].values

        # 2. Hybrid SQL (Vector + Keyword match in metadata or content)
        # Build OR conditions so any keyword independently triggers a match.
        params: list[object] = [str(query_embedding)]
        conditions = []
        for i, kw in enumerate(keywords, start=2):
            conditions.append(f"(content ILIKE ${i} OR metadata::text ILIKE ${i})")
            params.append(f"%{kw}%")
        where_clause = " OR ".join(conditions) if conditions else "TRUE"
        params.append(limit)
        limit_param = len(params)

        # where_clause contains only asyncpg placeholders ($2, $3...) — no user input is interpolated
        sql = f"""
            SELECT id, content, metadata, memory_type,
                   1 - (embedding <=> $1) as score
            FROM long_term_memory
            WHERE {where_clause}
            ORDER BY embedding <=> $1
            LIMIT ${limit_param};
        """  # nosec B608
        async with self.pool.acquire() as conn:
            rows = await conn.fetch(sql, *params)
            
            return [
                MemoryResult(
                    id=str(r['id']),
                    content=r['content'],
                    metadata=json.loads(r['metadata']),
                    score=r['score'],
                    memory_type=r['memory_type']
                ) for r in rows
            ]

    async def _check_reindex(self, conn: asyncpg.Connection) -> None:
        """Periodic reindexing for ivfflat efficiency."""
        if self._new_vectors_count >= self._reindex_threshold:
            logger.info("Reindexing long term memory...")
            count_row = await conn.fetchval("SELECT count(*) FROM long_term_memory;")
            lists = max(1, int(cast(int, count_row) ** 0.5))
            
            await conn.execute(f"""
                DROP INDEX IF EXISTS idx_memory_embedding_ivfflat;
                CREATE INDEX idx_memory_embedding_ivfflat 
                ON long_term_memory USING ivfflat (embedding vector_cosine_ops) 
                WITH (lists = {lists});
            """)
            self._new_vectors_count = 0
