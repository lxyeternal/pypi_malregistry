"""
BLOB Hunter - Dependency Confusion PoC

This package is for security research purposes only.
It demonstrates the dependency confusion vulnerability.

When installed, it sends a callback to verify the attack vector
without executing any malicious code.
"""

__version__ = "999.0.0"
__author__ = "Security Researcher"

def poc_info():
    return {
        "name": "blobhunter-depconf-poc",
        "purpose": "Dependency Confusion PoC",
        "tool": "BLOB Hunter",
    }
