from chacha_lite_encrypt import ChaChaEncryption, generate_key, generate_nonce

key = generate_key()

plaintext = "This is a secret message"
ciphertext = ChaChaEncryption.encrypt(plaintext, key)

print(f"Plaintext: {plaintext}")
print(f"Ciphertext (hex): {ciphertext.hex()}")

decrypted = ChaChaEncryption.decrypt(ciphertext, key)
print(f"Decrypted: {decrypted.decode('utf-8')}")
