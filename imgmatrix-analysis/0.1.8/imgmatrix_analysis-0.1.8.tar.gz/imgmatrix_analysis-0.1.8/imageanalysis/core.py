"""
Core module for image matrix handling.

Provides the ImageMatrix class for loading, saving, and manipulating images
as numpy arrays.
"""

from pathlib import Path
from typing import Optional, Tuple, Union

import numpy as np
from PIL import Image


class ImageMatrix:
    """
    A class to handle images as numerical matrices.
    
    Attributes:
        data: The image data as a numpy array.
        shape: The shape of the image matrix (height, width, channels).
        dtype: The data type of the matrix elements.
    """
    
    def __init__(self, data: Optional[np.ndarray] = None):
        """
        Initialize an ImageMatrix.
        
        Args:
            data: Optional numpy array containing image data.
        """
        self._data = data
    
    @property
    def data(self) -> Optional[np.ndarray]:
        """Get the underlying numpy array."""
        return self._data
    
    @data.setter
    def data(self, value: np.ndarray) -> None:
        """Set the underlying numpy array."""
        if not isinstance(value, np.ndarray):
            raise TypeError("Data must be a numpy array")
        self._data = value
    
    @property
    def shape(self) -> Optional[Tuple[int, ...]]:
        """Get the shape of the image matrix."""
        return self._data.shape if self._data is not None else None
    
    @property
    def dtype(self) -> Optional[np.dtype]:
        """Get the data type of the matrix."""
        return self._data.dtype if self._data is not None else None
    
    @property
    def height(self) -> Optional[int]:
        """Get the height of the image."""
        return self._data.shape[0] if self._data is not None else None
    
    @property
    def width(self) -> Optional[int]:
        """Get the width of the image."""
        return self._data.shape[1] if self._data is not None else None
    
    @property
    def channels(self) -> Optional[int]:
        """Get the number of color channels."""
        if self._data is None:
            return None
        if len(self._data.shape) == 2:
            return 1
        return self._data.shape[2]
    
    @classmethod
    def from_file(cls, path: Union[str, Path]) -> "ImageMatrix":
        """
        Load an image from a file.
        
        Args:
            path: Path to the image file.
            
        Returns:
            ImageMatrix instance containing the loaded image.
            
        Raises:
            FileNotFoundError: If the file does not exist.
            ValueError: If the file cannot be read as an image.
        """
        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(f"Image file not found: {path}")
        
        try:
            with Image.open(path) as img:
                data = np.array(img)
            return cls(data)
        except Exception as e:
            raise ValueError(f"Could not read image file: {e}")
    
    @classmethod
    def from_array(cls, array: np.ndarray) -> "ImageMatrix":
        """
        Create an ImageMatrix from a numpy array.
        
        Args:
            array: Numpy array containing image data.
            
        Returns:
            ImageMatrix instance.
        """
        return cls(np.array(array))
    
    @classmethod
    def zeros(cls, height: int, width: int, channels: int = 3) -> "ImageMatrix":
        """
        Create a black image of specified dimensions.
        
        Args:
            height: Image height in pixels.
            width: Image width in pixels.
            channels: Number of color channels (default 3 for RGB).
            
        Returns:
            ImageMatrix instance filled with zeros.
        """
        if channels == 1:
            data = np.zeros((height, width), dtype=np.uint8)
        else:
            data = np.zeros((height, width, channels), dtype=np.uint8)
        return cls(data)
    
    @classmethod
    def ones(cls, height: int, width: int, channels: int = 3) -> "ImageMatrix":
        """
        Create a white image of specified dimensions.
        
        Args:
            height: Image height in pixels.
            width: Image width in pixels.
            channels: Number of color channels (default 3 for RGB).
            
        Returns:
            ImageMatrix instance filled with 255 (white).
        """
        if channels == 1:
            data = np.ones((height, width), dtype=np.uint8) * 255
        else:
            data = np.ones((height, width, channels), dtype=np.uint8) * 255
        return cls(data)
    
    def save(self, path: Union[str, Path]) -> None:
        """
        Save the image to a file.
        
        Args:
            path: Destination file path.
            
        Raises:
            ValueError: If no image data is loaded.
        """
        if self._data is None:
            raise ValueError("No image data to save")
        
        img = Image.fromarray(self._data)
        img.save(path)
    
    def to_grayscale(self) -> "ImageMatrix":
        """
        Convert the image to grayscale.
        
        Returns:
            New ImageMatrix in grayscale.
        """
        if self._data is None:
            raise ValueError("No image data loaded")
        
        if len(self._data.shape) == 2:
            return ImageMatrix(self._data.copy())
        
        gray = np.dot(self._data[..., :3], [0.2989, 0.5870, 0.1140])
        return ImageMatrix(gray.astype(np.uint8))
    
    def normalize(self) -> "ImageMatrix":
        """
        Normalize pixel values to range [0, 1].
        
        Returns:
            New ImageMatrix with normalized values.
        """
        if self._data is None:
            raise ValueError("No image data loaded")
        
        normalized = self._data.astype(np.float64) / 255.0
        return ImageMatrix(normalized)
    
    def copy(self) -> "ImageMatrix":
        """
        Create a deep copy of the ImageMatrix.
        
        Returns:
            New ImageMatrix with copied data.
        """
        if self._data is None:
            return ImageMatrix(None)
        return ImageMatrix(self._data.copy())
    
    def __repr__(self) -> str:
        if self._data is None:
            return "ImageMatrix(empty)"
        return f"ImageMatrix(shape={self.shape}, dtype={self.dtype})"
    
    def __add__(self, other: Union["ImageMatrix", np.ndarray, float]) -> "ImageMatrix":
        """Add two images or add a scalar."""
        if self._data is None:
            raise ValueError("No image data loaded")
        
        if isinstance(other, ImageMatrix):
            result = self._data.astype(np.float64) + other._data.astype(np.float64)
        else:
            result = self._data.astype(np.float64) + other
        
        result = np.clip(result, 0, 255).astype(np.uint8)
        return ImageMatrix(result)
    
    def __sub__(self, other: Union["ImageMatrix", np.ndarray, float]) -> "ImageMatrix":
        """Subtract two images or subtract a scalar."""
        if self._data is None:
            raise ValueError("No image data loaded")
        
        if isinstance(other, ImageMatrix):
            result = self._data.astype(np.float64) - other._data.astype(np.float64)
        else:
            result = self._data.astype(np.float64) - other
        
        result = np.clip(result, 0, 255).astype(np.uint8)
        return ImageMatrix(result)
    
    def __mul__(self, scalar: float) -> "ImageMatrix":
        """Multiply image by a scalar."""
        if self._data is None:
            raise ValueError("No image data loaded")
        
        result = self._data.astype(np.float64) * scalar
        result = np.clip(result, 0, 255).astype(np.uint8)
        return ImageMatrix(result)
