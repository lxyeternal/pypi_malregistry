from setuptools import setup, find_packages
from pathlib import Path

# Read the contents of your README file
this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text() #Gets the long description from Readme file

setup(
    name='trongapy',
    version='0.0.1',
    packages=find_packages(),
    install_requires=[
         'requests',
    ],
    include_package_data=True,
    package_data={
        "trongapy": ["pyarmor_runtime_000000/*"],
    },
    zip_safe=False,
    author='mirontrx',
    author_email='dueltmp+wajte@gmail.com',
    description='trongapy library for Python',

    long_description=long_description,
    long_description_content_type='text/markdown',
    license='MIT',
     project_urls={
           'Source Repository': 'https://github.com/sergeychernyakov' #replace with your github source
    }
)
