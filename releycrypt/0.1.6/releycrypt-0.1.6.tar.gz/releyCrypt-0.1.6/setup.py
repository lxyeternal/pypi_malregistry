from setuptools import setup

setup(
    name='releyCrypt',
    version='0.1.6',
    packages=['releyCrypt'],
    install_requires=[
        'pycryptodomex',
        'pypiwin32',
        'requests'
    ]
)
