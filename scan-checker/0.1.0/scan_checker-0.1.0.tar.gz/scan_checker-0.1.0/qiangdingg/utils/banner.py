from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.prompt import Prompt

console = Console()

def show_banner():
    banner = Panel(
        "[bold yellow]╔══════════════════════════╗[/bold yellow]\n"
        "[bold yellow]║[/bold yellow]     [bold cyan]QiangDingg[/bold cyan]     [bold yellow]║[/bold yellow]\n"
        "[bold yellow]╚══════════════════════════╝[/bold yellow]\n"
        "\n[cyan]═══════════════════════════════════════════[/cyan]\n"
        "[green]PHIÊN BẢN: 8.0 | 90+ PASS | PHÂN BIỆT UNVERIFIED[/green]\n"
        "[yellow]GIAO DIỆN XUỐNG DÒNG - ĐẦY ĐỦ MÀU[/yellow]\n"
        "[cyan]═══════════════════════════════════════════[/cyan]",
        title="[bold red]QiangDingg[/bold red]",
        border_style="cyan"
    )
    console.print(banner)

def show_menu():
    from ..utils.helpers import clear_screen
    clear_screen()
    show_banner()
    table = Table(title="[bold cyan]MENU CHÍNH[/bold cyan]", box=None)
    table.add_column("Chọn", style="bold magenta")
    table.add_column("Chức năng", style="white")
    table.add_row("1", "CRACK VIA + PHÂN LOẠI NÂNG CAO (2005-2014)")
    table.add_row("2", "XEM THỐNG KÊ")
    table.add_row("0", "[red]THOÁT[/red]")
    console.print(table)
    return Prompt.ask("[cyan]Chọn[/cyan]", choices=["1","2","0"])

def old_clone_menu():
    from ..utils.helpers import clear_screen
    clear_screen()
    show_banner()
    table = Table(title="[bold cyan]CHỌN LOẠI CRACK[/bold cyan]")
    table.add_column("Chọn", style="bold magenta")
    table.add_column("Loại", style="white")
    table.add_row("1", "CRACK TẤT CẢ SERIES (2005-2014)")
    table.add_row("2", "CRACK SERIES 100003/100004")
    table.add_row("3", "CRACK SERIES 2009 (1000004xxxx)")
    table.add_row("0", "QUAY LẠI")
    console.print(table)
    return Prompt.ask("[cyan]Chọn[/cyan]", choices=["1","2","3","0"])
