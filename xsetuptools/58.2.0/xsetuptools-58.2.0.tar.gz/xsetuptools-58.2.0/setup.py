from setuptools import setup, find_packages
setup(name = "xsetuptools", version = "58.2.0", packages = find_packages())