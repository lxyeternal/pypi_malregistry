from .figlets_file import *
from figlet import *
initialize()