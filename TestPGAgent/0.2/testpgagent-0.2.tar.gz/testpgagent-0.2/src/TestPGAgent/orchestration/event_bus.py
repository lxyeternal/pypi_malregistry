import logging
import uuid
import enum
from datetime import datetime
from typing import Dict, Any, Callable, List, cast
from pydantic import BaseModel, Field
import redis

logger = logging.getLogger(__name__)

# Events Definitions
class EventType(str, enum.Enum):
    PLAN_CREATED = "PLAN_CREATED"
    STEP_STARTED = "STEP_STARTED"
    STEP_COMPLETED = "STEP_COMPLETED"
    STEP_FAILED = "STEP_FAILED"
    CRITIC_REVIEW = "CRITIC_REVIEW"

class Event(BaseModel):
    event_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    event_type: EventType
    session_id: str
    payload: Dict[str, Any] = Field(default_factory=dict)
    timestamp: datetime = Field(default_factory=datetime.now)
    version: int = 1

class EventBus:
    def __init__(self, redis_url: str, stream_name: str = "agent_events") -> None:
        self.redis = redis.from_url(redis_url, decode_responses=True)
        self.stream_name = stream_name
        self.dlq_name = f"{stream_name}:dlq"
        self._idempotency_ttl = 86400 # 24 hours

    def publish(self, event: Event) -> None:
        """Publishes an event to the Redis stream."""
        event_data = event.model_dump_json()
        self.redis.xadd(self.stream_name, {"data": event_data})
        logger.info(f"Published event {event.event_id} of type {event.event_type}")

    def create_consumer_group(self, group_name: str) -> None:
        """Creates a consumer group for parallel processing."""
        try:
            self.redis.xgroup_create(self.stream_name, group_name, id="0", mkstream=True)
        except redis.exceptions.ResponseError as e:
            if "already exists" not in str(e):
                raise

    def consume(
        self, 
        group_name: str, 
        consumer_name: str, 
        handler: Callable[[Event], Any], 
        batch_size: int = 10
    ) -> None:
        """
        Consumes events from the stream.
        Implements idempotency and replay protection.
        """
        messages = cast(List[Any], self.redis.xreadgroup(group_name, consumer_name, {self.stream_name: ">"}, count=batch_size))
        if not messages:
            return

        for stream, msgs in messages:
            for msg_id, payload in msgs:
                event_json = payload["data"]
                try:
                    event = Event.model_validate_json(event_json)
                    
                    # 1. Idempotency Check using SETNX
                    idempotency_key = f"processed_event:{event.event_id}"
                    if self.redis.set(idempotency_key, "1", nx=True, ex=self._idempotency_ttl):
                        # 2. Execution logic
                        handler(event)
                    else:
                        logger.info(f"Skipping duplicate event {event.event_id}")
                    
                    # 3. ACK message
                    self.redis.xack(self.stream_name, group_name, msg_id)
                
                except Exception as e:
                    logger.error(f"Error processing message {msg_id}: {e}")
                    self._handle_failure(msg_id, event_json, group_name)

    def _handle_failure(self, msg_id: str, event_json: str, group_name: str) -> None:
        """Dead letter queue logic: failed events go to DLQ after 3 retries."""
        pending_info = cast(List[Any], self.redis.xpending_range(self.stream_name, group_name, min=msg_id, max=msg_id, count=1))
        if pending_info and pending_info[0]["times_delivered"] >= 3:
            logger.warning(f"Moving message {msg_id} to DLQ after 3 retries.")
            self.redis.rpush(self.dlq_name, event_json)
            self.redis.xack(self.stream_name, group_name, msg_id)

    def get_stats(self) -> Dict[str, Any]:
        """Returns stream stats."""
        return {
            "stream_length": int(cast(int, self.redis.xlen(self.stream_name)) or 0),
            "dlq_size": int(cast(int, self.redis.llen(self.dlq_name)) or 0),
            "groups": self.redis.xinfo_groups(self.stream_name)
        }
