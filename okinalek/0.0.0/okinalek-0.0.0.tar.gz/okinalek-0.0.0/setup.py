from setuptools import setup

setup(
    name='okinalek',
    version='',
    description='okinalek',
    author='okinalek',
    author_email='magalie876956@2rwuvtol.saucent.online',
    packages=['okinalek'],
    install_requires=[],
)
