# gatr\nA dummy Python package version of gatr.
