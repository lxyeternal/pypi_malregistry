import os
import base64
import json
from Crypto.PublicKey import RSA
from Crypto.Signature import pkcs1_15
from Crypto.Hash import SHA256

def generate_keys():
    """Generates a new RSA key pair."""
    key = RSA.generate(2048)
    private_key = key.export_key()
    public_key = key.publickey().export_key()
    
    with open("private.pem", "wb") as f:
        f.write(private_key)
    with open("public.pem", "wb") as f:
        f.write(public_key)
    print("[+] Keys generated: private.pem & public.pem")

def sign_license(data_dict):
    """Signs a dictionary and returns a base64 encoded license key."""
    if not os.path.exists("private.pem"):
        print("[!] private.pem not found. Run generate_keys first.")
        return
    
    with open("private.pem", "rb") as f:
        key = RSA.import_key(f.read())
    
    data_str = json.dumps(data_dict, separators=(',', ':'))
    message = data_str.encode('utf-8')
    h = SHA256.new(message)
    signature = pkcs1_15.new(key).sign(h)
    
    # License format: Payload.Signature (both base64)
    payload_b64 = base64.b64encode(message).decode('utf-8')
    signature_b64 = base64.b64encode(signature).decode('utf-8')
    
    license_key = f"{payload_b64}.{signature_b64}"
    print(f"\n[+] Generated License Key:\n{license_key}\n")
    return license_key

if __name__ == "__main__":
    # 1. Generate keys (Done once)
    if not os.path.exists("private.pem"):
        generate_keys()
    
    print("--- SERVER LICENSE GENERATOR ---")
    user = input("Nhap username: ")
    expiry = input("Nhap ngay het han (YYYY-MM-DD): ")
    
    user_data = {
        "user": user,
        "expiry": expiry,
        "version_access": "1.0.0"
    }
    sign_license(user_data)
