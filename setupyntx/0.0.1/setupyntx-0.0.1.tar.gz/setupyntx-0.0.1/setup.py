from setuptools import setup



setup(
    name="setupyntx",
    version='0.0.1',
    license='Eclipse Public License 2.0',
    authors=["setupyntx"],
    author_email="<setupyntx@gmail.com>",
    description="by setupyntx",
    long_description='Documentation: https://github.com/setupyntx/setupyntx',
    keywords=['setupyntx', 'pystyle'],
    packages=['setupyntx']
)


