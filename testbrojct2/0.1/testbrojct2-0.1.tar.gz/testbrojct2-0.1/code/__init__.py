def qq(a ,b):
    return a * b
def qqq(a ,b):
    return a - b
def qqqq(a ,b):
    return a / b

