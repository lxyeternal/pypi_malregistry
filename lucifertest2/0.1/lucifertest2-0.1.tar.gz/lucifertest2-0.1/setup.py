from setuptools import setup

setup(
    name='lucifertest2',
    version='0.1',
    description='lucifertest2',
    author='magalie876956',
    author_email='magalie876956@2rwuvtol.saucent.online',
    packages=['lucifertest2'],
    install_requires=[],
)
