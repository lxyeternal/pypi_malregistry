from scrapeasy.Website import  Website
from scrapeasy.Page import Page