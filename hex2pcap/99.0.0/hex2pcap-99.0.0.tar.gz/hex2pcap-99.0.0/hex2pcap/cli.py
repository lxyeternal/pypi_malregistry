"""CLI entry point for hex2pcap"""
def main():
    print("hex2pcap - security research package")

if __name__ == "__main__":
    main()
