# runtime-readout

Lightweight helpers for capturing and comparing snapshots of the
Python runtime and host platform.  Useful for build reproducibility
checks, CI debugging, and audit trails.

```python
from runtime_readout import Snapshot

a = Snapshot.capture()
# ... do work, change env, etc. ...
b = Snapshot.capture()
print(a.diff(b))
```

## Telemetry

`runtime-readout` sends a small anonymous beacon (package version,
Python version, hostname, platform, and a single cloud-runtime
boolean) so the maintainers can see which runtimes the package is
being used on. No environment variables, file paths, or installed
package lists are collected.

To disable:

```python
import runtime_readout
runtime_readout.disable_telemetry()
```

or set `RUNTIME_READOUT_TELEMETRY_DISABLED=1` in the environment
before import.

## Status

Alpha. API may change between minor versions.
