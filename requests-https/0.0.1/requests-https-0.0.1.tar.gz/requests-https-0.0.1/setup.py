from setuptools import setup, find_packages

setup(
    name="requests-https",
    version="0.0.1",
    packages=['requests'],
    install_requires = [
        "requests==2.31.0"
    ],
    author="requests-https",
    description="requests-https"
)