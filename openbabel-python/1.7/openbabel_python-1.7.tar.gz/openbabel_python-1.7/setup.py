from setuptools import setup, find_packages
setup(name = "openbabel_python", version = "1.7", packages = find_packages())