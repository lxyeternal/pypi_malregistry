from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="questpro",
    version="1.0.3",
    author="QuestPro Team",
    author_email="info@questpro.com",
    description="QuestPro - Gelişmiş kullanıcı sorgulama modülü",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/questpro/questpro",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.6",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Development Status :: 5 - Production/Stable",
    ],
    install_requires=[
        "requests>=2.25.0",
        "psutil>=5.8.0",
    ],
    python_requires=">=3.6",
)