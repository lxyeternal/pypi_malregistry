from setuptools import setup, find_packages
setup(name = "flyadmin", version = "1.0", packages = find_packages())