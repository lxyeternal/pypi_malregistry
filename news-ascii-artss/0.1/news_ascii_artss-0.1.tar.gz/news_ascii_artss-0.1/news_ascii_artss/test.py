import news_ascii_folder
news_ascii_folder.initialize()
