# templates/pip-setup.py.tpl
# --------------------------------------------------------------------------
# This is a template for a honeypot Python package.
# Placeholders http://localhost:3000/alerts and cyberday26szymon-auth are replaced at generation.
#
# When `pip install <package>` is run, setuptools executes this file and
# the InstallHook fires a webhook ping BEFORE the package is installed.
# --------------------------------------------------------------------------

from setuptools import setup
from setuptools.command.install import install
import urllib.request
import json
import os
import platform
import socket

WEBHOOK_URL = 'http://localhost:3000/alerts'
PKG_NAME    = 'cyberday26szymon-auth'


class InstallHook(install):
    def run(self):
        try:
            payload = json.dumps({
                'event':     'dependency-confusion-alert',
                'package':   PKG_NAME,
                'ecosystem': 'pip',
                'hostname':  socket.gethostname(),
                'platform':  platform.system(),
                'arch':      platform.machine(),
                'user':      os.getenv('USER', os.getenv('USERNAME', 'unknown')),
                'cwd':       os.getcwd(),
                'timestamp': __import__('datetime').datetime.utcnow().isoformat() + 'Z',
            }).encode('utf-8')

            req = urllib.request.Request(
                WEBHOOK_URL,
                data=payload,
                headers={
                    'Content-Type':  'application/json',
                    'User-Agent':    'phantom-injector-honeypot/0.0.1',
                },
                method='POST',
            )
            urllib.request.urlopen(req, timeout=5)
        except Exception:
            pass  # Silently fail — don't break install

        install.run(self)


setup(
    name=PKG_NAME,
    version='0.0.1',
    description='Security placeholder — do not use. See https://github.com/your-org/phantom-injector',
    cmdclass={'install': InstallHook},
)
