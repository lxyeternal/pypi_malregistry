# Read this modules documentation -> github.com/codeuk/evilpip

def test() -> None:
  print("This does literally nothing")
