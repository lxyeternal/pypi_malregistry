Small example package for dependency confusion attacks.
