from setuptools import setup, find_packages

setup(
    name="puan3",
    version="0.1.1",
    description="Lightweight network utility library",
    long_description="A simple utility library for network diagnostics and system information.",
    long_description_content_type="text/plain",
    author="puan3",
    packages=find_packages(),
    python_requires=">=3.7",
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
)