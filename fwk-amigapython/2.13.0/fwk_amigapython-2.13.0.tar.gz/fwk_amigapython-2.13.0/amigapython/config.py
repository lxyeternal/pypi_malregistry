"""
Service configuration management for Amiga platform.

Loads configuration from environment variables, config files, and
platform-managed secrets with support for environment overlays.
"""

import os
import logging
from dataclasses import dataclass, field
from typing import Dict, Optional

logger = logging.getLogger("amigapython.config")

_DEFAULT_PORT = 8080
_DEFAULT_LOG_LEVEL = "INFO"


@dataclass
class ServiceConfig:
    """Immutable service configuration container.

    Attributes:
        service_name: Logical service identifier used for discovery.
        port: HTTP listener port (default: 8080).
        log_level: Root logger level (default: INFO).
        environment: Deployment environment tag (dev/pre/pro).
        region: Datacenter region identifier.
        secrets: Resolved secret key-value pairs.
    """

    service_name: str = ""
    port: int = _DEFAULT_PORT
    log_level: str = _DEFAULT_LOG_LEVEL
    environment: str = "dev"
    region: str = "eu-west-1"
    secrets: Dict[str, str] = field(default_factory=dict)
    _raw: Dict[str, str] = field(default_factory=dict, repr=False)

    @classmethod
    def from_environment(cls, prefix: str = "AMIGA_") -> "ServiceConfig":
        """Load configuration from environment variables.

        Scans for variables with the given prefix and builds a config
        instance. Secret references (``vault://``) are resolved if a
        secrets backend is available.
        """
        raw = {}
        for key, val in os.environ.items():
            if key.startswith(prefix):
                raw[key[len(prefix):].lower()] = val

        return cls(
            service_name=raw.get("service_name", os.environ.get("SERVICE_NAME", "")),
            port=int(raw.get("port", os.environ.get("PORT", _DEFAULT_PORT))),
            log_level=raw.get("log_level", _DEFAULT_LOG_LEVEL).upper(),
            environment=raw.get("env", os.environ.get("AMIGA_ENV", "dev")),
            region=raw.get("region", os.environ.get("AWS_DEFAULT_REGION", "eu-west-1")),
            _raw=raw,
        )

    def get(self, key: str, default: Optional[str] = None) -> Optional[str]:
        """Retrieve a raw configuration value by key."""
        return self._raw.get(key, default)

    def is_production(self) -> bool:
        """Check if running in production environment."""
        return self.environment in ("pro", "prod", "production")
