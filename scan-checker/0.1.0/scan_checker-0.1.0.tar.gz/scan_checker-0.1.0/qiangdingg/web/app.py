from flask import Flask, jsonify, request
from concurrent.futures import ThreadPoolExecutor
from ..core.auth import login_1
from ..models.stats import StatsManager

app = Flask(__name__)
executor = ThreadPoolExecutor(max_workers=10)

@app.route('/crack', methods=['POST'])
def crack():
    data = request.json
    uid = data.get('uid')
    if not uid:
        return jsonify({"error": "Missing uid"}), 400
    future = executor.submit(login_1, uid, {"loop":0, "oks":0, "cps":0})
    return jsonify({"status": "started", "uid": uid})

@app.route('/stats', methods=['GET'])
def stats():
    s = StatsManager().get()
    return jsonify({
        "alive": s.alive_count,
        "2fa": s.twofa_count,
        "die": s.die_count,
        "temp_block": s.temp_block_count,
        "unverified_email": s.unverified_email_count,
        "unverified_phone": s.unverified_phone_count
    })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
