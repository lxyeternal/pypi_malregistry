Odoo addon: SPP Base
====================

Base module for Odoo Social Protection Programmes (SPP) integration.
Part of the OpenSPP ecosystem (https://openspp.org).

Provides foundational models and helpers used by all other ``odoo-addon-spp-*`` modules.

Compatibility
-------------

* Odoo 16.0 / 17.0
* Python >= 3.7

Installation
------------

.. code-block:: bash

   pip install odoo-addon-spp-base

License
-------

LGPL-3
