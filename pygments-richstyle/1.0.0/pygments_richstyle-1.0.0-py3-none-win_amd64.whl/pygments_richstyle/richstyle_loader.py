"""
richstyle_loader.py

This module integrates `.richstyle` theme files (CSS-like syntax)
with the MyPygments package.

It allows users to load custom syntax highlighting themes for MyPygments
and RichX using simple `.richstyle` files.

Example
-------
from mypyments.richstyle_loader import RichstyleTheme

theme = RichstyleTheme.from_file("themes/oceanic_deep.richstyle")
print(theme.styles)

# For use with Pygments:
from mypyments.formatters import TerminalFormatter
from mypyments import highlight, lexers

code = 'print("Hello, world!")'
lexer = lexers.get_lexer_by_name("python")
formatter = TerminalFormatter(style=theme)
print(highlight(code, lexer, formatter))
"""

from __future__ import annotations
from pathlib import Path
from typing import Dict, Any
from .style import Style
from .rich_css_style import compile_stylesheet_to_dict


class RichstyleTheme(Style):
    """
    A Pygments-compatible Style class generated dynamically from a .richstyle file.
    """

    background_color = "#000000"
    highlight_color = "#333333"
    default_style = ""

    # Will be populated dynamically
    styles: Dict[Any, str] = {}

    def __init__(self, mapping: Dict[str, str]):
        """
        Initialize a theme directly from a mapping of selector -> style string.
        """
        super().__init__()
        self.styles = mapping

    # ------------------------------------------------------------
    # Factory methods
    # ------------------------------------------------------------

    @classmethod
    def from_file(cls, path: str | Path) -> "RichstyleTheme":
        """
        Load a .richstyle file and return a RichstyleTheme instance.
        """
        mapping = compile_stylesheet_to_dict(path)
        return cls(mapping)

    @classmethod
    def from_string(cls, text: str) -> "RichstyleTheme":
        """
        Create a RichstyleTheme from raw .richstyle text.
        """
        import io
        from .rich_css_style import parse_richstyle, _decls_to_style_string

        _, rules = parse_richstyle(text)
        mapping: Dict[str, str] = {}
        for selector, decls in rules.items():
            mapping[selector] = _decls_to_style_string(decls)
        return cls(mapping)

    # ------------------------------------------------------------
    # Compatibility with Pygments API
    # ------------------------------------------------------------

    def __getitem__(self, token):
        """
        Return a style string for a given Pygments token.
        """
        # Try exact token name
        key = str(token)
        if key in self.styles:
            return self.styles[key]

        # Try lowercase name
        key_lower = key.lower()
        if key_lower in self.styles:
            return self.styles[key_lower]

        # Fallback to default
        return self.default_style

    def get_background_style(self) -> str:
        """
        Return background color if defined in .richstyle file.
        """
        bg_keys = ["background", "background-color", "bg"]
        for key in bg_keys:
            if key in self.styles:
                return self.styles[key]
        return self.background_color

    def to_rich_theme(self):
        """
        Convert this RichstyleTheme into a `rich.theme.Theme`
        for use directly with Rich Console.
        """
        from rich.theme import Theme
        return Theme(self.styles)
