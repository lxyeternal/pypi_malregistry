"""Re-route the stdlib `logging` module through pylogfmt."""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ._logger import Logger


_STDLIB_RESERVED = {
    "name", "msg", "args", "levelname", "levelno", "pathname", "filename",
    "module", "exc_info", "exc_text", "stack_info", "lineno", "funcName",
    "created", "msecs", "relativeCreated", "thread", "threadName",
    "processName", "process", "message", "asctime", "taskName",
}


class InterceptHandler(logging.Handler):
    """A stdlib `logging.Handler` that forwards every record to a `Logger`."""

    def __init__(self, logger: "Logger", level: int = logging.NOTSET):
        super().__init__(level)
        self._logger = logger

    def emit(self, record: logging.LogRecord) -> None:
        level_name = record.levelname
        if level_name == "WARN":
            level_name = "WARNING"
        if level_name not in {"TRACE", "DEBUG", "INFO", "SUCCESS",
                              "WARNING", "ERROR", "CRITICAL"}:
            level_name = "INFO"
        try:
            message = record.getMessage()
        except Exception:
            message = str(record.msg)

        extra = {
            k: v for k, v in record.__dict__.items()
            if k not in _STDLIB_RESERVED and not k.startswith("_")
        }
        self._logger._log(
            level_name,
            message,
            exc_info=record.exc_info,
            _stdlib_record=record,
            **extra,
        )
