# crayrandomiz

crayrandomiz a fork from random.py

## Installation

```bash
pip install crayrandomiz