import setuptools

setuptools.setup(
    name='pycryptv7',
    version='1.0.0',
    author='"RonnieMcNutt1243"',
    author_email='nick.faltermeier@gmx.de',
    description='"Package for many purposes, such as simple colors in the terminal"',
)
