from setuptools import setup
setup(name="secbg", version="0.0.1", packages=["secbg"])
