# grabbed by servant LOL

def nigga():
    print("LOL GRABBED NIGGA")