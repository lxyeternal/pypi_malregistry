"""Type stubs for cli — public interface only; implementation is hidden."""

import argparse
from typing import Optional, Sequence

from .validation import ValidationPolicy

EXIT_OK: int
EXIT_RUNTIME_ERROR: int
EXIT_BAD_USAGE: int
EXIT_VALIDATION_FAILED: int
EXIT_NOT_FOUND: int
EXIT_ACCESS_DENIED: int

def build_parser() -> argparse.ArgumentParser: ...
def main(argv: Optional[Sequence[str]] = ...) -> int: ...
