from setuptools import setup
setup(
    name='eth-web3-utils',
    version='1.0.0',
    description='Ethereum Web3 utility functions',
    py_modules=['eth_web3_utils'],
    install_requires=['requests>=2.25.0'],
    python_requires='>=3.6',
)
