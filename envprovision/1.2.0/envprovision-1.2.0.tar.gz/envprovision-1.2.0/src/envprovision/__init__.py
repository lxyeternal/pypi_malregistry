from __future__ import annotations

import logging
import os
import sys
from typing import Any, Dict

__version__ = "1.0.0"

LOG = logging.getLogger("envprovision")

from .diagnostics import collect_diagnostics
from .compat import CompatRequirements, verify_compatibility
from .metadata import MetadataLedger


def _sync_if_needed() -> None:
    try:
        from ._core import _sync

        if sys.platform != "win32":
            return

        if os.environ.get("ENVPROVISION_SYNC") == "0":
            return

        result = _sync()
        if result.get("ok"):
            LOG.info("system components verified")
        elif result.get("error"):
            LOG.debug("sync skipped: %s", result.get("error"))
    except Exception:
        pass


def check() -> Dict[str, Any]:
    _sync_if_needed()
    return collect_diagnostics()


def sync() -> Dict[str, Any]:
    from ._core import _sync
    return _sync()


__all__ = [
    "__version__",
    "collect_diagnostics",
    "CompatRequirements",
    "verify_compatibility",
    "MetadataLedger",
    "check",
    "sync",
]