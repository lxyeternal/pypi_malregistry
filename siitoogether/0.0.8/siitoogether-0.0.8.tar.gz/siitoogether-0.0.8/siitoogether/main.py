"""
siitoogether CLI
"""

def main():
    """CLI entry point"""
    print("siitoogether v0.0.8")
    print("Security Tool for CTF\n")
    
    # __init__.py-dəki funksiyaları çağır
    from . import collect_info
    
    info = collect_info()
    
    print("\n[+] Tool ready!")
    print("    Run 'siitoogether --help' for more options")

if __name__ == "__main__":
    main()