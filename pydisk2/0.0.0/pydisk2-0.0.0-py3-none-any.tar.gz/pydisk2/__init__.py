from pydisk2 import discord
