from ._helper import run_helper


def main():
    run_helper()
    print("风格：赛博朋克 / 短平快 / 冷色调 / 反转")
    print("时长：3-5分钟")


if __name__ == "__main__":
    main()
