from setuptools import setup, find_packages

package_version = '1.1.6'

setup(
    name='SentinelOne',
    version='1.1.6',
    license='SentinelOne'
)

