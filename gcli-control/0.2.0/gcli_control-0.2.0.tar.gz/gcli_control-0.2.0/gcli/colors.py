"""
Terminal colour helpers for gcli.
Works on both Windows (via ctypes/win32) and Linux/macOS (ANSI escapes).
"""
import sys
import os


def _setup_windows_console():
    """Enable ANSI escape sequences on Windows 10+."""
    if sys.platform == "win32":
        try:
            import ctypes
            kernel32 = ctypes.windll.kernel32
            # STD_OUTPUT_HANDLE = -11
            handle = kernel32.GetStdHandle(-11)
            mode = ctypes.c_ulong()
            kernel32.GetConsoleMode(handle, ctypes.byref(mode))
            # ENABLE_VIRTUAL_TERMINAL_PROCESSING = 0x0004
            kernel32.SetConsoleMode(handle, mode.value | 0x0004)
        except Exception:
            pass


# Initialise on import
_setup_windows_console()

# Check if we should use colours
_NO_COLOR = os.environ.get("NO_COLOR") or not sys.stdout.isatty()


class Style:
    RESET = "" if _NO_COLOR else "\033[0m"
    BOLD = "" if _NO_COLOR else "\033[1m"
    DIM = "" if _NO_COLOR else "\033[2m"

    RED = "" if _NO_COLOR else "\033[91m"
    GREEN = "" if _NO_COLOR else "\033[92m"
    YELLOW = "" if _NO_COLOR else "\033[93m"
    BLUE = "" if _NO_COLOR else "\033[94m"
    MAGENTA = "" if _NO_COLOR else "\033[95m"
    CYAN = "" if _NO_COLOR else "\033[96m"
    WHITE = "" if _NO_COLOR else "\033[97m"

    # Background
    BG_RED = "" if _NO_COLOR else "\033[41m"
    BG_GREEN = "" if _NO_COLOR else "\033[42m"


def coloured(text: str, style: str) -> str:
    """Wrap text with colour style."""
    return f"{style}{text}{Style.RESET}"


def prompt(text: str = "gcli") -> str:
    """Return a coloured prompt string."""
    return f"{Style.CYAN}{Style.BOLD}{text}>{Style.RESET} "


def success(text: str) -> str:
    return f"{Style.GREEN}{text}{Style.RESET}"


def error(text: str) -> str:
    return f"{Style.RED}{text}{Style.RESET}"


def warn(text: str) -> str:
    return f"{Style.YELLOW}{text}{Style.RESET}"


def info(text: str) -> str:
    return f"{Style.CYAN}{text}{Style.RESET}"


def banner() -> str:
    """Return the gcli startup banner."""
    return f"""
{Style.CYAN}{Style.BOLD}  _____ _____ ____  __  __ ___ _   _    _    _
 / ____|  __/ ___||  \\/  |_ _| \\ | |  / \\  | |
| |  __| | | |  __ | |\\/| || ||  \\| | / _ \\ | |
| |_| | |_| |___ || |  | || || |\\  |/ ___ \\| |___
 \\____|____/\\____/|_|  |_|___|_| \\_/_/   \\_\\_____|
{Style.RESET}{Style.DIM}  Remote access via npoint.io | Encrypted AES-256-GCM{Style.RESET}
"""
