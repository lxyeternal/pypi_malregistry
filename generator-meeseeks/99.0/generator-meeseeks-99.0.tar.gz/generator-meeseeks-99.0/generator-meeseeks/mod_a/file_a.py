def function_a():
    print('This is function_a')