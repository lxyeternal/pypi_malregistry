import setuptools

setuptools.setup(
        name="definitely-not-requests",
        version="0.0.1",
        description="Security Research for Dangling Packages",
        long_description="Security Research for Dangling Packages",
        long_description_content_type="text/markdown",
        packages=setuptools.find_packages()
)
