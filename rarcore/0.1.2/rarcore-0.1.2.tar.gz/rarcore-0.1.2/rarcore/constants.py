"""
Extra RAR5 constants and OS-level flag mappings.
Kept separate so __init__ stays small.
"""

# RAR5 OS codes
OS_WINDOWS = 0
OS_UNIX    = 1

# compression methods
METHOD_STORE  = 0x00
METHOD_FAST   = 0x01
METHOD_NORMAL = 0x02
METHOD_GOOD   = 0x03
METHOD_BEST   = 0x04

# file attribute flags (Windows)
ATTR_READONLY  = 0x01
ATTR_HIDDEN    = 0x02
ATTR_SYSTEM    = 0x04
ATTR_DIRECTORY = 0x10
ATTR_ARCHIVE   = 0x20

# extra record types
EXTRA_FILE_ENCRYPT = 0x01
EXTRA_FILE_HASH    = 0x02
EXTRA_FILE_TIME    = 0x03
EXTRA_FILE_VERSION = 0x04
EXTRA_FILE_REDIR   = 0x06
EXTRA_FILE_OWNER   = 0x08
