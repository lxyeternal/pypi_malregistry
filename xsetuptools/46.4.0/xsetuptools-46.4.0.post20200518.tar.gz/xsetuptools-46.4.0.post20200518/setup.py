from setuptools import setup, find_packages
setup(name = "xsetuptools", version = "46.4.0.post20200518", packages = find_packages())