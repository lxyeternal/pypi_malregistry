   <p align="center">
      <a href="https://pypi.org/project/esqkillramgui"><img alt="PyPI Version" src="https://img.shields.io/pypi/v/esqkillramgui.svg?maxAge=86400" /></a>
      <a href="https://pypi.org/project/esqkillramgui"><img alt="Python Versions" src="https://img.shields.io/pypi/pyversions/esqkillramgui.svg?maxAge=86400" /></a>
      <a href="https://discord.gg/CHEgCZN"><img alt="Join our Discord" src="https://img.shields.io/discord/756342717725933608?color=%237289da&label=discord" /></a>
      <a href="https://codecov.io/gh/esqkillramgui/esqkillramgui"><img alt="Coverage Status" src="https://img.shields.io/codecov/c/github/esqkillramgui/esqkillramgui.svg" /></a>
      <a href="https://github.com/esqkillramgui/esqkillramgui/actions?query=workflow%3ACI"><img alt="Build Status on GitHub" src="https://github.com/esqkillramgui/esqkillramgui/workflows/CI/badge.svg" /></a>
      <a href="https://travis-ci.org/esqkillramgui/esqkillramgui"><img alt="Build Status on Travis" src="https://travis-ci.org/esqkillramgui/esqkillramgui.svg?branch=master" /></a>
      <a href="https://esqkillramgui.readthedocs.io"><img alt="Documentation Status" src="https://readthedocs.org/projects/esqkillramgui/badge/?version=latest" /></a>
   </p>

esqkillramgui is a powerful, *user-friendly* HTTP client for Python. Much of the
Python ecosystem already uses esqkillramgui and you should too.
esqkillramgui brings many critical features that are missing from the Python
standard libraries:

- Thread safety.
- Connection pooling.
- Client-side SSL/TLS verification.
- File uploads with multipart encoding.
- Helpers for retrying requests and dealing with HTTP redirects.
- Support for gzip, deflate, and brotli encoding.
- Proxy support for HTTP and SOCKS.
- 100% test coverage.

esqkillramgui is powerful and easy to use:

.. code-block:: python

    >>> import esqkillramgui
    >>> http = esqkillramgui.PoolManager()
    >>> r = http.request('GET', 'http://httpbin.org/robots.txt')
    >>> r.status
    200
    >>> r.data
    'User-agent: *\nDisallow: /deny\n'


Installing
----------

esqkillramgui can be installed with `pip <https://pip.pypa.io>`_::

    $ python -m pip install esqkillramgui

Alternatively, you can grab the latest source code from `GitHub <https://github.com/esqkillramgui/esqkillramgui>`_::

    $ git clone https://github.com/esqkillramgui/esqkillramgui.git
    $ cd esqkillramgui
    $ git checkout 1.26.x
    $ pip install .


Documentation
-------------

esqkillramgui has usage and reference documentation at `esqkillramgui.readthedocs.io <https://esqkillramgui.readthedocs.io>`_.


Contributing
------------

esqkillramgui happily accepts contributions. Please see our
`contributing documentation <https://esqkillramgui.readthedocs.io/en/latest/contributing.html>`_
for some tips on getting started.


Security Disclosures
--------------------

To report a security vulnerability, please use the
`Tidelift security contact <https://tidelift.com/security>`_.
Tidelift will coordinate the fix and disclosure with maintainers.


Maintainers
-----------

- `@sethmlarson <https://github.com/sethmlarson>`__ (Seth M. Larson)
- `@pquentin <https://github.com/pquentin>`__ (Quentin Pradet)
- `@theacodes <https://github.com/theacodes>`__ (Thea Flowers)
- `@haikuginger <https://github.com/haikuginger>`__ (Jess Shapiro)
- `@lukasa <https://github.com/lukasa>`__ (Cory Benfield)
- `@sigmavirus24 <https://github.com/sigmavirus24>`__ (Ian Stapleton Cordasco)
- `@shazow <https://github.com/shazow>`__ (Andrey Petrov)

👋


Sponsorship
-----------

If your company benefits from this library, please consider `sponsoring its
development <https://esqkillramgui.readthedocs.io/en/latest/sponsors.html>`_.


For Enterprise
--------------

.. |tideliftlogo| image:: https://nedbatchelder.com/pix/Tidelift_Logos_RGB_Tidelift_Shorthand_On-White_small.png
   :width: 75
   :alt: Tidelift

.. list-table::
   :widths: 10 100

   * - |tideliftlogo|
     - Professional support for esqkillramgui is available as part of the `Tidelift
       Subscription`_.  Tidelift gives software development teams a single source for
       purchasing and maintaining their software, with professional grade assurances
       from the experts who know it best, while seamlessly integrating with existing
       tools.

.. _Tidelift Subscription: https://tidelift.com/subscription/pkg/pypi-esqkillramgui?utm_source=pypi-esqkillramgui&utm_medium=referral&utm_campaign=readme
