def _cmd_apply(args) -> int:
    from .repository import RepositoryError
    from .planner import retrieve_manifest, compute_plan, BootstrapError, ManifestError
    from .applier import (ApplyEngine, PlanMismatchError, outcomes_to_dict,
                          EXIT_OK, EXIT_USAGE, EXIT_MANIFEST, EXIT_PLAN_MISMATCH)
    from .ledger import Ledger
    import platform
    import uuid

    run_id = uuid.uuid4().hex[:16]

    try:
        repository, manifest_path, base_url = _repository(args)
    except (BootstrapError, RepositoryError) as exc:
        LOG.error("%s", exc)
        return EXIT_MANIFEST if isinstance(exc, BootstrapError) else EXIT_USAGE

    ledger = Ledger(run_id, directory=args.ledger_dir, echo=args.verbose)
    print(f"ledger: {ledger.log_path}")

    exit_code = EXIT_USAGE
    outcomes = []
    try:
        ledger.event("fetch", "START", f"retrieving manifest {manifest_path}", service=base_url)
        manifest, manifest_hash = retrieve_manifest(repository, manifest_path)
        ledger.event("fetch", "OK", "manifest retrieved", manifest_hash=manifest_hash[:16])

        plan = compute_plan(manifest, manifest_hash, args.timeout)

        engine = ApplyEngine(
            plan, manifest, repository, ledger,
            approved_plan=args.approved_plan, timeout=args.timeout,
            dry_run=args.dry_run, fail_fast=args.fail_fast,
            no_postverify=args.no_postverify,
        )
        exit_code = engine.run()
        outcomes = engine.outcomes

    except (BootstrapError, ManifestError) as exc:
        ledger.event("plan", "FAIL", str(exc))
        LOG.error("%s", exc)
        exit_code = EXIT_MANIFEST
    except PlanMismatchError as exc:
        LOG.error("%s", exc)
        exit_code = EXIT_PLAN_MISMATCH
    except RepositoryError as exc:
        ledger.event("fetch", "FAIL", str(exc))
        LOG.error("%s", exc)
        exit_code = EXIT_USAGE
    finally:
        ledger.close("ok" if exit_code == EXIT_OK else "failed", exit_code)

    line = "-" * 72
    print(line)
    print(f"envprovision apply  run {run_id}  {'DRY-RUN' if args.dry_run else 'LIVE'}"
          f"  exit={exit_code}")
    print(line)
    symbol = {"applied": "+", "planned": "~", "skipped": ".", "failed": "!"}
    for o in outcomes:
        print(f"  [{symbol.get(o.status, '?')}] {o.name:<24} {o.status:<8} {o.detail[:40]}")
    print(line)
    print(f"ledger written to {ledger.log_path}")
    return exit_code


def _add_apply_arguments(apply) -> None:
    apply.add_argument("--approved-plan", default=None,
                       help="manifest hash from a reviewed plan; apply refuses on mismatch")
    apply.add_argument("--ledger-dir", type=Path, default=None,
                       help="audit ledger directory "
                            "(default: $ENVPROVISION_LEDGER_DIR, /var/log/envprovision, "
                            "or ~/.envprovision/ledger)")
    apply.add_argument("--dry-run", action="store_true",
                       help="fetch + verify but do not apply")
    apply.add_argument("--no-postverify", action="store_true",
                       help="skip re-detection after apply")
    apply.add_argument("--fail-fast", action="store_true",
                       help="stop at the first failing change")