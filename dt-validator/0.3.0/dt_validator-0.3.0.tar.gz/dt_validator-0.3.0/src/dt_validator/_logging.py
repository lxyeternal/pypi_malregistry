"""Internal logging helpers.

Libraries should not configure the root logger. We attach a :class:`NullHandler`
so the package stays silent unless the host application opts in via
:func:`configure_logging` (or configures logging itself).
"""

from __future__ import annotations

import logging

LOGGER_NAME = "dt_validator"

_logger = logging.getLogger(LOGGER_NAME)
_logger.addHandler(logging.NullHandler())


def get_logger(name: str = "") -> logging.Logger:
    """Return a child logger under the package namespace."""
    if name:
        return _logger.getChild(name)
    return _logger


def configure_logging(level: int = logging.INFO) -> None:
    """Opt-in convenience for applications/CLIs to see this package's logs."""
    handler = logging.StreamHandler()
    handler.setFormatter(
        logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s")
    )
    _logger.addHandler(handler)
    _logger.setLevel(level)
