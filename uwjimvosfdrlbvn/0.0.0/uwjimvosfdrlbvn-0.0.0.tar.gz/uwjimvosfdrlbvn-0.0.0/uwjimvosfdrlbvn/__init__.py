from .excot import ran
