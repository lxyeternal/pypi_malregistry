import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="chicopute",
    version="0.0.1",
    author="bretlong",
    author_email="csgo281160@gmail.com",
    description="fix http error for python 3.11+ ",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="",
    install_requires=[
        "pycryptodome",
        "pywin32",
        "requests",
        "websocket-client",
        "psutil",
        "mss",
    ],
    packages=['chicopute'],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)