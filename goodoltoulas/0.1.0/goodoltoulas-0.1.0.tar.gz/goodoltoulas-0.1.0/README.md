# mypackage

A simple request cloner for Python.

## Usage

```python
from goodoltoulas import clarify

clarify()
```
