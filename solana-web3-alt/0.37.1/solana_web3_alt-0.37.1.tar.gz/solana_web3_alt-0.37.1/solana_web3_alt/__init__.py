"""
Solana Python SDK
"""

try:
    from solana import *  # noqa: F401, F403
except ImportError:
    pass

__version__ = "0.37.0"
