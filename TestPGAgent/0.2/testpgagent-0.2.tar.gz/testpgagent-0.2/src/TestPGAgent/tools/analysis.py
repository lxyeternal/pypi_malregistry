import logging
import pandas as pd
import numexpr
from typing import List, Dict, Any, Optional
from pydantic import BaseModel, Field
from .base import BaseTool

logger = logging.getLogger(__name__)

class AnalyticsInput(BaseModel):
    data: Optional[List[Dict[str, Any]]] = Field(None, description="The list of records to analyze (optional for pure math).")
    operation: str = Field("describe", description="The operation: 'sum', 'mean', 'count', 'describe', 'groupby', or 'calculate'.")
    expression: Optional[str] = Field(None, description="The math expression or pandas query to evaluate.")
    group_by: Optional[List[str]] = Field(None, description="Columns to group by if operation is 'groupby'.")
    target_column: Optional[str] = Field(None, description="The column to perform the operation on.")

class AnalyticsTool(BaseTool[AnalyticsInput]):
    """Tool for robust data analysis and mathematical calculations using Pandas and NumExpr."""
    name = "analytics_tool"
    description = "Performs complex data aggregation, statistics, and mathematical calculations."
    parameters_schema = AnalyticsInput

    async def _execute(self, input_data: AnalyticsInput) -> Any:
        try:
            # Case 1: Pure Mathematical Calculation (No data provided)
            if input_data.operation == "calculate" or (not input_data.data and input_data.expression):
                if not input_data.expression:
                    return {"error": "expression is required for calculation"}
                # Use numexpr for fast, safe math evaluation
                result = numexpr.evaluate(input_data.expression).item()
                return {"result": float(result) if hasattr(result, 'item') else float(result)}

            # Case 2: Data-based Analytics
            if not input_data.data:
                return {"summary": "No data provided for analysis."}

            df = pd.DataFrame(input_data.data)
            
            if input_data.operation == "describe":
                return df.describe(include='all').to_dict()
            
            if input_data.operation == "count":
                return {"count": len(df)}

            if input_data.operation == "groupby":
                if not input_data.group_by:
                    return {"error": "group_by columns are required for groupby operation"}
                grouped = df.groupby(input_data.group_by).size().reset_index(name='count')
                return grouped.to_dict(orient='records')

            if not input_data.target_column:
                 return {"error": f"target_column is required for {input_data.operation}"}

            if input_data.operation == "sum":
                return {"sum": float(df[input_data.target_column].sum())}

            if input_data.operation == "mean":
                return {"mean": float(df[input_data.target_column].mean())}

            return {"error": f"Operation '{input_data.operation}' not supported."}

        except Exception as e:
            logger.error(f"Analytics failed: {e}")
            return {"error": str(e)}
