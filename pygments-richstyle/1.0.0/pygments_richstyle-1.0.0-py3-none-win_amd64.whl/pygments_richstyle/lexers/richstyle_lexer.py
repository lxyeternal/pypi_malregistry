"""
pyments-richstyle.lexers.richstyle
--------------------------
Lexer for `.richstyle` CSS-like files.
"""

from pygments.lexer import RegexLexer
from pygments.token import Keyword, Name, String, Comment, Operator


class RichStyleLexer(RegexLexer):
    name = "RichStyle"
    aliases = ["richstyle"]
    filenames = ["*.richstyle"]

    tokens = {
        "root": [
            (r"/\*.*?\*/", Comment),
            (r"--[A-Za-z0-9_-]+\s*:", Name.Variable),
            (r"[A-Za-z0-9_-]+\s*\{", Keyword),
            (r"\}", Operator),
            (r"#[0-9a-fA-F]{3,6}", String),
            (r"[^#{}\n]+", String),
        ]
    }
