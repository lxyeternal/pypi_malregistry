# ☀️ sankislayer

**Sun Breathing Swarm** — A high-performance, concurrent Telegram swarm bot engine built on python-telegram-bot (v20.x+) and asyncio.

## 🌟 Key Features
* ⚔️ **Sun Breathing loops:** Coordinate group title loops at lightning speeds (0.003s delay).
* 🎵 **Direct Spotify Downloader:** Built-in fast Spotify MP3/visual media downloader.
* 🛡️ **Autonomous swarm promotion:** Self-promotes bot administrators within the swarm.
* 📂 **OSINT Social Lookup Panel:** `/13thform` integrates custom workers for Instagram, Facebook, Snapchat, GitHub, and phone traces.
* 📊 **Swarm Health Registry:** Dynamic grid monitoring of bot statuses and latencies.

## 🚀 Installation & Setup

```bash
pip install sankislayer
```

Or install from source:
```bash
git clone https://github.com/yourusername/sankislayer
cd sankislayer
pip install .
```

## ⚙️ Running the Swarm
You can run the bot directly using the command line script:
```bash
sankislayer
```
Make sure to configure your bot tokens and owner ID inside the package configuration.
