from setuptools import setup, find_packages
setup(name = "xsetuptools", version = "49.6.0.post20200814", packages = find_packages())