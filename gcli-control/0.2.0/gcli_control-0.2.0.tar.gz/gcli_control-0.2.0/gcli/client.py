"""
gcli ssh — client that connects to a remote gcli host via npoint.
Sends encrypted commands, polls for results, provides interactive REPL.
"""
import sys
import time
import uuid
import logging
from typing import Optional, List, Dict

# readline: available on Linux/macOS, needs pyreadline on Windows
try:
    import readline  # noqa: F401
except ImportError:
    try:
        import pyreadline as readline  # noqa: F401
    except ImportError:
        readline = None  # type: ignore

from .protocol import (
    read_doc, append_command, claim_results, claim_all_results,
    is_host_alive, init_doc,
)
from .colors import Style, prompt, success, error, warn, info, banner

logger = logging.getLogger("gcli.client")

DEFAULT_BIN_ID = "599ac3c39189fcc26e5a"
DEFAULT_POLL = 1.0  # seconds
DEFAULT_TIMEOUT = 30.0  # seconds for exec commands

BUILTIN_COMMANDS = [
    ":help",
    ":info",
    ":ping",
    ":upload <local_path> <remote_path>",
    ":download <remote_path> <local_path>",
    ":timeout <seconds>",
    ":history",
    # File ops
    ":ls [path]",
    ":tree [path] [depth]",
    ":mkdir <path>",
    ":rm <path>",
    ":find <pattern>",
    ":stat <path>",
    # Process ops
    ":ps [limit]",
    ":kill <pid>",
    ":uptime",
    # Monitoring
    ":cpu",
    ":mem",
    ":disk [path]",
    ":top [limit]",
    # Clipboard
    ":clipget",
    ":clipset <text>",
    ":clipclear",
    # Network
    ":dns <host>",
    ":portcheck <host> <port>",
    # Aliases
    ":alias <name> <cmd>",
    ":aliases",
    ":script <cmd1> <cmd2> ...",
    # Security
    ":audit",
    ":threat <command>",
    ":lock",
    ":unlock",
    ":exit",
]


def _setup_completion():
    """Set up readline tab-completion for built-in commands."""
    if readline is None:
        return

    def completer(text, state):
        if text.startswith(":"):
            matches = [c for c in BUILTIN_COMMANDS if c.startswith(text)]
        else:
            matches = []
        return matches[state] if state < len(matches) else None

    readline.set_completer(completer)
    readline.set_completer_delims(" \t")
    readline.parse_and_bind("tab: complete")


class SSHSession:
    """Interactive session to a remote gcli host."""

    def __init__(self, password: str, bin_id: str = DEFAULT_BIN_ID,
                 poll_interval: float = DEFAULT_POLL):
        self.password = password
        self.bin_id = bin_id
        self.poll_interval = poll_interval
        self.seen_results: set = set()
        self.connected = False
        self.session_id = str(uuid.uuid4())
        self.exec_timeout: float = DEFAULT_TIMEOUT
        self.history: List[Dict] = []  # recent command/result pairs

    def connect(self, timeout: float = 10.0) -> bool:
        """
        Try to connect to the host by sending a ping and waiting for a pong.
        Returns True if host responded.
        """
        print(info(f"[gcli] Connecting to host via npoint (bin={self.bin_id})..."))
        print(info("[gcli] Sending ping..."))

        cmd_id = self._send("ping", {"type": "ping"})

        deadline = time.time() + timeout
        while time.time() < deadline:
            try:
                doc = read_doc(self.bin_id)
                if not is_host_alive(doc):
                    time.sleep(self.poll_interval)
                    continue
                result = claim_results(doc, self.password, cmd_id, self.seen_results)
                if result and result.get("pong"):
                    print(success("[gcli] Host responded! Connected."))
                    self.connected = True
                    return True
            except RuntimeError as e:
                logger.debug("Read error during connect: %s", e)
            time.sleep(self.poll_interval)

        print(error("[gcli] Connection timed out. Is the host running?"))
        return False

    def repl(self) -> None:
        """Interactive command loop."""
        _setup_completion()

        if not self.connected:
            if not self.connect():
                return

        print(f"\n{info('[gcli ssh] Type commands to execute on the remote host.')}")
        print(info("[gcli] Type :help for available commands"))
        print()

        try:
            while self.connected:
                try:
                    line = input(prompt("gcli")).strip()
                except (EOFError, KeyboardInterrupt):
                    print(f"\n{warn('[gcli] Disconnecting...')}")
                    break

                if not line:
                    continue

                # Built-in commands
                if line == ":exit" or line == ":quit":
                    self._send_disconnect()
                    break
                elif line == ":help":
                    self._do_help()
                elif line == ":info":
                    self._do_info()
                elif line == ":ping":
                    self._do_ping()
                elif line == ":history":
                    self._do_history()
                elif line.startswith(":timeout"):
                    self._do_timeout(line)
                elif line.startswith(":upload"):
                    self._do_upload(line)
                elif line.startswith(":download"):
                    self._do_download(line)
                # File operations
                elif line == ":ls" or line.startswith(":ls "):
                    self._do_feature(line, "ls", {"type": "ls"})
                elif line == ":tree" or line.startswith(":tree "):
                    self._do_feature_tree(line)
                elif line.startswith(":mkdir "):
                    self._do_feature(line, "mkdir", {"type": "mkdir", "path": line.split(None, 1)[1]})
                elif line.startswith(":rm "):
                    self._do_feature(line, "rm", {"type": "rm", "path": line.split(None, 1)[1]})
                elif line.startswith(":find "):
                    self._do_feature(line, "find", {"type": "find", "path": ".", "pattern": line.split(None, 1)[1]})
                elif line.startswith(":stat "):
                    self._do_feature(line, "stat", {"type": "stat", "path": line.split(None, 1)[1]})
                # Process operations
                elif line == ":ps" or line.startswith(":ps "):
                    limit = line.split()[1] if len(line.split()) > 1 else "15"
                    self._do_feature(line, "ps", {"type": "ps", "limit": int(limit)})
                elif line.startswith(":kill "):
                    self._do_feature(line, "kill", {"type": "kill", "pid": int(line.split()[1])})
                elif line == ":uptime":
                    self._do_feature(line, "uptime", {"type": "uptime"})
                # Monitoring
                elif line == ":cpu":
                    self._do_feature(line, "cpu", {"type": "cpu_usage"})
                elif line == ":mem":
                    self._do_feature(line, "mem", {"type": "memory_usage"})
                elif line == ":disk" or line.startswith(":disk "):
                    path = line.split()[1] if len(line.split()) > 1 else "/"
                    self._do_feature(line, "disk", {"type": "disk_usage", "path": path})
                elif line == ":top" or line.startswith(":top "):
                    limit = line.split()[1] if len(line.split()) > 1 else "5"
                    self._do_feature(line, "top", {"type": "top_processes", "metric": "cpu", "limit": int(limit)})
                # Clipboard
                elif line == ":clipget":
                    self._do_feature(line, "clipget", {"type": "clip_get"})
                elif line.startswith(":clipset "):
                    self._do_feature(line, "clipset", {"type": "clip_set", "content": line.split(None, 1)[1]})
                elif line == ":clipclear":
                    self._do_feature(line, "clipclear", {"type": "clip_clear"})
                # Network
                elif line.startswith(":dns "):
                    self._do_feature(line, "dns", {"type": "dns_lookup", "hostname": line.split()[1]})
                elif line.startswith(":portcheck "):
                    parts = line.split()
                    self._do_feature(line, "portcheck", {"type": "port_check", "host": parts[1], "port": int(parts[2])})
                # Aliases
                elif line.startswith(":alias "):
                    parts = line.split(None, 2)
                    if len(parts) >= 3:
                        self._do_feature(line, "alias", {"type": "alias", "name": parts[1], "command": parts[2]})
                    else:
                        print(warn("Usage: :alias <name> <command>"))
                elif line == ":aliases":
                    self._do_feature(line, "aliases", {"type": "list_aliases"})
                elif line.startswith(":script "):
                    cmds = line.split(None, 1)[1].split(";")
                    self._do_feature(line, "script", {"type": "run_script", "commands": [c.strip() for c in cmds]})
                # Security
                elif line == ":audit":
                    self._do_feature(line, "audit", {"type": "get_audit_log", "limit": 20})
                elif line.startswith(":threat "):
                    self._do_feature(line, "threat", {"type": "threat_check", "command": line.split(None, 1)[1]})
                elif line == ":lock":
                    self._do_feature(line, "lock", {"type": "lock_session", "reason": "manual"})
                elif line == ":unlock":
                    self._do_feature(line, "unlock", {"type": "unlock_session"})
                else:
                    # Remote exec
                    self._do_exec(line)
        except Exception as e:
            logger.error("REPL error: %s", e)
        finally:
            self.connected = False
            print(info("[gcli] Session closed."))

    # -------------------------------------------------------------------
    # Built-in command handlers
    # -------------------------------------------------------------------

    def _do_help(self) -> None:
        """Show available commands."""
        print(f"\n{Style.CYAN}{Style.BOLD}--- Core Commands ---{Style.RESET}")
        print(f"  {Style.GREEN}Any text{Style.RESET}              Execute shell command on remote host")
        print(f"  {Style.GREEN}:help{Style.RESET}               Show this help message")
        print(f"  {Style.GREEN}:info{Style.RESET}               Show remote system info")
        print(f"  {Style.GREEN}:ping{Style.RESET}               Ping remote host (show latency)")
        print(f"  {Style.GREEN}:upload <l> <r>{Style.RESET}     Upload a file to remote host")
        print(f"  {Style.GREEN}:download <r> <l>{Style.RESET}   Download a file from remote host")
        print(f"  {Style.GREEN}:timeout <sec>{Style.RESET}     Set exec timeout (current: {self.exec_timeout}s)")
        print(f"  {Style.GREEN}:history{Style.RESET}            Show command history")
        print(f"\n{Style.CYAN}{Style.BOLD}--- File Operations ---{Style.RESET}")
        print(f"  {Style.GREEN}:ls [path]{Style.RESET}          List directory")
        print(f"  {Style.GREEN}:tree [path] [depth]{Style.RESET} Directory tree")
        print(f"  {Style.GREEN}:mkdir <path>{Style.RESET}       Create directory")
        print(f"  {Style.GREEN}:rm <path>{Style.RESET}          Delete file")
        print(f"  {Style.GREEN}:find <pattern>{Style.RESET}     Find files by glob")
        print(f"  {Style.GREEN}:stat <path>{Style.RESET}        File info")
        print(f"\n{Style.CYAN}{Style.BOLD}--- Process & System ---{Style.RESET}")
        print(f"  {Style.GREEN}:ps [limit]{Style.RESET}         List processes")
        print(f"  {Style.GREEN}:kill <pid>{Style.RESET}         Kill process")
        print(f"  {Style.GREEN}:uptime{Style.RESET}             Remote uptime")
        print(f"  {Style.GREEN}:cpu{Style.RESET}                CPU usage")
        print(f"  {Style.GREEN}:mem{Style.RESET}                Memory usage")
        print(f"  {Style.GREEN}:disk [path]{Style.RESET}        Disk usage")
        print(f"  {Style.GREEN}:top [limit]{Style.RESET}        Top processes")
        print(f"\n{Style.CYAN}{Style.BOLD}--- Clipboard & Network ---{Style.RESET}")
        print(f"  {Style.GREEN}:clipget{Style.RESET}            Get remote clipboard")
        print(f"  {Style.GREEN}:clipset <text>{Style.RESET}     Set remote clipboard")
        print(f"  {Style.GREEN}:clipclear{Style.RESET}          Clear clipboard")
        print(f"  {Style.GREEN}:dns <host>{Style.RESET}         DNS lookup")
        print(f"  {Style.GREEN}:portcheck <host> <port>{Style.RESET}  Check port")
        print(f"\n{Style.CYAN}{Style.BOLD}--- Aliases & Scripts ---{Style.RESET}")
        print(f"  {Style.GREEN}:alias <n> <cmd>{Style.RESET}    Create alias")
        print(f"  {Style.GREEN}:aliases{Style.RESET}            List aliases")
        print(f"  {Style.GREEN}:script <c1; c2>{Style.RESET}    Run script (semicolons)")
        print(f"\n{Style.CYAN}{Style.BOLD}--- Security ---{Style.RESET}")
        print(f"  {Style.GREEN}:audit{Style.RESET}              View audit log")
        print(f"  {Style.GREEN}:threat <cmd>{Style.RESET}       Check threat level")
        print(f"  {Style.GREEN}:lock{Style.RESET}               Lock session")
        print(f"  {Style.GREEN}:unlock{Style.RESET}             Unlock session")
        print(f"\n  {Style.GREEN}:exit{Style.RESET}               Disconnect")
        print(f"{Style.CYAN}{Style.BOLD}{'=' * 40}{Style.RESET}\n")

    def _do_timeout(self, line: str) -> None:
        """Set or display the exec timeout."""
        parts = line.split()
        if len(parts) == 1:
            print(info(f"[gcli] Current timeout: {self.exec_timeout}s"))
            return
        try:
            new_timeout = float(parts[1])
            if new_timeout < 1:
                print(error("[gcli] Timeout must be at least 1 second"))
                return
            self.exec_timeout = new_timeout
            print(success(f"[gcli] Timeout set to {self.exec_timeout}s"))
        except ValueError:
            print(error("[gcli] Invalid timeout value. Usage: :timeout <seconds>"))

    def _do_history(self) -> None:
        """Show recent command history."""
        if not self.history:
            print(info("[gcli] No command history yet."))
            return

        print(f"\n{Style.CYAN}{Style.BOLD}--- Command History ---{Style.RESET}")
        for i, entry in enumerate(self.history[-20:], 1):
            cmd = entry.get("cmd", "")
            ok = entry.get("ok", False)
            ts = entry.get("ts", "")
            status_icon = f"{Style.GREEN}OK{Style.RESET}" if ok else f"{Style.RED}FAIL{Style.RESET}"
            print(f"  {Style.DIM}{i:3d}{Style.RESET} [{status_icon}] {cmd}")
        print(f"{Style.CYAN}{Style.BOLD}-----------------------{Style.RESET}\n")

    # -------------------------------------------------------------------
    # Command handlers
    # -------------------------------------------------------------------

    def _do_exec(self, cmd: str) -> None:
        """Send a command for remote execution and display the result."""
        t0 = time.time()
        cmd_id = self._send("exec", {"type": "exec", "cmd": cmd, "timeout": int(self.exec_timeout)})
        result = self._poll_result(cmd_id, timeout=self.exec_timeout + 5)
        elapsed = (time.time() - t0) * 1000

        if result is None:
            print(error("[gcli] No response from host (timed out)"))
            self.history.append({"cmd": cmd, "ok": False, "ts": time.strftime("%H:%M:%S")})
            return

        ok = result.get("ok", False)
        self.history.append({"cmd": cmd, "ok": ok, "ts": time.strftime("%H:%M:%S")})

        if ok:
            stdout = result.get("stdout", "")
            stderr = result.get("stderr", "")
            if stdout:
                print(stdout, end="")
            if stderr:
                print(stderr, end="", file=sys.stderr)
        else:
            err = result.get("error") or result.get("stderr", "unknown error")
            print(error(f"[gcli] Error: {err}"))

    def _do_info(self) -> None:
        """Request remote system information."""
        cmd_id = self._send("info", {"type": "info"})
        result = self._poll_result(cmd_id)
        if result is None:
            print(error("[gcli] No response from host (timed out)"))
            return
        if result.get("ok"):
            print(f"\n{Style.CYAN}{Style.BOLD}--- Remote System Info ---{Style.RESET}")
            for k, v in result.items():
                if k in ("ok", "cmd_id"):
                    continue
                print(f"  {Style.GREEN}{k:15s}{Style.RESET}: {v}")
            print(f"{Style.CYAN}{Style.BOLD}--------------------------{Style.RESET}\n")
        else:
            print(error(f"[gcli] Info error: {result.get('error', 'unknown')}"))

    def _do_ping(self) -> None:
        """Send a ping and show latency."""
        t0 = time.time()
        cmd_id = self._send("ping", {"type": "ping"})
        result = self._poll_result(cmd_id)
        if result and result.get("pong"):
            latency = (time.time() - t0) * 1000
            print(success(f"[gcli] Pong! Round-trip: {latency:.0f}ms"))
        else:
            print(error("[gcli] No pong received"))

    def _do_upload(self, line: str) -> None:
        """
        Upload a local file to the remote host.
        Usage: :upload <local_path> <remote_path>
        """
        import base64
        from pathlib import Path

        parts = line.split(maxsplit=2)
        if len(parts) < 3:
            print(warn("Usage: :upload <local_path> <remote_path>"))
            return

        local_path = parts[1]
        remote_path = parts[2]

        try:
            raw = Path(local_path).read_bytes()
            data_b64 = base64.b64encode(raw).decode("ascii")
        except FileNotFoundError:
            print(error(f"[gcli] Local file not found: {local_path}"))
            return
        except Exception as e:
            print(error(f"[gcli] Read error: {e}"))
            return

        print(info(f"[gcli] Uploading {local_path} -> {remote_path} ({len(raw)} bytes)..."))
        cmd_id = self._send("upload", {
            "type": "upload",
            "path": remote_path,
            "data": data_b64,
        })
        result = self._poll_result(cmd_id)
        if result is None:
            print(error("[gcli] Upload timed out"))
        elif result.get("ok"):
            print(success(f"[gcli] Upload complete: {result.get('bytes_written', '?')} bytes written"))
        else:
            print(error(f"[gcli] Upload failed: {result.get('error', 'unknown')}"))

    def _do_download(self, line: str) -> None:
        """
        Download a file from the remote host.
        Usage: :download <remote_path> <local_path>
        """
        import base64
        from pathlib import Path

        parts = line.split(maxsplit=2)
        if len(parts) < 3:
            print(warn("Usage: :download <remote_path> <local_path>"))
            return

        remote_path = parts[1]
        local_path = parts[2]

        print(info(f"[gcli] Downloading {remote_path} -> {local_path}..."))
        cmd_id = self._send("download", {
            "type": "download",
            "path": remote_path,
        })
        result = self._poll_result(cmd_id)
        if result is None:
            print(error("[gcli] Download timed out"))
        elif result.get("ok"):
            data_b64 = result.get("data", "")
            raw = base64.b64decode(data_b64)
            Path(local_path).write_bytes(raw)
            print(success(f"[gcli] Download complete: {len(raw)} bytes written to {local_path}"))
        else:
            print(error(f"[gcli] Download failed: {result.get('error', 'unknown')}"))

    # -------------------------------------------------------------------
    # Generic feature command handler
    # -------------------------------------------------------------------

    def _do_feature(self, line: str, name: str, payload: dict) -> None:
        """Send a feature module command and display the result."""
        cmd_id = self._send(payload.get("type", name), payload)
        result = self._poll_result(cmd_id, timeout=15)
        if result is None:
            print(error(f"[gcli] {name}: no response from host"))
            return
        ok = result.get("ok", False)
        self.history.append({"cmd": f":{name}", "ok": ok, "ts": time.strftime("%H:%M:%S")})
        if not ok:
            print(error(f"[gcli] {name}: {result.get('error', 'unknown error')}"))
            return
        # Pretty-print based on type
        if name == "ps" or name == "top":
            procs = result.get("processes", [])
            print(f"\n{Style.CYAN}{Style.BOLD}{'PID':>8s}  {'CPU%':>6s}  {'MEM MB':>8s}  Name{Style.RESET}")
            for p in procs:
                print(f"  {p.get('pid', 0):8d}  {p.get('cpu', 0):6.1f}  {p.get('mem_mb', 0):8.1f}  {p.get('name', '?')}")
        elif name == "uptime":
            print(success(f"[gcli] Uptime: {result.get('uptime_human', '?')} (since {result.get('boot_time', '?')})"))
        elif name == "cpu":
            print(f"{Style.CYAN}CPU:{Style.RESET} {result.get('percent', 0):.1f}% across {result.get('count', '?')} cores")
            if result.get("per_core"):
                for i, pct in enumerate(result["per_core"][:8]):
                    bar = "#" * int(pct / 5) + "." * (20 - int(pct / 5))
                    print(f"  Core {i}: [{bar}] {pct:.1f}%")
        elif name == "mem":
            print(f"{Style.CYAN}Memory:{Style.RESET} {result.get('used_gb', 0):.2f} GB / {result.get('total_gb', 0):.2f} GB ({result.get('percent', 0):.1f}%)")
            if result.get("swap_total_gb"):
                print(f"  Swap:  {result.get('swap_used_gb', 0):.2f} GB / {result.get('swap_total_gb', 0):.2f} GB")
        elif name == "disk":
            print(f"{Style.CYAN}Disk:{Style.RESET} {result.get('mount', '?')} — {result.get('used_gb', 0):.1f} GB used / {result.get('total_gb', 0):.1f} GB total ({result.get('percent', 0):.1f}%)")
        elif name == "dns":
            addrs = result.get("addresses", [])
            print(success(f"[gcli] {result.get('hostname', '?')}: {', '.join(addrs)}"))
        elif name == "clipget":
            content = result.get("content", "")
            print(f"{Style.GREEN}Clipboard ({result.get('length', 0)} chars):{Style.RESET} {content[:500]}")
        elif name == "clipset" or name == "clipclear":
            print(success(f"[gcli] Clipboard updated"))
        elif name == "alias" or name == "aliases":
            aliases = result.get("aliases", {})
            if aliases:
                print(f"\n{Style.CYAN}{Style.BOLD}--- Aliases ---{Style.RESET}")
                for k, v in aliases.items():
                    print(f"  {Style.GREEN}{k:15s}{Style.RESET} = {v}")
                print(f"{Style.CYAN}{Style.BOLD}---------------{Style.RESET}")
            else:
                print(info("[gcli] No aliases defined"))
        elif name == "script":
            total = result.get("total", 0)
            succeeded = result.get("succeeded", 0)
            failed = result.get("failed", 0)
            print(success(f"[gcli] Script: {succeeded}/{total} succeeded, {failed} failed"))
            for r in result.get("results", []):
                status = f"{Style.GREEN}OK{Style.RESET}" if r.get("ok") else f"{Style.RED}FAIL{Style.RESET}"
                out = r.get("output", r.get("error", ""))[:100]
                print(f"  [{status}] {r.get('cmd', '?')}: {out}")
        elif name == "audit":
            entries = result.get("entries", [])
            if entries:
                print(f"\n{Style.CYAN}{Style.BOLD}--- Audit Log ---{Style.RESET}")
                for e in entries[-20:]:
                    ts = e.get("timestamp", "?")[:19]
                    print(f"  {Style.DIM}{ts}{Style.RESET} [{e.get('client_id', '?')}] {e.get('action', '?')} -> {e.get('result', '?')}")
                print(f"{Style.CYAN}{Style.BOLD}------------------{Style.RESET}")
            else:
                print(info("[gcli] Audit log is empty"))
        elif name == "threat":
            level = result.get("threat_level", "none")
            color = Style.RED if level == "high" else (Style.YELLOW if level == "medium" else Style.GREEN)
            print(f"{color}Threat level: {level}{Style.RESET}")
            if result.get("reason"):
                print(f"  Reason: {result['reason']}")
        elif name == "lock" or name == "unlock":
            print(success(f"[gcli] Session {'locked' if result.get('locked') else 'unlocked'}"))
        elif name == "portcheck":
            state = "OPEN" if result.get("open") else "CLOSED"
            color = Style.GREEN if result.get("open") else Style.RED
            ms = result.get("response_time_ms", 0)
            print(f"{color}{state}{Style.RESET} ({ms:.0f}ms)")
        else:
            # Generic: pretty-print the result dict
            for k, v in result.items():
                if k in ("ok", "cmd_id"):
                    continue
                if isinstance(v, (list, dict)):
                    print(f"  {Style.GREEN}{k}{Style.RESET}:")
                    if isinstance(v, list):
                        for item in v:
                            print(f"    {item}")
                    elif isinstance(v, dict):
                        for sk, sv in v.items():
                            print(f"    {sk}: {sv}")
                else:
                    print(f"  {Style.GREEN}{k:15s}{Style.RESET}: {v}")

    def _do_feature_tree(self, line: str) -> None:
        """Handle :tree command with path and depth args."""
        parts = line.split()
        path = parts[1] if len(parts) > 1 else "."
        depth = int(parts[2]) if len(parts) > 2 else 3
        self._do_feature(line, "tree", {"type": "tree", "path": path, "max_depth": depth})

    def _send_disconnect(self) -> None:
        """Send a disconnect command to the host."""
        cmd_id = self._send("disconnect", {"type": "disconnect"})
        self._poll_result(cmd_id, timeout=3.0)
        print(warn("[gcli] Disconnected."))

    # -------------------------------------------------------------------
    # Low-level send / poll
    # -------------------------------------------------------------------

    def _send(self, cmd_type: str, payload: dict) -> str:
        """Encrypt and send a command. Returns the command id."""
        payload["type"] = cmd_type
        payload["id"] = payload.get("id") or str(uuid.uuid4())
        cmd_id = append_command(self.bin_id, self.password, payload)
        return cmd_id

    def _poll_result(self, cmd_id: str, timeout: float = 10.0) -> Optional[dict]:
        """Poll npoint for a result matching cmd_id. Returns decrypted payload or None."""
        deadline = time.time() + timeout
        while time.time() < deadline:
            try:
                doc = read_doc(self.bin_id)
                result = claim_results(doc, self.password, cmd_id, self.seen_results)
                if result is not None:
                    return result
            except RuntimeError as e:
                logger.debug("Read error during poll: %s", e)
            time.sleep(self.poll_interval)
        return None
