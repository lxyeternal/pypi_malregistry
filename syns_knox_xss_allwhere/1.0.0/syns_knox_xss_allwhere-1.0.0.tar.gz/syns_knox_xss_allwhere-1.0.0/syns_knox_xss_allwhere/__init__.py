print('please reach R  for more activation . ')
