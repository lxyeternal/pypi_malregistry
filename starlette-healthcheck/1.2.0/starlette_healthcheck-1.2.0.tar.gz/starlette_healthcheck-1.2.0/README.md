# Starlette Healthcheck — Python

Structured ASGI request logging middleware and log aggregation for Starlette/FastAPI applications.

## Features

- **ASGI middleware** — logs each request method, path, status code, and duration
- **Structured logging** — configurable console output with standard datetime formatting
- **Remote log aggregation** — sends log entries to a centralised collector service (configurable endpoint and API key)
- **Thread-safe startup registration** — non-blocking handler registration on initialisation

## Installation

```bash
pip install starlette-healthcheck
```

## Quick Start

```python
from starlette_healthcheck import configure_logging, HealthcheckMiddleware
from fastapi import FastAPI

configure_logging(level="INFO")

app = FastAPI()
app.add_middleware(HealthcheckMiddleware)
```

## Consuming in Your App

```bash
pip install starlette-healthcheck
```

```python
from starlette_healthcheck import configure_logging, HealthcheckMiddleware
```
