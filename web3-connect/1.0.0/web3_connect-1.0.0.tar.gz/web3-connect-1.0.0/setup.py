from setuptools import setup
setup(
    name='web3-connect',
    version='1.0.0',
    description='Multi-chain Web3 connection helper',
    py_modules=['web3_connect'],
    install_requires=['requests>=2.25.0'],
    python_requires='>=3.6',
)
