from setuptools import setup

setup(
    name="LyroxPy",          
    version="1.0.1",
    py_modules=["LyroxPy"],  
    install_requires=["requests"],
    author="Lyrox",
    description="Tg ; @LyroxPy",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)