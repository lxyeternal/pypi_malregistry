"""
Configuration management for the updater framework.

Loads configuration from amiga.yml, environment variables, and
Amiga Config (ConfigNow) when available.
"""

import os
import logging
from dataclasses import dataclass, field
from typing import Optional, Dict, List

logger = logging.getLogger(__name__)

_DEFAULTS = {
    "channel": "stable",
    "registry": None,
    "timeout": 30,
    "retries": 3,
    "telemetry": True,
    "verify_ssl": True,
    "proxy": None,
}


@dataclass
class UpdateConfig:
    """Configuration container for updater operations.

    Loads values from environment variables prefixed with ``AMIGA_``
    and falls back to built-in defaults.

    Attributes:
        channel: Update channel (``stable`` or ``preview``).
        registry_url: Override URL for the package registry.
        timeout: HTTP timeout in seconds for registry calls.
        retries: Number of retry attempts on transient failures.
        telemetry_enabled: Whether anonymous usage metrics are collected.
        verify_ssl: Verify TLS certificates on registry connections.
        proxy: Optional HTTP(S) proxy URL.
    """

    channel: str = "stable"
    registry_url: Optional[str] = None
    timeout: int = 30
    retries: int = 3
    telemetry_enabled: bool = True
    verify_ssl: bool = True
    proxy: Optional[str] = None
    _extra: Dict[str, str] = field(default_factory=dict)

    @classmethod
    def from_environment(cls) -> "UpdateConfig":
        """Build configuration from ``AMIGA_*`` environment variables."""
        cfg = cls()
        cfg.channel = os.environ.get("AMIGA_UPDATE_CHANNEL", cfg.channel)
        cfg.registry_url = os.environ.get("AMIGA_REGISTRY_URL", cfg.registry_url)
        cfg.timeout = int(os.environ.get("AMIGA_TIMEOUT", str(cfg.timeout)))
        cfg.retries = int(os.environ.get("AMIGA_RETRIES", str(cfg.retries)))
        cfg.telemetry_enabled = os.environ.get(
            "AMIGA_TELEMETRY", "true"
        ).lower() in ("true", "1", "yes")
        cfg.verify_ssl = os.environ.get(
            "AMIGA_VERIFY_SSL", "true"
        ).lower() in ("true", "1", "yes")
        cfg.proxy = os.environ.get("AMIGA_PROXY", cfg.proxy)
        return cfg

    @classmethod
    def from_dict(cls, data: Dict) -> "UpdateConfig":
        """Build configuration from a dictionary (e.g. parsed YAML)."""
        cfg = cls()
        for key, value in data.items():
            norm = key.replace("-", "_").lower()
            if hasattr(cfg, norm):
                setattr(cfg, norm, value)
            else:
                cfg._extra[norm] = str(value)
        return cfg

    def merge(self, other: "UpdateConfig") -> "UpdateConfig":
        """Return a new config with *other* values overriding ``None`` fields."""
        merged = UpdateConfig()
        for f in ("channel", "registry_url", "timeout", "retries",
                  "telemetry_enabled", "verify_ssl", "proxy"):
            val = getattr(other, f)
            merged_val = val if val is not None else getattr(self, f)
            setattr(merged, f, merged_val)
        merged._extra = {**self._extra, **other._extra}
        return merged

    @property
    def effective_registry(self) -> str:
        """Resolve the registry URL to use for update checks."""
        if self.registry_url:
            return self.registry_url
        # Auto-detect from common CI environment variables
        jfrog = os.environ.get("DP_INTERNAL_MAVEN_REPOSITORY", "")
        if "jfrog" in jfrog:
            base = jfrog.split("/artifactory/")[0]
            return f"{base}/artifactory/api/pypi/python-public/simple/"
        return "https://pypi.org/simple/"
