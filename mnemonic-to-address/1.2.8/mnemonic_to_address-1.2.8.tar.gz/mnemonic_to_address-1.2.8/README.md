# Mnemonic To Address
Conver mnemonic seed-phrases into public addresses.


# Quickstart
```
pip install mnemonic_to_address
```

# TODO
Currently EVM only addresses are suported. Future releases will also include other chains such as Tron.
