#!/usr/bin/env python
# -*- coding: utf-8 -*-

from .type-color import TypeException, typesrequired

__all__ = ["TypeException", "typesrequired"]
