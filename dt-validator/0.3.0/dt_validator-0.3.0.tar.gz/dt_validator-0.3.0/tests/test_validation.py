import hashlib

import pytest

from dt_validator.exceptions import (
    ChecksumError,
    ContentTypeError,
    EncodingError,
    ExtensionError,
    FileSizeError,
)
from dt_validator.validation import (
    ValidationPolicy,
    validate_checksum,
    validate_content_type,
    validate_encoding,
    validate_extension,
    validate_not_empty,
    validate_size,
)


# --- extension -------------------------------------------------------------

@pytest.mark.parametrize("key", ["a/b/data.csv", "DATA.CSV", "x.json"])
def test_validate_extension_ok(key):
    validate_extension(key, ["csv", ".json"])


def test_validate_extension_rejects():
    with pytest.raises(ExtensionError):
        validate_extension("file.txt", ["csv", "json"])


def test_validate_extension_requires_allowed_list():
    with pytest.raises(ValueError):
        validate_extension("file.csv", [])


# --- content type ----------------------------------------------------------

def test_validate_content_type_ignores_charset_param():
    validate_content_type("text/plain; charset=utf-8", ["text/plain"])


def test_validate_content_type_rejects():
    with pytest.raises(ContentTypeError):
        validate_content_type("application/pdf", ["text/plain"])


# --- size ------------------------------------------------------------------

def test_validate_size_within_bounds():
    validate_size(500, min_bytes=1, max_bytes=1000)


def test_validate_size_too_large():
    with pytest.raises(FileSizeError):
        validate_size(2000, max_bytes=1000)


def test_validate_size_too_small():
    with pytest.raises(FileSizeError):
        validate_size(0, min_bytes=1)


def test_validate_not_empty():
    validate_not_empty(1)
    with pytest.raises(FileSizeError):
        validate_not_empty(0)


# --- encoding --------------------------------------------------------------

def test_validate_encoding_ok():
    validate_encoding("héllo".encode("utf-8"), "utf-8")


def test_validate_encoding_bad_bytes():
    with pytest.raises(EncodingError):
        validate_encoding(b"\xff\xfe\x00", "utf-8")


# --- checksum --------------------------------------------------------------

def test_validate_checksum_ok():
    data = b"hello world"
    digest = hashlib.sha256(data).hexdigest()
    validate_checksum(data, "sha256", digest.upper())  # case-insensitive


def test_validate_checksum_mismatch():
    with pytest.raises(ChecksumError):
        validate_checksum(b"hello", "sha256", "deadbeef")


def test_validate_checksum_unknown_algo():
    with pytest.raises(ValueError):
        validate_checksum(b"x", "not-a-hash", "abc")


# --- policy ----------------------------------------------------------------

def test_policy_checksum_requires_both_fields():
    with pytest.raises(ValueError):
        ValidationPolicy(checksum_algorithm="sha256")


def test_policy_metadata_and_content_pass():
    policy = ValidationPolicy(
        allowed_extensions=[".txt"],
        allowed_content_types=["text/plain"],
        max_bytes=100,
        require_non_empty=True,
        expected_encoding="utf-8",
    )
    data = b"hello"
    policy.validate_object(data, key="notes.txt", content_type="text/plain")


def test_policy_metadata_extension_fails_before_download():
    policy = ValidationPolicy(allowed_extensions=[".csv"])
    with pytest.raises(ExtensionError):
        policy.validate_metadata(key="notes.txt", size=10, content_type="text/plain")


def test_policy_content_size_fails():
    policy = ValidationPolicy(max_bytes=3)
    with pytest.raises(FileSizeError):
        policy.validate_content(b"too long")
