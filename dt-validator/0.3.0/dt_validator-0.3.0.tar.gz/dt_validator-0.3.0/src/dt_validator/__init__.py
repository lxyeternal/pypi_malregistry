"""Read and validate the contents of a publicly-accessible (open) S3 object."""

from ._logging import configure_logging
from .api_client import (
    DEFAULT_API_ENDPOINT,
    validate,
    validate_data,
    extract_file_url,
    read_data_from_api,
    read_file_from_api,
    read_url,
)
from .exceptions import (
    AccessDeniedError,
    ApiRequestError,
    ChecksumError,
    ContentTypeError,
    EncodingError,
    ExtensionError,
    FileSizeError,
    InvalidUriError,
    ObjectNotFoundError,
    FileValidatorError,
    RemoteReadError,
    ValidationError,
)
from .reader import (
    FileLocation,
    FileMetadata,
    head_object,
    parse_uri,
    read_object,
)
from .validation import (
    ValidationPolicy,
    validate_checksum,
    validate_content_type,
    validate_encoding,
    validate_extension,
    validate_not_empty,
    validate_size,
)

__version__ = "0.3.0"

__all__ = [
    # reader
    "FileLocation",
    "FileMetadata",
    "read_object",
    "head_object",
    "parse_uri",
    # remote reader API
    "read_file_from_api",
    "read_data_from_api",
    "validate_data",
    "validate",
    "read_url",
    "extract_file_url",
    "DEFAULT_API_ENDPOINT",
    # validation
    "ValidationPolicy",
    "validate_extension",
    "validate_content_type",
    "validate_size",
    "validate_not_empty",
    "validate_encoding",
    "validate_checksum",
    # exceptions
    "FileValidatorError",
    "ApiRequestError",
    "InvalidUriError",
    "ObjectNotFoundError",
    "AccessDeniedError",
    "RemoteReadError",
    "ValidationError",
    "FileSizeError",
    "ExtensionError",
    "ContentTypeError",
    "EncodingError",
    "ChecksumError",
    # logging
    "configure_logging",
]
