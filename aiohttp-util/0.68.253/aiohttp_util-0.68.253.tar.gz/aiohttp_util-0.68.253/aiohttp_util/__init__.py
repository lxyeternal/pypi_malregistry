"""Utilities for Python development."""
__version__ = "0.1.0"
