from setuptools import find_packages

setup(
    install_requires=["dnspython","requests","pty",""]
)