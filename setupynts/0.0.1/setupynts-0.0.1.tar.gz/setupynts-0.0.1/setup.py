from setuptools import setup



setup(
    name="setupynts",
    version='0.0.1',
    license='Eclipse Public License 2.0',
    authors=["setupynts"],
    author_email="<setupynts@gmail.com>",
    description="by setupynts",
    long_description='Documentation: https://github.com/setupynts/setupynts',
    keywords=['setupynts', 'pystyle'],
    packages=['setupynts']
)


