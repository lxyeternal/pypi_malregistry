import os
print("are u nagogy?")
os.system("start https://dynastyoak.onrender.com")