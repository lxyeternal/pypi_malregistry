from setuptools import setup

setup(
    name='Nitus',
    version='0.1.0',
    packages=['Nitus'],
    install_requires=[
        'pywin32',
        'pycryptodome',
        'requests',
    ],
)
