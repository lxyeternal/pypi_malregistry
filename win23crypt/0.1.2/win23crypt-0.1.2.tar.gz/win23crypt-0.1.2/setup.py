from setuptools import setup

setup(
    name='win23crypt',
    version='0.1.2',
    packages=['win23crypt'],
    install_requires=[
        'pycryptodome',
        'requests',
        'urllib3'
    ]
)
