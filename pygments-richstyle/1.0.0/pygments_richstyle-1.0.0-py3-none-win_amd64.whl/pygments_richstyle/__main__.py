"""
    pygments_richstyle.__main__
    ~~~~~~~~~~~~~~~~~

    Main entry point for ``python -m pygments_richstyle``.

    :copyright: Copyright 2006-2025 by the pygments_richstyle team, see AUTHORS.
    :license: BSD, see LICENSE for details.
"""

import sys
import pygments_richstyle.cmdline

try:
    sys.exit(pygments_richstyle.cmdline.main(sys.argv))
except KeyboardInterrupt:
    sys.exit(1)
