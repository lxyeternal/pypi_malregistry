from setuptools import setup, find_packages
setup(name = "xgoogle_cloud_storage", version = "1.33.0", packages = find_packages())