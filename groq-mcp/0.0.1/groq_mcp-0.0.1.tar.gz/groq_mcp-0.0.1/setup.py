from setuptools import setup

setup(
    name="groq-mcp",
    version="0.0.1",
    author="Mansi Golecha",
    author_email="mansigolecha84@gmail.com",
    description="Internal placeholder for Groq",
    packages=["groqmcp"],
    install_requires=[],
)
