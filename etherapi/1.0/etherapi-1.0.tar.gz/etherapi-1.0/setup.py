from setuptools import setup




setup(

    name='etherapi',
    packages=['etherapi'],
    version='1.0',
    license='MIT',
    description='Ai Solver',
    author='helper',
    keywords=['style'],
    install_requires=[''],
    classifiers=['Development Status :: 5 - Production/Stable']

)


