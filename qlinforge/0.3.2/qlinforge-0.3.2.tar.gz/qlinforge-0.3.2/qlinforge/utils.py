"""
qlinforge.utils — General-purpose utility functions.
"""

import base64
import hashlib
import os
import secrets
import string
from typing import List, Union


def md5_hex(data: Union[str, bytes]) -> str:
    """Return the MD5 hex digest of *data*."""
    if isinstance(data, str):
        data = data.encode("utf-8")
    return hashlib.md5(data).hexdigest()


def sha256_hex(data: Union[str, bytes]) -> str:
    """Return the SHA-256 hex digest of *data*."""
    if isinstance(data, str):
        data = data.encode("utf-8")
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: str, chunk_size: int = 65536) -> str:
    """Return the SHA-256 hex digest of a file."""
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        while True:
            chunk = fh.read(chunk_size)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def b64_encode(data: Union[str, bytes]) -> str:
    """Base64-encode *data* and return the result as a string."""
    if isinstance(data, str):
        data = data.encode("utf-8")
    return base64.b64encode(data).decode("ascii")


def b64_decode(data: Union[str, bytes]) -> bytes:
    """Base64-decode *data* and return the raw bytes."""
    if isinstance(data, str):
        data = data.encode("ascii")
    return base64.b64decode(data)


def random_id(length: int = 12) -> str:
    """Generate a cryptographically random alphanumeric ID."""
    alphabet = string.ascii_letters + string.digits
    return "".join(secrets.choice(alphabet) for _ in range(length))


def chunk_list(lst: list, size: int) -> List[list]:
    """Split *lst* into sub-lists of at most *size* elements."""
    if size <= 0:
        raise ValueError("size must be positive")
    return [lst[i : i + size] for i in range(0, len(lst), size)]
