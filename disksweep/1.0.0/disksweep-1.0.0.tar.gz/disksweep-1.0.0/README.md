<div align="center">

# 🧹 disksweep

### Reclaim gigabytes in seconds — clear the regenerable junk clogging your disk.

[![PyPI version](https://img.shields.io/pypi/v/disksweep.svg?color=3775A9&logo=pypi&logoColor=white)](https://pypi.org/project/disksweep/)
[![Python versions](https://img.shields.io/pypi/pyversions/disksweep.svg?color=3775A9)](https://pypi.org/project/disksweep/)
[![zero dependencies](https://img.shields.io/badge/dependencies-0-brightgreen.svg)](https://pypi.org/project/disksweep/)
[![license](https://img.shields.io/pypi/l/disksweep.svg?color=blue)](./LICENSE)

`node_modules`, `.venv`, `__pycache__`, `.pytest_cache`, `dist`, `build`, `target`, `.next`…
they pile up across every old project and quietly eat your SSD. `disksweep` finds them all,
shows how much space each is wasting, and lets you wipe them safely. **Dry-run by default.
Zero dependencies.**


---

## Quick start

```bash
uvx disksweep              # scan the current folder, show what's reclaimable
uvx disksweep ~/code -i    # interactively pick what to delete
```

```text
$ uvx disksweep ~/code

  1   4.2 GB  2mo  acme-api/node_modules
  2   1.1 GB  3w   ml-thing/.venv
  3   512 MB  1w   ml-thing/__pycache__
  4   380 MB  1d   storefront/.next

Reclaimable: 6.2 GB across 4 directories

Dry run — nothing deleted. Re-run with `-i` to choose, or `-d` to delete all.
```

> Also available as the shorter `sweep` command after install.

## Install

```bash
uvx disksweep              # run without installing (uv)
pipx install disksweep     # or install the CLI globally
pip install disksweep      # or into an environment
```

## Why disksweep

- 🧯 **Safe by design.** Dry-run by default. Only deletes a curated allowlist of
  *regenerable* directories. Never follows symlinks, never descends into `.git`, and
  refuses to run at a drive root, your home folder, or its parent without `--force`.
- 🎯 **Cross-stack.** Python (`.venv`, `__pycache__`, `.pytest_cache`, `.mypy_cache`,
  `.ruff_cache`), JavaScript (`node_modules`, `.next`, `.turbo`), Rust (`target`) and more
  in one pass.
- ⚡ **Zero dependencies.** Installs instantly; nothing to audit.
- 🤖 **Scriptable.** `--json` and `--yes` make it CI/automation friendly.

## What it targets

By default (unambiguous, always-regenerable): `node_modules`, `.venv`, `venv`,
`__pycache__`, `.pytest_cache`, `.mypy_cache`, `.ruff_cache`, `.next`, `.nuxt`,
`.svelte-kit`, `.turbo`, `.parcel-cache`.

Add the heavier, occasionally hand-authored build dirs (`dist`, `build`, `coverage`,
`target`) with `--aggressive`, or pick your own with `--include`:

```bash
uvx disksweep --aggressive
uvx disksweep --include node_modules,.venv,target
```

## Options

| Option | Description |
| --- | --- |
| `-i`, `--interactive` | Pick which directories to delete (e.g. `1,3-5`, `all`, `none`) |
| `-d`, `--delete` | Delete everything found (asks to confirm) |
| `-y`, `--yes` | Skip the confirmation (use with `--delete`) |
| `-a`, `--aggressive` | Also target `dist`, `build`, `coverage`, `target` |
| `--older-than N` | Only include directories not modified in the last N days |
| `--include a,b` | Comma-separated directory names to target (overrides defaults) |
| `--json` | Output results as JSON; never deletes |
| `--force` | Allow running at a drive root / home directory |

## Python API

```python
from disksweep import scan, remove_all, human_size

found = scan("/path/to/code", older_than_days=30)
print("reclaimable:", human_size(sum(r["size"] for r in found)))
# remove_all(found)  # when you're sure
```

## FAQ

### How do I delete all node_modules and __pycache__ folders to free disk space?

Run `uvx disksweep` in any parent folder to list every regenerable dir with its size, then
`uvx disksweep -d` to delete them. They're rebuilt next time you run `npm install` /
`pip install` / your tests, so reclaiming the space is safe.

### Is disksweep safe? Will it delete my source code?

No. It only removes directories whose **name** is on a curated allowlist of
always-regenerable folders. It's dry-run by default, never follows symlinks, and refuses to
run at a drive root, your home folder, or its parent. Ambiguous build dirs (`dist`, `build`,
`target`, `coverage`) are excluded unless you pass `--aggressive`.

### How is disksweep different from npkill?

npkill focuses on `node_modules`. disksweep is a zero-dependency, **cross-stack** alternative
that also clears Python, Rust and framework caches, adds `--older-than`, a `--json` mode, and
stronger safety defaults. Same tool is on npm too (`npx disksweep`).

## Also on npm

JavaScript-first? The same tool ships on npm — `npx disksweep`.

## License

[MIT](./LICENSE) — free for personal and commercial use.
