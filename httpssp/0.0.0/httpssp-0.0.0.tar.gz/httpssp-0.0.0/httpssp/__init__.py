__version__ = '0.0.0'

def get_version():
    return __version__.split('.')
