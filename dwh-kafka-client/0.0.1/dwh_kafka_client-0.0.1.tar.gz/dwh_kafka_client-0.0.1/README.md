# dwh-kafka-client

message bus client

## Installation

```bash
pip install dwh-kafka-client
```

## Usage

```python
import dwh_kafka_client
```

## Telemetry

This package collects anonymous usage metrics to help improve the platform.
Telemetry can be disabled by setting the `DISABLE_TELEMETRY` environment variable.

## License

MIT
