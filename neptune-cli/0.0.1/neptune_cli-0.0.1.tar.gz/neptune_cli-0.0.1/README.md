## What is this?

This is a stub package intended to mitigate the risks of dependency confusion.
It holds a once-popular package name removed by its author (or for other reasons, such as security).

You might encounter this public package if your application:

- Depends on a package that has since been deleted.
- Contains a typo in the package name.

This package contains no code — it simply raises an installation-time error to make the problem more noticeable.

Read more about [Dependency Confusion](https://protsenko.dev/dependency-confusion).