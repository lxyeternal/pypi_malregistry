import os
import time

from disksweep import (
    AGGRESSIVE_INCLUDE,
    DEFAULT_INCLUDE,
    dir_stats,
    format_age,
    human_size,
    parse_selection,
    remove,
    remove_all,
    scan,
)


def mkdir(*p):
    full = os.path.join(*p)
    os.makedirs(full, exist_ok=True)
    return full


def file(d, name, size=0):
    with open(os.path.join(d, name), "wb") as fh:
        fh.write(b"\0" * size)


def test_human_size():
    assert human_size(0) == "0 B"
    assert human_size(1024) == "1 KB"
    assert human_size(1536) == "1.5 KB"
    assert human_size(1024 * 1024 * 3) == "3 MB"


def test_format_age():
    now = 1_000_000_000_000
    assert format_age(now, now) == "just now"
    assert format_age(now - 2 * 86_400_000, now) == "2d"
    assert format_age(now - 21 * 86_400_000, now) == "3w"
    assert format_age(0, now) == "—"


def test_parse_selection():
    assert parse_selection("all", 3) == [0, 1, 2]
    assert parse_selection("none", 3) == []
    assert parse_selection("", 3) == []
    assert parse_selection("1,3", 3) == [0, 2]
    assert parse_selection("1-3", 5) == [0, 1, 2]
    assert parse_selection("2-1", 5) == [0, 1]
    assert parse_selection("1,1,2", 5) == [0, 1]
    assert parse_selection("9", 3) == []
    assert parse_selection("1,foo,2", 3) == [0, 1]


def test_dir_stats(tmp_path):
    d = str(tmp_path)
    file(d, "a.bin", 100)
    sub = mkdir(d, "sub")
    file(sub, "b.bin", 50)
    size, _ = dir_stats(d)
    assert size == 150


def test_scan_finds_and_does_not_descend(tmp_path):
    root = str(tmp_path)
    proj = mkdir(root, "proj")
    nm = mkdir(proj, "node_modules")
    file(nm, "x.js", 200)
    mkdir(nm, "dep", "node_modules")  # nested — must NOT be reported separately
    src = mkdir(proj, "src")
    file(src, "index.js", 10)
    results = scan(root)
    nm_hits = [r for r in results if r["name"] == "node_modules"]
    assert len(nm_hits) == 1
    assert nm_hits[0]["path"] == nm


def test_scan_skips_git(tmp_path):
    root = str(tmp_path)
    mkdir(root, ".git", "objects")
    mkdir(root, "node_modules")
    results = scan(root)
    assert all(f"{os.sep}.git{os.sep}" not in r["path"] for r in results)


def test_scan_custom_include(tmp_path):
    root = str(tmp_path)
    mkdir(root, "node_modules")
    mkdir(root, "dist")
    results = scan(root, include=["dist"])
    assert [r["name"] for r in results] == ["dist"]


def test_empty_include_matches_nothing(tmp_path):
    root = str(tmp_path)
    mkdir(root, "node_modules")
    assert scan(root, include=[]) == []


def test_aggressive_dirs_not_in_default(tmp_path):
    root = str(tmp_path)
    mkdir(root, "node_modules")
    mkdir(root, "dist")
    mkdir(root, "target")
    default_names = [r["name"] for r in scan(root)]
    assert "node_modules" in default_names
    assert "dist" not in default_names
    assert "target" not in default_names
    agg_names = [r["name"] for r in scan(root, include=[*DEFAULT_INCLUDE, *AGGRESSIVE_INCLUDE])]
    assert "dist" in agg_names and "target" in agg_names


def test_scan_older_than_filters_recent(tmp_path):
    root = str(tmp_path)
    nm = mkdir(root, "node_modules")
    file(nm, "fresh.js", 10)
    now = time.time() * 1000
    assert scan(root, older_than_days=30, now=now) == []


def test_scan_sorts_by_size_desc(tmp_path):
    root = str(tmp_path)
    big = mkdir(root, "a", "node_modules")
    file(big, "big.bin", 5000)
    small = mkdir(root, "b", ".venv")
    file(small, "small.bin", 100)
    results = scan(root)
    assert len(results) == 2
    assert results[0]["size"] >= results[1]["size"]
    assert results[0]["name"] == "node_modules"


def test_remove_and_remove_all(tmp_path):
    root = str(tmp_path)
    nm = mkdir(root, "node_modules")
    file(nm, "x.bin", 123)
    results = scan(root)
    res = remove_all(results)
    assert len(res["removed"]) == 1
    assert res["freed"] == 123
    assert not os.path.exists(nm)


def test_remove_nonexistent_is_success(tmp_path):
    assert remove(os.path.join(str(tmp_path), "does-not-exist")) is True
