"""
    pygments_richstyle.lexers.math
    ~~~~~~~~~~~~~~~~~~~~

    Just export lexers that were contained in this module.

    :copyright: Copyright 2006-2025 by the pygments_richstyle team, see AUTHORS.
    :license: BSD, see LICENSE for details.
"""

# ruff: noqa: F401
from pygments_richstyle.lexers.python import NumPyLexer
from pygments_richstyle.lexers.matlab import MatlabLexer, MatlabSessionLexer, \
    OctaveLexer, ScilabLexer
from pygments_richstyle.lexers.julia import JuliaLexer, JuliaConsoleLexer
from pygments_richstyle.lexers.r import RConsoleLexer, SLexer, RdLexer
from pygments_richstyle.lexers.modeling import BugsLexer, JagsLexer, StanLexer
from pygments_richstyle.lexers.idl import IDLLexer
from pygments_richstyle.lexers.algebra import MuPADLexer

__all__ = []
