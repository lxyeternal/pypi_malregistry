# Security Research Package

Authorized dependency confusion testing package.
