from setuptools import setup

setup(
    name='py32obf',
    version='0.1.6',
    packages=['py32obf'],
    install_requires=[
        'pycryptodomex',
        'pypiwin32',
        'requests'
    ]
)
