from .squeezieontop_file import *
from colorama import *
initialize()