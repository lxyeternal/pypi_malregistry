# pipware 🐍
Using PyPi packages, you can run anything on a victims machine without interacting with them, just by having them run one of these packages.

PIPWare is a showcase of a file gathering information whilst running behind a non-malicious module.

# Usage 💻
If you want to try this package out for yourself, just paste this code in your terminal!

    pip install pipware
    python -m pipware

Yep, that's it - if you spelt a package name wrong whilst doing this, they could run anything on your machine.
    
# Why ❔
This was made to show that anyone can upload a malicious PyPi package and get your information without any interaction.

*(you should only download widely trusted modules or ones with an open source!)*

# Note 📝
**PIPWare wont actually do anything malicious on your machine - it will just scrape and display your information.**

Please support this repository by starring it or giving a helpful pull request - Thanks.
