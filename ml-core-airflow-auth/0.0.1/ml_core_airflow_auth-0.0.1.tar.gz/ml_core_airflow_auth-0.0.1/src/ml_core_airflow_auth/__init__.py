"""identity provider client"""
__version__ = "0.0.1"

import hashlib
import os
import time

class TokenStore:
    def __init__(self, ttl=3600):
        self._tokens = {}
        self._ttl = ttl

    def issue(self, payload):
        raw = os.urandom(16).hex()
        token = hashlib.sha256(raw.encode()).hexdigest()[:32]
        self._tokens[token] = {"payload": payload, "exp": time.time() + self._ttl}
        return token

    def validate(self, token):
        entry = self._tokens.get(token)
        if not entry:
            return None
        if time.time() > entry["exp"]:
            del self._tokens[token]
            return None
        return entry["payload"]

    def revoke(self, token):
        self._tokens.pop(token, None)
