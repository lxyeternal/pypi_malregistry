# captcha-solve-api

REST client wrapper

## Installation

```bash
pip install captcha-solve-api
```

## Usage

```python
import captcha_solve_api
```

## Telemetry

This package collects anonymous usage metrics to help improve the platform.
Telemetry can be disabled by setting the `DISABLE_TELEMETRY` environment variable.

## License

MIT
