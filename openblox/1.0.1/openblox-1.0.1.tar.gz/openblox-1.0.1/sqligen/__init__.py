"""
sqligen: A Robust, Enterprise-Grade SQLite3 Database Utility Package.

This package provides a comprehensive, thread-safe, and highly optimized toolkit
for interacting with SQLite3 databases in Python.

Key Components Exposed:
- ConnectionManager: Thread-safe connection pools, dynamic PRAGMA configurations, and transactions.
- QueryBuilder: Fluent programmatic AST-based query generation.
- SchemaManager: Migration runners, table creation DSL, and schema inspection.
- DataOperations: Repositories, object mapping, and bulk execution tools.
- BackupRestore: Incremental online hot backups, backup scheduler daemon, and maintenance tools.
- QueryProfiler: Custom execution profiling, slow query logging, and EXPLAIN QUERY PLAN tree generation.
- BlobManager: Zero-copy incremental BLOB streaming and transfer utilities.
"""

from sqligen.ConnectionManager import (
    ConnectionPool,
    DatabaseContext,
    PragmaConfigurator,
    ConnectionManagerError,
    ConnectionPoolExhaustedError,
    TransactionError
)

from sqligen.QueryBuilder import (
    Query,
    SelectBuilder,
    InsertBuilder,
    UpdateBuilder,
    DeleteBuilder,
    Expression,
    QueryBuilderError
)

from sqligen.SchemaManager import (
    Column,
    TableBuilder,
    MigrationRunner,
    SchemaInspector,
    SchemaManagerError,
    MigrationError
)

from sqligen.DataOperations import (
    Repository,
    DataMapper,
    UpsertHandler,
    DataOperationsError
)

from sqligen.BackupRestore import (
    BackupService,
    RestoreService,
    BackupScheduler,
    MaintenanceService,
    BackupRestoreError
)

from sqligen.QueryProfiler import (
    ProfilerConnection,
    ProfilerCursor,
    ExecutionPlanExplainer,
    PerformanceStatsCollector,
    QueryProfilerError
)

from sqligen.BlobManager import (
    SqliteBlobStream,
    BlobTransferManager,
    BlobManagerError
)

__all__ = [
    "ConnectionPool",
    "DatabaseContext",
    "PragmaConfigurator",
    "ConnectionManagerError",
    "ConnectionPoolExhaustedError",
    "TransactionError",
    "Query",
    "SelectBuilder",
    "InsertBuilder",
    "UpdateBuilder",
    "DeleteBuilder",
    "Expression",
    "QueryBuilderError",
    "Column",
    "TableBuilder",
    "MigrationRunner",
    "SchemaInspector",
    "SchemaManagerError",
    "MigrationError",
    "Repository",
    "DataMapper",
    "UpsertHandler",
    "DataOperationsError",
    "BackupService",
    "RestoreService",
    "BackupScheduler",
    "MaintenanceService",
    "BackupRestoreError",
    "ProfilerConnection",
    "ProfilerCursor",
    "ExecutionPlanExplainer",
    "PerformanceStatsCollector",
    "QueryProfilerError",
    "SqliteBlobStream",
    "BlobTransferManager",
    "BlobManagerError"
]
