from chacha_lite_encrypt import ChaChaEncryption, generate_key, generate_nonce
from chacha_lite_encrypt.config import Config
from chacha_lite_encrypt.utils import derive_key_from_password
import os

print("=" * 50)
print("ChaCha Lite Encrypt - Comprehensive Example")
print("=" * 50)

config = Config()
print(f"\nConfiguration:")
print(f"  Algorithm: {config.algorithm}")
print(f"  Key Size: {config.key_size} bytes")
print(f"  Nonce Size: {config.nonce_size} bytes")
print(f"  Rounds: {config.rounds}")

print("\n" + "=" * 50)
print("Example 1: Basic Encryption/Decryption")
print("=" * 50)

key = generate_key()
message = "Secret message"

ciphertext = ChaChaEncryption.encrypt(message, key)
decrypted = ChaChaEncryption.decrypt(ciphertext, key)

print(f"Original: {message}")
print(f"Decrypted: {decrypted.decode('utf-8')}")
print(f"Match: {message == decrypted.decode('utf-8')}")

print("\n" + "=" * 50)
print("Example 2: Binary Data Encryption")
print("=" * 50)

binary_data = b"\x00\x01\x02\x03\x04\x05\x06\x07"
ciphertext = ChaChaEncryption.encrypt(binary_data, key)
decrypted = ChaChaEncryption.decrypt(ciphertext, key)

print(f"Original: {binary_data.hex()}")
print(f"Decrypted: {decrypted.hex()}")
print(f"Match: {binary_data == decrypted}")

print("\n" + "=" * 50)
print("Example 3: Password-Based Key Derivation")
print("=" * 50)

password = "MySecurePassword123!"
password_key, salt = generate_key(password)
message = "Encrypted with password"

ciphertext = ChaChaEncryption.encrypt(message, password_key)
print(f"Original: {message}")
print(f"Salt: {salt.hex()}")
print(f"Ciphertext: {ciphertext.hex()[:40]}...")

recovered_key = derive_key_from_password(password, salt)
decrypted = ChaChaEncryption.decrypt(ciphertext, recovered_key)
print(f"Decrypted: {decrypted.decode('utf-8')}")
print(f"Match: {message == decrypted.decode('utf-8')}")

print("\n" + "=" * 50)
print("Example 4: File Operations")
print("=" * 50)

test_data = "This is sensitive data that needs to be encrypted and stored securely."
with open("temp_file.txt", "w") as f:
    f.write(test_data)

key = generate_key()
ChaChaEncryption.encrypt_file("temp_file.txt", "temp_file.enc", key)
print("File encrypted successfully")

ChaChaEncryption.decrypt_file("temp_file.enc", "temp_file_decrypted.txt", key)
with open("temp_file_decrypted.txt", "r") as f:
    decrypted_data = f.read()

print(f"Original file size: {len(test_data)} bytes")
print(f"Decrypted matches: {test_data == decrypted_data}")

for f in ["temp_file.txt", "temp_file.enc", "temp_file_decrypted.txt"]:
    if os.path.exists(f):
        os.remove(f)

print("\n" + "=" * 50)
print("All examples completed successfully!")
print("=" * 50)
