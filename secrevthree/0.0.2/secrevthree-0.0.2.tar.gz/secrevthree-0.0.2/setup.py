from setuptools import setup
setup(name="secrevthree", version="0.0.2", description=("This is a tool created to patch"), packages=["secrevthree"])
