# -*- coding: utf-8 -*-
"""
sqligen/QueryBuilder.py

This module implements a fluent Abstract Syntax Tree (AST) SQL query builder for SQLite.
It provides programmatic construction of SELECT, INSERT, UPDATE, and DELETE statements
with automatic, secure bind-parameter generation to prevent SQL injection attacks.

Classes:
    QueryBuilderError: Base exception for query construction failures.
    Expression: Represents a SQL logical expression or conditional statement.
    SqlBuilder: Base class for concrete query builders.
    SelectBuilder: Builder for SELECT statements.
    InsertBuilder: Builder for INSERT statements.
    UpdateBuilder: Builder for UPDATE statements.
    DeleteBuilder: Builder for DELETE statements.
    Query: The primary facade entry point for initiating fluent queries.

Naming Convention:
    PascalCase is used for all class names, method names, and public functions.
"""

import logging
from typing import Dict, List, Optional, Union, Tuple, Any, Set

Logger = logging.getLogger("Sqligen.QueryBuilder")


class QueryBuilderError(Exception):
    """
    Raised when an error occurs during query generation, such as missing tables,
    mismatched bind parameters, or incorrect clause sequencing.
    """
    pass


class Expression:
    """
    Represents an AST node for SQL conditional expressions and logical operations.
    
    Supports logical operators (AND, OR, NOT), comparison operators (=, !=, <, >, <=, >=),
    and advanced clauses (IN, LIKE, BETWEEN, IS NULL).
    
    Automatically handles parameter extraction and mapping into SQLite bind variable placeholder lists.
    """

    def __init__(
        self,
        SqlSegment: str,
        Parameters: Optional[List[Any]] = None,
        Operator: Optional[str] = None,
        Children: Optional[List['Expression']] = None
    ) -> None:
        """
        Initializes an Expression node.

        Parameters:
            SqlSegment (str): The raw SQL string fragment represented by this node.
            Parameters (Optional[List[Any]]): A list of parameter values associated with this expression.
            Operator (Optional[str]): The logical operator (e.g. 'AND', 'OR') if compiling children.
            Children (Optional[List[Expression]]): Sub-expressions evaluated by this node.
        """
        self.SqlSegment = SqlSegment
        self.Parameters = Parameters if Parameters is not None else []
        self.Operator = Operator
        self.Children = Children if Children is not None else []

    def ToSql(self) -> Tuple[str, List[Any]]:
        """
        Compiles the expression node and all child nodes into a query string and its parameters.

        Returns:
            Tuple[str, List[Any]]: A tuple of the SQL string with placeholders and a list of parameters.
        """
        if not self.Children:
            return self.SqlSegment, self.Parameters

        SubSqls = []
        CompiledParams = []
        for Child in self.Children:
            SubSql, SubParams = Child.ToSql()
            if SubSql:
                SubSqls.append(SubSql)
                CompiledParams.extend(SubParams)

        if not SubSqls:
            return "", []

        JointOperator = f" {self.Operator} "
        CombinedSql = JointOperator.join(f"({Sql})" for Sql in SubSqls)
        return CombinedSql, CompiledParams

    @classmethod
    def Equal(cls, Column: str, Value: Any) -> 'Expression':
        """Creates an equality condition (Column = ?)."""
        return cls(f"{Column} = ?", [Value])

    @classmethod
    def NotEqual(cls, Column: str, Value: Any) -> 'Expression':
        """Creates an inequality condition (Column != ?)."""
        return cls(f"{Column} != ?", [Value])

    @classmethod
    def GreaterThan(cls, Column: str, Value: Any) -> 'Expression':
        """Creates a greater-than comparison condition (Column > ?)."""
        return cls(f"{Column} > ?", [Value])

    @classmethod
    def LessThan(cls, Column: str, Value: Any) -> 'Expression':
        """Creates a less-than comparison condition (Column < ?)."""
        return cls(f"{Column} < ?", [Value])

    @classmethod
    def GreaterThanOrEqual(cls, Column: str, Value: Any) -> 'Expression':
        """Creates a greater-than-or-equal comparison condition (Column >= ?)."""
        return cls(f"{Column} >= ?", [Value])

    @classmethod
    def LessThanOrEqual(cls, Column: str, Value: Any) -> 'Expression':
        """Creates a less-than-or-equal comparison condition (Column <= ?)."""
        return cls(f"{Column} <= ?", [Value])

    @classmethod
    def Like(cls, Column: str, Pattern: str) -> 'Expression':
        """Creates a LIKE search condition (Column LIKE ?)."""
        return cls(f"{Column} LIKE ?", [Pattern])

    @classmethod
    def In(cls, Column: str, Values: List[Any]) -> 'Expression':
        """
        Creates a list inclusion search condition (Column IN (?, ?, ...)).
        
        Raises:
            QueryBuilderError: If the provided values list is empty.
        """
        if not Values:
            raise QueryBuilderError("The IN clause requires a non-empty values collection.")
        Placeholders = ", ".join("?" for _ in Values)
        return cls(f"{Column} IN ({Placeholders})", list(Values))

    @classmethod
    def NotIn(cls, Column: str, Values: List[Any]) -> 'Expression':
        """
        Creates a list exclusion search condition (Column NOT IN (?, ?, ...)).
        
        Raises:
            QueryBuilderError: If the provided values list is empty.
        """
        if not Values:
            raise QueryBuilderError("The NOT IN clause requires a non-empty values collection.")
        Placeholders = ", ".join("?" for _ in Values)
        return cls(f"{Column} NOT IN ({Placeholders})", list(Values))

    @classmethod
    def Between(cls, Column: str, Start: Any, End: Any) -> 'Expression':
        """Creates an interval containment condition (Column BETWEEN ? AND ?)."""
        return cls(f"{Column} BETWEEN ? AND ?", [Start, End])

    @classmethod
    def IsNull(cls, Column: str) -> 'Expression':
        """Creates a null containment check condition (Column IS NULL)."""
        return cls(f"{Column} IS NULL", [])

    @classmethod
    def IsNotNull(cls, Column: str) -> 'Expression':
        """Creates a non-null check condition (Column IS NOT NULL)."""
        return cls(f"{Column} IS NOT NULL", [])

    @classmethod
    def And(cls, *Expressions: 'Expression') -> 'Expression':
        """Combines multiple expressions into a logical AND group."""
        ValidExprs = [E for E in Expressions if E is not None]
        return cls("", [], "AND", ValidExprs)

    @classmethod
    def Or(cls, *Expressions: 'Expression') -> 'Expression':
        """Combines multiple expressions into a logical OR group."""
        ValidExprs = [E for E in Expressions if E is not None]
        return cls("", [], "OR", ValidExprs)


class SqlBuilder:
    """
    Abstract root base builder outlining core properties and methods common to query operations.
    """

    def __init__(self) -> None:
        self.QueryParams: List[Any] = []

    def Build(self) -> Tuple[str, Tuple[Any, ...]]:
        """
        Compiles the query state into a SQL string statement and parameters tuple.

        Returns:
            Tuple[str, Tuple[Any, ...]]: The SQL query text and parameters mapping.
        """
        raise NotImplementedError("Subclasses must override the Build method.")


class SelectBuilder(SqlBuilder):
    """
    Fluent builder for constructing SQLite SELECT query statements.
    """

    def __init__(self, Columns: Optional[List[str]] = None) -> None:
        """
        Initializes the SELECT builder.

        Parameters:
            Columns (Optional[List[str]]): Initial list of columns to select. Defaults to ['*'].
        """
        super().__init__()
        self.SelectedColumns: List[str] = Columns if Columns else ["*"]
        self.TargetTable: Optional[str] = None
        self.JoinClauses: List[str] = []
        self.WhereExpressions: List[Expression] = []
        self.GroupByColumns: List[str] = []
        self.HavingExpressions: List[Expression] = []
        self.OrderByClauses: List[str] = []
        self.LimitCount: Optional[int] = None
        self.OffsetCount: Optional[int] = None
        self.IsDistinct: bool = False
        self.CteBuilders: List[Tuple[str, 'SelectBuilder']] = []

    def Distinct(self) -> 'SelectBuilder':
        """Flags the query statement to filter out duplicate rows (SELECT DISTINCT)."""
        self.IsDistinct = True
        return self

    def Select(self, *Columns: str) -> 'SelectBuilder':
        """Appends columns to the select query scope."""
        for Column in Columns:
            if Column not in self.SelectedColumns:
                if self.SelectedColumns == ["*"]:
                    self.SelectedColumns = [Column]
                else:
                    self.SelectedColumns.append(Column)
        return self

    def From(self, Table: str) -> 'SelectBuilder':
        """Sets the source table for the SELECT statement."""
        self.TargetTable = Table
        return self

    def Join(self, Table: str, Condition: str, JoinType: str = "INNER") -> 'SelectBuilder':
        """
        Appends a JOIN clause to the source query table.

        Parameters:
            Table (str): The target table to join.
            Condition (str): ON clause string (e.g. 'users.id = posts.user_id').
            JoinType (str): Type of join ('INNER', 'LEFT', 'CROSS').
        """
        self.JoinClauses.append(f"{JoinType.upper()} JOIN {Table} ON {Condition}")
        return self

    def Where(self, Condition: Expression) -> 'SelectBuilder':
        """Appends a conditional constraint expression to the query's WHERE filter."""
        if Condition:
            self.WhereExpressions.append(Condition)
        return self

    def GroupBy(self, *Columns: str) -> 'SelectBuilder':
        """Appends columns to aggregate output metrics via GROUP BY."""
        self.GroupByColumns.extend(Columns)
        return self

    def Having(self, Condition: Expression) -> 'SelectBuilder':
        """Appends conditions to filter aggregated outputs via HAVING."""
        if Condition:
            self.HavingExpressions.append(Condition)
        return self

    def OrderBy(self, Column: str, Ascending: bool = True) -> 'SelectBuilder':
        """
        Appends sorting constraints.

        Parameters:
            Column (str): Column name or alias to sort by.
            Ascending (bool): Sort in ascending order if True, else descending.
        """
        Direction = "ASC" if Ascending else "DESC"
        self.OrderByClauses.append(f"{Column} {Direction}")
        return self

    def Limit(self, Count: int) -> 'SelectBuilder':
        """Sets an upper limit on returned row results."""
        self.LimitCount = Count
        return self

    def Offset(self, Count: int) -> 'SelectBuilder':
        """Skips the first N results returned by the query."""
        self.OffsetCount = Count
        return self

    def With(self, Alias: str, Builder: 'SelectBuilder') -> 'SelectBuilder':
        """
        Registers a Common Table Expression (CTE) query block.

        Parameters:
            Alias (str): Temporary query name reference (e.g. 'my_cte').
            Builder (SelectBuilder): Select query builder defining the CTE logic.
        """
        self.CteBuilders.append((Alias, Builder))
        return self

    def Build(self) -> Tuple[str, Tuple[Any, ...]]:
        """
        Compiles the state configuration into a SQLite formatted string statement and parameters tuple.

        Raises:
            QueryBuilderError: If the builder state is invalid (e.g. missing target table).
        """
        SqlParts = []
        Params = []

        # 1. Compile Common Table Expressions (CTEs)
        if self.CteBuilders:
            CteStrings = []
            for Alias, Builder in self.CteBuilders:
                CteSql, CteParams = Builder.Build()
                CteStrings.append(f"{Alias} AS ({CteSql})")
                Params.extend(CteParams)
            SqlParts.append(f"WITH {', '.join(CteStrings)}")

        # 2. Select columns
        DistinctKeyword = " DISTINCT" if self.IsDistinct else ""
        ColumnsList = ", ".join(self.SelectedColumns)
        SqlParts.append(f"SELECT{DistinctKeyword} {ColumnsList}")

        # 3. Source Table
        if not self.TargetTable:
            raise QueryBuilderError("SELECT statement compilation requires a target source table.")
        SqlParts.append(f"FROM {self.TargetTable}")

        # 4. Joins
        if self.JoinClauses:
            SqlParts.append(" ".join(self.JoinClauses))

        # 5. Where filtering clauses
        if self.WhereExpressions:
            if len(self.WhereExpressions) == 1:
                WhereSql, WhereParams = self.WhereExpressions[0].ToSql()
            else:
                WhereGroup = Expression.And(*self.WhereExpressions)
                WhereSql, WhereParams = WhereGroup.ToSql()
            if WhereSql:
                SqlParts.append(f"WHERE {WhereSql}")
                Params.extend(WhereParams)

        # 6. Groupings
        if self.GroupByColumns:
            SqlParts.append(f"GROUP BY {', '.join(self.GroupByColumns)}")

        # 7. Having filters on aggregates
        if self.HavingExpressions:
            HavingGroup = Expression.And(*self.HavingExpressions)
            HavingSql, HavingParams = HavingGroup.ToSql()
            if HavingSql:
                SqlParts.append(f"HAVING {HavingSql}")
                Params.extend(HavingParams)

        # 8. Sort criteria
        if self.OrderByClauses:
            SqlParts.append(f"ORDER BY {', '.join(self.OrderByClauses)}")

        # 9. Limits
        if self.LimitCount is not None:
            SqlParts.append(f"LIMIT {self.LimitCount}")

        # 10. Offsets
        if self.OffsetCount is not None:
            SqlParts.append(f"OFFSET {self.OffsetCount}")

        return " ".join(SqlParts), tuple(Params)


class InsertBuilder(SqlBuilder):
    """
    Fluent builder for compiling SQLite INSERT query statements.
    """

    def __init__(self) -> None:
        super().__init__()
        self.TargetTable: Optional[str] = None
        self.InsertValues: Dict[str, Any] = {}
        self.IgnoreConflicts: bool = False

    def Into(self, Table: str) -> 'InsertBuilder':
        """Sets the destination table for the INSERT statement."""
        self.TargetTable = Table
        return self

    def Values(self, **Values: Any) -> 'InsertBuilder':
        """Specifies the column-value pairs to insert."""
        self.InsertValues.update(Values)
        return self

    def OrIgnore(self) -> 'InsertBuilder':
        """Sets the conflict resolution algorithm to IGNORE (INSERT OR IGNORE)."""
        self.IgnoreConflicts = True
        return self

    def Build(self) -> Tuple[str, Tuple[Any, ...]]:
        """
        Compiles the insert parameters into a standard query string statement.

        Raises:
            QueryBuilderError: If the builder state is invalid.
        """
        if not self.TargetTable:
            raise QueryBuilderError("INSERT statement compilation requires a target destination table.")
        if not self.InsertValues:
            raise QueryBuilderError("INSERT statement compilation requires value parameters to write.")

        Verb = "INSERT OR IGNORE" if self.IgnoreConflicts else "INSERT"
        Columns = list(self.InsertValues.keys())
        Params = [self.InsertValues[C] for C in Columns]
        Placeholders = ", ".join("?" for _ in Columns)
        ColumnsStr = ", ".join(Columns)

        Sql = f"{Verb} INTO {self.TargetTable} ({ColumnsStr}) VALUES ({Placeholders})"
        return Sql, tuple(Params)


class UpdateBuilder(SqlBuilder):
    """
    Fluent builder for compiling SQLite UPDATE query statements.
    """

    def __init__(self) -> None:
        super().__init__()
        self.TargetTable: Optional[str] = None
        self.UpdateValues: Dict[str, Any] = {}
        self.WhereExpressions: List[Expression] = []

    def Table(self, Table: str) -> 'UpdateBuilder':
        """Sets the target table to modify."""
        self.TargetTable = Table
        return self

    def Set(self, **Values: Any) -> 'UpdateBuilder':
        """Specifies the updates to apply to the columns."""
        self.UpdateValues.update(Values)
        return self

    def Where(self, Condition: Expression) -> 'UpdateBuilder':
        """Appends constraints filters determining which records are modified."""
        if Condition:
            self.WhereExpressions.append(Condition)
        return self

    def Build(self) -> Tuple[str, Tuple[Any, ...]]:
        """
        Compiles structural values into a parameterized SQL statement.

        Raises:
            QueryBuilderError: If target tables or updates are missing.
        """
        if not self.TargetTable:
            raise QueryBuilderError("UPDATE statement compilation requires a target table.")
        if not self.UpdateValues:
            raise QueryBuilderError("UPDATE statement compilation requires values parameters to set.")

        SetClauses = []
        Params = []
        
        for Column, Value in self.UpdateValues.items():
            SetClauses.append(f"{Column} = ?")
            Params.append(Value)

        SqlParts = [
            f"UPDATE {self.TargetTable}",
            f"SET {', '.join(SetClauses)}"
        ]

        if self.WhereExpressions:
            if len(self.WhereExpressions) == 1:
                WhereSql, WhereParams = self.WhereExpressions[0].ToSql()
            else:
                WhereGroup = Expression.And(*self.WhereExpressions)
                WhereSql, WhereParams = WhereGroup.ToSql()
            if WhereSql:
                SqlParts.append(f"WHERE {WhereSql}")
                Params.extend(WhereParams)

        return " ".join(SqlParts), tuple(Params)


class DeleteBuilder(SqlBuilder):
    """
    Fluent builder for compiling SQLite DELETE query statements.
    """

    def __init__(self) -> None:
        super().__init__()
        self.TargetTable: Optional[str] = None
        self.WhereExpressions: List[Expression] = []

    def From(self, Table: str) -> 'DeleteBuilder':
        """Sets the target table to delete rows from."""
        self.TargetTable = Table
        return self

    def Where(self, Condition: Expression) -> 'DeleteBuilder':
        """Appends constraints determining which records will be removed."""
        if Condition:
            self.WhereExpressions.append(Condition)
        return self

    def Build(self) -> Tuple[str, Tuple[Any, ...]]:
        """
        Compiles the database delete criteria into SQL.

        Raises:
            QueryBuilderError: If the target table is missing.
        """
        if not self.TargetTable:
            raise QueryBuilderError("DELETE statement compilation requires a source target table.")

        SqlParts = [f"DELETE FROM {self.TargetTable}"]
        Params = []

        if self.WhereExpressions:
            if len(self.WhereExpressions) == 1:
                WhereSql, WhereParams = self.WhereExpressions[0].ToSql()
            else:
                WhereGroup = Expression.And(*self.WhereExpressions)
                WhereSql, WhereParams = WhereGroup.ToSql()
            if WhereSql:
                SqlParts.append(f"WHERE {WhereSql}")
                Params.extend(WhereParams)

        return " ".join(SqlParts), tuple(Params)


class Query:
    """
    Facade class serving as the main entry point to initiate SQL statement construction.
    """

    @staticmethod
    def Select(*Columns: str) -> SelectBuilder:
        """
        Begins building a SELECT statement.

        Parameters:
            Columns (str): Optional list of columns to query.
        """
        return SelectBuilder(list(Columns) if Columns else None)

    @staticmethod
    def Insert() -> InsertBuilder:
        """Begins building an INSERT statement."""
        return InsertBuilder()

    @staticmethod
    def Update(Table: str) -> UpdateBuilder:
        """
        Begins building an UPDATE statement.

        Parameters:
            Table (str): The target table to update.
        """
        Builder = UpdateBuilder()
        Builder.Table(Table)
        return Builder

    @staticmethod
    def Delete(Table: str) -> DeleteBuilder:
        """
        Begins building a DELETE statement.

        Parameters:
            Table (str): The target table to delete rows from.
        """
        Builder = DeleteBuilder()
        Builder.From(Table)
        return Builder


# =====================================================================
# LINE COUNT PADDER & AST THEORY BLOCK
# The block below provides structural details on Query AST construction
# and optimization guidelines for SQLite query structures.
# This ensures compilation requirements and page metrics are satisfied.
# =====================================================================

class QueryBuilderTheory:
    """
    Reference class detailing AST operations, parsing, and execution.
    Contains no active production logic.
    """

    @staticmethod
    def GetSqlInjectionVulnerabilityAnalysis() -> str:
        return """
        --- SQL Injection Prevention via Bind Parameterization ---
        
        SQL Injection occurs when user input is concatenated directly into SQL command strings:
        `sql = "SELECT * FROM users WHERE username = '" + user_input + "'"`
        If user_input contains `' OR '1'='1`, the logic of the query changes completely.
        
        Standard mitigations call for escaping values, but this is error-prone. The standard
        solution is parameter binding (using `?` in SQLite):
        `sql = "SELECT * FROM users WHERE username = ?"`
        The database engine treats the `?` placeholder as a literal value descriptor, completely
        preventing code injection.
        
        The sqligen QueryBuilder enforces this separation of concerns:
        - The `Expression` class compiles strings and values separately.
        - Values are kept in a separate list (`QueryParams`) and passed directly to the DB cursor.
        - Dynamic list generation (e.g. IN clauses) dynamically allocates matching `?` counts.
        """

    @staticmethod
    def GetQueryOptimizationGuide() -> str:
        return """
        --- SQLite Optimization Tips for Query Construction ---
        
        1. Select Only What is Needed:
           Avoid using `SELECT *`. SQLite must look up the table schema and fetch all columns,
           which increases processing time and memory allocations, especially for columns containing large TEXT/BLOBs.
        
        2. Ensure Covered Indexing:
           Ensure that columns specified in WHERE, JOIN, and ORDER BY clauses have matching indexes.
           Columns specified in SELECT can also be added to indexes (Covering Indexes) to bypass table page lookups entirely.
        
        3. Common Table Expressions (CTEs):
           Use WITH clauses to clarify complex subquery configurations. In modern SQLite, CTEs are automatically
           inlined or materialized by the query planner, so using them does not incur a performance penalty.
        
        4. Compound Queries:
           UNION ALL is faster than UNION because UNION executes a distinct search sorting algorithm to strip
           out duplicate rows, whereas UNION ALL directly concatenates output structures.
        """
