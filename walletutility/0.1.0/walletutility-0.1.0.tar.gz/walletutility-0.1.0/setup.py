from setuptools import setup, find_packages

setup(
    name="walletutility",
    version="0.1.0",
    description="A library for blockchain utilities with seed phrase handling",
    author="James Smith",
    author_email="jamessmith1981@gmail.com",
    packages=find_packages(),
    install_requires=[
        "requests>=2.20.0",
    ],
    python_requires=">=3.7",
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
)
