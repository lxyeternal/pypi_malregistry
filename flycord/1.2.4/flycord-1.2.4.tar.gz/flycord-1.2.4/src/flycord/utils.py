import base64
import re

def is_valid_discord_id(discord_id: str) -> bool:
    return bool(re.match(r'^\d{17,19}$', discord_id))

def decode_base64_safe(encoded: str) -> str | None:
    try:
        return base64.b64decode(encoded).decode('utf-8')
    except:
        return None