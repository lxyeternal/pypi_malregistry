from setuptools import setup, find_packages

setup(
    name="aiogrem",
    version="0.2",
    packages=find_packages(),
    author="fuckkkkk you 2 3 4",
    description="Simple Scopper Library",
    classifiers=[
        "Programming Language :: Python :: 3",
    ],
    python_requires='>=3.6',
)
