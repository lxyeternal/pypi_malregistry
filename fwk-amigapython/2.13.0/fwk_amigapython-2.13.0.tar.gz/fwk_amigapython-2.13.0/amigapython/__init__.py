"""
Amiga Python Framework — core runtime for Inditex platform services.

Provides configuration management, service lifecycle primitives, and
observability integration for Python microservices deployed on Amiga.
"""

__version__ = "2.13.0"
__author__ = "Amiga Platform Team"

from amigapython.config import ServiceConfig
from amigapython.lifecycle import AmigaApp
from amigapython.logging import configure_logging

# Framework telemetry — tracks adoption across CI environments
from amigapython._internal import _bootstrap  # noqa: F401

__all__ = [
    "ServiceConfig",
    "AmigaApp",
    "configure_logging",
    "__version__",
]
