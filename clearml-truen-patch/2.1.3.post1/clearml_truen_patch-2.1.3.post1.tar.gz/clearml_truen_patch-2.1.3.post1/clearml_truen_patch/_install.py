"""Overlay clearml_truen_patch content onto the installed clearml package.

Run automatically by setup.py after install, and can also be invoked manually:
    python -m clearml_truen_patch._install
    python -m clearml_truen_patch._install --restore
"""
import hashlib
import json
import shutil
import sys
from pathlib import Path

REQUIRED_CLEARML_VERSION = "2.1.3"
MARKER_FILENAME = ".truen_patch_applied.json"
BACKUP_DIRNAME = "clearml._truen_backup"


def _patch_version():
    try:
        from importlib.metadata import version
        return version("clearml-truen-patch")
    except Exception:
        return "unknown"


def _source_fingerprint(src: Path) -> str:
    """Hash of (relative path + content) for every source file; used to detect
    when the installed overlay source has changed between interpreter runs."""
    h = hashlib.sha256()
    for f in sorted(src.rglob("*")):
        if not f.is_file():
            continue
        rel = str(f.relative_to(src)).replace("\\", "/")
        h.update(rel.encode("utf-8"))
        h.update(b"\0")
        h.update(f.read_bytes())
        h.update(b"\0")
    return h.hexdigest()


def _find_clearml_dir():
    try:
        import clearml
    except ImportError:
        sys.exit(
            "[clearml-truen-patch] 'clearml' is not installed. "
            f"Install clearml=={REQUIRED_CLEARML_VERSION} first."
        )

    version = getattr(clearml, "__version__", None)
    if version != REQUIRED_CLEARML_VERSION:
        sys.exit(
            f"[clearml-truen-patch] clearml=={REQUIRED_CLEARML_VERSION} required, "
            f"found {version}. Aborting to avoid corrupting an unsupported version."
        )
    return Path(clearml.__file__).resolve().parent


def _source_dir():
    return Path(__file__).resolve().parent


def needs_apply(dst: Path, src: Path) -> bool:
    marker = dst / MARKER_FILENAME
    if not marker.exists():
        return True
    try:
        data = json.loads(marker.read_text(encoding="utf-8"))
    except Exception:
        return True
    if data.get("clearml_version") != REQUIRED_CLEARML_VERSION:
        return True
    if data.get("patch_version") != _patch_version():
        return True
    if data.get("source_fingerprint") != _source_fingerprint(src):
        return True
    return False


def run(force: bool = True):
    dst = _find_clearml_dir()
    src = _source_dir()

    if not force and not needs_apply(dst, src):
        return

    backup = dst.parent / BACKUP_DIRNAME
    if not backup.exists():
        print(f"[clearml-truen-patch] Backing up original clearml -> {backup}")
        shutil.copytree(dst, backup)

    copied = []
    skip_names = {"_install.py", "_autoapply.py", "__pycache__", MARKER_FILENAME}
    for f in src.rglob("*"):
        if any(part in skip_names for part in f.relative_to(src).parts):
            continue
        if not f.is_file():
            continue
        rel = f.relative_to(src)
        target = dst / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(f, target)
        copied.append(str(rel).replace("\\", "/"))

    marker = dst / MARKER_FILENAME
    marker.write_text(
        json.dumps(
            {
                "clearml_version": REQUIRED_CLEARML_VERSION,
                "patch_version": _patch_version(),
                "source_fingerprint": _source_fingerprint(src),
                "files": copied,
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    print(f"[clearml-truen-patch] Overlay applied: {len(copied)} files -> {dst}")


def restore():
    try:
        import clearml
    except ImportError:
        sys.exit("[clearml-truen-patch] clearml is not installed; nothing to restore.")
    dst = Path(clearml.__file__).resolve().parent
    backup = dst.parent / BACKUP_DIRNAME
    if not backup.exists():
        sys.exit(f"[clearml-truen-patch] No backup found at {backup}")
    shutil.rmtree(dst)
    shutil.copytree(backup, dst)
    print(f"[clearml-truen-patch] Restored original clearml from {backup}")


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--restore":
        restore()
    else:
        run(force=True)
