import pytest
import asyncio
import os
from typing import Dict, Any
from unittest.mock import AsyncMock, patch, MagicMock
from pg_agent.tools import BaseTool, SecureSQLTool, SearchTool, AnalyticsTool
from pydantic import BaseModel

class MockInput(BaseModel):
    data: str

class MockTool(BaseTool[MockInput]):
    name = "mock_tool"
    description = "A mock tool for testing."
    parameters_schema = MockInput

    async def _execute(self, input_data: MockInput) -> str:
        if input_data.data == "fail":
            raise ValueError("Intentional failure")
        if input_data.data == "slow":
            await asyncio.sleep(0.5)
        return f"Processed: {input_data.data}"

@pytest.mark.asyncio
async def test_tool_execution_success() -> None:
    tool = MockTool()
    result = await tool.execute({"data": "test"})
    
    assert result.success is True
    assert result.data == "Processed: test"
    assert "execution_time_seconds" in result.metadata

@pytest.mark.asyncio
async def test_tool_validation_error() -> None:
    tool = MockTool()
    result = await tool.execute({"wrong_key": "test"})
    
    assert result.success is False
    assert result.error is not None
    assert "Invalid input" in result.error

@pytest.mark.asyncio
async def test_tool_timeout() -> None:
    tool = MockTool()
    tool.timeout = 0.1
    result = await tool.execute({"data": "slow"})
    
    assert result.success is False

@pytest.mark.asyncio
async def test_hooks() -> None:
    tool = MockTool()
    pre_called = False
    post_called = False

    def pre_hook(name: str, input_data: Dict[str, Any]) -> None:
        nonlocal pre_called
        pre_called = True

    def post_hook(name: str, input_data: Dict[str, Any], result: Any) -> Any:
        nonlocal post_called
        post_called = True
        result.metadata["hook_added"] = True
        return result

    tool.add_pre_hook(pre_hook)
    tool.add_post_hook(post_hook)
    
    result = await tool.execute({"data": "test"})
    
    assert pre_called is True
    assert post_called is True
    assert result.metadata["hook_added"] is True

@pytest.mark.asyncio
async def test_sql_tool_readonly() -> None:
    tool = SecureSQLTool()
    
    # Valid SELECT
    with patch.dict(os.environ, {"DATABASE_URL": "postgresql://test:test@localhost:5432/test"}):
        with patch("asyncpg.connect", new_callable=AsyncMock) as mock_connect:
            mock_conn = mock_connect.return_value
            mock_conn.fetch.return_value = [{"id": 1, "name": "test"}]
            
            result = await tool.execute({"query": "SELECT * FROM users"})
            assert result.success is True
    
    # Invalid DROP
    result = await tool.execute({"query": "DROP TABLE users"})
    assert result.success is False
    assert result.error is not None
    assert "Non-read-only" in result.error

@pytest.mark.asyncio
async def test_analytics_tool_math() -> None:
    tool = AnalyticsTool()
    
    # Basic math
    result = await tool.execute({"expression": "2 + 2 * 3", "operation": "calculate"})
    assert result.data["result"] == 8.0
    
    # Safety: attempt to use forbidden names (numexpr is inherently safer but still)
    result = await tool.execute({"expression": "abs(-10)"}) # numexpr supports some functions
    assert result.data["result"] == 10.0

@pytest.mark.asyncio
async def test_analytics_tool_aggregation() -> None:
    tool = AnalyticsTool()
    data = [
        {"name": "A", "value": 10},
        {"name": "B", "value": 20},
        {"name": "A", "value": 30},
    ]
    
    # Sum
    result = await tool.execute({
        "data": data,
        "operation": "sum",
        "target_column": "value"
    })
    assert result.data["sum"] == 60.0
    
    # Groupby
    result = await tool.execute({
        "data": data,
        "operation": "groupby",
        "group_by": ["name"]
    })
    assert len(result.data) == 2

@pytest.mark.asyncio
async def test_search_tool() -> None:
    # Mock SearchTool to avoid real API calls
    tool = SearchTool(api_key="test")
    
    mock_response = MagicMock()
    mock_response.text = "Gemini CLI results"
    mock_response.candidates = [MagicMock(grounding_metadata=None)]

    with patch.object(tool.client.models, "generate_content", return_value=mock_response):
        result = await tool.execute({"query": "Gemini CLI"})
        assert result.success is True
        assert result.data["answer"] == "Gemini CLI results"
