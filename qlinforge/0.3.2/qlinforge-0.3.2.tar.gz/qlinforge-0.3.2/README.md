# qlinforge - Data Validation & Formatting Toolkit

A lightweight Python utility library for data validation, formatting, and parsing. Designed to simplify common data processing tasks without heavy dependencies.

## Features

- **Validators** — Email, URL, IP address, phone number, and custom regex validation
- **Formatters** — JSON pretty-print, CSV-to-dict conversion, timestamp formatting
- **Parsers** — INI-style config parsing, environment variable expansion
- **Utils** — Hash computation, base64 encoding, random ID generation

## Installation

```bash
pip install qlinforge
```

## Quick Start

```python
from qlinforge import validators, formatters, parsers, utils

# Validate input
assert validators.is_email("user@example.com")
assert validators.is_ipv4("192.168.1.1")
assert validators.is_url("https://github.com")

# Format data
print(formatters.pretty_json({"key": "value", "items": [1, 2, 3]}))
ts = formatters.timestamp_to_str(1700000000, fmt="%Y-%m-%d %H:%M:%S")

# Parse config
config = parsers.parse_ini_string("""
[database]
host = localhost
port = 5432
""")

# Utilities
h = utils.sha256_file("/path/to/file")
uid = utils.random_id(length=16)
```

## Modules

### validators

| Function | Description |
|----------|-------------|
| `is_email(value)` | RFC 5322 simplified email validation |
| `is_url(value)` | HTTP/HTTPS URL validation |
| `is_ipv4(value)` | IPv4 address validation |
| `is_ipv6(value)` | IPv6 address validation |
| `is_phone_cn(value)` | Chinese mobile phone number validation |
| `matches(value, pattern)` | Custom regex matching |

### formatters

| Function | Description |
|----------|-------------|
| `pretty_json(data, indent=2)` | Pretty-print JSON data |
| `csv_to_dict(csv_text)` | Convert CSV text to list of dicts |
| `timestamp_to_str(ts, fmt=None)` | Unix timestamp to formatted string |
| `str_to_timestamp(s, fmt=None)` | Formatted string to Unix timestamp |
| `humanize_bytes(n)` | Human-readable file sizes |

### parsers

| Function | Description |
|----------|-------------|
| `parse_ini_string(text)` | Parse INI-style config from string |
| `parse_env_file(path)` | Parse .env file |
| `expand_env_vars(text)` | Expand `${VAR}` references in text |
| `flatten_dict(d, sep='.')` | Flatten nested dict |

### utils

| Function | Description |
|----------|-------------|
| `md5_hex(data)` | MD5 hash (hex string) |
| `sha256_hex(data)` | SHA-256 hash (hex string) |
| `sha256_file(path)` | SHA-256 hash of a file |
| `b64_encode(data)` | Base64 encode |
| `b64_decode(data)` | Base64 decode |
| `random_id(length=12)` | Random alphanumeric ID |
| `chunk_list(lst, size)` | Split list into chunks |

## License

MIT
