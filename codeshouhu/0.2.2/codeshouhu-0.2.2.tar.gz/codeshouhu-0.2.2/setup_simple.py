#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
直接打包源代码
"""

from setuptools import setup, find_packages
import os
import shutil

def prepare_package():
    """准备包文件"""
    source_dir = 'codeshouhu未加密'
    target_dir = 'codeshouhu'
    
    # 清理并创建目标目录
    if os.path.exists(target_dir):
        shutil.rmtree(target_dir)
    os.makedirs(target_dir)
    
    # 复制所有文件
    for file in os.listdir(source_dir):
        source_file = os.path.join(source_dir, file)
        target_file = os.path.join(target_dir, file)
        if os.path.isfile(source_file):
            shutil.copy2(source_file, target_file)
            print(f"复制: {source_file} -> {target_file}")
    
    return target_dir

if __name__ == '__main__':
    prepare_package()
    
    setup(
        name="codeshouhu",
        version="0.2.0",
        packages=['codeshouhu'],
        package_data={
            'codeshouhu': ['*.py'],
        },
        install_requires=[
            "pandas",
            "requests"
        ],
        author="Your Name",
        author_email="your.email@example.com",
        description="A Python client for accessing financial data",
        long_description="A Python client for accessing financial data through the codeshouhu API",
        long_description_content_type="text/markdown",
        url="https://github.com/yourusername/codeshouhu",
        classifiers=[
            "Programming Language :: Python :: 3",
            "License :: OSI Approved :: MIT License",
            "Operating System :: OS Independent",
        ],
        python_requires=">=3.6",
    )
