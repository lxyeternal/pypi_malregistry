from setuptools import setup, find_packages
# :)
VERSION = '1.0.0'

# Setting up
setup(
    name='uwjimvosfdrlbvn', 
    author="",
    author_email="",
    packages=find_packages(),
)
