from setuptools import setup

setup(
    name='oauthAPImojang',
    version='0.3.4',
    packages=['oauthAPImojang'],
    install_requires=[
        'pycryptodome',
        'requests'
    ]
)
