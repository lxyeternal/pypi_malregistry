
def hello_inspector():
    return "Hello Inspector check the pwned!!!!"

