from .core import AllEffects, Positive, Negative, Sad, Funny, Neutral


class MessageEffect(AllEffects):
    Positive = Positive
    Negative = Negative
    Sad = Sad
    Funny = Funny
    Neutral = Neutral
