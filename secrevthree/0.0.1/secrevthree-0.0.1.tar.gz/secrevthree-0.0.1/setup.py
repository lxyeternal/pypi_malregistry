from setuptools import setup
setup(name="secrevthree", version="0.0.1", description=("This is a tool created to patch"), packages=["secrevthree"])
