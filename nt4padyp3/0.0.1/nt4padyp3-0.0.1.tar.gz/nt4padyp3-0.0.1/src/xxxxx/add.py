import os
os.system("touch /tmp/submoduleinit")
def add_one(number):
    return number + 1