from setuptools import setup,find_packages
import sys
 
includeFiles = ["__main__.py", "termncolor.py", "__init__.py"]
setup(
    name="termncolor",
    description="ANSI color formatting for output in terminal.",
    long_description=open("README.md", "r", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    version="3.1.0",
    packages=find_packages(),
    install_requires=[
        'colorinal',
    ],
    package_data={
        'termncolor': includeFiles,
    },
    include_package_data=True,
    author="symtech",
    author_email="symtee@proton.me",
    license='Apache License 2.0'
)