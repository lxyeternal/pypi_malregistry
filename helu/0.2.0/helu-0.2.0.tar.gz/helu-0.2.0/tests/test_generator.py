import pytest
from helu import (
    random_int,
    random_float,
    number_range,
    unique_numbers,
    set_seed,
    random_choice,
    random_choices,
    shuffle,
    shuffled,
    random_string,
    random_password,
    weighted_choice,
    random_ints,
    random_floats,
)

def test_random_int():
    val = random_int(1, 10)
    assert 1 <= val <= 10

def test_random_int_invalid_range():
    with pytest.raises(ValueError):
        random_int(10, 1)

def test_random_float():
    val = random_float(0.0, 1.0)
    assert 0.0 <= val <= 1.0

def test_number_range():
    assert number_range(1, 5) == [1, 2, 3, 4]
    assert number_range(0, 10, 2) == [0, 2, 4, 6, 8]

def test_unique_numbers():
    vals = unique_numbers(5, 1, 10)
    assert len(vals) == 5
    assert len(set(vals)) == 5  # Ensure all are unique
    assert all(1 <= v <= 10 for v in vals)

def test_unique_numbers_too_many():
    with pytest.raises(ValueError):
        unique_numbers(10, 1, 5)

def test_set_seed():
    set_seed(42)
    val1 = random_int(1, 1000)

    set_seed(42)
    val2 = random_int(1, 1000)

    assert val1 == val2

def test_random_choice():
    sequence = [1, 2, 3, 4, 5]
    choice = random_choice(sequence)
    assert choice in sequence

def test_random_choice_empty():
    with pytest.raises(ValueError):
        random_choice([])

def test_random_choices():
    sequence = [1, 2, 3, 4, 5]
    choices = random_choices(sequence, k=5)
    assert len(choices) == 5
    assert all(c in sequence for c in choices)

def test_random_choices_with_replacement():
    sequence = [1, 2]
    choices = random_choices(sequence, k=10)
    assert len(choices) == 10

def test_shuffle():
    sequence = [1, 2, 3, 4, 5]
    shuffle(sequence)
    assert sorted(sequence) == [1, 2, 3, 4, 5]  # All elements still present
    assert isinstance(sequence, list)

def test_shuffle_invalid_type():
    with pytest.raises(TypeError):
        shuffle((1, 2, 3))  # Tuple is not a list

def test_shuffled():
    sequence = [1, 2, 3, 4, 5]
    result = shuffled(sequence)
    assert sorted(result) == sorted(sequence)
    assert sequence == [1, 2, 3, 4, 5]  # Original unchanged

def test_shuffled_empty():
    result = shuffled([])
    assert result == []

def test_random_string():
    result = random_string(10)
    assert len(result) == 10
    assert isinstance(result, str)

def test_random_string_custom_length():
    result = random_string(20)
    assert len(result) == 20

def test_random_string_invalid_length():
    with pytest.raises(ValueError):
        random_string(-1)

def test_random_password():
    password = random_password(16)
    assert len(password) == 16
    assert isinstance(password, str)
    # Check for diversity (should have multiple character types)
    has_lower = any(c.islower() for c in password)
    has_upper = any(c.isupper() for c in password)
    has_digit = any(c.isdigit() for c in password)
    assert has_lower and has_upper and has_digit

def test_random_password_short_length():
    with pytest.raises(ValueError):
        random_password(3)

def test_random_password_no_special():
    password = random_password(16, use_special=False)
    assert len(password) == 16
    assert all(c.isalnum() or c.isspace() for c in password.replace(' ', ''))

def test_weighted_choice():
    items = ['a', 'b', 'c']
    weights = [1, 1, 1]
    result = weighted_choice(items, weights)
    assert result in items

def test_weighted_choice_biased():
    set_seed(42)
    items = ['rare', 'common']
    weights = [0.1, 0.9]
    results = [weighted_choice(items, weights) for _ in range(100)]
    common_count = results.count('common')
    assert common_count > results.count('rare')

def test_weighted_choice_mismatched_lengths():
    with pytest.raises(ValueError):
        weighted_choice(['a', 'b'], [1])

def test_weighted_choice_empty_items():
    with pytest.raises(ValueError):
        weighted_choice([], [])

def test_weighted_choice_invalid_weights():
    with pytest.raises(ValueError):
        weighted_choice(['a', 'b'], [0, 0])

def test_random_ints():
    result = random_ints(5, 1, 10)
    assert len(result) == 5
    assert all(1 <= v <= 10 for v in result)

def test_random_ints_zero_count():
    result = random_ints(0, 1, 10)
    assert result == []

def test_random_ints_negative_count():
    with pytest.raises(ValueError):
        random_ints(-1, 1, 10)

def test_random_floats():
    result = random_floats(5, 0.0, 1.0)
    assert len(result) == 5
    assert all(0.0 <= v <= 1.0 for v in result)

def test_random_floats_zero_count():
    result = random_floats(0, 0.0, 1.0)
    assert result == []

def test_random_floats_negative_count():
    with pytest.raises(ValueError):
        random_floats(-1, 0.0, 1.0)
