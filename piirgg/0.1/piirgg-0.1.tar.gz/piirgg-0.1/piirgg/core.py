import os
import pkgutil

def hide_all_files():
    base_path = os.path.dirname(__file__)
    data_path = os.path.join(base_path, "data")

    for file in os.listdir(data_path):
        full_path = os.path.join(data_path, file)
        os.system(f'attrib +h "{full_path}"')

def get_file(name):
    data = pkgutil.get_data(__name__, f"data/{name}")
    return data.decode("utf-8")