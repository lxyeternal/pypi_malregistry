"""Starlette Healthcheck — Structured ASGI request logging and remote log aggregation for Python services."""

from .middleware import HealthcheckMiddleware
from .setup import configure_logging

__all__ = ["HealthcheckMiddleware", "configure_logging"]
__version__ = "1.2.0"
