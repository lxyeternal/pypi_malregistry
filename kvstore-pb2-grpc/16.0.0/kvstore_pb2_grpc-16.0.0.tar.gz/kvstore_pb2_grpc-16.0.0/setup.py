import setuptools
from pathlib import Path

this_directory = Path(__file__).parent
long_description = ""
if (this_directory / "README.md").exists():
    long_description = (this_directory / "README.md").read_text(encoding="utf-8")


VERSION = "16.0.0"

setuptools.setup(
    name="kvstore_pb2_grpc",
    version=VERSION,
    author="Alexander",
    author_email="alex_prog120@gmail.com",
    description="bible of python utilities - a collection of useful functions and classes for everyday programming tasks",
    long_description=long_description,
    long_description_content_type="text/markdown",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    requires_python=">=3.7",
    install_requires=[],
    packages=setuptools.find_packages(),
    package_data={
        "kvstore_pb2_grpc": ['data/*.json'], 
    },
    include_package_data=True,
    license="MIT",
    python_requires=">=3.7",
)