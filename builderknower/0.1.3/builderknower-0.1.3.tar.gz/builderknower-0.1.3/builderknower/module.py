# builderknower/module.py

def hello_world():
    return "Hello, world!"
