import argparse

from .banner import startup_banner
from .loader import startup_loader
from .dashboard import dashboard
from .shell import start_shell


def main():

    parser = argparse.ArgumentParser(add_help=False)

    parser.add_argument("command", nargs="?")

    args = parser.parse_args()

    if args.command == "log":

        startup_banner()

        startup_loader()

        dashboard()

        start_shell()

    else:

        print()

        print("Usage:")

        print("   insta log")

        print()