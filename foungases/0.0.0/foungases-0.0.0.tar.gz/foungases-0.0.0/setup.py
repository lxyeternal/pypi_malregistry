from setuptools import setup

setup(
    name='foungases',
    version='',
    description='foungases',
    author='foungases',
    author_email='magalie354615@8s08t4.gpa.lu',
    packages=['foungases'],
    install_requires=[],
)
