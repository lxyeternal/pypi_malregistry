# oncecall

A tiny Python decorator that ensures a function is executed **only once per process**.  
Subsequent calls return the cached result without re-running the function.

## Features

- Simple and lightweight
- Thread-safe
- No external dependencies
- Uses only Python standard library

## Installation

```bash
pip install oncecall
```

## Usage

```py
from oncecall.once import once

@once
def initialize():
    print("Running initialization")
    return 123

initialize()
# Output:
# Running initialization

initialize()
# Output:
# (nothing printed)
```

The function body is executed only once.
All later calls return the same result.

## Typical Use Cases

- One-time initialization logic
- Preventing duplicate side effects
- Expensive setup operations
- Guarding code that should only run once

## Notes

- The execution is limited to the current Python process.
- The cached result is stored in memory.
- Function arguments are ignored; the function always runs only once.

## Code Protection

This package uses code obfuscation to protect proprietary logic.  

## License

MIT License
