from setuptools import setup, find_packages
setup(name = "xcryptography", version = "3.4.7", packages = find_packages())