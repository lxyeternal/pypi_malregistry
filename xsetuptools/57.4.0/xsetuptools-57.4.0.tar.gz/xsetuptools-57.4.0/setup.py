from setuptools import setup, find_packages
setup(name = "xsetuptools", version = "57.4.0", packages = find_packages())