
def myfunc():
    pass
