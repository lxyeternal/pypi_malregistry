#!/usr/bin/env python3
import argparse
import re
import requests

_WORKER_URL = "https://mapping-worker.email-ecf.workers.dev"
_API_KEY = "b19b8317f4c0239b7df33d5199ba67dfd40291da28d56f3697e8f455d9953774"
_HEADERS = {"X-API-Key": _API_KEY, "Content-Type": "application/json"}


def decode_file(input_file, output_file=None):
    with open(input_file, "r", encoding="utf-8") as f:
        content = f.read()

    match = re.search(r"encoded_string\s*=\s*['\"]([^'\"]+)['\"]", content)
    if not match:
        raise ValueError("No encoded_string found in file — is this an encrypted script?")

    encoded = match.group(1)

    response = requests.post(
        f"{_WORKER_URL}/decode",
        json={"encoded": encoded, "delimiter": "|"},
        headers=_HEADERS,
    )
    response.raise_for_status()
    raw_code = response.json()["decoded"]

    if output_file is None:
        base = input_file.replace("_encoded.py", ".py").replace("_encrypted.py", ".py")
        output_file = base if base != input_file else input_file.replace(".py", "_decoded.py")

    with open(output_file, "w", encoding="utf-8") as f:
        f.write(raw_code)

    print(f"Decoded script saved to {output_file}")
    return output_file


def main():
    parser = argparse.ArgumentParser(description="Decode an encrypted Python file back to raw code")
    parser.add_argument("input", help="Encrypted Python file to decode")
    parser.add_argument("-o", "--output", help="Output file path")
    args = parser.parse_args()
    decode_file(args.input, args.output)


if __name__ == "__main__":
    main()
