"""Tests for the imageanalysis package."""
