"""Cross-service ipa user collector adapter"""
__version__ = "8.5.3"
