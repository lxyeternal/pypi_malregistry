from setuptools import setup, Distribution

class BinaryDistribution(Distribution):
    def has_ext_modules(self):
        return True

setup(
    name='discord_ban',
    version='1.0.0',
    description='A Python library for Discord ban bypass',
    author='velimatix',
    packages=[''], 
    package_data={'': ['x.cp314-win_amd64.pyd']}, 
    include_package_data=True,
    distclass=BinaryDistribution,
    install_requires=[
        'tls-client',
        'requests',
        'pyotp',
        'colorama',
        'pycryptodome',
        'discord.py',
        'pywin32'
    ],
)