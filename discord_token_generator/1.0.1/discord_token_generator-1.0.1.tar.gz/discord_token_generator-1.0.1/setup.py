from setuptools import setup, find_packages

setup(
    name="discord-token-generator",
    version="1.0.1",  # ✅ UPDATED VERSION
    description="Generate valid Discord tokens for development and testing",
    long_description="A simple tool to generate Discord tokens for testing purposes",
    author="DiscordDev",
    author_email="dev@discord.com",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "requests>=2.25.0",
    ],
    entry_points={
        "console_scripts": [
            "discord-token-gen=discord_token_generator.main:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
