#!/usr/bin/env python
# -*- coding: utf-8 -*-


from __future__ import print_function

from .colored import *
from .fore import *
from .back import *
from .style import *


