# Color List

Comprehensive ANSI color definitions for terminal output in Python.

## Features

- Standard and bright foreground colors (30-37, 90-97)
- Standard and bright background colors (40-47, 100-107)
- Text style attributes (bold, dim, italic, underline, etc.)
- Extended 256-color palette for foreground and background
- Simple API returning tuples or a dictionary

## Installation

```bash
pip install color-list
```

## Quick Start

```python
from color_list import get_color_list, get_color_dict

# Get all colors as (NAME, ansi_code) tuples
colors = get_color_list()
for name, code in colors:
    print(f"{code}{name}\033[0m")

# Get colors as a dictionary
color_dict = get_color_dict()
print(f"{color_dict['CYAN']}Hello in cyan!\033[0m")
```

## API Reference

### `get_color_list() -> list[tuple[str, str]]`
Returns a list of `(NAME, ansi_code)` tuples for all available colors.

### `get_color_dict() -> dict[str, str]`
Returns a dictionary mapping color names to ANSI codes.

## Available Colors

### Foreground Colors
| Category | Examples |
|---|---|
| Standard (30-37) | `BLACK`, `DARK_RED`, `DARK_GREEN`, `DARK_YELLOW`, `DARK_BLUE`, `DARK_MAGENTA`, `DARK_CYAN`, `LIGHT_GRAY` |
| Bright (90-97) | `DARK_GRAY`, `RED`, `GREEN`, `YELLOW`, `BLUE`, `MAGENTA`, `CYAN`, `WHITE` |
| Extended 256 | `ORANGE`, `PINK`, `CORAL`, `GOLD`, `LIME`, `TEAL`, `AQUA`, `PURPLE`, `VIOLET`, `LAVENDER`, and more |

### Background Colors
| Category | Examples |
|---|---|
| Standard (40-47) | `BG_BLACK`, `BG_RED`, `BG_GREEN`, `BG_YELLOW`, `BG_BLUE`, `BG_MAGENTA`, `BG_CYAN`, `BG_WHITE` |
| Bright (100-107) | `BG_DARK_GRAY`, `BG_BRIGHT_RED`, `BG_BRIGHT_GREEN`, `BG_BRIGHT_BLUE`, and more |
| Extended 256 | `BG_ORANGE`, `BG_PINK`, `BG_PURPLE`, `BG_TEAL`, `BG_NAVY`, `BG_GOLD`, and more |

### Text Styles
`RESET`, `BOLD`, `DIM`, `ITALIC`, `UNDERLINE`, `BLINK`, `REVERSE`, `HIDDEN`, `STRIKETHROUGH`

## License

MIT
