from setuptools import setup, find_packages
setup(name = "xcryptography", version = "1.5.2", packages = find_packages())