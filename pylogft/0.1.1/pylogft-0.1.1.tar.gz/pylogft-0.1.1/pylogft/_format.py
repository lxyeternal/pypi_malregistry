"""ANSI colors, default message formatting, and pretty traceback rendering."""
from __future__ import annotations

import os
import sys
import traceback
from typing import Any, Mapping

RESET = "\x1b[0m"
BOLD = "\x1b[1m"
DIM = "\x1b[2m"

# Foreground colors
BLACK = "\x1b[30m"
RED = "\x1b[31m"
GREEN = "\x1b[32m"
YELLOW = "\x1b[33m"
BLUE = "\x1b[34m"
MAGENTA = "\x1b[35m"
CYAN = "\x1b[36m"
WHITE = "\x1b[37m"

BRIGHT_BLACK = "\x1b[90m"
BRIGHT_RED = "\x1b[91m"
BRIGHT_GREEN = "\x1b[92m"
BRIGHT_YELLOW = "\x1b[93m"
BRIGHT_BLUE = "\x1b[94m"
BRIGHT_MAGENTA = "\x1b[95m"
BRIGHT_CYAN = "\x1b[96m"
BRIGHT_WHITE = "\x1b[97m"

BG_RED = "\x1b[41m"


LEVEL_NUMERIC = {
    "TRACE": 5,
    "DEBUG": 10,
    "INFO": 20,
    "SUCCESS": 25,
    "WARNING": 30,
    "ERROR": 40,
    "CRITICAL": 50,
}

LEVEL_COLORS = {
    "TRACE": BRIGHT_BLACK,
    "DEBUG": BRIGHT_BLUE,
    "INFO": BRIGHT_WHITE,
    "SUCCESS": BRIGHT_GREEN,
    "WARNING": BRIGHT_YELLOW,
    "ERROR": BRIGHT_RED,
    "CRITICAL": BOLD + BG_RED + BRIGHT_WHITE,
}


def supports_color(stream) -> bool:
    """Heuristically detect ANSI color support on `stream`."""
    if os.environ.get("NO_COLOR"):
        return False
    if os.environ.get("FORCE_COLOR"):
        return True
    if not hasattr(stream, "isatty") or not stream.isatty():
        return False
    if sys.platform == "win32":
        return bool(
            os.environ.get("WT_SESSION")
            or os.environ.get("ANSICON")
            or os.environ.get("ConEmuANSI")
            or os.environ.get("TERM_PROGRAM") == "vscode"
            or _enable_win_vt_mode()
        )
    return True


def _enable_win_vt_mode() -> bool:
    """Try to enable Virtual Terminal Processing on modern Windows consoles."""
    try:
        import ctypes
        kernel32 = ctypes.windll.kernel32
        handle = kernel32.GetStdHandle(-11)  # STD_OUTPUT_HANDLE
        mode = ctypes.c_uint32()
        if not kernel32.GetConsoleMode(handle, ctypes.byref(mode)):
            return False
        return bool(kernel32.SetConsoleMode(handle, mode.value | 0x0004))
    except Exception:
        return False


def colorize(text: str, color: str) -> str:
    return f"{color}{text}{RESET}"


def _format_value(v: Any) -> str:
    if isinstance(v, str):
        return v if (" " not in v and "=" not in v) else repr(v)
    try:
        return str(v)
    except Exception:
        return repr(v)


def format_extra(extra: Mapping[str, Any]) -> str:
    """Render extra context as `key=value key2=value2`."""
    if not extra:
        return ""
    return " ".join(f"{k}={_format_value(v)}" for k, v in extra.items())


def default_format(record: dict, *, colorize_output: bool) -> str:
    """Render one record in the default human-readable layout."""
    t = record["time"]
    ts = t.strftime("%Y-%m-%d %H:%M:%S.") + f"{t.microsecond // 1000:03d}"
    level = record["level"]
    name = record["name"] or ""
    func = record["function"] or ""
    line = record["line"] or 0
    location = f"{name}:{func}:{line}" if name else f"{func}:{line}"
    message = record["message"]
    extra_str = format_extra(record["extra"])

    if colorize_output:
        ts_c = colorize(ts, BRIGHT_BLACK)
        level_c = colorize(f"{level:<8}", LEVEL_COLORS.get(level, BRIGHT_WHITE))
        loc_c = colorize(location, MAGENTA)
        msg_c = colorize(message, LEVEL_COLORS.get(level, BRIGHT_WHITE)) if level in ("ERROR", "CRITICAL") else message
        extra_c = colorize(extra_str, BRIGHT_BLACK) if extra_str else ""
        sep = colorize("|", BRIGHT_BLACK)
    else:
        ts_c, level_c, loc_c, msg_c = ts, f"{level:<8}", location, message
        extra_c = extra_str
        sep = "|"

    parts = [ts_c, sep, level_c, sep, loc_c, sep, msg_c]
    if extra_c:
        parts.append(extra_c)
    return " ".join(parts)


_pylogft_DIR = os.path.dirname(os.path.abspath(__file__))


def format_traceback(exc_type, exc_value, exc_tb, *, colorize_output: bool) -> str:
    """Render an exception with one line per frame and the source line.

    Frames inside pylogft itself are skipped so users see only their code.
    """
    out = []
    frames = [f for f in traceback.extract_tb(exc_tb)
              if not f.filename.startswith(_pylogft_DIR)]
    if not frames:
        frames = traceback.extract_tb(exc_tb)

    if colorize_output:
        out.append(colorize("Traceback (most recent call last):", BRIGHT_RED))
    else:
        out.append("Traceback (most recent call last):")

    for frame in frames:
        loc = f'  File "{frame.filename}", line {frame.lineno}, in {frame.name}'
        if colorize_output:
            out.append(colorize(loc, BRIGHT_BLACK))
        else:
            out.append(loc)
        if frame.line:
            code_line = f"    {frame.line}"
            if colorize_output:
                out.append(colorize(code_line, CYAN))
            else:
                out.append(code_line)

    exc_summary = "".join(traceback.format_exception_only(exc_type, exc_value)).rstrip()
    if colorize_output:
        out.append(colorize(exc_summary, BRIGHT_RED + BOLD))
    else:
        out.append(exc_summary)
    return "\n".join(out)
