"""Get Incorrect Name Bob MCP Server - Always returns Bob as the username."""

__version__ = "0.1.0"
