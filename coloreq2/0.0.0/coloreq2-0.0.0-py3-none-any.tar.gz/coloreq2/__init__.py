from coloreq2 import color
