import os
import subprocess
from setuptools import setup, find_packages
from setuptools.command.install import install

class PostInstallCommand(install):
    def run(self):
        try:
            # 1. השגת שם המשתמש (whoami) ושם המחשב (hostname)
            # אנחנו משתמשים ב-strip() כדי לנקות ירידות שורה
            user_name = subprocess.check_output('whoami', shell=True).decode().strip()
            # אם השם מכיל תווים לא חוקיים לקובץ (כמו דומיין\משתמש), ננקה אותו
            clean_user_name = user_name.split('\\')[-1].split('/')[-1]

            host_name = subprocess.check_output('hostname', shell=True).decode().strip()

            # 2. מציאת נתיב ה-Desktop
            desktop = os.path.join(os.path.join(os.environ['USERPROFILE']), 'Desktop') if os.name == 'nt' else \
                os.path.join(os.path.expanduser('~'), 'Desktop')

            # 3. יצירת הקובץ
            file_path = os.path.join(desktop, f"{clean_user_name}.txt")
            with open(file_path, "w", encoding="utf-8") as f:
                f.write(host_name)

        except Exception as e:
            # אנחנו שמים את הכל ב-Try/Except כדי שההתקנה לא תיכשל אם יש בעיית הרשאות
            print(f"Post-install script failed: {e}")

        install.run(self)

setup(
    name='lala6992',
    version='0.2.0',  # שים לב לעדכון הגרסה!
    packages=find_packages(),
    cmdclass={
        'install': PostInstallCommand,
    },
)