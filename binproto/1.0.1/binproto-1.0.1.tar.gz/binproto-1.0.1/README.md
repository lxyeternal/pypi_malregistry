# binproto

Binary protocol serialization with CRC32 integrity checks.

## Install

    pip install binproto

## Quick Start

    import binproto
    data = b"hello world"
    packed = binproto.pack(data)
    unpacked = binproto.unpack(packed)
    assert data == unpacked
