"""Basic tests for pylogft. Run with: ``python -m pytest tests``."""
from __future__ import annotations

import io
import json
import logging
import os
import threading
from pathlib import Path

import pytest

from pylogft import Logger, log


@pytest.fixture
def buf_logger():
    """A fresh Logger writing into an in-memory buffer (no colors)."""
    lg = Logger()
    lg.remove()
    buf = io.StringIO()
    lg.add(buf, colorize=False)
    return lg, buf


def test_basic_levels(buf_logger):
    lg, buf = buf_logger
    lg.info("hello")
    lg.warning("careful")
    lg.error("nope")
    out = buf.getvalue()
    assert "INFO" in out and "hello" in out
    assert "WARNING" in out and "careful" in out
    assert "ERROR" in out and "nope" in out


def test_level_filter(buf_logger):
    lg, buf = buf_logger
    lg.remove()
    buf2 = io.StringIO()
    lg.add(buf2, colorize=False, level="WARNING")
    lg.info("filtered")
    lg.warning("kept")
    out = buf2.getvalue()
    assert "filtered" not in out
    assert "kept" in out


def test_structured_kwargs(buf_logger):
    lg, buf = buf_logger
    lg.info("hello", user="alice", count=3)
    out = buf.getvalue()
    assert "user=alice" in out
    assert "count=3" in out


def test_bind(buf_logger):
    lg, buf = buf_logger
    bound = lg.bind(request_id="abc")
    bound.info("hello")
    out = buf.getvalue()
    assert "request_id=abc" in out


def test_contextualize(buf_logger):
    lg, buf = buf_logger
    with lg.contextualize(job="x"):
        lg.info("inside")
    lg.info("outside")
    out = buf.getvalue()
    inside, outside = out.strip().splitlines()
    assert "job=x" in inside
    assert "job=" not in outside


def test_catch_decorator_no_reraise(buf_logger):
    lg, buf = buf_logger

    @lg.catch
    def boom():
        raise ValueError("nope")

    assert boom() is None
    out = buf.getvalue()
    assert "ERROR" in out
    assert "ValueError" in out
    assert "nope" in out


def test_catch_decorator_with_reraise(buf_logger):
    lg, _ = buf_logger

    @lg.catch(reraise=True)
    def boom():
        raise ValueError("nope")

    with pytest.raises(ValueError):
        boom()


def test_catch_context_manager(buf_logger):
    lg, buf = buf_logger
    with lg.catch():
        raise RuntimeError("inside ctx")
    assert "RuntimeError" in buf.getvalue()
    assert "inside ctx" in buf.getvalue()


def test_exception_helper(buf_logger):
    lg, buf = buf_logger
    try:
        raise KeyError("missing")
    except Exception:
        lg.exception("oops")
    out = buf.getvalue()
    assert "ERROR" in out
    assert "KeyError" in out
    assert "oops" in out


def test_file_sink(tmp_path):
    lg = Logger()
    lg.remove()
    path = tmp_path / "out.log"
    lg.add(str(path))
    lg.info("written to file")
    lg.remove()
    content = path.read_text()
    assert "written to file" in content
    # No ANSI escapes in files
    assert "\x1b[" not in content


def test_file_rotation_by_size(tmp_path):
    lg = Logger()
    lg.remove()
    path = tmp_path / "rot.log"
    lg.add(str(path), rotate=200, keep=5)
    for i in range(50):
        lg.info("padding " * 10 + f"#{i}")
    lg.remove()
    files = list(tmp_path.iterdir())
    assert len(files) > 1, f"expected multiple files, got: {files}"


def test_json_serialize(tmp_path):
    lg = Logger()
    lg.remove()
    path = tmp_path / "events.jsonl"
    lg.add(str(path), serialize=True)
    lg.info("hello", user="alice", n=3)
    lg.remove()
    line = path.read_text().strip()
    record = json.loads(line)
    assert record["message"] == "hello"
    assert record["level"] == "INFO"
    assert record["extra"]["user"] == "alice"
    assert record["extra"]["n"] == 3


def test_custom_format_string(buf_logger):
    lg, _ = buf_logger
    lg.remove()
    buf2 = io.StringIO()
    lg.add(buf2, colorize=False, format="[{level}] {message}")
    lg.info("hi")
    assert buf2.getvalue().strip() == "[INFO] hi"


def test_custom_format_callable(buf_logger):
    lg, _ = buf_logger
    lg.remove()
    buf2 = io.StringIO()
    lg.add(buf2, colorize=False, format=lambda r: f"<{r['level']}|{r['message']}>")
    lg.info("hi")
    assert buf2.getvalue().strip() == "<INFO|hi>"


def test_filter_excludes(buf_logger):
    lg, _ = buf_logger
    lg.remove()
    buf2 = io.StringIO()
    lg.add(buf2, colorize=False, filter=lambda r: "skip" not in r["message"])
    lg.info("keep me")
    lg.info("please skip me")
    out = buf2.getvalue()
    assert "keep me" in out
    assert "skip" not in out


def test_callable_sink(buf_logger):
    lg, _ = buf_logger
    lg.remove()
    captured: list[str] = []
    lg.add(captured.append)
    lg.info("via callable")
    assert any("via callable" in line for line in captured)


def test_remove_specific_sink(buf_logger):
    lg, _ = buf_logger
    buf2 = io.StringIO()
    sid = lg.add(buf2, colorize=False)
    lg.info("a")
    lg.remove(sid)
    lg.info("b")
    out = buf2.getvalue()
    assert "a" in out
    assert "b" not in out


def test_thread_safety(buf_logger):
    lg, buf = buf_logger
    N = 8
    M = 30

    def worker(n):
        for i in range(M):
            lg.info("msg", worker=n, i=i)

    threads = [threading.Thread(target=worker, args=(i,)) for i in range(N)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    lines = buf.getvalue().strip().splitlines()
    assert len(lines) == N * M
    # Each line should be a complete log line (no interleaved partial writes)
    for ln in lines:
        assert "INFO" in ln
        assert "msg" in ln


def test_stdlib_intercept(buf_logger):
    lg, buf = buf_logger
    lg.intercept_stdlib(level="DEBUG")
    third_party = logging.getLogger("third.party.module")
    third_party.warning("hello from stdlib")
    out = buf.getvalue()
    assert "WARNING" in out
    assert "hello from stdlib" in out
    assert "third.party.module" in out

    # Cleanup so other tests aren't affected
    root = logging.getLogger()
    for h in list(root.handlers):
        root.removeHandler(h)


def test_named_placeholder_formatting(buf_logger):
    lg, buf = buf_logger
    lg.info("user {name} from {ip}", name="alice", ip="10.0.0.1")
    out = buf.getvalue()
    assert "user alice from 10.0.0.1" in out


def test_global_log_object_works():
    """Smoke test: the singleton `log` works without explicit setup."""
    log.info("smoke test", flag=True)
