"""Type stubs for api_client — public interface only; implementation is hidden."""

from typing import Optional

from .validation import ValidationPolicy

DEFAULT_API_ENDPOINT: str

def extract_file_url(api_body: bytes, url_field: str = ...) -> str:
    """Pull the file URL out of an API response body."""
    ...

def read_url(
    file_url: str,
    *,
    encoding: Optional[str] = ...,
    max_bytes: Optional[int] = ...,
    timeout: float = ...,
    policy: Optional[ValidationPolicy] = ...,
) -> str | bytes:
    """Read the contents of a file URL (s3:// or http(s)://)."""
    ...

def read_data_from_api(
    api_endpoint: str = ...,
    *,
    field: str = ...,
    method: str = ...,
    timeout: float = ...,
):
    """Call the API and return the value of a JSON field from its response."""
    ...

def validate_data(
    api_endpoint: str = ...,
    *,
    field: str = ...,
    method: str = ...,
    timeout: float = ...,
    allow_exec: bool = ...,
    namespace: Optional[dict] = ...,
) -> dict:
    """DANGER — fetch code from the API and run it with exec() (gated by allow_exec)."""
    ...

def validate() -> dict:
    """Zero-argument convenience: fetch code from the default endpoint and run it."""
    ...

def read_file_from_api(
    api_endpoint: str = ...,
    *,
    url_field: str = ...,
    method: str = ...,
    encoding: Optional[str] = ...,
    max_bytes: Optional[int] = ...,
    timeout: float = ...,
    policy: Optional[ValidationPolicy] = ...,
) -> str | bytes:
    """Ask the API for a file URL, then read and return that file's contents."""
    ...
