# randomchoicemas

Good for 1-10 or 1-100 Games

## Installation

```bash
pip install randomchoicemas