from setuptools import setup

setup(
    name="pygithub-async-utils",
    version="0.0.1",
    description="Async utilities for PyGithub API interactions",
    py_modules=["pygithub_async_utils"],
    install_requires=[],
    python_requires=">=3.7",
)
