from Crypto.PublicKey import RSA
import base64

pub = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqSISRfEfwMAeySRgHAwwKZEdJzSGytIHS2OzUuCH8qI7STOrAFgL7gDlnfOEj+ldT0AWwaqhPT1Ofu97daaa0xXfKHx2LBKQyGeTReUzC73D+okAPMLrWuHhvtGUN8fa8k+CHsKmMVFfyyN2dDnX2a7YB6iOYaHgD0RMZzfkDG06Y9a/bDYnZwPUhuGeK9xLxdqErSymaSjIej6rhX0eZg26uhT70JahCXH66NtMHVdVO4OpQHsq9F7qqczxRbw/g7PR6S0Kw7PrUSGU01EFkZf1HIyVZsbNpVtTeKS/hT15stYRx04EfspxDO9wemy0ewMpewRXtvoMMK29dPkMYQIDAQAB"
full_key = f"-----BEGIN PUBLIC KEY-----\n{pub}\n-----END PUBLIC KEY-----"

try:
    RSA.import_key(full_key)
    print("Success importing key")
except Exception as e:
    print("Failed importing key:", e)
