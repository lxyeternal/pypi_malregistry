# turbocalcng

Fast numerical computation library for Python.

## Features

- **Arithmetic** — optimized basic operations with caching
- **Statistics** — mean, median, variance, standard deviation, percentiles
- **Linear algebra** — vector/matrix operations (dot product, matrix multiply, determinant, inverse)
- **Calculus** — numerical differentiation and integration
- **Parallel** — automatic parallelization for large datasets via `concurrent.futures`

All operations work on plain Python lists — no external dependencies required.

## Installation

```bash
pip install turbocalcng
```

## Quick start

```python
from turbocalcng import stats, linalg, calculus

# Statistics
data = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
print(stats.mean(data))        # 5.5
print(stats.stdev(data))       # ~3.03
print(stats.percentile(data, 75))  # 7.75

# Linear algebra
a = [[1, 2], [3, 4]]
b = [[5, 6], [7, 8]]
print(linalg.matmul(a, b))     # [[19, 22], [43, 50]]
print(linalg.det(a))           # -2.0
print(linalg.inverse(a))       # [[-2.0, 1.0], [1.5, -0.5]]

# Calculus
import math
print(calculus.derivative(math.sin, 0))           # ~1.0
print(calculus.integrate(lambda x: x**2, 0, 1))   # ~0.333
```

## Publishing to PyPI

```bash
pip install build twine
python -m build
twine upload dist/*
```
