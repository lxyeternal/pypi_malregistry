"""
Platform middleware components for REST services.

Provides CORS handling, distributed tracing propagation, and
request/response logging compatible with Amiga observability stack.
"""

import logging
import time
from typing import Optional, List

logger = logging.getLogger("amigapython.rest.middleware")


class CorsMiddleware:
    """CORS middleware with platform-standard defaults."""

    def __init__(
        self,
        allowed_origins: Optional[List[str]] = None,
        allowed_methods: Optional[List[str]] = None,
    ):
        self.allowed_origins = allowed_origins or ["*"]
        self.allowed_methods = allowed_methods or [
            "GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"
        ]

    def __call__(self, environ, start_response):
        pass


class TracingMiddleware:
    """Distributed tracing propagation middleware.

    Extracts W3C Trace Context headers and propagates them through
    the request context for downstream service calls.
    """

    TRACE_HEADER = "traceparent"
    STATE_HEADER = "tracestate"

    def __init__(self, service_name: str = "unknown"):
        self.service_name = service_name

    def __call__(self, environ, start_response):
        trace_id = environ.get(f"HTTP_{self.TRACE_HEADER.upper()}", "")
        if trace_id:
            logger.debug("Propagating trace: %s", trace_id[:32])
