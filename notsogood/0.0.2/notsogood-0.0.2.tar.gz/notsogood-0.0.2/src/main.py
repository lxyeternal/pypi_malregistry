def hi_there():
    print("This is fine!")