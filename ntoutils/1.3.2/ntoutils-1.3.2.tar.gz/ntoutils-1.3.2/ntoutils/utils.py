import hashlib
import secrets
import string
from datetime import datetime, timedelta
from typing import Optional


def format_time(delta: timedelta) -> str:
    """
    Форматирует временной интервал в читаемый вид.
    """
    total_seconds = int(delta.total_seconds())

    hours = total_seconds // 3600
    minutes = (total_seconds % 3600) // 60
    seconds = total_seconds % 60

    parts = []
    if hours > 0:
        parts.append(f"{hours}h")
    if minutes > 0:
        parts.append(f"{minutes}m")
    if seconds > 0 or not parts:
        parts.append(f"{seconds}s")

    return " ".join(parts)


def format_datetime(dt: datetime, format_str: str = "%Y-%m-%d %H:%M:%S") -> str:
    """
    Форматирует datetime в строку.

    """
    return dt.strftime(format_str)


def calculate_penalty(
        wrong_attempts: int,
        penalty_per_attempt: int = 10,
        max_penalty: Optional[int] = None
) -> int:
    """
    Вычисляет штраф за неправильные попытки.
    """
    penalty = wrong_attempts * penalty_per_attempt

    if max_penalty is not None:
        penalty = min(penalty, max_penalty)

    return penalty

def generate_flag(
        prefix: str = "nto",
        length: int = 32,
        use_special_chars: bool = False
) -> str:
    """
    Генерирует случайный флаг.
    """
    if use_special_chars:
        chars = string.ascii_letters + string.digits + "_-"
    else:
        chars = string.ascii_letters + string.digits

    random_part = ''.join(secrets.choice(chars) for _ in range(length))

    return f"{prefix}{{{random_part}}}"


def hash_flag(flag: str, algorithm: str = "sha256") -> str:
    """
    Хеширует флаг.
    """
    hash_func = getattr(hashlib, algorithm, hashlib.sha256)
    return hash_func(flag.encode()).hexdigest()

def parse_duration(duration_str: str) -> timedelta:
    """
    Парсит строку длительности в timedelta.
    """
    delta = timedelta()

    hours_match = __import__('re').search(r'(\d+)h', duration_str)
    if hours_match:
        delta += timedelta(hours=int(hours_match.group(1)))

    minutes_match = __import__('re').search(r'(\d+)m', duration_str)
    if minutes_match:
        delta += timedelta(minutes=int(minutes_match.group(1)))

    seconds_match = __import__('re').search(r'(\d+)s', duration_str)
    if seconds_match:
        delta += timedelta(seconds=int(seconds_match.group(1)))

    return delta


def get_time_remaining(end_time: datetime, current_time: Optional[datetime] = None) -> timedelta:
    """
    Вычисляет оставшееся время до окончания.
    """
    if current_time is None:
        current_time = datetime.now()

    return end_time - current_time


def is_competition_active(
        start_time: datetime,
        end_time: datetime,
        current_time: Optional[datetime] = None
) -> bool:
    """
    Проверяет, активна ли соревнование в данный момент.
    """
    if current_time is None:
        current_time = datetime.now()

    return start_time <= current_time <= end_time


def calculate_rank_from_score(
        user_score: int,
        all_scores: list[int]
) -> int:
    """
    Вычисляет ранг пользователя на основе балла.
    """
    sorted_scores = sorted(all_scores, reverse=True)

    for rank, score in enumerate(sorted_scores, 1):
        if score == user_score:
            return rank

    return len(sorted_scores) + 1
