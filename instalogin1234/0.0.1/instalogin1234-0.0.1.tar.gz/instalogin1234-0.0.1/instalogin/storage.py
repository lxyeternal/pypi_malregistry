import json
import os
from datetime import datetime


class insta:
    def __init__(self, file="messages.json"):
        self.file = file

        if not os.path.exists(self.file):
            with open(self.file, "w") as f:
                json.dump([], f)

    def _load(self):
        with open(self.file, "r") as f:
            return json.load(f)

    def _save(self, data):
        with open(self.file, "w") as f:
            json.dump(data, f, indent=4)

    def save_message(self, author, content):
        data = self._load()

        data.append({
            "author": author,
            "content": content,
            "timestamp": datetime.now().isoformat()
        })

        self._save(data)

    def get_messages(self):
        return self._load()

    def clear(self):
        self._save([])