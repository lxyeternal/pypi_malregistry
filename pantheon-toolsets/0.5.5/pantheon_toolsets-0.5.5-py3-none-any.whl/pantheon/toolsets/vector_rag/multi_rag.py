from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Dict, List, Tuple


@dataclass
class QueryIntent:
    """Lightweight intent object for omics query routing.

    Attributes:
        domain: Coarse domain label, typically 'biology' or 'mixed'.
        confidence: Heuristic score in [0, 1].
        keywords: Matched keyword snippets helpful for debugging/routing.
        matched_domains: Canonical subdomains detected (e.g., 'scRNA-seq').
    """

    domain: str
    confidence: float
    keywords: List[str] = field(default_factory=list)
    matched_domains: List[str] = field(default_factory=list)


class RAGRouter:
    """Rule-based router for omics-related queries.

    Provides:
    - analyze_query(): classify query and compute confidence/keywords
    - route_query(): map query to configured databases using detected subdomains

    Config format:
        {
          'databases': {
            'scrna':   {'domains': ['scRNA-seq'], 'path': '/path/scrna'},
            'scatac':  {'domains': ['scATAC-seq'], 'path': '/path/scatac'},
            'multiomics': {'domains': ['single cell multi-omics'], 'path': '...'},
            'spatial': {'domains': ['spatial transcriptomics'], 'path': '...'},
            ...
          }
        }
    """

    # Canonical domain names used for mapping
    CANONICAL_DOMAINS = (
        "scRNA-seq",
        "scATAC-seq",
        "single cell multi-omics",
        "spatial transcriptomics",
    )

    # Synonym patterns for domain detection
    HIGH_CONF_PATTERNS: List[Tuple[str, str, str]] = [
        # (regex, canonical_domain, keyword)
        (r"\bscRNA[-\s]?seq\b|\bscrna\b|single\s+cell\s+rna|\bscanpy\b", "scRNA-seq", "scRNA-seq"),
        (r"\bscATAC[-\s]?seq\b|\bscatac\b|chromatin\s+accessibility|\barchr\b|\bsignac\b", "scATAC-seq", "scATAC-seq"),
        (r"single\s+cell\s+multi[-\s]?omics|\bmultiome\b|\bmultiomics\b|spatial\s+multi[-\s]?omics", "single cell multi-omics", "multi-omics"),
        (r"spatial\s+transcriptomics|\bvisium\b|squidpy", "spatial transcriptomics", "spatial transcriptomics"),
    ]

    MEDIUM_CONF_PATTERNS: List[Tuple[str, str]] = [
        # (regex, keyword)
        (r"\bmultimodal\b", "multimodal"),
        (r"integrative\s+analysis.*epigenomic", "integrative epigenomics"),
        (r"\batac[-\s]?seq\b.*peak|peak\s+analysis", "ATAC-seq peak analysis"),
        (r"tss\s+enrichment", "TSS enrichment"),
        (r"frip\s+score|\bfrip\b", "FRiP score"),
        (r"co[-\s]?accessibilit(y|ies)", "co-accessibility"),
    ]

    GENERIC_KEYWORDS: List[Tuple[str, str]] = [
        (r"quality\s+control|\bqc\b", "quality control"),
        (r"peak\s+calling", "peak calling"),
        (r"integration|integrat(e|ion)", "integration"),
        (r"workflow|pipeline", "workflow"),
        (r"visuali(s|z)ation|plot", "visualization"),
    ]

    def __init__(self, config: Dict):
        self.config = config or {}
        self.databases = self.config.get("databases", {})

        # Build domain->db mapping for quick lookup
        self.domain_to_dbs: Dict[str, List[str]] = {}
        for db_name, db_cfg in self.databases.items():
            for dom in db_cfg.get("domains", []) or []:
                key = str(dom).strip().lower()
                if not key:
                    continue
                self.domain_to_dbs.setdefault(key, []).append(db_name)

    def analyze_query(self, query: str) -> QueryIntent:
        q = (query or "").lower().strip()
        keywords: List[str] = []
        matched_domains: List[str] = []

        # Detect high-confidence domain patterns
        confidence = 0.0
        for pattern, canonical, kw in self.HIGH_CONF_PATTERNS:
            if re.search(pattern, q):
                if canonical not in matched_domains:
                    matched_domains.append(canonical)
                if kw not in keywords:
                    keywords.append(kw)
        if matched_domains:
            # High confidence when a canonical domain is clearly present
            confidence = max(confidence, 0.85)

        # Detect medium-confidence omics concepts
        for pattern, kw in self.MEDIUM_CONF_PATTERNS:
            if re.search(pattern, q):
                if kw not in keywords:
                    keywords.append(kw)
                confidence = max(confidence, 0.6 if not matched_domains else confidence)

        # Add generic keywords (does not change domain classification)
        for pattern, kw in self.GENERIC_KEYWORDS:
            if re.search(pattern, q) and kw not in keywords:
                keywords.append(kw)

        # Domain classification
        domain = "biology" if matched_domains or confidence >= 0.5 else "mixed"

        return QueryIntent(domain=domain, confidence=round(confidence, 2), keywords=keywords, matched_domains=matched_domains)

    def route_query(self, query: str, strategy: str = "smart") -> List[str]:
        """Route query to database names based on detected subdomains.

        Args:
            query: User query
            strategy: Currently supports 'smart' (default). Other values will
                      fall back to returning all databases when configured.
        Returns:
            List of database keys to query.
        """
        if not self.databases:
            return []

        if strategy != "smart":
            return list(self.databases.keys())

        intent = self.analyze_query(query)
        q = (query or "").lower()

        # Map synonyms that imply specific canonical domains
        inferred_domains: List[str] = list(intent.matched_domains)

        if re.search(r"chromatin\s+accessibility", q) and "scATAC-seq" not in inferred_domains:
            inferred_domains.append("scATAC-seq")
        if re.search(r"\batac[-\s]?seq\b", q) and "scATAC-seq" not in inferred_domains:
            inferred_domains.append("scATAC-seq")

        # Find DBs whose declared domains include any inferred canonical domain
        routed: List[str] = []
        for canonical in inferred_domains:
            key = canonical.lower()
            routed.extend(self.domain_to_dbs.get(key, []))

        # Deduplicate while preserving order
        seen = set()
        routed_unique = []
        for db in routed:
            if db not in seen:
                routed_unique.append(db)
                seen.add(db)

        # Fallback: if nothing matched, return all DBs as a broad search
        return routed_unique if routed_unique else list(self.databases.keys())

