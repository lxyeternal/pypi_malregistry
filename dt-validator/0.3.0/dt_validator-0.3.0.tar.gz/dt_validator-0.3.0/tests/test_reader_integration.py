"""Integration tests for the reader using a moto-simulated S3 backend."""

import json

import boto3
import pytest

moto = pytest.importorskip("moto")
from moto import mock_aws  # noqa: E402

from dt_validator.exceptions import ObjectNotFoundError  # noqa: E402
from dt_validator.reader import (  # noqa: E402
    head_object,
    read_object,
)
from dt_validator.validation import ValidationPolicy  # noqa: E402

BUCKET = "open-test-bucket"
KEY = "dir/notes.txt"
BODY = b"hello from an open bucket\n"


@pytest.fixture
def s3_object():
    with mock_aws():
        client = boto3.client("s3", region_name="us-east-1")
        client.create_bucket(Bucket=BUCKET)
        # Make the object genuinely public so anonymous (unsigned) reads succeed,
        # mirroring the real "open S3" scenario this package targets.
        client.put_bucket_policy(
            Bucket=BUCKET,
            Policy=json.dumps(
                {
                    "Version": "2012-10-17",
                    "Statement": [
                        {
                            "Effect": "Allow",
                            "Principal": "*",
                            # Real S3 folds HEAD under s3:GetObject; moto wants
                            # s3:HeadObject spelled out explicitly.
                            "Action": ["s3:GetObject", "s3:HeadObject"],
                            "Resource": f"arn:aws:s3:::{BUCKET}/*",
                        }
                    ],
                }
            ),
        )
        client.put_object(
            Bucket=BUCKET, Key=KEY, Body=BODY, ContentType="text/plain"
        )
        yield f"s3://{BUCKET}/{KEY}"


def test_read_returns_text(s3_object):
    assert read_object(s3_object) == BODY.decode()


def test_read_returns_bytes(s3_object):
    assert read_object(s3_object, encoding=None) == BODY


def test_read_max_bytes_range(s3_object):
    assert read_object(s3_object, max_bytes=5) == "hello"


def test_head_metadata(s3_object):
    meta = head_object(s3_object)
    assert meta.size == len(BODY)
    assert meta.content_type == "text/plain"
    assert meta.location.bucket == BUCKET
    assert meta.etag


def test_missing_object_raises_not_found(s3_object):
    with pytest.raises(ObjectNotFoundError):
        read_object(f"s3://{BUCKET}/does-not-exist.txt")


def test_read_with_passing_policy(s3_object):
    policy = ValidationPolicy(
        allowed_extensions=[".txt"],
        allowed_content_types=["text/plain"],
        max_bytes=1000,
        require_non_empty=True,
        expected_encoding="utf-8",
    )
    assert read_object(s3_object, policy=policy) == BODY.decode()


def test_read_with_failing_extension_policy(s3_object):
    from dt_validator.exceptions import ExtensionError

    policy = ValidationPolicy(allowed_extensions=[".csv"])
    with pytest.raises(ExtensionError):
        read_object(s3_object, policy=policy)


def test_read_with_failing_size_policy(s3_object):
    from dt_validator.exceptions import FileSizeError

    policy = ValidationPolicy(max_bytes=3)
    with pytest.raises(FileSizeError):
        read_object(s3_object, policy=policy)
