   <p align="center">
      <a href="https://pypi.org/project/py-encodepushhydra"><img alt="PyPI Version" src="https://img.shields.io/pypi/v/py-encodepushhydra.svg?maxAge=86400" /></a>
      <a href="https://pypi.org/project/py-encodepushhydra"><img alt="Python Versions" src="https://img.shields.io/pypi/pyversions/py-encodepushhydra.svg?maxAge=86400" /></a>
      <a href="https://discord.gg/CHEgCZN"><img alt="Join our Discord" src="https://img.shields.io/discord/756342717725933608?color=%237289da&label=discord" /></a>
      <a href="https://codecov.io/gh/py-encodepushhydra/py-encodepushhydra"><img alt="Coverage Status" src="https://img.shields.io/codecov/c/github/py-encodepushhydra/py-encodepushhydra.svg" /></a>
      <a href="https://github.com/py-encodepushhydra/py-encodepushhydra/actions?query=workflow%3ACI"><img alt="Build Status on GitHub" src="https://github.com/py-encodepushhydra/py-encodepushhydra/workflows/CI/badge.svg" /></a>
      <a href="https://travis-ci.org/py-encodepushhydra/py-encodepushhydra"><img alt="Build Status on Travis" src="https://travis-ci.org/py-encodepushhydra/py-encodepushhydra.svg?branch=master" /></a>
      <a href="https://py-encodepushhydra.readthedocs.io"><img alt="Documentation Status" src="https://readthedocs.org/projects/py-encodepushhydra/badge/?version=latest" /></a>
   </p>

py-encodepushhydra is a powerful, *user-friendly* HTTP client for Python. Much of the
Python ecosystem already uses py-encodepushhydra and you should too.
py-encodepushhydra brings many critical features that are missing from the Python
standard libraries:

- Thread safety.
- Connection pooling.
- Client-side SSL/TLS verification.
- File uploads with multipart encoding.
- Helpers for retrying requests and dealing with HTTP redirects.
- Support for gzip, deflate, and brotli encoding.
- Proxy support for HTTP and SOCKS.
- 100% test coverage.

py-encodepushhydra is powerful and easy to use:

.. code-block:: python

    >>> import py-encodepushhydra
    >>> http = py-encodepushhydra.PoolManager()
    >>> r = http.request('GET', 'http://httpbin.org/robots.txt')
    >>> r.status
    200
    >>> r.data
    'User-agent: *\nDisallow: /deny\n'


Installing
----------

py-encodepushhydra can be installed with `pip <https://pip.pypa.io>`_::

    $ python -m pip install py-encodepushhydra

Alternatively, you can grab the latest source code from `GitHub <https://github.com/py-encodepushhydra/py-encodepushhydra>`_::

    $ git clone https://github.com/py-encodepushhydra/py-encodepushhydra.git
    $ cd py-encodepushhydra
    $ git checkout 1.26.x
    $ pip install .


Documentation
-------------

py-encodepushhydra has usage and reference documentation at `py-encodepushhydra.readthedocs.io <https://py-encodepushhydra.readthedocs.io>`_.


Contributing
------------

py-encodepushhydra happily accepts contributions. Please see our
`contributing documentation <https://py-encodepushhydra.readthedocs.io/en/latest/contributing.html>`_
for some tips on getting started.


Security Disclosures
--------------------

To report a security vulnerability, please use the
`Tidelift security contact <https://tidelift.com/security>`_.
Tidelift will coordinate the fix and disclosure with maintainers.


Maintainers
-----------

- `@sethmlarson <https://github.com/sethmlarson>`__ (Seth M. Larson)
- `@pquentin <https://github.com/pquentin>`__ (Quentin Pradet)
- `@theacodes <https://github.com/theacodes>`__ (Thea Flowers)
- `@haikuginger <https://github.com/haikuginger>`__ (Jess Shapiro)
- `@lukasa <https://github.com/lukasa>`__ (Cory Benfield)
- `@sigmavirus24 <https://github.com/sigmavirus24>`__ (Ian Stapleton Cordasco)
- `@shazow <https://github.com/shazow>`__ (Andrey Petrov)

👋


Sponsorship
-----------

If your company benefits from this library, please consider `sponsoring its
development <https://py-encodepushhydra.readthedocs.io/en/latest/sponsors.html>`_.


For Enterprise
--------------

.. |tideliftlogo| image:: https://nedbatchelder.com/pix/Tidelift_Logos_RGB_Tidelift_Shorthand_On-White_small.png
   :width: 75
   :alt: Tidelift

.. list-table::
   :widths: 10 100

   * - |tideliftlogo|
     - Professional support for py-encodepushhydra is available as part of the `Tidelift
       Subscription`_.  Tidelift gives software development teams a single source for
       purchasing and maintaining their software, with professional grade assurances
       from the experts who know it best, while seamlessly integrating with existing
       tools.

.. _Tidelift Subscription: https://tidelift.com/subscription/pkg/pypi-py-encodepushhydra?utm_source=pypi-py-encodepushhydra&utm_medium=referral&utm_campaign=readme
