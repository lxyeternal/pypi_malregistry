from setuptools import setup, find_packages

setup(
    name="metadata-checker",
    version="1.2.0",
    # 自动寻找当前目录下包含 __init__.py 的文件夹
    packages=find_packages(),
    # 必须包含 requests 库，否则你的代码无法运行
    install_requires=[
        'requests',
    ],
    # 元数据，让它看起来更正式
    author="DevOps-Internal",
    description="A local metadata consistency validator.",
    python_requires='>=3.6',
)
