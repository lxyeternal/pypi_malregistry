from setuptools import setup

setup(
    name='pandarequests',
    version='0.1.0',
    packages=['pandarequests'],
    url='',
    license='',
    author='dark',
    author_email='email@example.com',
    description='email@example.com'
)