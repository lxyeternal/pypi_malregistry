# alembic-util

migrations

## Installation

```bash
pip install alembic-util
```

## Usage

```python
import alembic_util
```

## License

MIT
