"""Utility functions for quantitative analysis."""
__version__ = '1.0.0'

def moving_average(data, window=20):
    """Calculate simple moving average."""
    if len(data) < window:
        return []
    return [sum(data[i:i+window])/window for i in range(len(data)-window+1)]
