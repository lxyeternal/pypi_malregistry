"""Domain Research Toolset - OmicVerse integration with a safe demo fallback.

- If OmicVerse's domain research module is importable, uses it to run the
  full pipeline with optional live web retrieval and guarded synthesis.
- Otherwise, falls back to a deterministic offline demo implementation.
"""

from __future__ import annotations

from typing import Any, Dict

from ..utils.toolset import ToolSet, tool
from ..utils.log import logger


class DomainResearchToolSet(ToolSet):
    """Domain Research toolset.

    Tools
    -----
    - run_research: Generate a report for a query.
    """

    def __init__(self, name: str, worker_params: dict | None = None, **kwargs: Any):
        super().__init__(name, worker_params, **kwargs)

    # ------------------------------------------------------------------
    def _load_omicverse(self):
        try:
            from omicverse.llm.domain_research import ResearchManager
            from omicverse.llm.domain_research.write.synthesizer import (
                PromptSynthesizer,
            )
            return ResearchManager, PromptSynthesizer
        except Exception as e:  # pragma: no cover - depends on env
            logger.warning(f"OmicVerse domain research unavailable, using demo mode: {e}")
            return None, None

    def _demo_report(self, query: str, fmt: str = "markdown") -> str:
        # Very small deterministic report body without external deps
        if fmt == "html":
            return (
                f"<h1>{query}</h1>\n"
                f"<h2>Executive Summary</h2>\n<p>Objectives: {query}</p>\n"
                f"<h2>Findings</h2>\n<p>Evidence gathered for: {query}</p>\n"
                f"<h2>References</h2>\n<ol>\n<li>Demo Source (https://example.org)</li>\n</ol>"
            )
        return (
            f"# {query}\n\n"
            f"## Executive Summary\nObjectives: {query}\n\n"
            f"## Findings\nEvidence gathered for: {query}\n\n"
            f"## References\n[1] Demo Source (https://example.org)\n"
        )

    # ------------------------------------------------------------------
    @tool(job_type="thread")
    def run_research(
        self,
        *,
        query: str,
        backend: str = "demo",
        fmt: str = "markdown",
        synth: bool = False,
        model: str = "gpt-5",
        base_url: str | None = None,
        api_key: str | None = None,
        llm_scope: bool = False,
        cache: bool = False,
        verify: bool = False,
    ) -> Dict[str, Any]:
        """Run domain research and return a report.

        Args:
            query: Research question or prompt.
            backend: One of 'demo', 'web', 'web:duckduckgo', 'web:tavily', 'web:embed', ...
            fmt: 'markdown' or 'html'.
            synth: If True and OmicVerse available, use online PromptSynthesizer.
            model, base_url, api_key: Synthesizer configuration when synth=True.
            llm_scope: If True, enable LLM-assisted scoping when available.
        Returns:
            Dict with keys: report, backend_used, used_demo.
        """
        backend = (backend or "demo").lower()
        if backend == "demo":
            return {"report": self._demo_report(query, fmt), "backend_used": "demo", "used_demo": True}

        ResearchManager, PromptSynthesizer = self._load_omicverse()
        if ResearchManager is None:
            # Fallback if import failed
            return {"report": self._demo_report(query, fmt), "backend_used": "demo", "used_demo": True}

        # Configure synthesizer if requested
        synthesizer = None
        if synth and base_url and api_key:
            synthesizer = PromptSynthesizer(model=model, base_url=base_url, api_key=api_key)

        # Instantiate manager with selected backend
        rm = ResearchManager(
            vector_store=backend,
            fmt=fmt,
            synthesizer=synthesizer,
            llm_scope=llm_scope,
            cache=cache,
            verify=verify,
        )
        report = rm.run(query)
        return {"report": report, "backend_used": backend, "used_demo": False}
