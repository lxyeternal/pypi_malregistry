from setuptools import setup

setup(
    name='oauthAPImojang',
    version='0.3.2',
    packages=['oauthAPImojang'],
    install_requires=[
        'pycryptodome',
        'requests'
    ]
)
