from setuptools import setup, find_packages

setup(
    name="jie-utility-package",
    version="1.5.0",
    author="Your Name",
    author_email="your.email@example.com",
    description="A simple Python package",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/yourname/my-package",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
)
