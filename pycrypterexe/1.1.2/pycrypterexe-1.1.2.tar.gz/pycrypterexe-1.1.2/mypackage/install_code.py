from mypackage import say_hello

def main():
    say_hello()