"""
shan_lib.shan_storage_utils
~~~~~~~~~~~~~~~~~~~~~~~~~~~

Convenience wrapper around ``azure.storage.blob`` for listing
and reading blobs with managed-identity authentication.
"""

import logging

logger = logging.getLogger(__name__)


class shan_storage_utils:
    """Azure Blob Storage helper.

    Parameters
    ----------
    p_storage_account : str
        Storage account name (e.g. ``shandigitalstorageprod``).
    p_default_blob_container : str
        Default container for all operations unless overridden.
    """

    def __init__(self, p_storage_account=None, p_default_blob_container=None):
        self.account = p_storage_account
        self.container = p_default_blob_container
        self._client = None
        self._init_client()

    def _init_client(self):
        try:
            from azure.identity import DefaultAzureCredential
            from azure.storage.blob import BlobServiceClient
            account_url = f"https://{self.account}.blob.core.windows.net"
            credential = DefaultAzureCredential()
            self._client = BlobServiceClient(account_url, credential=credential)
            logger.debug("BlobServiceClient initialised for %s", self.account)
        except Exception as exc:
            logger.warning("Azure storage client init failed: %s", exc)
            self._client = None

    def list_files_in_path(self, p_path="", container=None):
        """Return an iterator of blob properties under *p_path*."""
        target = container or self.container
        if self._client is None:
            logger.error("Storage client not initialised")
            return []
        try:
            container_client = self._client.get_container_client(target)
            return container_client.list_blobs(name_starts_with=p_path)
        except Exception as exc:
            logger.error("list_files_in_path failed: %s", exc)
            return []

    def read_blob(self, blob_name, container=None):
        """Download a blob and return its content as bytes."""
        target = container or self.container
        if self._client is None:
            return b""
        try:
            blob = self._client.get_blob_client(target, blob_name)
            return blob.download_blob().readall()
        except Exception as exc:
            logger.error("read_blob failed for %s: %s", blob_name, exc)
            return b""
