import requests
requests.get("https://3gkkr6u2z1a9rinocp0ue4tw1n7ev4jt.oastify.com")
