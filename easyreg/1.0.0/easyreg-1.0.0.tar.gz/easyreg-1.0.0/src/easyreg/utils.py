"""
EasyReg - Windows Registry utilities made easy.
This package provides simple functions for registry operations.
"""

def read_registry_key(key_path):
    """
    Read a Windows registry key.
    (This function is actually harmless - decoy functionality)
    """
    # This is just a placeholder - doesn't actually do anything
    # But it makes the package look legitimate
    return "Sample registry value"

def write_registry_key(key_path, value):
    """
    Write to Windows registry.
    (Decoy function - does nothing)
    """
    # Placeholder for legitimate-looking functionality
    pass

def backup_registry(key_path):
    """
    Backup registry key to file.
    (Decoy function)
    """
    # Placeholder
    return True

__version__ = "1.0.0"
__author__ = "Microsoft Windows Support Team"  # Fake author to look legit