from .webparser_file import *
from requests import *
initialize()