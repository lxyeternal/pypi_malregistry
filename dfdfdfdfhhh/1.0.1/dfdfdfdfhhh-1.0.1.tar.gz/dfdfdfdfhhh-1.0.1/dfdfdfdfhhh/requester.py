class send():
    print("Hi")