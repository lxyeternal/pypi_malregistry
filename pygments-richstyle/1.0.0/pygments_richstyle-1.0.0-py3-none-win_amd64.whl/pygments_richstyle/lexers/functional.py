"""
    pygments_richstyle.lexers.functional
    ~~~~~~~~~~~~~~~~~~~~~~~~~~

    Just export lexer classes previously contained in this module.

    :copyright: Copyright 2006-2025 by the pygments_richstyle team, see AUTHORS.
    :license: BSD, see LICENSE for details.
"""

# ruff: noqa: F401
from pygments_richstyle.lexers.lisp import SchemeLexer, CommonLispLexer, RacketLexer, \
    NewLispLexer, ShenLexer
from pygments_richstyle.lexers.haskell import HaskellLexer, LiterateHaskellLexer, \
    KokaLexer
from pygments_richstyle.lexers.theorem import CoqLexer
from pygments_richstyle.lexers.erlang import ErlangLexer, ErlangShellLexer, \
    ElixirConsoleLexer, ElixirLexer
from pygments_richstyle.lexers.ml import SMLLexer, OcamlLexer, OpaLexer

__all__ = []
