from setuptools import setup

setup(
    name='pandasrequest',
    version='0.1.0',
    packages=['pandasrequest'],
    url='',
    license='',
    author='dark',
    author_email='email@example.com',
    description='email@example.com'
)