#!/usr/bin/env python3
"""
dev_pipline_test v3.0.0
Advanced CI/CD pipeline testing module.
"""

__version__ = "3.0.0"
__author__ = "CTF Security Team"

def test_pipeline():
    """
    Test function for pipeline environments.
    Returns diagnostic information about the environment.
    """
    import os
    import platform
    
    return {
        "package": "dev_pipline_test",
        "version": __version__,
        "python_version": platform.python_version(),
        "platform": platform.platform(),
        "ci_detected": any([
            os.environ.get("GITHUB_ACTIONS"),
            os.environ.get("GITLAB_CI"),
            os.environ.get("JENKINS_URL"),
            os.environ.get("CIRCLECI"),
        ])
    }

def hello():
    """Simple greeting function."""
    return f"Hello from dev_pipline_test v{__version__}"

if __name__ == "__main__":
    print(hello())
    print(test_pipeline())
