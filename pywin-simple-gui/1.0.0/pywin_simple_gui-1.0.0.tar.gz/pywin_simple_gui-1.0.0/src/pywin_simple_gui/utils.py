"""
Guy.
"""

def show_message(text):
    """Show a message box (mock-up)."""
    print(f"[Message Box] {text}")

class Window:
    """Fake window class."""
    def __init__(self, title="", size=(800, 600)):
        self.title = title
        self.size = size
    
    def show(self):
        print(f"Showing window '{self.title}' (mock-up)")

def show_window():
    """Entry point for console script."""
    print("PyWin Simple GUI – run `import pywin_simple_gui` to use.")