"""
YOLO Base Handler
=================
YOLO Detection / Segmentation / Pose가 공유하는 공통 로직.

공통 요소:
    - dataset.yaml (또는 data.yaml) 파싱
    - train/val/test split 디렉토리 탐색
    - images/ ↔ labels/ 매칭
    - 이미지 + 라벨 파일 스캔
"""

import os

from . import BaseFormatHandler


class YoloBaseHandler(BaseFormatHandler):
    """YOLO 계열 포맷의 공통 베이스 핸들러.

    서브클래스는 다음을 오버라이드해야 합니다:
        - FORMAT_NAME, DESCRIPTION, DIRECTORY_GUIDE
        - _validate_label_sample()  — 라벨 형식 샘플 검증 (선택)
        - _parse_label_line()       — 라벨 파일의 각 줄 파싱 (통계용)
        - report_dashboard()        — 포맷별 대시보드 시각화
        - register_fiftyone()       — FiftyOne 데이터셋 등록
    """

    YAML_CANDIDATES = ["dataset.yaml", "data.yaml"]

    # ----------------------------------------------------------------
    # validate_structure (공통)
    # ----------------------------------------------------------------
    def validate_structure(self, source_path: str) -> list:
        """YOLO 공통 구조 검증: YAML 존재, names 키, split 디렉토리."""
        issues = []

        # 1. YAML 파일 확인
        yaml_path = self._find_yaml(source_path)
        if not yaml_path:
            issues.append(
                f"Config file not found. "
                f"Expected one of: {', '.join(self.YAML_CANDIDATES)} in {source_path}"
            )
            return issues  # YAML 없으면 이후 검증 불가

        # 2. YAML 파싱 + 필수 키 확인
        try:
            data = self._load_yaml(yaml_path)
        except Exception as e:
            issues.append(f"Failed to parse YAML ({yaml_path}): {e}")
            return issues

        if not data.get('names'):
            issues.append("'names' key is missing in YAML. Class names must be defined.")

        # 3. split 디렉토리 존재 확인
        found_splits = []
        for split in ['train', 'val', 'test']:
            split_path = data.get(split)
            if split_path:
                abs_path = self._resolve_split_path(source_path, data, split_path)
                if os.path.isdir(abs_path):
                    found_splits.append(split)
                    # 4. images/ 디렉토리 확인
                    img_dir = os.path.join(abs_path, 'images')
                    if not os.path.isdir(img_dir) and not os.path.isdir(abs_path):
                        issues.append(
                            f"'{split}' split: 'images/' subdirectory not found in {abs_path}"
                        )
                else:
                    issues.append(f"'{split}' split: directory not found at {abs_path}")

        if not found_splits:
            issues.append(
                "No split directories found. "
                "YAML must define at least one of: train, val, test"
            )

        # 5. 포맷별 추가 검증 (서브클래스 오버라이드)
        issues.extend(self._validate_format_specific(source_path, data))

        return issues

    def _validate_format_specific(self, source_path: str, yaml_data: dict) -> list:
        """서브클래스에서 오버라이드하여 포맷별 추가 검증을 수행합니다."""
        return []

    # ----------------------------------------------------------------
    # extract_schema (공통 뼈대)
    # ----------------------------------------------------------------
    def extract_schema(self, source_path: str, **kwargs) -> dict:
        """YAML에서 스키마를 추출하고 split별 통계를 생성합니다."""
        yaml_path = self._find_yaml(source_path)
        data = self._load_yaml(yaml_path)

        # Class names 파싱
        names = data.get('names', [])
        if isinstance(names, dict):
            names = [names[k] for k in sorted(names.keys())]

        task_type = data.get('task', self._default_task_type())

        schema = {
            "format": "yolo",
            "task": task_type,
            "nc": len(names),
            "names": names,
        }
        # 포맷별 스키마 확장 (예: kpt_shape)
        schema.update(self._extra_schema_fields(data))

        # Split별 통계 스캔
        use_pixel_stats = kwargs.get('use_pixel_stats', False)
        print(f"Generating Health Report (Pixel stats: {'ENABLED' if use_pixel_stats else 'DISABLED'})...")

        stats = {}
        for split in ['train', 'val', 'test']:
            split_p = data.get(split)
            if not split_p:
                continue

            abs_split_path = self._resolve_split_path(source_path, data, split_p)
            if not os.path.exists(abs_split_path):
                print(f"Warning: Split path not found, skipping '{split}': {abs_split_path}")
                continue

            # images/labels 디렉토리 탐색
            img_dir, lbl_dir = self._discover_img_lbl_dirs(abs_split_path)

            split_stats = self._scan_split(img_dir, lbl_dir, names, use_pixel_stats)
            if split_stats:
                stats[split] = split_stats

        return {"schema": schema, "stats": stats}

    def _default_task_type(self) -> str:
        """서브클래스에서 오버라이드: 기본 task 타입."""
        return "detect"

    def _extra_schema_fields(self, yaml_data: dict) -> dict:
        """서브클래스에서 오버라이드: 추가 스키마 필드."""
        return {}

    # ----------------------------------------------------------------
    # split 스캔 (공통 뼈대 + 서브클래스 확장)
    # ----------------------------------------------------------------
    def _scan_split(self, img_dir, lbl_dir, names, use_pixel_stats) -> dict:
        """이미지 + 라벨 스캔. 기본은 detection용 스캔."""
        img_count = 0
        lbl_map = {}

        for root, dirs, files in os.walk(img_dir):
            for f in files:
                if os.path.splitext(f)[1].lower() in self.SUPPORTED_IMAGE_EXTS:
                    img_count += 1
                    rel_base = os.path.splitext(
                        os.path.relpath(os.path.join(root, f), img_dir)
                    )[0]
                    lbl_map[rel_base] = os.path.join(root, f)

        if img_count == 0:
            return None

        # 라벨 스캔 (서브클래스가 _parse_label_file을 오버라이드)
        labeled_count = 0
        ins_per_class = {i: 0 for i in range(len(names))}
        extra_stats = self._init_extra_stats()

        if os.path.isdir(lbl_dir):
            for root, dirs, files in os.walk(lbl_dir):
                for f in files:
                    if f.endswith('.txt'):
                        rel_base = os.path.splitext(
                            os.path.relpath(os.path.join(root, f), lbl_dir)
                        )[0]
                        img_path = lbl_map.get(rel_base)
                        if img_path:
                            labeled_count += 1
                            self._parse_label_file(
                                os.path.join(root, f), img_path, names,
                                ins_per_class, extra_stats, use_pixel_stats
                            )

        result = {
            "images": img_count,
            "labeled_images": labeled_count,
            "background_images": img_count - labeled_count,
            "instances_per_class": ins_per_class,
        }
        result.update(extra_stats)
        return result

    def _init_extra_stats(self) -> dict:
        """서브클래스에서 오버라이드: 추가 통계 초기화."""
        return {}

    def _parse_label_file(self, lbl_path, img_path, names,
                          ins_per_class, extra_stats, use_pixel_stats):
        """라벨 파일의 각 줄을 파싱. 서브클래스에서 오버라이드합니다."""
        try:
            with open(lbl_path, 'r') as f:
                for line in f:
                    parts = line.strip().split()
                    if len(parts) >= 5:
                        cid = int(parts[0])
                        if 0 <= cid < len(names):
                            ins_per_class[cid] += 1
        except Exception:
            pass

    # ----------------------------------------------------------------
    # FiftyOne Registration (공통)
    # ----------------------------------------------------------------
    def register_fiftyone(self, fo_dataset, source_path: str, **kwargs) -> None:
        """YOLO 계열의 FiftyOne 등록. (Detection / Segmentation 용)
        Pose는 별도의 수동 파싱이 필요하므로 서브클래스에서 오버라이드합니다.
        """
        import fiftyone as fo
        import tempfile

        yaml_path = self._find_yaml(source_path)
        data = self._load_yaml(yaml_path)

        for split in ['train', 'val', 'test']:
            split_p = data.get(split)
            if not split_p:
                continue

            abs_split_path = self._resolve_split_path(source_path, data, split_p)
            if not os.path.exists(abs_split_path):
                continue

            # FiftyOne용 임시 YAML 생성 (절대 경로 보장)
            # FiftyOne의 YOLOv5Dataset 임포터는 경로에 'images'가 포함되어 있어야 'labels'로 치환하여 인덱싱할 수 있습니다.
            # 따라서 명시적으로 이미지가 들어있는 최하위 디렉토리를 찾아 타겟으로 지정합니다.
            img_dir, _ = self._discover_img_lbl_dirs(abs_split_path)

            with tempfile.NamedTemporaryFile(suffix=".yaml", mode="w", delete=False, encoding='utf-8') as tf:
                import yaml
                temp_data = data.copy()
                
                # [Optimization] 원본 YAML에 absolute path가 설정되어 있으면 FiftyOne이 타 split까지 
                # 강제로 모두 파싱하여 태그가 마지막 등록된 split(val)로 전부 덮어씌워지는 치명적 버그 방지
                for s in ['train', 'val', 'test']:
                    if s != split and s in temp_data:
                        del temp_data[s]
                
                # FiftyOne이 이 경로를 기준으로 'images' -> 'labels' 치환을 수행하도록 유도
                temp_data['path'] = os.path.dirname(img_dir)
                temp_data[split] = os.path.basename(img_dir)
                yaml.dump(temp_data, tf)
                temp_yaml_path = tf.name

            try:
                extra_kwargs = self._get_fiftyone_extra_kwargs()
                fo_dataset.add_dir(
                    dataset_type=fo.types.YOLOv5Dataset,
                    yaml_path=temp_yaml_path,
                    split=split,
                    tags=[split],
                    **extra_kwargs
                )
            finally:
                if os.path.exists(temp_yaml_path):
                    os.remove(temp_yaml_path)

    def get_sample_count(self, source_path: str) -> int:
        """YOLO 데이터셋의 실제 이미지(샘플) 수를 반환합니다."""
        yaml_path = self._find_yaml(source_path)
        if not yaml_path:
            return 0
        data = self._load_yaml(yaml_path)
        
        total_images = 0
        for split in ['train', 'val', 'test']:
            split_p = data.get(split)
            if not split_p:
                continue
            abs_split_path = self._resolve_split_path(source_path, data, split_p)
            if not os.path.exists(abs_split_path):
                continue
            
            img_dir, _ = self._discover_img_lbl_dirs(abs_split_path)
            if os.path.isdir(img_dir):
                for root, dirs, files in os.walk(img_dir):
                    for f in files:
                        if os.path.splitext(f)[1].lower() in self.SUPPORTED_IMAGE_EXTS:
                            total_images += 1
        return total_images

    def _get_fiftyone_extra_kwargs(self) -> dict:
        """FiftyOne add_dir()에 전달할 추가 인자 (예: label_type='polylines')."""
        return {}

    def _find_yaml(self, source_path: str):
        """YAML 설정 파일 경로를 반환합니다."""
        for name in self.YAML_CANDIDATES:
            p = os.path.join(source_path, name)
            if os.path.exists(p):
                return p
        return None

    @staticmethod
    def _load_yaml(yaml_path: str) -> dict:
        """YAML 파일을 파싱하여 dict로 반환합니다."""
        import yaml
        with open(yaml_path, 'r', encoding='utf-8') as f:
            data = yaml.safe_load(f)
        if not data:
            raise ValueError("YAML is empty or invalid.")
        return data

    @staticmethod
    def _resolve_split_path(source_path, yaml_data, split_value) -> str:
        """YAML의 split 경로를 절대 경로로 해석합니다."""
        if os.path.isabs(split_value):
            return os.path.normpath(split_value)
        base_dir = yaml_data.get('path', '')
        if base_dir and not os.path.isabs(base_dir):
            base_dir = os.path.join(source_path, base_dir)
        elif not base_dir:
            base_dir = source_path
        return os.path.normpath(os.path.join(base_dir, split_value))

    @staticmethod
    def _discover_img_lbl_dirs(abs_split_path):
        """split 경로에서 images/labels 디렉토리를 탐색합니다."""
        img_dir = os.path.join(abs_split_path, 'images')
        lbl_dir = os.path.join(abs_split_path, 'labels')

        if not os.path.isdir(img_dir):
            img_dir = abs_split_path
            if 'images' in abs_split_path:
                lbl_dir = abs_split_path.replace('images', 'labels')
            else:
                lbl_dir = abs_split_path
        return img_dir, lbl_dir

    @staticmethod
    def _get_image_size(path):
        """경량 이미지 사이즈 추출."""
        try:
            from PIL import Image
            with Image.open(path) as img:
                return img.size
        except Exception:
            return (640, 640)
