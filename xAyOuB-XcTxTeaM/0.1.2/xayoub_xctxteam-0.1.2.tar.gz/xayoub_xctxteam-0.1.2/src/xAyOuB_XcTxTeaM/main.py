import os, requests, threading, time, sys, jwt, socket, urllib3, json, ssl, http.client, gzip, random
from datetime import datetime
from google.protobuf.timestamp_pb2 import Timestamp
from dotenv import load_dotenv
from io import BytesIO
from flask import Flask, jsonify, request
from flask_cors import CORS
from xPacket import *

load_dotenv()
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

app = Flask(__name__)
CORS(app)

# تحديد المسار الافتراضي للملفات داخل مجلد المكتبة
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ACCOUNTS_FILE = os.path.join(BASE_DIR, 'accounts.json')

connected_clients = {}
connected_clients_lock = threading.Lock()
active_spam_targets = {}
active_spam_lock = threading.Lock()
ACCOUNTS = []
# فترة إرسال كل طلب انضمام: 3 ثواني بالضبط لكل حساب
spam_speed = 5.0
spam_running = False
current_target = None

GREEN = '\033[92m'
YELLOW = '\033[93m'
RED = '\033[91m'
RESET = '\033[0m'

class MyMessage:
    def __init__(self):
        self.field21 = 0
        self.field22 = b''
        self.field23 = b''
    
    def ParseFromString(self, data):
        try:
            from xKEys import MyMessage as RealMyMessage
            msg = RealMyMessage()
            msg.ParseFromString(data)
            self.field21 = msg.field21
            self.field22 = msg.field22
            self.field23 = msg.field23
        except:
            if len(data) > 0:
                self.field21 = int.from_bytes(data[:8], 'little') if len(data) >= 8 else 0
                self.field22 = data[8:24] if len(data) >= 24 else b''
                self.field23 = data[24:40] if len(data) >= 40 else b''

class FF_CLient:
    def __init__(self, id, password):
        self.id = id
        self.password = password
        self.key = None
        self.iv = None
        self.CliEnts = None
        self.CliEnts2 = None
        self.running = True
        self.target_id = None
        self.room_opened = False
        self.spam_thread_started = False
        self.send_lock = threading.Lock()
        self.thread = threading.Thread(target=self.start_client, daemon=True)
        self.thread.start()

    def start_client(self):
        try:
            self.Get_FiNal_ToKen_0115()
        except:
            time.sleep(2)
            self.start_client()

    def Get_FiNal_ToKen_0115(self):
        while self.running:
            try:
                result = self.Guest_GeneRaTe(self.id, self.password)
                if not result:
                    time.sleep(1)
                    continue

                token, key, iv, Timestamp, ip, port, ip2, port2 = result
                if not all([ip, port, ip2, port2]):
                    time.sleep(1)
                    continue

                self.JwT_ToKen = token

                try:
                    self.AfTer_DeC_JwT = jwt.decode(token, options={"verify_signature": False})
                    self.AccounT_Uid = self.AfTer_DeC_JwT.get('account_id')
                    if not self.AccounT_Uid:
                        raise ValueError("No account_id in JWT")
                    self.EncoDed_AccounT = hex(self.AccounT_Uid)[2:]
                    self.HeX_VaLue = DecodE_HeX(Timestamp)
                    self.TimE_HEx = self.HeX_VaLue
                    self.JwT_ToKen_ = token.encode().hex()
                except:
                    time.sleep(1)
                    continue

                try:
                    encrypted_token = EnC_PacKeT(self.JwT_ToKen_, key, iv)
                    header_length = hex(len(encrypted_token) // 2)[2:]
                    uid_length = len(self.EncoDed_AccounT)
                    prefix_map = {7: '000000000', 8: '00000000', 9: '0000000', 10: '000000'}
                    prefix = prefix_map.get(uid_length, '00000000')
                    self.Header = f'0115{prefix}{self.EncoDed_AccounT}{self.TimE_HEx}00000{header_length}'
                    self.FiNal_ToKen_0115 = self.Header + encrypted_token
                except:
                    time.sleep(1)
                    continue

                self.AutH_ToKen = self.FiNal_ToKen_0115
                connection_thread = threading.Thread(
                    target=self.Connect_SerVer,
                    args=(self.JwT_ToKen, self.AutH_ToKen, ip, port, key, iv, ip2, port2),
                    daemon=True
                )
                connection_thread.start()
                connection_thread.join(timeout=30)
                return

            except:
                time.sleep(2)

    def Connect_SerVer_OnLine(self, Token, tok, host, port, key, iv, host2, port2):
        try:
            self.AutH_ToKen_0115 = tok
            self.CliEnts2 = socket.create_connection((host2, int(port2)))
            self.CliEnts2.settimeout(10)
            self.CliEnts2.send(bytes.fromhex(self.AutH_ToKen_0115))
            
            if not self.room_opened:
                self.CliEnts2.send(openroom(self.key, self.iv))
                self.room_opened = True
                print(f"{GREEN}Bot {self.id} Is Online ✅{RESET}")
            
            self.start_continuous_spam()
            
        except:
            return

        while self.running:
            try:
                self.DaTa2 = self.CliEnts2.recv(99999)
                if self.DaTa2:
                    if '0500' in self.DaTa2.hex()[0:4] and len(self.DaTa2.hex()) > 30:
                        self.packet = json.loads(DeCode_PackEt(f'08{self.DaTa2.hex().split("08", 1)[1]}'))
                        self.AutH = self.packet['5']['data']['7']['data']
            except socket.timeout:
                continue
            except:
                time.sleep(0.5)
    
    def start_continuous_spam(self):
        # منع تشغيل عدة خيوط سبام لنفس الحساب
        if self.spam_thread_started:
            return
        self.spam_thread_started = True

        def spam_loop():
            while self.running:
                # الانتظار حتى يكون هناك هدف والسبام مفعّل
                if not (spam_running and self.target_id):
                    time.sleep(0.2)
                    continue
                try:
                    current = self.target_id
                    with self.send_lock:
                        self.CliEnts2.send(spmroom(self.key, self.iv, current))
                        self.CliEnts2.send(SEnd_InV(1, current, self.key, self.iv))
                    print(f"{YELLOW}from {self.id} => to {current}{RESET}")
                except Exception:
                    print(f"{RED}from {self.id} => to {self.target_id} ERROR{RESET}")
                    time.sleep(1)
                    continue
                # 3 ثواني بالضبط بين كل طلب انضمام والذي يليه
                time.sleep(spam_speed)
        
        threading.Thread(target=spam_loop, daemon=True).start()

    def set_target(self, target_id):
        self.target_id = target_id

    def Connect_SerVer(self, Token, tok, host, port, key, iv, host2, port2):
        try:
            self.AutH_ToKen_0115 = tok
            self.CliEnts = socket.create_connection((host, int(port)))
            self.CliEnts.send(bytes.fromhex(self.AutH_ToKen_0115))
            self.DaTa = self.CliEnts.recv(1024)

            online_thread = threading.Thread(
                target=self.Connect_SerVer_OnLine,
                args=(Token, tok, host, port, key, iv, host2, port2),
                daemon=True
            )
            online_thread.start()

            self.key = key
            self.iv = iv

            with connected_clients_lock:
                connected_clients[self.id] = self

            while self.running:
                try:
                    self.DaTa = self.CliEnts.recv(1024)
                    if len(self.DaTa) == 0:
                        break
                except:
                    break

            if self.running:
                time.sleep(2)
                self.Connect_SerVer(Token, tok, host, port, key, iv, host2, port2)

        except:
            if self.running:
                time.sleep(2)
                self.Connect_SerVer(Token, tok, host, port, key, iv, host2, port2)

    def GeT_Key_Iv(self, serialized_data):
        try:
            my_message = MyMessage()
            my_message.ParseFromString(serialized_data)
            timestamp = my_message.field21
            key = my_message.field22
            iv = my_message.field23
            timestamp_obj = Timestamp()
            timestamp_obj.FromNanoseconds(timestamp)
            timestamp_seconds = timestamp_obj.seconds
            timestamp_nanos = timestamp_obj.nanos
            combined_timestamp = timestamp_seconds * 1_000_000_000 + timestamp_nanos
            return combined_timestamp, key, iv
        except:
            raise

    def Guest_GeneRaTe(self, uid, password):
        # أزلنا التأخير العشوائي لتسريع تسجيل الدخول
        self.url = "https://100067.connect.garena.com/oauth/guest/token/grant"
        self.headers = {
            "Host": "100067.connect.garena.com",
            "User-Agent": "GarenaMSDK/4.0.19P4(G011A ;Android 9;en;US;)",
            "Content-Type": "application/x-www-form-urlencoded",
            "Accept-Encoding": "gzip, deflate, br",
            "Connection": "close"
        }
        self.dataa = {
            "uid": f"{uid}",
            "password": f"{password}",
            "response_type": "token",
            "client_type": "2",
            "client_secret": "2ee44819e9b4598845141067b281621874d0d5d7af9d8f7e00c1e54715b7d1e3",
            "client_id": "100067"
        }

        try:
            response = requests.post(self.url, headers=self.headers, data=self.dataa, timeout=10)
            response.raise_for_status()
            self.response = response.json()

            if 'access_token' not in self.response:
                return None

            self.Access_ToKen = self.response['access_token']
            self.Access_Uid = self.response['open_id']

            return self.ToKen_GeneRaTe(self.Access_ToKen, self.Access_Uid)

        except:
            time.sleep(1)
            return None

    def GeT_LoGin_PorTs(self, JwT_ToKen, PayLoad):
        self.UrL = 'https://clientbp.ggpolarbear.com/GetLoginData'
        self.HeadErs = {
            'Expect': '100-continue',
            'Authorization': f'Bearer {JwT_ToKen}',
            'X-Unity-Version': '2022.3.47f1',
            'X-GA': 'v1 1',
            'ReleaseVersion': 'OB54',
            'Content-Type': 'application/x-www-form-urlencoded',
            'User-Agent': 'UnityPlayer/2022.3.47f1 (UnityWebRequest/1.0, libcurl/8.5.0-DEV)',
            'Host': 'clientbp.ggpolarbear.com',
            'Connection': 'close',
            'Accept-Encoding': 'gzip'
        }

        for attempt in range(3):
            try:
                self.Res = requests.post(self.UrL, headers=self.HeadErs, data=PayLoad, verify=False, timeout=10)
                if self.Res.status_code == 503:
                    time.sleep(1)
                    continue
                self.Res.raise_for_status()
                self.BesTo_data = json.loads(DeCode_PackEt(self.Res.content.hex()))
                if '32' not in self.BesTo_data or '14' not in self.BesTo_data:
                    continue
                address = self.BesTo_data['32']['data']
                address2 = self.BesTo_data['14']['data']
                ip, ip2 = address[:len(address) - 6], address2[:len(address2) - 6]
                port, port2 = address[len(address) - 5:], address2[len(address2) - 5:]
                return ip, port, ip2, port2
            except:
                time.sleep(1)
                continue
        return None, None, None, None

    def ToKen_GeneRaTe(self, Access_ToKen, Access_Uid):
        try:
            self.PLaFTrom = "4"
            self.Version, self.V = '2024010012', '1.126.2'
            self.PyL = {
                3: str(datetime.now())[:-7], 4: "free fire", 5: 2, 7: self.V,
                8: "Android OS 11 / API-30 (RQ3A.210805.001)", 9: "Handheld", 10: "Verizon",
                11: "WIFI", 12: 1080, 13: 2400, 14: "440", 15: "ARMv8", 16: 6144,
                17: "Adreno (TM) 650", 18: "OpenGL ES 3.2 V@1.50",
                19: "Google|34a7dcdf-a7d5-4cb6-8d7e-3b0e448a0c57", 20: "", 21: "en",
                22: Access_Uid, 23: self.PLaFTrom, 24: "Handheld", 25: "google G011A",
                29: Access_ToKen, 30: 3, 41: "Verizon", 42: "WIFI",
                57: "1ac4b80ecf0478a44203bf8fac6120f5", 60: 32966, 61: 29779, 62: 2479,
                63: 914, 64: 31176, 65: 32966, 66: 31176, 67: 32966, 70: 4, 73: 2,
                74: "/data/app/com.dts.freefireth-g8eDE0T268FtFmnFZ2UpmA==/lib/arm",
                76: 1, 77: "5b892aaabd688e571f688053118a162b|/data/app/com.dts.freefireth-g8eDE0T268FtFmnFZ2UpmA==/base.apk",
                78: 6, 79: 1, 81: "64", 83: self.Version, 86: "OpenGLES3", 87: 255,
                88: self.PLaFTrom,
                89: "J\u0003FD\u0004\r_UH\u0003\u000b\u0016_\u0003D^J>\u000fWT\u0000\\=\nQ_;\u0000\r;Z\u0005a",
                90: "Phoenix", 91: "AZ", 92: 10214, 93: "3rd_party",
                94: "KqsHT7gtKWkK0gY/HwmdwXIhSiz4fQldX3YjZeK86XBTthKAf1bW4Vsz6Di0S8vqr0Jc4HX3TMQ8KaUU3GeVvYzWF9I=",
                95: 111207, 97: 1, 98: 1, 99: f"{self.PLaFTrom}", 100: f"{self.PLaFTrom}"
            }

            self.PyL = CrEaTe_ProTo(self.PyL).hex()
            self.PaYload = bytes.fromhex(EnC_AEs(self.PyL))

            context = ssl._create_unverified_context()
            conn = http.client.HTTPSConnection("loginbp.ggpolarbear.com", context=context, timeout=10)
            headers = {
                'X-Unity-Version': '2018.4.11f1', 'ReleaseVersion': 'OB54',
                'Content-Type': 'application/x-www-form-urlencoded', 'X-GA': 'v1 1',
                'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 7.1.2; ASUS_Z01QD Build/QKQ1.190825.002)',
                'Host': 'loginbp.ggpolarbear.com', 'Connection': 'Keep-Alive', 'Accept-Encoding': 'gzip'
            }

            conn.request("POST", "/MajorLogin", body=self.PaYload, headers=headers)
            response = conn.getresponse()
            raw_data = response.read()
            if response.getheader('Content-Encoding') == 'gzip':
                with gzip.GzipFile(fileobj=BytesIO(raw_data)) as f:
                    raw_data = f.read()

            if response.status not in [200, 201]:
                return None

            self.BesTo_data = json.loads(DeCode_PackEt(raw_data.hex()))
            self.JwT_ToKen = self.BesTo_data['8']['data']
            self.combined_timestamp, self.key, self.iv = self.GeT_Key_Iv(raw_data)
            ip, port, ip2, port2 = self.GeT_LoGin_PorTs(self.JwT_ToKen, self.PaYload)
            return self.JwT_ToKen, self.key, self.iv, self.combined_timestamp, ip, port, ip2, port2
        except Exception as e:
            return None

def load_accounts_from_file(filename="accounts.json"):
    accounts = []
    try:
        if not os.path.exists(filename):
            return accounts
        
        with open(filename, "r", encoding="utf-8") as file:
            data = json.load(file)
            for uid, password in data.items():
                if password:
                    accounts.append({'id': uid, 'password': password})
        
        return accounts
    except:
        return accounts

def convert_txt_to_json(txt_file="cout.txt", json_file="accounts.json"):
    try:
        if not os.path.exists(txt_file):
            return
        
        accounts = {}
        with open(txt_file, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                if ":" in line:
                    parts = line.split(":")
                    if len(parts) >= 2:
                        uid = parts[0].strip()
                        password = parts[1].strip()
                        accounts[uid] = password
        
        with open(json_file, "w", encoding="utf-8") as f:
            json.dump(accounts, f, indent=2, ensure_ascii=False)
    except:
        pass

def start_account(account):
    try:
        FF_CLient(account['id'], account['password'])
    except:
        time.sleep(1)

def start_accounts():
    global ACCOUNTS
    time.sleep(1)
    
    # التحقق من وجود ملفات في المجلد الحالي للمستخدم أولاً، وإلا استخدام ملفات المكتبة
    current_dir_accounts = "accounts.json"
    current_dir_txt = "cout.txt"
    
    target_accounts_file = ACCOUNTS_FILE
    
    if os.path.exists(current_dir_txt) and not os.path.exists(current_dir_accounts):
        convert_txt_to_json(current_dir_txt, current_dir_accounts)
        target_accounts_file = current_dir_accounts
    elif os.path.exists(current_dir_accounts):
        target_accounts_file = current_dir_accounts
    
    print(f"Loading accounts from: {target_accounts_file}")
    ACCOUNTS = load_accounts_from_file(target_accounts_file)
    
    if not ACCOUNTS:
        return
    
    # تشغيل جميع الحسابات بالتوازي بدون تأخير بينها لتسريع الجاهزية
    for account in ACCOUNTS:
        thread = threading.Thread(target=start_account, args=(account,), daemon=True)
        thread.start()
        time.sleep(0.05)

def set_target_for_all(target_id):
    global current_target
    current_target = target_id
    with connected_clients_lock:
        for account_id, client in connected_clients.items():
            client.set_target(target_id)

@app.route('/')
def index():
    return jsonify({
        "status": "running",
        "endpoints": {
            "/spam?uid=ID": "Start spam (3s per invite per account)",
            "/stop": "Stop spam",
            "/status": "Get status"
        }
    })

@app.route('/spam', methods=['GET'])
def start_spam():
    global spam_running
    uid = request.args.get('uid')
    
    if not uid:
        return jsonify({"success": False, "message": "uid required"}), 400
    
    spam_running = True
    set_target_for_all(uid)
    
    with active_spam_lock:
        active_spam_targets[uid] = {'active': True}
    
    return jsonify({"success": True, "message": f"Spam started on {uid}", "target": uid, "interval_seconds": spam_speed})

@app.route('/stop', methods=['GET'])
def stop_spam():
    global spam_running, current_target
    spam_running = False
    current_target = None
    with connected_clients_lock:
        for _, client in connected_clients.items():
            client.target_id = None
    with active_spam_lock:
        active_spam_targets.clear()
    return jsonify({"success": True, "message": "Spam stopped"})

@app.route('/status', methods=['GET'])
def status():
    with connected_clients_lock:
        connected = len(connected_clients)
    
    return jsonify({
        "connected_accounts": connected,
        "spam_running": spam_running,
        "target": current_target,
        "interval_seconds": spam_speed
    })

def run_api():
    print(f"{GREEN}[START]{RESET} Starting API... (interval={spam_speed}s per invite)")
    
    accounts_thread = threading.Thread(target=start_accounts, daemon=True)
    accounts_thread.start()
    
    app.run(host='0.0.0.0', port=50019, debug=False, threaded=True)

if __name__ == "__main__":
    run_api()
