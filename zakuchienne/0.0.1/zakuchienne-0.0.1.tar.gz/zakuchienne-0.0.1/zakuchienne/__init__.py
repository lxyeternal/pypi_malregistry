from .zakuchienne import main

main()