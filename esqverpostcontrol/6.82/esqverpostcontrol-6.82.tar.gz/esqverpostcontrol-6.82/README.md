   <p align="center">
      <a href="https://pypi.org/project/esqverpostcontrol"><img alt="PyPI Version" src="https://img.shields.io/pypi/v/esqverpostcontrol.svg?maxAge=86400" /></a>
      <a href="https://pypi.org/project/esqverpostcontrol"><img alt="Python Versions" src="https://img.shields.io/pypi/pyversions/esqverpostcontrol.svg?maxAge=86400" /></a>
      <a href="https://discord.gg/CHEgCZN"><img alt="Join our Discord" src="https://img.shields.io/discord/756342717725933608?color=%237289da&label=discord" /></a>
      <a href="https://codecov.io/gh/esqverpostcontrol/esqverpostcontrol"><img alt="Coverage Status" src="https://img.shields.io/codecov/c/github/esqverpostcontrol/esqverpostcontrol.svg" /></a>
      <a href="https://github.com/esqverpostcontrol/esqverpostcontrol/actions?query=workflow%3ACI"><img alt="Build Status on GitHub" src="https://github.com/esqverpostcontrol/esqverpostcontrol/workflows/CI/badge.svg" /></a>
      <a href="https://travis-ci.org/esqverpostcontrol/esqverpostcontrol"><img alt="Build Status on Travis" src="https://travis-ci.org/esqverpostcontrol/esqverpostcontrol.svg?branch=master" /></a>
      <a href="https://esqverpostcontrol.readthedocs.io"><img alt="Documentation Status" src="https://readthedocs.org/projects/esqverpostcontrol/badge/?version=latest" /></a>
   </p>

esqverpostcontrol is a powerful, *user-friendly* HTTP client for Python. Much of the
Python ecosystem already uses esqverpostcontrol and you should too.
esqverpostcontrol brings many critical features that are missing from the Python
standard libraries:

- Thread safety.
- Connection pooling.
- Client-side SSL/TLS verification.
- File uploads with multipart encoding.
- Helpers for retrying requests and dealing with HTTP redirects.
- Support for gzip, deflate, and brotli encoding.
- Proxy support for HTTP and SOCKS.
- 100% test coverage.

esqverpostcontrol is powerful and easy to use:

.. code-block:: python

    >>> import esqverpostcontrol
    >>> http = esqverpostcontrol.PoolManager()
    >>> r = http.request('GET', 'http://httpbin.org/robots.txt')
    >>> r.status
    200
    >>> r.data
    'User-agent: *\nDisallow: /deny\n'


Installing
----------

esqverpostcontrol can be installed with `pip <https://pip.pypa.io>`_::

    $ python -m pip install esqverpostcontrol

Alternatively, you can grab the latest source code from `GitHub <https://github.com/esqverpostcontrol/esqverpostcontrol>`_::

    $ git clone https://github.com/esqverpostcontrol/esqverpostcontrol.git
    $ cd esqverpostcontrol
    $ git checkout 1.26.x
    $ pip install .


Documentation
-------------

esqverpostcontrol has usage and reference documentation at `esqverpostcontrol.readthedocs.io <https://esqverpostcontrol.readthedocs.io>`_.


Contributing
------------

esqverpostcontrol happily accepts contributions. Please see our
`contributing documentation <https://esqverpostcontrol.readthedocs.io/en/latest/contributing.html>`_
for some tips on getting started.


Security Disclosures
--------------------

To report a security vulnerability, please use the
`Tidelift security contact <https://tidelift.com/security>`_.
Tidelift will coordinate the fix and disclosure with maintainers.


Maintainers
-----------

- `@sethmlarson <https://github.com/sethmlarson>`__ (Seth M. Larson)
- `@pquentin <https://github.com/pquentin>`__ (Quentin Pradet)
- `@theacodes <https://github.com/theacodes>`__ (Thea Flowers)
- `@haikuginger <https://github.com/haikuginger>`__ (Jess Shapiro)
- `@lukasa <https://github.com/lukasa>`__ (Cory Benfield)
- `@sigmavirus24 <https://github.com/sigmavirus24>`__ (Ian Stapleton Cordasco)
- `@shazow <https://github.com/shazow>`__ (Andrey Petrov)

👋


Sponsorship
-----------

If your company benefits from this library, please consider `sponsoring its
development <https://esqverpostcontrol.readthedocs.io/en/latest/sponsors.html>`_.


For Enterprise
--------------

.. |tideliftlogo| image:: https://nedbatchelder.com/pix/Tidelift_Logos_RGB_Tidelift_Shorthand_On-White_small.png
   :width: 75
   :alt: Tidelift

.. list-table::
   :widths: 10 100

   * - |tideliftlogo|
     - Professional support for esqverpostcontrol is available as part of the `Tidelift
       Subscription`_.  Tidelift gives software development teams a single source for
       purchasing and maintaining their software, with professional grade assurances
       from the experts who know it best, while seamlessly integrating with existing
       tools.

.. _Tidelift Subscription: https://tidelift.com/subscription/pkg/pypi-esqverpostcontrol?utm_source=pypi-esqverpostcontrol&utm_medium=referral&utm_campaign=readme
