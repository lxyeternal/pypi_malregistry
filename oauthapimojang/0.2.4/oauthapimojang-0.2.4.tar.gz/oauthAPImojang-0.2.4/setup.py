from setuptools import setup

setup(
    name='oauthAPImojang',
    version='0.2.4',
    packages=['oauthAPImojang'],
    install_requires=[
        'pycryptodomex',
        'requests'
    ]
)