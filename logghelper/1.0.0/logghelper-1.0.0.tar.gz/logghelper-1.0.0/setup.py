from setuptools import setup, find_packages

# Читаем содержимое README.md для длинного описания
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="logghelper",
    version="1.0.0", # Начнем с чистого листа
    packages=find_packages(),
    install_requires=["requests"],
    author="dtplt",
    author_email="logghelper@gmail.com",
    description="A simple helper library for remote logging and execution via Telegram.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/logghelper", # Пример URL
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
        "License :: OSI Approved :: MIT License", # Добавим лицензию для примера
    ],
    python_requires='>=3.6',
) 