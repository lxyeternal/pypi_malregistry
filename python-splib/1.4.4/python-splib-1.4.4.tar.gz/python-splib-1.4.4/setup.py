from setuptools import setup
setup(name="python-splib", version="1.4.4", packages=["splib","splib._internal"], install_requires=['python-tracing>=0.1.5','shopee-sp-protocol>=0.4.0','garena-common>=1.0.25','seccache'], description=("This is splib for python"))
