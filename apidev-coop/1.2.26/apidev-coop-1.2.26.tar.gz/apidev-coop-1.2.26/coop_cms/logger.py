import logging

logger = logging.getLogger("coop_cms")