from setuptools import setup, find_packages

setup(
    name='make-helper',
    version='0.1.1',
    packages=find_packages(),
    install_requires=['requests', 'cryptography'],
    include_package_data=True,
    package_data={'dev_helper': ['encrypted.bin']},
    description='A helpful developer utility',
    author='Make Dev',
    license='MIT',
)