from ttlo.ttlo import *

ttlo()
