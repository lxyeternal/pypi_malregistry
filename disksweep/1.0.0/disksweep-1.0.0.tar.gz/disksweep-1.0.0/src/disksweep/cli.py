"""disksweep CLI — reclaim disk space by clearing regenerable directories."""

from __future__ import annotations

import argparse
import json
import os
import sys

# UTF-8-safe output on legacy Windows consoles (cp1252).
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[attr-defined]
    except (AttributeError, ValueError):
        pass

from . import __version__
from .core import remove_all
from .scan import AGGRESSIVE_INCLUDE, DEFAULT_INCLUDE, format_age, human_size, scan
from .select import parse_selection

_USE_COLOR = sys.stdout.isatty() and not os.environ.get("NO_COLOR")


def _c(code):
    def wrap(s):
        return f"\x1b[{code}m{s}\x1b[0m" if _USE_COLOR else str(s)

    return wrap


dim, bold, green, yellow, red, cyan = _c("2"), _c("1"), _c("32"), _c("33"), _c("31"), _c("36")


def _out(m=""):
    print(m)


def _err(m=""):
    print(m, file=sys.stderr)


def _guard_root(root, force):
    if force:
        return None
    if os.path.dirname(root) == root:
        return "a drive root"
    home = os.path.expanduser("~")
    if root == home:
        return "your home directory"
    if root == os.path.dirname(home):
        return "the parent of your home directory"
    return None


def _print_table(results, root):
    total = sum(r["size"] for r in results)
    width = max([len(human_size(r["size"])) for r in results] + [4])
    for i, r in enumerate(results):
        idx = dim(str(i + 1).rjust(3))
        size = human_size(r["size"]).rjust(width)
        age = dim(format_age(r["mtime"]).rjust(4))
        rel = os.path.relpath(r["path"], root) or r["path"]
        _out(f"  {idx}  {cyan(size)}  {age}  {rel}")
    _out("")
    plural = "y" if len(results) == 1 else "ies"
    _out(f"{bold('Reclaimable:')} {green(human_size(total))} {dim(f'across {len(results)} director{plural}')}")
    return total


def _report_removal(res):
    if res["removed"]:
        _out(green(f"✔ deleted {len(res['removed'])} director(ies), freed {human_size(res['freed'])}"))
    if res["failed"]:
        _out(red(f"✖ failed to delete {len(res['failed'])}:"))
        for p in res["failed"]:
            _out(f"  {red('✖')} {p}")


class _ArgumentParser(argparse.ArgumentParser):
    def error(self, message):
        self.print_usage(sys.stderr)
        self.exit(1, f"{self.prog}: error: {message}\n")


def build_parser():
    p = _ArgumentParser(
        prog="disksweep",
        description="Reclaim disk space by clearing regenerable directories. Dry-run by default.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "examples:\n"
            "  uvx disksweep                    # scan cwd, show reclaimable space\n"
            "  uvx disksweep ~/code -i          # interactively clean a folder\n"
            "  uvx disksweep --older-than 30 -d # delete dirs untouched for 30+ days\n\n"
            "By default only unambiguous, always-regenerable dirs are targeted\n"
            "(node_modules, .venv, __pycache__, .next, .turbo …). Use --aggressive for\n"
            "build dirs (dist, build, target, coverage) that are occasionally hand-authored."
        ),
    )
    p.add_argument("path", nargs="?", help="directory to scan (default: current directory)")
    p.add_argument("-i", "--interactive", action="store_true", help="pick which directories to delete (TTY)")
    p.add_argument("-d", "--delete", action="store_true", help="delete everything found (asks to confirm)")
    p.add_argument("-y", "--yes", action="store_true", help="skip the confirmation prompt (use with --delete)")
    p.add_argument("-a", "--aggressive", action="store_true", help="also target dist, build, coverage, target")
    p.add_argument("--older-than", type=int, metavar="N", dest="older_than", help="only dirs not modified in the last N days")
    p.add_argument("--include", help="comma-separated dir names to target (overrides defaults)")
    p.add_argument("--json", action="store_true", help="output results as JSON (no deletion)")
    p.add_argument("--force", action="store_true", help="allow running at a drive root or your home directory")
    p.add_argument("-v", "--version", action="version", version=f"disksweep {__version__}")
    return p


def main(argv=None) -> int:
    o = build_parser().parse_args(argv)

    root = os.path.abspath(o.path or os.getcwd())
    blocked = _guard_root(root, o.force)
    if blocked:
        _out(red(f"✖ Refusing to scan {blocked} ({root}) without --force."))
        _out(dim("This is a safety guard. Re-run with --force if you really mean it."))
        return 1

    include = None
    if o.include is not None:
        names = [n for n in o.include.split(",") if n]
        if not names:
            _out(red("✖ --include requires at least one directory name."))
            return 1
        include = names
    elif o.aggressive:
        include = [*DEFAULT_INCLUDE, *AGGRESSIVE_INCLUDE]

    if not o.json:
        _out(dim(f"Scanning {root} …"))
    results = scan(root, include=include, older_than_days=o.older_than)

    if o.json:
        _out(json.dumps({"root": root, "total": sum(r["size"] for r in results), "results": results}, indent=2))
        return 0

    if not results:
        _out(green("✔ nothing to clean — no regenerable directories found."))
        return 0

    _out("")
    _print_table(results, root)
    _out("")

    # interactive selection
    if o.interactive:
        if not sys.stdin.isatty():
            _out(red("✖ --interactive requires a terminal."))
            return 1
        answer = input(dim("Select to delete (e.g. 1,3-5 · all · none): "))
        idxs = parse_selection(answer, len(results))
        if not idxs:
            _out(dim("Nothing selected."))
            return 0
        chosen = [results[i] for i in idxs]
        freeable = sum(r["size"] for r in chosen)
        ok = input(yellow(f"Delete {len(chosen)} director(ies), freeing {human_size(freeable)}? [y/N] "))
        if ok.strip().lower() not in ("y", "yes"):
            _out(dim("Aborted."))
            return 0
        _report_removal(remove_all(chosen))
        return 0

    # delete everything found
    if o.delete:
        if not o.yes:
            if not sys.stdin.isatty():
                _out(red("✖ Refusing to delete without confirmation. Pass --yes in non-interactive use."))
                return 1
            total = sum(r["size"] for r in results)
            ok = input(yellow(f"Delete ALL {len(results)} director(ies), freeing {human_size(total)}? [y/N] "))
            if ok.strip().lower() not in ("y", "yes"):
                _out(dim("Aborted."))
                return 0
        _report_removal(remove_all(results))
        return 0

    # default: dry run
    _out(dim("Dry run — nothing deleted. Re-run with `-i` to choose, or `-d` to delete all."))
    return 0


if __name__ == "__main__":
    sys.exit(main())
