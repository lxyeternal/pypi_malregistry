def show():
    RED   = '\033[0;31m'
    BRED  = '\033[1;31m'
    DIM   = '\033[2m'
    RESET = '\033[0m'

    print("")
    print(f"{BRED} █████╗ ██╗   ██╗██████╗ ███████╗██╗  ██╗{RESET}")
    print(f"{BRED}██╔══██╗██║   ██║██╔══██╗██╔════╝╚██╗██╔╝{RESET}")
    print(f"{BRED}███████║██║   ██║██████╔╝█████╗   ╚███╔╝ {RESET}")
    print(f"{BRED}██╔══██║██║   ██║██╔══██╗██╔══╝   ██╔██╗ {RESET}")
    print(f"{BRED}██║  ██║╚██████╔╝██║  ██║███████╗██╔╝ ██╗{RESET}")
    print(f"{BRED}╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝{RESET}")
    print("")
    print(f"{DIM}        Terminal AI Coding Agent{RESET}")
    print("")
    print(f"{BRED}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━{RESET}")
    print("")
    print(f"{BRED}  Aurex installed successfully!{RESET}")
    print("")
    print(f"{DIM}  19 AI models included. To get started:{RESET}")
    print("")
    print(f"  {RED}aurex{RESET}       {DIM}# Launch Aurex{RESET}")
    print("")
    print(f"{DIM}  Inside Aurex:{RESET}")
    print(f"  {RED}model{RESET}       {DIM}# Switch AI model{RESET}")
    print(f"  {RED}help{RESET}        {DIM}# Show all commands{RESET}")
    print(f"  {RED}exit{RESET}        {DIM}# Quit{RESET}")
    print("")
    print(f"{BRED}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━{RESET}")
    print("")
    print(f"  Run {BRED}aurex{RESET} to start.")
    print("")
