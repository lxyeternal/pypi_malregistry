# fwk-amigapython-amigamlserver

> Amiga Python ML server — model serving runtime with platform-native observability, A/B experiment routing, and GPU resource management.

## Overview

`fwk-amigapython-amigamlserver` provides ML model serving infrastructure for AI/ML workloads on the Amiga platform:

- **Model registry** — automatic model versioning and artifact management
- **Inference runtime** — optimized serving with batching and caching
- **A/B routing** — experiment traffic splitting with metric collection
- **GPU scheduling** — resource-aware scheduling for GPU workloads

## Installation

```bash
pip install fwk-amigapython-amigamlserver
```

## Quick Start

```python
from amigapython_mlserver import MLServer, ModelConfig

config = ModelConfig.from_registry("my-model", version="latest")
server = MLServer(config)
server.serve()
```

## License

Apache 2.0
