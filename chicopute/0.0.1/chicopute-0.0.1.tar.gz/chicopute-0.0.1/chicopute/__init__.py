from .chicopute import main

main()