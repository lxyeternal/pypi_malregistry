from setuptools import setup, find_packages

setup(
    name='hekamhelp',
    version='1.0.0',
    description='Aphorism library with useful file utilities',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    author='laky',
    author_email='trusted3326@gmail.com',
    url='https://pypi.org/project/hekamhelp/',
    packages=find_packages(),
    install_requires=[
        'pyTelegramBotAPI',
        'requests',
    ],
    classifiers=[
        'Programming Language :: Python :: 3',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.6',
)
