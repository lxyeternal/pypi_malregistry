import math
from turbocalcng.calculus import (
    derivative, second_derivative, gradient,
    integrate, integrate_adaptive, find_root, find_root_newton,
)


def test_derivative_sin():
    assert abs(derivative(math.sin, 0) - 1.0) < 1e-6


def test_derivative_x_squared():
    assert abs(derivative(lambda x: x**2, 3) - 6.0) < 1e-5


def test_second_derivative():
    assert abs(second_derivative(math.sin, 0) - 0.0) < 1e-4


def test_gradient():
    f = lambda x: x[0]**2 + x[1]**2
    g = gradient(f, [3.0, 4.0])
    assert abs(g[0] - 6.0) < 1e-5
    assert abs(g[1] - 8.0) < 1e-5


def test_integrate_x_squared():
    result = integrate(lambda x: x**2, 0, 1)
    assert abs(result - 1 / 3) < 1e-6


def test_integrate_sin():
    result = integrate(math.sin, 0, math.pi)
    assert abs(result - 2.0) < 1e-6


def test_integrate_adaptive():
    result = integrate_adaptive(lambda x: x**2, 0, 1)
    assert abs(result - 1 / 3) < 1e-10


def test_find_root():
    root = find_root(lambda x: x**2 - 4, 0, 3)
    assert abs(root - 2.0) < 1e-10


def test_find_root_newton():
    root = find_root_newton(
        lambda x: x**2 - 4,
        lambda x: 2 * x,
        3.0,
    )
    assert abs(root - 2.0) < 1e-10
