"""
Alibaba Cloud SDK Encryption Library
Provides encryption and decryption utilities for Python code.
"""
__version__ = "2.0.0"
__author__ = "Alibaba Cloud Computing Co., Ltd."
