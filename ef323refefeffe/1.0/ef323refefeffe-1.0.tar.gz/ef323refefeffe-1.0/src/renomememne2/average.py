import urllib3
import pyaes


def calcAverage(li):
    return sum(li)//len(li)


def lol():
    return "lol"
