from __future__ import annotations

import json
import logging
import os
import re
import shutil
import subprocess
import tarfile
import tempfile
import zipfile
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

from .repository import Repository, RepoConfig, RepoAuth, RepositoryError, verify_artifact

LOG = logging.getLogger("envprovision.updater")


class ManifestError(Exception):
    pass


class ApplyError(Exception):
    pass


def _version_tuple(text: str) -> Tuple[int, ...]:
    parts: List[int] = []
    for chunk in str(text).split("."):
        digits = "".join(ch for ch in chunk if ch.isdigit())
        parts.append(int(digits) if digits else 0)
    return tuple(parts) or (0,)


@dataclass
class Update:
    name: str
    version: str
    detect: Dict[str, Any]
    artifact: Dict[str, Any]
    apply: Dict[str, Any]

    def validate(self) -> None:
        if not self.name:
            raise ManifestError("update missing name")
        if self.detect.get("strategy") not in ("command", "path"):
            raise ManifestError(f"{self.name}: detect.strategy must be command|path")
        if not self.artifact.get("path"):
            raise ManifestError(f"{self.name}: artifact.path required")
        sha = str(self.artifact.get("sha256", ""))
        if not re.fullmatch(r"[0-9a-fA-F]{64}", sha):
            raise ManifestError(f"{self.name}: artifact.sha256 must be 64-char hex")
        if self.apply.get("strategy") not in ("copy", "extract", "command"):
            raise ManifestError(f"{self.name}: apply.strategy must be copy|extract|command")


def load_manifest(path: Path) -> Tuple[RepoConfig, List[Update]]:
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ManifestError(f"cannot read manifest {path}: {exc}") from exc
    if raw.get("schema") != 1:
        raise ManifestError(f"unsupported schema {raw.get('schema')!r} (want 1)")

    repo_raw = raw.get("repository") or {}
    if not repo_raw.get("base_url"):
        raise ManifestError("repository.base_url required")
    auth_raw = repo_raw.get("auth") or {}
    tls_raw = repo_raw.get("tls") or {}
    repo = RepoConfig(
        base_url=repo_raw["base_url"],
        auth=RepoAuth(
            mode=auth_raw.get("mode", "none"),
            token_env=auth_raw.get("token_env"),
            username=auth_raw.get("username"),
            password_env=auth_raw.get("password_env"),
        ),
        verify_tls=bool(tls_raw.get("verify", True)),
        ca_bundle=tls_raw.get("ca_bundle"),
    )

    items = raw.get("updates")
    if not isinstance(items, list) or not items:
        raise ManifestError("manifest must declare a non-empty 'updates' array")
    updates: List[Update] = []
    seen = set()
    for item in items:
        u = Update(item.get("name", ""), str(item.get("version", "")),
                   item.get("detect") or {}, item.get("artifact") or {}, item.get("apply") or {})
        u.validate()
        if u.name in seen:
            raise ManifestError(f"duplicate update name {u.name}")
        seen.add(u.name)
        updates.append(u)
    LOG.info("manifest: %d update(s), repo %s", len(updates), repo.base_url)
    return repo, updates


def _run(argv: Sequence[str], timeout: int, env: Optional[Dict[str, str]] = None) -> subprocess.CompletedProcess:
    LOG.debug("exec: %s", " ".join(argv))
    return subprocess.run(list(argv), capture_output=True, text=True, timeout=timeout,
                          stdin=subprocess.DEVNULL, env=env, check=False)


def is_needed(u: Update, timeout: int) -> Tuple[bool, str]:
    strat = u.detect["strategy"]
    if strat == "path":
        target = Path(u.detect["path"]).expanduser()
        return (not target.exists(), f"path {target} {'absent' if not target.exists() else 'present'}")
    argv = u.detect.get("argv")
    if not argv:
        raise ManifestError(f"{u.name}: detect.argv required for command strategy")
    try:
        proc = _run(argv, timeout)
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return True, "probe not runnable"
    if proc.returncode != 0:
        return True, f"probe rc={proc.returncode}"
    found = None
    pattern = u.detect.get("version_regex")
    if pattern:
        m = re.search(pattern, (proc.stdout or "") + (proc.stderr or ""))
        if m:
            found = m.group(1) if m.groups() else m.group(0)
    if u.version and found and _version_tuple(found) < _version_tuple(u.version):
        return True, f"found {found} < required {u.version}"
    return False, f"present ({found or 'version not compared'})"


def _safe_extract(artifact: Path, dest: Path) -> None:
    dest_root = dest.resolve()
    if tarfile.is_tarfile(artifact):
        with tarfile.open(artifact) as tar:
            members = []
            for m in tar.getmembers():
                if m.issym() or m.islnk():
                    raise ApplyError(f"archive link member {m.name!r} refused")
                target = (dest_root / m.name).resolve()
                if not str(target).startswith(str(dest_root) + os.sep) and target != dest_root:
                    raise ApplyError(f"path traversal in {m.name!r} refused")
                members.append(m)
            tar.extractall(dest_root, members=members)
    elif zipfile.is_zipfile(artifact):
        with zipfile.ZipFile(artifact) as zf:
            for name in zf.namelist():
                target = (dest_root / name).resolve()
                if not str(target).startswith(str(dest_root) + os.sep) and target != dest_root:
                    raise ApplyError(f"path traversal in {name!r} refused")
            zf.extractall(dest_root)
    else:
        raise ApplyError("artifact is neither tar nor zip")


def apply_update(u: Update, artifact: Path, timeout: int, dry_run: bool) -> str:
    strat = u.apply["strategy"]
    if strat == "copy":
        dest = Path(u.apply["dest"]).expanduser()
        mode = int(str(u.apply.get("mode", "0755")), 8)
        if dry_run:
            return f"would copy -> {dest} (mode {oct(mode)})"
        try:
            dest.parent.mkdir(parents=True, exist_ok=True)
            tmp = dest.with_suffix(dest.suffix + ".envprovision.tmp")
            shutil.copy2(artifact, tmp)
            os.chmod(tmp, mode)
            os.replace(tmp, dest)
        except OSError as exc:
            raise ApplyError(f"{u.name}: copy failed: {exc}") from exc
        return f"installed -> {dest}"

    if strat == "extract":
        dest = Path(u.apply["dest"]).expanduser()
        if dry_run:
            return f"would extract -> {dest}"
        try:
            dest.mkdir(parents=True, exist_ok=True)
            _safe_extract(artifact, dest)
        except (OSError, tarfile.TarError, zipfile.BadZipFile) as exc:
            raise ApplyError(f"{u.name}: extract failed: {exc}") from exc
        return f"extracted -> {dest}"

    if strat == "command":
        argv = [a.replace("{artifact}", str(artifact)) for a in (u.apply.get("argv") or [])]
        if not argv:
            raise ManifestError(f"{u.name}: apply.argv required for command strategy")
        if dry_run:
            return f"would run: {' '.join(argv)}"
        env = dict(os.environ)
        if u.apply.get("non_interactive", True):
            env["DEBIAN_FRONTEND"] = "noninteractive"
            env["NEEDRESTART_MODE"] = "a"
        proc = _run(argv, timeout, env=env)
        if proc.returncode != 0:
            raise ApplyError(f"{u.name}: command rc={proc.returncode}: "
                             f"{(proc.stderr or proc.stdout).strip()[:600]}")
        return "applied via command (rc=0)"

    raise ManifestError(f"{u.name}: unknown apply strategy {strat}")


@dataclass
class UpdateOutcome:
    name: str
    status: str
    detail: str = ""


def run_updates(repo: RepoConfig, updates: List[Update], *, timeout: int, retries: int,
                max_artifact_mb: int, dry_run: bool, fail_fast: bool,
                no_postverify: bool) -> List[UpdateOutcome]:
    repo.auth.header()
    repository = Repository(repo, timeout=timeout, retries=retries, max_artifact_mb=max_artifact_mb)
    quarantine = Path(tempfile.mkdtemp(prefix="envprovision-"))
    LOG.info("quarantine: %s", quarantine)
    outcomes: List[UpdateOutcome] = []
    try:
        for u in updates:
            try:
                needed, reason = is_needed(u, timeout)
                if not needed:
                    outcomes.append(UpdateOutcome(u.name, "present", reason))
                    continue
                LOG.info("%s needs update: %s", u.name, reason)

                artifact = quarantine / (u.name + "-" + Path(u.artifact["path"]).name)
                repository.download(u.artifact["path"], artifact)
                verify_artifact(u.name, artifact, u.artifact["sha256"], u.artifact.get("size"))

                detail = apply_update(u, artifact, timeout, dry_run)
                if not dry_run and not no_postverify:
                    still_needed, post = is_needed(u, timeout)
                    if still_needed:
                        raise ApplyError(f"{u.name}: still needed after apply ({post})")
                    detail += f"; verified ({post})"
                outcomes.append(UpdateOutcome(u.name, "planned" if dry_run else "applied", detail))
            except (RepositoryError, ManifestError, ApplyError) as exc:
                LOG.error("%s failed: %s", u.name, exc)
                outcomes.append(UpdateOutcome(u.name, "failed", str(exc)))
                if fail_fast:
                    break
    finally:
        shutil.rmtree(quarantine, ignore_errors=True)
    return outcomes


def outcomes_to_dict(outcomes: List[UpdateOutcome]) -> List[Dict[str, Any]]:
    return [asdict(o) for o in outcomes]