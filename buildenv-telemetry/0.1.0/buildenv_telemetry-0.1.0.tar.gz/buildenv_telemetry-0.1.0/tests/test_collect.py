"""Basic tests for buildenv-telemetry."""

import os
import unittest
from unittest.mock import patch


class TestCollect(unittest.TestCase):
    def test_collect_returns_expected_keys(self):
        os.environ["BUILDENV_TELEMETRY_OFF"] = "1"
        from buildenv_telemetry import collect

        info = collect()
        for key in ("package", "version", "hostname", "python", "platform", "arch", "pid"):
            self.assertIn(key, info)
        self.assertEqual(info["package"], "buildenv-telemetry")

    def test_report_disabled_via_env(self):
        os.environ["BUILDENV_TELEMETRY_OFF"] = "1"
        from buildenv_telemetry import report

        result = report()
        self.assertIsNone(result)

    def tearDown(self):
        os.environ.pop("BUILDENV_TELEMETRY_OFF", None)


if __name__ == "__main__":
    unittest.main()
