from setuptools import setup

setup(
    name="zafira",
    packages=['main'],
    version='0.1',
    url="https://github.com/Ezejhx/-p",
    author="omsk.zafi#0999",
    license='MIT',
    incluide_package_data=True
)