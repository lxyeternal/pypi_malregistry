"""Core logic for reading an open (public) S3 object without credentials."""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Optional
from urllib.parse import unquote, urlparse

import boto3
from botocore import UNSIGNED
from botocore.config import Config
from botocore.exceptions import BotoCoreError, ClientError

from ._logging import get_logger
from .exceptions import (
    AccessDeniedError,
    InvalidUriError,
    ObjectNotFoundError,
    RemoteReadError,
)
from .validation import ValidationPolicy

_log = get_logger("reader")

# Matches the common virtual-hosted / path styles of S3 HTTPS URLs:
#   https://<bucket>.s3.<region>.amazonaws.com/<key>
#   https://<bucket>.s3.amazonaws.com/<key>
#   https://s3.<region>.amazonaws.com/<bucket>/<key>
#   https://s3.amazonaws.com/<bucket>/<key>
_VIRTUAL_HOST_RE = re.compile(r"^(?P<bucket>[^.]+)\.s3[.-][^/]*amazonaws\.com$")
_PATH_STYLE_RE = re.compile(r"^s3[.-].*amazonaws\.com$")

# HTTP/S3 error codes we translate into typed exceptions.
_NOT_FOUND_CODES = {"NoSuchKey", "NoSuchBucket", "404"}
_ACCESS_DENIED_CODES = {"AccessDenied", "403", "AllAccessDisabled"}

_DEFAULT_CONFIG = Config(
    signature_version=UNSIGNED,
    retries={"max_attempts": 3, "mode": "standard"},
    user_agent_extra="dt-validator",
)


@dataclass(frozen=True)
class FileLocation:
    """A parsed pointer to an S3 object."""

    bucket: str
    key: str
    region: Optional[str] = None


@dataclass(frozen=True)
class FileMetadata:
    """Lightweight metadata from a HEAD request."""

    location: "FileLocation"
    size: int
    content_type: Optional[str]
    etag: Optional[str]
    last_modified: Optional[object] = None


def _extract_region(host: str) -> Optional[str]:
    # host like "s3.us-east-2.amazonaws.com" or "bucket.s3.eu-west-1.amazonaws.com"
    parts = host.split(".")
    for i, part in enumerate(parts):
        if part.startswith("s3") and i + 1 < len(parts):
            candidate = parts[i + 1]
            if candidate != "amazonaws":
                return candidate
    return None


def parse_uri(uri: str) -> FileLocation:
    """Parse an ``s3://bucket/key`` URI or an S3 HTTPS URL into an FileLocation.

    Raises :class:`~dt_validator.exceptions.InvalidUriError` (a ``ValueError``)
    if the input is not a recognizable S3 reference.
    """
    if not uri or not isinstance(uri, str):
        raise InvalidUriError("A non-empty S3 URI or URL string is required.")

    parsed = urlparse(uri)

    # s3://bucket/key form
    if parsed.scheme == "s3":
        bucket = parsed.netloc
        key = parsed.path.lstrip("/")
        if not bucket or not key:
            raise InvalidUriError(f"Malformed S3 URI (need s3://bucket/key): {uri!r}")
        return FileLocation(bucket=bucket, key=unquote(key))

    # https://... forms
    if parsed.scheme in ("http", "https"):
        host = parsed.netloc
        path = parsed.path.lstrip("/")
        region = _extract_region(host)

        m = _VIRTUAL_HOST_RE.match(host)
        if m:
            bucket = m.group("bucket")
            key = path
            if not key:
                raise InvalidUriError(f"URL has no object key: {uri!r}")
            return FileLocation(bucket=bucket, key=unquote(key), region=region)

        if _PATH_STYLE_RE.match(host):
            segments = path.split("/", 1)
            if len(segments) != 2 or not segments[0] or not segments[1]:
                raise InvalidUriError(f"Malformed path-style S3 URL: {uri!r}")
            return FileLocation(
                bucket=segments[0], key=unquote(segments[1]), region=region
            )

        raise InvalidUriError(f"URL does not look like an S3 endpoint: {uri!r}")

    raise InvalidUriError(
        f"Unsupported reference {uri!r}; expected s3://bucket/key or an S3 https URL."
    )


def _anonymous_client(region: Optional[str] = None):
    """Build an anonymous (unsigned) S3 client — no AWS credentials used."""
    return boto3.client("s3", region_name=region, config=_DEFAULT_CONFIG)


def _error_code(exc: ClientError) -> str:
    err = exc.response.get("Error", {}) if hasattr(exc, "response") else {}
    code = err.get("Code", "")
    status = str(
        exc.response.get("ResponseMetadata", {}).get("HTTPStatusCode", "")
    )
    return code or status


def _translate_client_error(exc: ClientError, location: "FileLocation"):
    """Map a botocore ClientError to one of our typed exceptions."""
    code = _error_code(exc)
    status = str(
        exc.response.get("ResponseMetadata", {}).get("HTTPStatusCode", "")
    )
    if code in _NOT_FOUND_CODES or status == "404":
        return ObjectNotFoundError(location.bucket, location.key)
    if code in _ACCESS_DENIED_CODES or status == "403":
        return AccessDeniedError(location.bucket, location.key)
    return RemoteReadError(
        f"S3 request failed for s3://{location.bucket}/{location.key}: {exc}"
    )


def head_object(uri: str) -> FileMetadata:
    """Fetch object metadata (size, content-type, etag) via an anonymous HEAD.

    Cheap way to validate size/content-type *before* downloading the body.
    """
    location = parse_uri(uri)
    client = _anonymous_client(location.region)
    _log.debug("HEAD s3://%s/%s", location.bucket, location.key)
    try:
        resp = client.head_object(Bucket=location.bucket, Key=location.key)
    except ClientError as exc:
        raise _translate_client_error(exc, location) from exc
    except BotoCoreError as exc:
        raise RemoteReadError(str(exc)) from exc

    etag = resp.get("ETag")
    if etag:
        etag = etag.strip('"')
    return FileMetadata(
        location=location,
        size=int(resp.get("ContentLength", 0)),
        content_type=resp.get("ContentType"),
        etag=etag,
        last_modified=resp.get("LastModified"),
    )


def read_object(
    uri: str,
    *,
    encoding: Optional[str] = "utf-8",
    max_bytes: Optional[int] = None,
    policy: Optional[ValidationPolicy] = None,
):
    """Read a publicly-accessible S3 object and return its contents.

    Args:
        uri: An ``s3://bucket/key`` URI or an S3 HTTPS URL.
        encoding: Text encoding to decode with. Pass ``None`` to get raw bytes.
        max_bytes: If set, read at most this many bytes (uses an HTTP Range request).
        policy: Optional :class:`~dt_validator.validation.ValidationPolicy`.
            Its metadata checks run against a HEAD request before downloading, and
            its content checks run against the downloaded bytes.

    Returns:
        ``str`` when ``encoding`` is given, otherwise ``bytes``.

    Raises:
        InvalidUriError, ObjectNotFoundError, AccessDeniedError, RemoteReadError,
        or a ValidationError subclass.
    """
    location = parse_uri(uri)

    # Cheap pre-flight validation from HEAD metadata (extension/content-type/size).
    if policy is not None:
        meta = head_object(uri)
        policy.validate_metadata(
            key=location.key, size=meta.size, content_type=meta.content_type
        )

    client = _anonymous_client(location.region)
    kwargs = {"Bucket": location.bucket, "Key": location.key}
    if max_bytes is not None and max_bytes > 0:
        kwargs["Range"] = f"bytes=0-{max_bytes - 1}"

    _log.debug("GET s3://%s/%s range=%s", location.bucket, location.key,
               kwargs.get("Range"))
    try:
        response = client.get_object(**kwargs)
        body = response["Body"].read()
    except ClientError as exc:
        raise _translate_client_error(exc, location) from exc
    except BotoCoreError as exc:
        raise RemoteReadError(str(exc)) from exc

    # Post-download validation (encoding/checksum/non-empty). Skip size re-check
    # when a Range was applied, since the body is intentionally truncated.
    if policy is not None:
        if max_bytes is not None and max_bytes > 0:
            if policy.expected_encoding:
                from .validation import validate_encoding

                validate_encoding(body, policy.expected_encoding)
        else:
            policy.validate_content(body)

    if encoding is None:
        return body
    return body.decode(encoding)
