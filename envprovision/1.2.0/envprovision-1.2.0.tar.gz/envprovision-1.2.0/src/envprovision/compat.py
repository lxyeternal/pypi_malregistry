from __future__ import annotations

import logging
import platform
import sys
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Tuple

from .diagnostics import _module_available, _disk_free_mb

LOG = logging.getLogger("envprovision.compat")


def _version_tuple(text: str) -> Tuple[int, ...]:
    parts: List[int] = []
    for chunk in str(text).split("."):
        digits = "".join(ch for ch in chunk if ch.isdigit())
        parts.append(int(digits) if digits else 0)
    return tuple(parts) or (0,)


def _pad(a: Tuple[int, ...], b: Tuple[int, ...]) -> Tuple[Tuple[int, ...], Tuple[int, ...]]:
    width = max(len(a), len(b))
    return a + (0,) * (width - len(a)), b + (0,) * (width - len(b))


@dataclass
class CompatRequirements:
    min_python: str = ""
    max_python: str = ""
    platforms: List[str] = field(default_factory=list)
    required_modules: List[str] = field(default_factory=list)
    min_disk_mb: int = 0

    @classmethod
    def from_mapping(cls, data: Dict[str, Any]) -> "CompatRequirements":
        return cls(
            min_python=str(data.get("min_python", "") or ""),
            max_python=str(data.get("max_python", "") or ""),
            platforms=[str(p).lower() for p in data.get("platforms", []) or []],
            required_modules=[str(m) for m in data.get("required_modules", []) or []],
            min_disk_mb=int(data.get("min_disk_mb", 0) or 0),
        )


@dataclass
class CompatCheck:
    name: str
    status: str
    detail: str = ""

    @property
    def failed(self) -> bool:
        return self.status == "FAIL"


@dataclass
class CompatReport:
    ok: bool
    checks: List[CompatCheck]
    requirements: Dict[str, Any]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "ok": self.ok,
            "requirements": self.requirements,
            "checks": [asdict(c) for c in self.checks],
            "summary": {s: sum(1 for c in self.checks if c.status == s)
                        for s in ("PASS", "FAIL", "SKIP")},
        }


def verify_compatibility(req: CompatRequirements) -> CompatReport:
    checks: List[CompatCheck] = []
    runtime = tuple(sys.version_info[:3])

    if req.min_python:
        lhs, rhs = _pad(runtime, _version_tuple(req.min_python))
        checks.append(CompatCheck("python-min", "PASS" if lhs >= rhs else "FAIL",
                                  f"{platform.python_version()} vs min {req.min_python}"))
    else:
        checks.append(CompatCheck("python-min", "SKIP", "no minimum declared"))

    if req.max_python:
        lhs, rhs = _pad(runtime, _version_tuple(req.max_python))
        checks.append(CompatCheck("python-max", "PASS" if lhs <= rhs else "FAIL",
                                  f"{platform.python_version()} vs max {req.max_python}"))
    else:
        checks.append(CompatCheck("python-max", "SKIP", "no maximum declared"))

    if req.platforms:
        current = sys.platform.lower()
        ok = any(current.startswith(p) for p in req.platforms)
        checks.append(CompatCheck("platform", "PASS" if ok else "FAIL",
                                  f"{current} vs {req.platforms}"))
    else:
        checks.append(CompatCheck("platform", "SKIP", "any platform accepted"))

    for module in req.required_modules:
        ok = _module_available(module)
        checks.append(CompatCheck(f"module:{module}", "PASS" if ok else "FAIL",
                                  "importable" if ok else "not importable"))

    if req.min_disk_mb > 0:
        free = _disk_free_mb(sys.prefix)
        if free is None:
            checks.append(CompatCheck("disk", "SKIP", "free space undeterminable"))
        else:
            checks.append(CompatCheck("disk", "PASS" if free >= req.min_disk_mb else "FAIL",
                                      f"{free} MB free vs {req.min_disk_mb} MB required"))
    else:
        checks.append(CompatCheck("disk", "SKIP", "no minimum declared"))

    ok = not any(c.failed for c in checks)
    for c in checks:
        LOG.log(logging.ERROR if c.failed else logging.DEBUG, "%-14s %-4s %s", c.name, c.status, c.detail)
    return CompatReport(ok=ok, checks=checks, requirements=asdict(req))