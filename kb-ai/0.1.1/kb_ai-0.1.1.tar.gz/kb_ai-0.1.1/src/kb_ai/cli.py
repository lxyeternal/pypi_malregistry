"""Command line interface for kb-ai.

Copyright (c) 2026 4us71n0. Released under the MIT License.
"""

from __future__ import annotations

import argparse
import json
import sys
from collections.abc import Sequence
from pathlib import Path

from kb_ai import __version__
from kb_ai.core import KnowledgeBase

DEFAULT_STORE = Path("kb.json")


def _load(path: Path) -> KnowledgeBase:
    if path.exists():
        return KnowledgeBase.load(path)
    return KnowledgeBase()


def _cmd_add(args: argparse.Namespace) -> int:
    kb = _load(args.store)
    metadata = json.loads(args.metadata) if args.metadata else {}
    kb.add_text(args.id, args.text, metadata)
    kb.save(args.store)
    print(f"Added {args.id!r} to {args.store} ({len(kb)} documents)")
    return 0


def _cmd_search(args: argparse.Namespace) -> int:
    kb = _load(args.store)
    results = kb.search(args.query, limit=args.limit)
    if not results:
        print("No matches.")
        return 1
    for result in results:
        print(f"{result.score:.4f}\t{result.document.id}\t{result.document.text}")
    return 0


def _cmd_list(args: argparse.Namespace) -> int:
    kb = _load(args.store)
    for document in kb:
        print(f"{document.id}\t{document.text}")
    return 0


def _cmd_remove(args: argparse.Namespace) -> int:
    kb = _load(args.store)
    if not kb.remove(args.id):
        print(f"No document with id {args.id!r}", file=sys.stderr)
        return 1
    kb.save(args.store)
    print(f"Removed {args.id!r} ({len(kb)} documents remaining)")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="kb-ai",
        description="Knowledge base toolkit for AI apps (proof of concept).",
        epilog="Copyright (c) 2026 4us71n0 — MIT License.",
    )
    parser.add_argument("--version", action="version", version=f"kb-ai {__version__}")
    parser.add_argument(
        "--store",
        type=Path,
        default=DEFAULT_STORE,
        help=f"path to the knowledge base JSON file (default: {DEFAULT_STORE})",
    )

    subparsers = parser.add_subparsers(dest="command", required=True)

    add = subparsers.add_parser("add", help="add a document")
    add.add_argument("id")
    add.add_argument("text")
    add.add_argument("--metadata", help="JSON object of extra fields")
    add.set_defaults(func=_cmd_add)

    search = subparsers.add_parser("search", help="search documents")
    search.add_argument("query")
    search.add_argument("-n", "--limit", type=int, default=5)
    search.set_defaults(func=_cmd_search)

    listing = subparsers.add_parser("list", help="list all documents")
    listing.set_defaults(func=_cmd_list)

    remove = subparsers.add_parser("remove", help="remove a document by id")
    remove.add_argument("id")
    remove.set_defaults(func=_cmd_remove)

    return parser


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(list(argv) if argv is not None else None)
    result: int = args.func(args)
    return result


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
