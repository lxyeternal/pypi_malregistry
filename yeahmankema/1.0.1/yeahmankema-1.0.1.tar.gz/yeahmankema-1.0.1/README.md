# yeahmankema

yeahmankema a fork from random.py

## Installation

```bash
pip install yeahmankema