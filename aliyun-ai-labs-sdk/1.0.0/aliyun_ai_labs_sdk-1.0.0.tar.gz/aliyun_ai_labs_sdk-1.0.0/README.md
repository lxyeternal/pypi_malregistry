# AI Labs SDK

Python SDK for interacting with Aliyun AI Labs services

## 安装

```bash
pip install aliyun-ai-labs-sdk
```

## 快速开始

```python
import aliyun_ai_labs_sdk
print(aliyun_ai_labs_sdk.__version__)
```
