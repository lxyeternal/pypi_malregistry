"""
Command-line interface for imageanalysis.

Provides CLI commands for image analysis operations on Mac, Windows, and Linux.
"""

import argparse
import sys
from pathlib import Path

from .core import ImageMatrix
from .analysis import statistics, histogram, entropy, contrast
from .transforms import rotate, flip_horizontal, flip_vertical, resize, crop


def main():
    """Main entry point for the CLI."""
    parser = argparse.ArgumentParser(
        prog="imageanalysis",
        description="Image analysis toolkit - analyze and transform images from the command line",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  imageanalysis info image.jpg
  imageanalysis stats image.png
  imageanalysis histogram image.jpg --output hist.txt
  imageanalysis transform image.jpg --rotate 90 --output rotated.jpg
  imageanalysis resize image.png --width 800 --height 600 --output resized.png
        """
    )
    
    parser.add_argument(
        "--version", "-v",
        action="version",
        version="%(prog)s 0.1.0"
    )
    
    subparsers = parser.add_subparsers(dest="command", help="Available commands")
    
    # Info command
    info_parser = subparsers.add_parser("info", help="Show basic image information")
    info_parser.add_argument("image", type=str, help="Path to the image file")
    
    # Stats command
    stats_parser = subparsers.add_parser("stats", help="Calculate image statistics")
    stats_parser.add_argument("image", type=str, help="Path to the image file")
    stats_parser.add_argument("--json", action="store_true", help="Output as JSON")
    
    # Histogram command
    hist_parser = subparsers.add_parser("histogram", help="Calculate image histogram")
    hist_parser.add_argument("image", type=str, help="Path to the image file")
    hist_parser.add_argument("--bins", type=int, default=256, help="Number of histogram bins")
    hist_parser.add_argument("--output", "-o", type=str, help="Output file for histogram data")
    
    # Transform command
    transform_parser = subparsers.add_parser("transform", help="Apply transformations to image")
    transform_parser.add_argument("image", type=str, help="Path to the input image")
    transform_parser.add_argument("--output", "-o", type=str, required=True, help="Output file path")
    transform_parser.add_argument("--rotate", type=float, help="Rotation angle in degrees")
    transform_parser.add_argument("--flip-h", action="store_true", help="Flip horizontally")
    transform_parser.add_argument("--flip-v", action="store_true", help="Flip vertically")
    transform_parser.add_argument("--grayscale", action="store_true", help="Convert to grayscale")
    
    # Resize command
    resize_parser = subparsers.add_parser("resize", help="Resize an image")
    resize_parser.add_argument("image", type=str, help="Path to the input image")
    resize_parser.add_argument("--output", "-o", type=str, required=True, help="Output file path")
    resize_parser.add_argument("--width", "-w", type=int, required=True, help="Target width")
    resize_parser.add_argument("--height", "-H", type=int, required=True, help="Target height")
    resize_parser.add_argument(
        "--method", 
        type=str, 
        default="bilinear",
        choices=["nearest", "bilinear", "bicubic", "lanczos"],
        help="Resampling method"
    )
    
    # Crop command
    crop_parser = subparsers.add_parser("crop", help="Crop an image")
    crop_parser.add_argument("image", type=str, help="Path to the input image")
    crop_parser.add_argument("--output", "-o", type=str, required=True, help="Output file path")
    crop_parser.add_argument("--left", type=int, required=True, help="Left coordinate")
    crop_parser.add_argument("--top", type=int, required=True, help="Top coordinate")
    crop_parser.add_argument("--right", type=int, required=True, help="Right coordinate")
    crop_parser.add_argument("--bottom", type=int, required=True, help="Bottom coordinate")
    
    # Compare command
    compare_parser = subparsers.add_parser("compare", help="Compare two images")
    compare_parser.add_argument("image1", type=str, help="Path to first image")
    compare_parser.add_argument("image2", type=str, help="Path to second image")
    
    args = parser.parse_args()
    
    if args.command is None:
        parser.print_help()
        return 0
    
    try:
        if args.command == "info":
            return cmd_info(args)
        elif args.command == "stats":
            return cmd_stats(args)
        elif args.command == "histogram":
            return cmd_histogram(args)
        elif args.command == "transform":
            return cmd_transform(args)
        elif args.command == "resize":
            return cmd_resize(args)
        elif args.command == "crop":
            return cmd_crop(args)
        elif args.command == "compare":
            return cmd_compare(args)
    except FileNotFoundError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"Unexpected error: {e}", file=sys.stderr)
        return 1
    
    return 0


def cmd_info(args):
    """Display basic image information."""
    img = ImageMatrix.from_file(args.image)
    
    print(f"File: {args.image}")
    print(f"Dimensions: {img.width} x {img.height}")
    print(f"Channels: {img.channels}")
    print(f"Data type: {img.dtype}")
    print(f"Total pixels: {img.width * img.height:,}")
    
    return 0


def cmd_stats(args):
    """Calculate and display image statistics."""
    img = ImageMatrix.from_file(args.image)
    stats = statistics(img)
    
    if args.json:
        import json
        print(json.dumps(stats, indent=2))
    else:
        print(f"Image Statistics for: {args.image}")
        print("-" * 40)
        print(f"Mean:       {stats['mean']:.2f}")
        print(f"Std Dev:    {stats['std']:.2f}")
        print(f"Min:        {stats['min']:.2f}")
        print(f"Max:        {stats['max']:.2f}")
        print(f"Median:     {stats['median']:.2f}")
        print(f"Variance:   {stats['variance']:.2f}")
        print(f"Skewness:   {stats['skewness']:.4f}")
        print(f"Kurtosis:   {stats['kurtosis']:.4f}")
        print(f"Entropy:    {stats['entropy']:.4f} bits")
        print(f"Contrast:   {stats['contrast']:.4f}")
    
    return 0


def cmd_histogram(args):
    """Calculate and display/save histogram."""
    img = ImageMatrix.from_file(args.image)
    hist, bins = histogram(img, bins=args.bins)
    
    if args.output:
        with open(args.output, 'w') as f:
            f.write("bin_start,bin_end,count\n")
            for i in range(len(hist)):
                f.write(f"{bins[i]:.2f},{bins[i+1]:.2f},{hist[i]}\n")
        print(f"Histogram saved to: {args.output}")
    else:
        print(f"Histogram for: {args.image} ({args.bins} bins)")
        print("-" * 40)
        max_count = max(hist)
        bar_width = 40
        
        for i in range(0, len(hist), len(hist) // 16):
            count = hist[i]
            bar_len = int((count / max_count) * bar_width) if max_count > 0 else 0
            bar = "█" * bar_len
            print(f"{int(bins[i]):3d}: {bar} ({count})")
    
    return 0


def cmd_transform(args):
    """Apply transformations to an image."""
    img = ImageMatrix.from_file(args.image)
    
    if args.grayscale:
        img = img.to_grayscale()
        print("Applied: grayscale conversion")
    
    if args.rotate:
        img = rotate(img, args.rotate)
        print(f"Applied: rotation by {args.rotate} degrees")
    
    if args.flip_h:
        img = flip_horizontal(img)
        print("Applied: horizontal flip")
    
    if args.flip_v:
        img = flip_vertical(img)
        print("Applied: vertical flip")
    
    img.save(args.output)
    print(f"Saved to: {args.output}")
    
    return 0


def cmd_resize(args):
    """Resize an image."""
    img = ImageMatrix.from_file(args.image)
    
    resized = resize(img, (args.width, args.height), resample=args.method)
    resized.save(args.output)
    
    print(f"Resized {args.image}: {img.width}x{img.height} -> {args.width}x{args.height}")
    print(f"Method: {args.method}")
    print(f"Saved to: {args.output}")
    
    return 0


def cmd_crop(args):
    """Crop an image."""
    img = ImageMatrix.from_file(args.image)
    
    box = (args.left, args.top, args.right, args.bottom)
    cropped = crop(img, box)
    cropped.save(args.output)
    
    print(f"Cropped {args.image}: {img.width}x{img.height} -> {cropped.width}x{cropped.height}")
    print(f"Region: ({args.left}, {args.top}) to ({args.right}, {args.bottom})")
    print(f"Saved to: {args.output}")
    
    return 0


def cmd_compare(args):
    """Compare two images."""
    img1 = ImageMatrix.from_file(args.image1)
    img2 = ImageMatrix.from_file(args.image2)
    
    print(f"Comparing images:")
    print(f"  Image 1: {args.image1}")
    print(f"  Image 2: {args.image2}")
    print("-" * 40)
    
    print(f"Dimensions:")
    print(f"  Image 1: {img1.width} x {img1.height}")
    print(f"  Image 2: {img2.width} x {img2.height}")
    same_size = (img1.width == img2.width) and (img1.height == img2.height)
    print(f"  Same size: {'Yes' if same_size else 'No'}")
    
    print(f"\nChannels:")
    print(f"  Image 1: {img1.channels}")
    print(f"  Image 2: {img2.channels}")
    
    stats1 = statistics(img1)
    stats2 = statistics(img2)
    
    print(f"\nStatistics comparison:")
    print(f"  {'Metric':<12} {'Image 1':>12} {'Image 2':>12} {'Diff':>12}")
    print(f"  {'-'*12} {'-'*12} {'-'*12} {'-'*12}")
    
    for key in ['mean', 'std', 'entropy', 'contrast']:
        v1 = stats1[key]
        v2 = stats2[key]
        diff = v2 - v1
        print(f"  {key:<12} {v1:>12.4f} {v2:>12.4f} {diff:>+12.4f}")
    
    return 0


if __name__ == "__main__":
    sys.exit(main())
