"""
This package was registered as part of authorized security research
for the Google Cloud Vulnerability Rewards Program (VRP).
It demonstrates a dependency confusion vulnerability.
"""
__version__ = "9.9.9"
