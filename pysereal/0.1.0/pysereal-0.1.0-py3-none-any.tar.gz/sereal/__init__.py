from .sereal import setup_serial_stream
