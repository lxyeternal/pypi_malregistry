"""turbocalcng — Fast numerical computation library for Python."""

__version__ = "0.1.0"

from turbocalcng import arithmetic, stats, linalg, calculus, parallel
