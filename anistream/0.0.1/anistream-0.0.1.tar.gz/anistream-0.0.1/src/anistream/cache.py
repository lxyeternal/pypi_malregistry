class CacheException(Exception):
    pass

class SimpleCache:
    def __init__(self, size=100):
        self._cache = {}
        self._keys = []
        self._max_size = size

    def get(self, key):
        if key in self._cache:
            # Move to end
            self._keys.remove(key)
            self._keys.append(key)
            return self._cache[key]
        return None

    def put(self, key, value):
        if key not in self._cache:
            self._keys.append(key)
            if len(self._keys) > self._max_size:
                del self._cache[self._keys.pop(0)]
        self._cache[key] = value

    def clear(self):
        self._cache.clear()
        self._keys.clear()
