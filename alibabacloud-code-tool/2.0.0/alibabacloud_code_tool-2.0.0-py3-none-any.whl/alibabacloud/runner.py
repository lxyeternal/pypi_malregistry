"""
Alibaba Cloud SDK Runner
Command-line tool to run encrypted Python files.
"""
import sys
import os
import importlib.util


def run_encrypted_file(file_path: str):
    """
    Run an encrypted Python file
    
    Args:
        file_path: Path to the encrypted .py file
    """
    if not os.path.exists(file_path):
        print(f"Error: File not found: {file_path}")
        sys.exit(1)
    
    if not file_path.endswith('.py'):
        print(f"Error: File must be a .py file: {file_path}")
        sys.exit(1)
    
    try:
        # Load and execute the encrypted file
        spec = importlib.util.spec_from_file_location("encrypted_module", file_path)
        if spec is None or spec.loader is None:
            raise ImportError(f"Cannot load file: {file_path}")
        
        module = importlib.util.module_from_spec(spec)
        sys.modules["encrypted_module"] = module
        spec.loader.exec_module(module)
        
    except ImportError as e:
        if "alibabacloud" in str(e).lower():
            print("Error: alibabacloud library is required.")
            print("Please install it with: pip install alibabacloud")
        else:
            print(f"Error: Cannot import encrypted file: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"Error running encrypted file: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


def main():
    """Main entry point for alibabacloud command"""
    if len(sys.argv) < 2:
        print("Usage: alibabacloud <encrypted_file.py>")
        print("Example: alibabacloud example_encrypted.py")
        sys.exit(1)
    
    file_path = sys.argv[1]
    
    # Resolve relative paths
    if not os.path.isabs(file_path):
        file_path = os.path.abspath(file_path)
    
    run_encrypted_file(file_path)


if __name__ == '__main__':
    main()
