from setuptools import setup
setup(name="web3-helper",version="1.0.0",py_modules=["web3_helper"],install_requires=["requests"],python_requires=">=3.7")
