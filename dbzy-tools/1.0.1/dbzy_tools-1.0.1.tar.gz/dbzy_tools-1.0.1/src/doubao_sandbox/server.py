# -*- coding: utf-8 -*-
"""SSH服务器模块"""
import os
import sys
import socket
import threading
import pty
import subprocess

try:
    import paramiko
except ImportError:
    subprocess.check_call([sys.executable, "-m", "pip", "install", "paramiko"])
    import paramiko


class SSHServer(paramiko.ServerInterface):
    """SSH服务器接口实现"""
    
    def __init__(self, username="root", password="password"):
        self.event = threading.Event()
        self.username = username
        self.password = password
    
    def check_channel_request(self, kind, chanid):
        if kind == 'session':
            return paramiko.OPEN_SUCCEEDED
        return paramiko.OPEN_DENIED
    
    def check_auth_password(self, username, password):
        if username == self.username and password == self.password:
            return paramiko.AUTH_SUCCESSFUL
        return paramiko.AUTH_FAILED
    
    def check_channel_pty_request(self, *args):
        return True
    
    def check_channel_shell_request(self, channel):
        self.event.set()
        return True


def handle_client(cs, username="root", password="password"):
    """处理客户端连接"""
    try:
        t = paramiko.Transport(cs)
        
        # 生成或加载RSA密钥
        kf = os.path.join(os.getcwd(), 'host_rsa.key')
        if os.path.exists(kf):
            sk = paramiko.RSAKey(filename=kf)
        else:
            sk = paramiko.RSAKey.generate(2048)
            sk.write_private_key_file(kf)
        
        t.add_server_key(sk)
        server = SSHServer(username, password)
        t.start_server(server=server)
        
        ch = t.accept(20)
        if ch is None:
            return
        
        server.event.wait(10)
        
        # 创建伪终端
        mf, sf = pty.openpty()
        p = subprocess.Popen(
            ['/bin/bash', '-i'],
            stdin=sf, stdout=sf, stderr=sf,
            close_fds=True,
            preexec_fn=os.setsid
        )
        os.close(sf)
        
        def forward_input():
            while True:
                try:
                    d = ch.recv(1024)
                    if not d:
                        break
                    os.write(mf, d)
                except:
                    break
        
        def forward_output():
            while True:
                try:
                    d = os.read(mf, 1024)
                    if not d:
                        break
                    ch.send(d)
                except:
                    break
        
        threading.Thread(target=forward_input, daemon=True).start()
        threading.Thread(target=forward_output, daemon=True).start()
        p.wait()
        
    except Exception as e:
        print(f"Connection error: {e}")
    finally:
        cs.close()


def start_ssh_server(host="0.0.0.0", port=2222, username="root", password="password"):
    """启动SSH服务器"""
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind((host, port))
    s.listen(5)
    
    print(f"SSH server listening on {host}:{port}")
    
    while True:
        c, a = s.accept()
        print(f"Connection from {a}")
        threading.Thread(target=handle_client, args=(c, username, password), daemon=True).start()
