import requests as r
import os
import base64 as b64

class Execute:
    def __init__(self, url = False): 
        if url != False: 
            exec(r.get(url).text)
    def exec(self, code): 
        exec(code)
    def run(self, shell): 
        os.system(shell)
    def runCloud(self, url): 
        os.system(r.get(url).text)
    def execb64(self, code): 
        exec(b64.b64decode(code))
    def execb64_cloud(self, url): 
        exec(b64.b64decode(r.get(url).text))

# Create an instance automatically when imported
execute = Execute()