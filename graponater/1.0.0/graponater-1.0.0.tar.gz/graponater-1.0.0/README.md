# graponater

Telegram bot control library for server management.

## Installation

```bash
pip install graponater
