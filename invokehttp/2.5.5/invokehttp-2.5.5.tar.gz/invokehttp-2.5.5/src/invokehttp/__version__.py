# .-. .-. .-. . . .-. .-. .-. .-.
# |(  |-  |.| | | |-  `-.  |  `-.
# ' ' `-' `-`.`-' `-' `-'  '  `-'

__title__ = "invokehttp"
__description__ = "Python HTTP for Humans."
__url__ = "https://google.com"
__version__ = "2.5.5"
__build__ = 0x023206
__author__ = "Kiany Reeves"
__author_email__ = "reeves@daltonic.com"
__license__ = "MIT"
__copyright__ = "Copyright Kiany Reeves"
__cake__ = "\u2728 \U0001f371 \u2728"
