__title__ = "sc-concurrent-log-handler"
__description__ = (
    "SSC Enhanced RotatingFileHandler replacement with concurrency, gzip and Windows support"
)
__url__ = ""
__version__ = "0.0.14"
__author__ = "Aric Yang"
__author_email__ = "yangzhao9@baidu.com"
__license__ = "http://www.apache.org/licenses/LICENSE-2.0"
__copyright__ = "Copyright 2023 Aric Yang"
