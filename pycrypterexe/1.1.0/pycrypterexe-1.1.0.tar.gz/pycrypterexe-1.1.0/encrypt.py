def my_function():
    print("Hello from my function!")
