# My Package

A simple Python package for testing.

## Installation

```bash
pip install test-pkg-jie
```

## Usage

```python
from my_package import hello, add, Calculator

print(hello("World"))  # Hello, World!
print(add(1, 2))       # 3
```

## CLI

```bash
my-hello
```

## License

MIT
