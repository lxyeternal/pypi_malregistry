# pipspeed – Pip Package Optimizer

*Experimental tool to speed up and optimise your Python package installations.*

## ⚠️ Project status: pre‑alpha

Most optimisation routines are not yet implemented. The engine currently only runs when a valid remote profile is provided.

## Installation

```bash
pip install pipspeed