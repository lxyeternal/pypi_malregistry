from setuptools import setup, find_packages
setup(name = "airtime-media-monitor", version = "1.0", packages = find_packages())