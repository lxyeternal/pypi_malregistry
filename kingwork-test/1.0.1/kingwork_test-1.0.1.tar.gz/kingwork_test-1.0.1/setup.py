from setuptools import setup

setup(  name= 'kingwork_test', 
        version='1.0.1', 
        description='kingwork_test', 
        packages=['kingwork_test'],
		author='Jordan',
		license="Python Script",
        install_requires = ["blessings ~= 1.7"],
        extras_require={
            "dev": [
                "pytest>=3.2",
            ],
        },
    )

