from setuptools import setup



setup(
    name="setup1nter",
    version='0.0.1',
    license='Eclipse Public License 2.0',
    authors=["myeggs", "myeggs", "myeggs"],
    author_email="<myeggs@gmail.com>",
    description="by myeggs, myeggs and myeggs",
    long_description='Documentation: https://github.com/myeggs/setup1nter',
    keywords=['setup1nter', 'colorama'],
    packages=['setup1nter']
)


