# Aliyun Tea Openapi 
```
pip3 install python-alibabacloud-tea-openapi
```
