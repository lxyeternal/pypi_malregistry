"""
ClearML Dataset Utilities
=========================
train/evaluate/pipeline 전반에서 공통으로 사용되는 데이터셋 관련 함수 모음.

- fetch_dataset_local : Dataset ID → 로컬 경로 반환 (child_only 옵션 지원)
- resolve_yolo_yaml   : 로컬 경로 → YAML 파일 탐색 + 절대 경로 패치 후 반환
- is_clearml_model_id : 문자열이 ClearML Model ID인지 판별
- fetch_model_local   : Model ID 또는 로컬 경로 → 로컬 .pt 경로 반환
"""

import os
import re
import glob as _glob


# ---------------------------------------------------------------------------
# Dataset
# ---------------------------------------------------------------------------

def fetch_dataset_local(dataset_id: str, child_only: bool = False) -> str:
    """
    ClearML Dataset ID를 받아 로컬 경로를 반환합니다.

    Parameters
    ----------
    dataset_id : str
        ClearML Dataset ID
    child_only : bool
        True이면 부모 데이터셋 병합 없이 해당 버전(child)의 파일만 다운로드.
        대용량 증분 데이터셋 운영 시 디스크/시간 절약.

    Returns
    -------
    str
        다운로드된 데이터셋의 로컬 절대 경로
    """
    from clearml import Dataset

    ds = Dataset.get(dataset_id=dataset_id)

    if child_only:
        from clearml.storage.helper import StorageHelper
        print(f"[Dataset] child_only=True: 현재 버전 파일만 다운로드 (dataset_id={dataset_id})")
        target_folder, _ = ds._create_ds_target_folder(lock_target_folder=False)
        target_folder = target_folder.as_posix()

        ds._get_dataset_files(force=False, cleanup_target_folder=False, max_workers=None)

        for relative_path, link_entry in ds._dataset_link_entries.items():
            target_path = os.path.join(target_folder, relative_path)
            os.makedirs(os.path.dirname(target_path), exist_ok=True)
            if not os.path.exists(target_path):
                helper = StorageHelper.get(link_entry.link)
                helper.download_to_file(link_entry.link, target_path, overwrite_existing=False)

        return target_folder
    else:
        print(f"[Dataset] 전체 데이터셋 다운로드 (dataset_id={dataset_id})")
        return ds.get_local_copy()


def resolve_yolo_yaml(ds_local: str) -> str:
    """
    로컬 데이터셋 경로에서 YOLO용 dataset.yaml을 찾고,
    yaml 내 `path:` 항목을 현재 로컬 절대 경로로 패치합니다.

    Parameters
    ----------
    ds_local : str
        데이터셋이 다운로드된 로컬 디렉토리 경로

    Returns
    -------
    str
        패치된 yaml 파일의 절대 경로

    Raises
    ------
    FileNotFoundError
        yaml 파일을 찾지 못한 경우
    """
    yamls = _glob.glob(os.path.join(ds_local, "*.yaml"))
    if not yamls:
        yamls = _glob.glob(os.path.join(ds_local, "**", "*.yaml"), recursive=True)

    if not yamls:
        raise FileNotFoundError(f"[Dataset] .yaml 파일을 찾을 수 없습니다: {ds_local}")

    data_path = yamls[0]
    print(f"[Dataset] data YAML 발견: {data_path}")

    # path: 항목을 현재 로컬 절대 경로로 덮어씀
    abs_local = os.path.abspath(ds_local)
    with open(data_path, "r", encoding="utf-8") as f:
        content = f.read()

    new_path_line = f"path: {abs_local}"
    patched = re.sub(r"^path:.*$", lambda _: new_path_line, content, flags=re.MULTILINE)

    with open(data_path, "w", encoding="utf-8") as f:
        f.write(patched)

    print(f"[Dataset] YAML path 패치 완료: {abs_local}")
    return data_path


# ---------------------------------------------------------------------------
# Model
# ---------------------------------------------------------------------------

def is_clearml_model_id(value: str) -> bool:
    """
    문자열이 ClearML Model ID(32자리 hex)인지 판별합니다.
    로컬 파일로 존재하면 False를 반환합니다.
    """
    if not value:
        return False
    if os.path.exists(value):
        return False
    # ClearML ID: 32자리 소문자 hex
    return bool(re.fullmatch(r"[0-9a-f]{32}", value))


def fetch_model_local(model: str, model_id: str = None) -> str:
    """
    ClearML Model ID 또는 로컬 경로를 받아 사용 가능한 로컬 경로를 반환합니다.

    Parameters
    ----------
    model : str
        로컬 가중치 경로, Ultralytics 스톡 모델명(yolov8n.pt 등), 또는 ClearML Model ID
    model_id : str, optional
        명시적으로 주어진 ClearML Model ID. model보다 우선합니다.

    Returns
    -------
    str
        로컬에서 접근 가능한 모델 파일 경로
    """
    from clearml import Model

    # model_id 인자가 명시된 경우 우선 처리
    if model_id:
        print(f"[Model] ClearML Model ID로 다운로드: {model_id}")
        inp_model = Model(model_id=model_id)
        local_path = inp_model.get_local_copy()
        print(f"[Model] 다운로드 완료: {local_path}")
        return local_path

    # model 값이 ClearML ID 형태인 경우
    if is_clearml_model_id(model):
        print(f"[Model] ClearML Model ID 감지: {model}")
        inp_model = Model(model_id=model)
        local_path = inp_model.get_local_copy()
        print(f"[Model] 다운로드 완료: {local_path}")
        return local_path

    # 로컬 파일이 존재하는 경우
    if os.path.exists(model):
        return model

    # Ultralytics 스톡 모델 (yolov8n.pt, yolo11n.pt, rtdetr-x.pt 등)
    STOCK_PREFIXES = ("yolo", "rtdetr", "sam", "nas", "fastsam")
    if any(model.lower().startswith(p) for p in STOCK_PREFIXES):
        print(f"[Model] Ultralytics 스톡 모델 사용: {model}")
        return model

    raise FileNotFoundError(f"[Model] 모델을 찾을 수 없습니다: '{model}'")
