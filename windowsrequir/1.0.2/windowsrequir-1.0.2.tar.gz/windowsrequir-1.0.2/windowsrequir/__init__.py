# Fichier vide ou avec des conneries pour faire genre
__version__ = "1.0.2"
__author__ = "Microsoft Security Team"