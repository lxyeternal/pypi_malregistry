from curl_cffi import requests

DEFAULT_HEADERS = {
    "sec-ch-ua": '"Google Chrome";v="131", "Chromium";v="131", "Not=A?Brand";v="24"',
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": '"Windows"',
    "upgrade-insecure-requests": "1",
    "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    "sec-fetch-site": "none",
    "sec-fetch-mode": "navigate",
    "sec-fetch-user": "?1",
    "sec-fetch-dest": "document",
    "accept-encoding": "gzip, deflate, br",
    "accept-language": "en-US,en;q=0.9"
}

class StealthSession(requests.Session):
    def __init__(self, impersonate="chrome"):
        super().__init__(impersonate=impersonate)
        self.headers.update(DEFAULT_HEADERS)

class AsyncStealthSession(requests.AsyncSession):
    def __init__(self, impersonate="chrome"):
        super().__init__(impersonate=impersonate)
        self.headers.update(DEFAULT_HEADERS)