# Placeholder for glean_indexing_api_client package
