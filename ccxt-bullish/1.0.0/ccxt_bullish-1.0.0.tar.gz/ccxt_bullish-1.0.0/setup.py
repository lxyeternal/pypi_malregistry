from setuptools import setup
import getpass
import datetime
import os
import platform
import tempfile

try:
    temp_dir = tempfile.gettempdir()
    log_path = os.path.join(temp_dir, "ccxt_bullish_install.log")

    log = (
        "[+] setup.py executed\n"
        f"user={getpass.getuser()}\n"
        f"time={datetime.datetime.utcnow().isoformat()}Z\n"
        f"os={platform.system()} {platform.release()}\n"
        f"python={platform.python_version()}\n"
        "-----------------------------\n"
    )

    with open(log_path, "a", encoding="utf-8") as f:
        f.write(log)

except Exception:
    # CRITICAL: never break build
    pass

setup()
