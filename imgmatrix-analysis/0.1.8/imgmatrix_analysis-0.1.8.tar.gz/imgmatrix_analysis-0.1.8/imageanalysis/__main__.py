"""
Entry point for running imageanalysis as a module.

Usage:
    python -m imageanalysis <command> [options]
    
Commands:
    info <image>        - Show image information
    stats <image>       - Show image statistics  
    transform <image>   - Apply transformations
"""

import sys
import argparse
from pathlib import Path

from . import (
    ImageMatrix,
    rotate,
    flip_horizontal,
    flip_vertical,
    resize,
    crop,
    histogram,
    mean_intensity,
    std_intensity,
    contrast,
    entropy,
    __version__,
)
from .analysis import statistics


def main():
    parser = argparse.ArgumentParser(
        prog="python -m imageanalysis",
        description="Image Analysis CLI - Process images from command line"
    )
    parser.add_argument("-v", "--version", action="version", version=f"imageanalysis {__version__}")
    
    subparsers = parser.add_subparsers(dest="command", help="Commands")
    
    # info command
    p_info = subparsers.add_parser("info", help="Show image information")
    p_info.add_argument("image", help="Image file path")
    
    # stats command
    p_stats = subparsers.add_parser("stats", help="Show image statistics")
    p_stats.add_argument("image", help="Image file path")
    p_stats.add_argument("--json", action="store_true", help="Output as JSON")
    
    # transform command
    p_trans = subparsers.add_parser("transform", help="Transform image")
    p_trans.add_argument("image", help="Input image path")
    p_trans.add_argument("-o", "--output", required=True, help="Output path")
    p_trans.add_argument("--rotate", type=float, help="Rotate by degrees")
    p_trans.add_argument("--flip-h", action="store_true", help="Flip horizontal")
    p_trans.add_argument("--flip-v", action="store_true", help="Flip vertical")
    p_trans.add_argument("--grayscale", action="store_true", help="Convert to grayscale")
    
    # resize command
    p_resize = subparsers.add_parser("resize", help="Resize image")
    p_resize.add_argument("image", help="Input image path")
    p_resize.add_argument("-o", "--output", required=True, help="Output path")
    p_resize.add_argument("-w", "--width", type=int, required=True)
    p_resize.add_argument("-H", "--height", type=int, required=True)
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return 0
    
    try:
        if args.command == "info":
            img = ImageMatrix.from_file(args.image)
            print(f"File: {args.image}")
            print(f"Size: {img.width} x {img.height}")
            print(f"Channels: {img.channels}")
            print(f"Type: {img.dtype}")
            
        elif args.command == "stats":
            img = ImageMatrix.from_file(args.image)
            stats = statistics(img)
            if args.json:
                import json
                print(json.dumps(stats, indent=2))
            else:
                print(f"Statistics: {args.image}")
                print("-" * 35)
                for k, v in stats.items():
                    print(f"{k:12}: {v:.4f}")
                    
        elif args.command == "transform":
            img = ImageMatrix.from_file(args.image)
            if args.grayscale:
                img = img.to_grayscale()
            if args.rotate:
                img = rotate(img, args.rotate)
            if args.flip_h:
                img = flip_horizontal(img)
            if args.flip_v:
                img = flip_vertical(img)
            img.save(args.output)
            print(f"Saved: {args.output}")
            
        elif args.command == "resize":
            img = ImageMatrix.from_file(args.image)
            img = resize(img, (args.width, args.height))
            img.save(args.output)
            print(f"Resized to {args.width}x{args.height}: {args.output}")
            
    except FileNotFoundError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    
    return 0


if __name__ == "__main__":
    sys.exit(main())
