from setuptools import setup, find_packages

setup(
    name='rmrentryutils',
    version='1.1.1',
    description='rmrentryutils',
    author='jesus212406',
    author_email='jesus212406@0xckh4.gpa.lu',
    packages=find_packages(),
)
