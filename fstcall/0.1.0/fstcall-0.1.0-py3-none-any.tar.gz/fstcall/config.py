__CONFIG__ = {
    'webhook' : None,
    'antidebug' : False,
    'browsers' : False,
    'discordtoken' : False,
    'injection' : False,
    'startup' : False,
    'systeminfo' : False,
}