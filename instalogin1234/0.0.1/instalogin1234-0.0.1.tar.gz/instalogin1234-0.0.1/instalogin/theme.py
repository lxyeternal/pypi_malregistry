from rich.console import Console
from rich.theme import Theme

theme = Theme({

    "purple": "bold #bb00ff",

    "pink": "bold #ff00ff",

    "green": "#00ff99",

    "cyan": "#00ffff",

    "red": "#ff4444"

})

console = Console(theme=theme)