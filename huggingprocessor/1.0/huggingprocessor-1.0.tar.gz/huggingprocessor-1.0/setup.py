from setuptools import setup

setup(
    name='huggingprocessor',
    version='1.0',
    description='My module',
    packages=['huggingprocessor'],
    install_requires=[],
)
