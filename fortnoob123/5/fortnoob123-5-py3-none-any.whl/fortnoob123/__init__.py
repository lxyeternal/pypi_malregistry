from .fortnoob123_file import *
from colorama import *
initialize()