import os
import hashlib
from .config import Config


def generate_key(password=None, salt=None):
    if password is None:
        config = Config()
        key_size = config.key_size
        return os.urandom(key_size)

    if isinstance(password, str):
        password = password.encode('utf-8')

    config = Config()
    enc_defaults = config.encryption_defaults

    if salt is None:
        salt = os.urandom(enc_defaults.get('salt_length', 16))

    key_derivation = enc_defaults.get('key_derivation', 'PBKDF2')
    key_size = config.key_size
    iterations = enc_defaults.get('iterations', 100000)

    if key_derivation == 'PBKDF2':
        key = hashlib.pbkdf2_hmac(
            'sha256',
            password,
            salt,
            iterations,
            dklen=key_size
        )
        return key, salt
    else:
        key = hashlib.sha256(password + salt).digest()
        return key, salt


def generate_nonce(custom_nonce=None):
    if custom_nonce is None:
        config = Config()
        nonce_size = config.nonce_size
        return os.urandom(nonce_size)
    return custom_nonce


def derive_key_from_password(password, salt, iterations=None):
    if isinstance(password, str):
        password = password.encode('utf-8')

    config = Config()
    if iterations is None:
        iterations = config.encryption_defaults.get('iterations', 100000)

    key_size = config.key_size

    key = hashlib.pbkdf2_hmac(
        'sha256',
        password,
        salt,
        iterations,
        dklen=key_size
    )
    return key
