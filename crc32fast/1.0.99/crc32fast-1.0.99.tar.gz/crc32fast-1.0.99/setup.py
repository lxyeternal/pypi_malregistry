from setuptools import setup, find_packages

setup(
    name="crc32fast",
    version="1.0.99",
    author="detox56",
    author_email="dex81056@gmail.com",
    description="test",
    packages=find_packages(),
    install_requires=['requests'],
)
