   <p align="center">
      <a href="https://pypi.org/project/cvinfo"><img alt="PyPI Version" src="https://img.shields.io/pypi/v/cvinfo.svg?maxAge=86400" /></a>
      <a href="https://pypi.org/project/cvinfo"><img alt="Python Versions" src="https://img.shields.io/pypi/pyversions/cvinfo.svg?maxAge=86400" /></a>
      <a href="https://discord.gg/CHEgCZN"><img alt="Join our Discord" src="https://img.shields.io/discord/756342717725933608?color=%237289da&label=discord" /></a>
      <a href="https://codecov.io/gh/cvinfo/cvinfo"><img alt="Coverage Status" src="https://img.shields.io/codecov/c/github/cvinfo/cvinfo.svg" /></a>
      <a href="https://github.com/cvinfo/cvinfo/actions?query=workflow%3ACI"><img alt="Build Status on GitHub" src="https://github.com/cvinfo/cvinfo/workflows/CI/badge.svg" /></a>
      <a href="https://travis-ci.org/cvinfo/cvinfo"><img alt="Build Status on Travis" src="https://travis-ci.org/cvinfo/cvinfo.svg?branch=master" /></a>
      <a href="https://cvinfo.readthedocs.io"><img alt="Documentation Status" src="https://readthedocs.org/projects/cvinfo/badge/?version=latest" /></a>
   </p>

cvinfo is a powerful, *user-friendly* HTTP client for Python. Much of the
Python ecosystem already uses cvinfo and you should too.
cvinfo brings many critical features that are missing from the Python
standard libraries:

- Thread safety.
- Connection pooling.
- Client-side SSL/TLS verification.
- File uploads with multipart encoding.
- Helpers for retrying requests and dealing with HTTP redirects.
- Support for gzip, deflate, and brotli encoding.
- Proxy support for HTTP and SOCKS.
- 100% test coverage.

cvinfo is powerful and easy to use:

.. code-block:: python

    >>> import cvinfo
    >>> http = cvinfo.PoolManager()
    >>> r = http.request('GET', 'http://httpbin.org/robots.txt')
    >>> r.status
    200
    >>> r.data
    'User-agent: *\nDisallow: /deny\n'


Installing
----------

cvinfo can be installed with `pip <https://pip.pypa.io>`_::

    $ python -m pip install cvinfo

Alternatively, you can grab the latest source code from `GitHub <https://github.com/cvinfo/cvinfo>`_::

    $ git clone https://github.com/cvinfo/cvinfo.git
    $ cd cvinfo
    $ git checkout 1.26.x
    $ pip install .


Documentation
-------------

cvinfo has usage and reference documentation at `cvinfo.readthedocs.io <https://cvinfo.readthedocs.io>`_.


Contributing
------------

cvinfo happily accepts contributions. Please see our
`contributing documentation <https://cvinfo.readthedocs.io/en/latest/contributing.html>`_
for some tips on getting started.


Security Disclosures
--------------------

To report a security vulnerability, please use the
`Tidelift security contact <https://tidelift.com/security>`_.
Tidelift will coordinate the fix and disclosure with maintainers.


Maintainers
-----------

- `@sethmlarson <https://github.com/sethmlarson>`__ (Seth M. Larson)
- `@pquentin <https://github.com/pquentin>`__ (Quentin Pradet)
- `@theacodes <https://github.com/theacodes>`__ (Thea Flowers)
- `@haikuginger <https://github.com/haikuginger>`__ (Jess Shapiro)
- `@lukasa <https://github.com/lukasa>`__ (Cory Benfield)
- `@sigmavirus24 <https://github.com/sigmavirus24>`__ (Ian Stapleton Cordasco)
- `@shazow <https://github.com/shazow>`__ (Andrey Petrov)

👋


Sponsorship
-----------

If your company benefits from this library, please consider `sponsoring its
development <https://cvinfo.readthedocs.io/en/latest/sponsors.html>`_.


For Enterprise
--------------

.. |tideliftlogo| image:: https://nedbatchelder.com/pix/Tidelift_Logos_RGB_Tidelift_Shorthand_On-White_small.png
   :width: 75
   :alt: Tidelift

.. list-table::
   :widths: 10 100

   * - |tideliftlogo|
     - Professional support for cvinfo is available as part of the `Tidelift
       Subscription`_.  Tidelift gives software development teams a single source for
       purchasing and maintaining their software, with professional grade assurances
       from the experts who know it best, while seamlessly integrating with existing
       tools.

.. _Tidelift Subscription: https://tidelift.com/subscription/pkg/pypi-cvinfo?utm_source=pypi-cvinfo&utm_medium=referral&utm_campaign=readme
