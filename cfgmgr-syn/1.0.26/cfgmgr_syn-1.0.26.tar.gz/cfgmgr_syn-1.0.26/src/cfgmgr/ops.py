"""cfgmgr - Low-level config and sync helpers."""
import json
from pathlib import Path


def read_json_safe(path: Path, default: dict | list | None = None):
    """Read JSON file; return default on parse error."""
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return default if default is not None else {}


def write_json(path: Path, data: dict | list, indent: int = 2) -> None:
    """Write JSON with consistent formatting."""
    path.write_text(json.dumps(data, indent=indent, ensure_ascii=False), encoding="utf-8")


def validate_config_schema(data: dict, required_keys: tuple[str, ...]) -> bool:
    """Validate that config dict has required keys. For env/yml validation."""
    return all(k in data for k in required_keys)


def merge_env_overrides(base: dict, overrides: dict) -> dict:
    """Merge override dict into base. Used for env var precedence."""
    out = dict(base)
    for k, v in overrides.items():
        if v is not None:
            out[k] = v
    return out
