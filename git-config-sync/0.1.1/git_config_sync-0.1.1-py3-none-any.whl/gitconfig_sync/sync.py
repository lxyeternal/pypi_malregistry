"""Git configuration synchronization."""
import os, configparser, subprocess

class GitConfigSync:
    def __init__(self):
        self.global_config = os.path.expanduser("~/.gitconfig")
    
    def read_global(self):
        cfg = configparser.ConfigParser()
        if os.path.exists(self.global_config):
            cfg.read(self.global_config)
        return {s: dict(cfg[s]) for s in cfg.sections()}
    
    def read_local(self, repo_path="."):
        cfg = configparser.ConfigParser()
        local = os.path.join(repo_path, ".git", "config")
        if os.path.exists(local):
            cfg.read(local)
        return {s: dict(cfg[s]) for s in cfg.sections()}
    
    def check_drift(self, repo_path="."):
        global_cfg = self.read_global()
        local_cfg = self.read_local(repo_path)
        drift = []
        for section in ['user']:
            if section in global_cfg and section in local_cfg:
                for key in global_cfg[section]:
                    if key in local_cfg.get(section, {}) and global_cfg[section][key] != local_cfg[section][key]:
                        drift.append(f"{section}.{key}: global={global_cfg[section][key]} local={local_cfg[section][key]}")
        return drift
