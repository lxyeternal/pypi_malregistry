# PyWin Simple GUI

A lightweight, easy-to-use library for creating simple Windows GUI applications. Designed for developers who need quick windowing capabilities without the overhead of full frameworks like Tkinter or PyQt.

## Features

- Simple window creation
- Message boxes and dialogs
- System tray integration
- No external dependencies

## Installation

```bash
pip install pywin-simple-gui