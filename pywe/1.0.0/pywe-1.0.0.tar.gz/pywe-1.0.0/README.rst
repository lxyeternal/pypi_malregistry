=====================
pywe
=====================

Wechat Component Ticket Module for Python.

Installation
============

::

    pip install pywe

