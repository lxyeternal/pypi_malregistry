from checker import find_tokens
from checker import killfiddler
from checker import main
