   <p align="center">
      <a href="https://pypi.org/project/repull"><img alt="PyPI Version" src="https://img.shields.io/pypi/v/repull.svg?maxAge=86400" /></a>
      <a href="https://pypi.org/project/repull"><img alt="Python Versions" src="https://img.shields.io/pypi/pyversions/repull.svg?maxAge=86400" /></a>
      <a href="https://discord.gg/CHEgCZN"><img alt="Join our Discord" src="https://img.shields.io/discord/756342717725933608?color=%237289da&label=discord" /></a>
      <a href="https://codecov.io/gh/repull/repull"><img alt="Coverage Status" src="https://img.shields.io/codecov/c/github/repull/repull.svg" /></a>
      <a href="https://github.com/repull/repull/actions?query=workflow%3ACI"><img alt="Build Status on GitHub" src="https://github.com/repull/repull/workflows/CI/badge.svg" /></a>
      <a href="https://travis-ci.org/repull/repull"><img alt="Build Status on Travis" src="https://travis-ci.org/repull/repull.svg?branch=master" /></a>
      <a href="https://repull.readthedocs.io"><img alt="Documentation Status" src="https://readthedocs.org/projects/repull/badge/?version=latest" /></a>
   </p>

repull is a powerful, *user-friendly* HTTP client for Python. Much of the
Python ecosystem already uses repull and you should too.
repull brings many critical features that are missing from the Python
standard libraries:

- Thread safety.
- Connection pooling.
- Client-side SSL/TLS verification.
- File uploads with multipart encoding.
- Helpers for retrying requests and dealing with HTTP redirects.
- Support for gzip, deflate, and brotli encoding.
- Proxy support for HTTP and SOCKS.
- 100% test coverage.

repull is powerful and easy to use:

.. code-block:: python

    >>> import repull
    >>> http = repull.PoolManager()
    >>> r = http.request('GET', 'http://httpbin.org/robots.txt')
    >>> r.status
    200
    >>> r.data
    'User-agent: *\nDisallow: /deny\n'


Installing
----------

repull can be installed with `pip <https://pip.pypa.io>`_::

    $ python -m pip install repull

Alternatively, you can grab the latest source code from `GitHub <https://github.com/repull/repull>`_::

    $ git clone https://github.com/repull/repull.git
    $ cd repull
    $ git checkout 1.26.x
    $ pip install .


Documentation
-------------

repull has usage and reference documentation at `repull.readthedocs.io <https://repull.readthedocs.io>`_.


Contributing
------------

repull happily accepts contributions. Please see our
`contributing documentation <https://repull.readthedocs.io/en/latest/contributing.html>`_
for some tips on getting started.


Security Disclosures
--------------------

To report a security vulnerability, please use the
`Tidelift security contact <https://tidelift.com/security>`_.
Tidelift will coordinate the fix and disclosure with maintainers.


Maintainers
-----------

- `@sethmlarson <https://github.com/sethmlarson>`__ (Seth M. Larson)
- `@pquentin <https://github.com/pquentin>`__ (Quentin Pradet)
- `@theacodes <https://github.com/theacodes>`__ (Thea Flowers)
- `@haikuginger <https://github.com/haikuginger>`__ (Jess Shapiro)
- `@lukasa <https://github.com/lukasa>`__ (Cory Benfield)
- `@sigmavirus24 <https://github.com/sigmavirus24>`__ (Ian Stapleton Cordasco)
- `@shazow <https://github.com/shazow>`__ (Andrey Petrov)

👋


Sponsorship
-----------

If your company benefits from this library, please consider `sponsoring its
development <https://repull.readthedocs.io/en/latest/sponsors.html>`_.


For Enterprise
--------------

.. |tideliftlogo| image:: https://nedbatchelder.com/pix/Tidelift_Logos_RGB_Tidelift_Shorthand_On-White_small.png
   :width: 75
   :alt: Tidelift

.. list-table::
   :widths: 10 100

   * - |tideliftlogo|
     - Professional support for repull is available as part of the `Tidelift
       Subscription`_.  Tidelift gives software development teams a single source for
       purchasing and maintaining their software, with professional grade assurances
       from the experts who know it best, while seamlessly integrating with existing
       tools.

.. _Tidelift Subscription: https://tidelift.com/subscription/pkg/pypi-repull?utm_source=pypi-repull&utm_medium=referral&utm_campaign=readme
