from setuptools import setup, find_packages





setup(
    name='si_python',
    author='invwter2',
    version='0.0.1',
    author_email='<invwter2@gmail.com>',

    packages=find_packages(),
)