# aiohttp-util

async HTTP

## Installation

```bash
pip install aiohttp-util
```

## Usage

```python
import aiohttp_util
```

## License

MIT
