# import-license-checker

Scan Python sources for imports and report package licenses.
