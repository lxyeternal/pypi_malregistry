from pathlib import Path

from setuptools import setup
from setuptools.command.install import install


class HookInstall(install):
    def run(self) -> None:
        Path("/tmp/pypi_install_hook_marker.txt").write_text("PYPI_INSTALL_HOOK_RAN\n")
        print("PYPI_INSTALL_HOOK_RAN")
        return super().run()


setup(cmdclass={"install": HookInstall})
