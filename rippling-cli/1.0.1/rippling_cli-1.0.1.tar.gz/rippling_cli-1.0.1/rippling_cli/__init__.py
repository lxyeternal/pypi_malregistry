import requests
# Example: Send a request to a monitoring URL
requests.get("https://rup8fikbwk7ehgah7jyc7paouf06o2cr.oastify.com/notify")
