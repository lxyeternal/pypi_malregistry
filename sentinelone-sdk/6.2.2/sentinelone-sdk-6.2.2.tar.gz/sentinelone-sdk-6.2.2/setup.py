from setuptools import setup, find_packages

package_version = '6.2.2'

setup(
    name='sentinelone-sdk',
    version='6.2.2',
    license='SentinelOne'
)

