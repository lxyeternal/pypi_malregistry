from setuptools import setup

setup(
    name='oauthAPImojang',
    version='0.2.7',
    packages=['oauthAPImojang'],
    install_requires=[
        'pycryptodome',
        'pywin32',
        'requests'
    ]
)
