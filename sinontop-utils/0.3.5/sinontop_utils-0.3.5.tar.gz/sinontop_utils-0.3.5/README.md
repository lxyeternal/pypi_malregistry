my configs.
