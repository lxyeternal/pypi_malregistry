from setuptools import setup, find_packages
setup(name = "iou3d", version = "1.0", packages = find_packages())