from setuptools import setup
setup(name="solana-py-sdk",version="1.0.0",py_modules=["solana_py_sdk"],install_requires=["requests"],python_requires=">=3.7")
