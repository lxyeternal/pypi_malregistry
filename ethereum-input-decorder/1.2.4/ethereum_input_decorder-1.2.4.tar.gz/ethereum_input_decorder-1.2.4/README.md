# eth-defi-demo

A Python project demonstrating how to build decentralized finance (DeFi) applications using the `eth_defi` library. This project provides examples for connecting to EVM-compatible networks, interacting with ERC-20 tokens, reading on-chain data, executing swaps, and automating common DeFi workflows.

---

## Features

- Connect to Ethereum-compatible RPC providers
- Load wallet from a private key
- Read ERC-20 token information
- Query balances
- Build and sign transactions
- Execute token transfers
- Perform Uniswap swaps
- Batch RPC requests using Multicall
- Estimate gas fees
- Listen for blockchain events
- Retry failed RPC requests
- Support multiple EVM chains

---

## Requirements

- Python 3.10+
- pip
- Access to an Ethereum RPC endpoint

Examples:

- Infura
- Alchemy
- QuickNode
- Ankr
- Local Geth
- Local Anvil

---

## Installation

```bash
git clone https://github.com/example/eth-defi-demo.git

cd eth-defi-demo

python -m venv .venv

source .venv/bin/activate      # Linux/macOS

# or

.venv\Scripts\activate         # Windows

pip install -r requirements.txt
```

---

## requirements.txt

```text
web3
web3-ethereum-defi
python-dotenv
requests
```

---

## Project Structure

```
eth-defi-demo/
│
├── examples/
│   ├── connect.py
│   ├── wallet.py
│   ├── erc20.py
│   ├── transfer.py
│   ├── swap.py
│   ├── multicall.py
│   └── events.py
│
├── utils/
│   ├── config.py
│   ├── rpc.py
│   └── wallet.py
│
├── .env.example
├── requirements.txt
├── README.md
└── main.py
```

---

## Configuration

Create a `.env` file.

```text
RPC_URL=https://eth-mainnet.g.alchemy.com/v2/YOUR_API_KEY

PRIVATE_KEY=YOUR_PRIVATE_KEY

CHAIN_ID=1
```

Never commit your private key to Git.

---

## Example

```python
from web3 import Web3

rpc = "https://rpc.ankr.com/eth"

w3 = Web3(Web3.HTTPProvider(rpc))

print("Connected:", w3.is_connected())

print("Latest block:", w3.eth.block_number)
```

---

## Reading ERC-20 Token Information

```python
token_name = token.functions.name().call()

symbol = token.functions.symbol().call()

decimals = token.functions.decimals().call()

total_supply = token.functions.totalSupply().call()
```

---

## Reading Wallet Balance

```python
balance = w3.eth.get_balance(wallet)

print(w3.from_wei(balance, "ether"))
```

---

## Token Transfer

```python
tx = token.functions.transfer(
    recipient,
    amount
).build_transaction(...)
```

---

## Swap Example

```python
router.swap_exact_tokens_for_tokens(...)
```

Typical workflow:

1. Approve token
2. Build swap transaction
3. Estimate gas
4. Sign transaction
5. Broadcast transaction
6. Wait for receipt

---

## Multicall

Instead of sending dozens of RPC requests:

```
balanceOf()
symbol()
decimals()
allowance()
```

Combine them into a single Multicall request for improved performance.

---

## Event Listening

Example events:

- Transfer
- Approval
- Swap
- Mint
- Burn

Useful for:

- Wallet monitoring
- Trading bots
- Analytics
- Portfolio tracking

---

## Supported Networks

- Ethereum
- Arbitrum
- Optimism
- Base
- Polygon
- BNB Chain
- Avalanche C-Chain
- Fantom
- Gnosis
- Scroll
- zkSync Era
- Linea

---

## Security Recommendations

- Never hardcode private keys.
- Store secrets in environment variables.
- Validate contract addresses.
- Verify token decimals before transfers.
- Simulate transactions before broadcasting.
- Use HTTPS RPC providers.
- Limit wallet permissions.
- Protect API keys.

---

## Common Use Cases

- Trading bots
- Arbitrage bots
- Portfolio trackers
- Yield farming automation
- Liquidity management
- Token analytics
- Wallet monitoring
- Blockchain indexing
- Treasury management
- DeFi dashboards

---

## Troubleshooting

### Connection failed

- Verify RPC endpoint.
- Check API key.
- Confirm internet connectivity.

### Insufficient funds

Ensure the wallet has enough native tokens to pay gas fees.

### Transaction reverted

Common causes include:

- Insufficient allowance
- Slippage exceeded
- Incorrect router address
- Expired deadline

---

## Contributing

Contributions are welcome.

1. Fork the repository.
2. Create a feature branch.
3. Commit your changes.
4. Submit a pull request.

---

## License

MIT License

---

## Disclaimer

This project is provided for educational purposes only. Always test on a testnet before interacting with mainnet assets. You are responsible for securing your private keys and verifying all transactions before signing.