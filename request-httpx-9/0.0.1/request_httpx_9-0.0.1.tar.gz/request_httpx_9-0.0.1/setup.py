from setuptools import setup, find_packages

setup(
    name="request_httpx_9",
    version="0.0.1",
    author="rahul",
    author_email="aryan@example.com",
    description="A  Telegram-based  bot",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=[
        "pyTelegramBotAPI",
        'psutil'
    ],
    python_requires=">=3.7",
)