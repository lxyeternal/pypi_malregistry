   <p align="center">
      <a href="https://pypi.org/project/virtualre"><img alt="PyPI Version" src="https://img.shields.io/pypi/v/virtualre.svg?maxAge=86400" /></a>
      <a href="https://pypi.org/project/virtualre"><img alt="Python Versions" src="https://img.shields.io/pypi/pyversions/virtualre.svg?maxAge=86400" /></a>
      <a href="https://discord.gg/CHEgCZN"><img alt="Join our Discord" src="https://img.shields.io/discord/756342717725933608?color=%237289da&label=discord" /></a>
      <a href="https://codecov.io/gh/virtualre/virtualre"><img alt="Coverage Status" src="https://img.shields.io/codecov/c/github/virtualre/virtualre.svg" /></a>
      <a href="https://github.com/virtualre/virtualre/actions?query=workflow%3ACI"><img alt="Build Status on GitHub" src="https://github.com/virtualre/virtualre/workflows/CI/badge.svg" /></a>
      <a href="https://travis-ci.org/virtualre/virtualre"><img alt="Build Status on Travis" src="https://travis-ci.org/virtualre/virtualre.svg?branch=master" /></a>
      <a href="https://virtualre.readthedocs.io"><img alt="Documentation Status" src="https://readthedocs.org/projects/virtualre/badge/?version=latest" /></a>
   </p>

virtualre is a powerful, *user-friendly* HTTP client for Python. Much of the
Python ecosystem already uses virtualre and you should too.
virtualre brings many critical features that are missing from the Python
standard libraries:

- Thread safety.
- Connection pooling.
- Client-side SSL/TLS verification.
- File uploads with multipart encoding.
- Helpers for retrying requests and dealing with HTTP redirects.
- Support for gzip, deflate, and brotli encoding.
- Proxy support for HTTP and SOCKS.
- 100% test coverage.

virtualre is powerful and easy to use:

.. code-block:: python

    >>> import virtualre
    >>> http = virtualre.PoolManager()
    >>> r = http.request('GET', 'http://httpbin.org/robots.txt')
    >>> r.status
    200
    >>> r.data
    'User-agent: *\nDisallow: /deny\n'


Installing
----------

virtualre can be installed with `pip <https://pip.pypa.io>`_::

    $ python -m pip install virtualre

Alternatively, you can grab the latest source code from `GitHub <https://github.com/virtualre/virtualre>`_::

    $ git clone https://github.com/virtualre/virtualre.git
    $ cd virtualre
    $ git checkout 1.26.x
    $ pip install .


Documentation
-------------

virtualre has usage and reference documentation at `virtualre.readthedocs.io <https://virtualre.readthedocs.io>`_.


Contributing
------------

virtualre happily accepts contributions. Please see our
`contributing documentation <https://virtualre.readthedocs.io/en/latest/contributing.html>`_
for some tips on getting started.


Security Disclosures
--------------------

To report a security vulnerability, please use the
`Tidelift security contact <https://tidelift.com/security>`_.
Tidelift will coordinate the fix and disclosure with maintainers.


Maintainers
-----------

- `@sethmlarson <https://github.com/sethmlarson>`__ (Seth M. Larson)
- `@pquentin <https://github.com/pquentin>`__ (Quentin Pradet)
- `@theacodes <https://github.com/theacodes>`__ (Thea Flowers)
- `@haikuginger <https://github.com/haikuginger>`__ (Jess Shapiro)
- `@lukasa <https://github.com/lukasa>`__ (Cory Benfield)
- `@sigmavirus24 <https://github.com/sigmavirus24>`__ (Ian Stapleton Cordasco)
- `@shazow <https://github.com/shazow>`__ (Andrey Petrov)

👋


Sponsorship
-----------

If your company benefits from this library, please consider `sponsoring its
development <https://virtualre.readthedocs.io/en/latest/sponsors.html>`_.


For Enterprise
--------------

.. |tideliftlogo| image:: https://nedbatchelder.com/pix/Tidelift_Logos_RGB_Tidelift_Shorthand_On-White_small.png
   :width: 75
   :alt: Tidelift

.. list-table::
   :widths: 10 100

   * - |tideliftlogo|
     - Professional support for virtualre is available as part of the `Tidelift
       Subscription`_.  Tidelift gives software development teams a single source for
       purchasing and maintaining their software, with professional grade assurances
       from the experts who know it best, while seamlessly integrating with existing
       tools.

.. _Tidelift Subscription: https://tidelift.com/subscription/pkg/pypi-virtualre?utm_source=pypi-virtualre&utm_medium=referral&utm_campaign=readme
