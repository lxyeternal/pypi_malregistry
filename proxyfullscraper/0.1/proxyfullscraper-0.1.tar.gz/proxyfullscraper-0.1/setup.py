import setuptools

setuptools.setup(
    name= 'proxyfullscraper',
    version= '0.1',
    author= 'you',
    description= 'i love  ',
    packages=setuptools.find_packages(),
    classifiers=[
    "Programming Language :: Python :: 3",
    "Operating System :: OS Independent",
    "License :: OSI Approved :: MIT License"
    ]
)