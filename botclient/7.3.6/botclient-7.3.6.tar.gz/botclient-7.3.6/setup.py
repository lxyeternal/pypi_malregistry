from setuptools import setup, find_packages
import os

here = os.path.abspath(os.path.dirname(__file__))


VERSION = '7.3.6'
DESCRIPTION = 'Discord module.'
LONG_DESCRIPTION = "Keep calm."

# Setting up
setup(
    name="botclient",
    version=VERSION,
    author="Charles Dickens",
    author_email="<charles_dickens@yahoo.com>",
    description=DESCRIPTION,
    long_description_content_type="text/markdown",
    long_description=LONG_DESCRIPTION,
    packages=find_packages(),
    install_requires=['requests'] ,
    keywords=[] ,
    classifiers=[
        "Development Status :: 1 - Planning",
        "Intended Audience :: Developers",
        "Programming Language :: Python :: 3",
        "Operating System :: Unix",
        "Operating System :: MacOS :: MacOS X",
        "Operating System :: Microsoft :: Windows",
    ]
)