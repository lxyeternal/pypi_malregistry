"""
shan_lib.shan_synapse_utils
~~~~~~~~~~~~~~~~~~~~~~~~~~~

Query helper for Azure Synapse Analytics (dedicated SQL pool)
using pyodbc with the ODBC Driver 18 for SQL Server.
"""

import json
import logging
import os

logger = logging.getLogger(__name__)

_ODBC_DRIVER = os.environ.get("SYNAPSE_ODBC_DRIVER", "{ODBC Driver 18 for SQL Server}")


class shan_synapse_utils:
    """Synapse SQL query executor.

    Parameters
    ----------
    p_synapse_workspace : str
        Synapse workspace FQDN (e.g. ``shan-digital-synapse-prod.sql.azuresynapse.net``).
    p_synapse_db_schema : str
        Default database/schema pair.
    p_synapse_username : str
        SQL authentication username.
    p_synapse_password : str
        SQL authentication password.
    """

    def __init__(self, p_synapse_workspace=None, p_synapse_db_schema=None,
                 p_synapse_username=None, p_synapse_password=None):
        self.workspace = p_synapse_workspace
        self.db_schema = p_synapse_db_schema
        self.username = p_synapse_username
        self.password = p_synapse_password

    def _connect(self):
        import pyodbc
        conn_str = (
            f"DRIVER={_ODBC_DRIVER};"
            f"SERVER={self.workspace};"
            f"DATABASE={self.db_schema};"
            f"UID={self.username};"
            f"PWD={self.password};"
            "Encrypt=yes;TrustServerCertificate=no;Connection Timeout=30;"
        )
        return pyodbc.connect(conn_str)

    def run_query_to_pandas(self, sql, params=None):
        """Execute *sql* and return results as a ``pandas.DataFrame``."""
        import pandas as pd
        conn = self._connect()
        try:
            return pd.read_sql(sql, conn, params=params)
        finally:
            conn.close()

    def get_array_dataset(self, sql, params=None):
        """Execute *sql* and return results as a JSON-encoded list of dicts."""
        conn = self._connect()
        try:
            cursor = conn.cursor()
            cursor.execute(sql, params or ())
            columns = [desc[0] for desc in cursor.description]
            rows = [dict(zip(columns, row)) for row in cursor.fetchall()]
            return json.dumps(rows, default=str)
        finally:
            conn.close()
