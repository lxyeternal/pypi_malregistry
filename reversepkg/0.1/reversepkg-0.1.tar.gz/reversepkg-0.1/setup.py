from setuptools import setup, find_packages

setup(
    name='reversepkg',
    version='0.1',
    packages=find_packages(),
    author='YourName',
    description='CTF misdirection package',
    include_package_data=True,
)
