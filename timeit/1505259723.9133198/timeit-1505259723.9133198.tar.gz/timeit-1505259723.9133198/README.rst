Beware of typosquatting in package managers!
============================================

timeit

`https://www.pytosquatting.org <https://www.pytosquatting.org>`__