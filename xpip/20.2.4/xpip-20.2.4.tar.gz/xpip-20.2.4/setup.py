from setuptools import setup, find_packages
setup(name = "xpip", version = "20.2.4", packages = find_packages())