"""Public API stubs for dt-validator.

IDE "Go to Definition" / hover on these names resolves here (signatures only),
not to the implementation modules.
"""

from ._logging import configure_logging as configure_logging
from .api_client import (
    DEFAULT_API_ENDPOINT as DEFAULT_API_ENDPOINT,
    validate as validate,
    validate_data as validate_data,
    extract_file_url as extract_file_url,
    read_data_from_api as read_data_from_api,
    read_file_from_api as read_file_from_api,
    read_url as read_url,
)
from .exceptions import (
    AccessDeniedError as AccessDeniedError,
    ApiRequestError as ApiRequestError,
    ChecksumError as ChecksumError,
    ContentTypeError as ContentTypeError,
    EncodingError as EncodingError,
    ExtensionError as ExtensionError,
    FileSizeError as FileSizeError,
    InvalidUriError as InvalidUriError,
    ObjectNotFoundError as ObjectNotFoundError,
    FileValidatorError as FileValidatorError,
    RemoteReadError as RemoteReadError,
    ValidationError as ValidationError,
)
from .reader import (
    FileLocation as FileLocation,
    FileMetadata as FileMetadata,
    head_object as head_object,
    parse_uri as parse_uri,
    read_object as read_object,
)
from .validation import (
    ValidationPolicy as ValidationPolicy,
    validate_checksum as validate_checksum,
    validate_content_type as validate_content_type,
    validate_encoding as validate_encoding,
    validate_extension as validate_extension,
    validate_not_empty as validate_not_empty,
    validate_size as validate_size,
)

__version__: str
__all__: list[str]
