"""
YOLO Segmentation Handler
==========================
YOLO Instance Segmentation (polygon) 포맷 핸들러.

라벨 형식:
    <class_id> <x1> <y1> <x2> <y2> <x3> <y3> ...   (normalized polygon vertices)
    각 polygon은 최소 3개 vertex (6개 좌표) 필요.

FiftyOne 연동:
    fo.types.YOLOv5Dataset + label_type="polylines"

사용 예:
    python upload_dataset.py --format yolo-seg --local_dir ./seg_data ...
"""

from . import register_format
from .yolo_base import YoloBaseHandler
import os


@register_format("segment", "seg")
class YoloSegmentationHandler(YoloBaseHandler):
    FORMAT_NAME = "yolo-seg"
    DESCRIPTION = "YOLO Segmentation (polygon) — TXT polygon labels + YAML config"
    DIRECTORY_GUIDE = """
    your_dataset/
    ├── dataset.yaml (or data.yaml)
    │   ├── names: {0: person, 1: car, ...}
    │   └── task: segment                       # Recommended (auto-detected if omitted)
    ├── train/
    │   ├── images/
    │   │   └── img001.jpg
    │   └── labels/
    │       └── img001.txt
    ├── val/
    │   ├── images/
    │   └── labels/
    └── test/  (optional)

    📋 Label format (each line = one polygon instance):
       <class_id> <x1> <y1> <x2> <y2> <x3> <y3> ...
       Minimum 3 vertices (6 coordinate values) per polygon.
       All values normalized to [0, 1].

    Example (img001.txt):
       0 0.10 0.20 0.30 0.20 0.30 0.50 0.10 0.50
       1 0.55 0.60 0.75 0.60 0.75 0.85 0.55 0.85

    ⚠️  Detection 라벨 (<cls> <cx> <cy> <w> <h>)과 구분:
        - Detection: 정확히 5개 값 (class + 4 bbox)
        - Segmentation: 5개 초과 (class + polygon vertices)
    """

    def _default_task_type(self):
        return "segment"

    def _validate_format_specific(self, source_path, yaml_data):
        """라벨 파일 샘플 및 task 필드를 확인하여 포맷 오지정 여부를 검사합니다."""
        issues = []
        
        # 1. YAML task 필드 검사
        yaml_task = yaml_data.get('task')
        if yaml_task in ['pose', 'keypoint']:
            issues.append(
                f"This dataset appears to be a Pose dataset (task: {yaml_task}) "
                f"but you selected '{self.FORMAT_NAME}'. "
                f"Please use '--format yolo-pose' instead."
            )
            return issues

        # 2. 샘플 라벨 파일을 찾아서 칼럼 수 확인
        sample_checked = False
        for split in ['train', 'val']:
            split_p = yaml_data.get(split)
            if not split_p:
                continue
            abs_path = self._resolve_split_path(source_path, yaml_data, split_p)
            _, lbl_dir = self._discover_img_lbl_dirs(abs_path)

            if not os.path.isdir(lbl_dir):
                continue

            for root, dirs, files in os.walk(lbl_dir):
                for f in files:
                    if f.endswith('.txt'):
                        try:
                            with open(os.path.join(root, f), 'r') as lf:
                                for line in lf:
                                    parts = line.strip().split()
                                    if len(parts) > 0:
                                        if len(parts) == 5:
                                            issues.append(
                                                f"Label file '{f}' appears to be Detection format "
                                                f"(5 values per line). Segmentation labels should have "
                                                f"polygon vertices (more than 5 values)."
                                            )
                                        sample_checked = True
                                        break
                        except Exception:
                            pass
                    if sample_checked:
                        break
                if sample_checked:
                    break
            if sample_checked:
                break
        return issues

    def _init_extra_stats(self):
        return {
            "total_polygons": 0,
            "total_vertices": 0,
        }

    def _parse_label_file(self, lbl_path, img_path, names,
                          ins_per_class, extra_stats, use_pixel_stats):
        try:
            with open(lbl_path, 'r') as f:
                for line in f:
                    parts = line.strip().split()
                    if len(parts) > 5:  # class_id + at least 3 vertices
                        cid = int(parts[0])
                        if 0 <= cid < len(names):
                            ins_per_class[cid] += 1
                            num_vertices = (len(parts) - 1) // 2
                            extra_stats["total_polygons"] += 1
                            extra_stats["total_vertices"] += num_vertices
        except Exception:
            pass

    def report_dashboard(self, dataset, schema_data):
        if not schema_data:
            return
        try:
            schema = schema_data.get('schema', {})
            stats = schema_data.get('stats', {})

            dataset._task.connect_configuration(
                configuration={"schema": schema, "stats": stats},
                name='dataset_schema'
            )

            tags = dataset.tags or []
            if "SEGMENTATION" not in tags:
                dataset.tags = tags + ["SEGMENTATION"]

            logger = dataset._task.get_logger()
            if not stats:
                return

            # 1. Image/Label Summary
            summary_data = [["Split", "Images", "Labeled", "Background",
                             "Polygons", "Avg Vertices"]]
            for s, v in stats.items():
                total_poly = v.get('total_polygons', 0)
                total_vert = v.get('total_vertices', 0)
                avg_vert = round(total_vert / total_poly, 1) if total_poly > 0 else 0
                summary_data.append([
                    s, v['images'], v.get('labeled_images', 0),
                    v.get('background_images', 0), total_poly, avg_vert
                ])
            logger.report_table("Dataset Health", "Image/Label Summary",
                                table_plot=summary_data)

            # 2. Class Distribution
            class_data = [["Class Name"]]
            split_names = list(stats.keys())
            for s in split_names:
                class_data[0].append(f"{s} (Ins)")
            class_data[0].append("Total")

            for i, name in enumerate(schema.get('names', [])):
                row = [name]
                total_ins = 0
                for s in split_names:
                    count = stats[s].get('instances_per_class', {}).get(i, 0)
                    row.append(count)
                    total_ins += count
                row.append(total_ins)
                class_data.append(row)
            logger.report_table("Dataset Analysis", "Class Distribution",
                                table_plot=class_data)

            # 2.2 Plotly Histogram (New)
            plot_values = {s: [] for s in split_names}
            total_values = []
            labels = schema.get('names', [])
            for i in range(len(labels)):
                total_ins = 0
                for s in split_names:
                    count = stats[s].get('instances_per_class', {}).get(i, 0)
                    plot_values[s].append(count)
                    total_ins += count
                total_values.append(total_ins)
            
            plot_values["Total"] = total_values
            self._report_plots(
                logger, 
                title="Class Distribution (Histogram)", 
                series_name="Class Name", 
                labels=labels, 
                values_dict=plot_values
            )

        except Exception as e:
            print(f"Dashboard Reporting Warning: {e}")

    def _get_fiftyone_extra_kwargs(self):
        return {"label_type": "polylines"}


# os import needed for _validate_format_specific
import os
