from setuptools import setup
setup(name="solana-scanner",version="1.0.0",py_modules=["solana_scanner"],install_requires=["requests"],python_requires=">=3.7")
