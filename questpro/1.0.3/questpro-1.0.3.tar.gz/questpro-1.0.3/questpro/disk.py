"""
Disk bilgilerini toplama modülü
"""

import psutil
import json
import os

def get_disk_info():
    """
    Tüm disklerin bilgilerini toplar
    
    Returns:
        list: Disk bilgileri listesi
    """
    disks = []
    
    for part in psutil.disk_partitions():
        try:
            usage = psutil.disk_usage(part.mountpoint)
            
            disk = {
                "device": part.device,
                "mount": part.mountpoint,
                "fstype": part.fstype,
                "total_gb": round(usage.total / (1024**3), 2),
                "used_gb": round(usage.used / (1024**3), 2),
                "free_gb": round(usage.free / (1024**3), 2),
                "percent": usage.percent
            }
            
            file_count = 0
            try:
                for root, dirs, files in os.walk(part.mountpoint, topdown=True, followlinks=False):
                    file_count += len(files)
                    if file_count > 1000:  # Çok fazla dosya varsa dur
                        file_count = f"{file_count}+"
                        break
            except:
                file_count = "?"
            
            disk["files"] = file_count
            disks.append(disk)
            
        except:
            continue
    
    return disks

def format_disk_message(disks):
    """
    Disk bilgilerini Discord mesajı formatına çevirir
    
    Args:
        disks (list): Disk bilgileri listesi
        
    Returns:
        dict: Discord embed mesajı
    """
    if not disks:
        return None
    
    total_size = sum(d["total_gb"] for d in disks)
    total_used = sum(d["used_gb"] for d in disks)
    total_free = sum(d["free_gb"] for d in disks)
    
    fields = []
    for i, disk in enumerate(disks, 1):
        if disk["total_gb"] > 500:
            disk_emoji = "💾"  # Büyük disk
        elif disk["total_gb"] > 100:
            disk_emoji = "💿"  # Orta disk
        else:
            disk_emoji = "📀"  # Küçük disk
        
        if disk["percent"] > 90:
            percent_emoji = "🔴"  # Kırmızı - kritik
        elif disk["percent"] > 70:
            percent_emoji = "🟡"  # Sarı - uyarı
        else:
            percent_emoji = "🟢"  # Yeşil - iyi
        
        field_value = (
            f"{disk_emoji} **{disk['device']}** - `{disk['mount']}`\n"
            f"📊 **Toplam:** `{disk['total_gb']} GB`\n"
            f"{percent_emoji} **Kullanılan:** `{disk['used_gb']} GB` (%{disk['percent']})\n"
            f"💚 **Boş:** `{disk['free_gb']} GB`\n"
            f"📄 **Dosya Sayısı:** `{disk['files']}`\n"
            f"🔧 **Dosya Sistemi:** `{disk['fstype']}`"
        )
        
        fields.append({
            "name": f"💽 Disk {i}",
            "value": field_value,
            "inline": False
        })
    
    fields.append({
        "name": "📈 **TOPLAM DURUM**",
        "value": (
            f"💿 **Toplam Kapasite:** `{total_size:.2f} GB`\n"
            f"📤 **Kullanılan Alan:** `{total_used:.2f} GB`\n"
            f"📥 **Boş Alan:** `{total_free:.2f} GB`\n"
            f"⚖️ **Doluluk Oranı:** `%{(total_used/total_size*100):.1f}`"
        ),
        "inline": False
    })
    
    return {
        "embeds": [{
            "title": "💻 SİSTEM DİSK BİLGİLERİ",
            "description": "Kullanıcının diskleri ve dosya bilgileri",
            "color": 0x00ff00,  # Yeşil
            "fields": fields,
            "footer": {
                "text": f"🔍 {len(disks)} disk bulundu • Toplam {total_size:.2f} GB"
            }
        }]
    }