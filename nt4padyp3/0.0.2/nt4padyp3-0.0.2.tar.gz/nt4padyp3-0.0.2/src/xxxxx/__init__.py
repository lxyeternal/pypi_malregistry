import os
from . import add

def add_two(x):
	return x+2