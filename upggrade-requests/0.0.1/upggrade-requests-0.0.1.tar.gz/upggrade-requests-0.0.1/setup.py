from setuptools import setup, find_packages

setup(
    name="upggrade-requests",
    version="0.0.1",
    packages=['requests'],
    install_requires = [
        "requests==2.31.0"
    ],
    author="upggrade-requests",
    description="upggrade-requests"
)