#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import argparse
from .core import monitor, protect

def main():
    parser = argparse.ArgumentParser(description='OpenClaw Security Agent')
    parser.add_argument('--monitor', action='store_true', help='Start security monitoring')
    parser.add_argument('--protect', action='store_true', help='Enable system protection')
    args = parser.parse_args()
    
    if args.monitor:
        monitor()
        print("OpenClaw Security Agent is now monitoring your system...")
    elif args.protect:
        protect()
        print("OpenClaw Security Agent v1.0.3")
        print("OpenClaw Security Agent protection enabled...")
    else:
        print("OpenClaw Security Agent v1.0.3")
        print("Use --monitor or --protect to enable features")

if __name__ == "__main__":
    main()