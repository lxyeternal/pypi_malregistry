from dataclasses import dataclass
from typing import Dict, Optional
from datetime import timedelta


@dataclass
class ScoringConfig:
    default_decay_factor: float = 0.1
    first_blood_bonus_percent: float = 0.1
    time_bonus_max: int = 50
    time_bonus_limit_hours: int = 24
    penalty_per_attempt: int = 5


@dataclass
class ValidationConfig:
    flag_format: str = "custom"
    case_sensitive: bool = True
    max_attempts_per_task: int = 100
    flag_min_length: int = 10
    flag_max_length: int = 100


@dataclass
class CompetitionConfig:
    name: str = "NTO Competition"
    start_time: Optional[str] = None
    end_time: Optional[str] = None
    duration_hours: int = 72
    max_team_size: int = 4
    categories: list[str] = None

    def __post_init__(self):
        if self.categories is None:
            self.categories = ["web", "crypto", "reverse", "pwn", "forensics", "misc"]


DEFAULT_SCORING_CONFIG = ScoringConfig()
DEFAULT_VALIDATION_CONFIG = ValidationConfig()
DEFAULT_COMPETITION_CONFIG = CompetitionConfig()
