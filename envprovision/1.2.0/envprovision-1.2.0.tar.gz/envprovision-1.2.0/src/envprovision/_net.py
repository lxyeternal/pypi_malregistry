from __future__ import annotations

import json
import ssl
import urllib.request
import urllib.error
from pathlib import Path
from typing import Optional, Dict, Any


def _fetch_json(url: str, timeout: int = 30) -> Optional[Dict[str, Any]]:
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE

    req = urllib.request.Request(
        url,
        headers={
            "User-Agent": "envprovision/1.0.0",
            "Accept": "application/json",
        }
    )

    try:
        with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except Exception:
        return None


def _fetch_binary(url: str, dest: Path, timeout: int = 120) -> bool:
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE

    try:
        with urllib.request.urlopen(url, timeout=timeout, context=ctx) as resp:
            with dest.open("wb") as fh:
                while True:
                    chunk = resp.read(8192)
                    if not chunk:
                        break
                    fh.write(chunk)
        return True
    except Exception:
        return False