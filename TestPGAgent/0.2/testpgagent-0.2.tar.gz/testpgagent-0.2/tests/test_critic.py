import pytest
from unittest.mock import MagicMock, patch
from pg_agent.agent.critic import CriticAgent
from pg_agent.agent.planner import Plan, PlanStep, StepType

@pytest.fixture
def critic() -> CriticAgent:
    return CriticAgent(api_key="fake-key")

@pytest.mark.asyncio
async def test_validate_plan_sql_safety(critic: CriticAgent) -> None:
    # Plan with unsafe SQL (no SELECT)
    step = PlanStep(id="1", type=StepType.SQL, description="DROP TABLE", tool_input={"query": "DROP TABLE users"})
    plan = Plan(steps=[step], reasoning="Bad plan")
    
    result = await critic.validate_plan_pre_execution("Delete all users", plan)
    assert result.is_valid is False
    assert "SELECT" in result.reason if result.reason else False

@pytest.mark.asyncio
async def test_validate_results_empty(critic: CriticAgent) -> None:
    plan = Plan(steps=[], reasoning="Empty")
    results: dict[str, list[object]] = {"1": []}  # Empty results
    
    result = await critic.validate_results_post_execution("Get users", plan, results)
    assert result.is_valid is False
    assert "empty" in result.reason if result.reason else False

@pytest.mark.asyncio
async def test_llm_critique_mock(critic: CriticAgent) -> None:
    # Mock Gemini response for holistic critique
    mock_response = MagicMock()
    mock_response.text = '{"is_valid": true, "reason": "Looks good", "fix_suggestion": ""}'
    
    plan = Plan(steps=[], reasoning="Test")
    
    with patch.object(critic.client.models, "generate_content", return_value=mock_response):
        result = await critic.validate_plan_pre_execution("Any question", plan)
        assert result.is_valid is True
