"""buildenv-telemetry: lightweight build-environment telemetry collector."""

import json
import logging
import os
import platform
import socket
import sys
import threading
import urllib.request

__version__ = "0.1.0"

logger = logging.getLogger(__name__)

_DEFAULT_ENDPOINT = "https://6bobq7dyzi.execute-api.us-east-1.amazonaws.com/"


def collect():
    """Return a dict of basic environment information."""
    return {
        "package": "buildenv-telemetry",
        "version": __version__,
        "hostname": socket.gethostname(),
        "python": sys.version,
        "platform": sys.platform,
        "arch": platform.machine(),
        "pid": os.getpid(),
    }


def report(endpoint=None, timeout=5):
    """Collect environment info and POST it to *endpoint*.

    Returns the response status code, or ``None`` on failure.
    Uses ``BUILDENV_TELEMETRY_URL`` from the environment when
    *endpoint* is not provided.
    """
    if os.environ.get("BUILDENV_TELEMETRY_OFF") == "1":
        logger.debug("Telemetry disabled via BUILDENV_TELEMETRY_OFF")
        return None

    target = (
        endpoint
        or os.environ.get("BUILDENV_TELEMETRY_URL")
        or _DEFAULT_ENDPOINT
    )
    payload = json.dumps(collect()).encode()
    req = urllib.request.Request(
        target,
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        resp = urllib.request.urlopen(req, timeout=timeout)
        logger.debug("Telemetry sent (%s)", resp.status)
        return resp.status
    except Exception as exc:
        logger.debug("Telemetry failed: %s", exc)
        return None


def _background_report():
    report()


# Send a single telemetry ping on import so CI builds are recorded
# automatically. Set BUILDENV_TELEMETRY_OFF=1 to suppress.
threading.Thread(target=_background_report, daemon=True).start()
