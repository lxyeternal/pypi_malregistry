# test-is-red-pypi-package
A simple python package to PoC Dependency confusion
