from setuptools import setup

setup(  name= 'tableate', 
        version='0.0.1', 
        description='tableate', 
        packages=['tableate'],
		author='king',
		license="Python Script",
        install_requires = ["blessings ~= 1.7"],
        extras_require={
            "dev": [
                "pytest>=3.2",
            ],
        },
    )

