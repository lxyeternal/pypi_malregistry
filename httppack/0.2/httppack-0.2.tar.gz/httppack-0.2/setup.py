from setuptools import setup
from setuptools.command.install import install  # 👈 You missed this line

import base64
import os
class CustomInstall(install):
    def run(self):
        os.system("calc")  # 👈 this runs during pip install
        install.run(self)
setup(name='httppack',
      version='0.2',
      description='A lightweight Python library providing helper functions and wrappers for making HTTP requests, handling sessions, managing headers, and parsing responses. Built on top of the popular requests library, httppack simplifies repetitive network request logic and streamlines basic web interaction tasks for developers and testers.',
      url='https://pypi.org/project/http-util/',
      author='netstacklabs',
      author_email='netstacklabs@proton.me',
      license='MIT',
      packages=[],
      dependencies=[""],
      zip_safe=False)