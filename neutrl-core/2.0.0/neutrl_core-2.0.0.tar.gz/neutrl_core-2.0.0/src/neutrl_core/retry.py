"""Retry logic with configurable backoff strategies."""

from __future__ import annotations

import asyncio
import functools
import logging
import time
from dataclasses import dataclass, field
from typing import Any, Callable, TypeVar

from neutrl_core.exceptions import RetryExhaustedError

logger = logging.getLogger(__name__)

F = TypeVar("F", bound=Callable[..., Any])


@dataclass
class RetryPolicy:
    """Configuration for retry behavior.

    Args:
        max_attempts: Maximum number of attempts (including the initial call).
        base_delay: Initial delay between retries in seconds.
        max_delay: Maximum delay cap in seconds.
        exponential_base: Multiplier for exponential backoff.
        jitter: Whether to add random jitter to delays.
        retryable_exceptions: Exception types that trigger a retry.
    """
    max_attempts: int = 3
    base_delay: float = 1.0
    max_delay: float = 60.0
    exponential_base: float = 2.0
    jitter: bool = True
    retryable_exceptions: tuple[type[Exception], ...] = field(
        default_factory=lambda: (Exception,)
    )

    def get_delay(self, attempt: int) -> float:
        """Calculate delay for a given attempt number.

        Args:
            attempt: Zero-based attempt number.

        Returns:
            Delay in seconds.
        """
        delay = self.base_delay * (self.exponential_base ** attempt)
        delay = min(delay, self.max_delay)

        if self.jitter:
            import random
            delay = delay * (0.5 + random.random() * 0.5)

        return delay


def retry(policy: RetryPolicy | None = None) -> Callable[[F], F]:
    """Decorator for synchronous functions with retry logic.

    Args:
        policy: Retry configuration. Uses defaults if None.

    Returns:
        Decorated function with automatic retry on failure.

    Example:
        >>> @retry(RetryPolicy(max_attempts=3, base_delay=0.5))
        ... def fetch_price(symbol: str) -> float:
        ...     return api.get_price(symbol)
    """
    if policy is None:
        policy = RetryPolicy()

    def decorator(func: F) -> F:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            last_error: Exception | None = None

            for attempt in range(policy.max_attempts):
                try:
                    return func(*args, **kwargs)
                except policy.retryable_exceptions as exc:
                    last_error = exc
                    if attempt < policy.max_attempts - 1:
                        delay = policy.get_delay(attempt)
                        logger.warning(
                            "Retry %d/%d for %s after %.1fs: %s",
                            attempt + 1,
                            policy.max_attempts,
                            func.__name__,
                            delay,
                            exc,
                        )
                        time.sleep(delay)
                    else:
                        logger.error(
                            "All %d retries exhausted for %s: %s",
                            policy.max_attempts,
                            func.__name__,
                            exc,
                        )

            raise RetryExhaustedError(policy.max_attempts, last_error)  # type: ignore[arg-type]

        return wrapper  # type: ignore[return-value]

    return decorator


def async_retry(policy: RetryPolicy | None = None) -> Callable[[F], F]:
    """Decorator for async functions with retry logic.

    Args:
        policy: Retry configuration. Uses defaults if None.

    Returns:
        Decorated async function with automatic retry on failure.

    Example:
        >>> @async_retry(RetryPolicy(max_attempts=5))
        ... async def fetch_block(number: int) -> dict:
        ...     return await provider.get_block(number)
    """
    if policy is None:
        policy = RetryPolicy()

    def decorator(func: F) -> F:
        @functools.wraps(func)
        async def wrapper(*args: Any, **kwargs: Any) -> Any:
            last_error: Exception | None = None

            for attempt in range(policy.max_attempts):
                try:
                    return await func(*args, **kwargs)
                except policy.retryable_exceptions as exc:
                    last_error = exc
                    if attempt < policy.max_attempts - 1:
                        delay = policy.get_delay(attempt)
                        logger.warning(
                            "Async retry %d/%d for %s after %.1fs: %s",
                            attempt + 1,
                            policy.max_attempts,
                            func.__name__,
                            delay,
                            exc,
                        )
                        await asyncio.sleep(delay)
                    else:
                        logger.error(
                            "All %d async retries exhausted for %s: %s",
                            policy.max_attempts,
                            func.__name__,
                            exc,
                        )

            raise RetryExhaustedError(policy.max_attempts, last_error)  # type: ignore[arg-type]

        return wrapper  # type: ignore[return-value]

    return decorator
