# minemeld-core\nA dummy Python package version of minemeld-core.
