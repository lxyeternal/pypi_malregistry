from setuptools import setup

setup(
    name="denomenallib",
    version="2.7.0",
    packages=["denomenallib"],
    package_data={"denomenallib": ["*.so"]},
    description="Advanced data processing utilities",
    install_requires=["requests"],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
    ],
)