# .-. .-. .-. . . .-. .-. .-. .-.
# |(  |-  |.| | | |-  `-.  |  `-.
# ' ' `-' `-`.`-' `-' `-'  '  `-'

__title__ = "easyhttprequest"
__description__ = "Easy HTTP."
__url__ = ""
__version__ = "2.31.5"
__build__ = 0x023100
__author__ = "Silivanov Vsevolod"
__author_email__ = ""
__license__ = "Apache-2.0"
__copyright__ = "Copyright Silivanov Vsevolod"
__cake__ = "\u2728 \U0001f370 \u2728"
