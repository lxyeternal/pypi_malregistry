# bt-signal-utils
Backtesting signal generation utilities.
