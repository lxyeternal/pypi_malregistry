# builderknower2/module.py

def hello_world():
    return "Hello, world!"
