"""
Network utilities for the gcli remote access tool.
Provides HTTP methods, DNS lookup, port scanning, traceroute, and speed test.
Uses only stdlib (urllib, socket, subprocess) for cross-platform compatibility.
"""
import io
import sys
import time
import socket
import logging
import subprocess
import urllib.request
import urllib.error
import urllib.parse
from typing import Any, Dict, List, Optional

logger = logging.getLogger("gcli.netutils")

MAX_BODY_BYTES = 1 * 1024 * 1024  # 1 MB


class NetUtils:
    """Cross-platform network utilities for gcli."""

    # ------------------------------------------------------------------
    # HTTP
    # ------------------------------------------------------------------

    def http_get(self, url: str, timeout: int = 10) -> dict:
        """Perform an HTTP GET request.

        Returns ``{"ok": True, "status": int, "headers": dict,
        "body": str, "size": int}`` on success.
        """
        try:
            req = urllib.request.Request(url, method="GET")
            req.add_header(
                "User-Agent",
                "Mozilla/5.0 (compatible; gcli/1.0)",
            )
            resp = urllib.request.urlopen(req, timeout=timeout)
            status = resp.getcode()
            headers = dict(resp.headers)
            raw = resp.read(MAX_BODY_BYTES + 1)
            truncated = len(raw) > MAX_BODY_BYTES
            body = raw[:MAX_BODY_BYTES].decode("utf-8", errors="replace")
            return {
                "ok": True,
                "status": status,
                "headers": headers,
                "body": body,
                "size": len(raw) if not truncated else len(raw) - 1,
                "truncated": truncated,
            }
        except urllib.error.HTTPError as exc:
            body_text = ""
            try:
                body_text = exc.read(MAX_BODY_BYTES).decode("utf-8", errors="replace")
            except Exception:
                pass
            return {
                "ok": True,
                "status": exc.code,
                "headers": dict(exc.headers) if exc.headers else {},
                "body": body_text,
                "size": len(body_text.encode("utf-8")),
            }
        except Exception as exc:
            logger.error("http_get failed for %s: %s", url, exc)
            return {"ok": False, "error": str(exc)}

    def http_head(self, url: str, timeout: int = 10) -> dict:
        """Perform an HTTP HEAD request.

        Returns ``{"ok": True, "status": int, "headers": dict,
        "content_type": str, "content_length": int}`` on success.
        """
        try:
            req = urllib.request.Request(url, method="HEAD")
            req.add_header(
                "User-Agent",
                "Mozilla/5.0 (compatible; gcli/1.0)",
            )
            resp = urllib.request.urlopen(req, timeout=timeout)
            status = resp.getcode()
            headers = dict(resp.headers)
            return {
                "ok": True,
                "status": status,
                "headers": headers,
                "content_type": headers.get("Content-Type", ""),
                "content_length": int(headers.get("Content-Length", 0)),
            }
        except urllib.error.HTTPError as exc:
            return {
                "ok": True,
                "status": exc.code,
                "headers": dict(exc.headers) if exc.headers else {},
                "content_type": (exc.headers or {}).get("Content-Type", ""),
                "content_length": int((exc.headers or {}).get("Content-Length", 0)),
            }
        except Exception as exc:
            logger.error("http_head failed for %s: %s", url, exc)
            return {"ok": False, "error": str(exc)}

    # ------------------------------------------------------------------
    # DNS
    # ------------------------------------------------------------------

    def dns_lookup(self, hostname: str) -> dict:
        """Resolve a hostname to IP addresses.

        Returns ``{"ok": True, "addresses": [...], "aliases": [...]}``.
        """
        try:
            results = socket.getaddrinfo(hostname, None)
            addresses = sorted({r[4][0] for r in results})
            aliases = sorted({name for r in results for name in (r[3],)})
            return {
                "ok": True,
                "addresses": addresses,
                "aliases": aliases,
            }
        except Exception as exc:
            logger.error("dns_lookup failed for %s: %s", hostname, exc)
            return {"ok": False, "error": str(exc)}

    # ------------------------------------------------------------------
    # Port check / scan
    # ------------------------------------------------------------------

    def port_check(self, host: str, port: int, timeout: float = 3) -> dict:
        """Check if a single TCP port is open.

        Returns ``{"ok": True, "open": bool, "response_time_ms": float}``.
        """
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(timeout)
            t0 = time.monotonic()
            result = sock.connect_ex((host, port))
            elapsed_ms = round((time.monotonic() - t0) * 1000, 2)
            sock.close()
            return {
                "ok": True,
                "open": result == 0,
                "response_time_ms": elapsed_ms,
            }
        except Exception as exc:
            logger.error("port_check failed for %s:%s: %s", host, port, exc)
            return {"ok": False, "error": str(exc)}

    def ports_scan(self, host: str, ports: List[int], timeout: float = 1) -> dict:
        """Scan multiple TCP ports on a host.

        Returns ``{"ok": True, "open_ports": [...], "closed_ports": [...]}``.
        """
        open_ports: List[int] = []
        closed_ports: List[int] = []
        try:
            for port in ports:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(timeout)
                result = sock.connect_ex((host, port))
                sock.close()
                if result == 0:
                    open_ports.append(port)
                else:
                    closed_ports.append(port)
            return {
                "ok": True,
                "open_ports": open_ports,
                "closed_ports": closed_ports,
            }
        except Exception as exc:
            logger.error("ports_scan failed for %s: %s", host, exc)
            return {"ok": False, "error": str(exc)}

    # ------------------------------------------------------------------
    # Traceroute
    # ------------------------------------------------------------------

    def traceroute(self, host: str, max_hops: int = 15) -> dict:
        """Run a simplified traceroute.

        Uses ``tracert`` on Windows and ``traceroute`` on Linux/macOS.
        Returns ``{"ok": True, "hops": [{"ttl": int, "host": str,
        "time_ms": float}, ...]}``.
        """
        try:
            if sys.platform == "win32":
                cmd = ["tracert", "-d", "-w", "1000", "-h", str(max_hops), host]
            else:
                cmd = ["traceroute", "-n", "-m", str(max_hops), "-w", "2", host]

            proc = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=max_hops * 10,
            )
            output = proc.stdout
            hops = self._parse_traceroute(output)
            return {"ok": True, "hops": hops}
        except FileNotFoundError:
            return {
                "ok": False,
                "error": "traceroute command not found on this system",
            }
        except subprocess.TimeoutExpired:
            return {"ok": False, "error": "traceroute timed out"}
        except Exception as exc:
            logger.error("traceroute failed for %s: %s", host, exc)
            return {"ok": False, "error": str(exc)}

    @staticmethod
    def _parse_traceroute(output: str) -> List[Dict[str, Any]]:
        """Parse traceroute / tracert output into a list of hop dicts."""
        hops: List[Dict[str, Any]] = []
        for line in output.splitlines():
            line = line.strip()
            if not line:
                continue
            # Skip header lines
            if line.lower().startswith("traceroute") or line.lower().startswith("determining"):
                continue
            if line.lower().startswith("over a maximum"):
                continue
            if line.lower().startswith("tracing route"):
                continue
            if line.lower().startswith("1"):
                pass  # fall through

            # Try to extract hop number from start
            parts = line.split(None, 1)
            if not parts or not parts[0].isdigit():
                continue

            ttl = int(parts[0])
            rest = parts[1] if len(parts) > 1 else ""

            hop_host = "*"
            hop_ms = 0.0

            if rest.strip() == "*":
                hop_host = "*"
            else:
                # Could be "192.168.1.1  5 ms  6 ms  4 ms" (traceroute)
                # or "1 ms  <1 ms  1 ms  192.168.1.1" (tracert)
                tokens = rest.split()
                # Check if first token looks like an IP/hostname
                if tokens and not tokens[0].replace(".", "").isdigit() and not tokens[0].startswith("<"):
                    hop_host = tokens[0]
                    # Find ms values
                    ms_vals = []
                    for tok in tokens[1:]:
                        if tok == "ms":
                            continue
                        clean = tok.replace("<", "").replace(",", "")
                        try:
                            ms_vals.append(float(clean))
                        except ValueError:
                            if "." in tok or tok.replace(".", "").isdigit():
                                hop_host = tok
                else:
                    # tracert style: times first, host last
                    ms_vals = []
                    for tok in tokens:
                        clean = tok.replace("<", "").replace(",", "")
                        try:
                            ms_vals.append(float(clean))
                        except ValueError:
                            if tok != "ms":
                                hop_host = tok
                    if tokens:
                        # Re-read ms values more carefully
                        ms_vals = []
                        host_found = False
                        for tok in reversed(tokens):
                            if host_found:
                                break
                            clean = tok.replace("<", "").replace(",", "")
                            try:
                                ms_vals.insert(0, float(clean))
                            except ValueError:
                                hop_host = tok
                                host_found = True

                if ms_vals:
                    hop_ms = round(sum(ms_vals) / len(ms_vals), 2)

            hops.append({"ttl": ttl, "host": hop_host, "time_ms": hop_ms})

        return hops

    # ------------------------------------------------------------------
    # Speed test (simple)
    # ------------------------------------------------------------------

    def speed_test(self, url: str = "http://speedtest.tele2.net/1MB.zip") -> dict:
        """Download a file and measure throughput.

        Returns ``{"ok": True, "download_bytes": int,
        "download_time_ms": float, "download_speed_mbps": float}``.
        """
        try:
            req = urllib.request.Request(url)
            req.add_header(
                "User-Agent",
                "Mozilla/5.0 (compatible; gcli/1.0)",
            )
            t0 = time.monotonic()
            resp = urllib.request.urlopen(req, timeout=30)
            data = resp.read()
            elapsed_s = time.monotonic() - t0
            elapsed_ms = round(elapsed_s * 1000, 2)
            bytes_downloaded = len(data)
            speed_mbps = round((bytes_downloaded * 8) / (elapsed_s * 1_000_000), 2) if elapsed_s > 0 else 0.0
            return {
                "ok": True,
                "download_bytes": bytes_downloaded,
                "download_time_ms": elapsed_ms,
                "download_speed_mbps": speed_mbps,
            }
        except Exception as exc:
            logger.error("speed_test failed: %s", exc)
            return {"ok": False, "error": str(exc)}


# ---------------------------------------------------------------------------
# Dispatch
# ---------------------------------------------------------------------------

def dispatch(payload: dict) -> dict:
    """Route a network command payload to the appropriate NetUtils method.

    >>> dispatch({"type": "dns_lookup", "hostname": "localhost"})["ok"]
    True
    """
    cmd_type = payload.get("type", "")
    nu = NetUtils()

    if cmd_type == "http_get":
        return nu.http_get(
            url=payload.get("url", ""),
            timeout=payload.get("timeout", 10),
        )
    elif cmd_type == "http_head":
        return nu.http_head(
            url=payload.get("url", ""),
            timeout=payload.get("timeout", 10),
        )
    elif cmd_type == "dns_lookup":
        hostname = payload.get("hostname", "")
        if not hostname:
            return {"ok": False, "error": "Missing 'hostname' field"}
        return nu.dns_lookup(hostname)
    elif cmd_type == "port_check":
        host = payload.get("host", "")
        port = payload.get("port")
        if not host or port is None:
            return {"ok": False, "error": "Missing 'host' or 'port' field"}
        return nu.port_check(
            host=host,
            port=int(port),
            timeout=payload.get("timeout", 3),
        )
    elif cmd_type == "traceroute":
        host = payload.get("host", "")
        if not host:
            return {"ok": False, "error": "Missing 'host' field"}
        return nu.traceroute(
            host=host,
            max_hops=payload.get("max_hops", 15),
        )
    elif cmd_type == "speed_test":
        return nu.speed_test(url=payload.get("url", ""))
    elif cmd_type == "ports_scan":
        host = payload.get("host", "")
        ports = payload.get("ports", [])
        if not host or not ports:
            return {"ok": False, "error": "Missing 'host' or 'ports' field"}
        return nu.ports_scan(
            host=host,
            ports=ports,
            timeout=payload.get("timeout", 1),
        )
    else:
        return {"ok": False, "error": f"Unknown netutils command type: {cmd_type!r}"}


# ---------------------------------------------------------------------------
# Self-test
# ---------------------------------------------------------------------------

def test_netutils() -> None:
    """Exercise every capability and print results."""
    nu = NetUtils()
    passed = 0
    failed = 0

    def check(label: str, result: dict) -> None:
        nonlocal passed, failed
        if result.get("ok"):
            passed += 1
            print(f"  PASS  {label}")
        else:
            failed += 1
            print(f"  FAIL  {label} -> {result.get('error', 'unknown')}")

    print("=" * 60)
    print("gcli.netutils self-test")
    print("=" * 60)

    # dns_lookup
    print("\n--- dns_lookup (localhost) ---")
    r = dispatch({"type": "dns_lookup", "hostname": "localhost"})
    check("dns_lookup localhost", r)
    if r["ok"]:
        print(f"  addresses: {r['addresses']}")

    # port_check
    print("\n--- port_check (localhost:80) ---")
    r = dispatch({"type": "port_check", "host": "localhost", "port": 80, "timeout": 2})
    check("port_check localhost:80", r)
    if r["ok"]:
        print(f"  open: {r['open']}  time: {r['response_time_ms']}ms")

    # ports_scan
    print("\n--- ports_scan (localhost) ---")
    r = dispatch({
        "type": "ports_scan",
        "host": "localhost",
        "ports": [22, 80, 443, 3306, 8080],
        "timeout": 1,
    })
    check("ports_scan localhost", r)
    if r["ok"]:
        print(f"  open: {r['open_ports']}  closed: {r['closed_ports']}")

    # http_head
    print("\n--- http_head (example.com) ---")
    r = dispatch({"type": "http_head", "url": "http://example.com", "timeout": 10})
    check("http_head example.com", r)
    if r["ok"]:
        print(f"  status: {r['status']}  content_type: {r['content_type']}")

    # http_get
    print("\n--- http_get (example.com) ---")
    r = dispatch({"type": "http_get", "url": "http://example.com", "timeout": 10})
    check("http_get example.com", r)
    if r["ok"]:
        print(f"  status: {r['status']}  size: {r['size']}")

    # traceroute
    print("\n--- traceroute (localhost) ---")
    r = dispatch({"type": "traceroute", "host": "localhost", "max_hops": 5})
    check("traceroute localhost", r)
    if r["ok"]:
        print(f"  hops: {len(r['hops'])}")

    # speed_test (may fail in restricted networks)
    print("\n--- speed_test ---")
    r = dispatch({"type": "speed_test"})
    check("speed_test", r)
    if r["ok"]:
        print(f"  {r['download_bytes']} bytes in {r['download_time_ms']}ms = {r['download_speed_mbps']} Mbps")

    # dispatch unknown type
    print("\n--- dispatch unknown type ---")
    r = dispatch({"type": "bogus"})
    assert not r["ok"], f"Expected failure for bogus type: {r}"
    check("dispatch bogus type", r)

    print("\n" + "=" * 60)
    print(f"Results: {passed} passed, {failed} failed")
    print("=" * 60)


if __name__ == "__main__":
    test_netutils()
