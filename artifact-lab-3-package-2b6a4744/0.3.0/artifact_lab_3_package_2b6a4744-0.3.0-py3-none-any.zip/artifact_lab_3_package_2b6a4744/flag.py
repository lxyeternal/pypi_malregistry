# artifact_lab_3_package_2b6a4744/flag.py
def hello():
    print("Hello, World!")

