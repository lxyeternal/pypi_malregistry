"""shared primitives"""
__version__ = "0.0.1"

_VERSION = "0.0.1"

class DdeCommon:
    def __init__(self, **kwargs):
        self._opts = kwargs
        self._ready = False

    def init(self):
        self._ready = True
        return self

    @property
    def version(self):
        return _VERSION

    def configure(self, **overrides):
        self._opts.update(overrides)
        return self
