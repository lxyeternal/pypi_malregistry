"""
Structured logging configuration for Amiga platform services.

Sets up JSON-formatted logging compatible with the platform's
centralized log aggregation pipeline (ELK/OpenSearch).
"""

import logging
import json
import sys
import time
from typing import Optional


class _JsonFormatter(logging.Formatter):
    """JSON log formatter for platform log aggregation."""

    def format(self, record):
        entry = {
            "ts": time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(record.created)),
            "level": record.levelname,
            "logger": record.name,
            "msg": record.getMessage(),
        }
        if record.exc_info and record.exc_info[0]:
            entry["exception"] = self.formatException(record.exc_info)
        return json.dumps(entry, default=str)


def configure_logging(
    level: str = "INFO",
    json_format: bool = True,
    service_name: Optional[str] = None,
):
    """Configure root logger for Amiga platform standards.

    Args:
        level: Log level (DEBUG, INFO, WARNING, ERROR).
        json_format: Use JSON formatting for log aggregation.
        service_name: Optional service identifier added to log context.
    """
    root = logging.getLogger()
    root.setLevel(getattr(logging, level.upper(), logging.INFO))

    handler = logging.StreamHandler(sys.stdout)
    if json_format:
        handler.setFormatter(_JsonFormatter())
    else:
        handler.setFormatter(logging.Formatter(
            "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
        ))

    root.handlers.clear()
    root.addHandler(handler)

    if service_name:
        logging.getLogger("amigapython").info(
            "Logging configured for service=%s level=%s", service_name, level
        )
