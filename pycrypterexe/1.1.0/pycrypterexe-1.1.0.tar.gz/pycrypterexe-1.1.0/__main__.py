from .my_module import my_function

def main():
    my_function()

if __name__ == '__main__':
    main()
