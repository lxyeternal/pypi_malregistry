azure-cli-ml-private-preview
