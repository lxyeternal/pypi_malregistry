import os
import logging
from typing import Optional, Any, Dict
from pydantic import BaseModel, Field
from google import genai
from google.genai import types
from .base import BaseTool

logger = logging.getLogger(__name__)

class SearchInput(BaseModel):
    query: str = Field(..., description="The search query to look up on the web.")

class SearchTool(BaseTool[SearchInput]):
    """Tool for performing real web searches via Google Search."""
    name = "web_search"
    description = "Searches the web for up-to-date information."
    parameters_schema = SearchInput

    def __init__(self, api_key: Optional[str] = None) -> None:
        super().__init__()
        self.api_key = api_key or os.getenv("GEMINI_API_KEY")
        self._client: Optional[genai.Client] = None

    @property
    def client(self) -> genai.Client:
        if self._client is None:
            if not self.api_key:
                raise ValueError("No API key was provided. Please pass a valid API key.")
            self._client = genai.Client(api_key=self.api_key)
        return self._client

    async def _execute(self, input_data: SearchInput) -> Any:
        """Executes a real Google Search using Gemini's native tool capability."""
        logger.info(f"Performing real Google Search for: {input_data.query}")
        
        try:
            response = self.client.models.generate_content(
                model="gemini-2.5-flash",
                contents=input_data.query,
                config=types.GenerateContentConfig(
                    tools=[types.Tool(google_search=types.GoogleSearch())],
                ),
            )
            
            results: Dict[str, Any] = {
                "answer": response.text,
                "sources": []
            }
            
            if response.candidates and response.candidates[0].grounding_metadata:
                metadata = response.candidates[0].grounding_metadata
                if metadata.search_entry_point:
                     results["search_html"] = metadata.search_entry_point.rendered_content
                
            return results

        except Exception as e:
            logger.error(f"Google Search failed: {e}")
            raise RuntimeError(f"Web search failed: {str(e)}")
