# kube-health-tools

Lightweight Kubernetes node health diagnostics and connectivity checker.

## Install

```bash
pip install kube-health-tools
```

## Usage

```bash
kube-health --config config.yaml
python3 -m kube_health
```

## Features

- Node connectivity verification
- API server health checks
- Network path diagnostics
- Configurable thresholds
