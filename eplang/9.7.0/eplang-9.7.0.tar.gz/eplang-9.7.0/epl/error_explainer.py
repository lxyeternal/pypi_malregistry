"""
EPL Error Explainer v2.0 — Enterprise-Grade Diagnostics

Provides Rust/Elm-level error explanations with:
  - 55+ offline pattern matchers (zero API calls needed)
  - Context window: shows surrounding source lines with pointer arrows
  - "Did you mean?" fuzzy matching for variables, functions, AND keywords
  - Auto-fix suggestions with corrected code
  - Error code documentation links
  - Optional AI enhancement via --ai-errors flag

Usage (internal):
    from epl.error_explainer import explain, format_explanation
    exp = explain(error, source=source_code, ai=False)
    print(format_explanation(exp))
"""

import difflib
import logging
import re
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

_log = logging.getLogger(__name__)


# ─── Structured Result ───────────────────────────────────


@dataclass
class ErrorExplanation:
    """Structured error explanation produced by the explainer."""

    error_type: str  # e.g. "NameError"
    error_code: str  # e.g. "E0500"
    message: str  # Original error message
    line: Optional[int]  # Line number where the error occurred
    source_line: str  # The actual source code at that line

    # Pattern-based analysis
    what_went_wrong: str  # Plain English description of the problem
    how_to_fix: str  # Concrete fix suggestion
    corrected_code: str  # Suggested corrected source line (may be empty)

    # Optional AI analysis
    ai_explanation: str = ''  # AI-generated deep explanation (empty if AI disabled)

    # Metadata
    category: str = ''  # "syntax", "runtime", "type", "name", "io", "index"
    confidence: float = 1.0  # How confident the pattern match is (0.0-1.0)

    # v2.0: Enterprise-grade fields
    context_lines: List[Tuple[int, str]] = field(default_factory=list)  # (line_no, content)
    docs_link: str = ''  # e.g. "https://epl-lang.org/errors/E0400"
    did_you_mean: str = ''  # Fuzzy keyword/token suggestion


# ─── EPL Stdlib Functions (for "did you mean?" on functions) ──

_COMMON_STDLIB_FUNCTIONS = [
    'length',
    'to_text',
    'to_integer',
    'to_decimal',
    'to_number',
    'uppercase',
    'lowercase',
    'trim',
    'split',
    'join',
    'replace',
    'contains',
    'starts_with',
    'ends_with',
    'index_of',
    'sorted',
    'reversed',
    'range',
    'type_of',
    'absolute',
    'round',
    'round_number',
    'floor',
    'ceil',
    'sqrt',
    'square_root',
    'power',
    'max',
    'min',
    'maximum',
    'minimum',
    'random',
    'random_number',
    'random_integer',
    'sum',
    'keys',
    'values',
    'items',
    'has_key',
    'get',
    'push',
    'pop',
    'remove',
    'remove_at',
    'insert',
    'format',
    'char_code',
    'from_char_code',
    'now',
    'today',
    'sleep',
    'year',
    'month',
    'day',
    'uuid',
    'uuid4',
    'base64_encode',
    'base64_decode',
    'regex_test',
    'regex_match',
    'regex_find_all',
    'regex_replace',
    'json_parse',
    'json_stringify',
    'http_get',
    'http_post',
    'url_encode',
    'url_decode',
    'print_error',
    'exit_code',
    'platform',
    'args',
    'env_get',
    'is_number',
    'is_string',
    'is_list',
    'is_null',
    'map',
    'filter',
    'enumerate',
    'zip',
    'sin',
    'cos',
    'tan',
    'asin',
    'acos',
    'atan',
    'atan2',
    'log',
    'sign',
    'clamp',
    'lerp',
    'pi',
    'euler',
    'degrees',
    'radians',
    'is_finite',
    'is_nan',
    'zip_lists',
    'enumerate_list',
    'file_read',
    'file_write',
    'file_append',
    'file_exists',
    'open',
    'query',
    'execute',
    'create_table',
]


# ─── Python/JS → EPL Keyword Map ─────────────────────────

_FOREIGN_KEYWORD_MAP = {
    # Python keywords → EPL equivalents
    'def': 'Function <name> Takes <params> ... End',
    'print': 'Say / Display / Show / Print (capitalized)',
    'elif': 'Otherwise If',
    'else': 'Otherwise',
    'while': 'While <condition> ... End',
    'for': 'For Each / For...from...to / Repeat N times',
    'return': 'Return <value>',
    'class': 'Class <Name> ... End',
    'import': 'Import "module"',
    'true': 'True / Yes',
    'false': 'False / No',
    'none': 'Nothing',
    'null': 'Nothing',
    'try': 'Try ... Catch error ... End',
    'except': 'Catch <error>',
    'raise': 'Throw <message>',
    'pass': '(EPL does not need pass — just leave the block empty or add a Note)',
    'assert': 'Assert <expression>',
    'lambda': 'lambda <params> -> <expression>',
    'with': '(EPL uses Try/Catch for resource management)',
    'yield': 'Yields <value>',
    'async': 'Async Function <name> ... End',
    'await': 'Await <expression>',
    # JavaScript keywords → EPL equivalents
    'var': 'Create <name> equal to <value>',
    'let': 'Create <name> equal to <value>',
    'const': 'Constant <name> = <value>',
    'function': 'Function <name> Takes <params> ... End',
    'console': 'Say / Display / Print',
    'if': 'If <condition> Then ... End',
    'switch': 'Match <value> When ... Default ... End',
    'case': 'When <value>',
    'default': 'Default',
    'new': 'New <ClassName>(<args>)',
    'this': 'self (inside a class method)',
    'throw': 'Throw <message>',
    'catch': 'Catch <error>',
    'typeof': 'type_of(<value>)',
    'undefined': 'Nothing',
}


# ─── EPL Keywords (excluded from "did you mean?" candidates) ──

_EPL_KEYWORDS = {
    'create',
    'set',
    'to',
    'equal',
    'say',
    'print',
    'display',
    'show',
    'if',
    'then',
    'otherwise',
    'end',
    'while',
    'repeat',
    'times',
    'for',
    'each',
    'in',
    'from',
    'step',
    'function',
    'define',
    'takes',
    'return',
    'class',
    'extends',
    'implements',
    'new',
    'try',
    'catch',
    'finally',
    'throw',
    'assert',
    'import',
    'use',
    'true',
    'false',
    'yes',
    'no',
    'nothing',
    'and',
    'or',
    'not',
    'match',
    'when',
    'default',
    'break',
    'continue',
    'constant',
    'module',
    'export',
    'interface',
    'abstract',
    'override',
    'static',
    'public',
    'private',
    'protected',
    'async',
    'await',
    'yields',
    'ask',
    'input',
    'read',
    'write',
    'append',
    'file',
}

# ─── EPL Keywords List (for "did you mean?" on keywords) ──

_EPL_KEYWORD_LIST = sorted(_EPL_KEYWORDS)


def _did_you_mean_keyword(token: str) -> str:
    """Fuzzy-match a mistyped token against all EPL keywords.

    Returns the best match or empty string if no close match found.
    Handles common typos like 'Funtion' -> 'Function', 'Whille' -> 'While'.
    """
    token_lower = token.lower()
    if token_lower in _EPL_KEYWORDS:
        return ''  # Exact match — not a typo
    matches = difflib.get_close_matches(token_lower, _EPL_KEYWORD_LIST, n=1, cutoff=0.7)
    return matches[0].capitalize() if matches else ''


# ─── Error Code Documentation Map ────────────────────────

_DOCS_BASE_URL = 'https://epl-lang.org/errors'


def _get_docs_link(error_code: str) -> str:
    """Generate a documentation link for an error code."""
    if not error_code or error_code == 'E0000':
        return ''
    return f'{_DOCS_BASE_URL}/{error_code}'


# ─── Context Window Builder ──────────────────────────────


def _build_context_lines(source_lines, error_line, radius=2):
    """Build a context window of source lines around the error.

    Returns a list of (line_number, line_content) tuples showing
    `radius` lines before and after the error line.
    """
    if not source_lines or not error_line:
        return []
    total = len(source_lines)
    start = max(1, error_line - radius)
    end = min(total, error_line + radius)
    return [(i, source_lines[i - 1]) for i in range(start, end + 1)]


# ─── Pattern Explainer Functions ─────────────────────────


def _explain_undefined_var(match, source_line, source_lines):
    """Generate explanation for undefined variable errors."""
    name = match.group(1)
    all_names = set()
    for line in source_lines:
        for m in re.finditer(r'\b([a-zA-Z_]\w*)\b', line):
            all_names.add(m.group(1))
    candidates = [n for n in all_names if n.lower() not in _EPL_KEYWORDS and n != name]
    similar = difflib.get_close_matches(name, candidates, n=3, cutoff=0.6)
    if similar:
        best = similar[0]
        corrected = source_line.replace(name, best) if source_line else ''
        return (
            f"Variable '{name}' has not been declared. Did you mean '{best}'?",
            f"Replace '{name}' with '{best}', or declare it first with: Create {name} equal to <value>",
            corrected,
        )
    return (
        f"Variable '{name}' has not been declared in this scope.",
        f'Declare it before using it: Create {name} equal to <value>',
        f'Create {name} equal to <value>' if not source_line else '',
    )


def _explain_undefined_func(match, source_line, source_lines):
    """Generate explanation for undefined function errors."""
    name = match.group(1)
    similar = difflib.get_close_matches(name, _COMMON_STDLIB_FUNCTIONS, n=3, cutoff=0.65)
    if similar:
        suggestion_list = ', '.join(similar)
        return (
            f"Function '{name}' does not exist.",
            f'Did you mean: {suggestion_list}?',
            source_line.replace(name, similar[0]) if source_line else '',
        )
    return (
        f"Function '{name}' is not defined. It is not a built-in function and was not declared.",
        f'Define it first:\n      Function {name} Takes <params>\n          ...\n      End',
        '',
    )


def _explain_unexpected_token(match, source_line, source_lines):
    """Generate explanation for unexpected token errors."""
    token = match.group(1)
    lower_token = token.lower()
    # Check for Python/JS foreign keywords
    if lower_token in _FOREIGN_KEYWORD_MAP:
        epl_equiv = _FOREIGN_KEYWORD_MAP[lower_token]
        return (
            f"'{token}' is not valid EPL syntax — it looks like Python or JavaScript.",
            f'EPL equivalent: {epl_equiv}',
            '',
        )
    # Try fuzzy keyword match for typos (e.g. 'Funtion' -> 'Function')
    suggestion = _did_you_mean_keyword(token)
    if suggestion:
        corrected = source_line.replace(token, suggestion) if source_line else ''
        return (
            f"'{token}' is not a recognized keyword. Did you mean '{suggestion}'?",
            f"Replace '{token}' with '{suggestion}'.",
            corrected,
        )
    return (
        f"The parser did not expect '{token}' at this position.",
        'Check for typos, missing keywords, or mismatched block delimiters (End).',
        '',
    )


def _explain_missing_end(match, source_line, source_lines):
    """Generate explanation for missing End block errors."""
    open_blocks = []
    block_starters = [
        (r'^\s*(?:define\s+)?function\s+', 'Function'),
        (r'^\s*if\s+', 'If'),
        (r'^\s*while\s+', 'While'),
        (r'^\s*repeat\s+', 'Repeat'),
        (r'^\s*for\s+each\s+', 'For Each'),
        (r'^\s*for\s+', 'For'),
        (r'^\s*class\s+', 'Class'),
        (r'^\s*try\b', 'Try'),
        (r'^\s*match\s+', 'Match'),
        (r'^\s*async\s+function\s+', 'Async Function'),
        (r'^\s*module\s+', 'Module'),
        (r'^\s*interface\s+', 'Interface'),
    ]
    for i, line in enumerate(source_lines):
        stripped = line.strip().lower()
        if stripped.startswith('#') or stripped.startswith('//') or stripped.startswith('note:'):
            continue
        for pattern, block_type in block_starters:
            if re.match(pattern, stripped):
                open_blocks.append((block_type, i + 1))
                break
        if re.match(r'end\b', stripped):
            if open_blocks:
                open_blocks.pop()
    if open_blocks:
        block_type, block_line = open_blocks[-1]
        return (
            f"The '{block_type}' block starting on line {block_line} was never closed.",
            f"Add 'End' to close the '{block_type}' block.",
            'End',
        )
    return (
        "A block (If, Function, While, Class, Try, etc.) is missing its closing 'End'.",
        "Add 'End' at the end of the unclosed block.",
        'End',
    )


def _explain_type_mismatch(match, source_line, source_lines):
    return (
        'You are trying to combine or compare values of incompatible types (e.g., text and numbers).',
        'Convert types explicitly: to_text(number) or to_integer(text).',
        '',
    )


def _explain_index_out_of_range(match, source_line, source_lines):
    return (
        'You are trying to access a position in a list that does not exist.',
        'Check the list size with length(list) before accessing by index. '
        'Remember: EPL list indices start at 0.',
        '',
    )


def _explain_divide_by_zero(match, source_line, source_lines):
    return (
        'You are dividing a number by zero, which is mathematically undefined.',
        'Add a check before dividing:\n'
        '      If divisor != 0 Then\n'
        '          Create result equal to value / divisor\n'
        '      End',
        '',
    )


def _explain_key_not_found(match, source_line, source_lines):
    return (
        'You are trying to access a key in a Map that does not exist.',
        'Use has_key(map, key) to check before accessing, or use get(map, key, default_value).',
        '',
    )


def _explain_not_callable(match, source_line, source_lines):
    return (
        'You are trying to call something that is not a function — it might be a variable or a value.',
        'Make sure the name refers to a function, not a variable. Check spelling.',
        '',
    )


def _explain_max_recursion(match, source_line, source_lines):
    return (
        'A function is calling itself (or another function that calls it back) too many times without stopping.',
        'Add a base case — a condition where the function returns without calling itself:\n'
        '      Function countdown Takes n\n'
        '          If n <= 0 Then\n'
        '              Say "Done!"\n'
        '              Return\n'
        '          End\n'
        '          Say n\n'
        '          Call countdown(n - 1)\n'
        '      End',
        '',
    )


def _explain_import_error(match, source_line, source_lines):
    return (
        'The module or file you are trying to import could not be found.',
        'Check the path and spelling. Usage: Import "module_name" or Import "path/to/file.epl"',
        '',
    )


def _explain_constant_reassign(match, source_line, source_lines):
    name = match.group(1) if match.lastindex else 'the constant'
    return (
        f"You are trying to change '{name}', but it was declared as a constant.",
        'Constants cannot be changed after creation. Use a regular variable instead:\n'
        f'      Create {name} equal to <value>',
        '',
    )


def _explain_function_not_defined(match, source_line, source_lines):
    name = match.group(1)
    similar = difflib.get_close_matches(name, _COMMON_STDLIB_FUNCTIONS, n=3, cutoff=0.65)
    if similar:
        return (
            f"Function '{name}' has not been defined.",
            f'Did you mean: {", ".join(similar)}?',
            '',
        )
    return (
        f"Function '{name}' is not defined anywhere in your code.",
        f'Define it first:\n      Function {name} Takes <params>\n          ...\n      End',
        '',
    )


def _explain_class_not_found(match, source_line, source_lines):
    name = match.group(1)
    return (
        f"Class '{name}' has not been defined.",
        f'Make sure the class is defined before you try to use it:\n'
        f'      Class {name}\n          ...\n      End',
        '',
    )


def _explain_not_a_class(match, source_line, source_lines):
    name = match.group(1)
    return (
        f"'{name}' exists but it is not a class — you cannot use it as a parent class or instantiate it.",
        f"Check that '{name}' was defined with 'Class {name} ... End', not as a variable or function.",
        '',
    )


def _explain_wrong_arg_count(match, source_line, source_lines):
    func_name = match.group(1) if match.lastindex else 'the function'
    return (
        f"You called '{func_name}' with the wrong number of arguments.",
        'Check the function definition to see how many parameters it expects.',
        '',
    )


def _explain_list_index_type(match, source_line, source_lines):
    return (
        'List indices must be integers, but you provided a different type.',
        'Use to_integer(value) if your index is stored as text or decimal.',
        '',
    )


def _explain_cannot_call(match, source_line, source_lines):
    type_name = match.group(1) if match.lastindex else 'this value'
    return (
        f'You are trying to call {type_name} as if it were a function, but it is not callable.',
        'Make sure the name refers to a defined Function, not a variable.',
        '',
    )


def _explain_for_each_type(match, source_line, source_lines):
    return (
        "'For Each' can only iterate over lists, text, maps, or generators.",
        'Make sure the collection variable is a list, text, or map before iterating.',
        '',
    )


def _explain_cannot_convert(match, source_line, source_lines):
    return (
        'The value could not be converted to the target type.',
        'Make sure the value is in the correct format before converting:\n'
        '      to_integer("42") works, but to_integer("hello") does not.',
        '',
    )


def _explain_property_not_found(match, source_line, source_lines):
    prop = match.group(1) if match.lastindex else 'the property'
    return (
        f"The property '{prop}' does not exist on this object.",
        f"Check the spelling of '{prop}' and make sure the object has this property defined.",
        '',
    )


def _explain_repeat_count(match, source_line, source_lines):
    return (
        'The repeat count must be a positive integer.',
        'Use a whole number: Repeat 5 times ... End',
        '',
    )


def _explain_type_assign_mismatch(match, source_line, source_lines):
    """Explain type assignment mismatch — e.g. assigning decimal to integer variable."""
    value_type = match.group(1) if match.lastindex >= 1 else 'value'
    var_name = match.group(2) if match.lastindex >= 2 else 'the variable'
    var_type = match.group(3) if match.lastindex >= 3 else 'declared type'
    return (
        f"You are trying to assign a {value_type} value to variable '{var_name}' "
        f'which was declared as type {var_type}. Type-checked variables can only '
        f'hold values of their declared type.',
        f'Either:\n'
        f'      1. Convert the value: to_integer(value) or round(value)\n'
        f"      2. Change the variable type to 'decimal': Create {var_name} as Decimal equal to <value>\n"
        f'      3. Remove the type annotation: {var_name} = <value>',
        '',
    )


def _explain_overflow(match, source_line, source_lines):
    return (
        'A numeric calculation produced a result too large to represent.',
        'Check your math for unintended large exponents or infinite loops.',
        '',
    )


def _explain_file_not_found(match, source_line, source_lines):
    path = match.group(1) if match.lastindex else 'the file'
    return (
        f"The file '{path}' could not be found or opened.",
        f'Check that the file path is correct and the file exists:\n'
        f'      If file_exists("{path}") Then\n'
        f'          Create content equal to file_read("{path}")\n'
        f'      End',
        '',
    )


def _explain_method_not_found(match, source_line, source_lines):
    method = match.group(1) if match.lastindex else 'the method'
    return (
        f"Method '{method}' does not exist on this object.",
        'Check the spelling. Common list methods: push(), pop(), map(), filter(), reduce().\n'
        '      Common string methods: split(), trim(), uppercase(), lowercase(), replace().',
        '',
    )


def _explain_missing_then(match, source_line, source_lines):
    return (
        "An 'If' statement is missing its 'Then' keyword.",
        "Add 'Then' after the condition:\n"
        '      If age > 18 Then\n'
        '          Say "Adult"\n'
        '      End',
        '',
    )


def _explain_missing_takes(match, source_line, source_lines):
    return (
        "A Function definition with parameters is missing the 'Takes' keyword.",
        "Add 'Takes' before the parameter list:\n"
        '      Function greet Takes name\n'
        '          Say "Hello, " + name\n'
        '      End',
        '',
    )


def _explain_iterator_exhausted(match, source_line, source_lines):
    return (
        'A generator or iterator has been fully consumed and has no more values.',
        'If you need to iterate again, recreate the generator.',
        '',
    )


def _explain_read_only(match, source_line, source_lines):
    prop = match.group(1) if match.lastindex else 'the property'
    return (
        f"'{prop}' is read-only and cannot be modified.",
        'Use a different variable name, or copy the value into a mutable variable first.',
        '',
    )


# ─── Pattern Registry ────────────────────────────────────

_PATTERNS: List[dict] = [
    # NameError patterns
    {
        'match': r"undefined variable ['\"]?(\w+)['\"]?",
        'category': 'name',
        'explain': _explain_undefined_var,
    },
    {
        'match': r"variable ['\"]?(\w+)['\"]? has not been (?:created|declared|defined)",
        'category': 'name',
        'explain': _explain_undefined_var,
    },
    {
        'match': r"undefined function ['\"]?(\w+)['\"]?",
        'category': 'name',
        'explain': _explain_undefined_func,
    },
    {'match': r'not callable', 'category': 'name', 'explain': _explain_not_callable},
    # ParserError patterns
    {'match': r'expected ["\']?end["\']?', 'category': 'syntax', 'explain': _explain_missing_end},
    {
        'match': r"unexpected token ['\"]?(\w+)['\"]?",
        'category': 'syntax',
        'explain': _explain_unexpected_token,
    },
    # TypeError patterns
    {
        'match': r'cannot (add|subtract|multiply|combine|concatenate).*(?:string|text).*(?:integer|number|float|decimal)',
        'category': 'type',
        'explain': _explain_type_mismatch,
    },
    {'match': r'type mismatch', 'category': 'type', 'explain': _explain_type_mismatch},
    {'match': r'cannot compare', 'category': 'type', 'explain': _explain_type_mismatch},
    # RuntimeError patterns
    {
        'match': r'divide by zero|division by zero',
        'category': 'runtime',
        'explain': _explain_divide_by_zero,
    },
    {
        'match': r'index out of range|index.*bounds',
        'category': 'index',
        'explain': _explain_index_out_of_range,
    },
    {
        'match': r'key not found|key.*does not exist',
        'category': 'runtime',
        'explain': _explain_key_not_found,
    },
    {
        'match': r'maximum recursion|stack overflow',
        'category': 'runtime',
        'explain': _explain_max_recursion,
    },
    # ImportError patterns
    {
        'match': r'cannot find|module not found|import.*failed',
        'category': 'import',
        'explain': _explain_import_error,
    },
    # EPL-native patterns
    {
        'match': r'function ["\']?(\w+)["\']? has not been defined',
        'category': 'name',
        'explain': _explain_function_not_defined,
    },
    {
        'match': r'(?:parent )?class ["\']?(\w+)["\']? not found',
        'category': 'name',
        'explain': _explain_class_not_found,
    },
    {
        'match': r'["\']?(\w+)["\']? is not a class',
        'category': 'type',
        'explain': _explain_not_a_class,
    },
    {
        'match': r'cannot change constant ["\']?(\w+)["\']?',
        'category': 'runtime',
        'explain': _explain_constant_reassign,
    },
    {
        'match': r'(\w+)\(\) takes \d+ argument',
        'category': 'runtime',
        'explain': _explain_wrong_arg_count,
    },
    {
        'match': r'(?:list|text) index must be integer',
        'category': 'type',
        'explain': _explain_list_index_type,
    },
    {'match': r'cannot call (\w+)', 'category': 'type', 'explain': _explain_cannot_call},
    {'match': r'for each requires', 'category': 'type', 'explain': _explain_for_each_type},
    {'match': r'repeat count', 'category': 'type', 'explain': _explain_repeat_count},
    {
        'match': r'cannot convert to (?:integer|decimal)',
        'category': 'runtime',
        'explain': _explain_cannot_convert,
    },
    {
        'match': r'has no property ["\']?(\w+)["\']?',
        'category': 'type',
        'explain': _explain_property_not_found,
    },
    {
        'match': r'cannot (?:add|subtract|negate|slice|index into)',
        'category': 'type',
        'explain': _explain_type_mismatch,
    },
    # Type assignment mismatch — e.g. "Cannot assign decimal value to variable X of type integer"
    {
        'match': r'cannot assign (\w+) value to variable ["\']?(\w+)["\']? of type (\w+)',
        'category': 'type',
        'explain': _explain_type_assign_mismatch,
    },
    {
        'match': r'cannot assign .* to .*type',
        'category': 'type',
        'explain': lambda m, src, lines: (
            'You are assigning a value of the wrong type to a type-checked variable.',
            'Convert the value to the correct type, or remove the type annotation.',
            '',
        ),
    },
    # Numeric overflow
    {
        'match': r'overflow|number too large|result too large',
        'category': 'runtime',
        'explain': _explain_overflow,
    },
    # File I/O errors
    {
        'match': r'(?:file|path) ["\']?([^\'"]+)["\']? (?:not found|does not exist)',
        'category': 'io',
        'explain': _explain_file_not_found,
    },
    {
        'match': r'permission denied|access denied',
        'category': 'io',
        'explain': lambda m, src, lines: (
            'The program does not have permission to access this file or resource.',
            'Check file permissions, or run with appropriate privileges.',
            '',
        ),
    },
    # Method not found on object
    {
        'match': r'(?:method|member) ["\']?(\w+)["\']? (?:not found|does not exist|is not defined)',
        'category': 'name',
        'explain': _explain_method_not_found,
    },
    # Missing Then / Takes keywords
    {
        'match': r'expected ["\']?then["\']?',
        'category': 'syntax',
        'explain': _explain_missing_then,
    },
    {
        'match': r'expected ["\']?takes["\']?',
        'category': 'syntax',
        'explain': _explain_missing_takes,
    },
    # Iterator / Generator exhaustion
    {
        'match': r'generator.*exhaust|iterator.*stop|stopiteration',
        'category': 'runtime',
        'explain': _explain_iterator_exhausted,
    },
    # Read-only property
    {
        'match': r'(?:read.only|cannot (?:set|modify|write)) ["\']?(\w+)["\']?',
        'category': 'runtime',
        'explain': _explain_read_only,
    },
    # Map/Dict key type errors
    {
        'match': r'(?:map|dict) key must be',
        'category': 'type',
        'explain': lambda m, src, lines: (
            'Map keys must be strings, numbers, or booleans — not lists or maps.',
            'Convert the key to a string: to_text(key).',
            '',
        ),
    },
    # Beginner mistakes (foreign language syntax)
    {
        'match': r'unexpected.*print\b',
        'category': 'syntax',
        'explain': lambda m, src, lines: (
            "EPL does not use 'print()' — it uses English keywords for output.",
            'Replace \'print(...)\' with: Say "your message"',
            re.sub(r'print\s*\(\s*', 'Say ', src).rstrip(')') if src else 'Say "Hello"',
        ),
    },
    {
        'match': r'unexpected.*\bdef\b',
        'category': 'syntax',
        'explain': lambda m, src, lines: (
            "EPL does not use 'def' to define functions — it uses English syntax.",
            'Use: Function <name> Takes <params> ... End',
            '',
        ),
    },
    {
        'match': r'unexpected.*\bfor\b',
        'category': 'syntax',
        'explain': lambda m, src, lines: (
            "EPL uses English-style loops instead of C/Python-style 'for'.",
            "Use: 'For Each item In list', 'For i from 1 to 10', or 'Repeat 5 times'",
            '',
        ),
    },
    # JavaScript/TypeScript Bridge errors
    {
        'match': r'node\.js is not installed',
        'category': 'runtime',
        'explain': lambda m, src, lines: (
            'The JavaScript bridge requires Node.js, which is not installed on this system.',
            "Install Node.js from https://nodejs.org/ and ensure 'node' is in your PATH.",
            '',
        ),
    },
    {
        'match': r'cannot load module ["\']?([\w@/.-]+)["\']?',
        'category': 'runtime',
        'explain': lambda m, src, lines: (
            f'The npm package "{m.group(1)}" could not be loaded by Node.js.',
            f'Install it with: epl jsinstall {m.group(1)}',
            '',
        ),
    },
    {
        'match': r'js bridge (?:pipe broken|process terminated)',
        'category': 'runtime',
        'explain': lambda m, src, lines: (
            'The Node.js bridge subprocess crashed or was terminated unexpectedly.',
            'Check your Node.js installation and ensure no other process is interfering. '
            'Try running the program again.',
            '',
        ),
    },
    # ─── More beginner mistakes ───────────────────────────
    # Using = instead of == in conditions
    {
        'match': r'unexpected.*(?:assign|equal).*(?:if|while|condition)',
        'category': 'syntax',
        'explain': lambda m, src, lines: (
            "You may be using '=' (assignment) where you meant '==' (comparison).",
            "In conditions, use '==' to compare:\n"
            '      If score == 100 Then\n'
            '          Say "Perfect!"\n'
            '      End',
            src.replace(' = ', ' == ') if src and ' = ' in src else '',
        ),
    },
    # Missing quotes around strings
    {
        'match': r'unexpected.*identifier.*(?:say|display|show|print)',
        'category': 'syntax',
        'explain': lambda m, src, lines: (
            'You may be missing quotes around a text value.',
            'Wrap text in double quotes:\n      Say "Hello, World!"',
            '',
        ),
    },
    # Using curly braces (C/Java style)
    {
        'match': r'unexpected.*[{}]',
        'category': 'syntax',
        'explain': lambda m, src, lines: (
            "EPL does not use curly braces { } — it uses 'End' to close blocks.",
            "Remove the braces and use 'End' instead:\n"
            '      If condition Then\n'
            '          ...\n'
            '      End',
            '',
        ),
    },
    # Using semicolons
    {
        'match': r'unexpected.*semicolon|unexpected.*[;]',
        'category': 'syntax',
        'explain': lambda m, src, lines: (
            'EPL does not use semicolons — each statement goes on its own line.',
            'Remove the semicolon. Each EPL statement is one line.',
            src.replace(';', '') if src else '',
        ),
    },
    # C++ cout / Java System.out
    {
        'match': r'unexpected.*cout|unexpected.*system',
        'category': 'syntax',
        'explain': lambda m, src, lines: (
            "EPL does not use 'cout' or 'System.out' — it uses English keywords.",
            'Use: Say "your message"  or  Display "your message"',
            '',
        ),
    },
    # Ruby puts
    {
        'match': r'unexpected.*puts',
        'category': 'syntax',
        'explain': lambda m, src, lines: (
            "EPL does not use 'puts' — it uses English keywords for output.",
            'Use: Say "your message"  or  Print "your message"',
            '',
        ),
    },
    # Parentheses around If condition (C-style)
    {
        'match': r'unexpected.*parenthes.*(?:if|while)',
        'category': 'syntax',
        'explain': lambda m, src, lines: (
            'EPL does not require parentheses around conditions.',
            'Remove the parentheses:\n      If age > 18 Then\n          (not: If (age > 18) Then)',
            '',
        ),
    },
    # Wrong string concatenation (using , instead of +)
    {
        'match': r'cannot.*concatenat.*comma|unexpected comma.*(?:say|print|display)',
        'category': 'syntax',
        'explain': lambda m, src, lines: (
            "Use '+' to join text values, not commas.",
            'Concatenate with +:\n      Say "Hello, " + name + "!"',
            '',
        ),
    },
    # Missing 'In' in For Each
    {
        'match': r'expected.*in.*for each|for each.*missing.*in',
        'category': 'syntax',
        'explain': lambda m, src, lines: (
            "'For Each' loops require the 'In' keyword.",
            'Use: For Each item In myList\n         Say item\n     End',
            '',
        ),
    },
    # Missing 'equal to' in Create
    {
        'match': r'expected.*equal.*create|create.*missing.*equal',
        'category': 'syntax',
        'explain': lambda m, src, lines: (
            "'Create' statements need 'equal to' to assign a value.",
            'Use: Create name equal to "EPL"\n     or: Create count equal to 0',
            '',
        ),
    },
    # Wrong boolean values
    {
        'match': r'unexpected.*true|unexpected.*false',
        'category': 'syntax',
        'explain': lambda m, src, lines: (
            'EPL booleans are capitalized: True/False or Yes/No.',
            'Use: True, False, Yes, No\n     (not: true, false)',
            '',
        ),
    },
    # Missing 'to' in range loop
    {
        'match': r'expected.*to.*for.*from|for.*from.*missing.*to',
        'category': 'syntax',
        'explain': lambda m, src, lines: (
            "'For...from' loops require the 'to' keyword.",
            'Use: For i from 1 to 10\n         Say i\n     End',
            '',
        ),
    },
    # Unterminated string
    {
        'match': r'unterminated string|unclosed string|string not closed',
        'category': 'syntax',
        'explain': lambda m, src, lines: (
            'A string literal was opened with a quote but never closed.',
            'Make sure every opening quote has a matching closing quote:\n'
            '      Say "Hello, World!"',
            '',
        ),
    },
    # Unexpected end of input
    {
        'match': r'unexpected end of (?:input|file)|unexpected eof',
        'category': 'syntax',
        'explain': lambda m, src, lines: (
            'The file ended unexpectedly — a block or expression is incomplete.',
            'Check that all blocks have their closing End keyword:\n'
            '      Function greet Takes name\n'
            '          Say "Hello, " + name\n'
            '      End    <-- make sure this is present',
            '',
        ),
    },
]


# ─── Main Entry Point ────────────────────────────────────


def explain(error, source: str = None, ai: bool = False) -> ErrorExplanation:
    """Generate a structured explanation for an EPL error.

    Args:
        error: An EPLError instance (or any exception with .message and .line)
        source: Full source code string (optional — falls back to thread-local context)
        ai: Whether to include AI-generated explanation (requires Ollama or cloud API)

    Returns:
        ErrorExplanation with all analysis results including context window,
        docs link, and keyword suggestions.
    """
    from epl.errors import _get_source_lines

    if source:
        source_lines = source.splitlines()
    else:
        source_lines = _get_source_lines() or []

    error_line = getattr(error, 'line', None)
    source_at_line = ''
    if error_line and source_lines and 0 < error_line <= len(source_lines):
        source_at_line = source_lines[error_line - 1].strip()

    error_msg = getattr(error, 'message', str(error))
    error_type = type(error).__name__
    error_code = error._error_code() if hasattr(error, '_error_code') else 'E0000'

    what_went_wrong = 'An error occurred in your EPL code.'
    how_to_fix = 'Review the error message and source line above for clues.'
    corrected_code = ''
    category = 'runtime'
    confidence = 0.3

    msg_lower = error_msg.lower()
    for pattern in _PATTERNS:
        match = re.search(pattern['match'], msg_lower)
        if match:
            try:
                what_went_wrong, how_to_fix, corrected_code = pattern['explain'](
                    match, source_at_line, source_lines
                )
                category = pattern['category']
                confidence = 0.9
            except Exception as exc:
                _log.debug('Pattern explainer failed: %s', exc)
            break

    # v2.0: Build context window (2 lines above/below error)
    context_lines = _build_context_lines(source_lines, error_line, radius=2)

    # v2.0: Generate docs link from error code
    docs_link = _get_docs_link(error_code)

    # v2.0: Try keyword fuzzy matching on tokens in the error message
    did_you_mean = ''
    # Extract potential mistyped tokens from the error message
    token_match = re.search(r"unexpected token ['\"]?(\w+)['\"]?", msg_lower)
    if token_match:
        did_you_mean = _did_you_mean_keyword(token_match.group(1))
    elif source_at_line:
        # Try each word on the error line against EPL keywords
        for word in re.findall(r'\b([A-Z][a-z]+\w*)\b', source_at_line):
            suggestion = _did_you_mean_keyword(word)
            if suggestion and suggestion.lower() != word.lower():
                did_you_mean = suggestion
                break

    result = ErrorExplanation(
        error_type=error_type,
        error_code=error_code,
        message=error_msg,
        line=error_line,
        source_line=source_at_line,
        what_went_wrong=what_went_wrong,
        how_to_fix=how_to_fix,
        corrected_code=corrected_code,
        category=category,
        confidence=confidence,
        context_lines=context_lines,
        docs_link=docs_link,
        did_you_mean=did_you_mean,
    )

    if ai:
        result.ai_explanation = _get_ai_explanation(error, source)

    return result


# ─── AI Integration ──────────────────────────────────────


def _get_ai_explanation(error, source: str = None) -> str:
    """Get AI-powered explanation using the configured AI backend.

    Uses Ollama (local) or cloud provider (Gemini/Groq) if available.
    Returns empty string if no AI backend is reachable or no API key is configured.
    NEVER leaks API errors (401, 403, etc.) to the user.
    """
    try:
        from epl.ai import _use_cloud, explain_error, is_available

        if not (is_available() or _use_cloud()):
            return ''

        error_msg = getattr(error, 'message', str(error))
        result = explain_error(error_msg, source_code=source) or ''

        # Never show raw API errors to users
        if result and (
            'api error' in result.lower()
            or 'invalid api key' in result.lower()
            or '401' in result
            or '403' in result
        ):
            return ''

        return result
    except Exception:
        return ''


# ─── Rich Terminal Formatting ─────────────────────────────


def format_explanation(exp: ErrorExplanation, color: bool = True) -> str:
    """Format an ErrorExplanation for terminal display.

    Produces Rust/Elm-style diagnostic output with:
      - Error code badge with docs link
      - Context window with line numbers and pointer arrows
      - 'Did you mean?' keyword suggestions
      - Actionable fix suggestions with corrected code
      - Category and confidence metadata
    """
    if color:
        try:
            from epl.errors import _bold, _cyan, _dim, _green, _red, _yellow
        except ImportError:
            color = False

    if not color:
        _bold = _red = _green = _cyan = _dim = _yellow = lambda s: s

    bar = '\u2501' * 52
    thin_bar = '\u2500' * 52

    lines = []
    lines.append('')
    lines.append(f'  {_cyan(bar)}')

    # ── Header with error code badge ──
    category_badge = f'[{exp.category.upper()}]' if exp.category else ''
    code_badge = f'[{exp.error_code}]' if exp.error_code and exp.error_code != 'E0000' else ''
    header_parts = ['Error Explanation']
    if code_badge:
        header_parts.append(code_badge)
    if category_badge:
        header_parts.append(category_badge)
    lines.append(f'  {_bold(" ".join(header_parts))}')
    lines.append(f'  {_cyan(bar)}')

    # ── Context window (source lines around the error) ──
    if exp.context_lines:
        lines.append('')
        lines.append(f'  {_bold("Source:")}')
        # Calculate max line number width for alignment
        max_ln = max(ln for ln, _ in exp.context_lines)
        ln_width = len(str(max_ln))
        for ln, content in exp.context_lines:
            ln_str = str(ln).rjust(ln_width)
            if ln == exp.line:
                # Error line — highlighted with arrow
                lines.append(f'  {_red(">")} {_dim(ln_str)} {_red("|")} {_bold(content)}')
                # Pointer arrow under the line
                stripped = content.lstrip()
                indent = len(content) - len(stripped)
                pointer = ' ' * indent + '^' * max(len(stripped), 1)
                lines.append(f'    {" " * ln_width} {_red("|")} {_red(pointer)}')
            else:
                lines.append(f'    {_dim(ln_str)} {_dim("|")} {_dim(content)}')

    # ── What went wrong ──
    lines.append('')
    lines.append(f'  {_bold("What went wrong:")}')
    for part in exp.what_went_wrong.split('\n'):
        lines.append(f'    {part}')

    # ── Did you mean? ──
    if exp.did_you_mean:
        lines.append('')
        lines.append(f'  {_bold("Did you mean:")}')
        lines.append(f'    {_yellow(exp.did_you_mean)}')

    # ── How to fix ──
    lines.append('')
    lines.append(f'  {_bold("How to fix:")}')
    for part in exp.how_to_fix.split('\n'):
        lines.append(f'    {_green(part)}')

    # ── Suggested corrected code ──
    if exp.corrected_code:
        lines.append('')
        lines.append(f'  {_bold("Suggested code:")}')
        for part in exp.corrected_code.split('\n'):
            lines.append(f'    {_green(part)}')

    # ── AI Analysis (only if available) ──
    if exp.ai_explanation:
        lines.append('')
        lines.append(f'  {_dim(thin_bar)}')
        lines.append(f'  {_bold("AI Analysis:")}')
        for ai_line in exp.ai_explanation.split('\n'):
            lines.append(f'    {ai_line}')

    # ── Footer with docs link ──
    lines.append('')
    lines.append(f'  {_cyan(bar)}')
    if exp.docs_link:
        lines.append(f'  {_dim("Docs:")} {_cyan(exp.docs_link)}')
    lines.append('')

    return '\n'.join(lines)
