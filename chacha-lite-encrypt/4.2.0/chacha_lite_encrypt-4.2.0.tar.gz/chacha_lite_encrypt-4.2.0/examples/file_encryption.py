from chacha_lite_encrypt import ChaChaEncryption, generate_key
import os

key = generate_key()

with open('test_input.txt', 'w') as f:
    f.write('This is a file that will be encrypted')

ChaChaEncryption.encrypt_file('test_input.txt', 'test_input.txt.enc', key)
print("File encrypted")

ChaChaEncryption.decrypt_file('test_input.txt.enc', 'test_input_decrypted.txt', key)
print("File decrypted")

with open('test_input_decrypted.txt', 'r') as f:
    print(f"Decrypted content: {f.read()}")

os.remove('test_input.txt')
os.remove('test_input.txt.enc')
os.remove('test_input_decrypted.txt')
