from setuptools import setup, find_packages

setup(
    name="hy-api-utilities",
    version="0.2.10",
    description="Hyatt API utilities library",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="Hyatt Data Analytics",
    author_email="datascience@hyatt.com",
    license="MIT",
    python_requires=">=3.7",
    packages=find_packages(),
    extras_require={
        "auth": [],
    },
)
