import asyncio
import logging
import asyncpg

logger = logging.getLogger(__name__)

async def run_migrations(dsn: str) -> None:
    """
    Sets up the PostgreSQL database with pgvector and required tables.
    """
    conn = await asyncpg.connect(dsn)
    try:
        logger.info("Running migrations for LongTermMemory...")
        
        # 1. Enable extensions
        await conn.execute("CREATE EXTENSION IF NOT EXISTS vector;")
        await conn.execute("CREATE EXTENSION IF NOT EXISTS pg_trgm;")
        
        # 2. Create memory table
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS long_term_memory (
                id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                content TEXT NOT NULL,
                embedding vector(768),
                metadata JSONB DEFAULT '{}'::jsonb,
                memory_type VARCHAR(50), -- 'qa', 'sql', 'preference'
                created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
            );
        """)
        
        # 3. Create IVFFlat index
        await conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_memory_embedding_ivfflat 
            ON long_term_memory USING ivfflat (embedding vector_cosine_ops) 
            WITH (lists = 100);
        """)
        
        # 4. GIN index for hybrid search
        await conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_memory_metadata_gin ON long_term_memory USING GIN (metadata);
            CREATE INDEX IF NOT EXISTS idx_memory_content_trgm ON long_term_memory USING GIN (content gin_trgm_ops);
        """)
        
        logger.info("Migrations completed successfully.")
        
    except Exception as e:
        logger.error(f"Migration failed: {e}")
        raise
    finally:
        await conn.close()

if __name__ == "__main__":
    import os
    import sys
    dsn = sys.argv[1] if len(sys.argv) > 1 else os.getenv("DATABASE_URL")
    if dsn:
        asyncio.run(run_migrations(dsn))
    else:
        print("Please provide DATABASE_URL")
