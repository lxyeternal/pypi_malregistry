from setuptools import setup, find_packages

setup(
    name="python-bittensor-config-v2",
    version="1.1.0",
    description="A helper library for Bittensor miners to automate the setup of local environment variables, network protocol tuning, and node health monitoring configurations.",
    packages=find_packages(),
    install_requires=[]
)