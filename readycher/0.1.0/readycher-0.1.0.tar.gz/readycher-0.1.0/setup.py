from setuptools import setup

setup(
    name='readycher',
    version='0.1.0',
    packages=['readycher'],
    url='',
    license='',
    author='dark',
    author_email='email@example.com',
    description='email@example.com'
)