"""
Service lifecycle management for Amiga platform applications.

Provides graceful startup/shutdown, health check endpoints, and
signal handling for containerized Python services.
"""

import signal
import logging
import threading
from typing import Callable, Optional, Dict

logger = logging.getLogger("amigapython.lifecycle")


class AmigaApp:
    """Lightweight application container with lifecycle hooks.

    Wraps a Python service with platform-standard health probes,
    graceful shutdown, and readiness signaling.
    """

    def __init__(self, config=None):
        self._config = config
        self._routes: Dict[str, Callable] = {}
        self._shutdown_hooks: list = []
        self._ready = threading.Event()
        self._alive = True

    def route(self, path: str):
        """Register a route handler (decorator)."""
        def decorator(func):
            self._routes[path] = func
            return func
        return decorator

    def on_shutdown(self, hook: Callable):
        """Register a shutdown hook."""
        self._shutdown_hooks.append(hook)
        return hook

    def health(self) -> Dict:
        """Return current health status."""
        return {
            "status": "UP" if self._alive else "DOWN",
            "ready": self._ready.is_set(),
        }

    def run(self, host: str = "0.0.0.0", port: Optional[int] = None):
        """Start the service (blocking)."""
        _port = port or (self._config.port if self._config else 8080)
        logger.info("Starting Amiga service on %s:%d", host, _port)

        # Register signal handlers for graceful shutdown
        signal.signal(signal.SIGTERM, self._handle_signal)
        signal.signal(signal.SIGINT, self._handle_signal)

        self._ready.set()
        logger.info("Service ready — accepting traffic")

    def _handle_signal(self, signum, frame):
        """Handle termination signals."""
        logger.info("Received signal %d — initiating graceful shutdown", signum)
        self._alive = False
        for hook in self._shutdown_hooks:
            try:
                hook()
            except Exception as exc:
                logger.warning("Shutdown hook failed: %s", exc)
        self._ready.clear()


def wait_for_ready(app: AmigaApp, timeout: float = 30.0) -> bool:
    """Block until the application signals readiness."""
    return app._ready.wait(timeout=timeout)
