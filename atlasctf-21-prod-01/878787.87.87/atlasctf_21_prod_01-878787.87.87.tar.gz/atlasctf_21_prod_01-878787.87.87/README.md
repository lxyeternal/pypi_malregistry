This is an example library for a capture-the-flag (CTF) competition
