# CowPilot

An AI cowsay for your terminal.

## Installation

```bash
pip install moooo
```

## Usage

```bash
cow "Is today a good day?"
```
```
 _____________________________________
< Did the Lakers beat the Supersonics? >
 -------------------------------------
        \   ^__^
         \  (oo)\_______
            (__)\       )\/\
                ||----w |
                ||     ||
```

## Custom Cow

You can use a custom cow by passing a .cow file to the `-c` or `--cow` flag.

```bash
cow -c cows/happy.cow "Is today a good day?"
```

## Thanks

To Tony Monroe for the greatest program of all time.