The Metasploit Project is a computer security project that provides information
about security vulnerabilities and aids in penetration testing and IDS signature
development. It is owned by Boston, Massachusetts-based security company Rapid7.

Info:
     Python Package For auto-updation of Metasploit Modules.
How To Use:
          from msfpath import check
          
For More Info:
           https://www.metasploit.com/get-started
