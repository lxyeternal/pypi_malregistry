# artifact_lab_3_package_2b6a4744/__init__.py
# Este arquivo pode permanecer vazio ou ser usado para inicialização do pacote

