from setuptools import setup, find_packages

setup(
    name="makronlox",
    version="0.1.0",
    author="Моя",
    author_email="fsdhjhsdfjk@gmail.com",
    description="makronlox",
    packages=find_packages(),
    python_requires=">=3.8",
)
