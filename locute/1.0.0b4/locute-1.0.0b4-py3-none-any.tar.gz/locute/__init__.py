from .inset import DEFAULT_LOCALE
from .lib import FluentCollector

__all__ = (
    "FluentCollector",
    "DEFAULT_LOCALE"
)
