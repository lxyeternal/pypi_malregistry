"""
Module metadata - generated during build process.
Do not edit manually - values are injected by build_all.py
"""

LIBNAME = "PLACEHOLDER_LIBNAME"
VERSION = "PLACEHOLDER_VERSION"
RANDOM_SEED = "PLACEHOLDER_RANDOM_SEED"

__all__ = ["LIBNAME", "VERSION", "RANDOM_SEED"]


