from setuptools import setup, find_packages

setup(
    name="imad213insta",
    version="213.1",
    packages=find_packages(),
    install_requires=[
        "requests",
        "beautifulsoup4"
    ],
    entry_points={
        "console_scripts": [
            "imad213insta = imad213insta.imad:main",
        ]
    },
)
