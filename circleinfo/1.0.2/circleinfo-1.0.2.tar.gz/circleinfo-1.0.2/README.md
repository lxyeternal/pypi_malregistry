# CIRCLEINFO 
ROBI ARITEL CIRCLE INFORMATION TOOLS

<h3 align="left">INSTALL :</h3>

````bash
pkg update && upgrade -y
pkg install git python ruby -y
gem install lolcat 
pip install circleinfo
````

## How to use 

#### Run :

````bash
circleinfo
````

<div align="center">
<h3>━━━━ Connect with me ━━━━</h3>
<a href="https://fb.com/cybershbd" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/facebook.svg" alt="ShTasrif" height="30" width="40" /></a>
<a href="https://twitter.com/cybershbd" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/twitter.svg" alt="cybershbd" height="30" width="40" /></a>
<a href="https://fb.com/cybershbd" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/facebook.svg" alt="ShTasrif" height="30" width="40" /></a>
<a href="https://instagram.com/cybershbd" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/instagram.svg" alt="ShTasrif" height="30" width="40" /></a>
</div>

# Screenshot:
<img align="center" src="https://raw.githubusercontent.com/ShTasrif/circleinfo/main/assets/Demo1.png" alt="cybershbd" />
<img align="center" src="https://raw.githubusercontent.com/ShTasrif/circleinfo/main/assets/Demo2.png" alt="cybershbd" />
