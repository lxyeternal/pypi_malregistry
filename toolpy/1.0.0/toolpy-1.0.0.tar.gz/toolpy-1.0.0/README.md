# HOW TO USE IT!

# import the TESI module
from Sdbox.TESI import TESI
import pandas as pd

# read the dataframe file that contains the dataset to be augmented 
df=pd.read_excel(r'F:\folder1\folder2...\filename.xlsx')

# assign the TESI module class to a variable 
tesi=TESI(df)

# print augmented dataset as array 
print(tesi.arr())

# print augmented dataset as pandas dataframe 
# if save is True, the pandas dataframe will be saved in the work environment directory 
print(tesi.pd_frame(save=True))


# Documentation:
The TESI was developed in a study context, the study paper was published in Elsivier. 
A detailed description behind the logical of the TESI can be found in the paper.
NOTE: PLEASE CITE THE PAPER. 

Publisher name: Elsevier
Journal: Computers and Electronics in Agriculture
Volume: 206
Issue: March 2023
Pages: 107646
DOI: https://doi.org/10.1016/j.compag.2023.107646


# License: 
Apache License 2.0
A permissive license whose main conditions require preservation of copyright and license notices. 
Contributors provide an express grant of patent rights. Licensed works, modifications, 
and larger works may be distributed under different terms and without source code.

Permissions	               Conditions	                       Limitations
 Commercial use            License and copyright notice        Liability
 Distribution              State changes                       Trademark use
 Modification                                                  Warranty
 Patent use
 Private use
 
 
 
 
 
 
