# Optional: You can log a message here too
print("Thanks for installing my_analytics_package!")
