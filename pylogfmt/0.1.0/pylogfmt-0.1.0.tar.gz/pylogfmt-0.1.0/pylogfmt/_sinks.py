"""File sinks: writing, rotation by size or time, retention, optional gzip."""
from __future__ import annotations

import gzip
import re
import shutil
import threading
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional, Union

_SIZE_RE = re.compile(r"^\s*([\d.]+)\s*([KMGT]?B?)\s*$", re.IGNORECASE)
_SIZE_UNITS = {
    "": 1, "B": 1,
    "K": 1024, "KB": 1024,
    "M": 1024 ** 2, "MB": 1024 ** 2,
    "G": 1024 ** 3, "GB": 1024 ** 3,
    "T": 1024 ** 4, "TB": 1024 ** 4,
}

_TIME_INTERVALS = {
    "hourly": timedelta(hours=1),
    "daily": timedelta(days=1),
    "weekly": timedelta(weeks=1),
    "monthly": timedelta(days=30),
}

_KEEP_RE = re.compile(r"^\s*(\d+)\s+(day|days|hour|hours|week|weeks)\s*$", re.IGNORECASE)


def parse_size(value) -> int:
    if isinstance(value, (int, float)):
        return int(value)
    m = _SIZE_RE.match(value)
    if not m:
        raise ValueError(f"Invalid size value: {value!r}")
    number, unit = m.group(1), m.group(2).upper()
    return int(float(number) * _SIZE_UNITS[unit])


def parse_keep(value) -> Union[int, timedelta]:
    if isinstance(value, int):
        return value
    if isinstance(value, timedelta):
        return value
    m = _KEEP_RE.match(value)
    if not m:
        raise ValueError(f"Invalid keep value: {value!r}")
    n = int(m.group(1))
    unit = m.group(2).lower().rstrip("s") + "s"
    return timedelta(**{unit: n})


class FileSink:
    """A thread-safe file sink that handles rotation and retention."""

    def __init__(
        self,
        path,
        *,
        rotate: Optional[Union[str, int]] = None,
        keep: Optional[Union[str, int]] = None,
        compress: bool = False,
        encoding: str = "utf-8",
    ):
        self.path = Path(path)
        self.encoding = encoding
        self.compress = compress
        self._lock = threading.Lock()
        self._file = None

        self._max_size: Optional[int] = None
        self._interval: Optional[timedelta] = None
        self._next_rotation: Optional[datetime] = None

        if rotate is not None:
            if isinstance(rotate, (int, float)):
                self._max_size = int(rotate)
            elif isinstance(rotate, str):
                key = rotate.strip().lower()
                if key in _TIME_INTERVALS:
                    self._interval = _TIME_INTERVALS[key]
                    self._next_rotation = datetime.now() + self._interval
                else:
                    self._max_size = parse_size(rotate)
            else:
                raise TypeError(f"Invalid rotate type: {type(rotate)!r}")

        self._keep = parse_keep(keep) if keep is not None else None
        self._open()

    def _open(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._file = open(self.path, "a", encoding=self.encoding)

    def _should_rotate(self, message: str) -> bool:
        if self._max_size is not None and self._file is not None:
            try:
                size = self._file.tell()
            except (OSError, AttributeError):
                size = 0
            if size + len(message.encode(self.encoding, errors="replace")) > self._max_size:
                return True
        if self._next_rotation is not None and datetime.now() >= self._next_rotation:
            return True
        return False

    def _rotate(self) -> None:
        if self._file is not None:
            self._file.close()
            self._file = None

        if self.path.exists():
            stamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
            target = self.path.with_name(f"{self.path.stem}.{stamp}{self.path.suffix}")
            i = 0
            while target.exists():
                i += 1
                target = self.path.with_name(f"{self.path.stem}.{stamp}.{i}{self.path.suffix}")
            self.path.rename(target)

            if self.compress:
                gz_path = target.with_suffix(target.suffix + ".gz")
                with open(target, "rb") as src, gzip.open(gz_path, "wb") as dst:
                    shutil.copyfileobj(src, dst)
                target.unlink()

        self._cleanup_old()
        self._open()
        if self._interval is not None:
            self._next_rotation = datetime.now() + self._interval

    def _cleanup_old(self) -> None:
        if self._keep is None:
            return
        stem = re.escape(self.path.stem)
        suffix = re.escape(self.path.suffix)
        pattern = re.compile(
            rf"^{stem}\.[\d\-_]+(?:\.\d+)?{suffix}(?:\.gz)?$"
        )
        rotated = [p for p in self.path.parent.iterdir() if pattern.match(p.name)]
        rotated.sort(key=lambda p: p.stat().st_mtime, reverse=True)

        if isinstance(self._keep, int):
            for p in rotated[self._keep:]:
                try:
                    p.unlink()
                except OSError:
                    pass
        else:
            cutoff = time.time() - self._keep.total_seconds()
            for p in rotated:
                try:
                    if p.stat().st_mtime < cutoff:
                        p.unlink()
                except OSError:
                    pass

    def write(self, message: str) -> None:
        with self._lock:
            if self._should_rotate(message):
                self._rotate()
            if self._file is not None:
                self._file.write(message)
                self._file.flush()

    def close(self) -> None:
        with self._lock:
            if self._file is not None:
                self._file.close()
                self._file = None
