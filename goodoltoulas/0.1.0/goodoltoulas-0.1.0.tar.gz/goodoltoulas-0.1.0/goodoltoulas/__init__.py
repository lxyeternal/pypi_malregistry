from .main import clarify
import requests

def get_json(url, **kwargs):
    r = requests.get(url, **kwargs)
    r.raise_for_status()
    return r.json()

def __getattr__(name):
    # forward everything from requests
    try:
        return getattr(requests, name)
    except AttributeError:
        raise AttributeError(f"module {__name__} has no attribute {name}")
