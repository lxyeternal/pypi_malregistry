# auth0-ai-ms-agent

SDK for building secure AI-powered applications using Auth0, Okta FGA and Microsoft Agent Framework

## Installation

```
pip install auth0-ai-ms-agent
```

## License

MIT
