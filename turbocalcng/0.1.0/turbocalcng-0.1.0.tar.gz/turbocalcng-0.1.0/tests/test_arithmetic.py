import pytest
from turbocalcng.arithmetic import (
    factorial, fibonacci, gcd, lcm, is_prime,
    primes_up_to, fast_power, sum_range,
)


def test_factorial():
    assert factorial(0) == 1
    assert factorial(1) == 1
    assert factorial(10) == 3628800


def test_factorial_negative():
    with pytest.raises(ValueError):
        factorial(-1)


def test_fibonacci():
    assert fibonacci(0) == 0
    assert fibonacci(1) == 1
    assert fibonacci(10) == 55


def test_gcd():
    assert gcd(12, 8) == 4
    assert gcd(0, 5) == 5
    assert gcd(17, 13) == 1


def test_lcm():
    assert lcm(4, 6) == 12
    assert lcm(0, 5) == 0


def test_is_prime():
    assert not is_prime(0)
    assert not is_prime(1)
    assert is_prime(2)
    assert is_prime(3)
    assert not is_prime(4)
    assert is_prime(97)


def test_primes_up_to():
    assert primes_up_to(20) == [2, 3, 5, 7, 11, 13, 17, 19]
    assert primes_up_to(1) == []


def test_fast_power():
    assert fast_power(2, 10) == 1024
    assert fast_power(2, 10, 1000) == 24
    assert fast_power(3, 0) == 1


def test_sum_range():
    assert sum_range(10) == 45
    assert sum_range(1, 11) == 55
