from setuptools import setup, find_packages
setup(name = "xsetuptools", version = "40.8.0", packages = find_packages())