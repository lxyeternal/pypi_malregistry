"""
Remote process management for gcli.
Provides listing, killing, inspecting processes, environment variables,
uptime, and network info. Uses psutil when available, falls back to
platform-native commands otherwise.
"""
import os
import sys
import time
import socket
import platform
import subprocess
import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

logger = logging.getLogger("gcli.processes")

try:
    import psutil
    HAS_PSUTIL = True
except ImportError:
    HAS_PSUTIL = False
    logger.debug("psutil not available, using subprocess fallback")

SYSTEM_CRITICAL_PIDS: set = {0, 1}
if sys.platform == "win32":
    SYSTEM_CRITICAL_NAMES: set = {
        "system", "idle", "smss.exe", "csrss.exe", "wininit.exe",
        "winlogon.exe", "services.exe", "lsass.exe", "lsm.exe",
        "svchost.exe", "dwm.exe", "csrsrss.exe",
    }
else:
    SYSTEM_CRITICAL_NAMES: set = {"init", "kthreadd", "systemd", "launchd"}

SECRET_KEYWORDS = {"password", "secret", "token", "key", "api"}

PSUTIL_SORT_MAP = {
    "cpu": "cpu_percent",
    "mem": "memory_percent",
    "pid": "pid",
    "name": "name",
}


class ProcessManager:
    """Cross-platform remote process management."""

    def ps(self, sort_by: str = "cpu", limit: int = 20) -> dict:
        """List running processes.

        Returns dict with ``"ok"`` and ``"processes"`` list.
        """
        try:
            if HAS_PSUTIL:
                processes = self._ps_psutil(sort_by, limit)
            elif sys.platform == "win32":
                processes = self._ps_tasklist(sort_by, limit)
            else:
                processes = self._ps_posix(sort_by, limit)
            return {"ok": True, "processes": processes}
        except Exception as e:
            logger.error("ps failed: %s", e)
            return {"ok": False, "error": str(e)}

    def kill(self, pid: int, force: bool = False) -> dict:
        """Terminate a process by PID.

        Returns dict with ``"ok"``, ``"pid"``, and ``"signal"``.
        """
        if pid in SYSTEM_CRITICAL_PIDS:
            return {"ok": False, "error": f"Refusing to kill system-critical PID {pid}"}
        if pid <= 0:
            return {"ok": False, "error": f"Invalid PID: {pid}"}

        if sys.platform == "win32":
            return self._kill_windows(pid, force)
        return self._kill_posix(pid, force)

    def process_info(self, pid: int) -> dict:
        """Detailed info on a single process.

        Returns dict with ``"ok"`` and process details.
        """
        try:
            if HAS_PSUTIL:
                return self._info_psutil(pid)
            elif sys.platform == "win32":
                return self._info_tasklist(pid)
            else:
                return self._info_posix(pid)
        except Exception as e:
            logger.error("process_info failed for pid %d: %s", pid, e)
            return {"ok": False, "error": str(e)}

    def env(self, filter_key: Optional[str] = None) -> dict:
        """Return environment variables, filtering out secrets.

        Returns dict with ``"ok"`` and ``"env"`` dict.
        """
        try:
            result: Dict[str, str] = {}
            for key, value in os.environ.items():
                lower_key = key.lower()
                if any(kw in lower_key for kw in SECRET_KEYWORDS):
                    continue
                if filter_key and filter_key.lower() not in lower_key:
                    continue
                result[key] = value
            return {"ok": True, "env": result}
        except Exception as e:
            logger.error("env failed: %s", e)
            return {"ok": False, "error": str(e)}

    def uptime(self) -> dict:
        """Return system uptime.

        Returns dict with ``"ok"``, ``"uptime_seconds"``, ``"uptime_human"``,
        and ``"boot_time"``.
        """
        try:
            boot_ts = psutil.boot_time() if HAS_PSUTIL else self._boot_time_fallback()
            uptime_sec = time.time() - boot_ts
            boot_dt = datetime.fromtimestamp(boot_ts, tz=timezone.utc)
            return {
                "ok": True,
                "uptime_seconds": int(uptime_sec),
                "uptime_human": self._format_duration(uptime_sec),
                "boot_time": boot_dt.strftime("%Y-%m-%d %H:%M:%S UTC"),
            }
        except Exception as e:
            logger.error("uptime failed: %s", e)
            return {"ok": False, "error": str(e)}

    def network_info(self) -> dict:
        """Return network interface info.

        Returns dict with ``"ok"``, ``"interfaces"`` list, ``"hostname"``,
        and ``"fqdn"``.
        """
        try:
            hostname = socket.gethostname()
            try:
                fqdn = socket.getfqdn()
            except Exception:
                fqdn = hostname

            interfaces: List[dict] = []
            if HAS_PSUTIL:
                interfaces = self._net_psutil()
            else:
                interfaces = self._net_fallback()

            return {
                "ok": True,
                "interfaces": interfaces,
                "hostname": hostname,
                "fqdn": fqdn,
            }
        except Exception as e:
            logger.error("network_info failed: %s", e)
            return {"ok": False, "error": str(e)}

    # ------------------------------------------------------------------
    # ps – psutil
    # ------------------------------------------------------------------

    def _ps_psutil(self, sort_by: str, limit: int) -> list:
        sort_key = PSUTIL_SORT_MAP.get(sort_by, "cpu_percent")
        procs = []
        for p in psutil.process_iter(
            ["pid", "name", "cpu_percent", "memory_percent",
             "memory_info", "username", "status", "create_time"]
        ):
            try:
                info = p.info
                mem_mb = (info["memory_info"].rss / (1024 * 1024)) if info.get("memory_info") else 0.0
                create_time = ""
                if info.get("create_time"):
                    create_time = datetime.fromtimestamp(
                        info["create_time"], tz=timezone.utc
                    ).strftime("%Y-%m-%d %H:%M")
                procs.append({
                    "pid": info["pid"],
                    "name": info.get("name", ""),
                    "cpu": round(info.get("cpu_percent") or 0.0, 1),
                    "mem_mb": round(mem_mb, 1),
                    "user": info.get("username") or "",
                    "status": info.get("status") or "",
                    "started": create_time,
                })
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue

        procs.sort(key=lambda p: p.get(sort_key, 0), reverse=True)
        return procs[:limit]

    def _ps_tasklist(self, sort_by: str, limit: int) -> list:
        result = subprocess.run(
            ["tasklist", "/FO", "CSV", "/NH"],
            capture_output=True, text=True, timeout=10,
        )
        procs = []
        for line in result.stdout.strip().splitlines():
            parts = [p.strip('"') for p in line.split(",")]
            if len(parts) < 5:
                continue
            name = parts[0]
            pid = int(parts[1]) if parts[1].isdigit() else 0
            mem_str = parts[4].replace(",", "").replace(" K", "").replace(" KB", "")
            try:
                mem_mb = round(int(mem_str) / 1024, 1)
            except ValueError:
                mem_mb = 0.0
            procs.append({
                "pid": pid,
                "name": name,
                "cpu": 0.0,
                "mem_mb": mem_mb,
                "user": parts[3] if len(parts) > 3 else "",
                "status": parts[2] if len(parts) > 2 else "",
                "started": "",
            })

        sort_key = "pid" if sort_by == "pid" else "name" if sort_by == "name" else "mem_mb"
        procs.sort(key=lambda p: p[sort_key], reverse=(sort_key != "name"))
        return procs[:limit]

    def _ps_posix(self, sort_by: str, limit: int) -> list:
        result = subprocess.run(
            ["ps", "aux"],
            capture_output=True, text=True, timeout=10,
        )
        procs = []
        lines = result.stdout.strip().splitlines()
        if not lines:
            return procs

        for line in lines[1:]:
            parts = line.split(None, 10)
            if len(parts) < 11:
                continue
            procs.append({
                "pid": int(parts[1]),
                "name": parts[10].split("/")[-1],
                "cpu": float(parts[2]),
                "mem_mb": round(float(parts[5]) / 1024, 1),
                "user": parts[0],
                "status": parts[7] if len(parts) > 7 else "",
                "started": parts[8] if len(parts) > 8 else "",
            })

        sort_key = "cpu" if sort_by == "cpu" else "mem_mb" if sort_by == "mem" else sort_by
        procs.sort(key=lambda p: p.get(sort_key, 0), reverse=True)
        return procs[:limit]

    # ------------------------------------------------------------------
    # kill
    # ------------------------------------------------------------------

    def _kill_windows(self, pid: int, force: bool) -> dict:
        cmd = ["taskkill", "/PID", str(pid)]
        if force:
            cmd.append("/F")
        if pid in SYSTEM_CRITICAL_PIDS or self._is_critical_by_name(pid):
            return {"ok": False, "error": f"Refusing to kill system-critical PID {pid}"}
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=5)
            if result.returncode == 0:
                return {
                    "ok": True,
                    "pid": pid,
                    "signal": "TASKKILL /F" if force else "TASKKILL",
                }
            return {"ok": False, "error": result.stderr.strip() or "taskkill failed"}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def _kill_posix(self, pid: int, force: bool) -> dict:
        import signal as _signal
        sig = _signal.SIGKILL if force else _signal.SIGTERM
        if self._is_critical_by_name(pid):
            return {"ok": False, "error": f"Refusing to kill system-critical PID {pid}"}
        try:
            os.kill(pid, sig)
            return {"ok": True, "pid": pid, "signal": sig.name}
        except PermissionError:
            return {"ok": False, "error": "Permission denied"}
        except ProcessLookupError:
            return {"ok": False, "error": f"No process with PID {pid}"}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def _is_critical_by_name(self, pid: int) -> bool:
        if HAS_PSUTIL:
            try:
                p = psutil.Process(pid)
                return p.name().lower() in SYSTEM_CRITICAL_NAMES
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                return False
        return False

    # ------------------------------------------------------------------
    # process_info
    # ------------------------------------------------------------------

    def _info_psutil(self, pid: int) -> dict:
        p = psutil.Process(pid)
        with p.oneshot():
            name = p.name()
            try:
                exe = p.exe()
            except (psutil.AccessDenied, psutil.NoSuchProcess):
                exe = ""
            try:
                cwd = p.cwd()
            except (psutil.AccessDenied, psutil.NoSuchProcess):
                cwd = ""
            cmdline = " ".join(p.cmdline())
            cpu_pct = p.cpu_percent(interval=0.1)
            mem_mb = round(p.memory_info().rss / (1024 * 1024), 1)
            num_threads = p.num_threads()
            create_time = datetime.fromtimestamp(
                p.create_time(), tz=timezone.utc
            ).strftime("%Y-%m-%d %H:%M:%S UTC")
            status = p.status()

        return {
            "ok": True,
            "pid": pid,
            "name": name,
            "exe": exe,
            "cwd": cwd,
            "cmdline": cmdline,
            "cpu_percent": round(cpu_pct, 1),
            "mem_mb": mem_mb,
            "num_threads": num_threads,
            "create_time": create_time,
            "status": status,
        }

    def _info_tasklist(self, pid: int) -> dict:
        result = subprocess.run(
            ["tasklist", "/FI", f"PID eq {pid}", "/FO", "CSV", "/V"],
            capture_output=True, text=True, timeout=10,
        )
        lines = result.stdout.strip().splitlines()
        if len(lines) < 2:
            return {"ok": False, "error": f"No process with PID {pid}"}

        parts = [p.strip('"') for p in lines[1].split(",")]
        name = parts[0] if parts else ""
        mem_str = parts[4].replace(",", "").replace(" K", "") if len(parts) > 4 else "0"
        try:
            mem_mb = round(int(mem_str) / 1024, 1)
        except ValueError:
            mem_mb = 0.0
        status = parts[2] if len(parts) > 2 else ""
        user = parts[3] if len(parts) > 3 else ""
        exe_path = parts[9] if len(parts) > 9 else ""

        return {
            "ok": True,
            "pid": pid,
            "name": name,
            "exe": exe_path,
            "cwd": "",
            "cmdline": "",
            "cpu_percent": 0.0,
            "mem_mb": mem_mb,
            "num_threads": 0,
            "create_time": "",
            "status": status,
        }

    def _info_posix(self, pid: int) -> dict:
        ps_result = subprocess.run(
            ["ps", "-p", str(pid), "-o", "pid,comm,pcpu,pmem,rss,stat,ttime,etime,user,args"],
            capture_output=True, text=True, timeout=10,
        )
        lines = ps_result.stdout.strip().splitlines()
        if len(lines) < 2:
            return {"ok": False, "error": f"No process with PID {pid}"}

        parts = lines[1].split(None, 9)
        if len(parts) < 10:
            return {"ok": False, "error": "Could not parse ps output"}

        rss_kb = int(parts[4]) if parts[4].isdigit() else 0
        return {
            "ok": True,
            "pid": pid,
            "name": parts[1],
            "exe": "",
            "cwd": "",
            "cmdline": parts[9] if len(parts) > 9 else "",
            "cpu_percent": float(parts[2]),
            "mem_mb": round(rss_kb / 1024, 1),
            "num_threads": 0,
            "create_time": "",
            "status": parts[5],
        }

    # ------------------------------------------------------------------
    # uptime helpers
    # ------------------------------------------------------------------

    def _boot_time_fallback(self) -> float:
        if sys.platform == "win32":
            result = subprocess.run(
                ["wmic", "os", "get", "LastBootUpTime", "/VALUE"],
                capture_output=True, text=True, timeout=10,
            )
            for line in result.stdout.splitlines():
                if "LastBootUpTime" in line:
                    val = line.split("=", 1)[1].strip()
                    dt = datetime.strptime(val[:14], "%Y%m%d%H%M%S")
                    return dt.timestamp()
        else:
            result = subprocess.run(
                ["uptime", "-s"],
                capture_output=True, text=True, timeout=10,
            )
            if result.returncode == 0:
                dt = datetime.strptime(result.stdout.strip(), "%Y-%m-%d %H:%M:%S")
                return dt.timestamp()
        return time.time()

    def _format_duration(self, seconds: float) -> str:
        seconds = int(seconds)
        days = seconds // 86400
        hours = (seconds % 86400) // 3600
        minutes = (seconds % 3600) // 60
        secs = seconds % 60
        parts = []
        if days:
            parts.append(f"{days}d")
        if hours:
            parts.append(f"{hours}h")
        if minutes:
            parts.append(f"{minutes}m")
        parts.append(f"{secs}s")
        return " ".join(parts)

    # ------------------------------------------------------------------
    # network info
    # ------------------------------------------------------------------

    def _net_psutil(self) -> list:
        interfaces = []
        addrs_map = psutil.net_if_addrs()
        stats_map = psutil.net_if_stats()
        io_map = psutil.net_io_counters(pernic=True)

        for name, addrs in addrs_map.items():
            addr_list = []
            for a in addrs:
                if a.family in (socket.AF_INET, socket.AF_INET6):
                    addr_list.append(a.address)
            stats = stats_map.get(name)
            io = io_map.get(name)
            interfaces.append({
                "name": name,
                "addrs": addr_list,
                "is_up": stats.isup if stats else False,
                "bytes_sent": io.bytes_sent if io else 0,
                "bytes_recv": io.bytes_recv if io else 0,
            })
        return interfaces

    def _net_fallback(self) -> list:
        if sys.platform == "win32":
            result = subprocess.run(
                ["ipconfig"],
                capture_output=True, text=True, timeout=10,
            )
            interfaces = []
            current_name = "unknown"
            addrs = []
            for line in result.stdout.splitlines():
                line = line.strip()
                if "adapter" in line.lower() or "adapter" in line.lower():
                    if addrs:
                        interfaces.append({"name": current_name, "addrs": addrs, "bytes_sent": 0, "bytes_recv": 0})
                    current_name = line.split(":")[0].strip() if ":" in line else line
                    addrs = []
                elif "IPv4" in line and ":" in line:
                    addr = line.split(":")[-1].strip()
                    if addr:
                        addrs.append(addr)
            if addrs:
                interfaces.append({"name": current_name, "addrs": addrs, "bytes_sent": 0, "bytes_recv": 0})
            return interfaces
        else:
            result = subprocess.run(
                ["ip", "-o", "addr", "show"],
                capture_output=True, text=True, timeout=10,
            )
            interfaces = []
            addrs_map: Dict[str, List[str]] = {}
            for line in result.stdout.splitlines():
                parts = line.split()
                if len(parts) >= 4:
                    name = parts[1]
                    if "inet" in parts[2]:
                        addr = parts[3].split("/")[0]
                        addrs_map.setdefault(name, []).append(addr)
            for name, addrs in addrs_map.items():
                interfaces.append({
                    "name": name,
                    "addrs": addrs,
                    "bytes_sent": 0,
                    "bytes_recv": 0,
                })
            return interfaces


_manager: Optional[ProcessManager] = None


def _get_manager() -> ProcessManager:
    global _manager
    if _manager is None:
        _manager = ProcessManager()
    return _manager


def dispatch(payload: dict) -> dict:
    """Route a command payload to the appropriate ProcessManager method.

    >>> dispatch({"type": "ps"})["ok"]
    True
    """
    cmd_type = payload.get("type", "")
    mgr = _get_manager()

    if cmd_type == "ps":
        return mgr.ps(
            sort_by=payload.get("sort_by", "cpu"),
            limit=payload.get("limit", 20),
        )
    elif cmd_type == "kill":
        pid = payload.get("pid")
        if pid is None:
            return {"ok": False, "error": "Missing 'pid' field"}
        return mgr.kill(pid=int(pid), force=bool(payload.get("force", False)))
    elif cmd_type == "process_info":
        pid = payload.get("pid")
        if pid is None:
            return {"ok": False, "error": "Missing 'pid' field"}
        return mgr.process_info(pid=int(pid))
    elif cmd_type == "env":
        return mgr.env(filter_key=payload.get("filter"))
    elif cmd_type == "uptime":
        return mgr.uptime()
    elif cmd_type == "network_info":
        return mgr.network_info()
    else:
        return {"ok": False, "error": f"Unknown processes command type: {cmd_type}"}


def test_processes() -> None:
    """Self-test: exercise every capability and print results."""
    print("=" * 60)
    print("gcli.processes self-test")
    print(f"psutil available: {HAS_PSUTIL}")
    print("=" * 60)

    mgr = ProcessManager()

    # ps
    print("\n--- ps (top 5 by CPU) ---")
    r = mgr.ps(sort_by="cpu", limit=5)
    assert r["ok"], f"ps failed: {r}"
    for p in r["processes"]:
        print(f"  PID={p['pid']:>6}  CPU={p['cpu']:>5.1f}%  MEM={p['mem_mb']:>8.1f}MB  {p['name']}")

    # process_info (current process)
    my_pid = os.getpid()
    print(f"\n--- process_info (PID {my_pid}) ---")
    r = mgr.process_info(my_pid)
    assert r["ok"], f"process_info failed: {r}"
    print(f"  name={r['name']}  exe={r.get('exe', '')[:60]}  threads={r.get('num_threads', '?')}")

    # env
    print("\n--- env (filter=PATH) ---")
    r = mgr.env(filter_key="PATH")
    assert r["ok"], f"env failed: {r}"
    for k, v in r["env"].items():
        print(f"  {k}={v[:80]}...")

    # env secret filtering
    r = mgr.env()
    assert r["ok"]
    for k in r["env"]:
        assert not any(w in k.lower() for w in SECRET_KEYWORDS), f"Secret leaked: {k}"

    # uptime
    print("\n--- uptime ---")
    r = mgr.uptime()
    assert r["ok"], f"uptime failed: {r}"
    print(f"  up {r['uptime_human']}  (since {r['boot_time']})")

    # network_info
    print("\n--- network_info ---")
    r = mgr.network_info()
    assert r["ok"], f"network_info failed: {r}"
    print(f"  hostname={r['hostname']}  fqdn={r['fqdn']}")
    for iface in r["interfaces"][:5]:
        print(f"  {iface['name']}: {iface['addrs']}")

    # dispatch routing
    print("\n--- dispatch ---")
    r = dispatch({"type": "ps", "limit": 2})
    assert r["ok"], f"dispatch ps failed: {r}"
    print(f"  dispatch ps -> {len(r['processes'])} processes")

    r = dispatch({"type": "uptime"})
    assert r["ok"]
    print(f"  dispatch uptime -> {r['uptime_human']}")

    r = dispatch({"type": "bogus"})
    assert not r["ok"]
    print(f"  dispatch bogus -> error: {r['error']}")

    print("\n" + "=" * 60)
    print("All tests passed.")
    print("=" * 60)


if __name__ == "__main__":
    test_processes()
