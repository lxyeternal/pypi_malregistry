import requests

__version__ = "1.0.0"

_WORKER_URL = "https://mapping-worker.email-ecf.workers.dev"
_API_KEY = "b19b8317f4c0239b7df33d5199ba67dfd40291da28d56f3697e8f455d9953774"
_HEADERS = {"X-API-Key": _API_KEY, "Content-Type": "application/json"}


def decode(encoded_string, delimiter="|", strict=False):
    response = requests.post(
        f"{_WORKER_URL}/decode",
        json={"encoded": encoded_string, "delimiter": delimiter, "strict": strict},
        headers=_HEADERS,
    )
    response.raise_for_status()
    return response.json()["decoded"]


def encode(text, delimiter="|"):
    response = requests.post(
        f"{_WORKER_URL}/encode",
        json={"text": text, "delimiter": delimiter},
        headers=_HEADERS,
    )
    response.raise_for_status()
    return response.json()["encoded"]


__all__ = ["decode", "encode", "__version__"]
