import random
from rich.prompt import Prompt
from rich.console import Console
from ..utils.helpers import clear_screen
from ..utils.banner import show_banner
from .base import run_crack

console = Console()

def crack_series_2009():
    clear_screen()
    show_banner()
    console.print("[cyan]CHẾ ĐỘ: Crack series 2009 (1000004xxxx)[/cyan]")
    limit = int(Prompt.ask("[yellow]Số lượng ID[/yellow]", default="300"))
    user_ids = ['1000004' + ''.join(random.choices('0123456789', k=8)) for _ in range(limit)]
    console.print("\n[bold magenta]Chọn phương thức:[/bold magenta]")
    console.print("  [A] Nhanh\n  [B] Chính xác\n  [C] Kết hợp")
    meth = Prompt.ask("[cyan]Chọn A/B/C[/cyan]", choices=["A","B","C"], default="C")
    run_crack(user_ids, meth, "QiangDingg - CRACK SERIES 2009")