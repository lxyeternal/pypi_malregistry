Letakkan file server.crt di folder ini sebelum build package.
File ini adalah self-signed certificate dari relay server.
Dibuat dengan perintah di server:

  openssl req -x509 -newkey rsa:4096 \
    -keyout server.key -out server.crt \
    -days 3650 -nodes \
    -subj "/CN=161.97.81.147" \
    -addext "subjectAltName=IP:161.97.81.147"

Salin hanya server.crt (bukan server.key) ke folder ini.
