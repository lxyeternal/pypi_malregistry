# Changelog

All notable changes to this project are documented here. The format follows
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/) and this project adheres
to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.1.0] - 2026-08-16

### Added
- `KnowledgeBase` with `add`, `add_text`, `get`, `remove`, `search`, `save`, `load`.
- `Document` and `SearchResult` dataclasses, plus the `tokenize` helper.
- tf-idf style keyword ranking with no third-party dependencies.
- `kb-ai` command line interface (`add`, `search`, `list`, `remove`).
- Typed package (`py.typed`), test suite, CI, and PyPI publish workflow.

[Unreleased]: https://github.com/4us71n0/kb-ai/compare/v0.1.0...HEAD
[0.1.0]: https://github.com/4us71n0/kb-ai/releases/tag/v0.1.0
