
from setuptools import setup, find_packages
setup(name='paysafe-api',version='1.0.0',description='Paysafe REST API client for Python',
      author='Paysafe Developer Team',packages=find_packages(),
      install_requires=['requests>=2.28'])
