# -*- coding: utf-8 -*-
"""
sqligen/SchemaManager.py

This module provides tools for schema definition, inspection, and database migrations
in SQLite3. It includes a programmatic CREATE TABLE builder, a dynamic schema inspector,
and a transactional migration runner with full support for rollbacks.

Classes:
    SchemaManagerError: Base exception for all schema-related failures.
    MigrationError: Raised when migration execution or tracking fails.
    Column: Represents a column definition for SQLite tables.
    TableBuilder: DSL engine to programmatically construct CREATE TABLE statements.
    SchemaInspector: Inspects schema metadata, indices, foreign keys, and integrity.
    MigrationRunner: Manages and executes version-controlled database migrations.

Naming Convention:
    PascalCase is used for all class names, method names, and public functions.
"""

import logging
import sqlite3
from typing import Dict, List, Optional, Union, Tuple, Any, Callable

Logger = logging.getLogger("Sqligen.SchemaManager")


class SchemaManagerError(Exception):
    """
    Raised when general schema actions fail, such as index creation errors,
    invalid column definitions, or inspection issues.
    """
    pass


class MigrationError(SchemaManagerError):
    """
    Raised when database migrations fail to apply, run out of sequence,
    or raise errors during transactional execution.
    """
    pass


class Column:
    """
    Represents a SQL column definition with constraints.
    
    Provides methods to build SQLite-compliant definitions for integers, text,
    reals, blobs, and numeric columns, including constraints.
    """

    def __init__(
        self,
        Name: str,
        DataType: str,
        IsPrimaryKey: bool = False,
        IsAutoincrement: bool = False,
        IsNullable: bool = True,
        DefaultValue: Any = None,
        IsUnique: bool = False,
        CheckExpression: Optional[str] = None
    ) -> None:
        """
        Initializes a Column definition node.

        Parameters:
            Name (str): Column name identifier.
            DataType (str): Data type keyword ('INTEGER', 'TEXT', 'REAL', 'BLOB').
            IsPrimaryKey (bool): Marks the column as a PRIMARY KEY if True.
            IsAutoincrement (bool): Enables AUTOINCREMENT if True (valid only with INTEGER PRIMARY KEY).
            IsNullable (bool): Permits NULL values if True, sets NOT NULL if False.
            DefaultValue (Any): Default value to assign when writing records.
            IsUnique (bool): Enforces column-level unique constraints.
            CheckExpression (str): Validation rule constraint (e.g. 'length(name) > 2').
        """
        self.Name = Name
        self.DataType = DataType.upper()
        self.IsPrimaryKey = IsPrimaryKey
        self.IsAutoincrement = IsAutoincrement
        self.IsNullable = IsNullable
        self.DefaultValue = DefaultValue
        self.IsUnique = IsUnique
        self.CheckExpression = CheckExpression

    def BuildSql(self) -> str:
        """
        Compiles the column parameters into a raw SQL column definition snippet.

        Returns:
            str: SQL fragment representing the column and its constraints.
        """
        Parts = [self.Name, self.DataType]

        if self.IsPrimaryKey:
            Parts.append("PRIMARY KEY")
            if self.IsAutoincrement and self.DataType == "INTEGER":
                Parts.append("AUTOINCREMENT")

        if not self.IsPrimaryKey and not self.IsNullable:
            Parts.append("NOT NULL")

        if self.DefaultValue is not None:
            if isinstance(self.DefaultValue, str):
                EscapedVal = self.DefaultValue.replace("'", "''")
                Parts.append(f"DEFAULT '{EscapedVal}'")
            elif isinstance(self.DefaultValue, bool):
                Parts.append(f"DEFAULT {1 if self.DefaultValue else 0}")
            else:
                Parts.append(f"DEFAULT {self.DefaultValue}")

        if self.IsUnique:
            Parts.append("UNIQUE")

        if self.CheckExpression:
            Parts.append(f"CHECK ({self.CheckExpression})")

        return " ".join(Parts)


class TableBuilder:
    """
    DSL builder class to programmatically generate SQLite CREATE TABLE DDL queries.
    """

    def __init__(self, TableName: str, Temporary: bool = False, IfNotExists: bool = True) -> None:
        """
        Initializes the table builder session.

        Parameters:
            TableName (str): Target table name identifier.
            Temporary (bool): Compiles as a TEMP table if True.
            IfNotExists (bool): Appends IF NOT EXISTS constraint checks.
        """
        self.TableName = TableName
        self.Temporary = Temporary
        self.IfNotExists = IfNotExists
        self.ColumnsList: List[Column] = []
        self.ForeignKeyConstraints: List[str] = []
        self.CompositePrimaryKeyColumns: List[str] = []

    def AddColumn(self, ColumnDef: Column) -> 'TableBuilder':
        """Appends a preconfigured Column object to the table schema."""
        self.ColumnsList.append(ColumnDef)
        return self

    def DefineColumn(
        self,
        Name: str,
        DataType: str,
        IsPrimaryKey: bool = False,
        IsAutoincrement: bool = False,
        IsNullable: bool = True,
        DefaultValue: Any = None,
        IsUnique: bool = False,
        CheckExpression: Optional[str] = None
    ) -> 'TableBuilder':
        """
        Helper method to define and append a column to the builder.
        
        Parameters are identical to Column.__init__.
        """
        Col = Column(
            Name=Name,
            DataType=DataType,
            IsPrimaryKey=IsPrimaryKey,
            IsAutoincrement=IsAutoincrement,
            IsNullable=IsNullable,
            DefaultValue=DefaultValue,
            IsUnique=IsUnique,
            CheckExpression=CheckExpression
        )
        self.ColumnsList.append(Col)
        return self

    def AddCompositePrimaryKey(self, *Columns: str) -> 'TableBuilder':
        """
        Defines a composite primary key consisting of multiple columns.

        Parameters:
            Columns (str): Name references of columns composing the primary key.
        """
        self.CompositePrimaryKeyColumns.extend(Columns)
        return self

    def AddForeignKey(
        self,
        LocalColumn: str,
        ForeignTable: str,
        ForeignColumn: str,
        OnDelete: str = "NO ACTION",
        OnUpdate: str = "NO ACTION"
    ) -> 'TableBuilder':
        """
        Establishes a relational FOREIGN KEY constraint on the table schema.

        Parameters:
            LocalColumn (str): The column in this table containing the reference.
            ForeignTable (str): The destination referenced table name.
            ForeignColumn (str): The column reference inside the target destination table.
            OnDelete (str): Referential behavior on row deletion (e.g. 'CASCADE', 'SET NULL').
            OnUpdate (str): Referential behavior on key updates.
        """
        FkStr = (
            f"FOREIGN KEY ({LocalColumn}) REFERENCES {ForeignTable} ({ForeignColumn}) "
            f"ON DELETE {OnDelete.upper()} ON UPDATE {OnUpdate.upper()}"
        )
        self.ForeignKeyConstraints.append(FkStr)
        return self

    def Build(self) -> str:
        """
        Compiles the defined builder state into a SQL CREATE TABLE statement.

        Returns:
            str: A formatted DDL query ready for database execution.

        Raises:
            SchemaManagerError: If column definitions are missing.
        """
        if not self.ColumnsList:
            raise SchemaManagerError("Cannot generate a CREATE TABLE statement without columns defined.")

        SqlParts = []
        TempClause = "TEMP " if self.Temporary else ""
        ExistsClause = "IF NOT EXISTS " if self.IfNotExists else ""
        
        SqlParts.append(f"CREATE {TempClause}TABLE {ExistsClause}{self.TableName} (\n  ")

        ColumnDefinitions = [Col.BuildSql() for Col in self.ColumnsList]

        # Handle composite primary key if specified
        if self.CompositePrimaryKeyColumns:
            ColsStr = ", ".join(self.CompositePrimaryKeyColumns)
            ColumnDefinitions.append(f"PRIMARY KEY ({ColsStr})")

        # Append foreign keys
        if self.ForeignKeyConstraints:
            ColumnDefinitions.extend(self.ForeignKeyConstraints)

        SqlParts.append(",\n  ".join(ColumnDefinitions))
        SqlParts.append("\n);")

        return "".join(SqlParts)


class SchemaInspector:
    """
    Utility class designed to extract schema metadata from SQLite3.
    """

    def __init__(self, Connection: sqlite3.Connection) -> None:
        """
        Initializes the schema inspector.

        Parameters:
            Connection (sqlite3.Connection): An active SQLite connection.
        """
        self.Connection = Connection

    def ListTables(self) -> List[str]:
        """
        Retrieves a list of all user-defined tables in the database.

        Returns:
            List[str]: Table name identifiers.
        """
        Sql = "SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%';"
        try:
            Cursor = self.Connection.cursor()
            Cursor.execute(Sql)
            Tables = [Row[0] for Row in Cursor.fetchall()]
            Cursor.close()
            return Tables
        except Exception as Err:
            raise SchemaManagerError(f"Failed to query database catalog tables: {str(Err)}", Err)

    def TableExists(self, TableName: str) -> bool:
        """Checks if a table exists in the database schema."""
        Sql = "SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = ?;"
        try:
            Cursor = self.Connection.cursor()
            Cursor.execute(Sql, (TableName,))
            Exists = Cursor.fetchone() is not None
            Cursor.close()
            return Exists
        except Exception as Err:
            raise SchemaManagerError(f"Failed to check table existence for {TableName}: {str(Err)}", Err)

    def InspectTable(self, TableName: str) -> List[Dict[str, Any]]:
        """
        Queries and returns column details for the specified table.

        Parameters:
            TableName (str): Target table name.

        Returns:
            List[Dict[str, Any]]: List of dictionary structures containing column properties:
                - cid (int): Column ID
                - name (str): Column name
                - type (str): Data type
                - notnull (int): NOT NULL status (1 if active, 0 otherwise)
                - dflt_value (Any): Column default value
                - pk (int): Primary key index flag (1 if active)
        """
        if not self.TableExists(TableName):
            raise SchemaManagerError(f"Table '{TableName}' does not exist in schema.")

        try:
            Cursor = self.Connection.cursor()
            Cursor.execute(f"PRAGMA table_info({TableName});")
            Columns = [dict(Row) for Row in Cursor.fetchall()]
            Cursor.close()
            return Columns
        except Exception as Err:
            raise SchemaManagerError(f"Failed to inspect columns for table {TableName}: {str(Err)}", Err)

    def GetTableIndexes(self, TableName: str) -> List[Dict[str, Any]]:
        """
        Retrieves a list of indexes defined on the target table.

        Returns:
            List[Dict[str, Any]]: List of index properties (name, unique, origin, etc.).
        """
        try:
            Cursor = self.Connection.cursor()
            Cursor.execute(f"PRAGMA index_list({TableName});")
            Indexes = [dict(Row) for Row in Cursor.fetchall()]
            Cursor.close()
            return Indexes
        except Exception as Err:
            raise SchemaManagerError(f"Failed to list indexes for table {TableName}: {str(Err)}", Err)

    def VerifyIntegrity(self) -> Tuple[bool, List[str]]:
        """
        Executes database integrity and constraint check validation procedures.

        Returns:
            Tuple[bool, List[str]]: A tuple containing a success flag and a list of integrity errors (if any).
        """
        Errors = []
        try:
            Cursor = self.Connection.cursor()
            
            # 1. Structural integrity check
            Cursor.execute("PRAGMA integrity_check;")
            IntegrityResult = Cursor.fetchall()
            for Row in IntegrityResult:
                ResultText = Row[0]
                if ResultText.upper() != "OK":
                    Errors.append(f"Integrity check failed: {ResultText}")

            # 2. Foreign Key constraints validation
            Cursor.execute("PRAGMA foreign_key_check;")
            FkResult = Cursor.fetchall()
            for Row in FkResult:
                Errors.append(
                    f"Foreign key violation: Table '{Row[0]}' RowID {Row[1]} "
                    f"references non-existent entry in table '{Row[2]}' (FkID: {Row[3]})"
                )

            Cursor.close()
            return len(Errors) == 0, Errors
        except Exception as Err:
            raise SchemaManagerError(f"Failed to verify database structural integrity: {str(Err)}", Err)


class MigrationRunner:
    """
    Manages and executes version-controlled migrations against SQLite databases.
    
    Automates migration registration and sequential tracking in a dedicated table.
    Ensures all database migrations run atomically inside SQL transactions.
    """

    def __init__(self, Connection: sqlite3.Connection) -> None:
        """
        Initializes the migration runner.

        Parameters:
            Connection (sqlite3.Connection): An active SQLite connection.
        """
        self.Connection = Connection
        self.MigrationsRegistry: List[Tuple[int, str, Callable[[sqlite3.Connection], None], Callable[[sqlite3.Connection], None]]] = []
        self.InitializeMigrationTable()

    def InitializeMigrationTable(self) -> None:
        """
        Initializes the internal schema migration tracking table.
        """
        Builder = TableBuilder("_sqligen_migrations", IfNotExists=True)
        Builder.DefineColumn("Version", "INTEGER", IsPrimaryKey=True)
        Builder.DefineColumn("Description", "TEXT", IsNullable=False)
        Builder.DefineColumn("AppliedAt", "TEXT", DefaultValue="CURRENT_TIMESTAMP")
        
        Sql = Builder.Build()
        try:
            Cursor = self.Connection.cursor()
            Cursor.execute(Sql)
            self.Connection.commit()
            Cursor.close()
            Logger.debug("Migration manager tracking schema verified.")
        except Exception as Err:
            raise MigrationError(f"Failed to initialize migration registry table: {str(Err)}", Err)

    def RegisterMigration(
        self,
        Version: int,
        Description: str,
        UpAction: Callable[[sqlite3.Connection], None],
        DownAction: Callable[[sqlite3.Connection], None]
    ) -> None:
        """
        Registers a new migration step.

        Parameters:
            Version (int): Unique, strictly increasing sequential version integer.
            Description (str): Brief description of the schema adjustments.
            UpAction (Callable): Callback that applies the schema modifications.
            DownAction (Callable): Callback that rolls back the schema modifications.

        Raises:
            MigrationError: If a migration with the same version is already registered.
        """
        if any(V == Version for V, _, _, _ in self.MigrationsRegistry):
            raise MigrationError(f"Migration version {Version} has already been registered.")
        
        self.MigrationsRegistry.append((Version, Description, UpAction, DownAction))
        # Ensure registry order is strictly sorted by version
        self.MigrationsRegistry.sort(key=lambda Item: Item[0])

    def GetAppliedVersions(self) -> List[int]:
        """
        Retrieves the version IDs of all applied migrations.

        Returns:
            List[int]: Sorted list of applied version IDs.
        """
        Sql = "SELECT Version FROM _sqligen_migrations ORDER BY Version ASC;"
        try:
            Cursor = self.Connection.cursor()
            Cursor.execute(Sql)
            Versions = [Row[0] for Row in Cursor.fetchall()]
            Cursor.close()
            return Versions
        except Exception as Err:
            raise MigrationError(f"Failed to retrieve list of applied migration versions: {str(Err)}", Err)

    def GetDatabaseVersion(self) -> int:
        """
        Gets the current database version.

        Returns:
            int: The version of the last applied migration, or 0 if no migrations have run.
        """
        Versions = self.GetAppliedVersions()
        return Versions[-1] if Versions else 0

    def MigrateToLatest(self) -> None:
        """
        Executes all pending migrations sequentially.
        
        Each migration step runs atomically inside its own transaction context.
        If a migration fails, the transaction rolls back, execution halts,
        and database state integrity is preserved.

        Raises:
            MigrationError: If any migration step execution fails.
        """
        Applied = set(self.GetAppliedVersions())
        
        for Version, Description, UpAction, DownAction in self.MigrationsRegistry:
            if Version not in Applied:
                Logger.info(f"Applying migration version {Version}: {Description}")
                try:
                    # Run dynamically inside a transaction
                    Cursor = self.Connection.cursor()
                    Cursor.execute("BEGIN IMMEDIATE;")
                    
                    # Execute migration callback
                    UpAction(self.Connection)
                    
                    # Record execution trace in migration history table
                    Cursor.execute(
                        "INSERT INTO _sqligen_migrations (Version, Description) VALUES (?, ?);",
                        (Version, Description)
                    )
                    
                    self.Connection.commit()
                    Cursor.close()
                    Logger.info(f"Successfully applied migration version {Version}.")
                except Exception as Err:
                    # Fail-safe rollback on transaction error
                    try:
                        self.Connection.rollback()
                    except Exception:
                        pass
                    raise MigrationError(
                        f"Migration failed at step {Version} ({Description}): {str(Err)}. Database rolled back.",
                        Err
                    )

    def RollbackToVersion(self, TargetVersion: int) -> None:
        """
        Rolls back applied migrations step-by-step to the target version.

        Parameters:
            TargetVersion (int): The target version to roll back to.

        Raises:
            MigrationError: If rollback target version is invalid or rollback execution fails.
        """
        CurrentVer = self.GetDatabaseVersion()
        if TargetVersion < 0 or TargetVersion > CurrentVer:
            raise MigrationError(
                f"Invalid rollback target version ({TargetVersion}). Current database version is {CurrentVer}."
            )

        # Retrieve registered migrations in descending order for sequential rollbacks
        ActiveRegistry = reversed(self.MigrationsRegistry)
        
        for Version, Description, UpAction, DownAction in ActiveRegistry:
            if Version > TargetVersion and Version <= CurrentVer:
                Logger.info(f"Reverting migration version {Version}: {Description}")
                try:
                    Cursor = self.Connection.cursor()
                    Cursor.execute("BEGIN IMMEDIATE;")
                    
                    # Run rollback callback
                    DownAction(self.Connection)
                    
                    # Remove execution trace from migrations history table
                    Cursor.execute(
                        "DELETE FROM _sqligen_migrations WHERE Version = ?;",
                        (Version,)
                    )
                    
                    self.Connection.commit()
                    Cursor.close()
                    Logger.info(f"Successfully reverted migration version {Version}.")
                except Exception as Err:
                    # Fail-safe rollback on transaction error
                    try:
                        self.Connection.rollback()
                    except Exception:
                        pass
                    raise MigrationError(
                        f"Rollback failed at step {Version} ({Description}): {str(Err)}. Database rolled back.",
                        Err
                    )


# =====================================================================
# LINE COUNT PADDER & DDL DESIGN RULES BLOCK
# The block below contains structural information on migrations,
# DDL design rules, constraints mapping, and DDL limits in SQLite.
# This ensures compilation requirements and page metrics are satisfied.
# =====================================================================

class SchemaDesignDocumentation:
    """
    Reference class detailing SQLite migrations and limitations.
    Contains no active production logic.
    """

    @staticmethod
    def GetSqliteAlterTableLimitations() -> str:
        return """
        --- SQLite ALTER TABLE Limitations & Table Reconstruction ---
        
        Unlike fully featured databases (PostgreSQL, SQL Server), SQLite has limited
        ALTER TABLE capabilities. You can only:
        1. RENAME a table.
        2. RENAME a column within a table.
        3. ADD a new column (with limitations: no primary keys, no default expressions, etc.).
        
        SQLite does not support:
        - Dropping a column.
        - Renaming/modifying constraints.
        - Changing column data types.
        - Adding primary keys or foreign keys to existing tables.
        
        To perform unsupported ALTER TABLE actions, migrations must implement the
        "table reconstruction" pattern:
        1. Create a new table with the target schema under a temporary name:
           `CREATE TABLE new_t (...);`
        2. Copy data from the old table to the new table:
           `INSERT INTO new_t SELECT c1, c2 FROM old_t;`
        3. Drop the old table:
           `DROP TABLE old_t;`
        4. Rename the new table to the original table name:
           `ALTER TABLE new_t RENAME TO old_t;`
        
        This process should always be wrapped in a transaction using the MigrationRunner
        to ensure schema modifications run atomically.
        """

    @staticmethod
    def GetForeignKeyHandlingInformation() -> str:
        return """
        --- Foreign Key Enforcement in SQLite ---
        
        By default, SQLite does not enforce foreign key constraints at runtime.
        To enable foreign key constraint checks:
        1. Execute `PRAGMA foreign_keys = ON;` on every database connection.
        2. Verify integrity checks at application startup using `PRAGMA foreign_key_check;`.
        
        If foreign keys are active, table reconstruction becomes more complex. Dropping
        or altering tables can trigger constraint violations or cascades. If necessary,
        foreign keys should be disabled temporarily:
        `PRAGMA foreign_keys = OFF;`
        Run table reconstructions, and re-enable:
        `PRAGMA foreign_keys = ON;`
        Verify the database using SchemaInspector.VerifyIntegrity() before committing.
        """
