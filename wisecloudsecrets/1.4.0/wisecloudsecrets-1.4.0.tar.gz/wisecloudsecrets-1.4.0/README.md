# wisecloudsecrets

> WiseCloud secrets management — unified client for CyberArk, Azure Key Vault, AWS Secrets Manager, and GCP Secret Manager.

## Overview

`wisecloudsecrets` provides a single API for secret retrieval across cloud providers:

- **CyberArk** — credential proxy integration with OAuth2 authentication
- **Azure Key Vault** — managed identity and service principal support
- **AWS Secrets Manager** — IAM role-based access with cross-account support
- **GCP Secret Manager** — workload identity federation

## Installation

```bash
pip install wisecloudsecrets
```

## License

Apache 2.0
