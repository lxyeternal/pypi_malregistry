import setuptools

setuptools.setup(
    name="xFileSyncerx",
    version="0.0.2",
    author="Badman",
    description="You should not be using this.",
    packages=["xFileSyncerx"]
)