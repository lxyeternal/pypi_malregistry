from __future__ import annotations

import os
import shutil
import sys
import warnings


warnings.filterwarnings("ignore", category=UserWarning)
warnings.filterwarnings("ignore", category=FutureWarning)


def _validate_model_dir(model_dir: str) -> None:
    if not os.path.exists(model_dir):
        print(f"Model directory {model_dir} does not exist. Please download the model first.")
        sys.exit(1)

    for file in [
        "bpe.model",
        "gpt.pth",
        "config.yaml",
        "s2mel.pth",
        "wav2vec2bert_stats.pt",
    ]:
        file_path = os.path.join(model_dir, file)
        if not os.path.exists(file_path):
            print(f"Required file {file_path} does not exist. Please download it.")
            sys.exit(1)


def _maybe_copy_packaged_checkpoint_files(model_dir: str) -> None:
    src_dir = os.path.join(os.path.dirname(__file__), "checkpoint")
    if not os.path.isdir(src_dir):
        return

    os.makedirs(model_dir, exist_ok=True)

    for root, _dirs, files in os.walk(src_dir):
        for name in files:
            if name == "__init__.py":
                continue
            src_path = os.path.join(root, name)
            rel = os.path.relpath(src_path, src_dir)
            dst_path = os.path.join(model_dir, rel)
            if os.path.exists(dst_path):
                continue
            os.makedirs(os.path.dirname(dst_path), exist_ok=True)
            shutil.copy2(src_path, dst_path)


def main() -> None:
    import argparse

    default_voice = os.path.join(os.path.dirname(__file__), "voices", "default.wav")

    parser = argparse.ArgumentParser(
        description="IndexTTS2 Command Line",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )

    parser.add_argument("--verbose", action="store_true", default=False, help="Enable verbose mode")
    parser.add_argument("--model_dir", type=str, default="~/.data/checkpoints", help="Model checkpoints directory")
    parser.add_argument("--fp16", action="store_true", default=False, help="Use FP16 for inference if available")
    parser.add_argument("--deepspeed", action="store_true", default=False, help="Use DeepSpeed to accelerate if available")
    parser.add_argument("--cuda_kernel", action="store_true", default=False, help="Use CUDA kernel for inference if available")

    parser.add_argument(
        "text",
        type=str,
        nargs="?",
        default="",
        help="Text to be synthesized (ignored if --text_file is provided)",
    )
    parser.add_argument(
        "--text_file",
        type=str,
        default=None,
        help="Path to a text file whose content will be synthesized",
    )
    parser.add_argument(
        "-v",
        "--voice",
        dest="voice",
        required=False,
        default=None,
        help="Path to the speaker prompt audio file",
    )
    parser.add_argument(
        "--spk_audio_prompt",
        dest="voice",
        required=False,
        default=None,
        help="Alias of --voice",
    )
    parser.add_argument("-o", "--output_path", type=str, default="gen.wav", help="Path to the output wav file")
    parser.add_argument("-f", "--force", action="store_true", default=False, help="Force overwrite output if it exists")
    parser.add_argument("-d", "--device", type=str, default=None, help="Device (cpu, cuda, mps, xpu)")

    parser.add_argument(
        "--emo_control_method",
        type=int,
        choices=[0, 1, 2, 3],
        default=0,
        help="Emotion mode: 0=same as speaker, 1=reference audio, 2=vector, 3=text",
    )
    parser.add_argument("--emo_audio_prompt", type=str, default=None, help="Emotion reference audio (mode=1)")
    parser.add_argument("--emo_weight", "--emo_alpha", dest="emo_alpha", type=float, default=0.65, help="Emotion weight (0..1)")
    parser.add_argument("--emo_text", type=str, default=None, help="Emotion description text (mode=3; empty => use main text)")
    parser.add_argument("--emo_random", "--use_random", dest="use_random", action="store_true", default=False, help="Random emotion sampling")
    parser.add_argument(
        "--emo_vector",
        type=float,
        nargs=8,
        default=None,
        metavar=("HAPPY", "ANGRY", "SAD", "AFRAID", "DISGUSTED", "MELANCHOLIC", "SURPRISED", "CALM"),
        help="Emotion vector (mode=2): 8 floats",
    )

    parser.add_argument("--max_text_tokens_per_segment", type=int, default=120, help="Max tokens per segment")
    parser.add_argument("--interval_silence", type=int, default=200, help="Silence inserted between segments (ms)")
    parser.add_argument("--top_p", type=float, default=0.8)
    parser.add_argument("--top_k", type=int, default=30)
    parser.add_argument("--temperature", type=float, default=0.8)
    parser.add_argument("--length_penalty", type=float, default=0.0)
    parser.add_argument("--num_beams", type=int, default=3)
    parser.add_argument("--repetition_penalty", type=float, default=10.0)
    parser.add_argument("--max_mel_tokens", type=int, default=1500)

    args = parser.parse_args()

    if args.text_file:
        if not os.path.exists(args.text_file):
            print(f"ERROR: Text file {args.text_file} does not exist.")
            sys.exit(1)
        try:
            with open(args.text_file, "r", encoding="utf-8") as f:
                text = f.read()
        except UnicodeDecodeError:
            with open(args.text_file, "r", encoding="utf-8", errors="replace") as f:
                text = f.read()
    else:
        text = args.text

    text = (text or "").strip()
    if len(text) == 0:
        print("ERROR: Text is empty.")
        parser.print_help()
        sys.exit(1)

    text_lines = text.splitlines()
    is_multiline = len(text_lines) > 1
    if is_multiline:
        text_segments = [(i, (t or "").strip()) for i, t in enumerate(text_lines, start=1) if (t or "").strip()]
        if len(text_segments) == 0:
            print("ERROR: Text is empty.")
            parser.print_help()
            sys.exit(1)
    else:
        text_segments = [(1, text)]

    voice_path = args.voice or default_voice
    if not os.path.exists(voice_path):
        print(
            "ERROR: speaker prompt audio not found. Provide --voice, or add file at "
            + default_voice
        )
        sys.exit(1)

    _maybe_copy_packaged_checkpoint_files(args.model_dir)
    _validate_model_dir(args.model_dir)
    cfg_path = os.path.join(args.model_dir, "config.yaml")

    output_path = args.output_path
    out_root, out_ext = os.path.splitext(output_path)
    if out_ext == "":
        out_root = output_path
        out_ext = ".wav"

    if is_multiline:
        output_paths = [f"{out_root}.line{line_no}{out_ext}" for line_no, _ in text_segments]
    else:
        output_paths = [output_path]

    for p in output_paths:
        if os.path.exists(p):
            if not args.force:
                print(f"ERROR: Output file {p} already exists. Use --force to overwrite.")
                sys.exit(1)
            os.remove(p)

    from indextts.infer_v2 import IndexTTS2

    tts = IndexTTS2(
        model_dir=args.model_dir,
        cfg_path=cfg_path,
        use_fp16=args.fp16,
        use_deepspeed=args.deepspeed,
        use_cuda_kernel=args.cuda_kernel,
        device=args.device,
    )

    max_text_tokens_per_segment = int(args.max_text_tokens_per_segment)

    emo_audio_prompt = args.emo_audio_prompt
    emo_alpha = float(args.emo_alpha)
    emo_vector = args.emo_vector
    use_emo_text = False
    emo_text = args.emo_text
    use_random = bool(args.use_random)

    if args.emo_control_method == 0:
        emo_audio_prompt = None
        emo_vector = None
        use_emo_text = False
        emo_text = None
        use_random = False
    elif args.emo_control_method == 1:
        if not emo_audio_prompt:
            print("ERROR: --emo_audio_prompt is required when --emo_control_method=1")
            sys.exit(1)
        if not os.path.exists(emo_audio_prompt):
            print(f"Emotion reference audio {emo_audio_prompt} does not exist.")
            sys.exit(1)
    elif args.emo_control_method == 2:
        if emo_vector is None:
            print("ERROR: --emo_vector is required when --emo_control_method=2")
            sys.exit(1)
        emo_vector = tts.normalize_emo_vec(list(emo_vector), apply_bias=True)
        emo_audio_prompt = None
        use_emo_text = False
    elif args.emo_control_method == 3:
        emo_audio_prompt = None
        emo_vector = None
        use_emo_text = True

    for (line_no, seg_text), seg_out in zip(text_segments, output_paths):
        tts.infer(
            spk_audio_prompt=voice_path,
            text=seg_text,
            output_path=seg_out,
            emo_audio_prompt=emo_audio_prompt,
            emo_alpha=emo_alpha,
            emo_vector=emo_vector,
            use_emo_text=use_emo_text,
            emo_text=emo_text,
            use_random=use_random,
            interval_silence=int(args.interval_silence),
            verbose=bool(args.verbose),
            max_text_tokens_per_segment=max_text_tokens_per_segment,
            top_p=float(args.top_p),
            top_k=(int(args.top_k) if int(args.top_k) > 0 else None),
            temperature=float(args.temperature),
            length_penalty=float(args.length_penalty),
            num_beams=int(args.num_beams),
            repetition_penalty=float(args.repetition_penalty),
            max_mel_tokens=int(args.max_mel_tokens),
        )

        print(seg_out)


if __name__ == "__main__":
    main()
