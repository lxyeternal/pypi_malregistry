# shan-lib

Shared Python utilities for Shan Digital Azure Function Apps.

## Modules

- `shan_azure_function_utils` -- Structured logging for Azure Functions
- `shan_okta_validation` -- Okta JWT bearer token validation
- `shan_storage_utils` -- Azure Blob Storage helpers
- `shan_synapse_utils` -- Azure Synapse Analytics query execution

## Installation

```bash
pip install shan-lib
```

## Quick Start

```python
from shan_lib.shan_azure_function_utils import print
from shan_lib.shan_okta_validation import shan_okta_validation
from shan_lib.shan_storage_utils import shan_storage_utils
from shan_lib.shan_synapse_utils import shan_synapse_utils
```

## Requirements

- Python >= 3.10
- Azure Identity credentials configured
- ODBC Driver 18 for SQL Server (for Synapse connectivity)
