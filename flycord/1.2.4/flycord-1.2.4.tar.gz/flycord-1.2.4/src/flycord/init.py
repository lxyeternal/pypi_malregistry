from .lookup import sorgu

__version__ = "1.2.4"
__all__ = ["sorgu"]