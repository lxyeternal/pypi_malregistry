"""Auto-apply overlay on interpreter startup (triggered by clearml_truen_patch.pth).

Delegates to _install.needs_apply() which checks clearml version, patch
version, and source fingerprint. Only copies files when something changed.
"""
import sys


def _safe_apply():
    try:
        from clearml_truen_patch._install import (
            run, needs_apply, _find_clearml_dir, _source_dir,
        )
        dst = _find_clearml_dir()
        src = _source_dir()
        if needs_apply(dst, src):
            run(force=True)
    except SystemExit:
        # _install exits on version mismatch; swallow to protect the host process.
        pass
    except Exception as e:
        sys.stderr.write(f"[clearml-truen-patch] auto-apply skipped: {e}\n")


_safe_apply()
