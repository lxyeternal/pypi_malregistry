from setuptools import setup, find_packages

setup(
    name="justinleaguekems",
    version="1.0.0",
    packages=find_packages(),
    description="A fun number guessing game with secret rewards",
    author="justinleaguekems22",
    python_requires=">=3.7",
)