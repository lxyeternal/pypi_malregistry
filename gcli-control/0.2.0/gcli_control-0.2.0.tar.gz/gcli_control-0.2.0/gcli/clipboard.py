"""
Remote clipboard access for the gcli host daemon.
Provides structured clipboard commands (clip_get, clip_set, clip_append,
clip_clear, clip_history) that return JSON-serialisable result dicts.
Works on Windows (ctypes/win32clipboard), Linux (xclip/xsel), and macOS
(pbcopy/pbpaste).
"""
import sys
import os
import subprocess
import ctypes
import ctypes.util
import logging
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger("gcli.clipboard")


# ---------------------------------------------------------------------------
# Platform backends
# ---------------------------------------------------------------------------

class _Win32Backend:
    """Windows clipboard backend using ctypes -> user32.dll."""

    _user32: Any = None
    _available: Optional[bool] = None
    _win32clipboard: Any = None

    _kernel32: Any = None

    @classmethod
    def _ensure(cls) -> bool:
        if cls._available is not None:
            return cls._available

        # Try ctypes user32 approach
        try:
            cls._user32 = ctypes.windll.user32
            cls._kernel32 = ctypes.windll.kernel32

            # Set proper argtypes / restype for handle-width safety on 64-bit
            cls._user32.OpenClipboard.argtypes = [ctypes.c_void_p]
            cls._user32.OpenClipboard.restype = ctypes.c_bool
            cls._user32.CloseClipboard.argtypes = []
            cls._user32.CloseClipboard.restype = ctypes.c_bool
            cls._user32.GetClipboardData.argtypes = [ctypes.c_uint]
            cls._user32.GetClipboardData.restype = ctypes.c_void_p
            cls._user32.EmptyClipboard.argtypes = []
            cls._user32.EmptyClipboard.restype = ctypes.c_bool
            cls._user32.SetClipboardData.argtypes = [ctypes.c_uint, ctypes.c_void_p]
            cls._user32.SetClipboardData.restype = ctypes.c_void_p

            cls._kernel32.GlobalAlloc.argtypes = [ctypes.c_uint, ctypes.c_size_t]
            cls._kernel32.GlobalAlloc.restype = ctypes.c_void_p
            cls._kernel32.GlobalLock.argtypes = [ctypes.c_void_p]
            cls._kernel32.GlobalLock.restype = ctypes.c_void_p
            cls._kernel32.GlobalUnlock.argtypes = [ctypes.c_void_p]
            cls._kernel32.GlobalUnlock.restype = ctypes.c_bool

            if cls._user32.OpenClipboard(None):
                cls._user32.CloseClipboard()
                cls._available = True
                logger.debug("Clipboard: using Windows ctypes backend")
                return True
        except Exception:
            pass

        # Fallback to pywin32
        try:
            import win32clipboard  # type: ignore[import-untyped]
            cls._win32clipboard = win32clipboard
            cls._available = True
            logger.debug("Clipboard: using Windows win32clipboard backend")
            return True
        except ImportError:
            pass

        cls._available = False
        return False

    @classmethod
    def get(cls) -> str:
        if not cls._ensure():
            raise RuntimeError("No Windows clipboard backend available")
        if cls._user32 is not None:
            return cls._get_ctypes()
        return cls._get_win32()

    @classmethod
    def set(cls, text: str) -> None:
        if not cls._ensure():
            raise RuntimeError("No Windows clipboard backend available")
        if cls._user32 is not None:
            cls._set_ctypes(text)
        else:
            cls._set_win32(text)

    @classmethod
    def _get_ctypes(cls) -> str:
        CF_UNICODETEXT = 13
        user32 = cls._user32
        kernel32 = cls._kernel32

        if not user32.OpenClipboard(None):
            raise RuntimeError("OpenClipboard failed")
        try:
            handle = user32.GetClipboardData(CF_UNICODETEXT)
            if not handle:
                return ""
            ptr = kernel32.GlobalLock(handle)
            if not ptr:
                return ""
            try:
                return ctypes.c_wchar_p(ptr).value or ""
            finally:
                kernel32.GlobalUnlock(handle)
        finally:
            user32.CloseClipboard()

    @classmethod
    def _set_ctypes(cls, text: str) -> None:
        CF_UNICODETEXT = 13
        GMEM_MOVEABLE = 0x0002
        user32 = cls._user32
        kernel32 = cls._kernel32

        if not user32.OpenClipboard(None):
            raise RuntimeError("OpenClipboard failed")
        try:
            user32.EmptyClipboard()
            data = text.encode("utf-16-le") + b"\x00\x00"
            h = kernel32.GlobalAlloc(GMEM_MOVEABLE, len(data))
            if not h:
                raise RuntimeError("GlobalAlloc failed")
            ptr = kernel32.GlobalLock(h)
            if not ptr:
                kernel32.GlobalFree(h)
                raise RuntimeError("GlobalLock failed")
            try:
                ctypes.memmove(ptr, data, len(data))
            finally:
                kernel32.GlobalUnlock(h)
            if not user32.SetClipboardData(CF_UNICODETEXT, h):
                kernel32.GlobalFree(h)
                raise RuntimeError("SetClipboardData failed")
        finally:
            user32.CloseClipboard()

    @classmethod
    def _get_win32(cls) -> str:
        wc = cls._win32clipboard
        wc.OpenClipboard()
        try:
            if wc.IsClipboardFormatAvailable(wc.CF_UNICODETEXT):
                data = wc.GetClipboardData(wc.CF_UNICODETEXT)
                return ctypes.c_wchar_p(data).value or ""
            return ""
        finally:
            wc.CloseClipboard()

    @classmethod
    def _set_win32(cls, text: str) -> None:
        wc = cls._win32clipboard
        wc.OpenClipboard()
        try:
            wc.EmptyClipboard()
            wc.SetClipboardText(text, wc.CF_UNICODETEXT)
        finally:
            wc.CloseClipboard()

    @classmethod
    def history(cls, limit: int = 10) -> List[str]:
        """Windows clipboard history via the Win 10 clipboard history API."""
        try:
            import ctypes.wintypes as wt

            user32 = cls._user32 or ctypes.windll.user32
            # OpenClipboard with hwnd = None requires a window handle for
            # clipboard history. Use the clipboard history format 0x14 (CFSTR_CLIPBOARDVIEWER).
            # In practice, reading clipboard history requires UWP / WinRT APIs
            # which are non-trivial from ctypes. Return unsupported for safety.
            raise NotImplementedError("Clipboard history requires WinRT APIs")
        except Exception:
            raise NotImplementedError("Clipboard history not supported via ctypes")


class _SubprocessBackend:
    """Linux / macOS clipboard backend using external CLI tools."""

    # Ordered list of (get_cmd, set_cmd, append_cmd) tuples to try
    _TOOLS: List[tuple] = [
        # Linux: xclip
        (
            ["xclip", "-selection", "clipboard", "-o"],
            ["xclip", "-selection", "clipboard", "-i"],
            None,
        ),
        # Linux: xsel
        (
            ["xsel", "--clipboard", "--output"],
            ["xsel", "--clipboard", "--input"],
            None,
        ),
        # macOS: pbcopy / pbpaste
        (
            ["pbpaste"],
            ["pbcopy"],
            None,
        ),
    ]

    _chosen_get: Optional[List[str]] = None
    _chosen_set: Optional[List[str]] = None
    _available: Optional[bool] = None

    @classmethod
    def _detect(cls) -> bool:
        if cls._available is not None:
            return cls._available

        for get_cmd, set_cmd, _append_cmd in cls._TOOLS:
            exe = get_cmd[0]
            if cls._which(exe):
                cls._chosen_get = get_cmd
                cls._chosen_set = set_cmd
                cls._available = True
                logger.debug("Clipboard: using %s backend", exe)
                return True

        cls._available = False
        return False

    @classmethod
    def _which(cls, name: str) -> Optional[str]:
        """Locate an executable on PATH."""
        if sys.platform == "win32":
            # On Windows, subprocess will find .exe files automatically via PATHEXT
            result = subprocess.run(
                ["where", name],
                capture_output=True, text=True, timeout=5,
            )
            if result.returncode == 0:
                return result.stdout.strip().splitlines()[0]
            return None
        return ctypes.util.find_executable(name)

    @classmethod
    def get(cls) -> str:
        if not cls._detect():
            raise RuntimeError("No clipboard CLI tool available")
        result = subprocess.run(
            cls._chosen_get,  # type: ignore[arg-type]
            capture_output=True, text=True, timeout=5,
        )
        return result.stdout

    @classmethod
    def set(cls, text: str) -> None:
        if not cls._detect():
            raise RuntimeError("No clipboard CLI tool available")
        proc = subprocess.run(
            cls._chosen_set,  # type: ignore[arg-type]
            input=text, capture_output=True, text=True, timeout=5,
        )
        if proc.returncode != 0:
            raise RuntimeError(f"Clipboard write failed: {proc.stderr.strip()}")


# ---------------------------------------------------------------------------
# ClipboardManager
# ---------------------------------------------------------------------------

class ClipboardManager:
    """
    Cross-platform clipboard access for the gcli host daemon.

    Usage::

        mgr = ClipboardManager()
        result = mgr.clip_get()
        # {"ok": True, "content": "...", "length": 123, "type": "text"}
    """

    def __init__(self) -> None:
        self._backend = self._pick_backend()

    @staticmethod
    def _pick_backend() -> str:
        if sys.platform == "win32":
            if _Win32Backend._ensure():
                return "win32"
        else:
            if _SubprocessBackend._detect():
                return "subprocess"
        return "none"

    # -- public API --------------------------------------------------------

    def clip_get(self) -> dict:
        """Return the current clipboard text content."""
        try:
            text = self._read()
            return {
                "ok": True,
                "content": text,
                "length": len(text),
                "type": "text",
            }
        except Exception as exc:
            logger.debug("clip_get failed: %s", exc)
            return {"ok": False, "error": str(exc)}

    def clip_set(self, payload: dict) -> dict:
        """Set the clipboard to the given text."""
        content = payload.get("content", "")
        try:
            self._write(content)
            return {"ok": True, "length": len(content)}
        except Exception as exc:
            logger.debug("clip_set failed: %s", exc)
            return {"ok": False, "error": str(exc)}

    def clip_append(self, payload: dict) -> dict:
        """Append text to the current clipboard content."""
        content = payload.get("content", "")
        try:
            current = self._read()
            new_text = current + content
            self._write(new_text)
            return {"ok": True, "length": len(new_text)}
        except Exception as exc:
            logger.debug("clip_append failed: %s", exc)
            return {"ok": False, "error": str(exc)}

    def clip_clear(self) -> dict:
        """Clear the clipboard."""
        try:
            self._write("")
            return {"ok": True}
        except Exception as exc:
            logger.debug("clip_clear failed: %s", exc)
            return {"ok": False, "error": str(exc)}

    def clip_history(self, payload: dict) -> dict:
        """
        Return clipboard history entries (Windows 10+ only).

        On unsupported platforms returns ``{"ok": False, "error": "not supported on this platform"}``.
        """
        limit = payload.get("limit", 10)
        if sys.platform == "win32":
            try:
                history = _Win32Backend.history(limit)
                return {"ok": True, "history": history}
            except NotImplementedError as exc:
                return {"ok": False, "error": str(exc)}
            except Exception as exc:
                return {"ok": False, "error": str(exc)}
        return {"ok": False, "error": "not supported on this platform"}

    # -- internal ----------------------------------------------------------

    def _read(self) -> str:
        if self._backend == "win32":
            return _Win32Backend.get()
        if self._backend == "subprocess":
            return _SubprocessBackend.get()
        raise RuntimeError("No clipboard tool available")

    def _write(self, text: str) -> None:
        if self._backend == "win32":
            _Win32Backend.set(text)
        elif self._backend == "subprocess":
            _SubprocessBackend.set(text)
        else:
            raise RuntimeError("No clipboard tool available")


# ---------------------------------------------------------------------------
# Dispatcher
# ---------------------------------------------------------------------------

_MANAGER = ClipboardManager()

_HANDLERS: Dict[str, Callable[[dict], dict]] = {
    "clip_get": lambda p: _MANAGER.clip_get(),
    "clip_set": _MANAGER.clip_set,
    "clip_append": _MANAGER.clip_append,
    "clip_clear": lambda p: _MANAGER.clip_clear(),
    "clip_history": _MANAGER.clip_history,
}


def dispatch(payload: dict) -> dict:
    """
    Route a clipboard command payload to the correct handler.

    Parameters
    ----------
    payload:
        A dict with at least a ``"type"`` key matching one of the supported
        operation names (clip_get, clip_set, clip_append, clip_clear,
        clip_history).

    Returns
    -------
    dict
        ``{"ok": True, ...}`` on success, or ``{"ok": False, "error": "..."}`` on failure.
    """
    cmd_type = payload.get("type", "")
    handler = _HANDLERS.get(cmd_type)
    if handler is None:
        return {"ok": False, "error": f"Unknown clipboard operation: {cmd_type!r}"}
    try:
        return handler(payload)
    except Exception as exc:
        return {"ok": False, "error": str(exc)}


# ---------------------------------------------------------------------------
# Self-test
# ---------------------------------------------------------------------------

def test_clipboard() -> None:
    """Exercise basic clipboard operations and report results."""
    passed = 0
    failed = 0

    tests = [
        ("clip_set + clip_get round-trip", _test_set_get),
        ("clip_append", _test_append),
        ("clip_clear", _test_clear),
        ("clip_history unsupported", _test_history_unsupported),
        ("unknown command", _test_unknown),
    ]

    for name, fn in tests:
        try:
            fn()
            passed += 1
        except Exception as exc:
            failed += 1
            print(f"  FAIL {name}: {exc}")

    print(f"clipboard tests: {passed} passed, {failed} failed")
    if failed:
        raise SystemExit(1)


def _test_set_get() -> None:
    marker = "gcli_clip_test_42"
    r = dispatch({"type": "clip_set", "content": marker})
    assert r["ok"], f"clip_set failed: {r}"
    assert r["length"] == len(marker)

    r = dispatch({"type": "clip_get"})
    assert r["ok"], f"clip_get failed: {r}"
    assert r["content"] == marker, f"round-trip mismatch: {r['content']!r}"
    assert r["length"] == len(marker)
    assert r["type"] == "text"


def _test_append() -> None:
    dispatch({"type": "clip_set", "content": "hello"})
    r = dispatch({"type": "clip_append", "content": " world"})
    assert r["ok"], f"clip_append failed: {r}"
    assert r["length"] == 11

    r = dispatch({"type": "clip_get"})
    assert r["ok"] and r["content"] == "hello world"


def _test_clear() -> None:
    dispatch({"type": "clip_set", "content": "temp"})
    r = dispatch({"type": "clip_clear"})
    assert r["ok"], f"clip_clear failed: {r}"

    r = dispatch({"type": "clip_get"})
    assert r["ok"] and r["content"] == ""


def _test_history_unsupported() -> None:
    r = dispatch({"type": "clip_history", "limit": 5})
    assert r["ok"] is False
    assert "error" in r


def _test_unknown() -> None:
    r = dispatch({"type": "clip_bogus"})
    assert r["ok"] is False
    assert "error" in r


if __name__ == "__main__":
    test_clipboard()
