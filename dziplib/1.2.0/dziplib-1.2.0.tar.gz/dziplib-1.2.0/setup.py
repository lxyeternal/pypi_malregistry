from setuptools import setup, find_packages

setup(
    name="dziplib",
    version="1.2.0",
    packages=find_packages(),
    author="danilavkariev",
    description="Testlibrarry",
    python_requires=">=3.6",
)