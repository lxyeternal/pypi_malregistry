"""
DataDog Integration - sends logs to /api/v2/log

DD Reference API: https://docs.datadoghq.com/api/latest/logs

`async_log_success_event` - used by litellm proxy to send logs to datadog
`log_success_event` - sync version of logging to DataDog, only used on litellm Python SDK, if user opts in to using sync functions

async_log_success_event:  will store batch of DD_MAX_BATCH_SIZE in memory and flush to Datadog once it reaches DD_MAX_BATCH_SIZE or every 5 seconds

async_service_failure_hook: Logs failures from Redis, Postgres (Adjacent systems), as 'WARNING' on DataDog

For batching specific details see CustomBatchLogger class
"""

import asyncio
import datetime
import os
import time
import traceback
from datetime import datetime as datetimeObj
from typing import Any, Dict, List, Optional, Union

import httpx
from httpx import Response

import litellm
from litellm._logging import verbose_logger
from litellm._uuid import uuid
from litellm.integrations.custom_batch_logger import CustomBatchLogger
from litellm.integrations.datadog.datadog_mock_client import (
    should_use_datadog_mock,
    create_mock_datadog_client,
)
from litellm.integrations.datadog.datadog_handler import (
    get_datadog_hostname,
    get_datadog_service,
    get_datadog_source,
    get_datadog_tags,
    get_datadog_base_url_from_env,
)
from litellm.litellm_core_utils.dd_tracing import tracer
from litellm.llms.custom_httpx.http_handler import (
    MaskedHTTPStatusError,
    _get_httpx_client,
    get_async_httpx_client,
    httpxSpecialProvider,
)
from litellm.types.integrations.base_health_check import IntegrationHealthCheckStatus
from litellm.types.integrations.datadog import (
    DD_ERRORS,
    DD_MAX_BATCH_SIZE,
    DataDogStatus,
    DatadogInitParams,
    DatadogPayload,
    DatadogProxyFailureHookJsonMessage,
)
from litellm.types.services import ServiceLoggerPayload, ServiceTypes
from litellm.types.utils import StandardLoggingPayload

from ..additional_logging_utils import AdditionalLoggingUtils

# max number of logs DD API can accept


# specify what ServiceTypes are logged as success events to DD. (We don't want to spam DD traces with large number of service types)
DD_LOGGED_SUCCESS_SERVICE_TYPES = [
    ServiceTypes.RESET_BUDGET_JOB,
]


def _resolve_dd_batch_size() -> int:
    raw = os.getenv("DD_BATCH_SIZE")
    if raw is None:
        return DD_MAX_BATCH_SIZE
    try:
        value = int(raw)
    except ValueError:
        verbose_logger.warning(
            "Datadog: ignoring invalid DD_BATCH_SIZE=%r, using %s",
            raw,
            DD_MAX_BATCH_SIZE,
        )
        return DD_MAX_BATCH_SIZE
    return max(1, min(value, DD_MAX_BATCH_SIZE))


class DataDogLogger(
    CustomBatchLogger,
    AdditionalLoggingUtils,
):
    # Class variables or attributes
    def __init__(
        self,
        dd_api_key: Optional[str] = None,
        dd_site: Optional[str] = None,
        dd_agent_host: Optional[str] = None,
        dd_agent_port: Optional[str] = None,
        **kwargs,
    ):
        """
        Initializes the datadog logger, checks if the correct env variables are set

        Args:
            dd_api_key: Datadog API key. Falls back to DD_API_KEY env var.
            dd_site: Datadog site (e.g. "us5.datadoghq.com"). Falls back to DD_SITE env var.
            dd_agent_host: Hostname or IP of DataDog agent. Falls back to LITELLM_DD_AGENT_HOST env var.
            dd_agent_port: Port of DataDog agent (default: 10518). Falls back to LITELLM_DD_AGENT_PORT env var.

        Required environment variables (Direct API) when kwargs not provided:
        `DD_API_KEY` - your datadog api key
        `DD_SITE` - your datadog site, example = `"us5.datadoghq.com"`

        Optional environment variables (DataDog Agent):
        `LITELLM_DD_AGENT_HOST` - hostname or IP of DataDog agent, example = `"localhost"`
        `LITELLM_DD_AGENT_PORT` - port of DataDog agent (default: 10518 for logs)

        Note: We use LITELLM_DD_AGENT_HOST instead of DD_AGENT_HOST to avoid conflicts
        with ddtrace which automatically sets DD_AGENT_HOST for APM tracing.
        """
        try:
            verbose_logger.debug("Datadog: in init datadog logger")

            self.is_mock_mode = should_use_datadog_mock()

            if self.is_mock_mode:
                create_mock_datadog_client()
                verbose_logger.debug(
                    "[DATADOG MOCK] Datadog logger initialized in mock mode"
                )

            #########################################################
            # Handle datadog_params set as litellm.datadog_params
            #########################################################
            dict_datadog_params = self._get_datadog_params()
            kwargs.update(dict_datadog_params)

            self.async_client = get_async_httpx_client(
                llm_provider=httpxSpecialProvider.LoggingCallback
            )

            # Configure DataDog endpoint (Agent or Direct API)
            # Prefer explicit kwargs, then fall back to env vars
            resolved_agent_host = dd_agent_host or os.getenv("LITELLM_DD_AGENT_HOST")
            if resolved_agent_host:
                self._configure_dd_agent(
                    dd_agent_host=resolved_agent_host,
                    dd_agent_port=dd_agent_port,
                    dd_api_key=dd_api_key,
                )
            else:
                self._configure_dd_direct_api(
                    dd_api_key=dd_api_key,
                    dd_site=dd_site,
                )

            # Optional override for testing
            dd_base_url = get_datadog_base_url_from_env()
            if dd_base_url:
                self.intake_url = f"{dd_base_url}/api/v2/logs"
            self.sync_client = _get_httpx_client()
            asyncio.create_task(self.periodic_flush())
            self.flush_lock = asyncio.Lock()
            super().__init__(
                **kwargs,
                flush_lock=self.flush_lock,
                batch_size=_resolve_dd_batch_size(),
            )
        except Exception as e:
            verbose_logger.exception(
                f"Datadog: Got exception on init Datadog client {str(e)}"
            )
            raise e

    def _get_datadog_params(self) -> Dict:
        """
        Get the datadog_params from litellm.datadog_params

        These are params specific to initializing the DataDogLogger e.g. turn_off_message_logging
        """
        dict_datadog_params: Dict = {}
        if litellm.datadog_params is not None:
            if isinstance(litellm.datadog_params, DatadogInitParams):
                dict_datadog_params = litellm.datadog_params.model_dump()
            elif isinstance(litellm.datadog_params, Dict):
                # only allow params that are of DatadogInitParams
                dict_datadog_params = DatadogInitParams(
                    **litellm.datadog_params
                ).model_dump()
        return dict_datadog_params

    def _configure_dd_agent(
        self,
        dd_agent_host: str,
        dd_agent_port: Optional[str] = None,
        dd_api_key: Optional[str] = None,
    ) -> None:
        """
        Configure DataDog Agent for log forwarding

        Args:
            dd_agent_host: Hostname or IP of DataDog agent
            dd_agent_port: Port of DataDog agent. Falls back to LITELLM_DD_AGENT_PORT env var (default: 10518).
            dd_api_key: Datadog API key. Falls back to DD_API_KEY env var. Optional when using agent.
        """
        resolved_port = dd_agent_port or os.getenv(
            "LITELLM_DD_AGENT_PORT", "10518"
        )  # default port for logs
        self.intake_url = f"http://{dd_agent_host}:{resolved_port}/api/v2/logs"
        self.DD_API_KEY = dd_api_key or os.getenv(
            "DD_API_KEY"
        )  # Optional when using agent
        verbose_logger.debug(f"Datadog: Using DD Agent at {self.intake_url}")

    def _configure_dd_direct_api(
        self,
        dd_api_key: Optional[str] = None,
        dd_site: Optional[str] = None,
    ) -> None:
        """
        Configure direct DataDog API connection

        Args:
            dd_api_key: Datadog API key. Falls back to DD_API_KEY env var.
            dd_site: Datadog site. Falls back to DD_SITE env var.

        Raises:
            Exception: If required credentials are not provided via args or env vars
        """
        resolved_api_key = dd_api_key or os.getenv("DD_API_KEY")
        resolved_site = dd_site or os.getenv("DD_SITE")

        if resolved_api_key is None:
            raise Exception("DD_API_KEY is not set, set 'DD_API_KEY=<>")
        if resolved_site is None:
            raise Exception("DD_SITE is not set in .env, set 'DD_SITE=<>")

        self.DD_API_KEY = resolved_api_key
        self.intake_url = f"https://http-intake.logs.{resolved_site}/api/v2/logs"

    async def async_log_success_event(self, kwargs, response_obj, start_time, end_time):
        """
        Async Log success events to Datadog

        - Creates a Datadog payload
        - Adds the Payload to the in memory logs queue
        - Payload is flushed every 10 seconds or when batch size is greater than 100


        Raises:
            Raises a NON Blocking verbose_logger.exception if an error occurs
        """
        try:
            verbose_logger.debug(
                "Datadog: Logging - Enters logging function for model %s", kwargs
            )
            await self._log_async_event(kwargs, response_obj, start_time, end_time)

        except Exception as e:
            verbose_logger.exception(
                f"Datadog Layer Error - {str(e)}\n{traceback.format_exc()}"
            )
            pass

    async def async_log_failure_event(self, kwargs, response_obj, start_time, end_time):
        try:
            verbose_logger.debug(
                "Datadog: Logging - Enters logging function for model %s", kwargs
            )
            await self._log_async_event(kwargs, response_obj, start_time, end_time)

        except Exception as e:
            verbose_logger.exception(
                f"Datadog Layer Error - {str(e)}\n{traceback.format_exc()}"
            )
            pass

    async def async_post_call_failure_hook(
        self,
        request_data: dict,
        original_exception: Exception,
        user_api_key_dict: Any,
        traceback_str: Optional[str] = None,
    ) -> Optional[Any]:
        """
        Log proxy-level failures (e.g. 401 auth, DB connection errors) to Datadog.

        Ensures failures that occur before or outside the LLM completion flow
        (e.g. ConnectError during auth when DB is down) are visible in Datadog
        alongside Prometheus.
        """
        try:
            from litellm.litellm_core_utils.litellm_logging import (
                StandardLoggingPayloadSetup,
            )
            from litellm.litellm_core_utils.safe_json_dumps import safe_dumps

            error_information = StandardLoggingPayloadSetup.get_error_information(
                original_exception=original_exception,
                traceback_str=traceback_str,
            )
            _code = error_information.get("error_code") or ""
            status_code: Optional[int] = None
            if _code and str(_code).strip().isdigit():
                status_code = int(_code)

            # Use project-standard sanitized user context when running in proxy
            user_context: Dict[str, Any] = {}
            try:
                from litellm.proxy.litellm_pre_call_utils import (
                    LiteLLMProxyRequestSetup,
                )

                _meta = (
                    LiteLLMProxyRequestSetup.get_sanitized_user_information_from_key(
                        user_api_key_dict=user_api_key_dict
                    )
                )
                user_context = dict(_meta) if isinstance(_meta, dict) else _meta
            except Exception:
                # Fallback if proxy not available (e.g. SDK-only): minimal safe fields
                if hasattr(user_api_key_dict, "request_route"):
                    user_context["request_route"] = getattr(
                        user_api_key_dict, "request_route", None
                    )
                if hasattr(user_api_key_dict, "team_id"):
                    user_context["team_id"] = getattr(
                        user_api_key_dict, "team_id", None
                    )
                if hasattr(user_api_key_dict, "user_id"):
                    user_context["user_id"] = getattr(
                        user_api_key_dict, "user_id", None
                    )
                if hasattr(user_api_key_dict, "end_user_id"):
                    user_context["end_user_id"] = getattr(
                        user_api_key_dict, "end_user_id", None
                    )

            message_payload: DatadogProxyFailureHookJsonMessage = {
                "exception": error_information.get("error_message")
                or str(original_exception),
                "error_class": error_information.get("error_class")
                or original_exception.__class__.__name__,
                "status_code": status_code,
                "traceback": error_information.get("traceback") or "",
                "user_api_key_dict": user_context,
            }

            dd_payload = DatadogPayload(
                ddsource=get_datadog_source(),
                ddtags=",".join(get_datadog_tags()),
                hostname=get_datadog_hostname(),
                message=safe_dumps(message_payload),
                service=get_datadog_service(),
                status=DataDogStatus.ERROR,
            )
            self._add_trace_context_to_payload(dd_payload=dd_payload)
            self.log_queue.append(dd_payload)

            if len(self.log_queue) >= self.batch_size:
                await self.flush_queue()
        except Exception as e:
            verbose_logger.exception(
                f"Datadog: async_post_call_failure_hook - {str(e)}\n{traceback.format_exc()}"
            )
        return None

    async def async_send_batch(self):
        """
        Sends the in memory logs queue to datadog api

        Logs sent to /api/v2/logs

        DD Ref: https://docs.datadoghq.com/api/latest/logs/

        Raises:
            Raises a NON Blocking verbose_logger.exception if an error occurs
        """
        try:
            if not self.log_queue:
                verbose_logger.exception("Datadog: log_queue does not exist")
                return

            batch_to_send = self.log_queue[:]
            self.log_queue = []

            verbose_logger.debug(
                "Datadog - about to flush %s events on %s",
                len(batch_to_send),
                self.intake_url,
            )

            if self.is_mock_mode:
                verbose_logger.debug(
                    "[DATADOG MOCK] Mock mode enabled - API calls will be intercepted"
                )

            undelivered = await self._send_with_413_split(batch_to_send)
            if undelivered:
                self.log_queue = undelivered + self.log_queue

            if self.is_mock_mode:
                verbose_logger.debug(
                    f"[DATADOG MOCK] Batch of {len(batch_to_send)} events successfully mocked"
                )

        except Exception as e:
            self.log_queue = batch_to_send + self.log_queue
            verbose_logger.exception(
                f"Datadog Error sending batch API - {str(e)}\n{traceback.format_exc()}"
            )

    async def _send_with_413_split(self, batch: List) -> List:
        """
        Send a batch, halving any sub-batch that 413s (payload too large) and retrying the
        halves, since Datadog enforces a 5MB uncompressed limit per request.

        A 413 surfaces as a raised MaskedHTTPStatusError (httpx raise_for_status), not a
        returned response, so both paths are handled. A lone event that still 413s is
        dropped to avoid wedging the queue on an undeliverable payload. Returns the events
        that could not be delivered because of a non-413 (transient) error, so the caller
        re-queues only those and never the events already accepted by Datadog.
        """
        pending: List[List] = [batch]
        while pending:
            chunk = pending.pop()
            if not chunk:
                continue
            try:
                response = await self.async_send_compressed_data(chunk)
            except Exception as e:
                if isinstance(e, MaskedHTTPStatusError) and e.status_code == 413:
                    response = e.response
                else:
                    verbose_logger.exception(
                        f"Datadog Error sending batch API - {str(e)}"
                    )
                    return self._undelivered(chunk, pending)

            if response.status_code == 413:
                if len(chunk) == 1:
                    verbose_logger.error(DD_ERRORS.DATADOG_413_ERROR.value)
                    continue
                mid = len(chunk) // 2
                pending.append(chunk[mid:])
                pending.append(chunk[:mid])
                continue

            if response.status_code != 202:
                verbose_logger.error(
                    "Datadog: unexpected response status_code=%s, text=%s",
                    response.status_code,
                    response.text,
                )
                return self._undelivered(chunk, pending)

            verbose_logger.debug(
                "Datadog: delivered %s events, status_code=%s, text=%s",
                len(chunk),
                response.status_code,
                response.text,
            )
        return []

    @staticmethod
    def _undelivered(chunk: List, pending: List[List]) -> List:
        return chunk + [event for remaining in reversed(pending) for event in remaining]

    async def flush_queue(self):
        if self.flush_lock is None:
            return

        async with self.flush_lock:
            if self.log_queue:
                verbose_logger.debug(
                    "Datadog: Flushing batch of %s events", len(self.log_queue)
                )
                await self.async_send_batch()
                if not self.log_queue:
                    self.last_flush_time = time.time()

    def log_success_event(self, kwargs, response_obj, start_time, end_time):
        """
        Sync Log success events to Datadog

        - Creates a Datadog payload
        - instantly logs it on DD API
        """
        try:
            if litellm.datadog_use_v1 is True:
                dd_payload = self._create_v0_logging_payload(
                    kwargs=kwargs,
                    response_obj=response_obj,
                    start_time=start_time,
                    end_time=end_time,
                )
            else:
                dd_payload = self.create_datadog_logging_payload(
                    kwargs=kwargs,
                    response_obj=response_obj,
                    start_time=start_time,
                    end_time=end_time,
                )

            # Build headers
            headers = {}
            # Add API key if available (required for direct API, optional for agent)
            if self.DD_API_KEY:
                headers["DD-API-KEY"] = self.DD_API_KEY

            response = self.sync_client.post(
                url=self.intake_url,
                json=dd_payload,  # type: ignore
                headers=headers,
            )

            response.raise_for_status()
            if response.status_code != 202:
                raise Exception(
                    f"Response from datadog API status_code: {response.status_code}, text: {response.text}"
                )

            verbose_logger.debug(
                "Datadog: Response from datadog API status_code: %s, text: %s",
                response.status_code,
                response.text,
            )

        except Exception as e:
            verbose_logger.exception(
                f"Datadog Layer Error - {str(e)}\n{traceback.format_exc()}"
            )
            pass
        pass

    async def _log_async_event(self, kwargs, response_obj, start_time, end_time):
        dd_payload = self.create_datadog_logging_payload(
            kwargs=kwargs,
            response_obj=response_obj,
            start_time=start_time,
            end_time=end_time,
        )

        self.log_queue.append(dd_payload)
        verbose_logger.debug(
            f"Datadog, event added to queue. Will flush in {self.flush_interval} seconds..."
        )

        if len(self.log_queue) >= self.batch_size:
            await self.flush_queue()

    def _create_datadog_logging_payload_helper(
        self,
        standard_logging_object: StandardLoggingPayload,
        status: DataDogStatus,
    ) -> DatadogPayload:
        from litellm.litellm_core_utils.safe_json_dumps import safe_dumps

        json_payload = safe_dumps(standard_logging_object)
        verbose_logger.debug("Datadog: Logger - Logging payload = %s", json_payload)
        dd_payload = DatadogPayload(
            ddsource=get_datadog_source(),
            ddtags=",".join(
                get_datadog_tags(standard_logging_object=standard_logging_object)
            ),
            hostname=get_datadog_hostname(),
            message=json_payload,
            service=get_datadog_service(),
            status=status,
        )
        self._add_trace_context_to_payload(dd_payload=dd_payload)
        return dd_payload

    def create_datadog_logging_payload(
        self,
        kwargs: Union[dict, Any],
        response_obj: Any,
        start_time: datetime.datetime,
        end_time: datetime.datetime,
    ) -> DatadogPayload:
        """
        Helper function to create a datadog payload for logging

        Args:
            kwargs (Union[dict, Any]): request kwargs
            response_obj (Any): llm api response
            start_time (datetime.datetime): start time of request
            end_time (datetime.datetime): end time of request

        Returns:
            DatadogPayload: defined in types.py
        """

        standard_logging_object: Optional[StandardLoggingPayload] = kwargs.get(
            "standard_logging_object", None
        )
        if standard_logging_object is None:
            raise ValueError("standard_logging_object not found in kwargs")

        status = DataDogStatus.INFO
        if standard_logging_object.get("status") == "failure":
            status = DataDogStatus.ERROR

        # Build the initial payload
        self.truncate_standard_logging_payload_content(standard_logging_object)

        dd_payload = self._create_datadog_logging_payload_helper(
            standard_logging_object=standard_logging_object,
            status=status,
        )
        return dd_payload

    async def async_send_compressed_data(self, data: List) -> Response:
        """
        Async helper to send compressed data to datadog self.intake_url

        Datadog recommends using gzip to compress data
        https://docs.datadoghq.com/api/latest/logs/

        "Datadog recommends sending your logs compressed. Add the Content-Encoding: gzip header to the request when sending"
        """

        import gzip

        from litellm.litellm_core_utils.safe_json_dumps import safe_dumps

        compressed_data = gzip.compress(safe_dumps(data).encode("utf-8"))

        # Build headers
        headers = {
            "Content-Encoding": "gzip",
            "Content-Type": "application/json",
        }

        # Add API key if available (required for direct API, optional for agent)
        if self.DD_API_KEY:
            headers["DD-API-KEY"] = self.DD_API_KEY

        response = await self.async_client.post(
            url=self.intake_url,
            data=compressed_data,  # type: ignore
            headers=headers,
        )
        return response

    async def async_service_failure_hook(
        self,
        payload: ServiceLoggerPayload,
        error: Optional[str] = "",
        parent_otel_span: Optional[Any] = None,
        start_time: Optional[Union[datetimeObj, float]] = None,
        end_time: Optional[Union[float, datetimeObj]] = None,
        event_metadata: Optional[dict] = None,
    ):
        """
        Logs failures from Redis, Postgres (Adjacent systems), as 'WARNING' on DataDog

        - example - Redis is failing / erroring, will be logged on DataDog
        """
        try:
            _payload_dict = payload.model_dump()
            _payload_dict.update(event_metadata or {})
            from litellm.litellm_core_utils.safe_json_dumps import safe_dumps

            _dd_message_str = safe_dumps(_payload_dict)
            _dd_payload = DatadogPayload(
                ddsource=get_datadog_source(),
                ddtags=",".join(get_datadog_tags()),
                hostname=get_datadog_hostname(),
                message=_dd_message_str,
                service=get_datadog_service(),
                status=DataDogStatus.WARN,
            )

            self.log_queue.append(_dd_payload)

        except Exception as e:
            verbose_logger.exception(
                f"Datadog: Logger - Exception in async_service_failure_hook: {e}"
            )
        pass

    async def async_service_success_hook(
        self,
        payload: ServiceLoggerPayload,
        error: Optional[str] = "",
        parent_otel_span: Optional[Any] = None,
        start_time: Optional[Union[datetimeObj, float]] = None,
        end_time: Optional[Union[float, datetimeObj]] = None,
        event_metadata: Optional[dict] = None,
    ):
        """
        Logs success from Redis, Postgres (Adjacent systems), as 'INFO' on DataDog

        No user has asked for this so far, this might be spammy on datatdog. If need arises we can implement this
        """
        try:
            # intentionally done. Don't want to log all service types to DD
            if payload.service not in DD_LOGGED_SUCCESS_SERVICE_TYPES:
                return

            _payload_dict = payload.model_dump()
            _payload_dict.update(event_metadata or {})

            from litellm.litellm_core_utils.safe_json_dumps import safe_dumps

            _dd_message_str = safe_dumps(_payload_dict)
            _dd_payload = DatadogPayload(
                ddsource=get_datadog_source(),
                ddtags=",".join(get_datadog_tags()),
                hostname=get_datadog_hostname(),
                message=_dd_message_str,
                service=get_datadog_service(),
                status=DataDogStatus.INFO,
            )

            self.log_queue.append(_dd_payload)

        except Exception as e:
            verbose_logger.exception(
                f"Datadog: Logger - Exception in async_service_failure_hook: {e}"
            )

    def _create_v0_logging_payload(
        self,
        kwargs: Union[dict, Any],
        response_obj: Any,
        start_time: datetime.datetime,
        end_time: datetime.datetime,
    ) -> DatadogPayload:
        """
        Note: This is our V1 Version of DataDog Logging Payload


        (Not Recommended) If you want this to get logged set `litellm.datadog_use_v1 = True`
        """

        litellm_params = kwargs.get("litellm_params", {})
        metadata = (
            litellm_params.get("metadata", {}) or {}
        )  # if litellm_params['metadata'] == None
        messages = kwargs.get("messages")
        optional_params = kwargs.get("optional_params", {})
        call_type = kwargs.get("call_type", "litellm.completion")
        cache_hit = kwargs.get("cache_hit", False)
        usage = response_obj["usage"]
        id = response_obj.get("id", str(uuid.uuid4()))
        usage = dict(usage)
        try:
            response_time = (end_time - start_time).total_seconds() * 1000
        except Exception:
            response_time = None

        try:
            response_obj = dict(response_obj)
        except Exception:
            response_obj = response_obj

        # Clean Metadata before logging - never log raw metadata
        # the raw metadata can contain circular references which leads to infinite recursion
        # we clean out all extra litellm metadata params before logging
        clean_metadata = {}
        if isinstance(metadata, dict):
            for key, value in metadata.items():
                # clean litellm metadata before logging
                if key in [
                    "endpoint",
                    "caching_groups",
                    "previous_models",
                ]:
                    continue
                else:
                    clean_metadata[key] = value

        # Build the initial payload
        payload = {
            "id": id,
            "call_type": call_type,
            "cache_hit": cache_hit,
            "start_time": start_time,
            "end_time": end_time,
            "response_time": response_time,
            "model": kwargs.get("model", ""),
            "user": kwargs.get("user", ""),
            "model_parameters": optional_params,
            "spend": kwargs.get("response_cost", 0),
            "messages": messages,
            "response": response_obj,
            "usage": usage,
            "metadata": clean_metadata,
        }

        from litellm.litellm_core_utils.safe_json_dumps import safe_dumps

        json_payload = safe_dumps(payload)

        verbose_logger.debug("Datadog: Logger - Logging payload = %s", json_payload)

        dd_payload = DatadogPayload(
            ddsource=get_datadog_source(),
            ddtags=",".join(get_datadog_tags()),
            hostname=get_datadog_hostname(),
            message=json_payload,
            service=get_datadog_service(),
            status=DataDogStatus.INFO,
        )
        return dd_payload

    def _add_trace_context_to_payload(
        self,
        dd_payload: DatadogPayload,
    ) -> None:
        """Attach Datadog APM trace context if one is active."""

        try:
            trace_context = self._get_active_trace_context()
            if trace_context is None:
                return

            dd_payload["dd.trace_id"] = trace_context["trace_id"]
            span_id = trace_context.get("span_id")
            if span_id is not None:
                dd_payload["dd.span_id"] = span_id
        except Exception:
            verbose_logger.exception(
                "Datadog: Failed to attach trace context to payload"
            )

    def _get_active_trace_context(self) -> Optional[Dict[str, str]]:
        try:
            current_span = None
            current_span_fn = getattr(tracer, "current_span", None)
            if callable(current_span_fn):
                current_span = current_span_fn()

            if current_span is None:
                current_root_span_fn = getattr(tracer, "current_root_span", None)
                if callable(current_root_span_fn):
                    current_span = current_root_span_fn()

            if current_span is None:
                return None

            trace_id = getattr(current_span, "trace_id", None)
            if trace_id is None:
                return None

            span_id = getattr(current_span, "span_id", None)
            trace_context: Dict[str, str] = {"trace_id": str(trace_id)}
            if span_id is not None:
                trace_context["span_id"] = str(span_id)
            return trace_context
        except Exception:
            verbose_logger.exception(
                "Datadog: Failed to retrieve active trace context from tracer"
            )
            return None

    async def async_health_check(self) -> IntegrationHealthCheckStatus:
        """
        Check if the service is healthy
        """
        from litellm.litellm_core_utils.litellm_logging import (
            create_dummy_standard_logging_payload,
        )

        standard_logging_object = create_dummy_standard_logging_payload()
        dd_payload = self._create_datadog_logging_payload_helper(
            standard_logging_object=standard_logging_object,
            status=DataDogStatus.INFO,
        )
        log_queue = [dd_payload]
        response = await self.async_send_compressed_data(log_queue)
        try:
            response.raise_for_status()
            return IntegrationHealthCheckStatus(
                status="healthy",
                error_message=None,
            )
        except httpx.HTTPStatusError as e:
            return IntegrationHealthCheckStatus(
                status="unhealthy",
                error_message=e.response.text,
            )
        except Exception as e:
            return IntegrationHealthCheckStatus(
                status="unhealthy",
                error_message=str(e),
            )

    async def get_request_response_payload(
        self,
        request_id: str,
        start_time_utc: Optional[datetimeObj],
        end_time_utc: Optional[datetimeObj],
    ) -> Optional[dict]:
        pass
