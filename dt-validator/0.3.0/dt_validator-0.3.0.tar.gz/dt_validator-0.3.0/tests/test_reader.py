import pytest

from dt_validator.reader import FileLocation, parse_uri


def test_parse_uri_basic():
    loc = parse_uri("s3://my-bucket/path/to/file.txt")
    assert loc == FileLocation(bucket="my-bucket", key="path/to/file.txt")


def test_parse_uri_url_encoded_key():
    loc = parse_uri("s3://my-bucket/a%20b/c.txt")
    assert loc.key == "a b/c.txt"


def test_parse_virtual_hosted_url_with_region():
    loc = parse_uri("https://my-bucket.s3.us-east-2.amazonaws.com/data/f.json")
    assert loc.bucket == "my-bucket"
    assert loc.key == "data/f.json"
    assert loc.region == "us-east-2"


def test_parse_virtual_hosted_url_no_region():
    loc = parse_uri("https://my-bucket.s3.amazonaws.com/f.json")
    assert loc.bucket == "my-bucket"
    assert loc.key == "f.json"
    assert loc.region is None


def test_parse_path_style_url():
    loc = parse_uri("https://s3.eu-west-1.amazonaws.com/my-bucket/dir/f.csv")
    assert loc.bucket == "my-bucket"
    assert loc.key == "dir/f.csv"
    assert loc.region == "eu-west-1"


@pytest.mark.parametrize(
    "bad",
    [
        "",
        "s3://bucket-only",
        "https://example.com/not-s3",
        "ftp://bucket/key",
    ],
)
def test_parse_rejects_bad_input(bad):
    with pytest.raises(ValueError):
        parse_uri(bad)
