"""Neutrl Core — shared configuration, logging, and utility library.

Provides standardized configuration loading, structured logging,
RPC provider management, and common helpers for Neutrl Protocol services.
"""

from neutrl_core.config import NeutrlConfig, ChainConfig, DatabaseConfig, NATSConfig
from neutrl_core.providers import ProviderManager, RPCEndpoint, ProviderHealth
from neutrl_core.logging import setup_logging, get_logger, LogLevel
from neutrl_core.retry import RetryPolicy, retry, async_retry
from neutrl_core.exceptions import (
    NeutrlCoreError,
    ConfigurationError,
    ProviderError,
    AllProvidersDownError,
    RetryExhaustedError,
)

__version__ = "2.0.0"
__author__ = "Daniel Mercer"

__all__ = [
    "NeutrlConfig",
    "ChainConfig",
    "DatabaseConfig",
    "NATSConfig",
    "ProviderManager",
    "RPCEndpoint",
    "ProviderHealth",
    "setup_logging",
    "get_logger",
    "LogLevel",
    "RetryPolicy",
    "retry",
    "async_retry",
    "NeutrlCoreError",
    "ConfigurationError",
    "ProviderError",
    "AllProvidersDownError",
    "RetryExhaustedError",
]
