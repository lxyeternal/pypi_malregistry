# artifact_lab_3_package_6e10193e/__init__.py
# Pode ser deixado vazio ou usado para inicialização

