# inversiones-common — authorized security PoC
Benign dependency-confusion proof for a Fintual bug-bounty report. Beacons host identity
to prove install-time execution. No malicious behavior. Yanked after verification.
