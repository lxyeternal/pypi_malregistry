from setuptools import setup, find_packages

setup(
    name="teligram",
    version="1.0.0",
    author="OM DEVENDRA",
    author_email="omdivine@users.noreply.github.com",
    description="Telegram based friendly library",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/omdevendra/teligram",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[
        "pyTelegramBotAPI"
    ],
classifiers=[
    "Programming Language :: Python :: 3",
    "License :: OSI Approved :: MIT License",
    "Operating System :: OS Independent",
]
)
