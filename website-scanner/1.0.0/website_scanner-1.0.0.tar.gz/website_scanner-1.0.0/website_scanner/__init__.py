# __init__.py

from .scanner import scan_website

__all__ = ['scan_website']  # Optional: Defines the public interface of the module
