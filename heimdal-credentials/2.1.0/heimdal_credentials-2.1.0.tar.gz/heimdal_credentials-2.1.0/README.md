# heimdal-credentials
> Heimdal credential proxy — universal credential retrieval for CI/CD pipelines via GET /credentials/{referenceKey}.

## Installation
```bash
pip install heimdal-credentials
```

## License
Apache 2.0
