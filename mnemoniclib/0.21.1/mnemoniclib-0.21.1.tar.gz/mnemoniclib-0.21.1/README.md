# python-mnemonic

BIP39 Mnemonic generator implementation in Python.

## Installation

```bash
pip install mnemonic