from setuptools import setup, find_packages

setup(
    name='ruamel-poc', 
    version='0.17.16', 
    description='ruamel',
    author='Vishal Kumar',
    packages=find_packages(),
    install_requires=[],
    zip_safe=False,
)
