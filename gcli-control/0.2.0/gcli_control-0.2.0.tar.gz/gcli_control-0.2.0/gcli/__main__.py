"""
gcli — remote access tool via npoint.io.

Commands:
    gcli host [--password P] [--bin ID] [--poll-interval N]
    gcli ssh  [--password P] [--bin ID]
    gcli stop [--bin ID]
"""
import argparse
import sys
import getpass
import logging

from .host import start_daemon, stop_daemon, DEFAULT_BIN_ID, DEFAULT_POLL
from .client import SSHSession
from .colors import banner, info, error

logger = logging.getLogger("gcli")


def cmd_host(args):
    """Start the gcli host daemon."""
    password = args.password
    if not password:
        password = getpass.getpass("Password: ")

    print(info(f"[gcli] Starting host daemon (bin={args.bin})..."))
    start_daemon(
        password=password,
        bin_id=args.bin,
        poll_interval=args.poll_interval,
        foreground=args.foreground,
    )


def cmd_ssh(args):
    """Connect to a remote gcli host."""
    password = args.password
    if not password:
        password = getpass.getpass("Password: ")

    print(banner())
    session = SSHSession(
        password=password,
        bin_id=args.bin,
    )
    session.repl()


def cmd_stop(args):
    """Stop a running gcli daemon."""
    stop_daemon(bin_id=args.bin)


def main():
    parser = argparse.ArgumentParser(
        prog="gcli",
        description="Remote access tool via npoint.io — encrypted command relay",
    )
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # ---- gcli host ----
    host_parser = subparsers.add_parser("host", help="Start the background host daemon")
    host_parser.add_argument("-p", "--password", default=None, help="Encryption password")
    host_parser.add_argument("-b", "--bin", default=DEFAULT_BIN_ID, help="npoint.io bin ID")
    host_parser.add_argument("--poll-interval", type=float, default=DEFAULT_POLL,
                             help="Poll interval in seconds (default: 2.0)")
    host_parser.add_argument("--foreground", action="store_true",
                             help="Run in foreground (don't detach)")

    # ---- gcli ssh ----
    ssh_parser = subparsers.add_parser("ssh", help="Connect to a remote gcli host")
    ssh_parser.add_argument("-p", "--password", default=None, help="Encryption password")
    ssh_parser.add_argument("-b", "--bin", default=DEFAULT_BIN_ID, help="npoint.io bin ID")

    # ---- gcli stop ----
    stop_parser = subparsers.add_parser("stop", help="Stop the host daemon")
    stop_parser.add_argument("-b", "--bin", default=DEFAULT_BIN_ID, help="npoint.io bin ID")

    args = parser.parse_args()

    if not args.command:
        print(banner())
        parser.print_help()
        sys.exit(1)

    try:
        if args.command == "host":
            print(banner())
            cmd_host(args)
        elif args.command == "ssh":
            cmd_ssh(args)
        elif args.command == "stop":
            cmd_stop(args)
    except KeyboardInterrupt:
        print(f"\n{error('[gcli] Interrupted.')}")
        sys.exit(130)
    except Exception as e:
        logger.error("Fatal error: %s", e)
        sys.exit(1)


if __name__ == "__main__":
    main()
