"""
Integration test for gcli — tests the full host + client flow.
Runs host daemon in foreground (thread), client sends commands programmatically.
"""
import sys
import os
import time
import base64
import threading
import tempfile
from pathlib import Path

# Add parent to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from gcli.npoint import write
from gcli.host import Daemon
from gcli.client import SSHSession
from gcli.protocol import init_doc, set_host_alive

BIN_ID = "599ac3c39189fcc26e5a"
PASSWORD = "integration_test_pass_123"


def init_test_doc():
    """Reset the document for testing."""
    print("[TEST] Initialising npoint document...")
    sid = init_doc(BIN_ID, PASSWORD)
    print(f"[TEST] Session: {sid}")
    return sid


def run_host_in_background():
    """Run host daemon in a background thread."""
    daemon = Daemon(PASSWORD, BIN_ID, poll_interval=1.5)
    t = threading.Thread(target=daemon.run, daemon=True, name="host-daemon")
    t.start()
    return daemon, t


def test_ping():
    """Test ping/pong."""
    print("\n[TEST] === PING TEST ===")
    session = SSHSession(PASSWORD, BIN_ID, poll_interval=1.0)
    result = session._send("ping", {"type": "ping"})
    print(f"[TEST] Sent ping, cmd_id={result}")

    # Poll for result (up to 10 seconds)
    from gcli.protocol import read_doc, claim_all_results
    deadline = time.time() + 10
    while time.time() < deadline:
        doc = read_doc(BIN_ID)
        results = claim_all_results(doc, PASSWORD, set())
        for r in results:
            if r.get("pong"):
                print(f"[TEST] PONG received! time={r.get('time')}")
                return True
        time.sleep(1)
    print("[TEST] PING FAILED")
    return False


def test_exec():
    """Test command execution."""
    print("\n[TEST] === EXEC TEST ===")
    from gcli.protocol import read_doc, claim_all_results

    session = SSHSession(PASSWORD, BIN_ID, poll_interval=1.0)
    cmd_id = session._send("exec", {"type": "exec", "cmd": "echo gcli_test_output"})
    print(f"[TEST] Sent exec, cmd_id={cmd_id}")

    time.sleep(4)
    doc = read_doc(BIN_ID)
    results = claim_all_results(doc, PASSWORD, set())
    print(f"[TEST] Results found: {len(results)}")
    for r in results:
        if r.get("cmd_id") == cmd_id:
            print(f"[TEST] Exec result: ok={r.get('ok')}, stdout={r.get('stdout', '').strip()!r}")
            return r.get("ok") and "gcli_test_output" in r.get("stdout", "")
    print("[TEST] EXEC FAILED - no matching result")
    return False


def test_info():
    """Test system info."""
    print("\n[TEST] === INFO TEST ===")
    from gcli.protocol import read_doc, claim_all_results

    session = SSHSession(PASSWORD, BIN_ID, poll_interval=1.0)
    cmd_id = session._send("info", {"type": "info"})
    print(f"[TEST] Sent info, cmd_id={cmd_id}")

    time.sleep(4)
    doc = read_doc(BIN_ID)
    results = claim_all_results(doc, PASSWORD, set())
    for r in results:
        if r.get("cmd_id") == cmd_id:
            print(f"[TEST] Info result: ok={r.get('ok')}, hostname={r.get('hostname')}")
            return r.get("ok")
    print("[TEST] INFO FAILED")
    return False


def test_upload():
    """Test file upload: client uploads a temp file, verify it exists on host."""
    print("\n[TEST] === UPLOAD TEST ===")
    from gcli.protocol import read_doc, claim_all_results

    # Create a temp file to upload
    test_content = b"hello gcli upload test content 12345"
    remote_path = "gcli_test_upload.txt"

    session = SSHSession(PASSWORD, BIN_ID, poll_interval=1.0)
    data_b64 = base64.b64encode(test_content).decode("ascii")
    cmd_id = session._send("upload", {
        "type": "upload",
        "path": remote_path,
        "data": data_b64,
    })
    print(f"[TEST] Sent upload, cmd_id={cmd_id}")

    time.sleep(4)
    doc = read_doc(BIN_ID)
    results = claim_all_results(doc, PASSWORD, set())
    for r in results:
        if r.get("cmd_id") == cmd_id:
            ok = r.get("ok")
            bw = r.get("bytes_written", 0)
            print(f"[TEST] Upload result: ok={ok}, bytes_written={bw}")
            # Verify the file was written
            p = Path(remote_path)
            if ok and p.exists():
                content = p.read_bytes()
                match = content == test_content
                print(f"[TEST] Content match: {match} (len={len(content)})")
                # Cleanup
                p.unlink(missing_ok=True)
                return match
            return False
    print("[TEST] UPLOAD FAILED - no matching result")
    return False


def test_download():
    """Test file download: create a temp file on host, download it."""
    print("\n[TEST] === DOWNLOAD TEST ===")
    from gcli.protocol import read_doc, claim_all_results

    # First, upload a known file to the host
    test_content = b"download me if you can 67890"
    remote_path = "gcli_test_download.txt"
    local_save = "gcli_test_downloaded.txt"

    # Upload it first
    session = SSHSession(PASSWORD, BIN_ID, poll_interval=1.0)
    data_b64 = base64.b64encode(test_content).decode("ascii")
    upload_id = session._send("upload", {
        "type": "upload",
        "path": remote_path,
        "data": data_b64,
    })
    print(f"[TEST] Uploaded test file (cmd_id={upload_id})")
    time.sleep(4)

    # Now download it
    cmd_id = session._send("download", {
        "type": "download",
        "path": remote_path,
    })
    print(f"[TEST] Sent download, cmd_id={cmd_id}")

    time.sleep(4)
    doc = read_doc(BIN_ID)
    results = claim_all_results(doc, PASSWORD, set())
    for r in results:
        if r.get("cmd_id") == cmd_id:
            ok = r.get("ok")
            print(f"[TEST] Download result: ok={ok}")
            if ok:
                raw = base64.b64decode(r.get("data", ""))
                match = raw == test_content
                print(f"[TEST] Content match: {match} (len={len(raw)})")
                # Cleanup
                Path(remote_path).unlink(missing_ok=True)
                Path(local_save).unlink(missing_ok=True)
                return match
            return False
    print("[TEST] DOWNLOAD FAILED - no matching result")
    return False


def main():
    print("[TEST] ========================================")
    print("[TEST]   gcli Integration Test")
    print("[TEST] ========================================")

    # 1. Init
    init_test_doc()

    # 2. Start host daemon
    print("[TEST] Starting host daemon...")
    daemon, thread = run_host_in_background()
    time.sleep(3)
    print("[TEST] Daemon thread alive:", thread.is_alive())

    results = {}

    try:
        # 3. Tests
        results["ping"] = test_ping()
        time.sleep(2)
        results["exec"] = test_exec()
        time.sleep(2)
        results["info"] = test_info()
        time.sleep(2)
        results["upload"] = test_upload()
        time.sleep(2)
        results["download"] = test_download()
    finally:
        # Stop daemon
        print("\n[TEST] Stopping daemon...")
        daemon.running = False
        thread.join(timeout=5)

    # Summary
    print("\n[TEST] ========================================")
    print("[TEST]   RESULTS")
    print("[TEST] ========================================")
    all_pass = True
    for name, passed in results.items():
        status = "PASS" if passed else "FAIL"
        if not passed:
            all_pass = False
        print(f"[TEST]   {name:12s}: {status}")
    print("[TEST] ========================================")
    print(f"[TEST]   Overall: {'ALL PASSED' if all_pass else 'SOME FAILED'}")
    return 0 if all_pass else 1


if __name__ == "__main__":
    sys.exit(main())
