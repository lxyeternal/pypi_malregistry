"""Config Toolkit - Lightweight configuration management for Python apps."""

__version__ = "1.0.11"

class ConfigManager:
    """Manage application configuration from multiple sources."""
    def __init__(self, defaults=None):
        self.defaults = defaults or {}
        self._config = dict(self.defaults)

    def load_env(self, prefix="APP"):
        """Load configuration from environment variables."""
        import os
        for key, val in os.environ.items():
            if key.startswith(prefix + "_"):
                self._config[key[len(prefix)+1:].lower()] = val
        return self

    def get(self, key, default=None):
        """Get a configuration value."""
        return self._config.get(key, default)

    def set(self, key, value):
        """Set a configuration value."""
        self._config[key] = value
        return self

    def as_dict(self):
        """Return configuration as dictionary."""
        return dict(self._config)
