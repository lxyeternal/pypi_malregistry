"""
dbhandler.exceptions - Custom exception classes.
"""


class DBHandlerError(Exception):
    """Base exception for all dbhandler errors."""


class ConnectionError(DBHandlerError):
    """Raised when a database connection fails."""


class QueryError(DBHandlerError):
    """Raised when a query fails to execute."""


class ModelError(DBHandlerError):
    """Raised when a model operation fails."""


class MigrationError(DBHandlerError):
    """Raised when a migration fails."""
