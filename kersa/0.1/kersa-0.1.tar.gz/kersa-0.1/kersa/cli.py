
def cli():
    print("YOU SHALL NOT PASS!")
    