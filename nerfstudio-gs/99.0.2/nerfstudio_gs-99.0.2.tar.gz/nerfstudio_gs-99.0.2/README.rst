nerfstudio-gs
=============

Gaussian Splatting backend plugin for `nerfstudio <https://github.com/nerfstudio-project/nerfstudio>`_.

Integrates the 3D Gaussian Splatting method (Kerbl et al., SIGGRAPH 2023) as a first-class trainer in the nerfstudio pipeline.

Installation::

    pip install nerfstudio-gs

Requires nerfstudio >= 1.0.0.

Usage
-----

.. code-block:: python

    import gaussiansplatting

Features
--------

- Easy pip installation
- All original dependencies included
- Compatible with Python 3.8+

Citation
--------

Kerbl, B., Kopanas, G., Leimkühler, T., & Drettakis, G. (2023).
3D Gaussian Splatting for Real-Time Radiance Field Rendering.
ACM Transactions on Graphics, 42(4).
