"""Resolve dm_core_bg.js / dm_core_bg.wasm (package data or explicit directory)."""

from __future__ import annotations

import os
import shutil
from pathlib import Path

PAYLOAD_JS = "dm_core_bg.js"
PAYLOAD_WASM = "dm_core_bg.wasm"

_override_dir: Path | None = None


def set_payload_dir(directory: str | Path) -> None:
    global _override_dir
    _override_dir = Path(directory)


def payload_dir() -> Path:
    if _override_dir is not None:
        return _override_dir
    env = os.environ.get("VAULT_PAYLOAD_DIR", "").strip()
    if env:
        return Path(env)
    pkg = Path(__file__).resolve().parent / "data"
    if (pkg / PAYLOAD_JS).is_file():
        return pkg
    root = Path(__file__).resolve().parents[2]
    if (root / PAYLOAD_JS).is_file():
        return root
    return pkg


def js_path() -> Path:
    return payload_dir() / PAYLOAD_JS


def wasm_path() -> Path:
    return payload_dir() / PAYLOAD_WASM


def ensure_payload_files() -> None:
    d = payload_dir()
    if (d / PAYLOAD_JS).is_file() and (d / PAYLOAD_WASM).is_file():
        return
    pkg = Path(__file__).resolve().parent / "data"
    d.mkdir(parents=True, exist_ok=True)
    for name in (PAYLOAD_JS, PAYLOAD_WASM):
        for src in (pkg / name, Path(__file__).resolve().parents[2] / name):
            if src.is_file():
                shutil.copy2(src, d / name)
                break
