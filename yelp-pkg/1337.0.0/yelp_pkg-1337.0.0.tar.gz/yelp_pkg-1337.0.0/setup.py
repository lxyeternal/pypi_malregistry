from setuptools import setup, find_packages

setup(
    name="yelp-pkg",
    version="1337.0.0",
    author="bugdotexe",
    author_email="bugdotexe@wearehackerone.com",
    description="Authorized Security Testing Package",
    long_description="This package is for authorized dependency confusion testing only.",
    packages=find_packages(),
    install_requires=[
        "requests>=2.25.1"
    ],
    python_requires='>=3.6',
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Topic :: Security",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ]
)
