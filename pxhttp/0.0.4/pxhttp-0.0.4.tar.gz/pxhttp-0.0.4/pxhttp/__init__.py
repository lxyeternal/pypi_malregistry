from .extractor import RelationExtractor
from .model import RelTaggerModel