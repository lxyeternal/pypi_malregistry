import asyncio
import collections
import logging
from typing import Dict, Any, AsyncGenerator, Deque, Set
from datetime import datetime, timedelta

from .planner import Plan, PlanStep, StepType
from pg_agent.tools.database import SecureSQLTool
from pg_agent.tools.web_search import SearchTool
from pg_agent.tools.analysis import AnalyticsTool

# Setup Logging
logger = logging.getLogger(__name__)

class ExecutionError(Exception):
    """Base exception for execution failures."""
    pass

class CircuitBreakerOpenError(ExecutionError):
    """Raised when the circuit breaker is open."""
    pass

class CircuitBreaker:
    def __init__(self, threshold: int = 5, window_seconds: int = 60) -> None:
        self.threshold = threshold
        self.window = timedelta(seconds=window_seconds)
        self.failures: Deque[datetime] = collections.deque()

    def record_failure(self) -> None:
        now = datetime.now()
        self.failures.append(now)
        self._clean_old_failures(now)
        if len(self.failures) >= self.threshold:
            logger.error("Circuit breaker OPEN!")

    def _clean_old_failures(self, now: datetime) -> None:
        while self.failures and now - self.failures[0] > self.window:
            self.failures.popleft()

    def is_open(self) -> bool:
        self._clean_old_failures(datetime.now())
        return len(self.failures) >= self.threshold

class ExecutionAgent:
    def __init__(self, pool_size: int = 5, step_timeout: float = 30.0) -> None:
        self.semaphore = asyncio.Semaphore(pool_size)
        self.step_timeout = step_timeout
        self.circuit_breaker = CircuitBreaker()
        self.results: Dict[str, Any] = {}
        self.step_events: Dict[str, asyncio.Event] = {}
        self.sql_tool = SecureSQLTool()
        self.search_tool = SearchTool()
        self.analytics_tool = AnalyticsTool()

    async def execute_plan(self, plan: Plan) -> AsyncGenerator[Dict[str, Any], None]:
        """Executes the plan steps with dependency resolution and worker pool."""
        self.results = {}
        self.step_events = {step.id: asyncio.Event() for step in plan.steps}
        
        logger.info(f"Executing plan with {len(plan.steps)} steps")
        
        # Track pending tasks
        tasks = []
        for step in plan.steps:
            tasks.append(asyncio.create_task(self._process_step_with_dependencies(step)))

        # Stream results as they complete
        completed_count = 0
        while completed_count < len(plan.steps):
            # Check for circuit breaker before waiting
            if self.circuit_breaker.is_open():
                for t in tasks:
                    t.cancel()
                raise CircuitBreakerOpenError("Too many failures, stopping execution.")

            # Check for task failures
            for t in tasks:
                if t.done() and not t.cancelled() and t.exception():
                    exc = t.exception()
                    for other_t in tasks:
                        if not other_t.done():
                            other_t.cancel()
                    if exc:
                        raise exc

            # Find a newly completed step
            new_completion = False
            for step_id, event in self.step_events.items():
                streamed: Set[str] = self.results.setdefault("_streamed", set())
                if event.is_set() and step_id not in streamed:
                    streamed.add(step_id)
                    new_completion = True
                    completed_count += 1
                    yield {
                        "event": "step_complete",
                        "step_id": step_id,
                        "result": self.results[step_id],
                        "progress": f"{completed_count}/{len(plan.steps)}"
                    }
            
            if not new_completion:
                # Wait for any task to finish or a short timeout
                await asyncio.wait(tasks, timeout=0.1, return_when=asyncio.FIRST_COMPLETED)

    async def _process_step_with_dependencies(self, step: PlanStep) -> None:
        """Waits for dependencies before executing the step."""
        for dep_id in step.depends_on:
            if dep_id in self.step_events:
                await self.step_events[dep_id].wait()
            else:
                logger.warning(f"Step {step.id} depends on unknown step {dep_id}")

        async with self.semaphore:
            result = await self._execute_with_retry(step)
            self.results[step.id] = result
            self.step_events[step.id].set()

    async def _execute_with_retry(self, step: PlanStep, retries: int = 2) -> Any:
        """Executes a single step with retries and timeout."""
        attempt = 0

        while attempt <= retries:
            if self.circuit_breaker.is_open():
                raise CircuitBreakerOpenError(f"Circuit breaker open, skipping {step.id}")

            try:
                # Actual execution simulation or tool call
                result = await asyncio.wait_for(self._dispatch_tool(step), timeout=self.step_timeout)
                return result

            except (asyncio.TimeoutError, Exception) as e:
                attempt += 1
                logger.warning(f"Step {step.id} attempt {attempt} failed: {e}")
                
                if attempt > retries:
                    # Try fallback if available
                    if step.fallback:
                        logger.info(f"Step {step.id} failed, attempting fallback {step.fallback.type}")
                        return await self._execute_with_retry(step.fallback, retries=0)
                    
                    self.circuit_breaker.record_failure()
                    raise ExecutionError(f"Step {step.id} failed after {retries} retries: {e}") from e
                
                await asyncio.sleep(1 * attempt) # Basic linear backoff

    async def _dispatch_tool(self, step: PlanStep) -> Any:
        """Dispatches to the specific tool handler."""
        logger.info(f"Executing {step.type}: {step.description}")
        
        if step.type == StepType.SQL:
            query = step.tool_input.get("query") if step.tool_input else None
            if not query:
                 query = step.description
            
            tool_result = await self.sql_tool.execute({"query": query})
            if tool_result.success:
                return tool_result.data
            else:
                raise ExecutionError(f"SQL Tool failed: {tool_result.error}")
                
        elif step.type == StepType.SEARCH:
            query = step.tool_input.get("query") if step.tool_input else step.description
            tool_result = await self.search_tool.execute({"query": query})
            if tool_result.success:
                return tool_result.data
            else:
                raise ExecutionError(f"Search Tool failed: {tool_result.error}")

        elif step.type == StepType.ANALYZE:
            # Handle both calculations and data aggregations
            input_data = []
            dep_ids = step.depends_on if step.depends_on else []
            for dep_id in dep_ids:
                dep_result = self.results.get(dep_id)
                if not dep_result:
                    continue
                if isinstance(dep_result, dict) and "results" in dep_result:
                    rows = dep_result["results"]
                    if isinstance(rows, list):
                        input_data.extend(rows)
                elif isinstance(dep_result, list):
                    input_data.extend(dep_result)
                else:
                    input_data.append(dep_result)

            # If no deps resolved data, wait for all other steps then collect their results.
            # This handles ANALYZE steps where the LLM omitted depends_on (race condition).
            if not input_data:
                for sid, event in self.step_events.items():
                    if sid != step.id and not event.is_set():
                        try:
                            await asyncio.wait_for(event.wait(), timeout=self.step_timeout)
                        except asyncio.TimeoutError:
                            pass
                for sid, res in self.results.items():
                    if sid.startswith("_") or sid == step.id:
                        continue
                    if isinstance(res, dict) and "results" in res:
                        input_data.extend(res["results"])
                    elif isinstance(res, list):
                        input_data.extend(res)

            # For combine/summarize steps: skip the analytics tool and return merged records directly.
            # Only use the analytics tool when a real numeric expression or aggregation is requested.
            tool_input = step.tool_input or {}
            operation = tool_input.get("operation", "")
            expression = tool_input.get("expression", "")

            if input_data and operation != "calculate":
                return {"combined_results": input_data, "row_count": len(input_data)}

            tool_params = {**tool_input}
            if input_data:
                tool_params["data"] = input_data
            if operation == "calculate" and not expression:
                return {"error": "expression is required for calculate operation"}

            tool_result = await self.analytics_tool.execute(tool_params)
            if tool_result.success:
                return tool_result.data
            else:
                raise ExecutionError(f"Analytics Tool failed: {tool_result.error}")

        elif step.type == StepType.VERIFY:
            # Basic validation: ensure previous steps returned data
            verification_results = {}
            for dep_id in step.depends_on:
                data = self.results.get(dep_id)
                if not data:
                    verification_results[dep_id] = "FAIL: No data returned"
                elif isinstance(data, list) and len(data) == 0:
                    verification_results[dep_id] = "FAIL: Empty list"
                else:
                    verification_results[dep_id] = "PASS"
            
            return {
                "status": "complete",
                "verifications": verification_results,
                "overall_pass": all(v == "PASS" for v in verification_results.values())
            }
        
        return {"status": "done"}
