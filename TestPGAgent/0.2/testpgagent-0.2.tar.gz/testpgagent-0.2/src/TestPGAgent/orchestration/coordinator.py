import logging
import uuid
import time
import enum
from typing import List, Dict, Any, Optional
from pydantic import BaseModel, Field
import redis

from pg_agent.agent.planner import Plan, PlanningAgent
from pg_agent.agent.executor import ExecutionAgent
from pg_agent.agent.critic import CriticAgent
from pg_agent.agent.rag import RAGPipeline
from pg_agent.memory.long_term import LongTermMemory

logger = logging.getLogger(__name__)

class CoordinationPattern(str, enum.Enum):
    SEQUENTIAL = "SEQUENTIAL"
    PARALLEL = "PARALLEL"

class AgentMessage(BaseModel):
    message_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    sender: str
    receiver: str
    payload: Any
    timestamp: float = Field(default_factory=time.time)

class OrchestrationState(BaseModel):
    session_id: str
    pattern: CoordinationPattern
    plan: Optional[Plan] = None
    results: Dict[str, Any] = Field(default_factory=dict)
    history: List[AgentMessage] = Field(default_factory=list)
    is_complete: bool = False

class Supervisor:
    """
    Main entry point for agent orchestration.
    Coordinates between Planner, Executor, and Critic.
    """
    def __init__(
        self, 
        api_key: str, 
        db_url: str, 
        redis_url: Optional[str] = None,
        max_retries: int = 3
    ):
        self.api_key = api_key
        self.planner = PlanningAgent(api_key=api_key, max_retries=max_retries)
        self.executor = ExecutionAgent()
        self.critic = CriticAgent(api_key=api_key)
        
        # Initialize RAG components
        self.memory = LongTermMemory(api_key=api_key, dsn=db_url)
        self.rag = RAGPipeline(api_key=api_key, memory=self.memory)
        
        self._checkpoint_interval = 5
        
        if redis_url:
            self.redis = redis.from_url(redis_url, decode_responses=True)
            self.use_redis = True
            logger.info(f"Connected to Redis at {redis_url}")
        else:
            self.redis_memory: Dict[str, str] = {} # Local in-memory fallback
            self.use_redis = False
            logger.info("REDIS_URL not provided. Session state will not persist across restarts.")

    async def setup_database(self) -> Dict[str, Any]:
        """Runs the database setup logic (extension + migrations)."""
        return await self.executor.sql_tool.setup_database()

    async def index_database_schema(self) -> None:
        """One-time or manual indexing of the current DB schema into RAG."""
        logger.info("Starting database schema indexing for RAG...")
        await self.memory.connect()
        if self.memory.pool:
            await self.memory.pool.execute("DELETE FROM long_term_memory WHERE memory_type = 'schema';")
        schema_info = await self.executor.sql_tool.fetch_schema()
        await self.rag.index_schema(schema_info)
        logger.info("Schema indexing complete.")

    async def orchestrate(self, session_id: str, pattern: CoordinationPattern, question: str) -> OrchestrationState:
        """
        Main orchestration loop based on the chosen pattern.
        """
        logger.info(f"Orchestrating session {session_id} with pattern {pattern.value}")
        
        state = self._load_state(session_id) or OrchestrationState(session_id=session_id, pattern=pattern)
        
        if pattern == CoordinationPattern.SEQUENTIAL:
            await self._run_sequential(state, question)
        elif pattern == CoordinationPattern.PARALLEL:
            await self._run_parallel(state, question)
        
        self._save_state(state)
        return state

    async def _run_sequential(self, state: OrchestrationState, question: str) -> None:
        """Sequential: Planner -> Executor -> Critic -> Responder"""
        # 0. Capability Discovery
        capabilities = await self.executor.sql_tool.check_capabilities()

        # Reset per-turn state but preserve conversation history
        state.plan = None
        state.results = {}
        state.is_complete = False

        # Track user message in history for multi-turn context
        state.history.append(AgentMessage(sender="user", receiver="planner", payload=question))

        # 1. Planning
        augmented_context = ""
        try:
            chunks = await self.rag.retrieve(question, top_k=10)
            if chunks:
                augmented_context = self.rag.format_prompt_context(chunks)
        except Exception as e:
            logger.warning(f"RAG retrieval failed: {e}")

        history = []
        for msg in state.history[:-1]:  # exclude the message we just added
            role = "user" if msg.sender == "user" else "model"
            history.append({"role": role, "content": str(msg.payload)})

        state.plan = self.planner.plan(
            question,
            history,
            capabilities=capabilities,
            augmented_context=augmented_context
        )
        self._maybe_checkpoint(state)

        # 2. Execution with Self-Correction Loop
        if state.plan:
            max_corrections = 2
            correction_count = 0
            
            while correction_count <= max_corrections:
                try:
                    async for event in self.executor.execute_plan(state.plan):
                        if event["event"] == "step_complete":
                            state.results[event["step_id"]] = event["result"]
                            self._maybe_checkpoint(state)
                    break # Success
                except Exception as e:
                    correction_count += 1
                    if correction_count > max_corrections:
                        raise e
                    
                    logger.warning(f"Execution failed, attempting self-correction {correction_count}: {e}")
                    failed_step_id = "1"
                    for step in state.plan.steps:
                        if step.id in str(e):
                            failed_step_id = step.id
                            break
                    
                    state.plan = self.planner.refine_step(question, state.plan, failed_step_id, str(e))
                    state.results = {} 
                    self._maybe_checkpoint(state)

        # 3. Critique
        if state.results and not state.is_complete and state.plan:
            # Note: validate_results_post_execution is async
            critique = await self.critic.validate_results_post_execution(question, state.plan, state.results)
            if critique.is_valid:
                state.is_complete = True
            else:
                logger.warning(f"Critic rejected results: {critique.reason}")

        # Track assistant response in history for multi-turn context
        if state.results:
            state.history.append(AgentMessage(sender="assistant", receiver="user", payload=state.results))

    async def _run_parallel(self, state: OrchestrationState, question: str) -> None:
        """Parallel: Multiple Executors on independent steps"""
        await self._run_sequential(state, question)

    def _save_state(self, state: OrchestrationState) -> None:
        key = f"orch_state:{state.session_id}"
        if self.use_redis:
            self.redis.set(key, state.model_dump_json())
        else:
            self.redis_memory[key] = state.model_dump_json()

    def _load_state(self, session_id: str) -> Optional[OrchestrationState]:
        key = f"orch_state:{session_id}"
        data = self.redis.get(key) if self.use_redis else self.redis_memory.get(key)
        if isinstance(data, str):
            return OrchestrationState.model_validate_json(data)
        return None

    def _maybe_checkpoint(self, state: OrchestrationState) -> None:
        if len(state.results) % self._checkpoint_interval == 0:
            self._save_state(state)
