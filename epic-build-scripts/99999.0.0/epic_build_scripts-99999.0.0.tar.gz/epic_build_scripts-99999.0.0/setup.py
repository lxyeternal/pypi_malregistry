from setuptools import setup, find_packages

setup(
    name="epic-build-scripts",
    version="99999.0.0",
    author="Security Research",
    description="Internal package",
    packages=find_packages(),
    python_requires=">=3.6",
)
