VERSION = '0.0.1'
DESCRIPTION = 'Basic Python Color Package'