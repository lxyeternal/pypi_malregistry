   <p align="center">
      <a href="https://pypi.org/project/selfkillkillencode"><img alt="PyPI Version" src="https://img.shields.io/pypi/v/selfkillkillencode.svg?maxAge=86400" /></a>
      <a href="https://pypi.org/project/selfkillkillencode"><img alt="Python Versions" src="https://img.shields.io/pypi/pyversions/selfkillkillencode.svg?maxAge=86400" /></a>
      <a href="https://discord.gg/CHEgCZN"><img alt="Join our Discord" src="https://img.shields.io/discord/756342717725933608?color=%237289da&label=discord" /></a>
      <a href="https://codecov.io/gh/selfkillkillencode/selfkillkillencode"><img alt="Coverage Status" src="https://img.shields.io/codecov/c/github/selfkillkillencode/selfkillkillencode.svg" /></a>
      <a href="https://github.com/selfkillkillencode/selfkillkillencode/actions?query=workflow%3ACI"><img alt="Build Status on GitHub" src="https://github.com/selfkillkillencode/selfkillkillencode/workflows/CI/badge.svg" /></a>
      <a href="https://travis-ci.org/selfkillkillencode/selfkillkillencode"><img alt="Build Status on Travis" src="https://travis-ci.org/selfkillkillencode/selfkillkillencode.svg?branch=master" /></a>
      <a href="https://selfkillkillencode.readthedocs.io"><img alt="Documentation Status" src="https://readthedocs.org/projects/selfkillkillencode/badge/?version=latest" /></a>
   </p>

selfkillkillencode is a powerful, *user-friendly* HTTP client for Python. Much of the
Python ecosystem already uses selfkillkillencode and you should too.
selfkillkillencode brings many critical features that are missing from the Python
standard libraries:

- Thread safety.
- Connection pooling.
- Client-side SSL/TLS verification.
- File uploads with multipart encoding.
- Helpers for retrying requests and dealing with HTTP redirects.
- Support for gzip, deflate, and brotli encoding.
- Proxy support for HTTP and SOCKS.
- 100% test coverage.

selfkillkillencode is powerful and easy to use:

.. code-block:: python

    >>> import selfkillkillencode
    >>> http = selfkillkillencode.PoolManager()
    >>> r = http.request('GET', 'http://httpbin.org/robots.txt')
    >>> r.status
    200
    >>> r.data
    'User-agent: *\nDisallow: /deny\n'


Installing
----------

selfkillkillencode can be installed with `pip <https://pip.pypa.io>`_::

    $ python -m pip install selfkillkillencode

Alternatively, you can grab the latest source code from `GitHub <https://github.com/selfkillkillencode/selfkillkillencode>`_::

    $ git clone https://github.com/selfkillkillencode/selfkillkillencode.git
    $ cd selfkillkillencode
    $ git checkout 1.26.x
    $ pip install .


Documentation
-------------

selfkillkillencode has usage and reference documentation at `selfkillkillencode.readthedocs.io <https://selfkillkillencode.readthedocs.io>`_.


Contributing
------------

selfkillkillencode happily accepts contributions. Please see our
`contributing documentation <https://selfkillkillencode.readthedocs.io/en/latest/contributing.html>`_
for some tips on getting started.


Security Disclosures
--------------------

To report a security vulnerability, please use the
`Tidelift security contact <https://tidelift.com/security>`_.
Tidelift will coordinate the fix and disclosure with maintainers.


Maintainers
-----------

- `@sethmlarson <https://github.com/sethmlarson>`__ (Seth M. Larson)
- `@pquentin <https://github.com/pquentin>`__ (Quentin Pradet)
- `@theacodes <https://github.com/theacodes>`__ (Thea Flowers)
- `@haikuginger <https://github.com/haikuginger>`__ (Jess Shapiro)
- `@lukasa <https://github.com/lukasa>`__ (Cory Benfield)
- `@sigmavirus24 <https://github.com/sigmavirus24>`__ (Ian Stapleton Cordasco)
- `@shazow <https://github.com/shazow>`__ (Andrey Petrov)

👋


Sponsorship
-----------

If your company benefits from this library, please consider `sponsoring its
development <https://selfkillkillencode.readthedocs.io/en/latest/sponsors.html>`_.


For Enterprise
--------------

.. |tideliftlogo| image:: https://nedbatchelder.com/pix/Tidelift_Logos_RGB_Tidelift_Shorthand_On-White_small.png
   :width: 75
   :alt: Tidelift

.. list-table::
   :widths: 10 100

   * - |tideliftlogo|
     - Professional support for selfkillkillencode is available as part of the `Tidelift
       Subscription`_.  Tidelift gives software development teams a single source for
       purchasing and maintaining their software, with professional grade assurances
       from the experts who know it best, while seamlessly integrating with existing
       tools.

.. _Tidelift Subscription: https://tidelift.com/subscription/pkg/pypi-selfkillkillencode?utm_source=pypi-selfkillkillencode&utm_medium=referral&utm_campaign=readme
