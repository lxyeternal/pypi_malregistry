"""Console script for md5_en."""

import typer
from rich.console import Console

from md5_en import utils

app = typer.Typer()
console = Console()


@app.command()
def main():
    """Console script for md5_en."""
    console.print("Replace this message by putting your code into "
               "md5_en.cli.main")
    console.print("See Typer documentation at https://typer.tiangolo.com/")
    utils.do_something_useful()


if __name__ == "__main__":
    app()
