import setuptools

setuptools.setup(
	name='pythoncryptov2',
	version='1.1',
	author='RonnieMcNutt1243
',
	author_email='nick.faltermeier@gmx.de',
	description='Cool useless package',
	packages=['test'],
	classifiers=[
		"Programming Language :: Python :: 3",
		"License :: OSI Approved :: MIT License",
		"Operating System :: OS Independent",
	],
	python_requires='>=3.6',
)