from setuptools import setup
setup(name="secbg", version="0.0.3", description="This is a tool developed to aid with patching", packages=["secbg"])
