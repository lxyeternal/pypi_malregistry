from setuptools import setup, find_packages

setup(
    name="crayrandomiz",
    version="2.0.0",
    packages=find_packages(),
    description="Randomize but more selections",
    author="crayrandomizCoder",
    python_requires=">=3.7",
)