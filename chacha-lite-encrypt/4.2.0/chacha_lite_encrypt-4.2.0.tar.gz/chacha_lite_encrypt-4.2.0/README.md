# ChaCha Lite Encrypt

A lightweight ChaCha20 encryption library for Python.

## Features

- Pure Python ChaCha20 implementation
- No external dependencies
- Simple and intuitive API
- Support for both text and binary encryption
- File encryption and decryption
- Built-in key derivation from passwords
- Automatic nonce generation

## Installation

```bash
pip install chacha-lite-encrypt
```

## Basic Usage

```python
from chacha_lite_encrypt import ChaChaEncryption, generate_key

key = generate_key()
plaintext = b"Hello, World!"

ciphertext = ChaChaEncryption.encrypt(plaintext, key)
decrypted = ChaChaEncryption.decrypt(ciphertext, key)

print(decrypted)
```

## License

MIT
