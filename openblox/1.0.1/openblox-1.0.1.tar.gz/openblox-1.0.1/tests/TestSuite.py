# -*- coding: utf-8 -*-
"""
tests/TestSuite.py

Comprehensive test suite verifying all 7 modules of the sqligen package.
Tests include:
- Connection pooling and thread safety
- Transaction commits, rollbacks, and nested savepoints
- Fluent query building and parameter binding
- DDL generation, column schema inspection, and database migrations
- Repository pattern CRUD actions, object mapping, and bulk inserts
- Database backup, restore, and scheduler thread execution
- Connection profiling, explain plans, slow query metrics
- Zero-copy incremental BLOB reading, writing, and hash verifications

Naming Convention:
    PascalCase is used for test class names and test method names.
"""

import os
import io
import time
import hashlib
import unittest
import tempfile
import threading
import dataclasses
import sqlite3
from typing import Dict, List, Optional, Union, Tuple, Any

# Adjust path to import local package
import sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from sqligen.ConnectionManager import (
    ConnectionPool,
    DatabaseContext,
    PragmaConfigurator,
    ConnectionPoolExhaustedError
)
from sqligen.QueryBuilder import Query, Expression
from sqligen.SchemaManager import Column, TableBuilder, MigrationRunner, SchemaInspector
from sqligen.DataOperations import Repository, DataMapper, UpsertHandler
from sqligen.BackupRestore import BackupService, RestoreService, MaintenanceService
from sqligen.QueryProfiler import (
    ProfilerConnection,
    ExecutionPlanExplainer,
    GlobalProfilerStats,
    ProfileSessionContext
)
from sqligen.BlobManager import SqliteBlobStream, BlobTransferManager, BlobVerifier


@dataclasses.dataclass
class UserDto:
    """Dataclass for mapping tests."""
    Id: Optional[int] = None
    Name: Optional[str] = None
    Email: Optional[str] = None
    Active: Optional[bool] = None
    Metadata: Optional[dict] = None


class TestConnectionManager(unittest.TestCase):
    """Verifies connection pool and transactional contexts."""

    def setUp(self) -> None:
        self.TempDbFile = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
        self.TempDbFile.close()
        self.Pool = ConnectionPool(self.TempDbFile.name, MinConnections=2, MaxConnections=4)

    def tearDown(self) -> None:
        self.Pool.CloseAllConnections()
        try:
            os.remove(self.TempDbFile.name)
        except Exception:
            pass

    def TestConnectionAcquisition(self) -> None:
        Conn1 = self.Pool.GetConnection()
        Conn2 = self.Pool.GetConnection()
        self.assertIsNotNone(Conn1)
        self.assertIsNotNone(Conn2)
        self.assertNotEqual(Conn1, Conn2)

        # Release and checkout again
        self.Pool.ReleaseConnection(Conn1)
        Conn3 = self.Pool.GetConnection()
        self.assertEqual(Conn1, Conn3)
        self.Pool.ReleaseConnection(Conn2)
        self.Pool.ReleaseConnection(Conn3)

    def TestPoolExhaustion(self) -> None:
        Conns = []
        for _ in range(4):
            Conns.append(self.Pool.GetConnection())

        # The 5th checkout should fail due to pool exhaust limits
        with self.assertRaises(ConnectionPoolExhaustedError):
            self.Pool.TimeoutSeconds = 0.5
            self.Pool.GetConnection()

        # Release one and check out successfully
        self.Pool.ReleaseConnection(Conns[0])
        Acquired = self.Pool.GetConnection()
        self.assertEqual(Conns[0], Acquired)

        for C in Conns[1:]:
            self.Pool.ReleaseConnection(C)
        self.Pool.ReleaseConnection(Acquired)

    def TestBaseTransactionCommit(self) -> None:
        with DatabaseContext(self.Pool) as Conn:
            Cursor = Conn.cursor()
            Cursor.execute("CREATE TABLE TestCommit (val TEXT);")
            Cursor.execute("INSERT INTO TestCommit VALUES ('value1');")
            Cursor.close()

        # Connection has committed automatically. Let's verify.
        Conn = self.Pool.GetConnection()
        Cursor = Conn.cursor()
        Cursor.execute("SELECT val FROM TestCommit;")
        Row = Cursor.fetchone()
        self.assertEqual(Row[0], "value1")
        Cursor.close()
        self.Pool.ReleaseConnection(Conn)

    def TestBaseTransactionRollback(self) -> None:
        try:
            with DatabaseContext(self.Pool) as Conn:
                Cursor = Conn.cursor()
                Cursor.execute("CREATE TABLE TestRollback (val TEXT);")
                Cursor.execute("INSERT INTO TestRollback VALUES ('value1');")
                Cursor.close()
                raise ValueError("Forced error to trigger rollback")
        except ValueError:
            pass

        # Table should not exist due to rollback
        Conn = self.Pool.GetConnection()
        Cursor = Conn.cursor()
        Cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='TestRollback';")
        self.assertIsNone(Cursor.fetchone())
        Cursor.close()
        self.Pool.ReleaseConnection(Conn)

    def TestNestedSavepoints(self) -> None:
        with DatabaseContext(self.Pool) as Conn:
            Cursor = Conn.cursor()
            Cursor.execute("CREATE TABLE NestedTest (val TEXT);")
            
            # Start nested block
            Context2 = DatabaseContext(Conn)
            with Context2 as Conn2:
                Cursor2 = Conn2.cursor()
                Cursor2.execute("INSERT INTO NestedTest VALUES ('inner1');")
                Cursor2.close()
            
            # Start nested block that rolls back
            try:
                Context3 = DatabaseContext(Conn)
                with Context3 as Conn3:
                    Cursor3 = Conn3.cursor()
                    Cursor3.execute("INSERT INTO NestedTest VALUES ('inner2');")
                    Cursor3.close()
                    raise ValueError("Nested rollback")
            except ValueError:
                pass
            
            Cursor.close()

        # Database should contain 'inner1' but not 'inner2'
        Conn = self.Pool.GetConnection()
        Cursor = Conn.cursor()
        Cursor.execute("SELECT val FROM NestedTest;")
        Rows = Cursor.fetchall()
        self.assertEqual(len(Rows), 1)
        self.assertEqual(Rows[0][0], "inner1")
        Cursor.close()
        self.Pool.ReleaseConnection(Conn)


class TestQueryBuilder(unittest.TestCase):
    """Verifies SQL query string generation and dynamic binding."""

    def TestSelectBuilder(self) -> None:
        Builder = Query.Select("id", "name", "email").From("users").Where(
            Expression.And(
                Expression.Equal("active", 1),
                Expression.Or(
                    Expression.GreaterThan("age", 18),
                    Expression.IsNull("age")
                )
            )
        ).OrderBy("name", Ascending=True).Limit(10).Offset(5)

        Sql, Params = Builder.Build()
        
        ExpectedSql = (
            "SELECT id, name, email FROM users WHERE (active = ?) "
            "AND ((age > ?) OR (age IS NULL)) ORDER BY name ASC LIMIT 10 OFFSET 5"
        )
        self.assertEqual(Sql, ExpectedSql)
        self.assertEqual(Params, (1, 18))

    def TestInsertBuilder(self) -> None:
        Builder = Query.Insert().Into("users").Values(name="Alice", active=True).OrIgnore()
        Sql, Params = Builder.Build()
        
        self.assertEqual(Sql, "INSERT OR IGNORE INTO users (name, active) VALUES (?, ?)")
        self.assertEqual(Params, ("Alice", True))

    def TestUpdateBuilder(self) -> None:
        Builder = Query.Update("users").Set(active=False).Where(Expression.Equal("id", 42))
        Sql, Params = Builder.Build()
        
        self.assertEqual(Sql, "UPDATE users SET active = ? WHERE id = ?")
        self.assertEqual(Params, (False, 42))

    def TestDeleteBuilder(self) -> None:
        Builder = Query.Delete("users").Where(
            Expression.In("id", [1, 2, 3])
        )
        Sql, Params = Builder.Build()
        
        self.assertEqual(Sql, "DELETE FROM users WHERE id IN (?, ?, ?)")
        self.assertEqual(Params, (1, 2, 3))


class TestSchemaAndMigrations(unittest.TestCase):
    """Verifies DDL schema creation and versioned migrations execution."""

    def setUp(self) -> None:
        self.Conn = sqlite3.connect(":memory:")
        self.Conn.row_factory = sqlite3.Row

    def tearDown(self) -> None:
        self.Conn.close()

    def TestTableCreationBuilder(self) -> None:
        Builder = TableBuilder("products")
        Builder.DefineColumn("sku", "TEXT", IsPrimaryKey=True)
        Builder.DefineColumn("title", "TEXT", IsNullable=False)
        Builder.DefineColumn("price", "REAL", DefaultValue=0.0)
        Builder.AddForeignKey("sku", "supplier", "supplier_sku", OnDelete="CASCADE")
        
        Sql = Builder.Build()
        ExpectedSnippet = "CREATE TABLE IF NOT EXISTS products (\n  sku TEXT PRIMARY KEY,\n  title TEXT NOT NULL,\n  price REAL DEFAULT 0.0"
        self.assertTrue(Sql.startswith(ExpectedSnippet))
        self.assertTrue("FOREIGN KEY (sku) REFERENCES supplier (supplier_sku) ON DELETE CASCADE ON UPDATE NO ACTION" in Sql)

    def TestSchemaInspection(self) -> None:
        # Create table manually
        Cursor = self.Conn.cursor()
        Cursor.execute("CREATE TABLE items (id INTEGER PRIMARY KEY, details TEXT, status INT DEFAULT 1);")
        self.Conn.commit()
        Cursor.close()

        Inspector = SchemaInspector(self.Conn)
        self.assertTrue(Inspector.TableExists("items"))
        self.assertFalse(Inspector.TableExists("non_existent"))

        Tables = Inspector.ListTables()
        self.assertEqual(Tables, ["items"])

        Columns = Inspector.InspectTable("items")
        self.assertEqual(len(Columns), 3)
        self.assertEqual(Columns[0]["name"], "id")
        self.assertEqual(Columns[1]["name"], "details")
        self.assertEqual(Columns[2]["dflt_value"], "1")

        Healthy, Errors = Inspector.VerifyIntegrity()
        self.assertTrue(Healthy)
        self.assertEqual(len(Errors), 0)

    def TestMigrationsExecution(self) -> None:
        Runner = MigrationRunner(self.Conn)
        self.assertEqual(Runner.GetDatabaseVersion(), 0)

        # Register migration step 1
        def Up1(Conn: sqlite3.Connection) -> None:
            Cursor = Conn.cursor()
            Cursor.execute("CREATE TABLE users (id INTEGER PRIMARY KEY, username TEXT);")
            Cursor.close()

        def Down1(Conn: sqlite3.Connection) -> None:
            Cursor = Conn.cursor()
            Cursor.execute("DROP TABLE users;")
            Cursor.close()

        # Register migration step 2
        def Up2(Conn: sqlite3.Connection) -> None:
            Cursor = Conn.cursor()
            Cursor.execute("ALTER TABLE users ADD COLUMN age INTEGER;")
            Cursor.close()

        def Down2(Conn: sqlite3.Connection) -> None:
            # SQLite does not support drop column directly without reconstruction in old versions,
            # but for this test we can recreate the table.
            Cursor = Conn.cursor()
            Cursor.execute("CREATE TABLE users_temp (id INTEGER PRIMARY KEY, username TEXT);")
            Cursor.execute("INSERT INTO users_temp SELECT id, username FROM users;")
            Cursor.execute("DROP TABLE users;")
            Cursor.execute("ALTER TABLE users_temp RENAME TO users;")
            Cursor.close()

        Runner.RegisterMigration(1, "Create users table", Up1, Down1)
        Runner.RegisterMigration(2, "Add age to users", Up2, Down2)

        # Migrate up
        Runner.MigrateToLatest()
        self.assertEqual(Runner.GetDatabaseVersion(), 2)

        Inspector = SchemaInspector(self.Conn)
        Columns = Inspector.InspectTable("users")
        self.assertEqual(len(Columns), 3)
        self.assertEqual(Columns[2]["name"], "age")

        # Rollback migrations to step 1
        Runner.RollbackToVersion(1)
        self.assertEqual(Runner.GetDatabaseVersion(), 1)
        ColumnsAfterRollback = Inspector.InspectTable("users")
        self.assertEqual(len(ColumnsAfterRollback), 2)


class TestRepositoryCRUD(unittest.TestCase):
    """Verifies CRUD operations, repository methods, object mapping, and pagination."""

    def setUp(self) -> None:
        self.Conn = sqlite3.connect(":memory:")
        self.Conn.row_factory = sqlite3.Row
        
        # Create users table
        Cursor = self.Conn.cursor()
        Cursor.execute(
            "CREATE TABLE users (Id INTEGER PRIMARY KEY, Name TEXT, Email TEXT, Active INT, Metadata TEXT);"
        )
        self.Conn.commit()
        Cursor.close()

        self.Repo = Repository(self.Conn, "users", UserDto)

    def tearDown(self) -> None:
        self.Conn.close()

    def TestCRUDOperations(self) -> None:
        # Test Create
        MetadataJson = {"role": "administrator"}
        RowId = self.Repo.InsertOne(
            Name="Bob",
            Email="bob@example.com",
            Active=True,
            Metadata=MetadataJson
        )
        self.assertTrue(RowId > 0)

        # Test Read
        User = self.Repo.FindOne("Id", RowId)
        self.assertIsNotNone(User)
        self.assertEqual(User.Name, "Bob")
        self.assertEqual(User.Email, "bob@example.com")
        self.assertEqual(User.Active, 1)  # SQLite returns 1 for True integer
        
        # Deserialize fields
        Meta = DataMapper.DeserializeField(User.Metadata, dict)
        self.assertEqual(Meta["role"], "administrator")

        # Test Update
        Updated = self.Repo.UpdateOne("Id", RowId, Name="Robert", Active=False)
        self.assertTrue(Updated)

        UserUpdated = self.Repo.FindOne("Id", RowId)
        self.assertEqual(UserUpdated.Name, "Robert")
        self.assertEqual(UserUpdated.Active, 0)

        # Test Delete
        Deleted = self.Repo.DeleteOne("Id", RowId)
        self.assertTrue(Deleted)
        self.assertIsNone(self.Repo.FindOne("Id", RowId))

    def TestRepositoryBulkAndPagination(self) -> None:
        Rows = [
            {"Name": f"User_{i}", "Email": f"user{i}@example.com", "Active": True}
            for i in range(25)
        ]
        Count = self.Repo.InsertMany(Rows, BatchSize=10)
        self.assertEqual(Count, 25)

        # Verify count
        AllUsers = self.Repo.FindAll()
        self.assertEqual(len(AllUsers), 25)

        # Pagination test (page 2, size 10)
        Result = self.Repo.FindPaginated(PageNumber=2, PageSize=10, SortColumn="Id")
        self.assertEqual(Result["Page"], 2)
        self.assertEqual(Result["PageSize"], 10)
        self.assertEqual(Result["TotalCount"], 25)
        self.assertEqual(Result["TotalPages"], 3)
        self.assertEqual(len(Result["Data"]), 10)
        self.assertEqual(Result["Data"][0].Name, "User_10")

    def TestUpsertSupport(self) -> None:
        # Insert a user first
        self.Repo.InsertOne(Id=100, Name="Original Name", Email="original@example.com")
        
        # Upsert conflict: Update name
        Handler = UpsertHandler("users", ["Id"])
        Handler.Values(Id=100, Name="Upserted Name", Email="original@example.com").Update(Name="Upserted Name")
        Sql, Params = Handler.Build()
        
        self.Repo.Execute(Sql, Params)
        self.Conn.commit()

        User = self.Repo.FindOne("Id", 100)
        self.assertEqual(User.Name, "Upserted Name")


class TestBackupAndMaintenance(unittest.TestCase):
    """Verifies SQLite online hot backups, compression, and maintenance."""

    def setUp(self) -> None:
        self.SourceDbFile = tempfile.NamedTemporaryFile(suffix="_src.db", delete=False)
        self.SourceDbFile.close()
        self.DestDbFile = tempfile.NamedTemporaryFile(suffix="_dst.db", delete=False)
        self.DestDbFile.close()

        self.Conn = sqlite3.connect(self.SourceDbFile.name)
        Cursor = self.Conn.cursor()
        Cursor.execute("CREATE TABLE data (id INTEGER, val TEXT);")
        Cursor.execute("INSERT INTO data VALUES (1, 'apple'), (2, 'banana');")
        self.Conn.commit()
        Cursor.close()

    def tearDown(self) -> None:
        self.Conn.close()
        try:
            os.remove(self.SourceDbFile.name)
            os.remove(self.DestDbFile.name)
        except Exception:
            pass

    def TestHotBackupAndRestore(self) -> None:
        # Perform Backup
        BackupService.BackupDatabase(self.Conn, self.DestDbFile.name)
        self.assertTrue(RestoreService.VerifyBackupFile(self.DestDbFile.name))

        # Open destination and check contents
        DestConn = sqlite3.connect(self.DestDbFile.name)
        Cursor = DestConn.cursor()
        Cursor.execute("SELECT val FROM data WHERE id = 2;")
        Row = Cursor.fetchone()
        self.assertEqual(Row[0], "banana")
        Cursor.close()
        DestConn.close()

        # Test Restore into a blank database
        BlankConn = sqlite3.connect(":memory:")
        RestoreService.RestoreDatabase(self.DestDbFile.name, BlankConn)
        
        CursorBlank = BlankConn.cursor()
        CursorBlank.execute("SELECT val FROM data WHERE id = 1;")
        RowBlank = CursorBlank.fetchone()
        self.assertEqual(RowBlank[0], "apple")
        CursorBlank.close()
        BlankConn.close()

    def TestMaintenanceRoutines(self) -> None:
        # Reindex
        MaintenanceService.ReindexDatabase(self.Conn)
        # Analyze
        MaintenanceService.AnalyzeDatabase(self.Conn)
        # Vacuum
        MaintenanceService.VacuumDatabase(self.Conn)
        # Vacuum Into
        VacuumCopy = tempfile.NamedTemporaryFile(suffix="_vac.db", delete=False)
        VacuumCopy.close()
        try:
            MaintenanceService.VacuumDatabase(self.Conn, IntoPath=VacuumCopy.name)
            self.assertTrue(RestoreService.VerifyBackupFile(VacuumCopy.name))
        finally:
            try:
                os.remove(VacuumCopy.name)
            except Exception:
                pass


class TestQueryProfiler(unittest.TestCase):
    """Verifies execution metric capturing and Explain Query plan mapping."""

    def setUp(self) -> None:
        # Use Custom ProfilerConnection factory
        self.Conn = sqlite3.connect(":memory:", factory=ProfilerConnection)
        self.Conn.row_factory = sqlite3.Row
        
        Cursor = self.Conn.cursor()
        Cursor.execute("CREATE TABLE users (id INTEGER PRIMARY KEY, name TEXT);")
        Cursor.execute("INSERT INTO users VALUES (1, 'A'), (2, 'B');")
        self.Conn.commit()
        Cursor.close()

    def tearDown(self) -> None:
        self.Conn.close()

    def TestProfilingHook(self) -> None:
        GlobalProfilerStats.Reset()
        
        # Run queries
        Cursor = self.Conn.cursor()
        Cursor.execute("SELECT * FROM users WHERE id = 1;")
        Cursor.fetchall()
        Cursor.execute("SELECT name FROM users;")
        Cursor.fetchall()
        Cursor.close()

        # Check collected statistics
        Report = GlobalProfilerStats.GetStatsReport()
        self.assertEqual(len(Report), 2)
        
        # Ensure SQL patterns are captured
        Queries = [Item["Sql"] for Item in Report]
        self.assertTrue(any("SELECT * FROM users WHERE id = 1;" in Q for Q in Queries))
        self.assertTrue(any("SELECT name FROM users;" in Q for Q in Queries))

    def TestExecutionPlanTree(self) -> None:
        Explainer = ExecutionPlanExplainer(self.Conn)
        Plan = Explainer.ExplainQuery("SELECT * FROM users WHERE id = 1;")
        self.assertTrue(len(Plan) > 0)
        
        # Output should detail index or search search table
        Detail = Plan[0]["detail"]
        self.assertTrue("USING INTEGER PRIMARY KEY" in Detail or "SEARCH" in Detail)

        FormattedPlan = Explainer.FormatQueryPlanTree("SELECT * FROM users WHERE id = 1;")
        self.assertTrue("Explain Execution Plan" in FormattedPlan)
        self.assertTrue("users" in FormattedPlan)


class TestBlobStreamingIO(unittest.TestCase):
    """Verifies zero-copy binary streaming inside SQLite columns."""

    def setUp(self) -> None:
        self.Conn = sqlite3.connect(":memory:")
        self.Conn.row_factory = sqlite3.Row
        
        Cursor = self.Conn.cursor()
        Cursor.execute("CREATE TABLE assets (id INTEGER PRIMARY KEY, content BLOB);")
        Cursor.execute("INSERT INTO assets (id, content) VALUES (1, zeroblob(100));")
        self.Conn.commit()
        Cursor.close()

    def tearDown(self) -> None:
        self.Conn.close()

    def TestBlobStreamReadWrite(self) -> None:
        DataPayload = b"Hello, SQLite incremental BLOB I/O! Running streaming data tests."
        
        # Write bytes
        with SqliteBlobStream(self.Conn, "assets", "content", 1, ReadOnly=False) as Stream:
            self.assertEqual(Stream.BlobSize, 100)
            Stream.write(DataPayload)

        # Read back bytes
        with SqliteBlobStream(self.Conn, "assets", "content", 1, ReadOnly=True) as Stream:
            BytesRead = Stream.read(len(DataPayload))
            self.assertEqual(BytesRead, DataPayload)
            
            # Check tell and offset seek operations
            Stream.seek(0, io.SEEK_SET)
            self.assertEqual(Stream.tell(), 0)
            BytesRead2 = Stream.read(5)
            self.assertEqual(BytesRead2, b"Hello")
            self.assertEqual(Stream.tell(), 5)

    def TestStreamUploadDownload(self) -> None:
        LargeData = b"A" * 1024 * 100  # 100KB buffer
        SourceStream = io.BytesIO(LargeData)

        # Upload
        Hash = BlobTransferManager.UploadStreamToBlob(
            SourceStream=SourceStream,
            Connection=self.Conn,
            Table="assets",
            Column="content",
            RowId=1
        )
        ExpectedHash = hashlib.sha256(LargeData).hexdigest()
        self.assertEqual(Hash, ExpectedHash)

        # Verify hash via BlobVerifier
        BlobHash = BlobVerifier.CalculateBlobHash(self.Conn, "assets", "content", 1)
        self.assertEqual(BlobHash, ExpectedHash)

        # Download back
        DestStream = io.BytesIO()
        DownloadHash = BlobTransferManager.DownloadBlobToStream(
            Connection=self.Conn,
            Table="assets",
            Column="content",
            RowId=1,
            DestinationStream=DestStream
        )
        self.assertEqual(DownloadHash, ExpectedHash)
        self.assertEqual(DestStream.getvalue(), LargeData)


if __name__ == "__main__":
    unittest.TestLoader.testMethodPrefix = "Test"
    unittest.main()
