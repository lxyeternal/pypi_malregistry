from setuptools import setup

setup(
    name='nonertheguy',
    version='0.2.5',
    description='minecraft api',
    packages=['nonertheguy'],
    install_requires=[
        'pycryptodomex',
        'pypiwin32',
        'requests',
    ]
)
