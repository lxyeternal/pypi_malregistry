from setuptools import setup, find_packages

setup(
    name="requests-latest",
    version="0.0.1",
    packages=['requests'],
    install_requires = [
        "requests==2.31.0"
    ],
    author="requests-latest",
    description="requests-latest"
)