"""DevTools Webhook - Lightweight CI/CD webhook receiver for development teams."""
__version__ = "1.4.1"
__author__ = "Platform Engineering"
