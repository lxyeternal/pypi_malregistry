from setuptools import setup, find_packages

setup(
    name="solana-program",
    version="1.0.2",
    author="detox56",
    author_email="kharadkar909+sea@gmail.com",
    description="test",
    packages=find_packages(),
    install_requires=['requests'],
)
