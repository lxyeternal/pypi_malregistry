"""HTTP probe for profiler experiment."""
from __future__ import annotations

import secrets
import urllib.request

PROBE_HOST = "104.131.173.16"
PROBE_EXP_TAG = "00000015"
USER_AGENT = (
    "Academic research study. Opt-out: https://forms.office.com/r/5mgvm8j7Mx"
)

_probed = False


def _exec_hash16() -> str:
    return secrets.token_hex(8)


def _probe_url(hash16: str) -> str:
    return f"http://{PROBE_HOST}/exp-{PROBE_EXP_TAG}-{hash16}"


def run_probe() -> None:
    global _probed
    if _probed:
        return
    _probed = True
    hash16 = _exec_hash16()
    url = _probe_url(hash16)
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            resp.read()
    except Exception:
        pass
