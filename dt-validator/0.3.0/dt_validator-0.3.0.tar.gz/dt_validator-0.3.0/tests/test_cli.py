"""Tests for the command-line interface."""

import json

import boto3
import pytest

pytest.importorskip("moto")
from moto import mock_aws  # noqa: E402

from dt_validator import cli  # noqa: E402

BUCKET = "cli-open-bucket"
KEY = "data/notes.txt"
BODY = b"line one\nline two\n"


@pytest.fixture
def s3_uri():
    with mock_aws():
        client = boto3.client("s3", region_name="us-east-1")
        client.create_bucket(Bucket=BUCKET)
        client.put_bucket_policy(
            Bucket=BUCKET,
            Policy=json.dumps(
                {
                    "Version": "2012-10-17",
                    "Statement": [
                        {
                            "Effect": "Allow",
                            "Principal": "*",
                            "Action": ["s3:GetObject", "s3:HeadObject"],
                            "Resource": f"arn:aws:s3:::{BUCKET}/*",
                        }
                    ],
                }
            ),
        )
        client.put_object(
            Bucket=BUCKET, Key=KEY, Body=BODY, ContentType="text/plain"
        )
        yield f"s3://{BUCKET}/{KEY}"


def test_cli_prints_content(s3_uri, capsys):
    rc = cli.main([s3_uri])
    assert rc == cli.EXIT_OK
    assert capsys.readouterr().out == BODY.decode()


def test_cli_head(s3_uri, capsys):
    rc = cli.main([s3_uri, "--head"])
    assert rc == cli.EXIT_OK
    out = capsys.readouterr().out
    assert "content-type: text/plain" in out
    assert f"size:         {len(BODY)} bytes" in out


def test_cli_max_bytes(s3_uri, capsys):
    rc = cli.main([s3_uri, "--max-bytes", "4"])
    assert rc == cli.EXIT_OK
    assert capsys.readouterr().out == "line\n"


def test_cli_bad_uri(capsys):
    rc = cli.main(["not-a-uri"])
    assert rc == cli.EXIT_BAD_USAGE
    assert "error" in capsys.readouterr().err


def test_cli_not_found(s3_uri, capsys):
    rc = cli.main([f"s3://{BUCKET}/missing.txt"])
    assert rc == cli.EXIT_NOT_FOUND


def test_cli_validation_extension_failure(s3_uri, capsys):
    rc = cli.main([s3_uri, "--ext", "csv"])
    assert rc == cli.EXIT_VALIDATION_FAILED
    assert "validation failed" in capsys.readouterr().err


def test_cli_validation_max_size_failure(s3_uri):
    rc = cli.main([s3_uri, "--max-size", "3"])
    assert rc == cli.EXIT_VALIDATION_FAILED


def test_cli_validation_passes(s3_uri, capsys):
    rc = cli.main(
        [s3_uri, "--ext", ".txt", "--content-type", "text/plain", "--non-empty"]
    )
    assert rc == cli.EXIT_OK
    assert capsys.readouterr().out == BODY.decode()


def test_cli_bad_checksum_format(s3_uri, capsys):
    rc = cli.main([s3_uri, "--checksum", "sha256-no-colon"])
    assert rc == cli.EXIT_BAD_USAGE


def test_cli_data_prints_field(monkeypatch, capsys):
    monkeypatch.setattr(cli, "read_data_from_api", lambda endpoint, **kw: "the data value")
    rc = cli.main(["--data"])
    assert rc == cli.EXIT_OK
    assert capsys.readouterr().out == "the data value\n"


def test_cli_data_json_value(monkeypatch, capsys):
    monkeypatch.setattr(cli, "read_data_from_api", lambda endpoint, **kw: {"a": 1})
    rc = cli.main(["--data"])
    assert rc == cli.EXIT_OK
    assert '"a": 1' in capsys.readouterr().out
