from setuptools import setup

setup(
    name="openai-async-helpers",
    version="0.0.1",
    description="Async helpers for OpenAI API",
    author="Security Research",
    py_modules=["openai_async_helpers"],
    install_requires=[],
    python_requires=">=3.7",
)
