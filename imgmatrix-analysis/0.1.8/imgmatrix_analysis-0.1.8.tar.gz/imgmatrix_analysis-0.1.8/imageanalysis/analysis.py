"""
Image analysis functions.

Provides functions for statistical analysis and feature extraction from images.
"""

from typing import Dict, Optional, Tuple, Union

import numpy as np
from scipy import stats as scipy_stats

from .core import ImageMatrix


def histogram(
    image: ImageMatrix,
    bins: int = 256,
    channel: Optional[int] = None
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Calculate the histogram of an image.
    
    Args:
        image: The ImageMatrix to analyze.
        bins: Number of histogram bins.
        channel: Specific channel to analyze (None for all/grayscale).
        
    Returns:
        Tuple of (histogram counts, bin edges).
    """
    if image.data is None:
        raise ValueError("No image data loaded")
    
    data = image.data
    
    if channel is not None and len(data.shape) == 3:
        data = data[:, :, channel]
    elif len(data.shape) == 3:
        data = np.mean(data, axis=2)
    
    hist, bin_edges = np.histogram(data.flatten(), bins=bins, range=(0, 255))
    return hist, bin_edges


def mean_intensity(image: ImageMatrix, channel: Optional[int] = None) -> float:
    """
    Calculate the mean pixel intensity.
    
    Args:
        image: The ImageMatrix to analyze.
        channel: Specific channel to analyze (None for all).
        
    Returns:
        Mean intensity value.
    """
    if image.data is None:
        raise ValueError("No image data loaded")
    
    data = image.data
    
    if channel is not None and len(data.shape) == 3:
        data = data[:, :, channel]
    
    return float(np.mean(data))


def std_intensity(image: ImageMatrix, channel: Optional[int] = None) -> float:
    """
    Calculate the standard deviation of pixel intensity.
    
    Args:
        image: The ImageMatrix to analyze.
        channel: Specific channel to analyze (None for all).
        
    Returns:
        Standard deviation of intensity.
    """
    if image.data is None:
        raise ValueError("No image data loaded")
    
    data = image.data
    
    if channel is not None and len(data.shape) == 3:
        data = data[:, :, channel]
    
    return float(np.std(data))


def contrast(image: ImageMatrix) -> float:
    """
    Calculate the Michelson contrast of an image.
    
    Contrast = (I_max - I_min) / (I_max + I_min)
    
    Args:
        image: The ImageMatrix to analyze.
        
    Returns:
        Contrast value between 0 and 1.
    """
    if image.data is None:
        raise ValueError("No image data loaded")
    
    if len(image.data.shape) == 3:
        data = np.mean(image.data, axis=2)
    else:
        data = image.data
    
    i_max = float(np.max(data))
    i_min = float(np.min(data))
    
    if i_max + i_min == 0:
        return 0.0
    
    return (i_max - i_min) / (i_max + i_min)


def entropy(image: ImageMatrix) -> float:
    """
    Calculate the Shannon entropy of an image.
    
    Higher entropy indicates more information content / complexity.
    
    Args:
        image: The ImageMatrix to analyze.
        
    Returns:
        Entropy value in bits.
    """
    if image.data is None:
        raise ValueError("No image data loaded")
    
    if len(image.data.shape) == 3:
        data = np.mean(image.data, axis=2).astype(np.uint8)
    else:
        data = image.data
    
    hist, _ = np.histogram(data.flatten(), bins=256, range=(0, 255))
    hist = hist[hist > 0]
    probs = hist / hist.sum()
    
    return float(-np.sum(probs * np.log2(probs)))


def statistics(image: ImageMatrix) -> Dict[str, float]:
    """
    Calculate comprehensive statistics for an image.
    
    Args:
        image: The ImageMatrix to analyze.
        
    Returns:
        Dictionary containing various statistical measures.
    """
    if image.data is None:
        raise ValueError("No image data loaded")
    
    if len(image.data.shape) == 3:
        data = np.mean(image.data, axis=2)
    else:
        data = image.data.astype(np.float64)
    
    flat_data = data.flatten()
    
    return {
        "mean": float(np.mean(flat_data)),
        "std": float(np.std(flat_data)),
        "min": float(np.min(flat_data)),
        "max": float(np.max(flat_data)),
        "median": float(np.median(flat_data)),
        "variance": float(np.var(flat_data)),
        "skewness": float(scipy_stats.skew(flat_data)),
        "kurtosis": float(scipy_stats.kurtosis(flat_data)),
        "entropy": entropy(image),
        "contrast": contrast(image),
    }


def pixel_distribution(
    image: ImageMatrix,
    percentiles: Tuple[float, ...] = (25, 50, 75)
) -> Dict[str, float]:
    """
    Calculate pixel value distribution percentiles.
    
    Args:
        image: The ImageMatrix to analyze.
        percentiles: Tuple of percentile values to compute.
        
    Returns:
        Dictionary mapping percentile names to values.
    """
    if image.data is None:
        raise ValueError("No image data loaded")
    
    flat_data = image.data.flatten()
    
    result = {}
    for p in percentiles:
        result[f"p{int(p)}"] = float(np.percentile(flat_data, p))
    
    return result
