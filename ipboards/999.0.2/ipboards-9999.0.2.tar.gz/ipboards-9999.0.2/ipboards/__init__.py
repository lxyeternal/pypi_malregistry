def totallynothing():
    pass