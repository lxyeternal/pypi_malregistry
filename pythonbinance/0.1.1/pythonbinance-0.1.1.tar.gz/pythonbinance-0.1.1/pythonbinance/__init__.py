print('You probably meant to install python-binance')
