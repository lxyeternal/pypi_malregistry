from readychars import hello

hello()