__version__ = "0.0.0"

def info():
    return "This is a dummy sfnt2woff-zopfli package for PyPI."
