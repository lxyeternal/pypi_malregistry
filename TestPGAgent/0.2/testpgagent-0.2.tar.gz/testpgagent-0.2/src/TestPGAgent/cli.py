import asyncio
import os
import argparse
import sys
import logging
import uuid
import json
from typing import Any

try:
    import readline  # noqa: F401 - enables arrow keys and history in input()
except ImportError:
    pass
from dotenv import load_dotenv
from pg_agent.orchestration.coordinator import Supervisor, CoordinationPattern

# Configure minimal default logging
logging.basicConfig(
    level=logging.WARNING,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("pg-agent")

def print_banner() -> None:
    print("""
    ┌──────────────────────────────────────────────────┐
    │             🐘 PG AGENT - DB ASSISTANT           │
    └──────────────────────────────────────────────────┘
    """)

def print_step(step_id: str, description: str, data: Any) -> None:
    print(f"\n[Step {step_id}] {description}")
    if isinstance(data, list):
        print(f"  └─ Returned {len(data)} rows.")
        if data:
            print(f"  └─ Sample: {json.dumps(data[0], indent=2)}")
    elif isinstance(data, dict):
        print(f"  └─ Result: {json.dumps(data, indent=2)}")
    else:
        print(f"  └─ Result: {data}")

async def run_query(supervisor: Supervisor, question: str, pattern: str, index: bool) -> None:
    if index:
        print("🔍 Indexing database schema...")
        await supervisor.index_database_schema()
        
    print(f"🚀 Processing: {question}")
    
    session_id = str(uuid.uuid4())
    coord_pattern = CoordinationPattern.SEQUENTIAL if pattern == "SEQUENTIAL" else CoordinationPattern.PARALLEL
    
    state = await supervisor.orchestrate(
        session_id=session_id,
        pattern=coord_pattern,
        question=question
    )
    
    if state.plan:
        print("\n🧠 Reasoning:")
        print(f"   {state.plan.reasoning}")
        
        print("\n📝 Execution:")
        for step in state.plan.steps:
            if step.id in state.results:
                print_step(step.id, step.description, state.results[step.id])
    else:
        print("\n❌ No plan was generated.")

async def interactive_chat(supervisor: Supervisor, pattern: str, index: bool) -> None:
    print_banner()
    print("Type 'exit' or 'quit' to leave. Type 'index' to refresh schema.")
    
    if index:
        print("🔍 Initial schema indexing...")
        await supervisor.index_database_schema()

    session_id = str(uuid.uuid4())
    coord_pattern = CoordinationPattern.SEQUENTIAL if pattern == "SEQUENTIAL" else CoordinationPattern.PARALLEL

    while True:
        try:
            question = input("\n💬 pg-agent > ").strip()
            if not question:
                continue
            if question.lower() in ["exit", "quit"]:
                break
            if question.lower() == "index":
                print("🔍 Re-indexing database schema...")
                await supervisor.index_database_schema()
                continue

            state = await supervisor.orchestrate(
                session_id=session_id,
                pattern=coord_pattern,
                question=question
            )

            if state.plan and state.results:
                # Print last reasoning
                print(f"\n🧠 {state.plan.reasoning}")
                # Print only results for clarity in chat
                for step in state.plan.steps:
                    if step.id in state.results:
                        data = state.results[step.id]
                        if step.type == "SQL" and isinstance(data, list):
                             print(f"✅ Found {len(data)} results.")
                             if data:
                                 print(json.dumps(data[:3], indent=2)) # Show top 3
                        else:
                             print(f"✅ {step.description}: {data}")
            else:
                print("⚠️ I couldn't find an answer for that.")

        except KeyboardInterrupt:
            break
        except Exception as e:
            print(f"❌ Error: {e}")

def main() -> None:
    load_dotenv()
    
    parser = argparse.ArgumentParser(description="PG Agent - Internal Team DB Assistant")
    parser.add_argument("--verbose", "-v", action="store_true", help="Enable detailed logging")
    parser.add_argument("--index", action="store_true", help="Index database schema before running")
    
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # 'setup' command
    subparsers.add_parser("setup", help="Enable pgvector and prepare the database")

    # 'ask' command
    ask_parser = subparsers.add_parser("ask", help="Ask a single question")
    ask_parser.add_argument("question", type=str, help="The question you want to ask")
    ask_parser.add_argument("--pattern", type=str, default="SEQUENTIAL", choices=["SEQUENTIAL", "PARALLEL"], help="Orchestration pattern")
    ask_parser.add_argument("--redis", type=str, help="Redis URL")
    ask_parser.add_argument("--retries", type=int, default=1, help="Max retries")

    # 'chat' command
    chat_parser = subparsers.add_parser("chat", help="Start an interactive session")
    chat_parser.add_argument("--pattern", type=str, default="SEQUENTIAL", choices=["SEQUENTIAL", "PARALLEL"])
    chat_parser.add_argument("--redis", type=str, help="Redis URL")
    
    args = parser.parse_args()

    if args.verbose:
        logging.getLogger().setLevel(logging.INFO)

    # Validate Environment
    api_key = os.getenv("GEMINI_API_KEY")
    db_url = os.getenv("DATABASE_URL")
    
    if not api_key or not db_url:
        print("❌ Error: GEMINI_API_KEY and DATABASE_URL must be set in environment or .env file.")
        sys.exit(1)

    redis_url = getattr(args, "redis", None) or os.getenv("REDIS_URL")
    retries = getattr(args, "retries", 1)

    supervisor = Supervisor(
        api_key=api_key, 
        db_url=db_url, 
        redis_url=redis_url, 
        max_retries=retries
    )

    try:
        if args.command == "setup":
            print("🛠️  Setting up database for PG Agent...")
            results = asyncio.run(supervisor.setup_database())
            print(f"  ├─ pgvector: {results.get('pgvector')}")
            print(f"  ├─ Memory tables: {results.get('tables')}")
            if results.get("errors"):
                print("\n⚠️  Warnings/Errors encountered:")
                for err in results["errors"]:
                    print(f"  └─ {err}")
            else:
                print("\n✅ Database setup complete and ready!")
        elif args.command == "chat":
            asyncio.run(interactive_chat(supervisor, args.pattern, args.index))
        elif args.command == "ask" or (not args.command and hasattr(args, "question")):
            asyncio.run(run_query(supervisor, args.question or "", args.pattern, args.index))
        else:
            parser.print_help()
    except KeyboardInterrupt:
        print("\nGoodbye!")
    except Exception as e:
        print(f"\n❌ Fatal Error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
