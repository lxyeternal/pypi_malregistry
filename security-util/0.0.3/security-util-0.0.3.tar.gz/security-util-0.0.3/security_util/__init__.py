"""
Disclaimer!
For educational purposes only.
"""