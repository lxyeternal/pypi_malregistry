# lucifer

Commands : 

``pip install twine``
``python setup.py sdist``
``twine upload dist/*``