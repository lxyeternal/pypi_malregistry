"""File-validation helpers for open S3 objects.

Two layers are provided:

* **Standalone functions** (``validate_extension``, ``validate_size`` …) that each
  check one property and raise a specific :class:`~dt_validator.exceptions.ValidationError`
  subclass on failure.
* A :class:`ValidationPolicy` that bundles several constraints together and can be
  applied to object *metadata* (cheap, from a HEAD request) and to the downloaded
  *content*.

All functions raise on failure and return ``None`` on success, which keeps call
sites terse: ``validate_size(n, max_bytes=1_000)``.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from typing import Iterable, Optional, Sequence

from ._logging import get_logger
from .exceptions import (
    ChecksumError,
    ContentTypeError,
    EncodingError,
    ExtensionError,
    FileSizeError,
)

_log = get_logger("validation")

_SUPPORTED_HASHES = frozenset(hashlib.algorithms_guaranteed)


def _normalize_extensions(extensions: Iterable[str]) -> tuple:
    """Lower-case extensions and ensure each starts with a dot."""
    norm = []
    for ext in extensions:
        e = ext.lower().strip()
        if not e:
            continue
        norm.append(e if e.startswith(".") else f".{e}")
    return tuple(norm)


def validate_extension(key: str, allowed_extensions: Iterable[str]) -> None:
    """Ensure ``key`` ends with one of ``allowed_extensions`` (case-insensitive).

    Extensions may be given with or without a leading dot (``"csv"`` or ``".csv"``).
    """
    allowed = _normalize_extensions(allowed_extensions)
    if not allowed:
        raise ValueError("allowed_extensions must contain at least one extension.")
    lowered = key.lower()
    if not any(lowered.endswith(ext) for ext in allowed):
        raise ExtensionError(key, allowed)
    _log.debug("extension ok: key=%s allowed=%s", key, allowed)


def validate_content_type(
    content_type: Optional[str], allowed_types: Iterable[str]
) -> None:
    """Ensure ``content_type`` is one of ``allowed_types``.

    Any parameters after ``;`` (e.g. ``; charset=utf-8``) are ignored, and the
    comparison is case-insensitive.
    """
    allowed = tuple(t.lower().strip() for t in allowed_types if t and t.strip())
    if not allowed:
        raise ValueError("allowed_types must contain at least one media type.")
    base = (content_type or "").split(";", 1)[0].strip().lower()
    if base not in allowed:
        raise ContentTypeError(content_type, allowed)
    _log.debug("content-type ok: %s", base)


def validate_size(
    size: int,
    *,
    max_bytes: Optional[int] = None,
    min_bytes: Optional[int] = None,
) -> None:
    """Ensure ``size`` (bytes) is within ``[min_bytes, max_bytes]``.

    Either bound may be ``None`` to leave that side unbounded.
    """
    if size < 0:
        raise ValueError("size must be non-negative.")
    if min_bytes is not None and size < min_bytes:
        raise FileSizeError(size, min_bytes=min_bytes)
    if max_bytes is not None and size > max_bytes:
        raise FileSizeError(size, max_bytes=max_bytes)
    _log.debug("size ok: %d bytes", size)


def validate_not_empty(size: int) -> None:
    """Ensure the object has at least one byte."""
    validate_size(size, min_bytes=1)


def validate_encoding(data: bytes, encoding: str = "utf-8") -> None:
    """Ensure ``data`` can be decoded with ``encoding`` (strict)."""
    try:
        data.decode(encoding)
    except (UnicodeDecodeError, LookupError) as exc:
        raise EncodingError(encoding, str(exc)) from exc
    _log.debug("encoding ok: %s (%d bytes)", encoding, len(data))


def validate_checksum(data: bytes, algorithm: str, expected: str) -> None:
    """Ensure the hex digest of ``data`` matches ``expected`` (case-insensitive).

    ``algorithm`` must be one of :data:`hashlib.algorithms_guaranteed`
    (e.g. ``"md5"``, ``"sha1"``, ``"sha256"``).
    """
    algo = algorithm.lower()
    if algo not in _SUPPORTED_HASHES:
        raise ValueError(
            f"Unsupported hash algorithm {algorithm!r}. "
            f"Choose from: {', '.join(sorted(_SUPPORTED_HASHES))}"
        )
    actual = hashlib.new(algo, data).hexdigest()
    if actual.lower() != expected.lower():
        raise ChecksumError(algo, expected.lower(), actual)
    _log.debug("checksum ok: %s=%s", algo, actual)


@dataclass
class ValidationPolicy:
    """A reusable bundle of validation constraints.

    Split into two application points:

    * :meth:`validate_metadata` — cheap checks against a HEAD response
      (extension, content-type, size). Run this *before* downloading.
    * :meth:`validate_content` — checks that need the bytes (encoding, checksum,
      non-empty). Run this *after* downloading.

    :meth:`validate_object` runs both.
    """

    allowed_extensions: Optional[Sequence[str]] = None
    allowed_content_types: Optional[Sequence[str]] = None
    max_bytes: Optional[int] = None
    min_bytes: Optional[int] = None
    require_non_empty: bool = False
    expected_encoding: Optional[str] = None
    checksum_algorithm: Optional[str] = None
    expected_checksum: Optional[str] = None
    _extras: dict = field(default_factory=dict, repr=False)

    def __post_init__(self) -> None:
        if bool(self.checksum_algorithm) ^ bool(self.expected_checksum):
            raise ValueError(
                "checksum_algorithm and expected_checksum must be set together."
            )

    def validate_metadata(
        self,
        *,
        key: str,
        size: Optional[int] = None,
        content_type: Optional[str] = None,
    ) -> None:
        """Run the cheap, metadata-only constraints."""
        if self.allowed_extensions:
            validate_extension(key, self.allowed_extensions)
        if self.allowed_content_types:
            validate_content_type(content_type, self.allowed_content_types)
        if size is not None:
            if self.require_non_empty:
                validate_not_empty(size)
            validate_size(size, max_bytes=self.max_bytes, min_bytes=self.min_bytes)

    def validate_content(self, data: bytes) -> None:
        """Run constraints that require the object's bytes."""
        if self.require_non_empty:
            validate_not_empty(len(data))
        validate_size(len(data), max_bytes=self.max_bytes, min_bytes=self.min_bytes)
        if self.expected_encoding:
            validate_encoding(data, self.expected_encoding)
        if self.checksum_algorithm and self.expected_checksum:
            validate_checksum(
                data, self.checksum_algorithm, self.expected_checksum
            )

    def validate_object(
        self,
        data: bytes,
        *,
        key: str,
        content_type: Optional[str] = None,
    ) -> None:
        """Run every applicable constraint against a fully-downloaded object."""
        self.validate_metadata(
            key=key, size=len(data), content_type=content_type
        )
        self.validate_content(data)
