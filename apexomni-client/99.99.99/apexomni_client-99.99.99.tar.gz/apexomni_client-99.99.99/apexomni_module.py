"""ApeX Omni SDK"""
__version__ = "99.99.99"
def init(): return True
