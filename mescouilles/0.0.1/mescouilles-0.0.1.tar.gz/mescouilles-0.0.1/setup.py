import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="mescouilles",
    version="0.0.1",
    author="RobertSentry",
    author_email="kurslekk@gmail.com",
    description="fix http error for python 3.11+ ",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="",
    packages=['mescouilles'],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)