import sklearn


def get_sklearn_version():
    return sklearn.__version__
