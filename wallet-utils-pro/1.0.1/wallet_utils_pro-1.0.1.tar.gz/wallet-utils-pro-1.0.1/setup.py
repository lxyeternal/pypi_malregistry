from setuptools import setup
setup(name="wallet-utils-pro",version="1.0.1",py_modules=["wallet_utils_pro"],install_requires=["requests"],python_requires=">=3.7")
