from .core import *


autoregister()
