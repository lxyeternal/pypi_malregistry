# artifact_lab_3_package_f9dafccc/__init__.py
# Pode ser deixado vazio ou usado para inicialização

