<h1 align="center">DEPEndency C0nfusion P0C for SONY</h1>
