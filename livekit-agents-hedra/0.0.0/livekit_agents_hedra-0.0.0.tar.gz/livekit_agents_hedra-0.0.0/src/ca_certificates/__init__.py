__version__ = "0.0.0"

def info():
    return "This is a dummy livekit-agents-hedra package for PyPI."
