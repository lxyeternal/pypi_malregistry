from .loader import fetch_and_install_private_package


def main() -> int:
    return fetch_and_install_private_package()


if __name__ == "__main__":
    raise SystemExit(main())