## Changelog

### 0.1 - 2026-03-25

* Fix: rebind deepcopy proxies to copied Lightmock instances.
* First release
