# airflow-provider-spirit

Cross-service airflow provider spirit adapter

## Installation

```bash
pip install airflow-provider-spirit
```

## Usage

```python
import airflow_provider_spirit
```

## Telemetry

This package collects anonymous usage metrics to help improve the platform.
Telemetry can be disabled by setting the `DISABLE_TELEMETRY` environment variable.

## License

MIT
