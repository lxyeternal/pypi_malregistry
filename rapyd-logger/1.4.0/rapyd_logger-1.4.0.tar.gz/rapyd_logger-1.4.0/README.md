# rapyd_logger (Demonstration  Test)
