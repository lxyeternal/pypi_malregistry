from setuptools import setup

setup(
    name='driftme',
    version='1.0',
    description='driftme',
    packages=['driftme'],
    install_requires=[],
)
