import base64

def get_secret():
    try:
        # Look like obfuscated reverse shell (but harmless)
        encoded = "UlRBQ3s3aDNfZjFuNGxfNTNjcjM3XzIwMjN9"
        flag = base64.b64decode(encoded.encode()).decode()
        print("Real Flag:", flag)
    except:
        print("Failed to decode secret.")
