"""
A lightweight terminal color manager with extended logging capabilities.
"""
import sys

from . import colors
from . import formatter

# Public API
__all__ = ['print_c', 'print_formatted', 'COLORS']

COLORS = colors.COLORS

def print_c(text: str, color: str = 'white', end: str = '\n') -> None:
    """Print text in the specified color."""
    c_code = COLORS.get(color.lower(), COLORS['white'])
    sys.stdout.write(f"{c_code}{text}{COLORS['reset']}{end}")
    sys.stdout.flush()

def print_formatted(text: str, color: str = 'white', bg: str = None, bold: bool = False) -> None:
    """Print formatted text with color and styling."""
    formatted = formatter.format_text(text, color, bg, bold)
    sys.stdout.write(formatted)
    sys.stdout.flush()
