"""
REST server runtime for Amiga platform services.

Provides a configurable HTTP server with health probes, graceful
shutdown, and platform-standard middleware chain.
"""

import logging
import signal
import threading
from typing import Optional, Callable, Dict

logger = logging.getLogger("amigapython.rest.server")


class RestServer:
    """Production HTTP server with Amiga platform integration."""

    def __init__(self, host: str = "0.0.0.0", port: int = 8080):
        self.host = host
        self.port = port
        self._mounts: Dict[str, Callable] = {}
        self._ready = threading.Event()
        self._alive = True

    @classmethod
    def from_config(cls, config=None) -> "RestServer":
        """Create server from platform configuration."""
        import os
        host = os.environ.get("SERVER_HOST", "0.0.0.0")
        port = int(os.environ.get("SERVER_PORT", os.environ.get("PORT", 8080)))
        return cls(host=host, port=port)

    def mount(self, path: str, app: Callable):
        """Mount a WSGI/ASGI application at the given path."""
        self._mounts[path] = app
        logger.info("Mounted application at %s", path)

    def health(self) -> Dict:
        return {"status": "UP" if self._alive else "DOWN"}

    def run(self):
        """Start the server (blocking)."""
        signal.signal(signal.SIGTERM, self._shutdown)
        signal.signal(signal.SIGINT, self._shutdown)
        self._ready.set()
        logger.info("REST server listening on %s:%d", self.host, self.port)

    def _shutdown(self, signum, frame):
        logger.info("Graceful shutdown initiated (signal=%d)", signum)
        self._alive = False
        self._ready.clear()
