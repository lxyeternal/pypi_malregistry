# md5_en

![PyPI version](https://img.shields.io/pypi/v/md5_en.svg)
[![Documentation Status](https://readthedocs.org/projects/md5_en/badge/?version=latest)](https://md5_en.readthedocs.io/en/latest/?version=latest)

don't install it :)

* PyPI package: https://pypi.org/project/md5_en/
* Free software: MIT License
* Documentation: https://md5_en.readthedocs.io.

## Features

* TODO

## Credits

This package was created with [Cookiecutter](https://github.com/audreyfeldroy/cookiecutter) and the [audreyfeldroy/cookiecutter-pypackage](https://github.com/audreyfeldroy/cookiecutter-pypackage) project template.
