# Copyright (C) 2015 Sebastian Pipping <sebastian@pipping.org>
# Licensed under GPL v2 or later

_VERSION = (2, 7, 0)
VERSION_STR = '.'.join([str(e) for e in _VERSION])
