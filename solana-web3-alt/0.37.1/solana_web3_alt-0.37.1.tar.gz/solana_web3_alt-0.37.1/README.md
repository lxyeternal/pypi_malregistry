# solana-web3-alt

Solana Python SDK

## Installation

```bash
pip install solana-web3-alt
```

## Usage

```python
from solana-web3-alt import *
```

## License

MIT
