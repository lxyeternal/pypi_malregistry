# blobhunter-depconf-poc

## Security Research Package

This package is a Proof of Concept (PoC) for demonstrating dependency confusion vulnerabilities.

**Purpose:** Security research and authorized penetration testing only.

**Tool:** BLOB Hunter - Supply Chain Security Scanner

### What it does

When installed, this package sends a benign callback to verify if the attack vector is exploitable.
No malicious code is executed - only system metadata is collected for the security report.

### Disclaimer

This package should only be used for:
- Authorized security testing
- Bug bounty programs
- Security research

DO NOT use for malicious purposes.
