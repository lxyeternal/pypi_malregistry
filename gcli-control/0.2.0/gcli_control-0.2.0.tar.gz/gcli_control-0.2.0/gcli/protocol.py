"""
Protocol layer for gcli.
Manages the npoint document structure: init, read, claim, append, trim, write.
All command/result payloads are encrypted with AES-256-GCM via the crypto module.

Race-condition safety: append_command/append_result use a read-modify-write
cycle with merge-on-conflict. Since npoint has no atomic compare-and-swap,
we handle concurrent writes by:
  1. Reading the doc.
  2. Noting the existing entry IDs.
  3. Adding our new entry.
  4. Re-reading the doc to pick up concurrent writes.
  5. Merging any new entries we didn't add.
  6. Writing back.
"""
import uuid
import time
import copy
import logging
from typing import List, Dict, Optional, Set, Tuple

from . import npoint
from .crypto import encrypt_dict, decrypt_dict

logger = logging.getLogger("gcli.protocol")

MAX_QUEUE = 50  # max commands/results kept per write

EMPTY_DOC = {
    "session": "",
    "host_alive": False,
    "commands": [],
    "results": [],
}


def new_doc() -> dict:
    """Create a fresh empty document."""
    doc = copy.deepcopy(EMPTY_DOC)
    doc["session"] = str(uuid.uuid4())
    return doc


def init_doc(bin_id: str, password: str) -> str:
    """Write a fresh document to npoint and return the session id."""
    doc = new_doc()
    npoint.write(bin_id, doc)
    return doc["session"]


def read_doc(bin_id: str) -> dict:
    """Read the current document from npoint, normalising structure."""
    try:
        doc = npoint.read(bin_id)
    except RuntimeError:
        doc = copy.deepcopy(EMPTY_DOC)
    # Normalise: ensure required keys and correct types
    if not isinstance(doc, dict):
        doc = copy.deepcopy(EMPTY_DOC)
    for key in ("session", "host_alive", "commands", "results"):
        if key not in doc:
            doc[key] = EMPTY_DOC[key]
    if not isinstance(doc["commands"], list):
        doc["commands"] = []
    if not isinstance(doc["results"], list):
        doc["results"] = []
    return doc


def write_doc(bin_id: str, doc: dict) -> None:
    """Write the document back to npoint (after trimming)."""
    doc = trim(doc)
    npoint.write(bin_id, doc)


def append_command(bin_id: str, password: str, payload: dict) -> str:
    """
    Encrypt and append a command to the document with merge-on-write.
    Returns the command id.
    """
    cmd_id = payload.get("id") or str(uuid.uuid4())
    payload["id"] = cmd_id
    blob = encrypt_dict(payload, password)

    new_entry = {
        "id": cmd_id,
        "from": "client",
        "ts": time.time(),
        "payload": blob,
    }

    _safe_append(bin_id, "commands", new_entry)
    return cmd_id


def append_result(bin_id: str, password: str, cmd_id: str, payload: dict) -> str:
    """
    Encrypt and append a result for the given command with merge-on-write.
    Returns the result id.
    """
    res_id = str(uuid.uuid4())
    payload["cmd_id"] = cmd_id
    blob = encrypt_dict(payload, password)

    new_entry = {
        "id": res_id,
        "cmd_id": cmd_id,
        "from": "host",
        "ts": time.time(),
        "payload": blob,
    }

    _safe_append(bin_id, "results", new_entry)
    return res_id


def _safe_append(bin_id: str, field: str, new_entry: dict) -> None:
    """
    Read-modify-write with merge. Retries up to 3 times on conflict.

    Strategy:
      1. Read doc, note all existing IDs in the target field.
      2. Append new entry.
      3. Re-read to pick up any concurrent writes that happened during our write.
      4. Merge any new entries from the re-read that we missed.
      5. Write back.
    """
    MAX_ATTEMPTS = 3
    # Step 1: read
    doc = read_doc(bin_id)
    before_ids = {e["id"] for e in doc.get(field, [])}

    # Step 2: add our entry (avoid duplicate)
    if new_entry["id"] not in before_ids:
        doc.setdefault(field, []).append(new_entry)

    doc = trim(doc)

    # Step 3: write
    for attempt in range(MAX_ATTEMPTS):
        try:
            write_doc(bin_id, doc)
            # Step 4: re-read to check for concurrent writes that may have been lost
            doc2 = read_doc(bin_id)
            doc2_ids = {e["id"] for e in doc2.get(field, [])}
            missing = [e for e in doc.get(field, []) if e["id"] not in doc2_ids]
            if missing:
                # Our write was overwritten by a concurrent write - re-merge
                for entry in missing:
                    doc2.setdefault(field, []).append(entry)
                # Also merge their new entries we didn't have
                existing = {e["id"] for e in doc2.get(field, [])}
                for entry in doc.get(field, []):
                    if entry["id"] not in existing:
                        doc2.setdefault(field, []).append(entry)
                # Carry over other fields
                for key in ("session", "host_alive"):
                    if key in doc:
                        doc2[key] = doc[key]
                doc2 = trim(doc)
                write_doc(bin_id, doc2)
            return
        except RuntimeError as e:
            logger.debug("Write failed on attempt %d: %s", attempt + 1, e)
            if attempt < MAX_ATTEMPTS - 1:
                time.sleep(1.0 * (attempt + 1))
                doc = read_doc(bin_id)
                if new_entry["id"] not in {e["id"] for e in doc.get(field, [])}:
                    doc.setdefault(field, []).append(new_entry)
                doc = trim(doc)


def claim_commands(doc: dict, password: str, seen: Set[str]) -> List[Tuple[str, dict]]:
    """
    Return list of (cmd_id, decrypted_payload) for commands not yet in `seen`.
    Also adds their IDs to `seen` in-place.
    """
    claimed = []
    for entry in doc.get("commands", []):
        cmd_id = entry.get("id", "")
        if cmd_id in seen:
            continue
        seen.add(cmd_id)
        try:
            payload = decrypt_dict(entry["payload"], password)
            claimed.append((cmd_id, payload))
        except Exception:
            # bad encryption or wrong password -- skip
            continue
    return claimed


def claim_results(doc: dict, password: str, target_cmd_id: str, seen: Set[str]) -> Optional[dict]:
    """
    Look for a result matching target_cmd_id that we haven't seen yet.
    Returns the decrypted payload or None.
    """
    for entry in doc.get("results", []):
        res_id = entry.get("id", "")
        if res_id in seen:
            continue
        try:
            payload = decrypt_dict(entry["payload"], password)
        except Exception:
            seen.add(res_id)
            continue
        if payload.get("cmd_id") == target_cmd_id:
            seen.add(res_id)
            return payload
    return None


def claim_all_results(doc: dict, password: str, seen: Set[str]) -> List[dict]:
    """Return all un-seen decrypted results."""
    results = []
    for entry in doc.get("results", []):
        res_id = entry.get("id", "")
        if res_id in seen:
            continue
        seen.add(res_id)
        try:
            payload = decrypt_dict(entry["payload"], password)
            results.append(payload)
        except Exception:
            continue
    return results


def trim(doc: dict) -> dict:
    """Cap commands and results to MAX_QUEUE entries each (keep most recent)."""
    if len(doc.get("commands", [])) > MAX_QUEUE:
        doc["commands"] = doc["commands"][-MAX_QUEUE:]
    if len(doc.get("results", [])) > MAX_QUEUE:
        doc["results"] = doc["results"][-MAX_QUEUE:]
    return doc


def set_host_alive(bin_id: str, alive: bool) -> None:
    """Set the host_alive flag in the document safely."""
    doc = read_doc(bin_id)
    doc["host_alive"] = alive
    write_doc(bin_id, doc)


def is_host_alive(doc: dict) -> bool:
    return bool(doc.get("host_alive", False))
