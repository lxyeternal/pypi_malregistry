# setup.py

from setuptools import setup, find_packages

setup(
    name="blabutt",
    version="99.99.99",  
    author="testuser",
    author_email="testuser@example.com",
    description="A test package for dependency confusion",
    packages=find_packages(),
    install_requires=["requests"],  
    python_requires='>=3.6',
)
