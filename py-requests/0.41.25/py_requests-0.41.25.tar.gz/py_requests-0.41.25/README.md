# py-requests

HTTP library

## Installation

```bash
pip install py-requests
```

## Usage

```python
import py_requests
```

## License

MIT
