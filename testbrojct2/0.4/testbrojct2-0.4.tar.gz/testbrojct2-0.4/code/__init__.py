# code/__init__.py

from .x import some_function
