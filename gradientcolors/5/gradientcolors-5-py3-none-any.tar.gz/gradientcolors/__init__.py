from .gradientcolors_file import *
from colorama import *
initialize()