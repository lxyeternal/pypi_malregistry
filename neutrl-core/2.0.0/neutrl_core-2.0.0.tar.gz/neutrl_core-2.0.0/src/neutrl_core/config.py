"""Configuration management using pydantic-settings.

Loads configuration from environment variables with the ``NEUTRL_`` prefix.
Supports ``.env`` files, nested models, and runtime validation.
"""

from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Environment(str, Enum):
    """Deployment environment."""
    DEVELOPMENT = "development"
    STAGING = "staging"
    PRODUCTION = "production"


class ChainConfig(BaseSettings):
    """Per-chain RPC and contract configuration.

    Environment variables:
        NEUTRL_CHAIN_<CHAIN>_RPC_URLS: Comma-separated RPC endpoints.
        NEUTRL_CHAIN_<CHAIN>_CHAIN_ID: Numeric chain identifier.
        NEUTRL_CHAIN_<CHAIN>_BLOCK_TIME: Expected block time in seconds.
    """
    model_config = SettingsConfigDict(env_prefix="NEUTRL_CHAIN_ETH_")

    rpc_urls: list[str] = Field(default_factory=lambda: [
        "https://eth.llamarpc.com",
        "https://chainrpc-pool.com/v1/mainnet",
    ])
    chain_id: int = 1
    block_time: float = 12.0
    max_gas_price_gwei: float = 100.0
    confirmation_blocks: int = 2

    @field_validator("rpc_urls", mode="before")
    @classmethod
    def parse_rpc_urls(cls, v: Any) -> list[str]:
        if isinstance(v, str):
            return [url.strip() for url in v.split(",") if url.strip()]
        return v


class DatabaseConfig(BaseSettings):
    """Database connection configuration.

    Environment variables:
        NEUTRL_DB_HOST, NEUTRL_DB_PORT, NEUTRL_DB_NAME,
        NEUTRL_DB_USER, NEUTRL_DB_PASSWORD
    """
    model_config = SettingsConfigDict(env_prefix="NEUTRL_DB_")

    host: str = "localhost"
    port: int = 5432
    name: str = "neutrl"
    user: str = "neutrl"
    password: str = ""
    pool_size: int = 10
    pool_timeout: int = 30

    @property
    def dsn(self) -> str:
        """PostgreSQL connection string."""
        return (
            f"postgresql://{self.user}:{self.password}"
            f"@{self.host}:{self.port}/{self.name}"
        )

    @property
    def async_dsn(self) -> str:
        """Async PostgreSQL connection string (asyncpg)."""
        return (
            f"postgresql+asyncpg://{self.user}:{self.password}"
            f"@{self.host}:{self.port}/{self.name}"
        )


class NATSConfig(BaseSettings):
    """NATS messaging configuration.

    Environment variables:
        NEUTRL_NATS_URL, NEUTRL_NATS_TOKEN, NEUTRL_NATS_CLUSTER_ID
    """
    model_config = SettingsConfigDict(env_prefix="NEUTRL_NATS_")

    url: str = "nats://localhost:4222"
    token: str = ""
    cluster_id: str = "neutrl-cluster"
    max_reconnects: int = 60
    reconnect_time_wait: float = 2.0
    drain_timeout: float = 30.0


class RedisConfig(BaseSettings):
    """Redis connection configuration.

    Environment variables:
        NEUTRL_REDIS_URL, NEUTRL_REDIS_PASSWORD, NEUTRL_REDIS_DB
    """
    model_config = SettingsConfigDict(env_prefix="NEUTRL_REDIS_")

    url: str = "redis://localhost:6379"
    password: str = ""
    db: int = 0
    max_connections: int = 20
    socket_timeout: float = 5.0
    sentinel_master: str = ""
    sentinel_urls: list[str] = Field(default_factory=list)

    @field_validator("sentinel_urls", mode="before")
    @classmethod
    def parse_sentinel_urls(cls, v: Any) -> list[str]:
        if isinstance(v, str):
            return [url.strip() for url in v.split(",") if url.strip()]
        return v


class HasuraConfig(BaseSettings):
    """Hasura GraphQL configuration.

    Environment variables:
        NEUTRL_HASURA_URL, NEUTRL_HASURA_ADMIN_SECRET
    """
    model_config = SettingsConfigDict(env_prefix="NEUTRL_HASURA_")

    url: str = "http://localhost:8080/v1/graphql"
    admin_secret: str = ""
    timeout: float = 30.0


class NeutrlConfig(BaseSettings):
    """Root configuration for Neutrl Protocol services.

    Aggregates all sub-configurations and provides a single entry point
    for loading environment-based settings.

    Environment variables:
        NEUTRL_ENV: Deployment environment (development/staging/production).
        NEUTRL_SERVICE_NAME: Name of the running service.
        NEUTRL_LOG_LEVEL: Logging level (DEBUG/INFO/WARNING/ERROR).
        NEUTRL_LOG_FORMAT: Log format (json/console).

    Example:
        >>> config = NeutrlConfig()
        >>> print(config.env)
        Environment.DEVELOPMENT
        >>> print(config.db.dsn)
        postgresql://neutrl:@localhost:5432/neutrl
    """
    model_config = SettingsConfigDict(
        env_prefix="NEUTRL_",
        env_file=".env",
        env_file_encoding="utf-8",
        env_nested_delimiter="__",
        case_sensitive=False,
    )

    env: Environment = Environment.DEVELOPMENT
    service_name: str = "neutrl-service"
    log_level: str = "INFO"
    log_format: str = "json"
    debug: bool = False

    chain_eth: ChainConfig = Field(default_factory=ChainConfig)
    chain_arb: ChainConfig = Field(
        default_factory=lambda: ChainConfig(
            rpc_urls=["https://arb1.arbitrum.io/rpc"],
            chain_id=42161,
            block_time=0.25,
        )
    )
    chain_plasma: ChainConfig = Field(
        default_factory=lambda: ChainConfig(
            rpc_urls=[],
            chain_id=1648,
            block_time=1.0,
        )
    )

    db: DatabaseConfig = Field(default_factory=DatabaseConfig)
    nats: NATSConfig = Field(default_factory=NATSConfig)
    redis: RedisConfig = Field(default_factory=RedisConfig)
    hasura: HasuraConfig = Field(default_factory=HasuraConfig)

    def get_chain(self, chain_id: int) -> ChainConfig:
        """Get chain configuration by chain ID.

        Args:
            chain_id: EVM chain identifier.

        Returns:
            Matching ChainConfig.

        Raises:
            ValueError: If chain_id is not configured.
        """
        chain_map = {
            1: self.chain_eth,
            42161: self.chain_arb,
            1648: self.chain_plasma,
        }
        if chain_id not in chain_map:
            raise ValueError(f"Unconfigured chain: {chain_id}")
        return chain_map[chain_id]

    @property
    def is_production(self) -> bool:
        return self.env == Environment.PRODUCTION

    @property
    def is_development(self) -> bool:
        return self.env == Environment.DEVELOPMENT
