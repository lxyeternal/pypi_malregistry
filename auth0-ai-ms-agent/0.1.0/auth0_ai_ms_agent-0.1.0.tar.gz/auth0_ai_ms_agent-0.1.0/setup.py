from setuptools import setup, find_packages

setup(
    name="auth0-ai-ms-agent",
    version="0.1.0",
    description="SDK for building secure AI-powered applications using Auth0, Okta FGA and Microsoft Agent Framework",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="Auth0 Inc.",
    author_email="support@auth0.com",
    license="Apache-2.0",
    python_requires=">=3.7",
    packages=find_packages(),
)
