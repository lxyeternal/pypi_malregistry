from setuptools import setup, find_packages
setup(name = "xgoogle_cloud_core", version = "1.4.3", packages = find_packages())