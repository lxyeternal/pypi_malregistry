from setuptools import setup, find_packages

setup(
    name="jec",
    version="39.0.1",
    description="Operational package utility",
    author="Dev",
    packages=find_packages(),
)