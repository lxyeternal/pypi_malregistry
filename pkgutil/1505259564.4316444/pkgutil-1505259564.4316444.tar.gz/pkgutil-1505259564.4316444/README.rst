Beware of typosquatting in package managers!
============================================

pkgutil

`https://www.pytosquatting.org <https://www.pytosquatting.org>`__