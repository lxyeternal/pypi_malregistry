=====
Usage
=====

To use AWS Consoler in a project::

    import aws_consoler

To use AWS Consoler on the command line, run the following for the full help output::

    aws_consoler -h
