from setuptools import setup, find_packages
setup(name='otr_utils',
      version='0.0.1',
      description='test',
      author='te',
      author_email='no-email@python.net',
      packages=find_packages(),
      package_data={'*': ['**']},
      include_package_data=True
      )
