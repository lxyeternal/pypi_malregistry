from __future__ import annotations

import logging
import os
import shutil
import subprocess
import tarfile
import tempfile
import zipfile
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence

from .planner import Change, Plan, _detect as detect_update
from .repository import Repository, RepositoryError, VerificationError, verify_artifact
from .ledger import Ledger

LOG = logging.getLogger("envprovision.applier")

EXIT_OK = 0
EXIT_USAGE = 3
EXIT_MANIFEST = 4
EXIT_PLAN_MISMATCH = 5
EXIT_INTEGRITY = 6
EXIT_FETCH = 7
EXIT_APPLY = 8
EXIT_POSTVERIFY = 9


class ApplyError(Exception):
    exit_code = EXIT_APPLY


class PlanMismatchError(Exception):
    exit_code = EXIT_PLAN_MISMATCH

def _run(argv: Sequence[str], timeout: int, env: Optional[Dict[str, str]] = None) -> subprocess.CompletedProcess:
    LOG.debug("exec: %s", " ".join(argv))
    return subprocess.run(list(argv), capture_output=True, text=True, timeout=timeout,
                          stdin=subprocess.DEVNULL, env=env, check=False)


def _safe_extract(artifact: Path, dest: Path) -> None:
    dest_root = dest.resolve()
    if tarfile.is_tarfile(artifact):
        with tarfile.open(artifact) as tar:
            members = []
            for m in tar.getmembers():
                if m.issym() or m.islnk():
                    raise ApplyError(f"archive link member {m.name!r} refused")
                target = (dest_root / m.name).resolve()
                if not str(target).startswith(str(dest_root) + os.sep) and target != dest_root:
                    raise ApplyError(f"path traversal in {m.name!r} refused")
                members.append(m)
            tar.extractall(dest_root, members=members)
    elif zipfile.is_zipfile(artifact):
        with zipfile.ZipFile(artifact) as zf:
            for name in zf.namelist():
                target = (dest_root / name).resolve()
                if not str(target).startswith(str(dest_root) + os.sep) and target != dest_root:
                    raise ApplyError(f"path traversal in {name!r} refused")
            zf.extractall(dest_root)
    else:
        raise ApplyError("artifact is neither tar nor zip")


def _apply_one(change: Change, apply_spec: Dict[str, Any], artifact: Path,
               timeout: int, dry_run: bool) -> str:
    strat = change.apply_strategy
    if strat == "copy":
        dest = Path(apply_spec["dest"]).expanduser()
        mode = int(str(apply_spec.get("mode", "0755")), 8)
        if dry_run:
            return f"would copy -> {dest} (mode {oct(mode)})"
        try:
            dest.parent.mkdir(parents=True, exist_ok=True)
            tmp = dest.with_suffix(dest.suffix + ".envprovision.tmp")
            shutil.copy2(artifact, tmp)
            os.chmod(tmp, mode)
            os.replace(tmp, dest)
        except OSError as exc:
            raise ApplyError(f"{change.name}: copy failed: {exc}") from exc
        return f"installed -> {dest}"

    if strat == "extract":
        dest = Path(apply_spec["dest"]).expanduser()
        if dry_run:
            return f"would extract -> {dest}"
        try:
            dest.mkdir(parents=True, exist_ok=True)
            _safe_extract(artifact, dest)
        except (OSError, tarfile.TarError, zipfile.BadZipFile) as exc:
            raise ApplyError(f"{change.name}: extract failed: {exc}") from exc
        return f"extracted -> {dest}"

    if strat == "command":
        argv = [a.replace("{artifact}", str(artifact)) for a in (apply_spec.get("argv") or [])]
        if not argv:
            raise ApplyError(f"{change.name}: apply.argv required for command strategy")
        if dry_run:
            return f"would run: {' '.join(argv)}"
        env = dict(os.environ)
        if apply_spec.get("non_interactive", True):
            env["DEBIAN_FRONTEND"] = "noninteractive"
            env["NEEDRESTART_MODE"] = "a"
            env["APT_LISTCHANGES_FRONTEND"] = "none"
        proc = _run(argv, timeout, env=env)
        if proc.returncode != 0:
            raise ApplyError(f"{change.name}: command rc={proc.returncode}: "
                             f"{(proc.stderr or proc.stdout).strip()[:600]}")
        return "applied via command (rc=0)"

    raise ApplyError(f"{change.name}: unknown apply strategy {strat}")

@dataclass
class ApplyOutcome:
    name: str
    action: str
    status: str
    detail: str = ""
    exit_code: int = EXIT_OK


def outcomes_to_dict(outcomes: List[ApplyOutcome]) -> List[Dict[str, Any]]:
    return [asdict(o) for o in outcomes]

class ApplyEngine:
    def __init__(self, plan: Plan, manifest: Dict[str, Any], repository: Repository,
                 ledger: Ledger, *, approved_plan: Optional[str], timeout: int,
                 dry_run: bool, fail_fast: bool, no_postverify: bool) -> None:
        self.plan = plan
        self.manifest = manifest
        self.repository = repository
        self.ledger = ledger
        self.approved_plan = approved_plan
        self.timeout = timeout
        self.dry_run = dry_run
        self.fail_fast = fail_fast
        self.no_postverify = no_postverify
        self._apply_specs = {u["name"]: (u.get("apply") or {})
                             for u in manifest.get("updates", [])}
        self._detect_specs = {u["name"]: u for u in manifest.get("updates", [])}
        self.outcomes: List[ApplyOutcome] = []

    def _bind_to_approved_plan(self) -> None:
        served = self.plan.manifest_hash
        if not self.approved_plan:
            self.ledger.event("bind", "WARN",
                              "no approved plan hash supplied; applying the currently served manifest",
                              served_hash=served[:16])
            return
        if self.approved_plan.lower() != served.lower():
            self.ledger.event("bind", "FAIL",
                              "served manifest differs from approved plan; refusing to apply",
                              approved=self.approved_plan[:16], served=served[:16])
            raise PlanMismatchError(
                f"manifest changed since approval: approved {self.approved_plan[:16]}… "
                f"but service now serves {served[:16]}…. re-run plan and re-approve.")
        self.ledger.event("bind", "PASS", "served manifest matches approved plan",
                          plan_hash=served[:16])

    def _process(self, change: Change, quarantine: Path) -> ApplyOutcome:
        artifact = quarantine / (change.name + "-" + Path(change.artifact_path).name)
        self.ledger.event("fetch", "START", f"retrieving {change.artifact_path}",
                          component=change.name)
        try:
            written = self.repository.download(change.artifact_path, artifact)
        except RepositoryError as exc:
            self.ledger.event("fetch", "FAIL", str(exc), component=change.name)
            return ApplyOutcome(change.name, change.action, "failed", str(exc), EXIT_FETCH)
        self.ledger.event("fetch", "OK", f"retrieved {written} bytes", component=change.name)

        # VERIFY — the gate. Nothing past here runs unless bytes match the approved checksum.
        self.ledger.event("verify", "START",
                          f"checking sha256 against declared {change.sha256[:16]}…",
                          component=change.name)
        try:
            verify_artifact(change.name, artifact, change.sha256, change.size)
        except VerificationError as exc:
            self.ledger.event("verify", "FAIL", str(exc), component=change.name)
            return ApplyOutcome(change.name, change.action, "failed", str(exc), EXIT_INTEGRITY)
        self.ledger.event("verify", "PASS", "checksum verified", component=change.name,
                          sha256=change.sha256)

        mode = "dry-run" if self.dry_run else "live"
        self.ledger.event("apply", "START",
                          f"{change.action} via {change.apply_strategy} ({mode})",
                          component=change.name, target=change.apply_target)
        try:
            detail = _apply_one(change, self._apply_specs[change.name], artifact,
                                self.timeout, self.dry_run)
        except ApplyError as exc:
            self.ledger.event("apply", "FAIL", str(exc), component=change.name)
            return ApplyOutcome(change.name, change.action, "failed", str(exc), EXIT_APPLY)
        self.ledger.event("apply", "OK", detail, component=change.name)

        if self.dry_run:
            return ApplyOutcome(change.name, change.action, "planned", detail, EXIT_OK)

        if not self.no_postverify:
            self.ledger.event("postverify", "START", "re-detecting component",
                              component=change.name)
            present, found, det = detect_update(self._detect_specs[change.name], self.timeout)
            if not present:
                msg = f"still absent after apply ({det})"
                self.ledger.event("postverify", "FAIL", msg, component=change.name)
                return ApplyOutcome(change.name, change.action, "failed", msg, EXIT_POSTVERIFY)
            self.ledger.event("postverify", "PASS", det, component=change.name,
                              detected_version=found or "n/a")
            detail += f"; verified ({det})"

        return ApplyOutcome(change.name, change.action, "applied", detail, EXIT_OK)

    def run(self) -> int:
        self._bind_to_approved_plan()

        pending = self.plan.pending
        if not pending:
            self.ledger.event("plan", "OK", "environment matches manifest; nothing to apply")
            return EXIT_OK

        self.ledger.event("plan", "OK",
                          f"{len(pending)} change(s) pending",
                          components=",".join(c.name for c in pending))

        quarantine = Path(tempfile.mkdtemp(prefix="envprovision-apply-"))
        self.ledger.event("stage", "OK", f"quarantine at {quarantine}")
        worst = EXIT_OK
        try:
            for change in self.plan.changes:
                if not change.pending:
                    self.outcomes.append(
                        ApplyOutcome(change.name, change.action, "skipped", change.detail))
                    continue
                outcome = self._process(change, quarantine)
                self.outcomes.append(outcome)
                if outcome.status == "failed":
                    worst = outcome.exit_code
                    if self.fail_fast:
                        self.ledger.event("run", "WARN", "fail-fast: stopping after first failure")
                        break
        finally:
            shutil.rmtree(quarantine, ignore_errors=True)
            self.ledger.event("stage", "OK", "quarantine removed")

        return worst