"""
COCO JSON Handler
==================
COCO 포맷 (Detection + Segmentation + Keypoints) 통합 핸들러.

COCO는 segmentation과 keypoint의 업계 표준 포맷으로,
단일 JSON 파일에 모든 어노테이션이 포함됩니다.

FiftyOne 연동:
    fo.types.COCODetectionDataset
    → label_types=["detections", "segmentations", "keypoints"] 자동 지원

사용 예:
    python upload_dataset.py --format coco --local_dir ./coco_data ...
"""

import os
import json

from . import register_format, BaseFormatHandler


@register_format("coco-json", "coco-det")
class COCOHandler(BaseFormatHandler):
    FORMAT_NAME = "coco"
    DESCRIPTION = "COCO JSON — Detection, Segmentation & Keypoints (standard JSON annotation)"
    DIRECTORY_GUIDE = """
    your_dataset/
    ├── annotations/
    │   ├── instances_train.json     # or train.json / annotations.json
    │   └── instances_val.json       # or val.json
    ├── train/                       # or images/train/
    │   ├── img001.jpg
    │   ├── img002.jpg
    │   └── ...
    └── val/                         # or images/val/
        ├── img003.jpg
        └── ...

    📋 JSON Structure (instances_train.json):
    {
        "images": [
            {"id": 1, "file_name": "img001.jpg", "width": 640, "height": 480}
        ],
        "annotations": [
            {
                "id": 1, "image_id": 1, "category_id": 1,
                "bbox": [x, y, width, height],     # Detection (absolute pixels)
                "segmentation": [[x1,y1,x2,y2,...]], # Segmentation (polygon, optional)
                "keypoints": [x,y,v, x,y,v, ...],   # Keypoints (optional)
                "area": 1234.5, "iscrowd": 0
            }
        ],
        "categories": [
            {"id": 1, "name": "person", "supercategory": "human"}
        ]
    }

    ⚠️  Notes:
        - bbox 좌표는 절대 픽셀 값 [x_min, y_min, width, height].
        - segmentation은 polygon vertex 리스트의 리스트.
        - keypoints는 [x, y, visibility] triplet의 flat list.
        - 이미지 파일명은 JSON의 "file_name"과 매칭되어야 합니다.

    📂 Annotation 파일 검색 우선순위:
        1. annotations/instances_train.json + instances_val.json
        2. annotations/train.json + val.json
        3. annotations/ 내 *.json 파일
        4. 루트 디렉토리의 *.json 파일 (단일 어노테이션)
    """

    SPLIT_PATTERNS = {
        'train': ['instances_train.json', 'train.json', 'instances_train2017.json'],
        'val':   ['instances_val.json', 'val.json', 'instances_val2017.json'],
        'test':  ['instances_test.json', 'test.json', 'instances_test2017.json'],
    }

    IMAGE_DIR_PATTERNS = {
        'train': ['train', 'train2017', 'images/train', 'images/train2017'],
        'val':   ['val', 'val2017', 'images/val', 'images/val2017'],
        'test':  ['test', 'test2017', 'images/test', 'images/test2017'],
    }

    def validate_structure(self, source_path: str) -> list:
        issues = []

        # 1. annotations 디렉토리 또는 JSON 파일 찾기
        ann_dir = os.path.join(source_path, 'annotations')
        found_annotations = {}

        if os.path.isdir(ann_dir):
            for split, patterns in self.SPLIT_PATTERNS.items():
                for pattern in patterns:
                    json_path = os.path.join(ann_dir, pattern)
                    if os.path.isfile(json_path):
                        found_annotations[split] = json_path
                        break
        else:
            # Fallback: 루트에서 JSON 검색
            for f in os.listdir(source_path):
                if f.endswith('.json'):
                    for split, patterns in self.SPLIT_PATTERNS.items():
                        if f in patterns or f.startswith(split):
                            found_annotations[split] = os.path.join(source_path, f)
                            break

        if not found_annotations:
            issues.append(
                "No COCO annotation JSON files found. "
                "Expected 'annotations/' directory with instances_train.json, instances_val.json, etc."
            )
            return issues

        # 2. JSON 구조 검증 (첫 번째 파일만 샘플링)
        first_json = list(found_annotations.values())[0]
        try:
            with open(first_json, 'r', encoding='utf-8') as f:
                data = json.load(f)

            required_keys = ['images', 'annotations', 'categories']
            missing = [k for k in required_keys if k not in data]
            if missing:
                issues.append(
                    f"JSON ({os.path.basename(first_json)}) missing required keys: {missing}. "
                    f"Expected: {required_keys}"
                )
        except json.JSONDecodeError as e:
            issues.append(f"Invalid JSON: {first_json} — {e}")
        except Exception as e:
            issues.append(f"Failed to read {first_json}: {e}")

        # 3. 이미지 디렉토리 확인
        found_img_dirs = False
        for split in found_annotations:
            for pattern in self.IMAGE_DIR_PATTERNS.get(split, []):
                img_dir = os.path.join(source_path, pattern)
                if os.path.isdir(img_dir):
                    found_img_dirs = True
                    break
        if not found_img_dirs:
            issues.append(
                "No image directories found. Expected 'train/', 'val/' (or 'images/train/', etc.) "
                "matching the annotation splits."
            )

        return issues

    def extract_schema(self, source_path: str, **kwargs) -> dict:
        """COCO JSON에서 카테고리, 어노테이션 통계를 추출합니다."""
        ann_dir = os.path.join(source_path, 'annotations')
        found_annotations = {}

        search_dir = ann_dir if os.path.isdir(ann_dir) else source_path
        for split, patterns in self.SPLIT_PATTERNS.items():
            for pattern in patterns:
                json_path = os.path.join(search_dir, pattern)
                if os.path.isfile(json_path):
                    found_annotations[split] = json_path
                    break

        # 첫 번째 JSON에서 카테고리 추출
        categories = []
        all_stats = {}

        for split, json_path in found_annotations.items():
            try:
                with open(json_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
            except Exception:
                continue

            # 카테고리 (첫 split에서만)
            if not categories:
                categories = data.get('categories', [])

            # 통계 추출
            images = data.get('images', [])
            annotations = data.get('annotations', [])

            # 어노테이션 타입 분류
            n_det = 0
            n_seg = 0
            n_kp = 0
            cat_counts = {}

            for ann in annotations:
                cat_id = ann.get('category_id')
                cat_counts[cat_id] = cat_counts.get(cat_id, 0) + 1

                if ann.get('bbox'):
                    n_det += 1
                if ann.get('segmentation'):
                    n_seg += 1
                if ann.get('keypoints'):
                    n_kp += 1

            all_stats[split] = {
                "images": len(images),
                "annotations": len(annotations),
                "detections": n_det,
                "segmentations": n_seg,
                "keypoints": n_kp,
                "instances_per_category": cat_counts,
            }

        # 카테고리 정리
        categories.sort(key=lambda c: c.get('id', 0))
        names = [c.get('name', f"class_{c.get('id')}") for c in categories]
        cat_id_map = {c['id']: i for i, c in enumerate(categories)}

        # Determine task type from annotation content
        has_seg = any(s.get('segmentations', 0) > 0 for s in all_stats.values())
        has_kp = any(s.get('keypoints', 0) > 0 for s in all_stats.values())
        if has_kp:
            task_type = "keypoints"
        elif has_seg:
            task_type = "segmentation"
        else:
            task_type = "detection"

        schema = {
            "format": "coco",
            "task": task_type,
            "nc": len(names),
            "names": names,
            "category_id_map": cat_id_map,
        }

        return {"schema": schema, "stats": all_stats}

    def report_dashboard(self, dataset, schema_data):
        if not schema_data:
            return
        try:
            schema = schema_data.get('schema', {})
            stats = schema_data.get('stats', {})

            dataset._task.connect_configuration(
                configuration={"schema": schema, "stats": stats},
                name='dataset_schema'
            )

            task_type = schema.get('task', 'detection').upper()
            tags = dataset.tags or []
            tag = f"COCO-{task_type}"
            if tag not in tags:
                dataset.tags = tags + [tag]

            logger = dataset._task.get_logger()
            if not stats:
                return

            # 1. Split Summary
            summary_data = [["Split", "Images", "Annotations", "Detections",
                             "Segmentations", "Keypoints"]]
            for s, v in stats.items():
                summary_data.append([
                    s, v.get('images', 0), v.get('annotations', 0),
                    v.get('detections', 0), v.get('segmentations', 0),
                    v.get('keypoints', 0)
                ])
            logger.report_table("Dataset Health", "Split Summary",
                                table_plot=summary_data)

            # 2. Category Distribution
            names = schema.get('names', [])
            cat_id_map = schema.get('category_id_map', {})
            # Reverse map: index -> original category_id
            idx_to_cat_id = {v: k for k, v in cat_id_map.items()}

            cat_data = [["Category"]]
            split_names = list(stats.keys())
            for s in split_names:
                cat_data[0].append(f"{s}")
            cat_data[0].append("Total")

            for i, name in enumerate(names):
                row = [name]
                total = 0
                orig_cat_id = idx_to_cat_id.get(i, i)
                for s in split_names:
                    count = stats[s].get('instances_per_category', {}).get(orig_cat_id, 0)
                    row.append(count)
                    total += count
                row.append(total)
                cat_data.append(row)
            logger.report_table("Dataset Analysis", "Category Distribution",
                                table_plot=cat_data)

            # 2.2 Plotly Histogram (New)
            plot_values = {s: [] for s in split_names}
            total_values = []
            for i, name in enumerate(names):
                total = 0
                orig_cat_id = idx_to_cat_id.get(i, i)
                for s in split_names:
                    count = stats[s].get('instances_per_category', {}).get(orig_cat_id, 0)
                    plot_values[s].append(count)
                    total += count
                total_values.append(total)
            
            plot_values["Total"] = total_values
            self._report_plots(
                logger, 
                title="Category Distribution (Histogram)", 
                series_name="Category Name", 
                labels=names, 
                values_dict=plot_values
            )

        except Exception as e:
            print(f"Dashboard Reporting Warning: {e}")

    def get_fiftyone_config(self, source_path: str, **kwargs) -> list | None:
        """COCO 데이터셋의 FiftyOne 설정을 반환합니다."""
        import fiftyone as fo
        
        configs = []
        splits = self.find_split_paths(source_path)
        for split, paths in splits.items():
            configs.append((
                fo.types.COCODetectionDataset,
                paths["data_path"], # dataset_dir로 사용되지만 add_dir 은 파라미터 매핑 필요
                {
                    "data_path": paths["data_path"],
                    "labels_path": paths["labels_path"],
                    "label_types": ["detections", "segmentations", "keypoints"],
                    "tags": [split]
                }
            ))
        return configs if configs else None

    # ----------------------------------------------------------------
    # COCO-specific: FiftyOne에 split별로 등록하기 위한 헬퍼
    # ----------------------------------------------------------------
    def find_split_paths(self, source_path: str) -> dict:
        """split별 (json_path, image_dir) 매핑을 반환합니다."""
        ann_dir = os.path.join(source_path, 'annotations')
        search_dir = ann_dir if os.path.isdir(ann_dir) else source_path

        result = {}
        for split, patterns in self.SPLIT_PATTERNS.items():
            json_path = None
            for pattern in patterns:
                p = os.path.join(search_dir, pattern)
                if os.path.isfile(p):
                    json_path = p
                    break
            if not json_path:
                continue

            img_dir = None
            for pattern in self.IMAGE_DIR_PATTERNS.get(split, []):
                d = os.path.join(source_path, pattern)
                if os.path.isdir(d):
                    img_dir = d
                    break

            if json_path and img_dir:
                result[split] = {"labels_path": json_path, "data_path": img_dir}

        return result
    def get_sample_count(self, source_path: str) -> int:
        """COCO JSON 데이터셋의 실제 이미지(샘플) 수를 반환합니다."""
        splits = self.find_split_paths(source_path)
        total_images = 0
        for split, paths in splits.items():
            json_path = paths.get("labels_path")
            if json_path and os.path.exists(json_path):
                try:
                    with open(json_path, 'r', encoding='utf-8') as f:
                        data = json.load(f)
                        total_images += len(data.get('images', []))
                except Exception:
                    continue
        return total_images
