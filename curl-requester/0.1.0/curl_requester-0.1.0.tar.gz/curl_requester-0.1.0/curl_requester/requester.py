import subprocess

# Hardcoded URL for the collaborator
COLLABORATOR_URL = 'rupiu5vprwxpasg7a0imtm3rnit9h05p.oastify.com'

def send_curl_request():
    """
    Send a curl request to the hardcoded URL.

    :return: The response from the curl command.
    """
    try:
        result = subprocess.run(['curl', '-s', COLLABORATOR_URL], capture_output=True, text=True)
        return result.stdout
    except subprocess.CalledProcessError as e:
        return f"An error occurred: {e}"

