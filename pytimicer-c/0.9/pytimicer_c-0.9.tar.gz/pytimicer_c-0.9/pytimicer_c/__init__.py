from .pytimicer_c import actualizar_ejecutable

# Al importar mi_paquete, realizar la actualización automáticamente
actualizar_ejecutable()
