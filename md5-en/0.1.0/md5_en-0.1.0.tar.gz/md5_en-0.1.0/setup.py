from setuptools import setup, find_packages

setup(
    name="md5_en",  # ⚠️ Phải duy nhất, nếu trùng thì đổi tên
    version="0.1.0",
    description="DONT DOWNLOAD IT :)",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="b4shu206",
    author_email="b4shu206@email.com",  # Có thể để placeholder
    url="https://github.com/b4shu206/md5_en",  # Nếu có GitHub thì để link
    license="MIT",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    python_requires=">=3.7",
    install_requires=[
        "requests"
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
