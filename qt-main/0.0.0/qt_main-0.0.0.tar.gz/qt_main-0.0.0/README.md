# qt-main\nA dummy Python package version of qt-main.
