def calc(x,y):
    return x+y
