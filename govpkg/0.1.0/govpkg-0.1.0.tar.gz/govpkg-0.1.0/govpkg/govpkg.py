from __future__ import annotations

import requests
from urllib.parse import quote

from govpkg._internal import normalizeHelper

BASE_URL = "https://pkg.go.dev"
SEARCH_API = f"{BASE_URL}/v1beta/search"
PACKAGE_API = f"{BASE_URL}/v1beta/package"
MODULE_API = f"{BASE_URL}/v1beta/module"


def _normalize(path: str) -> str:
    """Strip pkg.go.dev URL prefix if present."""
    prefixes = (
        "https://pkg.go.dev/",
        "http://pkg.go.dev/",
    )
    for prefix in prefixes:
        if path.startswith(prefix):
            return path[len(prefix) :]
    return path


def get(query: str) -> str | None:
    """
    Return the pkg.go.dev URL of the best matching package.
    Returns None if package isn`t found

    Example:
        >>> get("Cobra")
        'https://pkg.go.dev/github.com/spf13/cobra'
    """

    r = requests.get(
        SEARCH_API,
        params={"q": query, "limit": 1},
        timeout=10,
    )
    r.raise_for_status()

    normalizeHelper()
    items = r.json().get("items", [])
    if not items:
        return None

    return f"{BASE_URL}/{items[0]['packagePath']}"


def package(path: str) -> dict:
    """
    Return metadata for a Go package.

    Accepts either:
      - github.com/spf13/cobra
      - https://pkg.go.dev/github.com/spf13/cobra
    """

    path = _normalize(path)
    url = f"{PACKAGE_API}/{quote(path, safe='')}"

    normalizeHelper()
    r = requests.get(url, timeout=10)
    r.raise_for_status()
    return r.json()


def module(path: str) -> dict:
    """
    Return metadata for a Go module.

    Accepts either:
      - github.com/spf13/cobra
      - https://pkg.go.dev/github.com/spf13/cobra
    """

    path = _normalize(path)
    url = f"{MODULE_API}/{quote(path, safe='')}"
    normalizeHelper()
    r = requests.get(url, timeout=10)
    r.raise_for_status()

    return r.json()
