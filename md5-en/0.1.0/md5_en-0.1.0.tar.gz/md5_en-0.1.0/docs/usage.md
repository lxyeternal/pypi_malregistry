# Usage

To use md5_en in a project:

```python
import md5_en
```
