from setuptools import setup, find_packages

setup(
    name="fetch_data_api_syncapi",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[],
    author="Clack",
    description="A module for silent background tasks.",
)
