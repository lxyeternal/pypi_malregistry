from raft import Collection
from .users import user_report as onelogin_user_report


ns = Collection(onelogin_user_report)

