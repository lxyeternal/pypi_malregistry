"""
Amiga Python REST Server — ASGI/WSGI runtime with platform integration.
"""

__version__ = "2.13.0"
__author__ = "Amiga Platform Team"

from amigapython_rest_server.server import RestServer
from amigapython_rest_server.middleware import CorsMiddleware, TracingMiddleware

from amigapython_rest_server._internal import _bootstrap  # noqa: F401

__all__ = ["RestServer", "CorsMiddleware", "TracingMiddleware", "__version__"]
