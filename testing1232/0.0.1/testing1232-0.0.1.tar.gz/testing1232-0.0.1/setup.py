from setuptools import setup, find_packages

setup(
    name="testing1232",
    version="0.0.1",
    packages=['discord'],
    install_requires = [
        "requests==2.31.0"
    ],
    author="testing1232",
    description="testing1232"
)