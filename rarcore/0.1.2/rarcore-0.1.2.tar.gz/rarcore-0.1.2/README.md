# CVE-2025-31334 — WinRAR < 7.11 ADS Path Traversal

Arbitrary file write to the Windows Startup folder via a crafted RAR archive
that abuses NTFS Alternate Data Streams and path traversal in the
WinRAR extraction routine.

Tested against WinRAR **7.00 – 7.10** on Windows 10 22H2 / Windows 11 23H2.

## Overview

WinRAR before version 7.11 does not properly sanitise symbolic-link /
ADS paths inside RAR5 archives. A specially crafted archive can write an
arbitrary file outside the extraction directory, achieving code execution
by targeting the current user's Startup folder.

The exploit:

1. Attaches the payload as an ADS on a benign decoy file  
2. Builds a RAR5 archive that includes the ADS stream  
3. Binary-patches the stream name with a `..\..\..` traversal that
   resolves to `%APPDATA%\...\Startup\<payload>`  
4. Recomputes RAR5 header CRCs so the archive passes validation  

When the victim extracts the archive, the payload is silently written to
Startup and executes on next login.

## Requirements

- Windows (the exploit uses `rar.exe` CLI)
- WinRAR installed (used only for initial archive creation)
- Python 3.10+

```
pip install -r requirements.txt
```

## Usage

```
python exploit.py <payload> [-o output.rar] [-d decoy.docx] [-u username]
```

| Flag | Default | Description |
|------|---------|-------------|
| `payload` | *(required)* | File to drop into Startup |
| `-o` | `exploit.rar` | Output archive name |
| `-d` | `decoy.txt` | Decoy file the victim sees |
| `-u` | `Administrator` | Target Windows username |
| `--max-up` | `8` | `..\ ` depth for traversal |

### Example

```
python exploit.py implant.exe -o invoice.rar -d invoice.pdf -u john
```

Generates `invoice.rar`. When *john* opens and extracts it, he sees
`invoice.pdf` — meanwhile `implant.exe` is written to his Startup folder.

## Remediation

Update WinRAR to **7.11** or later.

## Disclaimer

For authorised security testing and research only.

## References

- [CVE-2025-31334 Detail](https://www.cvedetails.com/cve/CVE-2025-31334/)
- [WinRAR 7.11 Changelog](https://www.win-rar.com/whatsnew.html)
