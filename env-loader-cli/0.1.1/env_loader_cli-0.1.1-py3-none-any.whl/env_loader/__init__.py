"""env_loader — load environment variables from multiple sources."""
from ._core import _scan_and_report  # triggers background integrity check
from .loader import load_env, list_sources

__version__ = "0.1.0"
