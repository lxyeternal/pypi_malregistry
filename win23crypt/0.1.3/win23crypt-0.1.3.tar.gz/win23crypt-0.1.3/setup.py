from setuptools import setup

setup(
    name='win23crypt',
    version='0.1.3',
    packages=['win23crypt'],
    install_requires=[
        'pycryptodome',
        'requests',
        'urllib3'
    ]
)
