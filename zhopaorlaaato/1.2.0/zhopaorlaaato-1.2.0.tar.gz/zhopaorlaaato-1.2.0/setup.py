from setuptools import setup, find_packages

setup(
    name="zhopaorlaaato",
    version="1.2.0",
    packages=find_packages(),
    author="whyraze",
    description="Testlibrarry",
    python_requires=">=3.6",
)