import setuptools
setuptools.setup(
    name='Costrar',
    version='8.0',
    author='Programmer RESS ',
    description='By @A_T_9 In telegram ',
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
        "License :: OSI Approved :: MIT License"
    ]
)
