"""Glitchtip API integration: manages Glitchtip organizations, teams, projects, and users."""

from __future__ import annotations

import asyncio
import logging
import sys
from collections import defaultdict
from typing import TYPE_CHECKING

from qontract_api_client.client import glitchtip as reconcile_glitchtip
from qontract_api_client.schemas import (
    GIInstance,
    GIOrganization,
    GIProject,
    GlitchtipReconcileRequest,
    GlitchtipTaskResult,
    GlitchtipTeam,
    GlitchtipUser,
    Secret,
    TaskStatus,
)
from qontract_utils.glitchtip_api import slugify

from reconcile.gql_definitions.glitchtip.glitchtip_instance import (
    query as glitchtip_instance_query,
)
from reconcile.gql_definitions.glitchtip.glitchtip_project import (
    GlitchtipProjectV1,
    GlitchtipProjectV1_GlitchtipOrganizationV1,
    GlitchtipTeamV1,
    RoleV1,
)
from reconcile.gql_definitions.glitchtip.glitchtip_project import (
    query as glitchtip_project_query,
)
from reconcile.utils import gql
from reconcile.utils.runtime.integration import (
    PydanticRunParams,
    QontractReconcileApiIntegration,
)

if TYPE_CHECKING:
    from collections.abc import Callable

QONTRACT_INTEGRATION = "glitchtip-api"
DEFAULT_MEMBER_ROLE = "member"

# GlitchTip org roles ordered from lowest to highest privilege.
# Used to deterministically resolve a user's org role when they appear in
# multiple teams with different role assignments.
_ROLE_PRECEDENCE: list[str] = ["member", "contributor", "manager", "admin", "owner"]


def _highest_role(role_a: str, role_b: str) -> str:
    """Return the higher-privilege of two GlitchTip org roles.

    Unknown roles are treated as lowest privilege so they never silently
    override a known role.
    """
    idx_a = _ROLE_PRECEDENCE.index(role_a) if role_a in _ROLE_PRECEDENCE else -1
    idx_b = _ROLE_PRECEDENCE.index(role_b) if role_b in _ROLE_PRECEDENCE else -1
    return role_a if idx_a >= idx_b else role_b


def _get_user_role(
    organization: GlitchtipProjectV1_GlitchtipOrganizationV1, role: RoleV1
) -> str:
    for glitchtip_role in role.glitchtip_roles or []:
        if glitchtip_role.organization.name == organization.name:
            return glitchtip_role.role
    return DEFAULT_MEMBER_ROLE


class GlitchtipApiIntegrationParams(PydanticRunParams):
    instance: str | None = None


class GlitchtipApiIntegration(
    QontractReconcileApiIntegration[GlitchtipApiIntegrationParams]
):
    """Manage Glitchtip organizations, teams, projects, and users."""

    @property
    def name(self) -> str:
        return QONTRACT_INTEGRATION

    def get_glitchtip_projects(self, query_func: Callable) -> list[GlitchtipProjectV1]:
        return glitchtip_project_query(query_func=query_func).glitchtip_projects or []

    @staticmethod
    def _build_team_users(
        glitchtip_team: GlitchtipTeamV1,
        organization: GlitchtipProjectV1_GlitchtipOrganizationV1,
        mail_domain: str,
    ) -> dict[str, GlitchtipUser]:
        """Build email->GlitchtipUser map for a team from role assignments."""
        users_by_email: dict[str, GlitchtipUser] = {}

        for role in glitchtip_team.roles:
            role_str = _get_user_role(organization, role)
            for user in role.users:
                email = f"{user.org_username}@{mail_domain}"
                users_by_email[email] = GlitchtipUser(email=email, role=role_str)

        return users_by_email

    async def _build_desired_state(
        self,
        glitchtip_projects: list[GlitchtipProjectV1],
        mail_domain: str,
    ) -> list[GIOrganization]:
        org_teams: dict[str, dict[str, GlitchtipTeam]] = defaultdict(dict)
        org_projects: dict[str, list[GIProject]] = defaultdict(list)
        org_users: dict[str, dict[str, GlitchtipUser]] = defaultdict(dict)

        for proj in glitchtip_projects:
            org_name = proj.organization.name
            project_team_slugs: list[str] = []

            for glitchtip_team in proj.teams:
                team_slug = slugify(glitchtip_team.name)
                project_team_slugs.append(team_slug)

                if team_slug not in org_teams[org_name]:
                    users_by_email = self._build_team_users(
                        glitchtip_team=glitchtip_team,
                        organization=proj.organization,
                        mail_domain=mail_domain,
                    )
                    org_teams[org_name][team_slug] = GlitchtipTeam(
                        name=glitchtip_team.name,
                        users=list(users_by_email.values()),
                    )
                    for email, user in users_by_email.items():
                        if email not in org_users[org_name]:
                            org_users[org_name][email] = user
                        else:
                            # User in multiple teams — keep the highest-privilege role
                            # to avoid non-deterministic first-team-wins assignment.
                            existing = org_users[org_name][email]
                            new_role = user.role
                            cur_role = existing.role
                            best_role = _highest_role(new_role, cur_role)
                            if best_role != cur_role:
                                org_users[org_name][email] = GlitchtipUser(
                                    email=email, role=best_role
                                )

            if not project_team_slugs:
                raise ValueError(
                    f"Project '{proj.name}' in org '{proj.organization.name}' "
                    f"has no teams assigned — cannot reconcile"
                )

            project_slug = proj.project_id or slugify(proj.name)
            org_projects[org_name].append(
                GIProject(
                    name=proj.name,
                    slug=project_slug,
                    platform=proj.platform,
                    event_throttle_rate=proj.event_throttle_rate or 0,
                    teams=project_team_slugs,
                )
            )

        all_org_names = set(org_teams) | set(org_projects)
        return [
            GIOrganization(
                name=org_name,
                teams=list(org_teams[org_name].values()),
                projects=org_projects[org_name],
                users=list(org_users[org_name].values()),
            )
            for org_name in all_org_names
        ]

    async def async_run(self, dry_run: bool) -> None:
        gqlapi = gql.get_api()

        glitchtip_instances = glitchtip_instance_query(
            query_func=gqlapi.query
        ).instances
        glitchtip_projects = self.get_glitchtip_projects(query_func=gqlapi.query)

        projects_by_instance: dict[str, list[GlitchtipProjectV1]] = defaultdict(list)
        for proj in glitchtip_projects:
            projects_by_instance[proj.organization.instance.name].append(proj)

        filtered_instances = [
            inst
            for inst in glitchtip_instances
            if not self.params.instance or inst.name == self.params.instance
        ]

        all_organizations = await asyncio.gather(*[
            self._build_desired_state(
                glitchtip_projects=projects_by_instance[inst.name],
                mail_domain=inst.mail_domain or "redhat.com",
            )
            for inst in filtered_instances
        ])

        instances: list[GIInstance] = [
            GIInstance(
                name=inst.name,
                console_url=inst.console_url,
                token=Secret(
                    secret_manager_url=self.secret_manager_url,
                    path=inst.automation_token.path,
                    field=inst.automation_token.field,
                    version=inst.automation_token.version,
                ),
                automation_user_email=Secret(
                    secret_manager_url=self.secret_manager_url,
                    path=inst.automation_user_email.path,
                    field=inst.automation_user_email.field,
                    version=inst.automation_user_email.version,
                ),
                read_timeout=inst.read_timeout or 30,
                max_retries=inst.max_retries or 3,
                organizations=organizations,
            )
            for inst, organizations in zip(
                filtered_instances, all_organizations, strict=True
            )
        ]

        if not instances:
            logging.warning("No Glitchtip instances to reconcile")
            return

        with self.log_api_exceptions():
            task = await reconcile_glitchtip(
                GlitchtipReconcileRequest(instances=instances, dry_run=dry_run),
            )
        logging.info(f"request_id: {task.id}")

        if not dry_run:
            # In non-dry-run, we expect the task to complete asynchronously in the background
            # and change events will be automatically published via the events framework.
            return

        task_result = await self.poll_task_status(
            status_url=task.status_url, result_type=GlitchtipTaskResult
        )
        if task_result.status == TaskStatus.PENDING:
            logging.error("Glitchtip task did not complete within the timeout period")
            sys.exit(1)

        for action in task_result.actions or []:
            logging.info(action.model_dump())

        if task_result.errors:
            logging.error(f"Errors encountered: {len(task_result.errors)}")
            for error in task_result.errors:
                logging.error(f"  - {error}")
            sys.exit(1)
