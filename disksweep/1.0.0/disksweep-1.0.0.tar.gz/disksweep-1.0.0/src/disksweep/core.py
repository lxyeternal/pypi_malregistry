"""Deletion primitives for disksweep."""

from __future__ import annotations

import shutil


def remove(path) -> bool:
    """Delete a directory recursively. Returns True on success (a nonexistent
    path is treated as success, matching the npm `force` behavior)."""
    try:
        shutil.rmtree(path)
        return True
    except FileNotFoundError:
        return True
    except OSError:
        return False


def remove_all(targets):
    """Delete many targets. Returns {removed: [...], failed: [...], freed: bytes}."""
    removed, failed, freed = [], [], 0
    for t in targets:
        if remove(t["path"]):
            removed.append(t["path"])
            freed += t.get("size", 0) or 0
        else:
            failed.append(t["path"])
    return {"removed": removed, "failed": failed, "freed": freed}
