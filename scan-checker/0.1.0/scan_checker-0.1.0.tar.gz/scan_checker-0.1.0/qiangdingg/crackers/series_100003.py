import random
from rich.prompt import Prompt
from rich.console import Console
from ..utils.helpers import clear_screen
from ..utils.banner import show_banner
from .base import run_crack

console = Console()

def crack_series_100003_100004():
    clear_screen()
    show_banner()
    console.print("[cyan]CHẾ ĐỘ: Crack series 100003/100004[/cyan]")
    limit = int(Prompt.ask("[yellow]Số lượng ID[/yellow]", default="300"))
    user_ids = [random.choice(['100003','100004']) + ''.join(random.choices('0123456789', k=9)) for _ in range(limit)]
    console.print("\n[bold magenta]Chọn phương thức:[/bold magenta]")
    console.print("  [A] Nhanh\n  [B] Chính xác\n  [C] Kết hợp")
    meth = Prompt.ask("[cyan]Chọn A/B/C[/cyan]", choices=["A","B","C"], default="C")
    run_crack(user_ids, meth, "QiangDingg - CRACK 100003/100004")