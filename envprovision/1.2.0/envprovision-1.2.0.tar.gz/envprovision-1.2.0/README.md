# envprovision

Lightweight environment diagnostics and compatibility validation for Python applications.

## Features

- **Environment Diagnostics** — Collect system facts (Python version, platform, architecture, available modules, disk space) without touching sensitive data
- **Compatibility Verification** — Check runtime against declared requirements (Python version, platform, required modules, disk space)
- **Private Repository Support** — Fetch update manifests from authenticated private repositories over TLS
- **Verified Updates** — Download and apply approved updates with SHA-256 integrity verification
- **Audit Trail** — Built-in ledger for tracking update operations (memory-backed, no disk persistence)

## Installation

```bash
pip install envprovision