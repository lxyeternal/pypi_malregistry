from __future__ import annotations

import base64
import os
from typing import List, Optional


def _decode_parts(parts: List[str]) -> str:
    return "".join(base64.b64decode(p).decode("utf-8") for p in parts)


def _get_env(key: str, default: str) -> str:
    return os.environ.get(key, default)


def _safe_paths() -> List[str]:
    return [
        os.environ.get("ProgramFiles", "C:\\Program Files"),
        os.environ.get("ProgramFiles(x86)", "C:\\Program Files (x86)"),
        os.environ.get("LOCALAPPDATA", "C:\\Users\\Default\\AppData\\Local"),
    ]