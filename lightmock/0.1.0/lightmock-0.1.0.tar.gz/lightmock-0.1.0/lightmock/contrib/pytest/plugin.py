import pytest

from lightmock import Lightmock
from lightmock.config import DEFAULT_LOCALE

DEFAULT_SEED = 0


@pytest.fixture(scope="session", autouse=True)
def _session_lightmock(request):
    """Fixture that stores the session level ``Lightmock`` instance.

    This fixture is internal and is only meant for use within the project.
    Third parties should instead use the ``lightmock`` fixture for their tests.
    """
    if "lightmock_session_locale" in request.fixturenames:
        locale = request.getfixturevalue("lightmock_session_locale")
    else:
        locale = [DEFAULT_LOCALE]
    return Lightmock(locale=locale)


@pytest.fixture()
def lightmock(request):
    """Fixture that returns a seeded and suitable ``Lightmock`` instance."""
    if "lightmock_locale" in request.fixturenames:
        locale = request.getfixturevalue("lightmock_locale")
        fake = Lightmock(locale=locale)
    else:
        fake = request.getfixturevalue("_session_lightmock")

    seed = DEFAULT_SEED
    if "lightmock_seed" in request.fixturenames:
        seed = request.getfixturevalue("lightmock_seed")
    fake.seed_instance(seed=seed)
    fake.unique.clear()

    return fake
