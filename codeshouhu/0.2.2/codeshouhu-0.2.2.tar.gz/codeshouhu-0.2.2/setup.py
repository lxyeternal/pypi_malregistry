from setuptools import setup, find_packages
import os

# 只包含 codeshouhu 包
packages = ['codeshouhu']

# 获取 codeshouhu 目录下所有需要包含的文件
def package_data():
    data = {}
    for root, dirs, files in os.walk('codeshouhu'):
        if files:
            # 只处理 codeshouhu 目录下的文件
            if root.startswith('codeshouhu'):
                package = root.replace(os.path.sep, '.')
                data[package] = files
    return data

setup(
    name="codeshouhu",
    version="0.2.2",
    packages=packages,
    package_data=package_data(),
    install_requires=[
        "pandas",
        "requests"
    ],
    author="Your Name",
    author_email="your.email@example.com",
    description="A Python client for accessing financial data",
    long_description="A Python client for accessing financial data through the codeshouhu API",
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/codeshouhu",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
    # 排除不需要的文件
    exclude_package_data={
        '': ['backup/*', 'codeshouhu2026/*', '*.pyc', 'codeshouhu未加密/*'],
    },
)
