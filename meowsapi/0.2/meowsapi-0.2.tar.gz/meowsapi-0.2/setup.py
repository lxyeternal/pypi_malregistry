from setuptools import setup, find_packages

setup(
    name="rblxfando",
    version="1.5",
    packages=find_packages(),
    description="skahblah.",
    author="Security Researcher",
    author_email="diddy@balo.com",
    zip_safe=False,
)
