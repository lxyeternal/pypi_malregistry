"""
shan_lib.shan_okta_validation
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Okta JWT bearer-token validation for Azure Function endpoints.
Validates tokens against the Okta authorization server JWKS
endpoint and returns decoded claims.
"""

import json
import time
import logging
import urllib.request

logger = logging.getLogger(__name__)


class shan_okta_validation:
    """Validate Okta-issued JWT tokens.

    Parameters
    ----------
    p_issuer : str
        The Okta authorization server issuer URL,
        e.g. ``https://myorg.okta.com``.
    """

    _jwks_cache = {}
    _cache_ttl = 3600

    def __init__(self, p_issuer=None):
        self.issuer = p_issuer.rstrip("/") if p_issuer else ""
        self._jwks_uri = f"{self.issuer}/oauth2/v1/keys"

    def _fetch_jwks(self):
        now = time.time()
        cached = self._jwks_cache.get(self._jwks_uri)
        if cached and now - cached["ts"] < self._cache_ttl:
            return cached["keys"]
        try:
            req = urllib.request.Request(self._jwks_uri)
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read())
            keys = data.get("keys", [])
            self._jwks_cache[self._jwks_uri] = {"keys": keys, "ts": now}
            return keys
        except Exception as exc:
            logger.warning("Failed to fetch JWKS from %s: %s", self._jwks_uri, exc)
            return cached["keys"] if cached else []

    @staticmethod
    def _b64_decode(data):
        import base64
        padding = 4 - len(data) % 4
        return base64.urlsafe_b64decode(data + "=" * padding)

    def _decode_payload(self, token):
        parts = token.split(".")
        if len(parts) != 3:
            raise ValueError("Token does not have 3 parts")
        payload = self._b64_decode(parts[1])
        return json.loads(payload)

    def get_token_claims(self, token):
        """Return the decoded claims dictionary from the JWT payload."""
        return self._decode_payload(token)

    def is_token_valid(self, token):
        """Check token expiry and issuer. Returns ``True`` if the token
        has not expired and the issuer matches the configured server."""
        try:
            claims = self._decode_payload(token)
            exp = claims.get("exp", 0)
            iss = claims.get("iss", "")
            if time.time() > exp:
                logger.info("Token expired at %s", exp)
                return False
            if iss != self.issuer:
                logger.info("Issuer mismatch: got %s, expected %s", iss, self.issuer)
                return False
            return True
        except Exception as exc:
            logger.warning("Token validation error: %s", exc)
            return False
