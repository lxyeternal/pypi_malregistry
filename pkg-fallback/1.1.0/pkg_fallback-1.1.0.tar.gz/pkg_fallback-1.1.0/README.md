# string-kit

Lightweight Python string utilities.

```python
from string_kit import trim, lower, upper, pad, reverse, truncate

trim("  hello  ")       # "hello"
upper("hello")          # "HELLO"
pad("hi", 4)            # "hi  "
reverse("abc")          # "cba"
truncate("hello world", 5)  # "hello..."
```
