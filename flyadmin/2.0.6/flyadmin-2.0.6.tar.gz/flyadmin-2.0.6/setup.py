from setuptools import setup, find_packages
setup(name = "flyadmin", version = "2.0.6", packages = find_packages())