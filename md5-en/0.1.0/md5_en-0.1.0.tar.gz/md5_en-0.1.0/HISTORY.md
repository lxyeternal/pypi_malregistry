# History

## 0.1.0 (2025-10-15)

* First release on PyPI.
