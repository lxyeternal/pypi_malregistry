
#Tahg4ever

def suma(n1: int, n1:int) -> int:
    return n1 + n2

def resta(n1: int, n1:int) -> int:
    return n1 - n2
