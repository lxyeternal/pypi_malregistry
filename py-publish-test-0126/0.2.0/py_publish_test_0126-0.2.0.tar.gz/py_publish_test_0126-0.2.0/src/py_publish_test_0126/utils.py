from .decorators import register_telemetry

@register_telemetry
def print_hello_world():
    print("hello world")