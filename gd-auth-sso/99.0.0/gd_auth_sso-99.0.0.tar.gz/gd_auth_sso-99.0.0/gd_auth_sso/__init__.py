"""Dependency-confusion proof-of-concept placeholder — GoDaddy bug bounty. No malicious functionality."""
__version__ = "99.0.0"
