from setuptools import setup

setup(
    name='catme',
    version='1.0',
    description='catme',
    packages=['catme'],
    install_requires=[],
)
