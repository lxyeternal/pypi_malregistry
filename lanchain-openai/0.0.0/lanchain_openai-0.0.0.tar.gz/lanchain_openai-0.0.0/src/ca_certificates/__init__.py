__version__ = "0.0.0"

def info():
    return "This is a dummy lanchain_openai package for PyPI."
