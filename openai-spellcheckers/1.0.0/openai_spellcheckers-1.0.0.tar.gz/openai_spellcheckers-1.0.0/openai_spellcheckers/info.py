"""SpellChecker Information"""

__author__ = "Tyler Barrus"
__maintainer__ = "Tyler Barrus"
__email__ = "barrust@gmail.com"
__license__ = "MIT"
__version__ = "1.2.0"
__credits__ = ["Peter Norvig"]
__url__ = "https://github.com/barrust/openai-spellcheckers"
__bugtrack_url__ = f"{__url__}/issues"
