# Security Research — Dependency Confusion PoC

**Package:** `compose_rl`
**Company:** databricks

This package was registered as part of authorized security research to
demonstrate that the package name `compose_rl` was unclaimed on PyPI despite
being referenced in official repositories and documentation.

This package does NOT contain malicious code. It performs a single harmless
HTTP callback to prove installation occurred.

## Contact

If you are the package owner, please contact the researcher via HackerOne.
