from chacha_lite_encrypt import ChaChaEncryption, generate_key

password = "my_secure_password"
key, salt = generate_key(password)

plaintext = "Sensitive data encrypted with password"
ciphertext = ChaChaEncryption.encrypt(plaintext, key)

print(f"Plaintext: {plaintext}")
print(f"Salt (hex): {salt.hex()}")
print(f"Ciphertext (hex): {ciphertext.hex()}")

from chacha_lite_encrypt.utils import derive_key_from_password
key_recovered = derive_key_from_password(password, salt)
decrypted = ChaChaEncryption.decrypt(ciphertext, key_recovered)

print(f"Decrypted: {decrypted.decode('utf-8')}")
