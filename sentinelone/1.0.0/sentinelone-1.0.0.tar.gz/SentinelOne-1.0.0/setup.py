from setuptools import setup, find_packages

package_version = '1.0.0'

setup(
    name='SentinelOne',
    version='1.0.0',
    license='SentinelOne'
)

