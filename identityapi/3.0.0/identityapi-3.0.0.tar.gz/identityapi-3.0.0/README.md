# identityapi
> Identity API client — OIDC/OAuth2 identity resolution, token management, and SSO integration.

## Installation
```bash
pip install identityapi
```

## License
Apache 2.0
