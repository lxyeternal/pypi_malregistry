print("Hello from lala python package!")

def hello():
    print("This is a function from the lala package!")