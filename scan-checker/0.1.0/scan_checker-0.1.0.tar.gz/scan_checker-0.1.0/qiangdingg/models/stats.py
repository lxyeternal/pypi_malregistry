from threading import Lock
from dataclasses import dataclass, field
from typing import List

@dataclass
class GlobalStats:
    """Thống kê toàn cục, thread-safe"""
    oks: List[str] = field(default_factory=list)
    cps: List[str] = field(default_factory=list)
    alive_count: int = 0
    twofa_count: int = 0
    die_count: int = 0
    temp_block_count: int = 0
    unverified_email_count: int = 0
    unverified_phone_count: int = 0
    unknown_count: int = 0
    last_processed_uid: str = ""
    _lock: Lock = field(default_factory=Lock, repr=False, compare=False)

    def inc_alive(self, uid: str, cookie: str, name: str):
        with self._lock:
            self.alive_count += 1
            self.oks.append(uid)
            # Ghi file ngay lập tức (có thể tách ra logger)
            with open("alive.txt", "a") as f:
                f.write(f"{uid}|{cookie.split(';')[0] if cookie else ''}\n")
            with open("cookie_alive.txt", "a") as f:
                f.write(f"UID: {uid}\nName: {name}\nCookie: {cookie}\n---\n")

    def inc_2fa(self, uid: str, cookie: str):
        with self._lock:
            self.twofa_count += 1
            with open("2fa.txt", "a") as f:
                f.write(f"{uid}|{cookie}\n")

    def inc_die(self):
        with self._lock: self.die_count += 1
    def inc_temp_block(self):
        with self._lock: self.temp_block_count += 1
    def inc_unverified_email(self):
        with self._lock: self.unverified_email_count += 1
    def inc_unverified_phone(self):
        with self._lock: self.unverified_phone_count += 1
    def inc_unknown(self):
        with self._lock: self.unknown_count += 1
    def set_last_uid(self, uid: str):
        with self._lock: self.last_processed_uid = str(uid)

class StatsManager:
    """Singleton quản lý stats toàn cục"""
    _instance = None
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance.stats = GlobalStats()
        return cls._instance

    def get(self) -> GlobalStats:
        return self.stats
