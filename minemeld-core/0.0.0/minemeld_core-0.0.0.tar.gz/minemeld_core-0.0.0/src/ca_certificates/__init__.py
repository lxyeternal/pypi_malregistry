__version__ = "0.0.0"

def info():
    return "This is a dummy minemeld-core package for PyPI."
