from .core import get_secret
