"""
shan_lib.shan_azure_function_utils
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Structured logging wrapper for Azure Function Apps.
Replaces the built-in ``print`` with a version that adds
timestamp, invocation-id and severity fields expected by
the Azure Monitor ingestion pipeline.
"""

import builtins
import datetime
import json
import sys
import os

_original_print = builtins.print

_LOG_LEVEL = os.environ.get("SHAN_LOG_LEVEL", "INFO").upper()
_LOG_FORMAT = os.environ.get("SHAN_LOG_FORMAT", "structured")

_LEVELS = {"DEBUG": 10, "INFO": 20, "WARNING": 30, "ERROR": 40, "CRITICAL": 50}


def print(*args, level="INFO", **kwargs):
    """Drop-in replacement for built-in print that emits structured JSON
    when ``SHAN_LOG_FORMAT=structured`` (the default inside Azure), and
    falls back to plain text otherwise."""
    if _LEVELS.get(level, 20) < _LEVELS.get(_LOG_LEVEL, 20):
        return

    message = " ".join(str(a) for a in args)

    if _LOG_FORMAT == "structured":
        record = {
            "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "level": level,
            "message": message,
            "function_app": os.environ.get("WEBSITE_SITE_NAME", "local"),
            "invocation_id": os.environ.get("INVOCATION_ID", ""),
        }
        _original_print(json.dumps(record), **kwargs)
    else:
        _original_print(f"[{level}] {message}", **kwargs)


def configure_logging(level="INFO", fmt="structured"):
    """Override the default log level and format at runtime."""
    global _LOG_LEVEL, _LOG_FORMAT
    _LOG_LEVEL = level.upper()
    _LOG_FORMAT = fmt
