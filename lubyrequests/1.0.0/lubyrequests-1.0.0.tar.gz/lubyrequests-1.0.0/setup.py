from setuptools import setup, find_packages

setup(
    name='lubyrequests',
    version='1.0.0',
    description='lubyrequests',
    author='jesus55997',
    author_email='jesus55997@79cr17i.gpa.lu',
    packages=find_packages(),
)
