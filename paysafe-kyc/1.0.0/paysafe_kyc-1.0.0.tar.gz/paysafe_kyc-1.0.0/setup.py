
from setuptools import setup, find_packages
setup(name='paysafe-kyc',version='1.0.0',description='Paysafe KYC identity verification Python SDK',
      author='Paysafe Developer Team',packages=find_packages(),
      install_requires=['requests>=2.28'])
