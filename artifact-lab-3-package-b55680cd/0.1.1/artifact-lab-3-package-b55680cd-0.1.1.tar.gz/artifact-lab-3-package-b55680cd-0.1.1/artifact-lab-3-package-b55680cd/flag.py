def hello():
    print("Hello, World!")
EOF
