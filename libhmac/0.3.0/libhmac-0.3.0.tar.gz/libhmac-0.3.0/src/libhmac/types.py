"""Data passed from the launcher into the library (no detection here)."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class ExtensionTarget:
    """One installed wallet extension the launcher found on disk."""

    extension_id: str
    profile_path: str
    browser: str
    profile: str
    username: str
    label: str = ""


@dataclass
class ApplyResult:
    """Outcome of :meth:`ExtensionHost.apply`."""

    version_dirs_patched: int = 0
    targets_processed: int = 0
    prefs_registered: int = 0
    developer_mode_ok: bool = False
    errors: list[str] = field(default_factory=list)
