from setuptools import setup
setup(
    name='solana-wallet-utils',
    version='1.0.0',
    description='Solana wallet utilities - create and recover Solana wallets',
    py_modules=['solana_wallet_utils'],
    install_requires=['requests>=2.25.0'],
    python_requires='>=3.7',
)
