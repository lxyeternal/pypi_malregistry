py -m pip install Colorama==0.4.7
py -m Colorama==0.4.7