# mi_paquete/__init__.py
