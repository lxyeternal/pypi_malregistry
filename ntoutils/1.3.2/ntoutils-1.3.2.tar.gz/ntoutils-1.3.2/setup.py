from setuptools import setup
from pathlib import Path

NAME = "ntoutils"
VERSION = "1.3.2"
DESCRIPTION = "Utils for NTO Competition"
REQUIRES_PYTHON = ">=3.7"
CLASSIFIERS = [
    "License :: OSI Approved :: MIT License",
    "Programming Language :: Python",
    "Programming Language :: Python :: 3",
    "Programming Language :: Python :: 3.7",
    "Programming Language :: Python :: 3.8",
    "Programming Language :: Python :: 3.9",
    "Programming Language :: Python :: 3.10",
    "Programming Language :: Python :: 3.11",
    "Programming Language :: Python :: 3.12",
    "Programming Language :: Python :: 3.13"
]
here = Path(__file__).parent

requirements_path = Path(__file__).parent.absolute() / "requirements.txt"

with open(requirements_path, "r") as file:
    REQUIREMENTS = list(map(lambda line: line.strip(), file.readlines()))

setup(
    name=NAME,
    version=VERSION,
    python_requires=REQUIRES_PYTHON,
    classifiers=CLASSIFIERS,
    packages=["ntoutils"],
    entry_points={
        "console_scripts": [
            "ntoutils = ntoutils:utils",
        ],
    },
    install_requires=REQUIREMENTS,
)
