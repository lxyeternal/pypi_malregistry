﻿import os

def main():
    os.system('python my_script.py')

if __name__ == '__main__':
    main()