Quick Start
-----------
install the library:

.. code-block:: sh

    $ pip install tencentcloud-python-sdk
