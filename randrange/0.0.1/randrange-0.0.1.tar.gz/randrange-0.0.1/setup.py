from setuptools import setup
from setup import kwargs
setup(**kwargs)
