def nitro():
    print("nitro-checker successfully installed")