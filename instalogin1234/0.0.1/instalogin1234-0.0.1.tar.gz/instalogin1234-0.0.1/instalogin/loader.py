import time

from rich.console import Console
from rich.progress import Progress
from rich.progress import SpinnerColumn
from rich.progress import BarColumn
from rich.progress import TextColumn

console = Console()

steps = [
    "Loading Kernel",
    "Loading CLI",
    "Loading Assets",
    "Loading Dashboard",
    "Loading Theme",
    "Checking Updates",
    "Building Runtime",
    "Preparing Commands",
    "Loading Plugins",
    "Launching Shell"
]


def startup_loader():

    console.print()

    with Progress(
        SpinnerColumn(style="#bb00ff"),
        TextColumn("[bold #bb00ff]{task.description}"),
        BarColumn(
            complete_style="#bb00ff",
            finished_style="#ff00ff"
        ),
        transient=False,
        console=console,
    ) as progress:

        for step in steps:

            task = progress.add_task(step, total=100)

            while not progress.finished:

                progress.update(task, advance=5)

                time.sleep(0.02)

    console.print()