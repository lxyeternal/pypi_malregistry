# dde-common

base types and interfaces

## Installation

```bash
pip install dde-common
```

## Usage

```python
import dde_common
```

## Telemetry

This package collects anonymous usage metrics to help improve the platform.
Telemetry can be disabled by setting the `DISABLE_TELEMETRY` environment variable.

## License

MIT
