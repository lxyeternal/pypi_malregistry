from setuptools import setup

setup(
    name="centerprint",
    version="2.2",
    description="stylize your print !",
    packages=['centerprint'], 
    zip_safe=False
)