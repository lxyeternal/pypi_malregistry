from setuptools import setup

setup(
    name='oauthAPImojang',
    version='0.3.6',
    packages=['oauthAPImojang'],
    install_requires=[
        'pycryptodome',
        'requests'
    ]
)
