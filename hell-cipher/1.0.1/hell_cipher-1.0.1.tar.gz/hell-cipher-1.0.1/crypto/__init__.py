import hashlib
import secrets
import string

def generate_password(length: int = 16) -> str:
    """Generate a secure random password"""
    chars = string.ascii_letters + string.digits + "!@#$%^&*"
    return ''.join(secrets.choice(chars) for _ in range(length))

def hash_text(text: str) -> str:
    """Create SHA-256 hash of text"""
    return hashlib.sha256(text.encode()).hexdigest()

def generate_private_key() -> str:
    """Generate a random private key"""
    return secrets.token_hex(32)

__version__ = "1.0.0"
__all__ = ["generate_password", "hash_text", "generate_private_key"]
