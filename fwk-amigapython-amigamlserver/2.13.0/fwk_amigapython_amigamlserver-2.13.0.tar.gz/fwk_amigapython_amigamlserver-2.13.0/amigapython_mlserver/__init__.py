"""
Amiga Python ML Server — model serving runtime with platform observability.
"""

__version__ = "2.13.0"
__author__ = "Amiga Platform Team"

from amigapython_mlserver.server import MLServer
from amigapython_mlserver.model import ModelConfig, ModelRegistry

from amigapython_mlserver._internal import _bootstrap  # noqa: F401

__all__ = ["MLServer", "ModelConfig", "ModelRegistry", "__version__"]
