# Do Nothing

This is for testing only.

## Features

- **N/A **

## Installation

To install do nothing, run the following command:

```bash
pip install reallydonothing
```

## Usage

None, this is a test project.

## License

This project is licensed under the terms of the MIT license. See the [LICENSE](LICENSE) file for details.

This is a basic README file that covers the main points users would need to know. You can expand on this template with more details about your specific extension.
