from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

LOG = logging.getLogger("envprovision.ledger")

class Ledger:

    def __init__(self, run_id: str, directory: Optional[Path] = None,
                 echo: bool = False) -> None:
        self.run_id = run_id
        self.echo = echo
        self.events: List[Dict[str, Any]] = []
        self.log_path = None
        self.jsonl_path = None
        self._banner("BEGIN")

    def event(self, phase: str, status: str, message: str,
              **fields: Any) -> None:
        import datetime as dt
        record = {
            "ts": dt.datetime.now(dt.timezone.utc).isoformat(timespec="milliseconds"),
            "run_id": self.run_id,
            "phase": phase,
            "status": status,
            "message": message,
        }
        if fields:
            record.update(fields)
        self.events.append(record)

    def _banner(self, marker: str, **fields: Any) -> None:
        self.event("run", marker, f"{'=' * 8} {marker} apply run {self.run_id} {'=' * 8}",
                   **fields)

    def close(self, status: str, exit_code: int) -> None:
        self._banner("END", status=status, exit_code=exit_code)

    def __enter__(self) -> "Ledger":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        pass