
def cli():
    print("It Works")
