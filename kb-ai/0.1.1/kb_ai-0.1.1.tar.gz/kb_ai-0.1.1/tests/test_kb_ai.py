from pathlib import Path

import pytest

import kb_ai
from kb_ai import Document, KnowledgeBase
from kb_ai.cli import main
from kb_ai.core import tokenize


@pytest.fixture()
def kb() -> KnowledgeBase:
    base = KnowledgeBase()
    base.add_text("faq-1", "Refunds are issued within 5 business days.", {"topic": "billing"})
    base.add_text("faq-2", "Password resets are sent by email.", {"topic": "auth"})
    base.add_text("faq-3", "Shipping takes 3 business days.", {"topic": "shipping"})
    return base


def test_version_is_exposed() -> None:
    assert kb_ai.__version__.count(".") == 2


def test_tokenize() -> None:
    assert tokenize("Refunds, in 5 days!") == ["refunds", "in", "5", "days"]


def test_add_and_get(kb: KnowledgeBase) -> None:
    assert len(kb) == 3
    assert "faq-1" in kb
    doc = kb.get("faq-1")
    assert doc is not None and doc.metadata["topic"] == "billing"


def test_add_replaces_same_id() -> None:
    base = KnowledgeBase([Document(id="a", text="first")])
    base.add_text("a", "second")
    assert len(base) == 1
    doc = base.get("a")
    assert doc is not None and doc.text == "second"


def test_search_ranks_relevant_document_first(kb: KnowledgeBase) -> None:
    results = kb.search("refunds business days")
    assert results
    assert results[0].document.id == "faq-1"
    assert results[0].score > 0


def test_search_respects_limit(kb: KnowledgeBase) -> None:
    assert len(kb.search("business days", limit=1)) == 1


def test_search_empty_query_returns_nothing(kb: KnowledgeBase) -> None:
    assert kb.search("") == []
    assert kb.search("!!!") == []


def test_remove(kb: KnowledgeBase) -> None:
    assert kb.remove("faq-2") is True
    assert kb.remove("faq-2") is False
    assert len(kb) == 2


def test_save_and_load_round_trip(kb: KnowledgeBase, tmp_path: Path) -> None:
    path = kb.save(tmp_path / "nested" / "kb.json")
    restored = KnowledgeBase.load(path)
    assert len(restored) == len(kb)
    doc = restored.get("faq-3")
    assert doc is not None and doc.metadata == {"topic": "shipping"}


def test_cli_add_search_list_remove(tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
    store = str(tmp_path / "kb.json")

    assert main(["--store", store, "add", "faq-1", "Refunds take 5 business days."]) == 0
    assert main(["--store", store, "search", "refunds"]) == 0
    assert "faq-1" in capsys.readouterr().out

    assert main(["--store", store, "list"]) == 0
    assert "faq-1" in capsys.readouterr().out

    assert main(["--store", store, "remove", "faq-1"]) == 0
    assert main(["--store", store, "remove", "faq-1"]) == 1


def test_cli_search_without_matches(tmp_path: Path) -> None:
    assert main(["--store", str(tmp_path / "kb.json"), "search", "anything"]) == 1
