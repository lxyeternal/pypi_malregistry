# safepackage
## An Awesome Calculator!
### Usage
```python
pip install safepackage
```
Then Simply:
```bash
python3 -c "import safepackage;print(safepackage.calc(15,19))"
```
Please stay safe :)
