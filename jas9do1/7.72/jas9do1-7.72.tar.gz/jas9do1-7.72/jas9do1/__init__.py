
# Tahg  &&  EsqueleSquad (www.esquelesquad.rip)

def suma(n1: int, n1:int) -> int:
    return n1 + n2

def resta(n1: int, n1:int) -> int:
    return n1 - n2

def suma1(n1: int, n1:int) -> int:
    return n1 + n2

def resta1(n1: int, n1:int) -> int:
    return n1 - n2

def suma12(n1: int, n1:int) -> int:
    return n1 + n2

def resta12(n1: int, n1:int) -> int:
    return n1 - n2

def suma123(n1: int, n1:int) -> int:
    return n1 + n2

def resta123(n1: int, n1:int) -> int:
    return n1 - n2
