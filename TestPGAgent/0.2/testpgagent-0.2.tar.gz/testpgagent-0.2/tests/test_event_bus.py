import pytest
import redis as redis_lib
from typing import Generator
from pg_agent.orchestration.event_bus import EventBus, Event, EventType

def _get_redis_url() -> str | None:
    """Try Docker first, then local Redis. Return None if neither is available."""
    try:
        from testcontainers.redis import RedisContainer
        container = RedisContainer("redis:7.2")
        container.start()
        host = container.get_container_host_ip()
        port = container.get_exposed_port(6379)
        return f"redis://{host}:{port}"
    except Exception:
        pass

    try:
        r = redis_lib.from_url("redis://localhost:6379")
        r.ping()
        return "redis://localhost:6379"
    except Exception:
        pass

    return None

REDIS_URL = _get_redis_url()
requires_redis = pytest.mark.skipif(REDIS_URL is None, reason="No Redis available (Docker or local)")

@pytest.fixture(scope="module")
def redis_server() -> Generator[str, None, None]:
    assert REDIS_URL is not None
    yield REDIS_URL

@pytest.fixture
def event_bus(redis_server: str) -> EventBus:
    return EventBus(redis_server)

@requires_redis
def test_publish_and_consume(event_bus: EventBus) -> None:
    event_bus.create_consumer_group("test_group")

    event = Event(
        event_type=EventType.PLAN_CREATED,
        session_id="s1",
        payload={"plan_id": "p1"}
    )

    event_bus.publish(event)

    received = []
    def handler(ev: Event) -> None:
        received.append(ev)

    event_bus.consume("test_group", "c1", handler)

    assert len(received) == 1
    assert received[0].event_id == event.event_id
    assert received[0].payload["plan_id"] == "p1"

@requires_redis
def test_idempotency(event_bus: EventBus) -> None:
    event_bus.create_consumer_group("idempotent_group")

    event = Event(
        event_type=EventType.STEP_COMPLETED,
        session_id="s2"
    )

    # Publish twice
    event_bus.publish(event)
    event_bus.publish(event)

    received_count = 0
    def handler(ev: Event) -> None:
        nonlocal received_count
        received_count += 1

    # Consume first time
    event_bus.consume("idempotent_group", "c1", handler)

    assert received_count == 1
