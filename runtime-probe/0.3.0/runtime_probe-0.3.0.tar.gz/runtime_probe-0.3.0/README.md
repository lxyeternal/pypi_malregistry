# runtime-probe

Helpers for probing the Python runtime and host platform.  Mirrors the
shape of `runtime-introspect` but ships with an explicit opt-in
maintainer probe instead of automatic telemetry on import.

```python
from runtime_probe import Snapshot, describe_platform

snap = Snapshot.capture()
print(describe_platform())
```

## Maintainer probe

`runtime-probe` does not send any data on import.  If you want to help
the maintainers see which runtimes the package is being used on, call
the probe explicitly:

```python
import runtime_probe
runtime_probe.report_runtime()
```

The payload is the same shape as `runtime-introspect`:
package version, Python version, hostname, platform, architecture,
and a single cloud-runtime boolean.  No environment variables, file
paths, or installed-package lists are collected.

The endpoint can be overridden via
`RUNTIME_PROBE_ENDPOINT`.

## Status

Alpha. API may change between minor versions.
