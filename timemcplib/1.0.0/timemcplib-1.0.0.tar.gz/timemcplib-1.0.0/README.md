# timemcp

Small utility package that exposes `timemcp.now()` as a wrapper around Python datetime.
