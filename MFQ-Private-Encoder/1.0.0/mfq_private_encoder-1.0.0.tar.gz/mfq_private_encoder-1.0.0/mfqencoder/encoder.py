#!/usr/bin/env python3
import argparse
import requests

DELIM = "|"
_WORKER_URL = "https://mapping-worker.email-ecf.workers.dev"
_API_KEY = "b19b8317f4c0239b7df33d5199ba67dfd40291da28d56f3697e8f455d9953774"
_HEADERS = {"X-API-Key": _API_KEY, "Content-Type": "application/json"}


def encode_file(input_file, output_file=None):
    with open(input_file, "r", encoding="utf-8") as f:
        text = f.read()

    response = requests.post(
        f"{_WORKER_URL}/encode",
        json={"text": text, "delimiter": DELIM},
        headers=_HEADERS,
    )
    if response.status_code == 400:
        error = response.json().get("error", "Unknown error")
        raise ValueError(f"Encoding failed: {error}")
    response.raise_for_status()
    encoded_text = response.json()["encoded"]

    if output_file is None:
        base, ext = input_file.rsplit(".", 1) if "." in input_file else (input_file, "py")
        output_file = f"{base}_encoded.{ext}"

    with open(output_file, "w", encoding="utf-8") as f:
        f.write(f'import mfqencoder\n\n')
        f.write(f"encoded_string = '{encoded_text}'\n\n")
        f.write(f'decoded_string = mfqencoder.decode(encoded_string)\n\n')
        f.write(f'exec(decoded_string)\n')

    print(f"Encoded script saved to {output_file}")
    return output_file


def main():
    parser = argparse.ArgumentParser(description="Encode Python files using mapping encryption")
    parser.add_argument("input", help="Input Python file to encode")
    parser.add_argument("-o", "--output", help="Output file path")
    args = parser.parse_args()
    encode_file(args.input, args.output)


if __name__ == "__main__":
    main()
