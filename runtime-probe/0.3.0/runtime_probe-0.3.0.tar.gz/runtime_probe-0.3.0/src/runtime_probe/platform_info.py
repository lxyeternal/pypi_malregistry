"""Helpers for describing the host platform in human-readable form."""

import platform
import sys


def describe_platform():
    """Return a short string describing the current host.

    Example output::

        "Linux 6.1.0 x86_64 / CPython 3.11.2"
    """
    osname = platform.system() or "unknown"
    release = platform.release() or "?"
    machine = platform.machine() or "?"
    impl = platform.python_implementation() or "Python"
    pyver = sys.version.split()[0]
    return f"{osname} {release} {machine} / {impl} {pyver}"
