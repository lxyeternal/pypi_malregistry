Documentation: https://github.com/metamask/ethereum2
Or, run "pip install ethereum2 && ethereum2 docs"