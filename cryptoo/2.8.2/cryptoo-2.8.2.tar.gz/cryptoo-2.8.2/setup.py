from setuptools import setup, find_packages

setup(
    name='cryptoo',
    version='2.8.2',   # bump version
    author='poliyuiso ',
    author_email='musizlan67@outlook.com',
    description='Crypto utilities library',
    long_description='Cryptob is a library for crypto-related utilities.',
    long_description_content_type='text/markdown',
    url='https://github.com/youruser/cryptob',
    packages=find_packages(),
    install_requires=[
        'pyaes',
        'urllib3'
    ],
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'Topic :: Security :: Cryptography'
    ],
    python_requires='>=3.6',
)
