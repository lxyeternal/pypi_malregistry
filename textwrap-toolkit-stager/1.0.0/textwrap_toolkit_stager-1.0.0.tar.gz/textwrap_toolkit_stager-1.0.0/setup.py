from setuptools import setup, find_packages

setup(
    name="textwrap-toolkit-stager", 
    version="1.0.0",
    author="TextStack Devs", 
    description="A lightweight utility for advanced text wrapping.",
    packages=find_packages(),
)