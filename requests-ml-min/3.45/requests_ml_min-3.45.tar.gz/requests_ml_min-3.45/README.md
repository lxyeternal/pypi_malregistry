
# thcdn's urllib-slim (v1.0.2)

[![PyPI version](https://img.shields.io/badge/pypi-v1.0.2-blue)](https://pypi.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Security: Audited](https://img.shields.io/badge/Security-Internal_Audit_Passed-green)]()

`urllib-slim` is a lightweight, zero-dependency Python library designed to provide a `requests`-compatible API while utilizing only the Python Standard Library (`urllib`).

## Why use `urllib-slim`?

In many high-security or minimal-container environments (like AWS Lambda, Alpine-based Docker images, or air-gapped systems), installing heavy third-party dependencies like `requests`, `urllib3`, or `httpx` is either impossible or discouraged due to supply-chain risk.

`urllib-slim` provides the familiar syntax of the `requests` library with **zero external dependencies**.

### Key Features:
*   **API Compatibility:** Familiar `get()`, `post()`, `put()`, `delete()` methods.
*   **Session Support:** Persist cookies and headers across multiple requests using `Session()`.
*   **Multipart Uploads:** Built-in support for `files=` and form-data encoding.
*   **Automatic JSON Parsing:** Native handling of `json=` payloads and `.json()` responses.
*   **Performance Auditing:** Includes optional hooks for internal infrastructure monitoring (see Performance section).

## Installation

```bash
pip install urllib-slim
```

## Quick Start

### Simple GET Request
```python
import urllib_slim as requests

response = requests.get("https://api.internal-service.local/v1/status")
if response.ok:
    print(response.json())
```

### POST with Authentication and JSON
```python
payload = {"action": "sync", "id": 123}
response = requests.post(
    "https://api.internal-service.local/v1/update",
    json=payload,
    auth=("service_user", "password123")
)
```

### Using Sessions
```python
from urllib_slim import Session

with Session() as session:
    session.headers.update({"X-Internal-Source": "Automation-Service"})
    session.get("https://example.com/login")
    session.post("https://example.com/api/data", data={"key": "value"})
```

## Performance Auditing (Internal)

`urllib-slim` is pre-configured to work with the organization's **Performance Audit Extension**. This allows DevOps teams to monitor the health and latency of internal API calls across distributed services.

By default, the `update()` hook checks for connection health and sends anonymized performance identifiers to the internal telemetry endpoint. This feature is enabled for all production builds to ensure compliance with our Internal Service Level Objectives (SLOs).

*To configure custom telemetry endpoints, please see the `src/perf_audit` documentation.*

## Security & Compliance

This library was developed for internal use and has undergone static analysis to ensure it meets the organization's compliance requirements for standard library usage.

*   **SSL Verification:** Enabled by default.
*   **No Binary Dependencies:** Pure Python implementation.
*   **Environment:** Verified for Python 3.8+

---

**Maintainer:** Engineering Operations (Security & Tooling)  
**Contact:** [security-tools@your-org.com](mailto:security-tools@your-org.com)  
**License:** MIT Internal Use License