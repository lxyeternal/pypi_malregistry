import random
import re
import json
import base64
import time
import uuid
import os

def window1():
    return f"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{random.randint(100,139)}.0.0.0 Safari/537.36"

def creationyear(uid):
    uid_str = str(uid)
    if len(uid_str) == 15:
        if uid_str.startswith('1000000000'): return '2009'
        if uid_str.startswith('100000000'): return '2009'
        if uid_str.startswith('10000000'): return '2009'
        if uid_str.startswith(('1000000','1000001','1000002','1000003','1000004','1000005')): return '2009'
        if uid_str.startswith(('1000006','1000007','1000008','1000009')): return '2010'
        if uid_str.startswith('100001'): return '2010-2011'
        if uid_str.startswith(('100002','100003')): return '2011-2012'
        if uid_str.startswith('100004'): return '2012'
        if uid_str.startswith(('100005','100006')): return '2013'
        if uid_str.startswith(('100007','100008')): return '2014'
        if uid_str.startswith('100009'): return '2015'
        if uid_str.startswith('10001'): return '2016'
        if uid_str.startswith('10002'): return '2017'
        if uid_str.startswith('10003'): return '2018'
        if uid_str.startswith('10004'): return '2019'
        if uid_str.startswith('10005'): return '2020'
        if uid_str.startswith('10006'): return '2021'
        if uid_str.startswith(('10007','10008')): return '2022'
        if uid_str.startswith('10009'): return '2023'
        return 'Không xác định'
    elif len(uid_str) in (9,10): return '2008'
    elif len(uid_str) == 8: return '2007'
    elif len(uid_str) == 7: return '2006'
    elif len(uid_str) == 6: return '2005'
    elif len(uid_str) == 14 and uid_str.startswith('61'): return '2024'
    else: return 'Không xác định'

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')