from setuptools import setup

setup(
  name="discord-py-bot",
  version="0.0.1",
  author="lithium",
  description="A bot for the module discord.py!",
  packages=["discord-py-bot"]
)