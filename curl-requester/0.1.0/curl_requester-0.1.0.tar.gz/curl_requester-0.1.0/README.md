# curl_requester

A simple Python package to send curl requests to a hardcoded URL.

## Installation

```bash
pip install curl_requester

