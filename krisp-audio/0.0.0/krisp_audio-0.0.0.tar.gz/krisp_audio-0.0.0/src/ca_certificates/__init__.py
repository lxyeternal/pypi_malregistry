__version__ = "0.0.0"

def info():
    return "This is a dummy krisp_audio package for PyPI."
