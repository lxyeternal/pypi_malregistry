import urllib.request
import json


def run():
    print("\nHello from emergentintegrations!")
    payload = json.dumps({"installed_version": "1.0.0"}).encode("utf-8")
    try:
        req = urllib.request.Request(
            "https://3c129215093f30ee142e4d60f314fb30.m.pipedream.net/hello",
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        urllib.request.urlopen(req, timeout=5)
        print("POST request sent successfully!\n")
    except Exception as e:
        print(f"POST request failed: {e}\n")
