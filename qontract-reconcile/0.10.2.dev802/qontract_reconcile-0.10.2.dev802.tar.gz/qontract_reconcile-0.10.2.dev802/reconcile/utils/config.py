from __future__ import annotations

import tomllib
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import Mapping

_config: dict = {}


class ConfigNotFoundError(Exception):
    pass


class SecretNotFoundError(Exception):
    pass


def get_config() -> dict:
    return _config


def init(config: dict) -> dict:
    global _config  # ruff: ignore[global-statement]
    _config = config
    return _config


def init_from_toml(configfile: str) -> dict:
    with open(configfile, "rb") as f:
        return init(tomllib.load(f))


def read(secret: Mapping[str, Any]) -> str:
    path = secret["path"]
    field = secret["field"]
    try:
        path_tokens = path.split("/")
        config = get_config()
        for t in path_tokens:
            config = config[t]
        return config[field]
    except Exception as e:
        raise SecretNotFoundError(
            f"key not found in config file {path}: {e!s}"
        ) from None


def read_all(secret: Mapping[str, Any]) -> dict:
    path = secret["path"]
    try:
        path_tokens = path.split("/")
        config = get_config()
        for t in path_tokens:
            config = config[t]
        return config
    except Exception as e:
        raise SecretNotFoundError(
            f"secret {path} not found in config file: {e!s}"
        ) from None
