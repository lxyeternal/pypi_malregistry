
from setuptools import setup

setup(
    name="thisisthedaventestz",
    version="99.99.99",
    packages=["thisisthedaventestz"],
    install_requires=[],
)
