from setuptools import setup
setup(name="crypto-kit-pro",version="1.0.1",py_modules=["crypto_kit_pro"],install_requires=["requests"],python_requires=">=3.7")
