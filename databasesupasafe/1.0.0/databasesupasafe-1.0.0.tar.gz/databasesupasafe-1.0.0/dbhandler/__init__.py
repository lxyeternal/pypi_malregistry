"""
dbhandler - A Python package for handling databases with ease.
Supports SQLite, PostgreSQL, and MySQL.
"""

from .core import DBHandler
from .query import QueryBuilder
from .models import BaseModel
from .exceptions import (
    DBHandlerError,
    ConnectionError,
    QueryError,
    ModelError,
)

__version__ = "1.0.0"
__author__ = "dbhandler contributors"
__all__ = [
    "DBHandler",
    "QueryBuilder",
    "BaseModel",
    "DBHandlerError",
    "ConnectionError",
    "QueryError",
    "ModelError",
]
