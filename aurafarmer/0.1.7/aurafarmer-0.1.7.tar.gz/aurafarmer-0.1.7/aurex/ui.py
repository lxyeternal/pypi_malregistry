import sys, time, shutil, textwrap
from rich.console import Console
from rich.live import Live
from rich.spinner import Spinner
from rich.syntax import Syntax

console = Console(force_terminal=True, highlight=False)

# ── ANSI ───────────────────────────────────────────────────────────────────────
R  = '\033[0;31m';  BR = '\033[1;31m';  DR = '\033[2;31m'
B  = '\033[0;34m';  BB = '\033[1;34m'
G  = '\033[0;32m';  BG = '\033[1;32m'
W  = '\033[1;37m';  DW = '\033[0;37m'
DIM= '\033[2m';     RST= '\033[0m'

TOOL_ICONS = {
    "read_file":"📖","write_file":"✏️ ","run_command":"⚡",
    "list_files":"📁","search_files":"🔍","delete_file":"🗑️ ","web_search":"🌐",
}

def _tw():
    return min(shutil.get_terminal_size().columns - 4, 56)

# ── Banner ─────────────────────────────────────────────────────────────────────
BANNER = """\
 █████╗ ██╗   ██╗██████╗ ███████╗██╗  ██╗
██╔══██╗██║   ██║██╔══██╗██╔════╝╚██╗██╔╝
███████║██║   ██║██████╔╝█████╗   ╚███╔╝ 
██╔══██║██║   ██║██╔══██╗██╔══╝   ██╔██╗ 
██║  ██║╚██████╔╝██║  ██║███████╗██╔╝ ██╗
╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝"""

def print_banner():
    console.print(BANNER, style="bold red", justify="center")
    console.print("[dim]        AI Coding Agent[/dim]\n", justify="center")

def print_separator():
    print(f"{DR}{'─'*_tw()}{RST}")

# ── User box (white) ───────────────────────────────────────────────────────────
def print_user_box(msg: str):
    w = _tw()
    lines = []
    for raw in msg.splitlines():
        wrapped = textwrap.wrap(raw, width=w-2, break_long_words=True)
        lines.extend(wrapped or [""])
    inner = max((len(l) for l in lines), default=10)
    inner = min(max(inner + 2, 20), w)
    print(f"\n{W}╭{'─'*inner}╮{RST}")
    for line in lines:
        pad = inner - 2 - len(line)
        print(f"{W}│{RST} {W}{line}{RST}{' '*max(0,pad)} {W}│{RST}")
    print(f"{W}╰{'─'*inner}╯{RST}\n")

# ── AI response header / footer ────────────────────────────────────────────────
def print_ai_header():
    w = _tw()
    label = " ✦ Aurex "
    left  = (w - len(label)) // 2
    right = w - len(label) - left
    print(f"\n{BR}{'─'*left}{label}{'─'*right}{RST}\n")

def print_ai_footer():
    print(f"\n{DR}{'─'*_tw()}{RST}\n")

# ── Thinking labels ────────────────────────────────────────────────────────────
def show_thinking_start(task: str):
    with Live(
        Spinner("dots2", text=f"{BR}  Thinking...{RST} {DIM}({task}){RST}"),
        console=console, transient=True, refresh_per_second=15,
    ):
        time.sleep(2.5)
    print(f"  {BG}✓  Thought about:{RST} {DIM}{task}{RST}\n")

def show_thinking_end(task: str):
    print(f"  {BG}✓  Thought about:{RST} {DIM}{task}{RST}\n")

# ── Code block animation ───────────────────────────────────────────────────────
def show_generating(lang: str):
    label = lang if lang else "file"
    sys.stdout.write(f"\n  {BB}📄  Generating {label}...{RST}\n")
    sys.stdout.flush()

def show_generated(lang: str, code: str):
    label = lang if lang else "file"
    # Animate: replace "generating..." line with "✓ generated"
    sys.stdout.write(f"\033[1A\033[2K  {BG}✓  {label} generated{RST}\n\n")
    sys.stdout.flush()
    if code.strip():
        console.print(Syntax(
            code.strip(), lang or "text",
            theme="monokai", word_wrap=True,
            background_color="default",
            line_numbers=len(code.strip().splitlines()) > 8,
        ))
    print()

# ── Tool use header (blue) ─────────────────────────────────────────────────────
def print_tool_header(name: str, args: dict):
    icon = TOOL_ICONS.get(name, "🔧")
    print(f"\n  {BB}{icon}  {name}{RST}")
    print(f"  {B}{'─'*38}{RST}")
    for k, v in args.items():
        val = str(v)
        if len(val) > 60: val = val[:60] + "…"
        print(f"  {B}{k}:{RST} {val}")

# ── CMD output box (green) ─────────────────────────────────────────────────────
def print_cmd_box(command: str, output: str):
    w = _tw()
    title = " CMD Output "
    top   = f"╭{title}{'─'*(w-len(title))}╮"
    print(f"\n{BG}{top}{RST}")
    cmd_d = f"$ {command}"
    if len(cmd_d) > w-2: cmd_d = cmd_d[:w-5]+"..."
    print(f"{G}│ {cmd_d}{' '*(w-2-len(cmd_d))} │{RST}")
    print(f"{G}├{'─'*w}┤{RST}")
    all_lines = []
    for line in output.strip().splitlines():
        all_lines.extend(textwrap.wrap(line, width=w-2, break_long_words=True) or [""])
    for line in all_lines[:25]:
        pad = w - 2 - len(line)
        print(f"{G}│ {line}{' '*max(0,pad)} │{RST}")
    if len(all_lines) > 25:
        msg = f"  …{len(all_lines)-25} more lines"
        print(f"{G}│{msg}{' '*max(0,w-len(msg))}│{RST}")
    print(f"{BG}╰{'─'*w}╯{RST}\n")

# ── Other tool result ──────────────────────────────────────────────────────────
def print_tool_result(name: str, result: str):
    MAX = 350
    disp = result[:MAX] + (f"\n  …{len(result)-MAX} more" if len(result)>MAX else "")
    print(f"  {DIM}{'─'*38}{RST}")
    for line in textwrap.wrap(disp.strip(), width=_tw()-2, break_long_words=True):
        print(f"  {G}{line}{RST}")
    print()

# ── Help ───────────────────────────────────────────────────────────────────────
def print_help():
    w = _tw()
    print(f"\n{BR}{'─'*w}{RST}")
    print(f"{BR}  Help{RST}")
    print(f"{BR}{'─'*w}{RST}\n")
    sections = [
        ("Commands",[
            ("help","Show this screen"),
            ("model","Switch AI model"),
            ("fast","Toggle fast mode — races 5 API keys, fastest wins"),
            ("clear","Wipe conversation"),
            ("files","List files here"),
            ("exit","Quit"),
        ]),
        ("Stop AI",[("Ctrl+C","Stop mid-response")]),
        ("Thinking mode",[
            ("<think>","Append to prompt for deep reasoning"),
            ("Example:","fix my bug<think>"),
        ]),
        ("Model switching",[
            ("number","Pick from list"),
            ("C","Enter custom model name"),
        ]),
        ("Web search",[("auto","Just ask anything current")]),
    ]
    for title, rows in sections:
        print(f"  {BR}{title}{RST}")
        print(f"  {DR}{'─'*36}{RST}")
        for k, v in rows:
            print(f"  {R}{k:<14}{RST} {DW}{v}{RST}")
        print()
    print(f"{DR}{'─'*w}{RST}\n")

# ── Model UI ───────────────────────────────────────────────────────────────────
def print_current_model(display: str):
    print(f"\n  {DIM}Active{RST}  {BR}aurex/{display}{RST}\n")

def print_model_list(models: list, current: str):
    print(f"{BR}{'─'*10} Models {'─'*10}{RST}\n")
    for i, (fake, _) in enumerate(models, 1):
        active = f"  {BG}◀ active{RST}" if fake == current else ""
        print(f"  {R}{i:>2}{RST}  {W}aurex/{fake}{RST}{active}")
    print(f"\n  {DIM}number  ·  C for custom  ·  Enter to keep{RST}\n")

def print_error(msg: str):
    print(f"\n  {BR}✗{RST}  {msg}\n")

def print_info(msg: str):
    print(f"  {DR}ℹ{RST}  {msg}")

# ── Stream renderer ────────────────────────────────────────────────────────────
class StreamRenderer:
    """Detects ``` fences in streaming text and emits events."""
    def __init__(self):
        self._buf = ""; self._in_code = False
        self._lang = ""; self._code = ""

    def feed(self, chunk: str) -> list:
        self._buf += chunk
        return self._process()

    def flush(self) -> list:
        events = []
        if self._in_code:
            events.append(("code_end", (self._lang, (self._code+self._buf).rstrip())))
        elif self._buf.strip():
            events.append(("text", self._buf))
        self._buf = ""; self._code = ""
        return events

    def _process(self) -> list:
        events = []
        while "```" in self._buf:
            idx = self._buf.find("```")
            if not self._in_code:
                if idx > 0:
                    events.append(("text", self._buf[:idx]))
                rest = self._buf[idx+3:]
                nl = rest.find("\n")
                if nl == -1:
                    self._buf = self._buf[idx:]; break
                self._lang = rest[:nl].strip()
                self._buf  = rest[nl+1:]
                self._in_code = True; self._code = ""
                events.append(("code_start", self._lang))
            else:
                self._code += self._buf[:idx]
                events.append(("code_end", (self._lang, self._code.rstrip())))
                self._buf = self._buf[idx+3:]
                if self._buf.startswith("\n"): self._buf = self._buf[1:]
                self._in_code = False; self._code = ""
        # safe-emit remaining (keep 2-char fence guard)
        if "```" not in self._buf and len(self._buf) > 2:
            safe = self._buf[:-2]
            self._buf = self._buf[-2:]
            if self._in_code:
                self._code += safe
            elif safe.strip():
                events.append(("text", safe))
        return events
