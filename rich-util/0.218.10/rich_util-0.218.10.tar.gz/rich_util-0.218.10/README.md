# rich-util

terminal

## Installation

```bash
pip install rich-util
```

## Usage

```python
import rich_util
```

## License

MIT
