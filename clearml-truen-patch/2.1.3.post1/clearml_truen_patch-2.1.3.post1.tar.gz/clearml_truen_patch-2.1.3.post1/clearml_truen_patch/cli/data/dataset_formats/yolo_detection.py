"""
YOLO Detection Handler
======================
YOLO Object Detection (bounding box) 포맷 핸들러.

라벨 형식:
    <class_id> <center_x> <center_y> <width> <height>   (normalized 0~1)

FiftyOne 연동:
    fo.types.YOLOv5Dataset (기본)

사용 예:
    python upload_dataset.py --format yolo-detect --local_dir ./coco128 ...
    python upload_dataset.py --format yolo ...    # "yolo" 별칭도 동작
"""

from . import register_format
from .yolo_base import YoloBaseHandler


@register_format("yolo", "yolo-det", "detect")
class YoloDetectionHandler(YoloBaseHandler):
    FORMAT_NAME = "yolo-detect"
    DESCRIPTION = "YOLO Detection (bbox) — TXT labels with bounding boxes + YAML config"
    DIRECTORY_GUIDE = """
    your_dataset/
    ├── dataset.yaml (or data.yaml)
    │   ├── names: {0: person, 1: car, ...}   # Required
    │   ├── train: train/images                # At least one split required
    │   ├── val: val/images
    │   └── test: test/images                  # Optional
    ├── train/
    │   ├── images/
    │   │   ├── img001.jpg
    │   │   └── img002.png
    │   └── labels/
    │       ├── img001.txt                     # One txt per image
    │       └── img002.txt
    ├── val/
    │   ├── images/
    │   └── labels/
    └── test/  (optional)

    📋 Label format (each line = one object):
       <class_id> <center_x> <center_y> <width> <height>
       All values normalized to [0, 1].

    Example (img001.txt):
       0 0.512 0.340 0.120 0.250
       1 0.750 0.600 0.080 0.150
    """

    def _default_task_type(self):
        return "detect"

    def _validate_format_specific(self, source_path: str, yaml_data: dict) -> list:
        """YAML의 task 필드를 확인하여 포맷 오지정 여부를 검사합니다."""
        issues = []
        yaml_task = yaml_data.get('task')
        if yaml_task in ['pose', 'keypoint']:
            issues.append(
                f"This dataset appears to be a Pose dataset (task: {yaml_task}) "
                f"but you selected '{self.FORMAT_NAME}'. "
                f"Please use '--format yolo-pose' instead."
            )
        elif yaml_task in ['segment', 'segmentation']:
            issues.append(
                f"This dataset appears to be a Segmentation dataset (task: {yaml_task}) "
                f"but you selected '{self.FORMAT_NAME}'. "
                f"Please use '--format yolo-seg' instead."
            )
        return issues

    def _init_extra_stats(self):
        return {"box_size_distribution": {
            "very_tiny": 0, "tiny": 0, "small": 0, "medium": 0, "large": 0
        }}

    def _parse_label_file(self, lbl_path, img_path, names,
                          ins_per_class, extra_stats, use_pixel_stats):
        img_w, img_h = (0, 0)
        if use_pixel_stats:
            img_w, img_h = self._get_image_size(img_path)

        try:
            with open(lbl_path, 'r') as f:
                for line in f:
                    parts = line.strip().split()
                    if len(parts) >= 5:
                        cid = int(parts[0])
                        if 0 <= cid < len(names):
                            ins_per_class[cid] += 1
                            if use_pixel_stats and img_w > 0:
                                area = (float(parts[3]) * img_w) * (float(parts[4]) * img_h)
                                boxes = extra_stats["box_size_distribution"]
                                if area < 64:
                                    boxes["very_tiny"] += 1
                                elif area < 256:
                                    boxes["tiny"] += 1
                                elif area < 1024:
                                    boxes["small"] += 1
                                elif area < 9216:
                                    boxes["medium"] += 1
                                else:
                                    boxes["large"] += 1
        except Exception:
            pass

    def report_dashboard(self, dataset, schema_data):
        if not schema_data:
            return
        try:
            schema = schema_data.get('schema', {})
            stats = schema_data.get('stats', {})

            dataset._task.connect_configuration(
                configuration={"schema": schema, "stats": stats},
                name='dataset_schema'
            )

            # Tag
            tags = dataset.tags or []
            task_tag = "DETECTION"
            if task_tag not in tags:
                dataset.tags = tags + [task_tag]

            logger = dataset._task.get_logger()

            if not stats:
                return

            # 1. Image/Label Summary
            summary_data = [["Split", "Images", "Labeled", "Background"]]
            for s, v in stats.items():
                summary_data.append([
                    s, v['images'],
                    v.get('labeled_images', 0),
                    v.get('background_images', 0)
                ])
            logger.report_table("Dataset Health", "Image/Label Summary", table_plot=summary_data)

            # 2. Class Distribution
            class_data = [["Class Name"]]
            split_names = list(stats.keys())
            for s in split_names:
                class_data[0].append(f"{s} (Ins)")
            class_data[0].append("Total")

            for i, name in enumerate(schema.get('names', [])):
                row = [name]
                total_ins = 0
                for s in split_names:
                    count = stats[s].get('instances_per_class', {}).get(i, 0)
                    row.append(count)
                    total_ins += count
                row.append(total_ins)
                class_data.append(row)
            logger.report_table("Dataset Analysis", "Class Distribution", table_plot=class_data)

            # 2.2 Plotly Histogram (New)
            plot_values = {s: [] for s in split_names}
            total_values = []
            labels = schema.get('names', [])
            for i in range(len(labels)):
                total_ins = 0
                for s in split_names:
                    count = stats[s].get('instances_per_class', {}).get(i, 0)
                    plot_values[s].append(count)
                    total_ins += count
                total_values.append(total_ins)
            
            plot_values["Total"] = total_values
            self._report_plots(
                logger, 
                title="Class Distribution (Histogram)", 
                series_name="Class Name", 
                labels=labels, 
                values_dict=plot_values
            )

            # 3. Object Scale Distribution (pixel stats가 활성화된 경우)
            first_split = list(stats.values())[0] if stats else {}
            if 'box_size_distribution' in first_split:
                has_data = any(
                    v > 0 for split_stats in stats.values()
                    for v in split_stats.get('box_size_distribution', {}).values()
                )
                if has_data:
                    scale_data = [["Split", "V.Tiny (<8x8)", "Tiny (<16x16)",
                                   "Small (<32x32)", "Medium (<96x96)", "Large (>96x96)"]]
                    for s, v in stats.items():
                        d = v.get('box_size_distribution', {})
                        scale_data.append([
                            s, d.get('very_tiny', 0), d.get('tiny', 0),
                            d.get('small', 0), d.get('medium', 0), d.get('large', 0)
                        ])
                    logger.report_table("Dataset Analysis", "Object Scale Distribution",
                                        table_plot=scale_data)

                    # 3.2 Plotly Histogram (New)
                    scale_labels = ["V.Tiny", "Tiny", "Small", "Medium", "Large"]
                    scale_plot_values = {s: [] for s in stats.keys()}
                    for s, v in stats.items():
                        d = v.get('box_size_distribution', {})
                        scale_plot_values[s] = [
                            d.get('very_tiny', 0), d.get('tiny', 0),
                            d.get('small', 0), d.get('medium', 0), d.get('large', 0)
                        ]
                    
                    self._report_plots(
                        logger, 
                        title="Object Scale Distribution (Histogram)", 
                        series_name="Scale Range", 
                        labels=scale_labels, 
                        values_dict=scale_plot_values
                    )

        except Exception as e:
            print(f"Dashboard Reporting Warning: {e}")


