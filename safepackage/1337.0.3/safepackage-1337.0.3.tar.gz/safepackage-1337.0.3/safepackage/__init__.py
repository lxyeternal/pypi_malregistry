from safepackage.Confused import *
from safepackage.calc import *
