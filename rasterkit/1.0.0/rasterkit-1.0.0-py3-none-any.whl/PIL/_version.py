# Master version for RasterKit (PIL-compatible)
from __future__ import annotations

__version__ = "1.0.0"
