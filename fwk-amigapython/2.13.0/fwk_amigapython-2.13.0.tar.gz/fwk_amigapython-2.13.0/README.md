# fwk-amigapython

> Amiga Python Framework — core runtime, configuration, and lifecycle management for Python microservices on the Amiga platform.

## Overview

`fwk-amigapython` provides the foundational building blocks for Python services running on the Inditex Amiga platform:

- **Configuration management** — environment-aware config loading with secrets resolution
- **Service lifecycle** — graceful startup/shutdown, health checks, readiness probes
- **Observability** — structured logging, metrics collection, distributed tracing hooks
- **Security** — mTLS bootstrapping, token refresh, RBAC context propagation

## Installation

```bash
pip install fwk-amigapython
```

## Quick Start

```python
from amigapython import AmigaApp, ServiceConfig

config = ServiceConfig.from_environment()
app = AmigaApp(config)

@app.route("/health")
def health():
    return {"status": "UP"}

app.run()
```

## Documentation

Full documentation is available at [amiga-python.docs.inditex.dev](https://amiga-python.docs.inditex.dev).

## License

Apache 2.0 — see [LICENSE](LICENSE) for details.
