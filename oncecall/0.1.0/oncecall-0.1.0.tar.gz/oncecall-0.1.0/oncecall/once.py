import functools
import threading

from . import utils

def once(func):
    """
    Decorator that ensures a function is executed only once per process.
    Subsequent calls return the cached result.
    """
    lock = threading.Lock()
    executed = False
    result = None

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        nonlocal executed, result
        if executed:
            return result
        with lock:
            if not executed:
                result = func(*args, **kwargs)
                executed = True
        return result

    return wrapper
