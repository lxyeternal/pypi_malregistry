# discord-telemetry

Paquete de ejemplo. Al importarlo imprime `discord-telemetry`:

```python
import discord_telemetry   # imprime: discord-telemetry
```

O como comando (entry point):

```bash
discord-telemetry
```

## ¿Dónde ejecuta código pip durante la instalación?

- **`pyproject.toml` → `[build-system]`**: declara el build backend que pip
  invoca para construir el paquete desde un sdist.
- **`setup.py`**: código Python que setuptools ejecuta durante el build.
  Los overrides de `cmdclass` (`build_py`, `install`, `develop`) son el
  equivalente al `postinstall` de npm.
- **`[project.scripts]`**: no corre en install; genera un ejecutable que
  corre cuando el usuario lo invoca.
- **`__init__.py`**: corre en import time (runtime), no en install.

Regla de seguridad clave: instalar un **wheel** NO ejecuta código del paquete
(solo se descomprime). Construir/instalar un **sdist** SÍ ejecuta el build
backend (`setup.py`). Por eso el vector real vive en el sdist.
