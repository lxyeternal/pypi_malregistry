def clarify():
    print("Package imported successfully!")
