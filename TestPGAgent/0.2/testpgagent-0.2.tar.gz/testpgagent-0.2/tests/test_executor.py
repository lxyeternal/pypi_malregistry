import pytest
from typing import Dict, Any
from unittest.mock import AsyncMock, MagicMock, patch
from pg_agent.agent.executor import ExecutionAgent, CircuitBreakerOpenError, ExecutionError
from pg_agent.agent.planner import Plan, PlanStep, StepType

@pytest.fixture
def agent() -> ExecutionAgent:
    a = ExecutionAgent(pool_size=2)
    # Mock the SQL tool to return success
    mock_sql_result = MagicMock()
    mock_sql_result.success = True
    mock_sql_result.data = [{"result": 1}]
    setattr(a.sql_tool, "execute", AsyncMock(return_value=mock_sql_result))

    # Mock the Search tool
    mock_search_result = MagicMock()
    mock_search_result.success = True
    mock_search_result.data = {"answer": "Mock search result"}
    setattr(a.search_tool, "execute", AsyncMock(return_value=mock_search_result))

    # Mock the Analytics tool
    mock_agg_result = MagicMock()
    mock_agg_result.success = True
    mock_agg_result.data = {"summary": "Mock analytics result"}
    setattr(a.analytics_tool, "execute", AsyncMock(return_value=mock_agg_result))

    return a

@pytest.mark.asyncio
async def test_execute_sequential_plan(agent: ExecutionAgent) -> None:
    step1 = PlanStep(id="1", type=StepType.SQL, description="SELECT 1")
    step2 = PlanStep(id="2", type=StepType.SEARCH, description="Search 1", depends_on=["1"])
    plan = Plan(steps=[step1, step2], reasoning="Sequential test")

    results = []
    async for event in agent.execute_plan(plan):
        results.append(event)
    
    assert len(results) == 2
    assert results[0]["step_id"] == "1"
    assert results[1]["step_id"] == "2"

@pytest.mark.asyncio
async def test_execute_analyze_step(agent: ExecutionAgent) -> None:
    # ANALYZE replaces AGGREGATE
    step1 = PlanStep(id="1", type=StepType.SQL, description="SELECT 1")
    step2 = PlanStep(id="2", type=StepType.ANALYZE, description="Analyze data", depends_on=["1"])
    plan = Plan(steps=[step1, step2], reasoning="Analyze test")

    results = []
    async for event in agent.execute_plan(plan):
        results.append(event)
    
    assert len(results) == 2
    assert results[1]["step_id"] == "2"
    result = results[1]["result"]
    assert "combined_results" in result
    assert result["row_count"] == len(result["combined_results"])

@pytest.mark.asyncio
async def test_step_retry_and_failure(agent: ExecutionAgent) -> None:
    with patch.object(agent, "_dispatch_tool", new_callable=AsyncMock) as mock_dispatch:
        mock_dispatch.side_effect = Exception("Tool failure")
        
        step1 = PlanStep(id="1", type=StepType.SQL, description="SELECT 1")
        plan = Plan(steps=[step1], reasoning="Failure test")

        with pytest.raises(ExecutionError):
            async for _ in agent.execute_plan(plan):
                pass
        
        assert mock_dispatch.call_count == 3

@pytest.mark.asyncio
async def test_circuit_breaker(agent: ExecutionAgent) -> None:
    agent.circuit_breaker.threshold = 2
    with patch.object(agent, "_dispatch_tool", new_callable=AsyncMock) as mock_dispatch:
        mock_dispatch.side_effect = Exception("Tool failure")
        
        step1 = PlanStep(id="1", type=StepType.SQL, description="SELECT 1")
        step2 = PlanStep(id="2", type=StepType.SEARCH, description="Search 1")
        plan = Plan(steps=[step1, step2], reasoning="Circuit breaker test")

        with pytest.raises(ExecutionError):
            async for _ in agent.execute_plan(plan):
                pass
        
        agent.circuit_breaker.record_failure()
        assert agent.circuit_breaker.is_open() is True

        with pytest.raises(CircuitBreakerOpenError):
            async for _ in agent.execute_plan(plan):
                pass

@pytest.mark.asyncio
async def test_fallback_logic(agent: ExecutionAgent) -> None:
    fallback_step = PlanStep(id="1_fallback", type=StepType.SEARCH, description="Fallback search")
    step1 = PlanStep(id="1", type=StepType.SQL, description="SELECT 1", fallback=fallback_step)
    plan = Plan(steps=[step1], reasoning="Fallback test")

    async def mock_dispatch(step: PlanStep) -> Dict[str, Any]:
        if step.type == StepType.SQL:
            raise Exception("SQL failed")
        return {"status": "fallback_success"}

    with patch.object(agent, "_dispatch_tool", side_effect=mock_dispatch):
        results = []
        async for event in agent.execute_plan(plan):
            results.append(event)
        
        assert len(results) == 1
        assert results[0]["result"] == {"status": "fallback_success"}
