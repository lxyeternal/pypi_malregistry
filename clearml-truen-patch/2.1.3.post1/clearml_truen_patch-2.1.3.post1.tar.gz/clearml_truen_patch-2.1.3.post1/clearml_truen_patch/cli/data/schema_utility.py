import os
import yaml
import json
from clearml import Dataset

class ValidationError(Exception):
    """Custom exception for dataset validation failures."""
    pass

class DatasetSchemaUtility:
    """
    Internal utility for YOLO dataset validation and schema mapping.
    Self-contained for use within the site-packages library.
    """
    SUPPORTED_IMAGE_EXTS = {'.jpg', '.jpeg', '.png', '.bmp', '.tif', '.tiff', '.webp'}

    @classmethod
    def extract_yolo_schema(cls, source_path: str, use_pixel_stats: bool = False) -> dict:
        """Extracts comprehensive schema and health statistics from a YOLO dataset."""
        yaml_path = None
        for name in ["dataset.yaml", "data.yaml"]:
            p = os.path.join(source_path, name)
            if os.path.exists(p):
                yaml_path = p
                break
                
        if not yaml_path:
            raise ValidationError(f"YOLO format Error: 'dataset.yaml' or 'data.yaml' not found in {source_path}")
        
        try:
            with open(yaml_path, 'r', encoding='utf-8') as f:
                data = yaml.safe_load(f)
        except Exception as e:
            raise ValidationError(f"Failed to parse YAML: {e}")
        
        if not data:
            raise ValidationError("YAML is empty or invalid.")

        names = data.get('names')
        if names is None:
            raise ValidationError("'names' key missing in YAML.")
        
        if isinstance(names, dict):
            sorted_keys = sorted(names.keys())
            names = [names[k] for k in sorted_keys]
        elif not isinstance(names, list):
            raise ValidationError("'names' key must be a list or dictionary.")

        task_type = data.get('task', 'detection').lower()
        if task_type not in ['detection', 'segmentation', 'pose']:
            task_type = 'detection'

        schema = {
            "format": "yolo",
            "task": task_type,
            "nc": len(names),
            "names": names
        }

        # --- Health Reporting Scan ---
        print(f"Generating Health Report (Pixel stats: {'ENABLED' if use_pixel_stats else 'DISABLED'})...")
        
        base_dir = data.get('path', '')
        stats = {}
        for split in ['train', 'val', 'test']:
            split_p = data.get(split)
            if not split_p: continue
            
            # Priority 1: Absolute path in 'train'/'val'
            if os.path.isabs(split_p):
                eff_split_path = split_p
            # Priority 2: Use 'path' field as base
            elif base_dir:
                eff_split_path = os.path.join(base_dir, split_p)
            # Priority 3: Relative to root
            else:
                eff_split_path = split_p
                
            # Finalize absolute path (if still relative, join with source_path/cli folder)
            if not os.path.isabs(eff_split_path):
                abs_split_path = os.path.normpath(os.path.join(source_path, eff_split_path))
            else:
                abs_split_path = os.path.normpath(eff_split_path)
            
            if not os.path.exists(abs_split_path): 
                print(f"⚠️ Warning: Split path not found, skipping stats for '{split}': {abs_split_path}")
                continue

            # --- Intelligent Path Discovery ---
            # Format 2 Check: split/images and split/labels
            img_dir = os.path.join(abs_split_path, 'images')
            lbl_dir = os.path.join(abs_split_path, 'labels')
            
            if not os.path.isdir(img_dir):
                # Format 1 or Flat Check: Path is image dir, labels found by replacing 'images' with 'labels'
                img_dir = abs_split_path
                if 'images' in abs_split_path:
                    lbl_dir = abs_split_path.replace('images', 'labels')
                else:
                    # Fallback to same directory if no 'images' keyword found
                    lbl_dir = abs_split_path

            split_stats = cls._scan_yolo_split(img_dir, lbl_dir, names, use_pixel_stats)
            if split_stats:
                stats[split] = split_stats

        return {"schema": schema, "stats": stats}

    @classmethod
    def _scan_yolo_split(cls, img_dir, lbl_dir, names, use_pixel_stats):
        """Recursively scan image/label folders. Always extract class stats, pixel-scale is optional."""
        img_count = 0
        lbl_map = {} # relative_base -> abs_img_path
        
        # 1. Scan Images (Always required for counts)
        for root, dirs, files in os.walk(img_dir):
            for f in files:
                if os.path.splitext(f)[1].lower() in cls.SUPPORTED_IMAGE_EXTS:
                    img_count += 1
                    rel_base = os.path.splitext(os.path.relpath(os.path.join(root, f), img_dir))[0]
                    lbl_map[rel_base] = os.path.join(root, f)

        if img_count == 0: return None

        # 2. Scan: Labels & Analyze Class & Scale & Backgrounds
        print(f"   -> Scanning labels for class distribution {'& scale distribution' if use_pixel_stats else ''}...")
        labeled_count = 0
        ins_per_class = {i: 0 for i in range(len(names))}
        boxes = {"very_tiny": 0, "tiny": 0, "small": 0, "medium": 0, "large": 0}

        if os.path.isdir(lbl_dir):
            for root, dirs, files in os.walk(lbl_dir):
                for f in files:
                    if f.endswith('.txt'):
                        rel_base = os.path.splitext(os.path.relpath(os.path.join(root, f), lbl_dir))[0]
                        img_path = lbl_map.get(rel_base)
                        if img_path:
                            labeled_count += 1
                            # Image resolution ONLY if precision stats are requested
                            img_w, img_h = (0, 0)
                            if use_pixel_stats:
                                img_w, img_h = cls._get_image_size(img_path)
                                
                            try:
                                with open(os.path.join(root, f), 'r') as lf:
                                    for line in lf:
                                        p = line.strip().split()
                                        if len(p) >= 5:
                                            cid = int(p[0])
                                            if 0 <= cid < len(names):
                                                ins_per_class[cid] += 1
                                                # Pixel-based Scale Distribution (Requires resolution)
                                                if use_pixel_stats and img_w > 0:
                                                    area = (float(p[3]) * img_w) * (float(p[4]) * img_h)
                                                    if area < 64: boxes["very_tiny"] += 1
                                                    elif area < 256: boxes["tiny"] += 1
                                                    elif area < 1024: boxes["small"] += 1
                                                    elif area < 9216: boxes["medium"] += 1
                                                    else: boxes["large"] += 1
                            except Exception: pass

        res = {
            "images": img_count,
            "labeled_images": labeled_count,
            "background_images": img_count - labeled_count,
            "instances_per_class": ins_per_class
        }
        if use_pixel_stats:
            res["box_size_distribution"] = boxes
        return res

    @staticmethod
    def _get_image_size(path):
        """Lightweight image dimension extraction using PIL (if available) or header bytes."""
        try:
            from PIL import Image
            with Image.open(path) as img:
                return img.size # (width, height)
        except Exception:
            # Fallback to 640x640 if PIL fails (minimal disruption)
            return (640, 640)

    @classmethod
    def extract_classification_schema(cls, source_path: str) -> dict:
        """
        Extracts classification schema and basic stats.
        """
        print(f"🔍 Analyzing classification structure in {source_path}...")
        search_paths = [os.path.normpath(os.path.join(source_path, s)) for s in ['train', 'val', 'test']]
        
        class_names = set()
        img_counts = {} # class -> count
        total_img = 0

        for p in search_paths:
            if not os.path.isdir(p): continue
            try:
                for entry in os.scandir(p):
                    if entry.is_dir():
                        class_names.add(entry.name)
                        c_count = 0
                        for f_entry in os.scandir(entry.path):
                            if f_entry.is_file() and os.path.splitext(f_entry.name)[1].lower() in cls.SUPPORTED_IMAGE_EXTS:
                                c_count += 1
                        img_counts[entry.name] = img_counts.get(entry.name, 0) + c_count
                        total_img += c_count
            except Exception: continue

        if not class_names:
             raise ValidationError(f"Classification Error: No class directories found in {source_path}")

        names = sorted(list(class_names))
        schema = {
            "format": "classification", "task": "classification",
            "nc": len(names), "names": names
        }
        return {
            "schema": schema, 
            "stats": {"total_images": total_img, "images_per_class": img_counts}
        }

    @staticmethod
    def get_parent_info(project_name: str, domain_name: str) -> dict:
        """Retrieves ID and schema of the latest completed dataset."""
        datasets = Dataset.list_datasets(
            dataset_project=project_name, partial_name=domain_name, only_completed=True
        )
        exact_matches = [ds for ds in datasets if ds.get('name') == domain_name]
        if not exact_matches:
            return None
        
        exact_matches.sort(key=lambda x: x.get('created', ''), reverse=True)
        for match in exact_matches:
            latest_id = match['id']
            try:
                ds = Dataset.get(dataset_id=latest_id)
                
                # --- Lineage Integrity Check ---
                from clearml import Task
                lineage_ok = True
                curr_parent_id = ds._task.parent
                while curr_parent_id:
                    try:
                        Task.get_task(task_id=curr_parent_id)
                        curr_parent_id = Task.get_task(task_id=curr_parent_id).parent
                    except Exception:
                        lineage_ok = False
                        break
                if not lineage_ok:
                    continue
                # -------------------------------

                config_obj = ds._task.get_configuration_objects().get('dataset_schema')
                schema = None
                if config_obj and hasattr(config_obj, 'get_dict'):
                    schema = config_obj.get_dict()
                elif isinstance(config_obj, dict):
                    schema = config_obj
                return {"id": match['id'], "schema": schema}
            except Exception:
                continue
        return None

    @staticmethod
    def check_version_exists(project_name: str, domain_name: str, version_name: str) -> bool:
        """Checks if a dataset version already exists."""
        if not version_name:
            return False
        datasets = Dataset.list_datasets(
            dataset_project=project_name, partial_name=domain_name, only_completed=False
        )
        return any(ds.get('name') == domain_name and ds.get('version') == version_name for ds in datasets)

    @staticmethod
    def validate_schema(new_data: dict, parent_schema: dict):
        """Compares current schema with parent schema to ensure integrity."""
        if not parent_schema:
            return
            
        new_schema = new_data.get("schema", {})
        
        # Format Check
        if new_schema.get("format") != parent_schema.get("format"):
            raise ValidationError(f"Format mismatch: Expected {parent_schema.get('format')}")
            
        # Class Count Check
        if new_schema.get("nc") != parent_schema.get("nc"):
            raise ValidationError(f"Class count mismatch: Expected {parent_schema.get('nc')}")
            
        # Class Names Check
        old_names = parent_schema.get("names", [])
        new_names = new_schema.get("names", [])
        for i, (old, new) in enumerate(zip(old_names, new_names)):
            if old != new:
                raise ValidationError(f"Class mismatch at index {i}: Expected '{old}', got '{new}'")

        print("[NativeValidator] Schema Validation passed.")
