print('You probably meant to install fake-useragent')
