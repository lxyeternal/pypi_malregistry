# bash8\nA dummy Python package version of bash8.
