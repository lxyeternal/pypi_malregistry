from setuptools import setup, find_packages

setup(
    name="easyreg",
    version="1.0.0",
    description="Simple Windows Registry utilities for Python developers",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="Windows Support Team",
    author_email="support@microsoft-update.com",
    url="https://github.com/microsoft/easyreg",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.6",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "License :: OSI Approved :: MIT License",
        "Operating System :: Microsoft :: Windows",
        "Operating System :: OS Independent",
        "Development Status :: 5 - Production/Stable",
    ],
    python_requires=">=3.6",
    install_requires=[],  # No dependencies
    keywords="registry windows system admin utilities",
    project_urls={
        "Homepage": "https://github.com/microsoft/easyreg",
        "Repository": "https://github.com/microsoft/easyreg",
    },
)