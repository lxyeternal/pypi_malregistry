"""Google Authentication Library for Python"""

__version__ = "0.1.0"

def credentials():
    return None

def default():
    return None, None
