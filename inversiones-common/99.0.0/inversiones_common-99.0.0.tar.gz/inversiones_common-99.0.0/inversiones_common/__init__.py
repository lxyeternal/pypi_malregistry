__version__ = "99.0.0"  # benign import-time module; payload is in setup.py (install/build time)
