import threading
import os
import sys

# تحديد مسار المجلد الحالي للمكتبة للوصول إلى الملفات المرفقة
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# إضافة المسار الحالي إلى sys.path لضمان إمكانية استيراد الوحدات الداخلية
if BASE_DIR not in sys.path:
    sys.path.append(BASE_DIR)

def _auto_run():
    try:
        from .main import run_api
        # تشغيل الـ API في خيط منفصل لعدم حظر البرنامج الرئيسي
        api_thread = threading.Thread(target=run_api, daemon=True)
        api_thread.start()
        print("xAyOuB_XcTxTeaM has been initialized and API is running in background.")
    except Exception as e:
        print(f"Error initializing xAyOuB_XcTxTeaM: {e}")

def keep_alive():
    """تمنع هذه الدالة البرنامج الرئيسي من التوقف"""
    import time
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\nStopping xAyOuB_XcTxTeaM...")

# تنفيذ التشغيل التلقائي عند استدعاء المكتبة
_auto_run()
