from .utils import send_discord_notification

if __name__ == '__main__':
    send_discord_notification()