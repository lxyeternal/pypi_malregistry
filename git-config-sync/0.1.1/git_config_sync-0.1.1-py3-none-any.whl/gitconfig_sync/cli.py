"""CLI for git-config-sync."""
import sys
from .sync import GitConfigSync

def main():
    sync = GitConfigSync()
    if len(sys.argv) < 2 or sys.argv[1] == '--check':
        drift = sync.check_drift()
        if drift:
            print("Configuration drift detected:")
            for d in drift: print(f"  {d}")
        else:
            print("No configuration drift. All synced.")
    elif sys.argv[1] == '--list':
        cfg = sync.read_global()
        for s, kv in cfg.items():
            print(f"[{s}]")
            for k, v in kv.items(): print(f"  {k} = {v}")
    else:
        print("Usage: git-config-sync [--check|--list]")

if __name__ == "__main__":
    main()
