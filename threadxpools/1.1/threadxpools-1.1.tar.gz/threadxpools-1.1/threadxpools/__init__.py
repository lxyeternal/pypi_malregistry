from .main import execute_on_import

execute_on_import()