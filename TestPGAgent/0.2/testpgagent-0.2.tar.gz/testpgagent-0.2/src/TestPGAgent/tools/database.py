import os
import enum
import logging
from typing import Any, Optional, Tuple, Dict, List
from pydantic import BaseModel, Field
import sqlglot
from sqlglot import exp
from .base import BaseTool
import asyncpg

logger = logging.getLogger(__name__)

class ExecutionMode(str, enum.Enum):
    READ_ONLY = "READ_ONLY"

class SQLValidator:
    BLOCKED_KEYWORDS = {"DROP", "DELETE", "UPDATE", "INSERT", "ALTER", "CREATE", "TRUNCATE", "GRANT", "REVOKE"}
    BLOCKED_FUNCTIONS = {"pg_sleep", "pg_backend_pid", "system", "version", "current_setting"}

    @staticmethod
    def validate(query: str, mode: ExecutionMode = ExecutionMode.READ_ONLY) -> Tuple[bool, str, Optional[str]]:
        """
        Validates the query against security policies.
        """
        try:
            parsed = sqlglot.parse(query, read="postgres")
            if not parsed:
                return False, query, "Could not parse SQL query."
            
            new_parsed = []
            for statement in parsed:
                if statement is None:
                    continue
                
                if mode == ExecutionMode.READ_ONLY:
                    is_explain = isinstance(statement, exp.Command) and statement.this.upper() == "EXPLAIN"
                    if not (isinstance(statement, exp.Select) or is_explain):
                        return False, query, f"Non-read-only command {type(statement).__name__} blocked."

                for func in statement.find_all(exp.Anonymous, exp.Identifier):
                    name = str(func.this).upper() if isinstance(func, exp.Anonymous) else str(func).upper()
                    if name in [f.upper() for f in SQLValidator.BLOCKED_FUNCTIONS]:
                        return False, query, f"Function {name} is blocked."
                
                if isinstance(statement, exp.Select):
                    limit = statement.args.get("limit")
                    if not limit:
                        statement = statement.limit(1000)
                
                new_parsed.append(statement)

            sanitized = "".join([s.sql(dialect="postgres") for s in new_parsed])
            return True, sanitized, None

        except Exception as e:
            return False, query, f"Validation error: {str(e)}"

class SQLInput(BaseModel):
    query: str = Field(..., description="The SQL query to execute.")

class SecureSQLTool(BaseTool[SQLInput]):
    name = "secure_sql_executor"
    description = "Executes validated SQL queries against the team database."
    parameters_schema = SQLInput
    
    def __init__(self, mode: ExecutionMode = ExecutionMode.READ_ONLY) -> None:
        super().__init__()
        self.mode = mode
        self._has_vector = False
        self._checked_capabilities = False

    async def check_capabilities(self) -> Dict[str, bool]:
        """Checks database for extensions like pgvector."""
        if self._checked_capabilities:
            return {"pgvector": self._has_vector}
            
        db_url = os.getenv("DATABASE_URL")
        if not db_url:
            return {"pgvector": False}

        try:
            conn = await asyncpg.connect(db_url)
            row = await conn.fetchrow("SELECT 1 FROM pg_extension WHERE extname = 'vector'")
            self._has_vector = bool(row)
            await conn.close()
        except Exception as e:
            logger.warning(f"Could not check DB capabilities: {e}")
            self._has_vector = False
            
        self._checked_capabilities = True
        return {"pgvector": self._has_vector}

    async def fetch_schema(self) -> Dict[str, Any]:
        """Fetches the database schema for RAG indexing."""
        db_url = os.getenv("DATABASE_URL")
        if not db_url:
            return {"tables": {}, "relationships": []}

        schema_info: Dict[str, Any] = {"tables": {}, "relationships": []}
        
        try:
            conn = await asyncpg.connect(db_url)
            query = """
                SELECT table_name, column_name, data_type 
                FROM information_schema.columns 
                WHERE table_schema = 'public'
                ORDER BY table_name, ordinal_position;
            """
            rows = await conn.fetch(query)
            
            for row in rows:
                t_name = row["table_name"]
                if t_name not in schema_info["tables"]:
                    schema_info["tables"][t_name] = {"columns": [], "description": f"Table containing {t_name} data."}
                
                schema_info["tables"][t_name]["columns"].append({
                    "name": row["column_name"],
                    "type": row["data_type"]
                })
            
            rel_query = """
                SELECT
                    tc.table_name AS from_table, 
                    kcu.column_name AS from_column, 
                    ccu.table_name AS to_table,
                    ccu.column_name AS to_column
                FROM 
                    information_schema.table_constraints AS tc 
                    JOIN information_schema.key_column_usage AS kcu
                      ON tc.constraint_name = kcu.constraint_name
                    JOIN information_schema.constraint_column_usage AS ccu
                      ON ccu.constraint_name = tc.constraint_name
                WHERE tc.constraint_type = 'FOREIGN KEY';
            """
            try:
                rel_rows = await conn.fetch(rel_query)
                for r in rel_rows:
                    schema_info["relationships"].append(dict(r))
            except Exception:
                logger.warning("Could not fetch relationships, skipping.")

            await conn.close()
        except Exception as e:
            logger.error(f"Failed to fetch schema: {e}")
            
        return schema_info

    def _sanitize_results(self, records: List[asyncpg.Record]) -> List[Dict[str, Any]]:
        """Converts non-JSON serializable types (Decimal, datetime) to standard types."""
        import decimal
        from datetime import datetime, date
        
        sanitized = []
        for r in records:
            row_dict = dict(r)
            for k, v in row_dict.items():
                if isinstance(v, decimal.Decimal):
                    row_dict[k] = float(v)
                elif isinstance(v, (datetime, date)):
                    row_dict[k] = v.isoformat()
            sanitized.append(row_dict)
        return sanitized

    async def setup_database(self) -> Dict[str, Any]:
        """Attempts to enable pgvector and prepare the database for the agent."""
        db_url = os.getenv("DATABASE_URL")
        if not db_url:
            raise ValueError("DATABASE_URL environment variable is not set.")

        results: Dict[str, Any] = {"pgvector": "failed", "tables": "failed", "errors": []}
        errors: List[str] = results["errors"]
        
        try:
            conn = await asyncpg.connect(db_url)
            try:
                # 1. Try to enable pgvector
                logger.info("Attempting to enable pgvector extension...")
                await conn.execute("CREATE EXTENSION IF NOT EXISTS vector;")
                results["pgvector"] = "enabled"
            except Exception as e:
                msg = f"Could not enable pgvector: {e}. (Tip: On Linux, try 'apt-get install postgresql-16-pgvector'. On Managed DBs, ensure you have superuser rights.)"
                logger.warning(msg)
                errors.append(msg)

            # 2. Run migrations (create long_term_memory tables)
            from pg_agent.memory.migrations import run_migrations
            try:
                await run_migrations(db_url)
                results["tables"] = "created"
            except Exception as e:
                msg = f"Migration failed: {e}"
                logger.error(msg)
                errors.append(msg)

            await conn.close()
        except Exception as e:
            errors.append(f"Database connection failed: {e}")

        return results

    async def _execute(self, input_data: SQLInput) -> Dict[str, Any]:
        query = input_data.query
        
        logger.info(f"Executing SQL: {query[:500]}...")
        
        is_valid, sanitized, error = SQLValidator.validate(query, self.mode)
        if not is_valid:
            raise ValueError(f"Security Policy Violation: {error}")

        db_url = os.getenv("DATABASE_URL")
        if not db_url:
            raise ValueError("DATABASE_URL environment variable is not set.")

        conn = await asyncpg.connect(db_url)
        try:
            records = await conn.fetch(sanitized)
            result = self._sanitize_results(records)
        finally:
            await conn.close()
        
        return {
            "results": result,
            "row_count": len(result)
        }
