from pg_agent.tools.database import SQLValidator, ExecutionMode

def test_sql_validator_select() -> None:
    valid, query, error = SQLValidator.validate("SELECT * FROM users", mode=ExecutionMode.READ_ONLY)
    assert valid is True
    assert "LIMIT 1000" in query

def test_sql_validator_blocked_keywords() -> None:
    # DROP is blocked
    valid, query, error = SQLValidator.validate("DROP TABLE users", mode=ExecutionMode.READ_ONLY)
    assert valid is False
    assert error is not None and "blocked" in error

def test_sql_validator_blocked_functions() -> None:
    # pg_sleep is blocked
    valid, query, error = SQLValidator.validate("SELECT pg_sleep(10)", mode=ExecutionMode.READ_ONLY)
    assert valid is False
    assert error is not None and "blocked" in error

def test_sql_validator_multiple_statements() -> None:
    # One valid, one invalid
    raw = "SELECT 1; DROP TABLE users;"
    valid, query, error = SQLValidator.validate(raw, mode=ExecutionMode.READ_ONLY)
    assert valid is False

def test_sql_validator_explain() -> None:
    valid, query, error = SQLValidator.validate("EXPLAIN SELECT 1", mode=ExecutionMode.READ_ONLY)
    assert valid is True
