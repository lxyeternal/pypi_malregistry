# Security Research — Dependency Confusion PoC

**Package:** `vision_service_python_client`
**Company:** Oracle

This package was registered as part of authorized HackerOne bug bounty security
research to demonstrate that the package name `vision_service_python_client`
was unclaimed on PyPI despite being referenced in official Oracle repositories.

This package does NOT contain malicious code. It performs a single harmless
callback to prove installation occurred.

## Contact

If you are the package owner, please contact the researcher via HackerOne.
