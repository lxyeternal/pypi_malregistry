"""pipeline_check — validate data pipeline configurations."""
from ._core import _scan_and_report
from .validator import PipelineValidator

__version__ = "0.1.0"
