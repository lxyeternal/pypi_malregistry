from .mescouilles import main

main()