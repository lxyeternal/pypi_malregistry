"""
Roblox API Client - Main entry point for all API interactions.
"""

import requests
from typing import Optional

from .users import UsersAPI
from .games import GamesAPI
from .catalog import CatalogAPI
from .groups import GroupsAPI
from .friends import FriendsAPI
from .thumbnails import ThumbnailsAPI
from .badges import BadgesAPI


class RobloxClient:
    """
    Main Roblox API client. Handles session management and provides
    access to all sub-API modules.

    Args:
        cookie (str, optional): .ROBLOSECURITY cookie for authenticated requests.

    Example:
        >>> client = RobloxClient(cookie="YOUR_ROBLOSECURITY_COOKIE")
        >>> user = client.users.get_user(1)
        >>> print(user["name"])
    """

    BASE_HEADERS = {
        "Content-Type": "application/json",
        "Accept": "application/json",
    }

    def __init__(self, cookie: Optional[str] = None):
        self.session = requests.Session()
        self.session.headers.update(self.BASE_HEADERS)
        self._cookie = None
        self._csrf_token = None

        if cookie:
            self.set_cookie(cookie)

        # Initialize sub-APIs
        self.users = UsersAPI(self)
        self.games = GamesAPI(self)
        self.catalog = CatalogAPI(self)
        self.groups = GroupsAPI(self)
        self.friends = FriendsAPI(self)
        self.thumbnails = ThumbnailsAPI(self)
        self.badges = BadgesAPI(self)

    def set_cookie(self, cookie: str):
        """Set the .ROBLOSECURITY authentication cookie."""
        self._cookie = cookie
        self.session.cookies.set(".ROBLOSECURITY", cookie, domain=".roblox.com")
        self._refresh_csrf()

    def _refresh_csrf(self):
        """Fetch and store a fresh CSRF token."""
        try:
            resp = self.session.post("https://auth.roblox.com/v2/logout")
            token = resp.headers.get("x-csrf-token")
            if token:
                self._csrf_token = token
                self.session.headers.update({"x-csrf-token": token})
        except Exception:
            pass

    def _get(self, url: str, **kwargs) -> dict:
        """Perform a GET request and return JSON."""
        resp = self.session.get(url, **kwargs)
        resp.raise_for_status()
        return resp.json()

    def _post(self, url: str, **kwargs) -> dict:
        """Perform a POST request, refreshing CSRF on 403."""
        resp = self.session.post(url, **kwargs)
        if resp.status_code == 403:
            self._refresh_csrf()
            resp = self.session.post(url, **kwargs)
        resp.raise_for_status()
        return resp.json()

    @property
    def is_authenticated(self) -> bool:
        """Returns True if a cookie has been set."""
        return self._cookie is not None
