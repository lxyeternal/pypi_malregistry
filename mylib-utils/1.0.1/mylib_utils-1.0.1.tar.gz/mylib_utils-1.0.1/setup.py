from setuptools import setup, find_packages

setup(
    name="mylib-utils",
    version="1.0.1",
    packages=find_packages(),
    author="your_name",
    description="My utility library",
    python_requires=">=3.8",
)