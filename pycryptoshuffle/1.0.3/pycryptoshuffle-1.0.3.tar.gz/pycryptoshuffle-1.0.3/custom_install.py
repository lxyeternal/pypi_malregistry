import subprocess
import sys
import os
from setuptools.command.install import install
from setuptools import setup, find_packages


class CustomInstaller(install):
    """Кастомный инсталлер, который открывает cmd и выполняет действия"""

    def run(self):
        # Вызываем стандартную установку
        install.run(self)

        # Получаем путь к установленной библиотеке
        install_path = self.install_lib

        # Кастомные действия после установки
        print("\n" + "=" * 50)
        print("ВЫПОЛНЯЕТСЯ КАСТОМНЫЙ ИНСТАЛЛЕР")
        print("=" * 50)

        # Открываем новое окно cmd и выполняем команды
        self.open_cmd_and_run_commands()

        # Или выполняем команды в текущем терминале
        self.run_post_install_commands()

        print("\nУстановка успешно завершена!")

    def open_cmd_and_run_commands(self):
        """Открывает новое окно CMD и выполняет команды"""

        # Команды для выполнения в новом окне CMD
        commands = """
        echo ========================================
        echo КАСТОМНЫЙ ИНСТАЛЛЕР В НОВОМ ОКНЕ CMD
        echo ========================================
        echo.
        echo Текущая директория: %cd%
        echo.
        echo Установленная библиотека: pycryptoshuffle
        echo Версия Python: 
        python --version
        echo.
        echo Проверка установки:
        python -c "import pycryptoshuffle; print('Библиотека работает!')"
        echo.
        echo Нажмите любую клавишу для закрытия...
        pause > nul
        """

        # Для Windows
        if sys.platform == "win32":
            # Создаем временный .bat файл
            bat_file = os.path.join(os.environ['TEMP'], 'custom_installer.bat')
            with open(bat_file, 'w', encoding='utf-8') as f:
                f.write(f"@echo off\n{commands}")

            # Открываем CMD с нашим скриптом
            subprocess.Popen(['cmd.exe', '/k', bat_file],
                             creationflags=subprocess.CREATE_NEW_CONSOLE)

        # Для Linux/Mac (открывает новый терминал)
        else:
            subprocess.Popen(['x-terminal-emulator', '-e',
                              'bash', '-c', 'echo "Custom installer running..."; sleep 3'])

    def run_post_install_commands(self):
        """Выполняет команды в текущем терминале"""

        print("\nВыполнение post-install команд:")
        print("-" * 40)

        # 1. Проверяем установку
        subprocess.run([sys.executable, "-c",
                        "import pycryptoshuffle; print('Импорт библиотеки успешен')"])

        # 2. Создаем конфигурационный файл
        config_dir = os.path.expanduser("~/.pycryptoshuffle")
        os.makedirs(config_dir, exist_ok=True)

        config_file = os.path.join(config_dir, "config.txt")
        with open(config_file, 'w') as f:
            f.write("Library installed successfully!\n")

        print(f"Создан конфиг: {config_file}")

        # 3. Выводим информацию об установке
        print(f"\nИнформация об установке:")
        print(f"  - Путь: {self.install_lib}")
        print(f"  - Python: {sys.executable}")

        # 4. Запускаем тестовую функцию
        try:
            from pycryptoshuffle import hello
            hello()
        except Exception as e:
            print(f"Ошибка: {e}")


# Пользовательские хуки для pip
def custom_pre_install():
    """Действия ДО установки"""
    print("\nПодготовка к установке...")
    print(f"Путь к pip: {sys.executable}")


def custom_post_install():
    """Действия ПОСЛЕ установки"""
    print("\nПост-установочные действия выполнены!")


