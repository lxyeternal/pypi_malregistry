# Explanation:

This is Simple Python Reverse Shell module.
It is show how one can write a exploit and upload a malicious code to pyorg.
If installed how the attacker can get over your machine.