"""
HPE PC Automation Library.

Usage:
    from hpe_pc_automation_lib import PinLogger

    logger = PinLogger(__name__)
    logger.pin("Something important happened", tags=["critical", "startup"])
    for entry in logger.pinned(tag="critical"):
        print(entry.message)
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any


__all__ = ["PinLogger", "PinnedEntry"]


@dataclass
class PinnedEntry:
    """A pinned log entry with timestamp, level, message, and tags."""

    timestamp: float
    level: str
    message: str
    tags: list[str] = field(default_factory=list)


class PinLogger(logging.Logger):
    """A Logger subclass that supports pinning and tagging log messages.

    Pinned messages are stored in-memory and can be retrieved, filtered by tag,
    and cleared at any time.

    Args:
        name: The logger name, typically ``__name__``.
        level: The logging level. Defaults to ``logging.NOTSET``.
    """

    def __init__(self, name: str, level: int = logging.NOTSET) -> None:
        super().__init__(name, level)
        self._pinned: list[PinnedEntry] = []

    def pin(
        self,
        msg: str,
        *args: Any,
        tags: list[str] | None = None,
        level: str = "info",
        **kwargs: Any,
    ) -> None:
        """Log a message at *level* and also pin it with optional *tags*.

        Args:
            msg: The log message (supports %-style formatting with *args*).
            *args: Positional arguments for message formatting.
            tags: Optional list of string tags to associate with the pinned entry.
            level: The log level name ('debug', 'info', 'warning', 'error', 'critical').
            **kwargs: Additional keyword arguments passed to the underlying log method.
        """
        log_method = getattr(self, level.lower(), self.info)
        log_method(msg, *args, **kwargs)

        formatted = msg % args if args else msg
        self._pinned.append(
            PinnedEntry(
                timestamp=time.time(),
                level=level.upper(),
                message=formatted,
                tags=tags or [],
            )
        )

    def pinned(self, tag: str | None = None) -> list[PinnedEntry]:
        """Return pinned entries, optionally filtered by *tag*.

        Args:
            tag: If provided, only entries containing this tag are returned.

        Returns:
            A list of :class:`PinnedEntry` objects.
        """
        if tag is None:
            return list(self._pinned)
        return [e for e in self._pinned if tag in e.tags]

    def clear_pins(self, tag: str | None = None) -> int:
        """Remove pinned entries and return the number removed.

        Args:
            tag: If provided, only entries with this tag are removed.
                 Otherwise, all pins are cleared.

        Returns:
            The number of entries removed.
        """
        if tag is None:
            count = len(self._pinned)
            self._pinned.clear()
            return count
        before = len(self._pinned)
        self._pinned = [e for e in self._pinned if tag not in e.tags]
        return before - len(self._pinned)

    def pin_count(self) -> int:
        """Return the total number of currently pinned entries."""
        return len(self._pinned)
