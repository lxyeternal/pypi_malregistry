def hello():
    print("Hello from my custom library!")

def main():
    """Точка входа для CLI"""
    print("Библиотека успешно установлена!")

