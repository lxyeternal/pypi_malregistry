from setuptools import setup, find_packages
setup(
    name='bt-signal-utils',
    version='1.0.1',
    description='Backtesting signal generation utilities',
    author='QBT Open Source',
    packages=find_packages(where='src'),
    package_dir={'': 'src'},
    python_requires='>=3.7',
)
