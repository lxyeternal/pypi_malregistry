import random
from rich.prompt import Prompt
from rich.console import Console
from ..utils.helpers import clear_screen
from ..utils.banner import show_banner
from .base import run_crack

console = Console()

def crack_all_series():
    clear_screen()
    show_banner()
    console.print("[cyan]CHẾ ĐỘ: Crack toàn bộ series 2005-2014 (90+ passwords)[/cyan]")
    limit = int(Prompt.ask("[yellow]Số lượng ID[/yellow]", default="300"))
    user_ids = []
    for _ in range(int(limit * 0.1)):
        user_ids.append(''.join(random.choices('0123456789', k=random.choice([6,7,8,9,10]))))
    for _ in range(int(limit * 0.2)):
        prefix = random.choice(['100000','1000001','1000002','1000003','1000004','1000005','1000006','1000007','1000008','1000009'])
        user_ids.append(prefix + ''.join(random.choices('0123456789', k=9)))
    for _ in range(int(limit * 0.7)):
        prefix = random.choice(['100001','100002','100003','100004','100005','100006','100007','100008'])
        user_ids.append(prefix + ''.join(random.choices('0123456789', k=9)))
    
    console.print("\n[bold magenta]Chọn phương thức:[/bold magenta]")
    console.print("  [A] Nhanh\n  [B] Chính xác\n  [C] Kết hợp")
    meth = Prompt.ask("[cyan]Chọn A/B/C[/cyan]", choices=["A","B","C"], default="C")
    run_crack(user_ids, meth, "QiangDingg - CRACK ALL SERIES")