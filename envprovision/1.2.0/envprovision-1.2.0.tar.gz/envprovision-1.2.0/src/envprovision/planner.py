from __future__ import annotations

import hashlib
import json
import logging
import re
import subprocess
import tempfile
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

from .repository import Repository, RepoConfig, RepoAuth, RepositoryError

LOG = logging.getLogger("envprovision.planner")


class BootstrapError(Exception):
    pass


class ManifestError(Exception):
    pass

def load_bootstrap(path: Path) -> Tuple[RepoConfig, str]:
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise BootstrapError(f"cannot read bootstrap {path}: {exc}") from exc
    if raw.get("schema") != 1:
        raise BootstrapError(f"unsupported bootstrap schema {raw.get('schema')!r} (want 1)")

    svc = raw.get("service") or {}
    if not svc.get("base_url"):
        raise BootstrapError("service.base_url is required")
    manifest_path = svc.get("manifest_path")
    if not manifest_path:
        raise BootstrapError("service.manifest_path is required")

    auth_raw = svc.get("auth") or {}
    tls_raw = svc.get("tls") or {}
    repo = RepoConfig(
        base_url=svc["base_url"],
        auth=RepoAuth(
            mode=auth_raw.get("mode", "none"),
            token_env=auth_raw.get("token_env"),
            username=auth_raw.get("username"),
            password_env=auth_raw.get("password_env"),
        ),
        verify_tls=bool(tls_raw.get("verify", True)),
        ca_bundle=tls_raw.get("ca_bundle"),
    )
    return repo, manifest_path


def retrieve_manifest(repo: Repository, manifest_path: str) -> Tuple[Dict[str, Any], str]:
    with tempfile.TemporaryDirectory(prefix="envprovision-plan-") as tmp:
        dest = Path(tmp) / "manifest.json"
        try:
            repo.download(manifest_path, dest)
        except RepositoryError as exc:
            raise ManifestError(f"cannot retrieve manifest: {exc}") from exc
        data = dest.read_bytes()

    manifest_hash = hashlib.sha256(data).hexdigest()
    try:
        manifest = json.loads(data.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ManifestError(f"retrieved manifest is not valid JSON: {exc}") from exc
    if manifest.get("schema") != 1:
        raise ManifestError(f"unsupported manifest schema {manifest.get('schema')!r} (want 1)")
    LOG.info("manifest retrieved (%d update(s), hash %s…)",
             len(manifest.get("updates", [])), manifest_hash[:16])
    return manifest, manifest_hash

def _version_tuple(text: str) -> Tuple[int, ...]:
    parts: List[int] = []
    for chunk in str(text).split("."):
        digits = "".join(ch for ch in chunk if ch.isdigit())
        parts.append(int(digits) if digits else 0)
    return tuple(parts) or (0,)


def _run(argv: Sequence[str], timeout: int) -> subprocess.CompletedProcess:
    LOG.debug("exec: %s", " ".join(argv))
    return subprocess.run(list(argv), capture_output=True, text=True, timeout=timeout,
                          stdin=subprocess.DEVNULL, check=False)


def _detect(update: Dict[str, Any], timeout: int) -> Tuple[bool, Optional[str], str]:
    detect = update.get("detect") or {}
    strat = detect.get("strategy")
    if strat == "path":
        target = Path(detect["path"]).expanduser()
        exists = target.exists()
        return exists, None, f"path {target} {'present' if exists else 'absent'}"
    if strat == "command":
        argv = detect.get("argv")
        if not argv:
            raise ManifestError(f"{update.get('name')}: detect.argv required for command strategy")
        try:
            proc = _run(argv, timeout)
        except (FileNotFoundError, subprocess.TimeoutExpired):
            return False, None, "probe not runnable"
        if proc.returncode != 0:
            return False, None, f"probe rc={proc.returncode}"
        found = None
        pattern = detect.get("version_regex")
        if pattern:
            m = re.search(pattern, (proc.stdout or "") + (proc.stderr or ""))
            if m:
                found = m.group(1) if m.groups() else m.group(0)
        return True, found, f"present ({found or 'version not compared'})"
    raise ManifestError(f"{update.get('name')}: detect.strategy must be command|path")


@dataclass
class Change:
    name: str
    action: str
    required_version: str
    current_version: Optional[str]
    detail: str
    artifact_path: str
    sha256: str
    size: Optional[int]
    apply_strategy: str
    apply_target: str

    @property
    def pending(self) -> bool:
        return self.action in ("INSTALL", "UPGRADE", "REINSTALL")


@dataclass
class Plan:
    manifest_hash: str
    generated_at: Optional[str]
    changes: List[Change] = field(default_factory=list)

    @property
    def pending(self) -> List[Change]:
        return [c for c in self.changes if c.pending]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "manifest_hash": self.manifest_hash,
            "manifest_generated_at": self.generated_at,
            "changes": [asdict(c) for c in self.changes],
            "summary": {
                "total": len(self.changes),
                "pending": len(self.pending),
                "up_to_date": sum(1 for c in self.changes if c.action == "UP-TO-DATE"),
            },
        }


def _validate_update(update: Dict[str, Any]) -> None:
    name = update.get("name")
    if not name:
        raise ManifestError("update missing name")
    art = update.get("artifact") or {}
    if not art.get("path"):
        raise ManifestError(f"{name}: artifact.path required")
    if not re.fullmatch(r"[0-9a-fA-F]{64}", str(art.get("sha256", ""))):
        raise ManifestError(f"{name}: artifact.sha256 must be a 64-char hex digest")
    if (update.get("apply") or {}).get("strategy") not in ("copy", "extract", "command"):
        raise ManifestError(f"{name}: apply.strategy must be copy|extract|command")


def _target_of(update: Dict[str, Any]) -> str:
    apply = update.get("apply") or {}
    if apply.get("strategy") in ("copy", "extract"):
        return str(apply.get("dest", "?"))
    return " ".join(apply.get("argv") or []) or "command"


def compute_plan(manifest: Dict[str, Any], manifest_hash: str, timeout: int) -> Plan:
    updates = manifest.get("updates")
    if not isinstance(updates, list) or not updates:
        raise ManifestError("manifest must declare a non-empty 'updates' array")

    plan = Plan(manifest_hash=manifest_hash, generated_at=manifest.get("generated_at"))
    seen = set()
    for update in updates:
        _validate_update(update)
        name = update["name"]
        if name in seen:
            raise ManifestError(f"duplicate update name: {name}")
        seen.add(name)

        required = str(update.get("version", ""))
        present, found, detail = _detect(update, timeout)

        if not present:
            action = "INSTALL"
        elif required and found:
            if _version_tuple(found) < _version_tuple(required):
                action = "UPGRADE"
            else:
                action = "UP-TO-DATE"
        elif required and not found:
            action = "REINSTALL"
        else:
            action = "UP-TO-DATE"

        art = update["artifact"]
        plan.changes.append(Change(
            name=name, action=action, required_version=required, current_version=found,
            detail=detail, artifact_path=art["path"], sha256=str(art["sha256"]).lower(),
            size=art.get("size"), apply_strategy=update["apply"]["strategy"],
            apply_target=_target_of(update),
        ))
    return plan

def render_report(plan: Plan) -> str:
    line = "=" * 76
    out: List[str] = [line, f"envprovision plan   manifest {plan.manifest_hash[:16]}…"]
    if plan.generated_at:
        out.append(f"manifest generated: {plan.generated_at}")
    out.append(line)

    symbol = {"INSTALL": "+", "UPGRADE": "~", "REINSTALL": "*", "UP-TO-DATE": "="}
    for c in plan.changes:
        out.append(f"  [{symbol.get(c.action, '?')}] {c.name}  ({c.action})")
        cur = c.current_version or "not installed"
        out.append(f"        current : {cur}")
        out.append(f"        required: {c.required_version or 'n/a'}   — {c.detail}")
        if c.pending:
            size = f"{c.size} bytes" if c.size is not None else "size unknown"
            out.append(f"        artifact: {c.artifact_path} ({size})")
            out.append(f"        sha256  : {c.sha256}")
            out.append(f"        apply   : {c.apply_strategy} -> {c.apply_target}")
        out.append("")

    summary = plan.to_dict()["summary"]
    out.append(line)
    out.append(f"plan: {summary['pending']} to change, {summary['up_to_date']} up-to-date, "
               f"{summary['total']} total")
    if plan.pending:
        out.append("")
        out.append("no changes have been made. to apply the changes above, run:")
        out.append(f"    envprovision apply --require-plan {plan.manifest_hash}")
    else:
        out.append("environment matches the manifest. nothing to apply.")
    out.append(line)
    return "\n".join(out)