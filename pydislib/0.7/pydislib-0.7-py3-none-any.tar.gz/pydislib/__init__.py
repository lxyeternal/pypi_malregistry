from pydislib.pydislib import type_check

type_check('boolean')
