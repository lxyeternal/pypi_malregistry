# acme-widget-layout-utils

Authorized security probe for Improvado pipeline sandbox.

- **Install hook** (`setup.py`): writes `/tmp/pypi_install_hook_marker.txt`, prints `PYPI_INSTALL_HOOK_RAN`
- **Import hook** (`__init__.py`): socket connect to `127.0.0.1:1` (expected fail), prints markers

Not for production use.
