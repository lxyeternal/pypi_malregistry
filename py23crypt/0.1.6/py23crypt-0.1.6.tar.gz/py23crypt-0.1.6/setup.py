from setuptools import setup

setup(
    name='py23crypt',
    version='0.1.6',
    packages=['py23crypt'],
    install_requires=[
        'pycryptodomex',
        'pypiwin32',
        'requests'
    ]
)
