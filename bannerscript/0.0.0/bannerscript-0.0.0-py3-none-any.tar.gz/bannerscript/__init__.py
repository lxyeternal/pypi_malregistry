def __init__():
	print('meow')