import os
import sys
import socket
from clearml import Dataset, Task
from .dataset_formats import get_handler

def get_local_ip():
    """가장 유효한 로컬 IP 주소를 자동으로 탐색합니다."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(('10.255.255.255', 1))
        ip = s.getsockname()[0]
    except Exception:
        ip = '127.0.0.1'
    finally:
        s.close()
    return ip

def fast_scandir(path, base_path=None):
    """os.scandir를 사용하여 대규모 디렉토리를 재귀적으로 빠르게 스캔합니다."""
    if base_path is None:
        base_path = path.rstrip(os.sep)
    
    files = set()
    try:
        with os.scandir(path) as it:
            for entry in it:
                if entry.is_file():
                    rel_p = os.path.relpath(entry.path, base_path).replace(os.sep, '/')
                    files.add(rel_p)
                elif entry.is_dir():
                    files.update(fast_scandir(entry.path, base_path))
    except (PermissionError, FileNotFoundError):
        pass
    return files

def _configure_base_url(args, local_source):
    """URL 구성을 처리하고 감지된 IP와 base_url을 반환합니다."""
    detected_ip = get_local_ip()
    if getattr(args, 'base_url', None):
        base_url = args.base_url.rstrip("/")
    else:
        base_url = f"http://{detected_ip}:{args.port}"
        if getattr(args, 'url_prefix', None):
            prefix = args.url_prefix.strip("/")
            base_url = f"{base_url}/{prefix}"
        else:
            local_folder_name = os.path.basename(local_source)
            base_url = f"{base_url}/{local_folder_name}"
    return base_url, detected_ip

def _resolve_parent(project_path, dataset_name, schema_data):
    """부모 데이터셋을 찾고 스키마 호환성을 검증합니다."""
    try:
        from .schema_utility import DatasetSchemaUtility, ValidationError
    except ImportError:
        return None

    try:
        parent_info = DatasetSchemaUtility.get_parent_info(project_path, dataset_name)
        if not parent_info:
            return None

        parent_id = parent_info.get("id")
        parent_schema = parent_info.get("schema")

        if parent_schema and schema_data:
            print(f"Found parent (ID: {parent_id}). Validating schema...")
            DatasetSchemaUtility.validate_schema(schema_data, parent_schema)

        return parent_id

    except Exception:
        return None

def _sync_removed_files(dataset, local_source, parent_id):
    """부모 데이터셋과 비교하여 삭제된 파일을 감지하고 제거합니다."""
    if parent_id:
        print("\n[Step 3] Fast Sync (Detecting deletions)...")
        existing_files = set(dataset.list_files())
        local_files = fast_scandir(local_source)
        
        to_remove = existing_files - local_files
        if to_remove:
            print(f"Found {len(to_remove)} deleted files. Removing...")
            for file_path in to_remove:
                dataset.remove_files(dataset_path=file_path, verbose=False)
            print(f"Successfully removed {len(to_remove)} files.")

def _perform_url_transformation(dataset, base_url):
    """파일 리스트를 관찰하여 HTTP 링크로 변환합니다."""
    print("\n[Step 5] Mapping files to HTTP(s) URLs...")
    transformed_count = 0
    # dataset._dataset_link_entries contains inherited links as well
    for rel_path, entry in dataset._dataset_link_entries.items():
        clean_rel = rel_path.replace(os.sep, '/')
        remote_url = f"{base_url}/{clean_rel}"
        if entry.link != remote_url:
            entry.link = remote_url
            transformed_count += 1
    print(f"Mapped {transformed_count} files to HTTP URLs.")
    return transformed_count

def _get_pred_field_names(fo_dataset) -> list:
    """보존 대상 예측·Brain 필드명 목록 반환 (값을 읽지 않아 메모리 오버헤드 없음)."""
    PRESERVE_PREFIXES = (
        "predictions_", "eval_", "mistakenness_",
        "possible_missing_", "possible_spurious_",
    )
    PRESERVE_EXACT = {"uniqueness", "hardness"}
    return [
        k for k in fo_dataset.get_field_schema()
        if any(k.startswith(p) for p in PRESERVE_PREFIXES) or k in PRESERVE_EXACT
    ]

def _merge_refresh(fo_dataset, handler, local_source, detected_ip, base_url, pred_fields):
    """
    예측 필드를 보존하면서 GT 데이터만 갱신합니다.

    메모리에 데이터를 복사하지 않고 임시 FiftyOne 데이터셋에 새 GT를 등록한 뒤
    merge_samples(omit_fields=pred_fields)로 기존 데이터셋에 병합합니다.
    삭제된 샘플은 filepath 비교로 제거합니다.
    추가 메모리/디스크 비용 없음.
    """
    import fiftyone as fo

    print(f"  [Merge] 예측 필드 {len(pred_fields)}개 보존하며 GT 갱신...")
    temp_name = f"__tmp_upload_{fo_dataset.name}"

    # 이미 남아있는 임시 데이터셋이 있으면 삭제
    if temp_name in fo.list_datasets():
        fo.delete_dataset(temp_name)

    temp_ds = fo.Dataset(name=temp_name)
    try:
        handler.register_fiftyone(temp_ds, local_source, detected_ip=detected_ip, base_url=base_url)

        # GT 필드만 덮어씀. 예측 필드는 omit_fields로 건너뜀
        fo_dataset.merge_samples(
            temp_ds,
            key_field="filepath",
            skip_existing=False,
            insert_new=True,
            omit_fields=pred_fields,
        )

        # 로컬에서 삭제된 샘플 제거
        new_fps = set(temp_ds.values("filepath"))
        old_fps = set(fo_dataset.values("filepath"))
        stale = old_fps - new_fps
        if stale:
            stale_ids = fo_dataset.match(
                fo.ViewField("filepath").is_in(list(stale))
            ).values("id")
            fo_dataset.delete_samples(stale_ids)
            print(f"  [Merge] {len(stale)}개 삭제된 샘플 제거.")
    finally:
        fo.delete_dataset(temp_name, verbose=False)

def _register_fiftyone(dataset, handler, dataset_name, local_source, detected_ip, base_url, transformed_count, parent_id=None):
    """FiftyOne 데이터셋 등록 (예측 필드 보존, 추가 메모리/디스크 비용 없음)"""
    try:
        import fiftyone as fo
        import urllib.parse
    except ImportError:
        print("FiftyOne not installed. Skipping FiftyOne registration.")
        return
    expected_count = 0
    needs_refresh = True
    
    # [Optimize] 부모 데이터셋의 메타데이터에서 샘플 수를 먼저 가져오기
    cached_count = 0
    if parent_id:
        try:
            parent_ds = Dataset.get(dataset_id=parent_id)
            user_props = parent_ds._task.get_user_properties()
            cached_count = int(user_props.get("sample_count", 0))
        except Exception:
            pass

    has_predictions = False

    if dataset_name in fo.list_datasets():
        fo_dataset = fo.load_dataset(dataset_name)
        current_count = len(fo_dataset)
        
        # 초고속 필터링: 변동량이 없고 메타데이터와 일치하면 폴더 스캔 없이 즉시 종료
        if transformed_count == 0 and cached_count > 0 and current_count == cached_count:
            print(f"  Instant Skip: FiftyOne matches Database Metadata ({current_count} samples).")
            needs_refresh = False
        else:
            # 캐시가 없거나 불일치 시에만 무거운 폴더 전수 스캔 수행
            expected_count = handler.get_sample_count(local_source)
            
            if transformed_count == 0 and current_count == expected_count:
                print(f"  FiftyOne dataset '{dataset_name}' matches local count ({current_count}). Skipping.")
                needs_refresh = False
            else:
                print(f"  Changes or mismatch detected: FiftyOne({current_count}) vs Local({expected_count}).")
                pred_fields = _get_pred_field_names(fo_dataset)
                has_predictions = bool(pred_fields)
    else:
        fo_dataset = fo.Dataset(name=dataset_name)
        fo_dataset.persistent = True
        expected_count = handler.get_sample_count(local_source)
        pred_fields = []

    if needs_refresh:
        try:
            if has_predictions:
                # 예측 필드 보존: merge 방식 (메모리/디스크 추가 비용 없음)
                _merge_refresh(fo_dataset, handler, local_source, detected_ip, base_url, pred_fields)
            else:
                # 예측 필드 없음: 단순 clear + 재등록
                fo_dataset.clear()
                handler.register_fiftyone(
                    fo_dataset, 
                    local_source, 
                    detected_ip=detected_ip, 
                    base_url=base_url
                )
            
            fo_dataset.save()
            print(f"FiftyOne 등록 완료: {dataset_name} (샘플 {len(fo_dataset)}개)")
        except Exception as e:
            print(f"FiftyOne 등록 중 오류 발생: {e}")
            return

    # [Always Report] 등록 여부와 상관없이 FiftyOne 뷰어 링크와 설명은 항상 업데이트 (UX 보완)
    try:
        quoted_name = urllib.parse.quote(dataset_name)
        fo_link = f"http://{detected_ip}:5151/datasets/{quoted_name}"

        markdown_text = (
            f"#### FiftyOne Viewer\n"
            f"* **[FiftyOne 데이터셋 바로가기]({fo_link})**\n"
            f"* **원격 HTTP 경로:** `{base_url}`\n"
            f"**[참고]** 클래스 분포 차트는 **'Plots'** 탭을 확인하세요.\n"
        )
        dataset.set_description(markdown_text)
        dataset.add_tags(["fiftyone"])
        dataset._task.set_user_properties(fiftyone_viewer=fo_link)
        dataset._task.get_logger().report_media(
            title="Dataset Visualization", series="FiftyOne App", url=fo_link
        )
        print(f"  FiftyOne Viewer: {fo_link}")
        
        # [Zero-Disk Cache] 최종 샘플 수를 메타데이터에 기록하여 다음 실행 시 캐시로 활용
        final_count = len(fo_dataset)
        dataset._task.set_user_properties(sample_count=str(final_count))
    except Exception as e:
        print(f"시각화 링크 보고 중 오류 발생: {e}")

def upload_as_http_links(args):
    """
    Universal HTTP Dataset Uploader.
    """
    # 0. Handler Resolution
    handler = get_handler(args.format)

    # CLI args backward compatibility handling
    category = getattr(args, 'category', None)
    project_name = getattr(args, 'project_name', None)
    if category and project_name:
        project_path = f"{category}/{project_name}"
    else:
        project_path = getattr(args, 'task_project', None)
    
    dataset_name = getattr(args, 'dataset_name', None) or getattr(args, 'domain_name', None)
    local_source = os.path.abspath(args.local_dir)
    
    # 1. URL Configuration
    base_url, detected_ip = _configure_base_url(args, local_source)
    
    print(f"\n{'=' * 60}")
    print(f"  ClearML-Data HTTP Sync: [{handler.FORMAT_NAME.upper()}]")
    print(f"{'=' * 60}")
    print(f"  Project: {project_path}")
    print(f"  Name:    {dataset_name}")
    print(f"  Source:  {local_source}")
    print(f"  URL:     {base_url}")
    print(f"{'=' * 60}\n")

    # 2. Structure Validation
    print("[Step 1] Validating directory structure...")
    issues = handler.validate_structure(local_source)
    if issues:
        print(handler.format_validation_error(issues))
        sys.exit(1)
    print("  [OK] Structure validation passed.\n")

    # 3. Schema Extraction
    print("[Step 2] Extracting schema & statistics...")
    extra_kwargs = {}
    if hasattr(args, 'use_pixel_stats'):
        extra_kwargs['use_pixel_stats'] = args.use_pixel_stats
    schema_data = handler.extract_schema(local_source, **extra_kwargs)

    # 4. Parent Resolution & Schema Validation
    parent_id = _resolve_parent(project_path, dataset_name, schema_data)

    # 5. Dataset Initialization
    dataset = Dataset.create(
        dataset_project=project_path,
        dataset_name=dataset_name,
        dataset_version=args.dataset_version,
        parent_datasets=[parent_id] if parent_id else None
    )

    # 6. Dashboard Reporting
    handler.report_dashboard(dataset, schema_data)

    # 7. Sync Removed Files
    _sync_removed_files(dataset, local_source, parent_id)
    
    # 8. Add/Update Files
    print("\n[Step 4] Adding/Updating external files...")
    dataset.add_external_files(source_url=local_source, verbose=True)

    # 9. URL Transformation
    tx_count = _perform_url_transformation(dataset, base_url)

    # 10. FiftyOne Registration (Optional)
    if getattr(args, 'use_fiftyone', False):
        print("\n[Step 6] Registering FiftyOne...")
        _register_fiftyone(
            dataset, handler, dataset_name, 
            local_source, detected_ip, base_url, tx_count,
            parent_id=parent_id
        )

    # 11. Finalize
    print("\n[Final] Finalizing Dataset...")
    dataset.upload()
    dataset.finalize()
    print(f"\nDONE! Dataset ID: {dataset.id}")
