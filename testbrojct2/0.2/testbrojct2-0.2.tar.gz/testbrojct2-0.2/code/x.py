# testbrojct2/x.py

def some_function():
    return("Hello from testbrojct2!")
