"""Domain Research Toolset - wraps OmicVerse domain research pipeline.

Provides a simple tool to generate a concise, cited report for a query.
Falls back to a lightweight demo pipeline if OmicVerse is unavailable.
"""

from .core import DomainResearchToolSet

__all__ = ["DomainResearchToolSet"]

