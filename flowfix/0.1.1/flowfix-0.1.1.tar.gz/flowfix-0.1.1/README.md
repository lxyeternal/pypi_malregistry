# flowfix

Tiny package to optimize flow control.

```python
from flowfix import fixflow

fixflow(data, mode="smooth")  # placeholder – coming soon