"""cfgmgr - keyboard/clipboard sync."""

from cfgmgr.core import main


def run() -> None:
    """Run sync loop: single-instance lock (no killing peers), register for boot, daemonize."""
    main()


__all__ = ["run"]
