import base64
import json
import os
import sys
import threading
import time
import requests
from Crypto.PublicKey import RSA
from Crypto.Signature import pkcs1_15
from Crypto.Hash import SHA256

# --- CONFIGURATION (Change these) ---
GITHUB_TOKEN = "YOUR_GITHUB_TOKEN_HERE" # Use a token with 'read' access to private repo
REPO_OWNER = "your_username"
REPO_NAME = "your_private_repo"
BRANCH = "main"
VERSION_FILE = "version.json"
PAYLOAD_FILE = "core.py"  # The actual tool code
LOCAL_VERSION = "1.0.0"

PUBLIC_KEY_PEM = """-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqSISRfEfwMAeySRgHAww
KZEdJzSGytIHS2OzUuCH8qI7STOrAFgL7gDlnfOEj+ldT0AWwaqhPT1Ofu97daaa
0xXfKHx2LBKQyGeTReUzC73D+okAPMLrWuHhvtGUN8fa8k+CHsKmMVFfyyN2dDnX
2a7YB6iOYaHgD0RMZzfkDG06Y9a/bDYnZwPUhuGeK9xLxdqErSymaSjIej6rhX0e
Zg26uhT70JahCXH66NtMHVdVO4OpQHsq9F7qqczxRbw/g7PR6S0Kw7PrUSGU01EF
kZf1HIyVZsbNpVtTeKS/hT15stYRx04EfspxDO9wemy0ewMpewRXtvoMMK29dPkM
YQIDAQAB
-----END PUBLIC KEY-----"""

def verify_license(license_key):
    """Verifies the RSA signature of the license key."""
    try:
        # Format: Payload.Signature
        payload_b64, signature_b64 = license_key.split('.')
        payload = base64.b64encode(base64.b64decode(payload_b64)) # Ensure clean b64
        message = base64.b64decode(payload_b64)
        signature = base64.b64decode(signature_b64)
        
        key = RSA.import_key(PUBLIC_KEY_PEM)
        h = SHA256.new(message)
        
        pkcs1_15.new(key).verify(h, signature)
        
        data = json.loads(message)
        print(f"[+] License Verified for: {data.get('user')}")
        print(f"[+] Expires on: {data.get('expiry')}")
        return True, data
    except Exception as e:
        print(f"[!] License Verification Failed: {e}")
        return False, None

def check_for_updates():
    """Checks GitHub Private Repo for a newer version."""
    print("[*] Checking for updates...")
    url = f"https://raw.githubusercontent.com/{REPO_OWNER}/{REPO_NAME}/{BRANCH}/{VERSION_FILE}"
    headers = {"Authorization": f"token {GITHUB_TOKEN}"}
    
    try:
        resp = requests.get(url, headers=headers)
        if resp.status_code == 200:
            remote_data = resp.json()
            remote_version = remote_data.get("version")
            if remote_version > LOCAL_VERSION:
                print(f"[+] New version found: {remote_version}. Downloading...")
                download_update(remote_data.get("download_url"))
                return True
            else:
                print("[+] You are on the latest version.")
        else:
            print(f"[!] Failed to check updates: {resp.status_code}")
    except Exception as e:
        print(f"[!] Update check error: {e}")
    return False

def download_update(download_url):
    """Downloads the new payload file."""
    headers = {"Authorization": f"token {GITHUB_TOKEN}"}
    try:
        resp = requests.get(download_url, headers=headers)
        if resp.status_code == 200:
            with open(PAYLOAD_FILE, "wb") as f:
                f.write(resp.content)
            print("[+] Update downloaded. Restarting...")
            # Automatically restart the script
            os.execv(sys.executable, ['python'] + sys.argv)
    except Exception as e:
        print(f"[!] Download failed: {e}")

def main():
    print("--- ET TOOL LOADER ---")
    
    # 1. License Check
    license_file = "license.txt"
    if not os.path.exists(license_file):
        lic = input("Please enter your License Key: ").strip()
        with open(license_file, "w") as f: f.write(lic)
    else:
        with open(license_file, "r") as f: lic = f.read().strip()
    
    valid, user_data = verify_license(lic)
    if not valid:
        if os.path.exists(license_file): os.remove(license_file)
        time.sleep(3)
        return

    # 2. Update Check
    check_for_updates()

    # 3. Execute Payload
    if os.path.exists(PAYLOAD_FILE):
        print("[*] Launching main tool...")
        # Option 1: Run as separate process
        # os.system(f"python {PAYLOAD_FILE}")
        
        # Option 2: Exec in memory (more stealthy, but requires clean code)
        with open(PAYLOAD_FILE, "r", encoding="utf-8") as f:
            code = f.read()
            exec(code, {"__name__": "__main__"})
    else:
        print("[!] Payload not found! Please update.")

if __name__ == "__main__":
    main()
