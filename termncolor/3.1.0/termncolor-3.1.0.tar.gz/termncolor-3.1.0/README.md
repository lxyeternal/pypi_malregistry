## termncolor

ANSI color formatting for output in terminal

### Installation

```
pip install termncolor
```

### Example
```
import sys

from termncolor import colored, cprint

text = colored("Hello, World!", "red", attrs=["reverse", "blink"])
print(text)
cprint("Hello, World!", "green", "on_red")

print_red_on_cyan = lambda x: cprint(x, "red", "on_cyan")
print_red_on_cyan("Hello, World!")
print_red_on_cyan("Hello, Universe!")

for i in range(10):
    cprint(i, "magenta", end=" ")

cprint("Attention!", "red", attrs=["bold"], file=sys.stderr)

# You can also specify 0-255 RGB ints via a tuple
cprint("Both foreground and background can use tuples", (100, 150, 250), (50, 60, 70))
```

### Overrides

Terminal colour detection can be disabled or enabled in several ways.

In order of precedence:
* Calling colored or cprint with a truthy no_color disables colour.
* Calling colored or cprint with a truthy force_color forces colour.
* Setting the ANSI_COLORS_DISABLED environment variable to any non-empty value disables colour.
* Setting the NO_COLOR environment variable to any non-empty value disables colour.
* Setting the FORCE_COLOR environment variable to any non-empty value forces colour.
* Setting the TERM environment variable to dumb, or using such a dumb terminal, disables colour.
* Finally, termncolor will attempt to detect whether the terminal supports colour.
