import tser
tser.init()