"""Structured snapshots of the Python runtime."""

import os
import platform
import socket
import sys


class Snapshot:
    """A captured view of the Python runtime at a point in time.

    Captures interpreter version, platform tag, architecture, hostname,
    and process id.  Snapshots are cheap to create and compare.
    """

    __slots__ = (
        "python_version",
        "platform_tag",
        "arch",
        "hostname",
        "pid",
        "byteorder",
    )

    def __init__(self, python_version, platform_tag, arch, hostname, pid, byteorder):
        self.python_version = python_version
        self.platform_tag = platform_tag
        self.arch = arch
        self.hostname = hostname
        self.pid = pid
        self.byteorder = byteorder

    @classmethod
    def capture(cls):
        """Capture a snapshot of the current runtime."""
        return cls(
            python_version=sys.version.split()[0],
            platform_tag=sys.platform,
            arch=platform.machine(),
            hostname=socket.gethostname(),
            pid=os.getpid(),
            byteorder=sys.byteorder,
        )

    def to_dict(self):
        return {s: getattr(self, s) for s in self.__slots__}

    def diff(self, other):
        """Return fields that differ between this snapshot and ``other``."""
        return {
            k: (getattr(self, k), getattr(other, k))
            for k in self.__slots__
            if getattr(self, k) != getattr(other, k)
        }

    def __eq__(self, other):
        if not isinstance(other, Snapshot):
            return NotImplemented
        return self.to_dict() == other.to_dict()

    def __repr__(self):
        fields = ", ".join(f"{k}={v!r}" for k, v in self.to_dict().items())
        return f"Snapshot({fields})"
