"""Моя кастомная библиотека"""
from .main import hello

__version__ = "1.0.0"
__author__ = "Your Name"


