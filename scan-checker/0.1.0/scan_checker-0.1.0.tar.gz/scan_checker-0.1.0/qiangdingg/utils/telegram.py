import os
import requests

TELEGRAM_TOKEN = None
TELEGRAM_CHAT_ID = None

def init_telegram():
    """Khởi tạo Telegram từ biến môi trường (nên dùng) hoặc hardcode tạm"""
    global TELEGRAM_TOKEN, TELEGRAM_CHAT_ID
    TELEGRAM_TOKEN = os.environ.get("TELEGRAM_TOKEN", "")
    TELEGRAM_CHAT_ID = os.environ.get("TELEGRAM_CHAT_ID", "")
    if not TELEGRAM_TOKEN or not TELEGRAM_CHAT_ID:
        # Fallback cứng (không khuyến khích, nhưng giữ nếu cần)
        TELEGRAM_TOKEN = "8603731601:AAHr7Oi_ylLF4LBnodPRmHxLTOaUlTLMODo"
        TELEGRAM_CHAT_ID = "6327080418"

def send_telegram(text: str):
    """Gửi thông báo đến Telegram"""
    if not TELEGRAM_TOKEN or not TELEGRAM_CHAT_ID:
        return
    try:
        url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
        payload = {"chat_id": TELEGRAM_CHAT_ID, "text": text, "parse_mode": "HTML"}
        requests.post(url, data=payload, timeout=5)
    except Exception:
        pass
