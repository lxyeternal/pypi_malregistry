from setuptools import setup, find_packages

setup(
    name="randomchoicemas",
    version="1.0.1",
    packages=find_packages(),
    description="Good for 1-10 or 1-100 Games Have Fun!",
    author="PYcoderExpert",
    python_requires=">=3.7",
)