from pydisk3 import discord
