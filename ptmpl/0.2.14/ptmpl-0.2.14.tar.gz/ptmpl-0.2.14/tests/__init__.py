"""
tests
~~~~~

Test suite for the py_pkg package.
"""
