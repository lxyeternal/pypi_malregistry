from setuptools import setup, find_packages

setup(
    name="rarcore-utils",
    version="1.3.2",
    description="Lightweight RAR5 archive helpers — environment checks, path utilities, and structural constants.",
    long_description=open("README.md").read() if __import__("os").path.exists("README.md") else "",
    long_description_content_type="text/markdown",
    author="rarcore-utils contributors",
    url="https://github.com/rarcore/rarcore-utils",
    license="MIT",
    packages=find_packages(),
    python_requires=">=3.8",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Topic :: System :: Archiving :: Compression",
    ],
)
