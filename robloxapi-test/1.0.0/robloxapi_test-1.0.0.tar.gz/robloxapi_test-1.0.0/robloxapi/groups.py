"""
Roblox Groups API - https://groups.roblox.com
"""

from typing import List, Optional


class GroupsAPI:
    BASE = "https://groups.roblox.com/v1"
    BASE2 = "https://groups.roblox.com/v2"

    def __init__(self, client):
        self._c = client

    def get_group(self, group_id: int) -> dict:
        """
        Get group info by ID.

        Returns:
            dict: {id, name, description, owner, shout, memberCount,
                   isBuildersClubOnly, publicEntryAllowed, hasVerifiedBadge}
        """
        return self._c._get(f"{self.BASE}/groups/{group_id}")

    def get_group_roles(self, group_id: int) -> dict:
        """
        Get all roles in a group.

        Returns:
            dict: {groupId, roles: [{id, name, description, rank,
                                     memberCount}, ...]}
        """
        return self._c._get(f"{self.BASE}/groups/{group_id}/roles")

    def get_group_members(self, group_id: int, role_id: Optional[int] = None,
                          limit: int = 10, cursor: Optional[str] = None,
                          sort_order: str = "Asc") -> dict:
        """
        Get members of a group, optionally filtered by role.

        Returns:
            dict: {previousPageCursor, nextPageCursor, data: [...]}
        """
        params = {"limit": limit, "sortOrder": sort_order}
        if cursor:
            params["cursor"] = cursor
        if role_id:
            return self._c._get(
                f"{self.BASE}/groups/{group_id}/roles/{role_id}/users",
                params=params,
            )
        return self._c._get(
            f"{self.BASE}/groups/{group_id}/users",
            params=params,
        )

    def get_user_groups(self, user_id: int) -> dict:
        """
        Get all groups a user belongs to.

        Returns:
            dict: {data: [{group, role}, ...]}
        """
        return self._c._get(f"{self.BASE2}/users/{user_id}/groups/roles")

    def search_groups(self, keyword: str, prioritize_exact: bool = True) -> dict:
        """
        Search for groups by name.

        Returns:
            dict: {keyword, previousPageCursor, nextPageCursor, data: [...]}
        """
        return self._c._get(
            f"{self.BASE}/groups/search",
            params={"keyword": keyword,
                    "prioritizeExactMatch": prioritize_exact},
        )

    def get_group_wall(self, group_id: int, limit: int = 10,
                       cursor: Optional[str] = None,
                       sort_order: str = "Desc") -> dict:
        """
        Get group wall posts.

        Returns:
            dict: {previousPageCursor, nextPageCursor, data: [...]}
        """
        params = {"limit": limit, "sortOrder": sort_order}
        if cursor:
            params["cursor"] = cursor
        return self._c._get(
            f"{self.BASE}/groups/{group_id}/wall/posts",
            params=params,
        )

    def get_group_funds(self, group_id: int) -> dict:
        """
        Get a group's current Robux balance (requires auth + group perms).

        Returns:
            dict: {robux}
        """
        return self._c._get(
            f"https://economy.roblox.com/v1/groups/{group_id}/currency"
        )

    def get_group_audit_log(self, group_id: int, action_type: str = "",
                            limit: int = 10,
                            cursor: Optional[str] = None) -> dict:
        """
        Get the group audit log (requires auth + admin perms).

        Returns:
            dict: {previousPageCursor, nextPageCursor, data: [...]}
        """
        params = {"limit": limit}
        if action_type:
            params["actionType"] = action_type
        if cursor:
            params["cursor"] = cursor
        return self._c._get(
            f"{self.BASE}/groups/{group_id}/audit-log",
            params=params,
        )
