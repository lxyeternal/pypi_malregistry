==============
``connection``
==============

.. automodule:: fabric.connection
