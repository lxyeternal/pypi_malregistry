from __future__ import annotations

import base64
import hashlib
import logging
import os
import re
import ssl
import time
from dataclasses import dataclass, field
from pathlib import Path, PurePosixPath
from typing import Optional, Tuple
from urllib import error as urlerror
from urllib import request as urlrequest
from urllib.parse import quote, urljoin

LOG = logging.getLogger("envprovision.repository")
HASH_CHUNK = 1024 * 1024


class RepositoryError(Exception):
    pass


class VerificationError(RepositoryError):
    pass


def sha256_file(path: Path) -> Tuple[str, int]:
    digest = hashlib.sha256()
    size = 0
    with path.open("rb") as fh:
        while True:
            chunk = fh.read(HASH_CHUNK)
            if not chunk:
                break
            size += len(chunk)
            digest.update(chunk)
    return digest.hexdigest(), size


@dataclass
class RepoAuth:
    mode: str = "none"
    token_env: Optional[str] = None
    username: Optional[str] = None
    password_env: Optional[str] = None

    def header(self) -> Optional[str]:
        if self.mode == "none":
            return None
        if self.mode == "bearer":
            token = os.environ.get(self.token_env or "")
            if not token:
                raise RepositoryError(f"bearer token env {self.token_env!r} unset/empty")
            return f"Bearer {token}"
        if self.mode == "basic":
            password = os.environ.get(self.password_env or "")
            if password is None:
                raise RepositoryError(f"basic password env {self.password_env!r} unset")
            raw = f"{self.username}:{password}".encode("utf-8")
            return "Basic " + base64.b64encode(raw).decode("ascii")
        raise RepositoryError(f"unknown auth mode {self.mode!r}")


@dataclass
class RepoConfig:
    base_url: str
    auth: RepoAuth = field(default_factory=RepoAuth)
    verify_tls: bool = True
    ca_bundle: Optional[str] = None


class Repository:
    def __init__(self, cfg: RepoConfig, timeout: int = 120, retries: int = 3,
                 max_artifact_mb: int = 512) -> None:
        self.cfg = cfg
        self.timeout = timeout
        self.retries = retries
        self.max_bytes = max_artifact_mb * 1024 * 1024
        self.ctx = self._ssl_context()

    def _ssl_context(self) -> ssl.SSLContext:
        if not self.cfg.verify_tls:
            LOG.warning("TLS verification DISABLED for %s — internal use only", self.cfg.base_url)
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            return ctx
        if self.cfg.ca_bundle:
            ca = Path(self.cfg.ca_bundle).expanduser()
            if not ca.exists():
                raise RepositoryError(f"ca_bundle not found: {ca}")
            return ssl.create_default_context(cafile=str(ca))
        return ssl.create_default_context()

    def _url(self, artifact_path: str) -> str:
        safe = quote(str(PurePosixPath(artifact_path)).lstrip("/"))
        return urljoin(self.cfg.base_url.rstrip("/") + "/", safe)

    def download(self, artifact_path: str, dest: Path) -> int:
        url = self._url(artifact_path)
        headers = {"User-Agent": "envprovision/1.0.0", "Accept": "application/octet-stream"}
        auth = self.cfg.auth.header()
        if auth:
            headers["Authorization"] = auth

        last: Optional[Exception] = None
        for attempt in range(1, self.retries + 1):
            try:
                LOG.info("downloading %s (attempt %d/%d)", url, attempt, self.retries)
                req = urlrequest.Request(url, headers=headers, method="GET")
                with urlrequest.urlopen(req, timeout=self.timeout, context=self.ctx) as resp:
                    declared = resp.headers.get("Content-Length")
                    if declared and int(declared) > self.max_bytes:
                        raise RepositoryError(f"declared size {declared} exceeds cap {self.max_bytes}")
                    return self._stream(resp, dest)
            except urlerror.HTTPError as exc:
                last = exc
                if exc.code < 500:
                    raise RepositoryError(f"HTTP {exc.code} {exc.reason} for {artifact_path}") from exc
                LOG.warning("HTTP %s attempt %d", exc.code, attempt)
            except (urlerror.URLError, TimeoutError, ssl.SSLError, OSError) as exc:
                last = exc
                LOG.warning("transient error attempt %d: %s", attempt, exc)
            if attempt < self.retries:
                time.sleep(min(2 ** attempt, 30))
        raise RepositoryError(f"{artifact_path}: exhausted {self.retries} attempts: {last}")

    def _stream(self, resp, dest: Path) -> int:
        written = 0
        try:
            with dest.open("wb") as fh:
                while True:
                    chunk = resp.read(HASH_CHUNK)
                    if not chunk:
                        break
                    written += len(chunk)
                    if written > self.max_bytes:
                        raise RepositoryError(f"artifact exceeded cap {self.max_bytes} mid-stream")
                    fh.write(chunk)
        except OSError as exc:
            raise RepositoryError(f"cannot write {dest}: {exc}") from exc
        return written


def verify_artifact(name: str, path: Path, expected_sha256: str,
                    expected_size: Optional[int] = None) -> None:
    expected = str(expected_sha256).lower()
    if not re.fullmatch(r"[0-9a-f]{64}", expected):
        raise VerificationError(f"{name}: declared sha256 is not a 64-char hex digest")
    actual, size = sha256_file(path)
    if actual != expected:
        raise VerificationError(f"{name}: sha256 mismatch expected={expected} actual={actual}")
    if expected_size is not None and int(expected_size) != size:
        raise VerificationError(f"{name}: size mismatch expected={expected_size} actual={size}")
    LOG.info("%s: verified (%s…)", name, actual[:16])